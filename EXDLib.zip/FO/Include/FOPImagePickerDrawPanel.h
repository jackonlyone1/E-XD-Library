//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPIMAGEPICKERDRAWPANEL_H__3B01D387_B6FF_46E1_A3EC_B52E5D094FF7__INCLUDED_)
#define AFX_FOPIMAGEPICKERDRAWPANEL_H__3B01D387_B6FF_46E1_A3EC_B52E5D094FF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPImagePickerDrawPanel.h : header file
//

#include "FOPComplexPickerDrawBase.h"

/////////////////////////////////////////////////////////////////////////////
// FOPImagePickerDrawPanel window
class FOPBitmapArray;

 
//===========================================================================
// Summary:
//     The FOPImagePickerDrawPanel class derived from FOPComplexPickerDrawBase
//      O P Image Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPImagePickerDrawPanel : public FOPComplexPickerDrawBase
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Image Picker Draw Panel, Constructs a FOPImagePickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		Res---Resource, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		sys---Specifies A Boolean value.  
	//		transparent---Specifies A Boolean value.  
	//		ind---Specifies a HasHeaderBar ind = NoHeaderBar object(Value).  
	//		but---Specifies a HasButton but = NoButton object(Value).
					FOPImagePickerDrawPanel(LPCTSTR Res, BOOL  sys = TRUE, BOOL  transparent = TRUE, 
										HasHeaderBar ind = NoHeaderBar, HasButton but = NoButton);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Image Picker Draw Panel, Constructs a FOPImagePickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		id---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		sys---Specifies A Boolean value.  
	//		transparent---Specifies A Boolean value.  
	//		ind---Specifies a HasHeaderBar ind = NoHeaderBar object(Value).  
	//		but---Specifies a HasButton but = NoButton object(Value).
					FOPImagePickerDrawPanel(UINT id, BOOL  sys = TRUE, BOOL  transparent = TRUE, 
										HasHeaderBar ind = NoHeaderBar, HasButton but = NoButton);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image Picker Draw Panel, Destructor of class FOPImagePickerDrawPanel
	//		Returns A  value (Object).
					~FOPImagePickerDrawPanel();


	// Notify system color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify System Color Change, .

	void			NotifySysColorChange();


	// forwarded to FOPBitmapArray
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		enabled---Specifies A Boolean value.
	// Draw state.
	void			Draw(CDC& DC, const CRect& rect, int nIndex, BOOL  transparent = FALSE, 
		BOOL  focus = FALSE, BOOL  enabled = TRUE);

	// Get fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetFillColor() const;

	// Get resource id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getp Resource I D, Returns the specified value.
	//		Returns a UINT type value.
	const UINT*		GetpResID();

	// Get image size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Sz, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&	GetImageSz() const;

	// Get use system colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Use System Colors, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetUseSystemColors() const;

	// Set use system colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use System Colors, Sets a specify value to current class FOPImagePickerDrawPanel
	// Parameters:
	//		bSys---bSys, Specifies A Boolean value.
	void			SetUseSystemColors(BOOL  bSys);

	// Add resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Resource, Adds an object to the specify list.
	// Parameters:
	//		id---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void			AddResource(UINT id);

	// Add resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Resource, Adds an object to the specify list.
	// Parameters:
	//		Res---Resource, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void			AddResource(LPCTSTR Res);

	// Select resource to fitting height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Resource Fitting Height, Call this function to select the given item.
	// Parameters:
	//		HorzSz---Horizontal Sz, Specifies A integer value.
	void			SelectResFittingHeight(int HorzSz);

protected:
	// helper functions
	// Select bitmap array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Bitmap Array, Call this function to select the given item.
	// Parameters:
	//		ba---A pointer to the FOPBitmapArray or NULL if the call failed.
	void			SelectBitmapArray(FOPBitmapArray* ba);

	// Retrieve array of strings.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Retrieve Arr String, .

	void 			RetrieveArrStr();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.

	// Init
	void			Init();

	// data
 
	// Current Bitmap Array, This member maintains a pointer to the object FOPBitmapArray.  
	FOPBitmapArray*	CurrentBitmapArray;

	// Array of bitmap.
	CTypedPtrArray<CPtrArray,FOPBitmapArray*> vBitmapArray;

	// Do use system colors.
 
	// System Color, This member sets TRUE if it is right.  
	BOOL 			m_bSysColor;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPIMAGEPICKERDRAWPANEL_H__3B01D387_B6FF_46E1_A3EC_B52E5D094FF7__INCLUDED_)
