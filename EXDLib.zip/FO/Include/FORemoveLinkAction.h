//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOREMOVELINKACTION_H__DF116C83_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
#define AFC_FOREMOVELINKACTION_H__DF116C83_DD9D_11D5_A4AC_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action
///////////////////////////////////////

#include "FOPortShape.h"
#include "FOAction.h"

class CFOCompositeShape;

///////////////////////////////////////////////////////////////////////////////////
// CFORemoveLinkAction -- action that remove link from canvas.

 
//===========================================================================
// Summary:
//     The CFORemoveLinkAction class derived from CFOAction
//      F O Remove Link Action
//===========================================================================

class FO_EXT_CLASS CFORemoveLinkAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveLinkAction---F O Remove Link Action, Specifies a E-XD++ CFORemoveLinkAction object (Value).
	DECLARE_ACTION(CFORemoveLinkAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Link Action, Constructs a CFORemoveLinkAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFORemoveLinkAction(CFODataModel* pModel, CFODrawShape* pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Link Action, Destructor of class CFORemoveLinkAction
	//		Returns A  value (Object).
	~CFORemoveLinkAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set To Port, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetToPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetToPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set From Port, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetFromPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetFromPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Third Port, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetThirdPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Third Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetThirdPort();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lay Link, Returns the specified value.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed
	CFOLinkShape *GetLayLink() { return m_pLayOnLink; }
	
	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lay Link, Sets a specify value to current class CFORemoveLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void SetLayLink(CFOLinkShape *pLink) { m_pLayOnLink = pLink; }

// Attributes
protected:

	// The pointer of end port.
 
	// To Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pToPort;

	// The pointer of start port.
 
	// From Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pFromPort;

	// The pointer of third port.
 
	// Third Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pThirdPort;

	// The pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape* m_pShape;

	// Lay on link shape.
 
	// Lay On Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *  m_pLayOnLink;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORemoveLinkAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFORemoveLinkAction::GetShape()
{
	return m_pShape;
}

_FOLIB_INLINE void CFORemoveLinkAction::SetToPort(CFOPortShape *pShape)
{
	m_pToPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFORemoveLinkAction::GetToPort()
{
	return m_pToPort;
}

_FOLIB_INLINE void CFORemoveLinkAction::SetFromPort(CFOPortShape *pShape)
{
	m_pFromPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFORemoveLinkAction::GetFromPort()
{
	return m_pFromPort;
}


_FOLIB_INLINE void CFORemoveLinkAction::SetThirdPort(CFOPortShape *pShape)
{
	m_pThirdPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFORemoveLinkAction::GetThirdPort()
{
	return m_pThirdPort;
}

#endif // !defined(AFC_FOREMOVELINKACTION_H__DF116C83_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
