//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOBASEENDOBJECT_H__207A9EE0_BD25_11D5_A47C_525400EA266C__2027_INCLUDED_)
#define AFC_FOBASEENDOBJECT_H__207A9EE0_BD25_11D5_A47C_525400EA266C__2027_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// CFOBaseEndObject.
//
// This is the base class of arrow end object,override the OnDraw
// method to handle your own arrow end object.
//
//------------------------------------------------------

#include "FOArea.h"
#include <math.h>
#include "FOPVisualProxy.h"
#include "FOGlobals.h"

 
//===========================================================================
// Summary:
//     The CFOBaseEndObject class derived from CObject
//      F O Base End Object
//===========================================================================

class FO_EXT_CLASS CFOBaseEndObject : public CObject  
{
protected:

	// DECLARE SERIAL CLASS
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseEndObject---F O Base End Object, Specifies a E-XD++ CFOBaseEndObject object (Value).
	DECLARE_SERIAL(CFOBaseEndObject);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base End Object, Constructs a CFOBaseEndObject object.
	//		Returns A  value (Object).
	CFOBaseEndObject();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base End Object, Constructs a CFOBaseEndObject object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBaseEndObject& src object(Value).
	CFOBaseEndObject(const CFOBaseEndObject& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base End Object, Destructor of class CFOBaseEndObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseEndObject();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBaseEndObject object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.
	// Creates the base end object.
	virtual void Create(
		// Line start point.
		CPoint &ptLineStart,
		// Line end point
		CPoint &ptLineEnd
		);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBaseEndObject& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBaseEndObject& src object(Value).
	CFOBaseEndObject& operator=(const CFOBaseEndObject& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOBaseEndObject* Copy() const;

	// Build an Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void BuildArea(
		// Arrow area.
		CFOArea* pArea
		);

public:

	/*************************************************************************
	|*
	|* Fill brush properties
	|*
	\************************************************************************/

	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Is It Transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTransparent() const;

	// Change to transparent fill mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void		SetTransparent(const BOOL &bTransparent);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// Get Brush Hatch
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushHatch() const;

	// Change Brush Hatch type,must be HS_
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Hatch, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetBrushHatch(const int &nHatch);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,shape use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

public:

	/*************************************************************************
	|*
	|* Pen properties
	|*
	\************************************************************************/

	// Get Line Width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int			GetLineWidth() const		{ return m_nLineWidth; }

	// Change the line with.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void		SetLineWidth(const int &nWidth);

	// Get Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetLineColor() const		{ return m_crLine; }

	// Change the Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetLineColor(const COLORREF &crColor);

	// Is It Null Pen
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null Pen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsNullPen() const;

	// Set Null Pen,with null pen,the pen width is 0.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Null Pen, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&bNull---&bNull, Specifies A Boolean value.
	void		SetNullPen(const BOOL &bNull);

	// Get Pen Style,return with PS_SOLID,PS_DOT...etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Style, Returns the specified value.
	//		Returns a int type value.
	int			GetPenStyle() const;

	// Change the Pen Style.
	// nPenStyle -- must be the PS_SOLID,PT_DOT...etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Style, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&nPenStyle---Pen Style, Specifies A integer value.
	void		SetPenStyle(const int &nPenStyle);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data to file.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Implementation
	// Allow memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Memory,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCount---nCount, Specifies A integer value.
	virtual void		AllocMemory(int nCount);

	// Get the spots count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Count, Returns the specified value.
	//		Returns a int type value.
	int					GetSpotCount() const;

	// Get the spots pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A LPPOINT value (Object).
	virtual LPPOINT		GetPoints() const;

	// Get the points of arrow..
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		mpPoint---mpPoint, Specifies A CPoint type value.
	virtual void		GetPoints(
		// Array of points.
		CArray<CPoint,CPoint>& mpPoint
		) const;

	// Set spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Points, Sets a specify value to current class CFOBaseEndObject
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		mpPoints---mpPoints, Specifies A LPPOINT Points array.  
	//		&nCount---&nCount, Specifies A integer value.
	virtual void		SetPoints(
		// Points.
		LPPOINT mpPoints, 
		// Count of point.
		const int &nCount
		);

	// Set spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Points, Sets a specify value to current class CFOBaseEndObject
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		mpPoint---mpPoint, Specifies A CPoint type value.
	virtual void		SetPoints(
		// Array of points.
		const CArray<CPoint,CPoint>& mpPoint
		);

	// Obtain the bounding rectangle of the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect				GetBoundRect() const;

// Implementation
public:

	// Get Line EndPoints
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Points, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void		GetLineEndPoints(
		// Start point.
		CPoint &ptStart,
		// End point.
		CPoint &ptEnd
		);

	// Set Line EndPoints
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Points, Sets a specify value to current class CFOBaseEndObject
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptStart---ptStart, Specifies A CPoint type value.  
	//		ptEnd---ptEnd, Specifies A CPoint type value.
	virtual void		SetLineEndPoints(
		// Start point.
		CPoint ptStart,
		// End point.
		CPoint ptEnd);

	// Change the Arrow Length
	// nLength -- specify the arrow length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow Length, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	void				SetArrowLength(int nLength)		{ m_nArrowLength = nLength; }

	// Obtain Arrow Length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow Length, Returns the specified value.
	//		Returns a int type value.
	int					GetArrowLength()				{ return m_nArrowLength; }

	// Change the Arrow Width
	// nWidth -- specify the arrow width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow Width, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void				SetArrowWidth(int nWidth)		{ m_nArrowWidth = nWidth; }

	// Obtain the Arrow Width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow Width, Returns the specified value.
	//		Returns a int type value.
	int					GetArrowWidth()					{ return m_nArrowWidth; }

	// Build Line End
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		BuildLineEnd();

	// Change transparent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent Value, Sets a specify value to current class CFOBaseEndObject
	// Parameters:
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.
	void				SetTransparentValue(const BYTE &nTrans) { m_nTransparent = nTrans; }


public:

	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawArrowLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	// Do draw arc line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Angle Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&startAngle---&startAngle, Specifies A float value.  
	//		&endAngle---&endAngle, Specifies A float value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bFill---&bFill, Specifies A Boolean value.
	virtual void DoDrawArrowAngleArcLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd,
		const int &nWidth,const float &startAngle,const float &endAngle,const COLORREF &crFill,const BOOL &bFill);


	// Do draw polygon.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawArrowPolygon(CDC *pDC,LPPOINT points,int nCount,const COLORREF &crFill);

	// SVG_Arrow.
	virtual CString SVG_Arrow();


	// SVG_Gen();
	virtual void SVG_Gen(CString &str);
	
	// SVG_Fill
	CString SVG_Fill(COLORREF color, int GrayScale);
public:

	// Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawLine(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrack(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

protected:

	// Define for brush.
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOBaseEndObject object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* CreateBrush(CDC* pDC = NULL);

	// Define for font.
	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();


	// Define for pen.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pen, You construct a CFOBaseEndObject object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreatePen(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetPen(CDC* pDC = NULL);

	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen Object, .

	void ReleasePenObject();

public:

#ifdef _DEBUG

	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	// AssertValid
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// Dump
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Is current shape being selected or not.
	virtual BOOL IsShapeSelected();
	
	// Set selected mode.
	virtual void SetSelectedMode(const BOOL &bSelect);

	// Set in focus.
	void SetFocusMode(const BOOL &bFocus);

	// Returns a pointer to the cached GDI pen object. 
	BOOL m_bWithExtMode;
	int m_nExtType;

	CPoint m_ptStart1;
	CPoint m_ptStart2;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetTrackPen(CDC* pDC = NULL);

protected:

	// Is shape selected.
	BOOL						m_bShapeSelected;

	// Is focus mode
	BOOL					m_bInFocus;

	// Tracking pen.
	CFOPenObjData			m_pTrackPen;

	// Arrow length.
 
	// Arrow Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nArrowLength;
	
	// Arrow width.
 
	// Arrow Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nArrowWidth;

	// The points of the control.
 
	// Shape Points, This member specify LPPOINT object.  
	LPPOINT			m_lpShapePoints;

	// The count point of the control.
 
	// Component Point Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCompPtCount;

	// Cached GDI brush. 
 
	// Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData	m_pBrush;

	// The line width.
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineWidth;

	// The line color.
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLine;
	
	// Transparent pen.
 
	// Null Pen, This member sets TRUE if it is right.  
	BOOL			m_bNullPen;

	// Pen style.
 
	// Pen Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPenStyle;

	// Pen.
 
	// Pen, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData	m_pPen;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The transparent brush.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// The brush hatch type.
 
	// Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHatch;

	// Line start point.
 
	// Line Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLineStart;

	// Line end point.
 
	// Line End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLineEnd;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;

	// Transparent value.
 
	// Transparent, This member sets An 8-bit integer that is not signed.  
	BYTE			m_nTransparent;
};

#include "FOBaseEndObject.inl"

#endif // !defined(AFC_FOBASEENDOBJECT_H__207A9EE0_BD25_11D5_A47C_525400EA266C__2027_INCLUDED_)
