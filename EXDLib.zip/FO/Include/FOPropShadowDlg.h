//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPROPSHADOWDLG_H__F71F13E3_F502_11D5_A4D2_525400EA266C__INCLUDED_)
#define AFX_FOPROPSHADOWDLG_H__F71F13E3_F502_11D5_A4D2_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPropShadowDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPropShadowDlg dialog
#include "FOPropertySheetCtrl.h"
#include "FOFillShadowPage0.h"
#include "FOFillShadowPage1.h"
#include "FOFillShadowPage2.h"
#include "FOFillSampleButton.h"
#include "FOImageButton.h"

class CFOPropertySheetCtrl;
 
//===========================================================================
// Summary:
//     The CFOPropShadowDlg class derived from CDialog
//      F O Property Shadow Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropShadowDlg : public CDialog
{
// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Shadow Dialog, Constructs a CFOPropShadowDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropShadowDlg(CWnd* pParent = NULL);   // standard constructor

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property Shadow Dialog, Destructor of class CFOPropShadowDlg
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPropShadowDlg();
// Dialog Data
	//{{AFX_DATA(CFOPropShadowDlg)
	enum { IDD = IDD_FO_PROP_SHADOW };
 
	// Spin, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_ySpin;
 
	// Spin, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_xSpin;
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_xOffset;
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_yOffset;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

public:
	
 
	// Property Sheet, This member maintains a pointer to the object CFOPropertySheetCtrl.  
	CFOPropertySheetCtrl* m_pPropSheet;
 
	// Sheet0, This member maintains a pointer to the object CFOFillShadowPage0.  
	CFOFillShadowPage0* m_pSheet0;
 
	// Sheet1, This member maintains a pointer to the object CFOFillShadowPage1.  
	CFOFillShadowPage1* m_pSheet1;
 
	// Sheet2, This member maintains a pointer to the object CFOFillShadowPage2.  
	CFOFillShadowPage2* m_pSheet2;
public:

	// End dialog.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Dialog, This member function is called by the framework to allow your application to handle a Windows message.

	void OnEndDialog();

public:
	// Color select button.
 
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	

	// Pattern color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crFG;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBK;

	//Brush Type
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;

	//////////////////////////////
	// Pattern color.
 
	// Old F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldFG;

	// Background color.
 
	// Old B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldBK;

	//Brush Type
 
	// Old Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldBrushType;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

	// Old x offset value.
 
	// Old Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_xOldOffset;

	// Old y offset value.
 
	// Old Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_yOldOffset;

	//
 
	// Is Axis Up, This member sets TRUE if it is right.  
	BOOL	m_bIsAxisUp;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPropShadowDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropShadowDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPROPSHADOWDLG_H__F71F13E3_F502_11D5_A4D2_525400EA266C__INCLUDED_)
