//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPANWND_H__CF84FC72_E7C1_4803_831D_A6B81490F92C__INCLUDED_)
#define AFX_FOPANWND_H__CF84FC72_E7C1_4803_831D_A6B81490F92C__INCLUDED_
 
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPanWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPanWnd window
#include "FODataModelBase.h"
#include "FOPUtil.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPNewPanWnd window

FO_EXT_CLASS extern UINT FOP_WM_VIEWVALID;
FO_EXT_CLASS extern UINT FOP_WM_VIEWINVALID;
FO_EXT_CLASS extern UINT FOP_WM_SHAPECHANGED;
FO_EXT_CLASS extern UINT FOP_WM_VIEW_UPDATE;
FO_EXT_CLASS extern UINT FOP_ZOOMSCALE_CHANGE;
FO_EXT_CLASS extern UINT FOP_WM_COREMSG;

class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOPanWnd class derived from CWnd
//      F O Pan Window
//===========================================================================

class FO_EXT_CLASS CFOPanWnd : public CWnd
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pan Window, Constructs a CFOPanWnd object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pDrawView---Draw View, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	CFOPanWnd(CFOPCanvasCore *pDrawView);
	
	// Attributes
public:
	// view border.
	int nViewportBorder;
	
	// left top corner
	FOPRect rcLTcorner;
	
	// right top corner
	FOPRect rcRTcorner;
	
	// right bottom corner
	FOPRect rcRBcorner;
	
	// left bottom corner
	FOPRect rcLBcorner;
	
	// left edge
	FOPRect rcLeftEdge;
	
	// top edge
	FOPRect rcTopEdge;
	
	// right edge
	FOPRect rcRightEdge;
	
	// bottom edge
	FOPRect rcBottomEdge;
	
	// drag marker
	int dragMarker;
	
	// drag start.
	FOPPoint ptDragStart;
	
	// in drag area
	FOPRect rcInDragArea;
	
	// scale factor
	float scaleFactor;
	
	// new bound rectangle
	FOPRect m_newBounds;
	
	// old bound rectangle
    FOPRect m_oldBounds;
	
	// rc viewport
	FOPRect rcViewport;
	
	// rectangle for sizing.
    FOPRect rcSizing;
	
public:
	// Set pan rectangle.
	void DrawViewport(CDC *pDC);
	
	// Calculate border rectangle.
	void CalculateBorderRect(const FOPRect &rcView);
	
	// calculate view zoom to viewport.
	FOPRect CalculateViewZoomToViewport(FOPRect rect);
	
	// Re calculate overview bound rectangle
	FOPRect RecalculateOverviewBounds();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPanWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		lpszTitle---lpszTitle, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Create method.
    virtual BOOL Create(const CRect &rcPos, LPCTSTR lpszTitle = NULL);
	
	// Redraw current window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Window, Call this member function to update the object.
	// Parameters:
	//		&bRedraw---&bRedraw, Specifies A Boolean value.
	void UpdateWnd(const BOOL &bRedraw = TRUE);

	// Obtain the notify window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Notify Window, Returns the specified value.
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *GetNotifyWnd() const { return pNotifyWnd; }

	// Enable update once the canvas updated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Update Now, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableUpdateNow(const BOOL &bEnable);
	
	// Obtain the pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetActiveView() { return m_pActiveView; }

	// Obtain the pointer of the valid active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetValidActiveView();

	// Obtain the offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Offset, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetOffset() const { return m_ptOffset; }

	// Change the pointer of the active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active View, Sets a specify value to current class CFOPanWnd
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.
	void SetActiveView(CFOPCanvasCore* pView);
	

	// Obtain the border space for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Space, Returns the specified value.
	//		Returns a int type value.
	int GetBorderSpace() const { return m_nBorderSpace; }

	// Change the border space for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Space, Sets a specify value to current class CFOPanWnd
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetBorderSpace(const int &nBorder) { m_nBorderSpace = nBorder; }
	// Set pan rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pan Rectangle, Sets a specify value to current class CFOPNewPanWnd
	// Parameters:
	//		rcPan---rcPan, Specifies A CRect type value.
    void FreshPanRect(CRect rcPan);
	
	// Drawing track rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
    void OnDrawTrackScale(CDC * pDC);
	
protected:
	
	// Obtain the correct log rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetLogRect();

	// The size of the rect being dragged
 
	// Resize, This member sets a CSize value.  
    CSize        m_szResize;       
	
	// Is the mosue Hold
 
	// Mouse Hold, This member sets TRUE if it is right.  
    BOOL         m_bMouseHold;       

	// The current viewport
 
	// Track Position, This member sets a CRect value.  
    CRect        m_rcTrackPosition;

	// Start offset x position.
 
	// Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			 m_nxStart;

public:
	// Set pan rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pan Rectangle, Sets a specify value to current class CFOPanWnd
	// Parameters:
	//		rcPan---rcPan, Specifies A CRect type value.
    void SetPanRect(CRect rcPan);
	
	// Drawing track rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
    void OnDrawTrackLine(CDC * pDC);
	
	// Do update
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Update, Call InitUpdate after creating a new object.

    void InitUpdate();

	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPanWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pan Window, Destructor of class CFOPanWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPanWnd();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPanWnd)
	// NOTE - the ClassWizard will add and remove member functions here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
#if _MFC_VER >= 0x0421
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
#endif
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Window, Called to notify a view that its document has been modified.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnUpdateWnd(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
protected:
	
	//The pointer to Notify Window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *			pNotifyWnd;
	
	// Current showing view rectangle
 
	// View, This member sets a CRect value.  
	CRect			m_rcView;

	// Zoom rectangle
 
	// Zoom, This member sets a CRect value.  
	FOPRect			m_rcZoom;
	
	// Size of the view
 
	// View, This member sets a CSize value.  
    CSize			m_szView;
	
	// be capture or not
 
	// Captured, This member sets TRUE if it is right.  
	BOOL			m_bCaptured;

	// Update now or not
 
	// Update Now, This member sets TRUE if it is right.  
	BOOL			m_bUpdateNow;
	
	// Window zoom scale value
 
	// X Zoom Scale, This member specify double object.  
	double			m_dXZoomScale;

 
	// Y Zoom Scale, This member specify double object.  
	double			m_dYZoomScale;
	
	// Offset point
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptOffset;
	
	// Pointer of the view
 
	// Active View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore*	m_pActiveView;

	// Border space for drawing.
 
	// Border Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nBorderSpace;
};

/////////////////////////////////////////////////////////////////////////////
// CFOBaseSliderCtrl

 
//===========================================================================
// Summary:
//     The CFOBaseSliderCtrl class derived from CSliderCtrl
//      F O Base Slider 
//===========================================================================

class FO_EXT_CLASS CFOBaseSliderCtrl : public CSliderCtrl
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Slider , Constructs a CFOBaseSliderCtrl object.
	//		Returns A  value (Object).
	CFOBaseSliderCtrl();				// default constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Slider , Constructs a CFOBaseSliderCtrl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	CFOBaseSliderCtrl( COLORREF cr );	// constructs the control and sets its primary color
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Slider , Destructor of class CFOBaseSliderCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseSliderCtrl();
	// Attributes
public:
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOBaseSliderCtrl)
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetShadowColor() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Hilite Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetHiliteColor() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Primary Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetPrimaryColor() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Primary Color, Sets a specify value to current class CFOBaseSliderCtrl
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetPrimaryColor( COLORREF cr );
	// Generated message map functions
protected:
	
 
	// Primary, This member sets A 32-bit value used as a color value.  
	COLORREF m_crPrimary;
 
	// Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF m_crShadow;
 
	// Hilite, This member sets A 32-bit value used as a color value.  
	COLORREF m_crHilite;
 
	// Mid Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF m_crMidShadow;
 
	// Darker Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF m_crDarkerShadow;
	
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush m_normalBrush;
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush m_focusBrush;
	
	//{{AFX_MSG(CFOBaseSliderCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Reflected Custom Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReflectedCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Item, Called when a visual aspect of an owner-draw child button control, combo-box control, list-box control, or menu needs to be drawn.
	// Parameters:
	//		nIDCtl---I D Ctl, Specifies A integer value.  
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_MSG
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//////////////////////////////////////////////////////////////
// CFOZoomSliderCtrl
 
 
//===========================================================================
// Summary:
//     The CFOZoomSliderCtrl class derived from CFOBaseSliderCtrl
//      F O Zoom Slider 
//===========================================================================

class FO_EXT_CLASS CFOZoomSliderCtrl : public CFOBaseSliderCtrl
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Zoom Slider , Constructs a CFOZoomSliderCtrl object.
	//		Returns A  value (Object).
	CFOZoomSliderCtrl();
	
	// Attributes
public:
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOZoomSliderCtrl)
	//}}AFX_VIRTUAL
	
	// Implementation
public:
 

	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOZoomSliderCtrl
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void SetPos( int nPos );
 
	// Buddy Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd* m_pBuddyWnd;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reflected Scroll Message, .

	void ReflectedScrollMessage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Buddy, Sets a specify value to current class CFOZoomSliderCtrl
	//		Returns A HWND value (Object).  
	// Parameters:
	//		pBuddyWnd---Buddy Window, A pointer to the CWnd or NULL if the call failed.
	HWND SetBuddy( CWnd* pBuddyWnd );
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Zoom Slider , Destructor of class CFOZoomSliderCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOZoomSliderCtrl();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOZoomSliderCtrl)
	//}}AFX_MSG
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//////////////////////////////////////////////////////////////
// CFOPNewPanWnd
 
class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOPNewPanWnd class derived from CWnd
//      F O P New Pan Window
//===========================================================================

class FO_EXT_CLASS CFOPNewPanWnd : public CWnd
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Pan Window, Constructs a CFOPNewPanWnd object.
	//		Returns A  value (Object).
	CFOPNewPanWnd();
	
	// Attributes
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewPanWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new window
	// dwStyle -- style of the window,it should be WS_CHILD|WS_VISIBLE
	// rcPos -- init position of the window
	// pParent -- pointer of the parent window
	// nID -- id value of the window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);
	
	// Re calc the view within the window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Calculate View Position, .
	// Parameters:
	//		&rcNew---&rcNew, Specifies A CRect type value.
	void ReCalcViewPos(const CRect &rcNew);

	// Redraw current window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Window, Call this member function to update the object.
	// Parameters:
	//		&bRedraw---&bRedraw, Specifies A Boolean value.
	void UpdateWnd(const BOOL &bRedraw = TRUE);

	// Obtain the notify window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Notify Window, Returns the specified value.
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *GetNotifyWnd() const { return pNotifyWnd; }

	// Enable update once the canvas updated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Update Now, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableUpdateNow(const BOOL &bEnable);
	
	// Obtain the pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetActiveView() { return m_pActiveView; }

	// Obtain the pointer of the valid active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetValidActiveView();

	// Obtain the offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Offset, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetOffset() const { return m_ptOffset; }

	// Change the pointer of the active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active View, Sets a specify value to current class CFOPNewPanWnd
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.
	void SetActiveView(CFOPCanvasCore* pView);
	
	// Redraw current window with the size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Redraw With, .
	// Parameters:
	//		*pView---*pView, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	void RedrawWith(CFOPCanvasCore *pView);
	
	// Obtain the border space for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Space, Returns the specified value.
	//		Returns a int type value.
	int GetBorderSpace() const { return m_nBorderSpace; }

	// Change the border space for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Space, Sets a specify value to current class CFOPNewPanWnd
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetBorderSpace(const int &nBorder) { m_nBorderSpace = nBorder; }

	// Obtain the correct log rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetLogRect();

	BOOL bLockUpdate;
protected:
	
	// The size of the rect being dragged
 
	// Resize, This member sets a CSize value.  
    CSize        m_szResize;       
	
	// Is the mosue Hold
 
	// Mouse Hold, This member sets TRUE if it is right.  
    BOOL         m_bMouseHold;       

	// The current viewport
 
	// Track Position, This member sets a CRect value.  
    CRect        m_rcTrackPosition;

	// Start offset x position.
 
	// Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			 m_nxStart;

	// view border.
	int nViewportBorder;

	// left top corner
	FOPRect rcLTcorner;

	// right top corner
	FOPRect rcRTcorner;

	// right bottom corner
	FOPRect rcRBcorner;

	// left bottom corner
	FOPRect rcLBcorner;

	// left edge
	FOPRect rcLeftEdge;

	// top edge
	FOPRect rcTopEdge;

	// right edge
	FOPRect rcRightEdge;

	// bottom edge
	FOPRect rcBottomEdge;
	
	// drag marker
	int dragMarker;

	// drag start.
	FOPPoint ptDragStart;
	
	// in drag area
	FOPRect rcInDragArea;
	
	// scale factor
	float scaleFactor;

	// new bound rectangle
	FOPRect m_newBounds;

	// old bound rectangle
    FOPRect m_oldBounds;

	// rc viewport
	FOPRect rcViewport;

	// rectangle for sizing.
    FOPRect rcSizing;
	
public:
	// Set pan rectangle.
	void DrawViewport(CDC *pDC);

	// Calculate border rectangle.
	void CalculateBorderRect(const FOPRect &rcView);

	// calculate view zoom to viewport.
	FOPRect CalculateViewZoomToViewport(FOPRect rect);

	// Re calculate overview bound rectangle
	FOPRect RecalculateOverviewBounds();

	//-----------------------------------------------------------------------
	// Summary:
	// Set Pan Rectangle, Sets a specify value to current class CFOPNewPanWnd
	// Parameters:
	//		rcPan---rcPan, Specifies A CRect type value.
    void SetPanRect(CRect rcPan);
	
	// Set pan rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pan Rectangle, Sets a specify value to current class CFOPNewPanWnd
	// Parameters:
	//		rcPan---rcPan, Specifies A CRect type value.
    void FreshPanRect(CRect rcPan);
	
	// Drawing track rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
    void OnDrawTrackLine(CDC * pDC);
	
	// Drawing track rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
    void OnDrawTrackScale(CDC * pDC);
	
	// Do update
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Update, Call InitUpdate after creating a new object.

    void InitUpdate();

	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPNewPanWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Pan Window, Destructor of class CFOPNewPanWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewPanWnd();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPNewPanWnd)
	// NOTE - the ClassWizard will add and remove member functions here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
#if _MFC_VER >= 0x0421
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
#endif
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Window, Called to notify a view that its document has been modified.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnUpdateWnd(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
protected:
	
	//The pointer to Notify Window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *			pNotifyWnd;
	
	// Current showing view rectangle
 
	// View, This member sets a CRect value.  
	FOPRect			m_rcView;

	// Zoom rectangle
 
	// Zoom, This member sets a CRect value.  
	FOPRect			m_rcZoom;
	
	// Size of the view
 
	// View, This member sets a CSize value.  
    CSize			m_szView;
	
	// be capture or not
 
	// Captured, This member sets TRUE if it is right.  
	BOOL			m_bCaptured;

	// Update now or not
 
	// Update Now, This member sets TRUE if it is right.  
	BOOL			m_bUpdateNow;
	
	// Window zoom scale value
 
	// X Zoom Scale, This member specify double object.  
	double			m_dXZoomScale;
	
 
	// Y Zoom Scale, This member specify double object.  
	double			m_dYZoomScale;
	
	// Offset point
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptOffset;
	
	// Pointer of the view
 
	// Active View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore*	m_pActiveView;

	// Border space for drawing.
 
	// Border Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nBorderSpace;

 
	// With Canvas Update, This member sets TRUE if it is right.  
	BOOL			m_bWithCanvasUpdate;
};

/////////////////////////////////////////////////////////////////////////////
#include "FOPControlBar.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPNewPanBar

class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOPNewPanBar class derived from CFOPControlBar
//      F O P New Pan Bar
//===========================================================================

class FO_EXT_CLASS CFOPNewPanBar : public CFOPControlBar
{
	// Construction
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Pan Bar, Constructs a CFOPNewPanBar object.
	//		Returns A  value (Object).
	CFOPNewPanBar();

	// New style pan window
 
	// Pan, This member specify E-XD++ CFOPNewPanWnd object.  
	CFOPNewPanWnd m_wndPan;

	// Slider control
 
	// Slider, This member specify E-XD++ CFOZoomSliderCtrl object.  
	CFOZoomSliderCtrl   m_wndSlider;   

	// Obtain the pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetActiveView();

	// Obtain the pointer of the valid active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Active View, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore ,or NULL if the call failed
	CFOPCanvasCore *GetValidActiveView();

	// Change the pointer of the active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active View, Sets a specify value to current class CFOPNewPanBar
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.
	void SetActiveView(CFOPCanvasCore* pView);
	
	// Update current window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Window, Call this member function to update the object.
	// Parameters:
	//		&bRedraw---&bRedraw, Specifies A Boolean value.
	void UpdateWnd(const BOOL &bRedraw = TRUE);

	// Update zoom scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Zoom Scale, Call this member function to update the object.

	void UpdateZoomScale();

	// Convert scale value to pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Sacle, .
	//		Returns a int type value.  
	// Parameters:
	//		&dScale---&dScale, Specifies a const double &dScale object(Value).
	int ConvertSacle(const double &dScale);

public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPNewPanBar)
	//}}AFX_VIRTUAL

// Implementation
public:

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Pan Bar, Destructor of class CFOPNewPanBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewPanBar();

 
	// Old Canvas, This member sets a CRect value.  
	CRect rcOldCanvas;
	// Generated message map functions
protected:

	//{{AFX_MSG(CFOPNewPanBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd( CDC* pDC );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPANWND_H__CF84FC72_E7C1_4803_831D_A6B81490F92C__INCLUDED_)
