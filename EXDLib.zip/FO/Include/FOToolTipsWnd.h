//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOP_TIP_H__3E0080F3_ED3F_11D5_A4C9_525400EA266C__INCLUDED_)
#define AFX_FOP_TIP_H__3E0080F3_ED3F_11D5_A4C9_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOToolTipsWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOToolTipsWnd window

#include "fodefines.h"
// Tooltip's directions
#define FOP_TIP_TOPEDGE_LEFT		0x00
#define FOP_TIP_TOPEDGE_RIGHT		0x01
#define FOP_TIP_TOPEDGE_CENTER		0x02
#define FOP_TIP_BOTTOMEDGE_LEFT		0x10
#define FOP_TIP_BOTTOMEDGE_RIGHT	0x11
#define FOP_TIP_BOTTOMEDGE_CENTER	0x12
#define FOP_TIP_LEFTEDGE_TOP		0x20
#define FOP_TIP_LEFTEDGE_BOTTOM		0x21
#define FOP_TIP_LEFTEDGE_VCENTER	0x22
#define FOP_TIP_RIGHTEDGE_TOP		0x30
#define FOP_TIP_RIGHTEDGE_BOTTOM	0x31
#define FOP_TIP_RIGHTEDGE_VCENTER	0x32

// This info structure
 
//===========================================================================
// Summary:
//      To use a FOP_TIP_INFO object, just call the constructor.
//      O P_ T I P_ I N F O
//===========================================================================

class FOP_TIP_INFO
{
public:
	HWND		hWnd;
	// I D Tool, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT		m_nIDTool;			// ID of tool   
 
	// Bounds, This member sets a CRect value.  
    CRect		m_rcBounds;			// Bounding rect for tool info to be displayed
 
	// Tooltip, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_sTooltip;			// The string of the tooltip
 
	// Mask, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT        m_nMask;			// The mask 
 
	// Styles, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nStyles;			// The tooltip's styles
 
	// Direction, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT        m_nDirection;		// Direction display the tooltip relate cursor point
 
	// Effect, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nEffect;			// The color's type or effects
 
	// Behaviour, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT        m_nBehaviour;		// The tooltip's be haviour
 
	// Granularity, This member sets An 8-bit integer that is not signed.  
	BYTE        m_nGranularity;		// The effect's granularity
 
	// Transparency, This member sets An 8-bit integer that is not signed.  
	BYTE        m_nTransparency;	// The factor of the window's transparency (0-100)
 
	// Begin, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBegin;			// Begin Color
 
	// End, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crEnd;			// End Color

public:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ T I P_ I N F O, Constructs a FOP_TIP_INFO object.
	//		Returns A  value (Object).
	FOP_TIP_INFO();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P_ T I P_ I N F O, Destructor of class FOP_TIP_INFO
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOP_TIP_INFO();

	// =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOP_TIP_INFO& value (Object).  
	// Parameters:
	//		val---Specifies a const FOP_TIP_INFO& val object(Value).
	virtual FOP_TIP_INFO& operator=(const FOP_TIP_INFO& val);

};

/////////////////////////////////////////////////////////////////////////////
// CFOToolTipsWnd window

 
//===========================================================================
// Summary:
//     The CFOToolTipsWnd class derived from CWnd
//      F O Tool Tips Window
//===========================================================================

class FO_EXT_CLASS CFOToolTipsWnd : public CWnd
{
public:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Tips Window, Constructs a CFOToolTipsWnd object.
	//		Returns A  value (Object).
	CFOToolTipsWnd();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Tips Window, Destructor of class CFOToolTipsWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolTipsWnd();

// Attributes
public:

	// Tooltip shape rectangle.
	enum {	FOP_TIP_SZ_ROUNDED_CX = 0,
			FOP_TIP_SZ_ROUNDED_CY,
			FOP_TIP_SZ_MARGIN_CX,
			FOP_TIP_SZ_MARGIN_CY,
			FOP_TIP_SZ_WIDTH_ANCHOR,
			FOP_TIP_SZ_HEIGHT_ANCHOR,
			FOP_TIP_SZ_MARGIN_ANCHOR,
			FOP_TIP_SZ_OFFSET_ANCHOR_CX,
			FOP_TIP_SZ_OFFSET_ANCHOR_CY,
			FOP_TIP_SZ_MAX_SIZES
		};

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOToolTipsWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		bBalloon---bBalloon, Specifies A Boolean value.
	// Create method
	BOOL Create(CWnd* pParentWnd, BOOL bBalloon = TRUE);
	
	// Operations
protected:
	
	// Tooltip state
	enum FOPTooltipState 
	{  
		FOP_TIP_STATE_HIDEN = 0,
		FOP_TIP_STATE_SHOWING,
		FOP_TIP_STATE_SHOWN,
		FOP_TIP_STATE_HIDING
	};

	// Backgroud style.
	enum 
	{	
		FOP_EFFECT_SOLID = 0,
		FOP_EFFECT_HGRADIENT,
		FOP_EFFECT_VGRADIENT,
		FOP_EFFECT_HCGRADIENT,
		FOP_EFFECT_VCGRADIENT
	};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOToolTipsWnd)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:

	// Handle event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relay Event, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	BOOL		RelayEvent(MSG* pMsg);

	// Show tooltip
	// pt -- point of the tooltip for showing.
	// ti -- tooltip structure.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Help Tooltip, Call this function to show the specify object.
	// Parameters:
	//		pt---Specifies A LPPOINT Points array.  
	//		ti---Specifies a FOP_TIP_INFO & ti object(Value).
	void		ShowHelpTooltip (LPPOINT pt, FOP_TIP_INFO & ti);

	// Hide tooltip
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Tooltip, Hides the objects by removing it from the display screen. 

	void		HideTooltip();

	// Create all fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Font, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	AdjustFont();

	// Release the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ReleaseFont();

	// Change the pointer of the parent window
	// pWnd -- pointer of the parent window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void		SetParentWindow(CWnd *pWnd);

	// color's functions
	// Background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color Background, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void		SetColorBk(COLORREF color);

	// Change back color
	// clrBegin -- begin color for gradient.
	// clrEnd -- end color for gradient
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color Background, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		clrBegin---clrBegin, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrEnd---clrEnd, Specifies A 32-bit COLORREF value used as a color value.
	void		SetColorBk(COLORREF clrBegin, COLORREF clrEnd);

	// Change background effect
	// dwEffect -- background effect
	// nGranulayity -- granulyity value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Effect Background, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		dwEffect---dwEffect, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nGranularity---nGranularity, Specifies An 8-bit BYTE integer that is not signed.
	void		SetEffectBk(DWORD dwEffect, BYTE nGranularity = 5);

	// behaviour's methods
	// Change be haviour
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Behaviour, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		dwBehaviour---dwBehaviour, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		SetBehaviour(DWORD dwBehaviour = 0);

	// Obtain the be haviour
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Behaviour, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD		GetBehaviour();

	// Change delay time
	// dwDuration -- duration time.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Delay Time, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		dwDuration---dwDuration, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwTime---dwTime, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		SetDelayTime(DWORD dwDuration, DWORD dwTime);

	// Obtain the dealy time
	// dwDuration -- delay time value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Delay Time, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwDuration---dwDuration, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD		GetDelayTime(DWORD dwDuration) const;

	// functions for sizes
	// Change shape size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		nSizeIndex---Size Index, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nValue---nValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		SetSize(DWORD nSizeIndex, DWORD nValue);

	// Obtain the shape size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		nSizeIndex---Size Index, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD		GetSize(DWORD nSizeIndex);

	// Set default size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Sizes, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		bBalloonSize---Balloon Size, Specifies A Boolean value.
	void		SetDefaultSizes(BOOL bBalloonSize = TRUE);

	// Change direction
	// dwDirection -- direction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Direction, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		dwDirection---dwDirection, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		SetDirection (DWORD dwDirection = FOP_TIP_BOTTOMEDGE_LEFT);

	// Obtain the direction.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direction, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD		GetDirection();

	// functions for notify window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		hWnd---hWnd, Specifies a HWND hWnd object(Value).
	void		SetNotify(HWND hWnd);

	// functions for notify window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		bParentNotify---Parent Notify, Specifies A Boolean value.
	void		SetNotify(BOOL bParentNotify = TRUE);

	// Hide border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Border, Hides the objects by removing it from the display screen. 

	void		HideBorder();

	// Change border color width,and height
	// color -- border color
	// nWidth -- border width
	// nHeight -- border height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	void		SetBorder(COLORREF color, int nWidth = 1, int nHeight = 1);

	// Change border brush width,and height.
	// hbr -- border fill brush
	// nWidth -- border width
	// nHeight -- border height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		hbr---Specifies a HBRUSH hbr object(Value).  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	void		SetBorder(HBRUSH hbr, int nWidth = 1, int nHeight = 1);

	// Transparency of tooltip
	// nTransparency -- transparency value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		nTransparency---nTransparency, Specifies An 8-bit BYTE integer that is not signed.
	void		SetTransparency(BYTE nTransparency = 0);

	// Obtain the transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.
	_FOLIB_INLINE		BYTE GetTransparency() { return m_nTransparency; }

	// Shadow of the tooltip
	// nOffsetX -- shadow offset x value
	// nOffsetY -- shadow offset y value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tooltip Shadow, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.  
	//		nDarkenPercent---Darken Percent, Specifies An 8-bit BYTE integer that is not signed.  
	//		bGradient---bGradient, Specifies A Boolean value.  
	//		nDepthX---Depth X, Specifies A integer value.  
	//		nDepthY---Depth Y, Specifies A integer value.
	void		SetTooltipShadow(int nOffsetX, int nOffsetY, BYTE nDarkenPercent = 50,
		BOOL bGradient = TRUE, int nDepthX = 7, int nDepthY = 7);

	// Drawing shadow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Shadow, Draws current object to the specify device.
	// Parameters:
	//		hDestDC---Dest D C, Specifies a HDC hDestDC object(Value).  
	//		nDestX---Dest X, Specifies A integer value.  
	//		nDestY---Dest Y, Specifies A integer value.  
	//		dwWidth---dwWidth, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwHeight---dwHeight, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		hMask---hMask, Specifies a HBITMAP hMask object(Value).  
	//		bGradient---bGradient, Specifies A Boolean value.  
	//		dwDepthX---Depth X, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwDepthY---Depth Y, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		DrawShadow(HDC hDestDC, int nDestX, int nDestY, DWORD dwWidth, DWORD dwHeight, 
		HBITMAP hMask, BOOL bGradient = FALSE, DWORD dwDepthX = 4, DWORD dwDepthY = 4);

	// Draw text
	// hDC -- handle of the HDC
	// str -- text for drawing
	// rcPos -- position of the drawing label
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text, Do a event. 
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		&str---Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void		DoDrawText(HDC hDC,const CString &str,const CRect &rcPos);

	// Calculate text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOToolTipsWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		nRight---nRight, Specifies A integer value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,int nRight,CStringArray& arLines);

	// Obtain the text size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Text Size, Do a event. 
	//		Returns a CSize type value.  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		&str---Specifies A CString type value.
	CSize		DoGetTextSize(HDC hDC,const CString &str);

	// Smooth mask image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Smooth Mask Image, .
	// Parameters:
	//		ImageWidth---Image Width, Specifies A integer value.  
	//		ImageHeight---Image Height, Specifies A integer value.  
	//		pInitImg---Initial Img, A pointer to the const COLORREF or NULL if the call failed.  
	//		KerWidth---Ker Width, Specifies A integer value.  
	//		KerHeight---Ker Height, Specifies A integer value.  
	//		pResImg_R---Resource Img_ R, A pointer to the double or NULL if the call failed.
	void		SmoothMaskImage(const int ImageWidth, 
				    const int ImageHeight,
                    const COLORREF* const pInitImg,
			        const int KerWidth,
			        const int KerHeight,
					double* const pResImg_R = NULL);

	// Get partial sums
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Partial Sums, Returns the specified value.
	// Parameters:
	//		pM---pM, A pointer to the const double or NULL if the call failed.  
	//		nMRows---M Rows, Specifies A integer value.  
	//		nMCols---M Cols, Specifies A integer value.  
	//		nPartRows---Part Rows, Specifies A integer value.  
	//		nPartCols---Part Cols, Specifies A integer value.  
	//		pBuff---pBuff, A pointer to the double or NULL if the call failed.  
	//		pRes---pRes, A pointer to the double or NULL if the call failed.
	void		GetPartialSums(const double* const pM,
					unsigned int nMRows,
					unsigned int nMCols,
					unsigned int nPartRows,
					unsigned int nPartCols,
					double* const pBuff,
					double* const pRes);
	
	// Darken color
	// clrColor -- color for darking
	// darken -- darken value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Darken Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		clrColor---clrColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		darken---Specifies a double darken object(Value).
	COLORREF	DarkenColor(COLORREF clrColor, double darken);

	// Alpha bit blt
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alpha Bit Bitblt, .
	// Parameters:
	//		hDestDC---Dest D C, Specifies a HDC hDestDC object(Value).  
	//		nDestX---Dest X, Specifies A integer value.  
	//		nDestY---Dest Y, Specifies A integer value.  
	//		dwWidth---dwWidth, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwHeight---dwHeight, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		hSrcDC---Source D C, Specifies a HDC hSrcDC object(Value).  
	//		nSrcX---Source X, Specifies A integer value.  
	//		nSrcY---Source Y, Specifies A integer value.  
	//		percent---Specifies A integer value.
	void		AlphaBitBlt(HDC hDestDC, int nDestX, int nDestY, DWORD dwWidth, DWORD dwHeight, HDC hSrcDC, 
		int nSrcX, int nSrcY, int percent = 100);

	// Pixel alpha
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pixel Alpha, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		clrSrc---clrSrc, Specifies A 32-bit COLORREF value used as a color value.  
	//		src_darken---Specifies a double src_darken object(Value).  
	//		clrDest---clrDest, Specifies A 32-bit COLORREF value used as a color value.  
	//		dest_darken---Specifies a double dest_darken object(Value).
	COLORREF	PixelAlpha (COLORREF clrSrc, double src_darken, COLORREF clrDest, double dest_darken);
	
	// Fill effect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Effect, .
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		dwEffect---dwEffect, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrBegin---clrBegin, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrEnd---clrEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		granularity---Specifies An 8-bit BYTE integer that is not signed.  
	//		coloring---Specifies An 8-bit BYTE integer that is not signed.
	void		FillEffect(HDC hDC, DWORD dwEffect, LPCRECT lpRect, COLORREF clrBegin, 
		COLORREF clrEnd = 0,  BYTE granularity = 0, BYTE coloring = 0);

	// Fill gradient
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient, .
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		colorStart---colorStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		colorFinish---colorFinish, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	void		FillGradient(HDC hDC, CRect rect, COLORREF colorStart, COLORREF colorFinish, BOOL bHorz = TRUE);

	// Multiple copy
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multiple Copy, .
	// Parameters:
	//		hDestDC---Dest D C, Specifies a HDC hDestDC object(Value).  
	//		nDestX---Dest X, Specifies A integer value.  
	//		nDestY---Dest Y, Specifies A integer value.  
	//		dwDestWidth---Dest Width, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwDestHeight---Dest Height, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		hSrcDC---Source D C, Specifies a HDC hSrcDC object(Value).  
	//		nSrcX---Source X, Specifies A integer value.  
	//		nSrcY---Source Y, Specifies A integer value.  
	//		dwSrcWidth---Source Width, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwSrcHeight---Source Height, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		MultipleCopy(HDC hDestDC, int nDestX, int nDestY, DWORD dwDestWidth, DWORD dwDestHeight,
		HDC hSrcDC, int nSrcX, int nSrcY, DWORD dwSrcWidth, DWORD dwSrcHeight);

protected:

	// Draw border
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Border, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		hRgn---hRgn, Specifies a HRGN hRgn object(Value).
	virtual void OnDrawBorder(HDC hDC, HRGN hRgn);

	// Generated message map functions
public:

	// Stop all timers
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stop All, Call this function to stop

	void		StopAll();

	// Kill timers
	
	//-----------------------------------------------------------------------
	// Summary:
	// Kill Timers, .
	// Parameters:
	//		dwIdTimer---Id Timer, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void		KillTimers(DWORD dwIdTimer = NULL);

	// Change new tooltip
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Tooltip, Sets a specify value to current class CFOToolTipsWnd
	// Parameters:
	//		hWnd---hWnd, Specifies a HWND hWnd object(Value).  
	//		&aInfo---&aInfo, Specifies a const FOP_TIP_INFO &aInfo object(Value).  
	//		bDisplayWithDelay---Display With Delay, Specifies A Boolean value.  
	//		type---Specifies A integer value.
	void		SetNewTooltip(HWND hWnd, const FOP_TIP_INFO &aInfo, BOOL bDisplayWithDelay = TRUE, 
		int type = 0);

	// Obtain the handle of the wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window From Point, Returns the specified value.
	//		Returns A HWND value (Object).  
	// Parameters:
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.  
	//		bUseDisabled---Use Disabled, Specifies A Boolean value.
	HWND		GetWndFromPoint(LPPOINT lpPoint, BOOL bUseDisabled = TRUE);

	// Send notify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Notify, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		pt---Specifies A LPPOINT Points array.  
	//		&aInfo---&aInfo, Specifies a FOP_TIP_INFO &aInfo object(Value).
	LRESULT		SendNotify(LPPOINT pt, FOP_TIP_INFO &aInfo);

	// Is cursor over tooltip
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Cursor Over Tooltip, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsCursorOverTooltip() const;

	// Is visible or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Visible, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL IsVisible() const { return ((GetStyle() & WS_VISIBLE) == WS_VISIBLE); }

	// Is notify or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Notify, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsNotify();

	// Previous display
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Display, .
	// Parameters:
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.
	void		PreDisplay(LPPOINT lpPoint);

	// Redraw tooltip
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		nTransparency---nTransparency, Specifies An 8-bit BYTE integer that is not signed.
	void		DoDraw(HDC hDC, BYTE nTransparency = 0);

	// Moving tooltip window on the screen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Moving Tip Window, .
	// Parameters:
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.  
	//		hDC---D C, Specifies a HDC hDC = NULL object(Value).
	void		MovingTipWindow(LPPOINT lpPoint, HDC hDC = NULL);

	// Automatic timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Pop Timer, Sets a specify value to current class CFOToolTipsWnd

	void		SetAutoPopTimer();

	// Free resources
	
	//-----------------------------------------------------------------------
	// Summary:
	// Free Resources, .

	void		FreeResources();

	// Obtain the tooltip direction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tooltip Direction, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwDirection---dwDirection, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.  
	//		lpAnchor---lpAnchor, Specifies A LPPOINT Points array.  
	//		rcBody---rcBody, Specifies A CRect type value.  
	//		rcFull---rcFull, Specifies A CRect type value.  
	//		rcTipArea---Tip Area, Specifies A CRect type value.
	DWORD		GetTooltipDirection(DWORD dwDirection, const LPPOINT lpPoint, LPPOINT lpAnchor, 
		CRect & rcBody, CRect & rcFull, CRect & rcTipArea, const BOOL &bNextScreen = FALSE);

	// Obtain the tooltip region
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tooltip Rgn, Returns the specified value.
	//		Returns A HRGN value (Object).  
	// Parameters:
	//		dwDirection---dwDirection, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	HRGN		GetTooltipRgn(DWORD dwDirection, int x, int y, int nWidth, int nHeight, const BOOL &bNextScreen = FALSE);

	// Gen tooltip showing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Tool Tip Showing, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hWnd---hWnd, Specifies a HWND hWnd object(Value).  
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.  
	//		&aInfo---&aInfo, Specifies a FOP_TIP_INFO &aInfo object(Value).
	BOOL		GenToolTipShowing(HWND hWnd, const LPPOINT lpPoint, FOP_TIP_INFO &aInfo);

	// Gen tooltip showing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Tool Tip Showing, .
	//		Returns A HWND value (Object).  
	// Parameters:
	//		lpPoint---lpPoint, Specifies A LPPOINT Points array.  
	//		&aInfo---&aInfo, Specifies a FOP_TIP_INFO &aInfo object(Value).
	HWND		GenToolTipShowing(const LPPOINT lpPoint, FOP_TIP_INFO &aInfo);

	//{{AFX_MSG(CFOToolTipsWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
#if _MSC_VER < 1300
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
    afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    afx_msg void OnActivateApp(BOOL bActive, DWORD hTask);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// The handle of the parent window
 
	// Parent Window, This member specify HWND object.  
	HWND		m_hParentWnd; 

	// The handle of the notified window
 
	// Notify Window, This member specify HWND object.  
	HWND		m_hNotifyWnd; 

	// Pointer of the parent window
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *		m_pParentWindow;

	// Original point
 
	// Original, This member specify POINT object.  
	POINT		m_ptOriginal;

	// Info about last displayed tool
 
	// Displayed Tool, This member specify HWND object.  
	HWND		m_hwndDisplayedTool;

	// Tooltip type
 
	// Tooltip Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTooltipType;

	// Info about displayed tooltip
 
	// Displayed, This member specify FOP_TIP_INFO object.  
	FOP_TIP_INFO m_tiDisplayed;

	// Info about last displayed tool
 
	// Delay Next Tool, This member sets TRUE if it is right.  
	BOOL		m_bDelayNextTool;

	// Next tip exist
 
	// Next Tool Exist, This member sets TRUE if it is right.  
	BOOL		m_bNextToolExist;

	// Next tool
 
	// Next Tool, This member specify HWND object.  
	HWND		m_hwndNextTool;

	// Next tip type
 
	// Next Tooltip Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nNextTooltipType;

	//Info about next tooltip
 
	// Next Tool, This member specify FOP_TIP_INFO object.  
	FOP_TIP_INFO m_tiNextTool; 

	// Current tip direction
 
	// Current Direction, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwCurDirection;

	// Transparent or not
 
	// Current Transparency, This member sets An 8-bit integer that is not signed.  
	BYTE		m_dwCurTransparency;

	// Tooltip state.
 
	// Tooltip State, This member specify FOPTooltipState object.  
	FOPTooltipState  m_nTooltipState;

	// Begin color of the background
 
	// Begin Background, This member sets A 32-bit value used as a color value.  
	COLORREF	m_clrBeginBk;

	// End color of the background
 
	// End Background, This member sets A 32-bit value used as a color value.  
	COLORREF	m_clrEndBk;

	//Background
	// A bitmap with tooltip's background only
 
	// Bitmap Background, This member specify HBITMAP object.  
	HBITMAP		m_hBitmapBk; 

	// A bitmap with tooltip's background only
 
	// Under Tooltip Background, This member specify HBITMAP object.  
	HBITMAP		m_hUnderTooltipBk;

	//Border of the tooltip
 
	// Border, This member specify HBRUSH object.  
	HBRUSH		m_hbrBorder;

	// Border size
 
	// Border, This member specify SIZE object.  
	SIZE		m_szBorder;

	//Shadow of the tooltip
 
	// Gradient Shadow, This member sets TRUE if it is right.  
	BOOL		m_bGradientShadow;

	// Offset shadow
 
	// Offset Shadow, This member specify SIZE object.  
	SIZE		m_szOffsetShadow;

	// Offset depth shadow
 
	// Depth Shadow, This member specify SIZE object.  
	SIZE		m_szDepthShadow;

	// Darken shadow
 
	// Darken Shadow, This member sets An 8-bit integer that is not signed.  
	BYTE		m_nDarkenShadow;

	// Define font.
	// Active page font.
 
	// Bold Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*      m_pBoldFont;

	// UnActive page font.
 
	// Normal Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*      m_pNormalFont;

	// Tooltip rgn
 
	// Tooltip, This member specify HRGN object.  
	HRGN		m_hrgnTooltip;

	// Default values for the window
 
	// Time Automatic Pop, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwTimeAutoPop; 

	// Initial time
 
	// Time Initial, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwTimeInitial; 

	// Fade In timer
 
	// Time Fade In, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwTimeFadeIn;

	// Fade out timer
 
	// Time Fade Out, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwTimeFadeOut;

	//The tooltip's behaviour
 
	// Behaviour, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwBehaviour;   

	// Effect background
 
	// Effect Background, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwEffectBk;

	// The default tooltip's direction
 
	// Direction, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwDirection;   

	// Style of the window.
 
	// Styles, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwStyles;

	// Granulayitye
 
	// Granularity, This member sets An 8-bit integer that is not signed.  
	BYTE		m_nGranularity;

	//The current value of transparency
 
	// Transparency, This member sets An 8-bit integer that is not signed.  
	BYTE		m_nTransparency; 

	// Shape size
 
	// Sizes[ F O P_ T I P_ S Z_ M A X_ S I Z E S], This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwSizes[FOP_TIP_SZ_MAX_SIZES];

	// The bound rect around the tip's area in the client coordinates.
 
	// Tip Area, This member sets a CRect value.  
	CRect		m_rcTipArea; 

	// The bound rect around the body of the tooltip in the client coordinates.
 
	// Tooltip, This member sets a CRect value.  
	CRect		m_rcTooltip; 

	// The bound rect around a tooltip include an anchor
 
	// Bounds Tooltip, This member sets a CRect value.  
	CRect		m_rcBoundsTooltip; 

	// The bound rect of the window under the tooltip in the screen coordinates
 
	// Under Tooltip, This member sets a CRect value.  
	CRect		m_rcUnderTooltip;  

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOP_TIP_H__3E0080F3_ED3F_11D5_A4C9_525400EA266C__INCLUDED_)
