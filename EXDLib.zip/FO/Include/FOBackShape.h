//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBackShape.h: interface for the CFOBackShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBACKSHAPE_H__5D3EDD1D_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOBACKSHAPE_H__5D3EDD1D_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODrawShape.h"

// Form mode
#define TYPE_FILE_FORM				100

// Window mode
#define TYPE_FILE_WINDOW			101

// Dialog mode
#define TYPE_FILE_DIALOG			102

// Default page margin pen color.
const COLORREF fo_crDefaultPageMargin		= RGB(127,127,127);

// Default page shadow color.
const COLORREF fo_crDefaultPageShadow		= RGB(207,207,207);

// Default page shadow size
const int	   fo_nDefaultPageShadowSize	= 6;

// Default minimize grid space.
const CSize	   fo_DefaultMinGridSpace		= CSize(6,6);

// Default maximize grid space.
const CSize    fo_DefaultMaxGridSpace		= CSize(520,520);

#include "FOActionStack.h"
#include "FOBaseActionMacro.h"

/////////////////////////////////////////////////////////////////////////////
// CFOBackShape
//
// This is the background shape of the canvas,you can call SetBackDrawComp which
// is defined within class CFODataModel to change the back shape.
//
// Override the OnDrawBack method to custom the background of the canvas.
// call SetBkColor which is defined within class CFODataModel to change the color
// of the background.
// See sample TestMap.
//

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOBackShape class derived from CObject
//      F O Back Shape
//===========================================================================

class FO_EXT_CLASS CFOBackShape : public CObject  
{
protected:

    //-----------------------------------------------------------------------
	// Summary:
	//DECLARE ERIAL class
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBackShape---F O Back Shape, Specifies a E-XD++ CFOBackShape object (Value).
	DECLARE_SERIAL(CFOBackShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	// pModel -- pointer of datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Back Shape, Constructs a CFOBackShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	CFOBackShape(CFODataModel *pModel = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Back Shape, Constructs a CFOBackShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBackShape& src object(Value).
	CFOBackShape(const CFOBackShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Back Shape, Destructor of class CFOBackShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBackShape();
		
public:
	
	// get shape list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component List, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeSet ,or NULL if the call failed
	CFODrawShapeSet *GetCompList() { return &m_GroupList; }
	
	// get shape count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCompCount()	{ return m_GroupList.GetCount(); }

	// Reset all the data,
	// Delete all the actions in the stack,it will clear the undo and redo's buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset History, Delete all the actions in the stack,it will clear the undo and redo's buffer.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetHistory();

	// Set maximize depth of undo actions.
	// nHistorySize -- size of history.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Undo Action Count, Sets a specify value to current class CFOBackShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nHistorySize---History Size, Specifies A integer value.
	virtual void SetMaxUndoActionCount(int nHistorySize);

	// Set maximize depth of redo actions.
	// nHistorySize -- size of the maximize redo stack.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Redo Action Count, Sets a specify value to current class CFOBackShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nHistorySize---History Size, Specifies A integer value.
	virtual void SetMaxRedoActionCount(int nHistorySize);

	// Is current back shape on editing state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Editing, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsEditing() const { return m_bEditing; }

	// Change editing state.
	// bEditing -- is editing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Editing, Sets a specify value to current class CFOBackShape
	// Parameters:
	//		&bEditing---&bEditing, Specifies A Boolean value.
	void SetEditing(const BOOL &bEditing) { m_bEditing = bEditing; }

	// Load background file from resource, you can use diagrameditor.exe to design this file.
	// nID -- Resource id.
	// lpszType -- resource type name,must the same as the resource ID's resource type name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From Resource, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadFromResource(UINT nID, LPCTSTR lpszType = _T("BackRes"),BOOL bAdd = FALSE);

	// Load background from file, you can use diagrameditor.exe to design this file.
	// lpszResName -- resource name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadFromFile(LPCTSTR lpszResName,BOOL bAdd = FALSE);

	// Create form resource.
	// lpszResName -- resource name.
	// lpszType -- resource type.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Object By Resource, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL MakeObjectByResource(LPCTSTR lpszResName, LPCTSTR lpszType,BOOL bAdd = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Full Link, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&aShapes---&aShapes, Specifies a const FOPContainer &aShapes object(Value).  
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void			RebuildFullLink(const FOPContainer &aShapes,
		// List of shapes.
		const CFODrawShapeSet& list
		);

	// Save document.
	// lpszPathName -- full path file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	// lpszPathName -- full path file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get first child.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Child Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetFirstChildShape();

	// Get the next object.
    // pos - the POSITION of the object in the list
    // Returns pos = NULL if there are no more objects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pos---Specifies A 32-bit long signed integer.
    CFODrawShape*			GetNextChild(const long& pos) const;

	// add shape to cache
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShape(CFODrawShape *pShape);

	// add shape list to cache
	// m_list -- list of shapes to be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void AddShapes(CFODrawShapeList &m_list);

	// add shape list to cache
	// m_list -- list of shapes to be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeSet &m_list object (Value).
	virtual void AddShapes(CFODrawShapeSet &m_list);

	// add shape at header of list.
	// pShape -- pointer of shape to be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape At Header, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShapeAtHeader(CFODrawShape *pShape);

	// add shapes list at header
	// m_list -- list of shapes to be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes At Header, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeSet &m_list object (Value).
	virtual void AddShapesAtHeader(CFODrawShapeSet &m_list);

	// remove shape from cache
	// pShape -- pointer of the shape to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape *pShape);

	// remove a shape list from cache
	// m_list -- list of shapes to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void RemoveShapes(CFODrawShapeList &m_list);

	// remove all shapes from the cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Find shape with name.
	// strName -- the name of the shape,it is the name that use GetObjectName to obtain.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	CFODrawShape *FindShapeWithName(const CString &strName);

	// Find shape with caption.
	// strCaption -- the caption of the shape,it is the caption that use GetObjectCaption to obtain.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strCaption---&strCaption, Specifies A CString type value.
	CFODrawShape *FindShapeWithCaption(const CString &strCaption);

	// Call this method to obtain the position of all shapes within cache..
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalBoundRect();

	// Change the layer ID of the shape.
	// nLayer -- id of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer, Sets a specify value to current class CFOBackShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nLayer---nLayer, Specifies a FOPLayerID nLayer object(Value).
	virtual void   SetLayer(FOPLayerID nLayer);

	// Change the pointer of the data model
	// pNewModel -- pointer of the model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOBackShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFODataModel or NULL if the call failed.
	virtual void SetModel(CFODataModel* pNewModel);

	// Do something when switch to design or undesign mode.
	virtual void DoModelSwitch(const BOOL &bDesign);


	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Components, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComps();

	// Hit test child shape,return the pointer of the shape.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Child, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFODrawShape *HitTestChild(const CPoint &ptHit);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Recalculate font point size.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);

	// Offset the full canvas.
	// ptOffset -- offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Canvas, .
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	void OffsetCanvas(const CPoint &ptOffset);

public:

	// Draw text specify,this is a instead of CDC's DrawText.
	// pDC -- pointer of CDC.
	// str -- Text string.
	// nFormat -- Text alignment,same as CDC's DrawText.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text New, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		str---Specifies A CString type value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawTextNew(CDC *pDC,const CString& str, LPRECT lpRect, UINT nFormat);
	
	// Draw margin of the page,only works with form editor mode.
	// pDC -- pointer of CDC.
	// rect -- position of page.
	// rcClip -- Clip rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Page Margin, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void OnDrawPageMargin(CDC *pDC,CRect &rect,const CRect &rcClip);

	// Draw the background of the page.
	// pDC -- pointer of CDC.
	// rcClip -- Clip rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Back, Draw the background of this canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void OnDrawBack(CDC *pDC,const CRect &rcClip);

	// Draw additional items
	// pDC -- pointer of DC.
	// rcUpdate -- udpate area position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Additional, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rcUpdate---&rcUpdate, Specifies A CRect type value.
	virtual void DoDrawAddi(CDC* pDC, const CRect &rcUpdate);	

	// Clip rectangle to the bounds of the canvas.
	// rcClip -- clip rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clipboard To Canvas, .
	// Parameters:
	//		rcClip---rcClip, Specifies A CRect type value.  
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void ClipToCanvas(CRect& rcClip, CDC *pDC, const BOOL &bEnable = FALSE);

	// Draw the grid.
	// pDC -- pointer of CDC.
	// rect -- position of page.
	// rcClip -- Clip rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Grid, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void OnDrawGrid(CDC *pDC, CRect &rect, const CRect &rcClip);

	// Returns a pointer to the model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	CFODataModel *GetModel()			{ return m_pModel; }

	// Does the actual drawing of the background.
	// pDC -- pointer of CDC.
	// rcClip -- Clip rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void OnDraw(CDC *pDC,const CRect &rcClip);

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBackShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBackShape& src object(Value).
	CFOBackShape& operator=(const CFOBackShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBackShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOBackShape* Copy() const;

protected:

	// Prepare DC and init all GDI objects.
	// Init the pen,brush.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Frees GDI objects and restores the state of the device context.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Draw the form mode system button.
	// pDC -- pointer of CDC.
	// rect -- position of button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Form Dialog Button, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.
	virtual void DrawFormDialogButton(CDC *pDC,CRect &rect);

	// Draw drag handle mark of the form.
	// pDC -- pointer of CDC.
	// rect -- position of form.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Form Drag Mark, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.
	virtual void DrawFormDragMark(CDC *pDC,CRect &rect);

	// Draw form body.
	// pDC -- pointer of the DC.
	// rcClip -- Clip rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Form, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void OnDrawForm(CDC *pDC,const CRect &rcClip);

	// This is a helper method, find total grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Total Grid, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.
	int FindTotalGrid();
	
	// Obtain the pointer of border pen.
	CPen *GetBorderPen();

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Is printing.
	BOOL	m_bIsPrint;

	// Member var
	// The icon of lock
 
	// Icon Lock, This member specify HICON object.  
	HICON			m_hIconLock;

	// the pointer to model.
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel*	m_pModel;

	// The color of margin
 
	// Margin Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crMarginColor;

	// object of class
 
	// Group List, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet	m_GroupList;

	// Version of shape.
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nVersion;

	// Is background shape is editing or not.
 
	// Editing, This member sets TRUE if it is right.  
	BOOL			m_bEditing;

	// Action stack.
	typedef CFOActionStack<CFOBaseAction*, CFOBaseAction*> ActionStack;

	// Border pen.
	CFOPenObjData myBorderPen;

public:

	// Undo stack.
 
	// Undo Stack, This member specify ActionStack object.  
	ActionStack m_UndoStack;

	// Redo stack.
 
	// Redo Stack, This member specify ActionStack object.  
	ActionStack m_RedoStack;
};

#endif // !defined(AFX_FOBACKSHAPE_H__5D3EDD1D_F259_11DD_A433_525400EA266C__INCLUDED_)
