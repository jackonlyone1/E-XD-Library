//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNARROWBUTTON_H__4512D91C_5410_4066_91BD_0331DFAFE682__INCLUDED_)
#define AFX_FOPDROPDOWNARROWBUTTON_H__4512D91C_5410_4066_91BD_0331DFAFE682__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownArrowButton.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// FOPDropDownArrowButton window
#include "FOPArrowPickerDrawPanel.h"
#include "FOPDropDownButtonBase.h"
#include "FOPPickerBaseWnd.h"

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownArrowButton window
void FO_API_DECL AFXAPI DDX_ArrowDropDown(CDataExchange *pDX, int nIDC, int& nArrow);

 
//===========================================================================
// Summary:
//     The FOPDropDownArrowButton class derived from FOPDropDownButtonBase
//      O P Drop Down Arrow Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownArrowButton : public FOPDropDownButtonBase, FOPDropArrowCallback
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownArrowButton---O P Drop Down Arrow Button, Specifies a FOPDropDownArrowButton object(Value).
	DECLARE_DYNCREATE(FOPDropDownArrowButton);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Arrow Button, Constructs a FOPDropDownArrowButton object.
	//		Returns A  value (Object).
	FOPDropDownArrowButton();

// Attributes
public:
	// Drop down wnd pointer.
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Arrow picker
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPDropArrowPickerDrawPanel.  
	FOPDropArrowPickerDrawPanel* pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPDropArrowPickerDrawPanel.  
	FOPDropArrowPickerDrawPanel* pDrawImpl;

	// Arrow type.
 
	// Arrow Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nArrowType;

	// End arrow style.
 
	// End Style, This member sets TRUE if it is right.  
	BOOL						m_bEndStyle;

// Operations
public:

	// Share draw impl.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownArrowButton& button object(Value).
	void						ShareDrawImpl(FOPDropDownArrowButton& button);

	// Get arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow, Returns the specified value.
	//		Returns a int type value.
	int	 						GetArrow()	const		{	return(m_nArrowType);		}

	// Draw impl.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPDropArrowPickerDrawPanel& value (Object).
	const	FOPDropArrowPickerDrawPanel&	GetDrawImpl() const	{	return *pDrawImpl;	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPDropArrowPickerDrawPanel& value (Object).
	FOPDropArrowPickerDrawPanel&	GetDrawImpl()		{	return *pDrawImpl;	}

	// Get minimum height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int					GetMinimumHeight() const;

	// Set arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow, Sets a specify value to current class FOPDropDownArrowButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void						SetArrow(int nWidth);

	// Do drop down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		bDraw---bDraw, Specifies A Boolean value.
	// Draw button.
	void						Draw(CDC& dc, const CRect& rc, BOOL bDraw);

	// callbacks
	// Do when arrow changing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Arrow Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellArrowChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choosing custom arrow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Arrow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomArrow();

	// Do when choosing none arrow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Arrow None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellArrowNone();

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPDropDownArrowButton
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void						SetTransparency(BOOL  bTransparent);

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 						IsTransparent()	const	{	return m_bTransparent;		}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownArrowButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Arrow Button, Destructor of class FOPDropDownArrowButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownArrowButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownArrowButton)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Is transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 						m_bTransparent;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNARROWBUTTON_H__4512D91C_5410_4066_91BD_0331DFAFE682__INCLUDED_)
