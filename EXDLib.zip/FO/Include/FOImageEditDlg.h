//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEEDITDLG_H__AA19F1D1_B867_11D5_A476_525400EA266C__INCLUDED_)
#define AFX_FOIMAGEEDITDLG_H__AA19F1D1_B867_11D5_A476_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageEditDlg window

#include "FODropColorPaletteWnd.h"
#include "FOPaintWnd.h"
#include "FOImageButton.h"

/////////////////////////////////////////////////////////////////////////////
// CFOImageEditDlg dialog

 
//===========================================================================
// Summary:
//     The CFOImageEditDlg class derived from CDialog
//      F O Image Edit Dialog
//===========================================================================

class FO_EXT_CLASS CFOImageEditDlg : public CDialog
{
 
	// F O Paint Window, This member specify friend object.  
	friend CFOPaintWnd;
	// Construction
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Edit Dialog, Constructs a CFOImageEditDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOImageEditDlg(CWnd* pParent = NULL);   
	
	// set bitmap to draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Bitmap, Sets a specify value to current class CFOImageEditDlg
	// Parameters:
	//		pBitmap---pBitmap, A pointer to the CBitmap or NULL if the call failed.
	void SetDrawBitmap(CBitmap* pBitmap);

	// set or get current tool
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Tool, Sets a specify value to current class CFOImageEditDlg
	// Parameters:
	//		nTool---nTool, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetCurrentTool(const UINT nTool);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Tool, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetCurrentTool() const;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	//when color change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	BOOL		OnColorChange (COLORREF color);
public:
	// Dialog Data
	//{{AFX_DATA(CFOImageEditDlg)
	enum { IDD = IDD_FO_IMAGE_EDITOR };
	//}}AFX_DATA

	// window style
 
	// Image, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CFOPaintWnd					m_wndImage;	// Image paint wnd.
 
	// Color, This member specify E-XD++ CFODropColorPaletteWnd object.  
	CFODropColorPaletteWnd		m_wndColor;	// Color select wnd.
 
	// Tool Bar, This member specify CToolBar object.  
	CToolBar					m_wndToolBar;// Color bar.
	// Operations:
protected:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOImageEditDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	// Pre translate message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOImageEditDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Colors, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnColors();

	// clear ,copy ,paste
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Clear, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolClear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Copy, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolCopy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Paste, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolPaste();

	// ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Ellipse, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolEllipse();

	// fill
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Fill, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolFill();

	// line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();

	// pen
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Pen, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolPen();

	// pick
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Pick, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolPick();

	// rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolRect();
	
	// update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Ellipse, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolEllipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Fill, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolFill(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Pen, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolPen(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Pick, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolPick(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Rectangle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Paste, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolPaste(CCmdUI* pCmdUI);
	
	// empty ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Emptyellipse, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolEmptyellipse();

	// empty rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Emptyfillrect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolEmptyfillrect();

	// empty round rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Emptyroundrect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolEmptyroundrect();
	
	// update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Emptyellipse, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolEmptyellipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Emptyfillrect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolEmptyfillrect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Emptyroundrect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolEmptyroundrect(CCmdUI* pCmdUI);
	
	// fill ellipse ,rect ,round rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Fillellipse, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolFillellipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Fillrect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolFillrect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Fillroundrect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolFillroundrect();	
	// update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Fillellipse, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolFillellipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Fillrect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolFillrect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Fillroundrect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolFillroundrect(CCmdUI* pCmdUI);
	
	// round rect and update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tool Roundrect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolRoundrect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tool Roundrect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolRoundrect(CCmdUI* pCmdUI);
	//}}AFX_MSG

	// when select day -> OK
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Day O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT	OnSelectDayOK(WPARAM wParam, LPARAM lParam);

	// when slect custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Custom, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT	OnSelectCustom(WPARAM wParam, LPARAM lParam);

	// when idle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Idle, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnIdle(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	// Attributes:
 
	// New, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush						brushNew;		// new brush 
 
	// Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*					m_pBitmap;		// pointer to bitmap		
 
	// Image, This member sets a CSize value.  
	CSize						m_szImage;		// size of image
 
	// Paint, This member sets a CRect value.  
	CRect						m_rcPaint;		// paint rect
 
	// Draw, This member sets a CRect value.  
	CRect						m_rcDraw;		// draw rect
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEEDITDLG_H__AA19F1D1_B867_11D5_A476_525400EA266C__INCLUDED_)
