//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOGRIDSHAPE_H__E944E4E1_1CC6_485B_ABDD_D321CE341879__INCLUDED_)
#define AFC_FOGRIDSHAPE_H__E944E4E1_1CC6_485B_ABDD_D321CE341879__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODrawPortsShape.h"
#include "FOGridCellObject.h"
#include "FOInsideBaseShape.h"

/////////////////////////////////////////////////////////////
// CFOGridShape -- grid shape control
//------------------------------------------------------
// Description: ID: FO_COMP_GRID 42
// Author: ucancode.net Software.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOGridShape class derived from CFODrawPortsShape
//      F O Grid Shape
//===========================================================================

class FO_EXT_CLASS CFOGridShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOGridShape---F O Grid Shape, Specifies a E-XD++ CFOGridShape object (Value).
	DECLARE_SERIAL(CFOGridShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Grid Shape, Constructs a CFOGridShape object.
	//		Returns A  value (Object).
	CFOGridShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Grid Shape, Constructs a CFOGridShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGridShape& src object(Value).
	CFOGridShape(const CFOGridShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Grid Shape, Destructor of class CFOGridShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOGridShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOGridShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the grid shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOGridShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nrows---Specifies A integer value.  
	//		ncols---Specifies A integer value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the grid shape and initializes the data members.
	// rcPos -- position of shape.
	// nrows -- rows of the grid.
	// ncols -- columns of the grid.
	// strCaption -- caption of the grid.
	virtual void Create(const CRect &rcPos,int nrows, int ncols,CString strCaption = _T(""));

	// Re create grid.
	virtual void ReCreateGrid(const int &nRows, const int &nCols);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOGridShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGridShape& src object(Value).
	CFOGridShape& operator=(const CFOGridShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Re calculate font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);

	// Change the pointer of the data model
	// pNewModel -- pointer of model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOGridShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFODataModel or NULL if the call failed.
	virtual void SetModel(CFODataModel* pNewModel);

	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
public:

	// Hit test text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Label, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOEditBoxShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFOEditBoxShape *HitTestLabel(const CPoint &ptHit);

	// Hit test horizontal split line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Horizontal Split Line, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual int HitHorzSplitLine(int x, int y);

	// Remove all cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Cells, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllCells();

	// Init grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Grid, Call InitGrid after creating a new object.
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void InitGrid(const CRect &rcPos);

	// Get cell position by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		idx---Specifies A integer value.  
	//		row---Specifies A integer value.  
	//		col---Specifies A integer value.
	virtual void     GetCellPosition(int idx, int& row, int& col);

	// Get cell index by row and col.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Index, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		row---Specifies A integer value.  
	//		col---Specifies A integer value.
	virtual int      GetCellIndex(int row, int col);

	// Update cell height and width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Width And Height, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	 UpdateWidthAndHeight();

	// Get cell by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOGridCellObject,or NULL if the call failed  
	// Parameters:
	//		cellIdx---cellIdx, Specifies A integer value.
	virtual CFOGridCellObject*   GetCell(int cellIdx);

	// Get cell index by row and col.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOGridCellObject,or NULL if the call failed  
	// Parameters:
	//		row---Specifies A integer value.  
	//		col---Specifies A integer value.
	virtual CFOGridCellObject*   GetCell(int row, int col);

	// Obtain the cell at a specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell, Returns the specified value.
	//		Returns a pointer to the object const CFOGridCellObject,or NULL if the call failed  
	// Parameters:
	//		cellIdx---cellIdx, Specifies A integer value.
	const CFOGridCellObject* GetCell(int cellIdx) const
	{
		if(cellIdx < 0 || cellIdx >= m_ncells)
			return 0; //null cell
		else
			return (CFOGridCellObject *)(m_pCells[cellIdx]);
	}
	
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Draw zero zero cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw_ Zero Zero, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void     Draw_ZeroZero(CDC *pDC);

	// Draw zero rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw_ Zero Row, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void     Draw_ZeroRow(CDC *pDC);

	// Draw zero cols.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw_ Zero Column, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void     Draw_ZeroCol(CDC *pDC);

	// Draw grid contents.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw_ Contents, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void     Draw_Contents(CDC *pDC);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& aPoly) const;

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);


	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Draw grid grid lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw_ Grid, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void     Draw_Grid(CDC *pDC);

	// Change fix row background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fix Row Color, Sets a specify value to current class CFOGridShape
	// Parameters:
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.
	void SetFixRowColor(const COLORREF &crBack);

	// Change fix column background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fix Column Color, Sets a specify value to current class CFOGridShape
	// Parameters:
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.
	void SetFixColColor(const COLORREF &crBack);
	
	// Show grid line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Grid Line, Call this function to show the specify object.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void ShowGridLine(const BOOL & bShow) { m_bGridline = bShow; }

	// Draw fix cols header.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Fix Column Header, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowFixColHeader(const BOOL &bShow) { m_bDrawFixCol = bShow; }

	// Draw fix rows header.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Fix Row Header, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowFixRowHeader(const BOOL &bShow) { m_bDrawFixRow = bShow;}

	// Get row count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetRowCount() { return m_nrows; }

	// Get col count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetColCount() { return m_ncols;}

	// Get cell counts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetCellCount() { return m_ncells; }

	// Obtain current cell index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Hit Index, Returns the specified value.
	//		Returns a int type value.
	int GetCurrentHitIndex() const { return m_nCurHitCell; }

	// Next current cell index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Hit Index, Returns the specified value.
	//		Returns a int type value.
	int GetNextHitIndex();

	// Reset current hit index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Current Hit Index, Called this function to empty a previously initialized CFOGridShape object.

	void ResetCurrentHitIndex() { m_nCurHitCell = -1; }

	// Allow label select.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Label Select, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowLabelSelect() const { return m_bAllowLabelSelect; }

	// Set label allow select mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Label Select, .
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void AllowLabelSelect(const BOOL &bEnable) { m_bAllowLabelSelect = bEnable; }

	// Change cell property.

	// Put group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Group Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual void PutGroupPropValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Group Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetGroupPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Get cell property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Property, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCellIndex---Cell Index, Specifies A integer value.  
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetCellProperty(
		// Specifies a cell index.
		int nCellIndex,
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Change cell property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Cell Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCellIndex---Cell Index, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL ChangeCellProperty(
		// Specifies a cell index.
		int nCellIndex,
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Change row property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Row Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRowIndex---Row Index, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL ChangeRowProperty(
		// Specifies a cell index.
		int nRowIndex,
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);
	
	// Change row property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Column Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nColIndex---Column Index, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL ChangeColProperty(
		// Specifies a cell index.
		int nColIndex,
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// build Index for properties
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Index For Property, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildIndexForProp();

	// Update property cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cache Properties, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CacheProperties();

public:
	// Update value with variable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Variable, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateVar();

	// draws bounding rect in XOR mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Set wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOGridShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCanvas---*pCanvas, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pCanvas);

public:

	// Reset update flags.
	virtual void UpdateHardWay();


	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dfX---dfX, Specifies a double dfX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dfX, double dY, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Position shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxRect();

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Get max position of track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror with point ref1 and ref2.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// skewing shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewXShape(int nAngle, double dOX, double dOY);

	// skewing shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewYShape(int nAngle, double dOX, double dOY);

	// skewing track shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackXShape(int nAngle, double dOX, double dOY);

	// skewing track shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackYShape(int nAngle, double dOX, double dOY);

	// Hit test label pos.
	// ptHit -- hit test point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Label Text Position, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual BOOL HitLabelTextPos(const CPoint& ptHit);

	// Obtain cell border type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetBorderType() const { return m_nBorderType; }

	// Change cell border type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Type, Sets a specify value to current class CFOGridShape
	// Parameters:
	//		&nBorder---&nBorder, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBorderType(const UINT &nBorder) { m_nBorderType = nBorder; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Dot track
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Dot Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DrawDotBorder(CDC* pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	
	// Total cols
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_ncols;

	// Total rows
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nrows;

	// Total cells.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_ncells;

	// Cells objects.
 
	// Cells, This member maintains a pointer to the object CFOGridCellObject*.  
	CFOGridCellObject**  m_pCells;

	// Heights
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int*            m_height;

	// Widths
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int*            m_width;

	// Show grid line or not
 
	// Gridline, This member sets TRUE if it is right.  
	BOOL            m_bGridline;

	// Draw fix row header.
 
	// Draw Fix Row, This member sets TRUE if it is right.  
	BOOL			m_bDrawFixRow;

	// Draw fix col header
 
	// Draw Fix Column, This member sets TRUE if it is right.  
	BOOL			m_bDrawFixCol;

	// Allow label select.
 
	// Allow Label Select, This member sets TRUE if it is right.  
	BOOL			m_bAllowLabelSelect;

	// Current cell index, it is designed for tab order.
 
	// Current Hit Cell, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurHitCell;

	// Cell border type.
 
	// Border Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBorderType;
};


#endif // !defined(AFC_FOGRIDSHAPE_H__E944E4E1_1CC6_485B_ABDD_D321CE341879__INCLUDED_)
