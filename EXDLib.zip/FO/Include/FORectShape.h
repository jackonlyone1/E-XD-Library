//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FORECTSHAPE_H__58CE67D0_C817_11D5_A48A_525400EA266C__INCLUDED_)
#define AFC_FORECTSHAPE_H__58CE67D0_C817_11D5_A48A_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////
// Shape.
//------------------------------------------------------

#include "FODrawPortsShape.h"

/////////////////////////////////////////////////////////////////////////////////////
// CFORectShape -- rectangle shape, ID: FO_COMP_RECTANGLE 30

 
//===========================================================================
// Summary:
//     The CFORectShape class derived from CFODrawPortsShape
//      F O Rectangle Shape
//===========================================================================

class FO_EXT_CLASS CFORectShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORectShape---F O Rectangle Shape, Specifies a E-XD++ CFORectShape object (Value).
	DECLARE_SERIAL(CFORectShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rectangle Shape, Constructs a CFORectShape object.
	//		Returns A  value (Object).
	CFORectShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rectangle Shape, Constructs a CFORectShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFORectShape& src object(Value).
	CFORectShape(const CFORectShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Rectangle Shape, Destructor of class CFORectShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFORectShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFORectShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the rectangle shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeCircularShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetSimpleValue(const double &dValue);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFORectShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFORectShape& src object(Value).
	CFORectShape& operator=(const CFORectShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
#if 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Font, Returns the specified value.
	//		Returns a pointer to the object Font,or NULL if the call failed
	Font* GetNewFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// V Draw Text, .
	// Parameters:
	//		&g---Specifies a Graphics &g object(Value).  
	//		&text---Specifies A CString type value.  
	//		*pFont---*pFont, A pointer to the const Font  or NULL if the call failed.  
	//		&rc---Specifies a const RectF &rc object(Value).  
	//		*pStrFor---String For, A pointer to the const StringFormat  or NULL if the call failed.  
	//		*pBrush---*pBrush, A pointer to the const Brush  or NULL if the call failed.
	void SVDrawText(Graphics &g, const CString &text, const Font *pFont, const RectF &rc, const StringFormat *pStrFor, const Brush *pBrush);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Error String, Draws current object to the specify device.
	// Parameters:
	//		&gr---Specifies a Graphics &gr object(Value).  
	//		bounds---Specifies a RectF bounds object(Value).  
	//		errorString---errorString, Specifies A CString type value.
	void DrawErrorString(Graphics &gr, RectF bounds, CString errorString);
#endif

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();
	
protected:

	// Is hot spot shape.
 
	// Hot Spot, This member sets TRUE if it is right.  
	BOOL				m_bHotSpot;
};

////////////////////////////////////////////////////////////////////////////
// CFOAutoFontTextShape --  this is a text shape, it's font size will
//						be automatic created with it's bounding rectangle.
// 
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOAutoFontTextShape class derived from CFORectShape
//      F O Automatic Font Text Shape
//===========================================================================

class FO_EXT_CLASS CFOAutoFontTextShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAutoFontTextShape---F O Automatic Font Text Shape, Specifies a E-XD++ CFOAutoFontTextShape object (Value).
	DECLARE_SERIAL(CFOAutoFontTextShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Automatic Font Text Shape, Constructs a CFOAutoFontTextShape object.
	//		Returns A  value (Object).
	CFOAutoFontTextShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Automatic Font Text Shape, Constructs a CFOAutoFontTextShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOAutoFontTextShape& src object(Value).
	CFOAutoFontTextShape(const CFOAutoFontTextShape& src);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Is or no auto font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is auto font Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsAutoFont() const;
	
	// Set auto font mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set auto font Mode, Sets a specify value to current class CFOAutoFontTextShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAuto---auto font Mode, Specifies A Boolean value.
	virtual void SetAutoFont(BOOL bAuto);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Automatic Font Text Shape, Destructor of class CFOAutoFontTextShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAutoFontTextShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOAutoFontTextShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Create auto size of font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Automatic Size Font, You construct a CFOAutoFontTextShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HFONT value (Object).  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		*rect---A pointer to the RECT  or NULL if the call failed.  
	//		string---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	HFONT CreateAutoSizeFont(HDC hdc, RECT *rect,LPCTSTR string);

	// Rectangle size from font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Size From Font, .
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		*pLf---*pLf, A pointer to the LOGFONT  or NULL if the call failed.
	CSize RectSizeFromFont( CDC *pDC, CString strLabel, LOGFONT *pLf );

	// Font size from rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Font Size From Rectangle, .
	//		Returns A LOGFONT value (Object).  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		*pLf---*pLf, A pointer to the LOGFONT  or NULL if the call failed.  
	//		*pR---*pR, A pointer to the CRect  or NULL if the call failed.
	LOGFONT FontSizeFromRect(CDC *pDC, CString strLabel, LOGFONT *pLf, CRect *pR );

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOAutoFontTextShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOAutoFontTextShape& src object(Value).
	CFOAutoFontTextShape& operator=(const CFOAutoFontTextShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Save size of shape.
 
	// Save, This member sets a CSize value.  
	CSize m_szSave;

	// Save old title
 
	// Old Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOldTitle;

	// Date font.
 
	// Date Font, This member specify LOGFONT object.  
	LOGFONT m_lfDateFont;

	// Current font size.
 
	// Current Font Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nCurFontSize;
};

////////////////////////////////////////////////////////////////////////////
// CFOPScaleRefShape --  This shape is used for scaling reference
//					FO_SCALE_REF_SHAPE 294
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPScaleRefShape class derived from CFORectShape
//      F O P Scale Reference Shape
//===========================================================================

class FO_EXT_CLASS CFOPScaleRefShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPScaleRefShape---F O P Scale Reference Shape, Specifies a E-XD++ CFOPScaleRefShape object (Value).
	DECLARE_SERIAL(CFOPScaleRefShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Scale Reference Shape, Constructs a CFOPScaleRefShape object.
	//		Returns A  value (Object).
	CFOPScaleRefShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Scale Reference Shape, Constructs a CFOPScaleRefShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPScaleRefShape& src object(Value).
	CFOPScaleRefShape(const CFOPScaleRefShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Scale Reference Shape, Destructor of class CFOPScaleRefShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPScaleRefShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPScaleRefShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPScaleRefShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPScaleRefShape& src object(Value).
	CFOPScaleRefShape& operator=(const CFOPScaleRefShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPScaleRefShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	// Return link path shape's key 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Path Shape, Returns the specified value.
	//		Returns a CString type value.
	CString GetLinkPathShape();
	
	// Change link path shape's key 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link Path Shape, Sets a specify value to current class CFOPScaleRefShape
	// Parameters:
	//		&strKey1---&strKey1, Specifies A CString type value.
	void SetLinkPathShape( const CString &strKey1 );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Move Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMoveShape() { return m_pCurMoveComponent; }

public:
	
 
	// Current Move Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape * m_pCurMoveComponent;
};


///////////////////////////////////////////////////////////////
// CFOGisLabelShape -- simple gis label shape. ID: FO_GIS_LABEL 333

 
//===========================================================================
// Summary:
//     The CFOGisLabelShape class derived from CFORectShape
//      F O Gis Label Shape
//===========================================================================

class FO_EXT_CLASS CFOGisLabelShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOGisLabelShape---F O Gis Label Shape, Specifies a E-XD++ CFOGisLabelShape object (Value).
	DECLARE_SERIAL(CFOGisLabelShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Gis Label Shape, Constructs a CFOGisLabelShape object.
	//		Returns A  value (Object).
	CFOGisLabelShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Gis Label Shape, Constructs a CFOGisLabelShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGisLabelShape& src object(Value).
	CFOGisLabelShape(const CFOGisLabelShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Gis Label Shape, Destructor of class CFOGisLabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOGisLabelShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOGisLabelShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOGisLabelShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGisLabelShape& src object(Value).
	CFOGisLabelShape& operator=(const CFOGisLabelShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};


///////////////////////////////////////////////////////////////
// CFOPTwoImageBoxShape -- image box that supports two images.

 
//===========================================================================
// Summary:
//     The CFOPTwoImageBoxShape class derived from CFORectShape
//      F O P Two Image Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPTwoImageBoxShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPTwoImageBoxShape---F O P Two Image Box Shape, Specifies a E-XD++ CFOPTwoImageBoxShape object (Value).
	DECLARE_SERIAL(CFOPTwoImageBoxShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Two Image Box Shape, Constructs a CFOPTwoImageBoxShape object.
	//		Returns A  value (Object).
	CFOPTwoImageBoxShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Two Image Box Shape, Constructs a CFOPTwoImageBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPTwoImageBoxShape& src object(Value).
	CFOPTwoImageBoxShape(const CFOPTwoImageBoxShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Two Image Box Shape, Destructor of class CFOPTwoImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPTwoImageBoxShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTwoImageBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button component from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	// Show full size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Full Size, Do a event. 

	void DoShowFullSize();
    
	// Export to image.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPTwoImageBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPTwoImageBoxShape& src object(Value).
	CFOPTwoImageBoxShape& operator=(const CFOPTwoImageBoxShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this component.
	virtual CFODrawShape* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPTwoImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:
	
	// Do sub menu change.
	// nMenuItem -- menu item.
	// strState -- state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadImage(CString strImagePath);

	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Image, Call this function to remove a specify value from the specify object.

	void RemoveOldImage();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Click Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadClickImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Click Image, Call this function to remove a specify value from the specify object.

	void RemoveOldClickImage();

	// Init image position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bResize---&bResize, Specifies A Boolean value.
	virtual BOOL DoStartShowEdit(const BOOL &bResize = FALSE);
    
public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Select status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Draws the 3D status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareMask();

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Click Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareClickMask();

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOPTwoImageBoxShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Get transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetImageTransparentColor() const { return m_crTransparent; }

	// Set transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent Color, Sets a specify value to current class CFOPTwoImageBoxShape
	// Parameters:
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	void SetImageTransparentColor(const COLORREF crTrans);


	// Change to second image state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set State, Sets a specify value to current class CFOPTwoImageBoxShape
	// Parameters:
	//		&nState---&nState, Specifies A integer value.
	void SetState(const int &nState);

	
public:
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();
	
	// Current timer ID
	
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current frame
	
	// Frame, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nFrame;
	
public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 
	
	void DoStartTimer();
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
public:
	// Current timer speed, default is 400
	
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;
	
	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

 
	// Normal File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalFile;
 
	// Click File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strClickFile;
 
	// Over File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOverFile;

	// Change the hit test color of polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Colors, Sets a specify value to current class CFOPTwoImageBoxShape
	// Parameters:
	//		highlightClr---highlightClr, Specifies A 32-bit COLORREF value used as a color value.  
	//		downclr---Specifies A 32-bit COLORREF value used as a color value.
	void SetColors(COLORREF highlightClr, COLORREF  downclr)
	{
		m_clrHighlight = highlightClr;   // default ::GetSysColor(COLOR_3DHIGHLIGHT)
		m_clrShadow = downclr;           // default ::GetSysColor(COLOR_3DSHADOW);
	}
	
protected:
	
	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL	m_bMouseDown;
	
	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL	m_bCanPress;
	
	// Colors for hit.
	COLORREF m_clrHighlight, m_clrShadow;
protected:
	
	// Image pointer.
 
	// Click Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImage;		
	
	// Is transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL m_bTransparent;
	
	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTransparent;
	
	// And mask image object.
 
	// Click Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageAndMask;
	
	// Or mask image object.
 
	// Click Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageOrMask;
protected:

	// Image pointer.
 
	// Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImage;		

	// And mask image object.
 
	// Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageAndMask;

	// Or mask image object.
 
	// Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageOrMask;
};

///////////////////////////////////////////////////////////////
// CFOPThreeImageBoxShape -- image box that supports three images.

 
//===========================================================================
// Summary:
//     The CFOPThreeImageBoxShape class derived from CFORectShape
//      F O P Three Image Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPThreeImageBoxShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPThreeImageBoxShape---F O P Three Image Box Shape, Specifies a E-XD++ CFOPThreeImageBoxShape object (Value).
	DECLARE_SERIAL(CFOPThreeImageBoxShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Three Image Box Shape, Constructs a CFOPThreeImageBoxShape object.
	//		Returns A  value (Object).
	CFOPThreeImageBoxShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Three Image Box Shape, Constructs a CFOPThreeImageBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPThreeImageBoxShape& src object(Value).
	CFOPThreeImageBoxShape(const CFOPThreeImageBoxShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Three Image Box Shape, Destructor of class CFOPThreeImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPThreeImageBoxShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPThreeImageBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button component from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	// Show full size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Full Size, Do a event. 

	void DoShowFullSize();
    
	// Do sub menu change.
	// nMenuItem -- menu item.
	// strState -- state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Export to image.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPThreeImageBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPThreeImageBoxShape& src object(Value).
	CFOPThreeImageBoxShape& operator=(const CFOPThreeImageBoxShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this component.
	virtual CFODrawShape* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadImage(CString strImagePath);

	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Image, Call this function to remove a specify value from the specify object.

	void RemoveOldImage();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Click Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadClickImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Click Image, Call this function to remove a specify value from the specify object.

	void RemoveOldClickImage();

	
	// Init image position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPThreeImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bResize---&bResize, Specifies A Boolean value.
	virtual BOOL DoStartShowEdit(const BOOL &bResize = FALSE);
    
public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Select status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Draws the 3D status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareMask();

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Click Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareClickMask();

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOPThreeImageBoxShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Get transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetImageTransparentColor() const { return m_crTransparent; }

	// Set transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent Color, Sets a specify value to current class CFOPThreeImageBoxShape
	// Parameters:
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	void SetImageTransparentColor(const COLORREF crTrans);


	// Change to second image state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set State, Sets a specify value to current class CFOPThreeImageBoxShape
	// Parameters:
	//		&nSecond---&nSecond, Specifies A integer value.
	void SetState(const int &nSecond);

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Third Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadThirdImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Third Image, Call this function to remove a specify value from the specify object.

	void RemoveOldThirdImage();
	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Third Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareThirdMask();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

 
	// Normal File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalFile;
 
	// Click File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strClickFile;
 
	// Over File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOverFile;
 
	// Four File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strFourFile;

	// Change the hit test color of polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Colors, Sets a specify value to current class CFOPThreeImageBoxShape
	// Parameters:
	//		highlightClr---highlightClr, Specifies A 32-bit COLORREF value used as a color value.  
	//		downclr---Specifies A 32-bit COLORREF value used as a color value.
	void SetColors(COLORREF highlightClr, COLORREF  downclr)
	{
		m_clrHighlight = highlightClr;   // default ::GetSysColor(COLOR_3DHIGHLIGHT)
		m_clrShadow = downclr;           // default ::GetSysColor(COLOR_3DSHADOW);
	}
	
public:
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();
	
	// Current timer ID
	
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current frame
	
	// Frame, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nFrame;
	
public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 
	
	void DoStartTimer();
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
public:
	// Current timer speed, default is 400
	
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;
	
	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

protected:
	
	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL	m_bMouseDown;
	
	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL	m_bCanPress;
	
	// Colors for hit.
	COLORREF m_clrHighlight, m_clrShadow;

	
	// Image pointer.
 
	// Third Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImage;	
	
	// And mask image object.
 
	// Third Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImageAndMask;
	
	// Or mask image object.
 
	// Third Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImageOrMask;
	
protected:
	
	// Image pointer.
 
	// Click Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImage;		
	
	// Is transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL m_bTransparent;
	
	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTransparent;
	
	// And mask image object.
 
	// Click Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageAndMask;
	
	// Or mask image object.
 
	// Click Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageOrMask;

protected:

	// Image pointer.
 
	// Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImage;		

	// And mask image object.
 
	// Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageAndMask;

	// Or mask image object.
 
	// Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageOrMask;
};

///////////////////////////////////////////////////////////////
// CFOPFourImageBoxShape -- image box that supports four images.

 
//===========================================================================
// Summary:
//     The CFOPFourImageBoxShape class derived from CFORectShape
//      F O P Four Image Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPFourImageBoxShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPFourImageBoxShape---F O P Four Image Box Shape, Specifies a E-XD++ CFOPFourImageBoxShape object (Value).
	DECLARE_SERIAL(CFOPFourImageBoxShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Four Image Box Shape, Constructs a CFOPFourImageBoxShape object.
	//		Returns A  value (Object).
	CFOPFourImageBoxShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Four Image Box Shape, Constructs a CFOPFourImageBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPFourImageBoxShape& src object(Value).
	CFOPFourImageBoxShape(const CFOPFourImageBoxShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Four Image Box Shape, Destructor of class CFOPFourImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPFourImageBoxShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPFourImageBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button component from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	// Show full size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Full Size, Do a event. 

	void DoShowFullSize();

    // Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Export to image.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Current timer ID
	
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current frame
	
	// Frame, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nFrame;
	
public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 
	
	void DoStartTimer();
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

public:
	// Current timer speed, default is 400
	
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;
	
	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPFourImageBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPFourImageBoxShape& src object(Value).
	CFOPFourImageBoxShape& operator=(const CFOPFourImageBoxShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this component.
	virtual CFODrawShape* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Do sub menu change.
	// nMenuItem -- menu item.
	// strState -- state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:
	
	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadImage(CString strImagePath);

	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Image, Call this function to remove a specify value from the specify object.

	void RemoveOldImage();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Click Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadClickImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Click Image, Call this function to remove a specify value from the specify object.

	void RemoveOldClickImage();

	
	// Init image position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPFourImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bResize---&bResize, Specifies A Boolean value.
	virtual BOOL DoStartShowEdit(const BOOL &bResize = FALSE);
    
public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Select status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Draws the 3D status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareMask();

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Click Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareClickMask();

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOPFourImageBoxShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Get transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetImageTransparentColor() const { return m_crTransparent; }

	// Set transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent Color, Sets a specify value to current class CFOPFourImageBoxShape
	// Parameters:
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	void SetImageTransparentColor(const COLORREF crTrans);


	// Change to second image state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set State, Sets a specify value to current class CFOPFourImageBoxShape
	// Parameters:
	//		&nSecond---&nSecond, Specifies A integer value.
	void SetState(const int &nSecond);

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Third Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadThirdImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Third Image, Call this function to remove a specify value from the specify object.

	void RemoveOldThirdImage();

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Third Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareThirdMask();


	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Four Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadFourImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Four Image, Call this function to remove a specify value from the specify object.

	void RemoveOldFourImage();
	
	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Four Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareFourMask();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

 
	// Normal File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalFile;
 
	// Click File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strClickFile;
 
	// Over File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOverFile;
 
	// Four File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strFourFile;

	// Change the hit test color of polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Colors, Sets a specify value to current class CFOPFourImageBoxShape
	// Parameters:
	//		highlightClr---highlightClr, Specifies A 32-bit COLORREF value used as a color value.  
	//		downclr---Specifies A 32-bit COLORREF value used as a color value.
	void SetColors(COLORREF highlightClr, COLORREF  downclr)
	{
		m_clrHighlight = highlightClr;   // default ::GetSysColor(COLOR_3DHIGHLIGHT)
		m_clrShadow = downclr;           // default ::GetSysColor(COLOR_3DSHADOW);
	}
	
protected:

	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL	m_bMouseDown;
	
	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL	m_bCanPress;
	
	// Colors for hit.
	COLORREF m_clrHighlight, m_clrShadow;

	
	// Image pointer.
 
	// Third Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImage;	
	
	// And mask image object.
 
	// Third Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImageAndMask;
	
	// Or mask image object.
 
	// Third Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pThirdImageOrMask;
	
	// Image pointer.
 
	// Four Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pFourImage;	
	
	// And mask image object.
 
	// Four Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pFourImageAndMask;
	
	// Or mask image object.
 
	// Four Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pFourImageOrMask;

protected:
	
	// Image pointer.
 
	// Click Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImage;		
	
	// Is transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL m_bTransparent;
	
	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTransparent;
	
	// And mask image object.
 
	// Click Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageAndMask;
	
	// Or mask image object.
 
	// Click Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageOrMask;

protected:

	// Image pointer.
 
	// Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImage;		

	// And mask image object.
 
	// Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageAndMask;

	// Or mask image object.
 
	// Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageOrMask;
};

//===========================================================================
// Summary:
//     The CFONewImageShape class derived from CFORectShape
//      New image shape.
//===========================================================================

class FO_EXT_CLASS CFONewImageShape : public CFORectShape  
{
protected:
	DECLARE_SERIAL(CFONewImageShape);
public:
	
	// constructor
	CFONewImageShape();
	
	// Copy constructor.
	CFONewImageShape(const CFONewImageShape& src);
	
	// Destructor.
	virtual ~CFONewImageShape();
	
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	CFONewImageShape& operator=(const CFONewImageShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	// Load image from file.
	BOOL LoadImageFile(const CString &strImage);

protected:

	// Load picture file
	void LoadPictureFile();
	
public:
	LPPICTURE	m_pPicture;
	int m_nImageWidth;
	int m_nImageHeight;
	CString m_strFileName;
};

//===========================================================================
// Summary:
//     The CFOXImageShape class derived from CFORectShape
//      New image shape.
//===========================================================================

class FO_EXT_CLASS CFOXImageShape : public CFORectShape  
{
protected:
	DECLARE_SERIAL(CFOXImageShape);
public:
	
	// constructor
	CFOXImageShape();
	
	// Copy constructor.
	CFOXImageShape(const CFOXImageShape& src);
	
	// Destructor.
	virtual ~CFOXImageShape();
	
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	CFOXImageShape& operator=(const CFOXImageShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	// Load image from file.
	BOOL LoadImageFile(const CString &strImage);

protected:

	// Load picture file
	void LoadPictureFile();
	
public:
	CFOPNewBitmap *m_pImageNormal;
	CFOPNewBitmap * m_pImageRotate;
	int m_nImageWidth;
	int m_nImageHeight;
	CString m_strFileName;
	int m_nSaveRotate;
};


////////////////////////////////////////////////////////////
// CFORotateRectShape

class FO_EXT_CLASS CFORotateRectShape : public CFORectShape  
{
protected:
	DECLARE_SERIAL(CFORotateRectShape);
public:
	
	// constructor
	CFORotateRectShape();
	
	// Copy constructor.
	CFORotateRectShape(const CFORotateRectShape& src);
	
	// Destructor.
	virtual ~CFORotateRectShape();
	
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	CFORotateRectShape& operator=(const CFORotateRectShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 
	
	void DoStartTimer();
	
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOPLiquidLineShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();

	int NormalValue(int nValue);
	
public:

	BOOL m_bReverse;

	// With Move State, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nWithMoveState;

	// Current timer ID
	
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current timer speed, default is 400
	
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;
	
	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

};

/////////////////////////////////////////////////////////////////////////
// CFOHMILedShape3
// FO_HMI_LED_SHAPE1 330

 
//===========================================================================
// Summary:
//     The CFOHMILedShape3 class derived from CFORectShape
//      F O H M I Led Shape1
//===========================================================================

class FO_EXT_CLASS CFOHMILedShape3 : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOHMILedShape3---F O H M I Led Shape1, Specifies a E-XD++ CFOHMILedShape3 object (Value).
	DECLARE_SERIAL(CFOHMILedShape3);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O H M I Led Shape1, Constructs a CFOHMILedShape3 object.
	//		Returns A  value (Object).
	CFOHMILedShape3();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O H M I Led Shape1, Constructs a CFOHMILedShape3 object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHMILedShape3& src object(Value).
	CFOHMILedShape3(const CFOHMILedShape3& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O H M I Led Shape1, Destructor of class CFOHMILedShape3
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOHMILedShape3();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOHMILedShape3 object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// SVG generate fill.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);
	
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOHMILedShape3& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHMILedShape3& src object(Value).
	CFOHMILedShape3& operator=(const CFOHMILedShape3& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	
	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOHMILedShape3
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOHMILedShape3
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// The pens and brushes needed to do the drawing
	
	// Timer Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	unsigned int m_TimerHandle;


};

#endif // !defined(AFC_FORECTSHAPE_H__58CE67D0_C817_11D5_A48A_525400EA266C__INCLUDED_)
