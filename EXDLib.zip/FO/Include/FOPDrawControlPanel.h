//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDRAWCONTROLPANEL_H__BB75ABE3_6FA2_451B_879E_A5FA08798A59__INCLUDED_)
#define AFX_FOPDRAWCONTROLPANEL_H__BB75ABE3_6FA2_451B_879E_A5FA08798A59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDrawControlPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDrawControlPanel window
#include "FOPDrawPickerBase.h"

#define SUNKENSHRINK 3
#define GREYSHRINK 3
#define DRAWSHRINK 2
#define FOCUSRECTWIDTH	1
#define DIVIDERWIDTH	2

 
//===========================================================================
// Summary:
//     The FOPDrawControlPanel class derived from FOPDrawPickerBase
//      O P Draw  Panel
//===========================================================================

class FO_EXT_CLASS FOPDrawControlPanel :  public FOPDrawPickerBase
{
public:
	// HeaderBars
	enum HasHeaderBar	
	{ 
		NoHeaderBar, 
		HeaderBarOne, 
		HeaderBarTwo, 
		HeaderBarBoth 
	};

	// Extra buttons.
	enum HasButton		
	{ 
		NoButton, 
		ButtonOne, 
		ButtonTwo, 
		ButtonBoth 
	};

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Draw  Panel, Constructs a FOPDrawControlPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarBoth object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
	FOPDrawControlPanel(HasHeaderBar ind = HeaderBarBoth, HasButton but = ButtonOne);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Draw  Panel, Destructor of class FOPDrawControlPanel
	//		Returns A  value (Object).
	~FOPDrawControlPanel();

	// Draw headerbar face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Header Bar Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawHeaderBarFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw button face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawButtonFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Get headerbar name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetHeaderBarName(int nIndex);

	// Get headerbar name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	const CString	GetHeaderBarName(HasHeaderBar ind);

	// Get button name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetButtonName(int nIndex);

	// Get button name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		ind---Specifies a HasButton ind object(Value).
	const CString  	GetButtonName(HasButton ind);

	// Get headerbar state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPDrawControlPanel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	virtual void	SetHeaderBarState(HasHeaderBar ind);

	// Set button state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button State, Sets a specify value to current class FOPDrawControlPanel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ind---Specifies a HasButton ind object(Value).
	virtual void	SetButtonState(HasButton ind);

	// Set headerbar string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar String, Sets a specify value to current class FOPDrawControlPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).  
	//		strText---strText, Specifies A CString type value.
	void			SetHeaderBarStr(HasHeaderBar ind, CString strText);

	// Set button string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button String, Sets a specify value to current class FOPDrawControlPanel
	// Parameters:
	//		ind---Specifies a HasButton ind object(Value).  
	//		strText---strText, Specifies A CString type value.
	void			SetButtonStr(HasButton ind, CString strText);
	
	// Get headerbar state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar State, Returns the specified value.
	//		Returns A HasHeaderBar value (Object).
	HasHeaderBar	GetHeaderBarState()	const	{	return m_nHeaderState;		}

	// Get button state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button State, Returns the specified value.
	//		Returns A HasButton value (Object).
	HasButton		GetButtonState()	const	{	return m_nCustButtonState;			}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify, .
	// Parameters:
	//		code---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Notify helper functions
	void 			Notify(UINT  code);
	
	// Get max headerbar button width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Header Bar Button Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int		GetMaxHeaderBarButtonWidth();
	
protected:

	// HeaderBar one string.
 
	// Header One Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strHeaderOneLabel;

	// HeaderBar two string.
 
	// Header Two Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strHeaderTwoLabel;

	// Button string.
 
	// Custom Button One Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCustButtonOneLabel;

	// Button two string.
 
	// Custom Button Two Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCustButtonTwoLabel;

	// HeaderBar state.
 
	// Header State, This member specify HasHeaderBar object.  
	HasHeaderBar	m_nHeaderState;

	// Button state.
 
	// Custom Button State, This member specify HasButton object.  
	HasButton		m_nCustButtonState;
	
};

// helper function
_FOLIB_INLINE void FOPFillRect(CDC& dc, const CRect& rc, const COLORREF& color)
{
	dc.SetBkColor(color);
	dc.ExtTextOut(0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDRAWCONTROLPANEL_H__BB75ABE3_6FA2_451B_879E_A5FA08798A59__INCLUDED_)
