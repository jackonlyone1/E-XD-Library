//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTABLESETDLG_H__88353E2B_61D4_4835_BAA2_3DE9CDC34CE7__INCLUDED_)
#define AFX_FOTABLESETDLG_H__88353E2B_61D4_4835_BAA2_3DE9CDC34CE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTableSetDlg.h : header file
//
#include "FOImageButton.h"

/////////////////////////////////////////////////////////////////////////////
// CFOTableSetDlg dialog

 
//===========================================================================
// Summary:
//     The CFOTableSetDlg class derived from CDialog
//      F O Table Set Dialog
//===========================================================================

class FO_EXT_CLASS CFOTableSetDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Set Dialog, Constructs a CFOTableSetDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOTableSetDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOTableSetDlg)
	enum { IDD = IDD_FO_TABLE_PROP };
 
	// Row, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinRow;
 
	// Column, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinCol;
 
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nCols;
 
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRows;
 
	// Fix Column, This member sets TRUE if it is right.  
	BOOL	m_bFixCol;
 
	// Fix Row, This member sets TRUE if it is right.  
	BOOL	m_bFixRow;
 
	// Grid Line, This member sets TRUE if it is right.  
	BOOL	m_bGridLine;
	//}}AFX_DATA

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTableSetDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOTableSetDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOMultiPolySetDlg dialog


//===========================================================================
// Summary:
//     The CFOMultiPolySetDlg class derived from CDialog
//      F O Table Set Dialog
//===========================================================================

class FO_EXT_CLASS CFOMultiPolySetDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Set Dialog, Constructs a CFOMultiPolySetDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOMultiPolySetDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOMultiPolySetDlg)
	enum { IDD = IDD_FO_TABLE_PROP };
	
	// Row, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinRow;
	
	// Column, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinCol;
	
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nCols;
	
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRows;
	
	// Fix Column, This member sets TRUE if it is right.  
	BOOL	m_bFixCol;
	
	// Fix Row, This member sets TRUE if it is right.  
	BOOL	m_bFixRow;
	
	// Grid Line, This member sets TRUE if it is right.  
	BOOL	m_bGridLine;
	//}}AFX_DATA
	
	
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiPolySetDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOMultiPolySetDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTABLESETDLG_H__88353E2B_61D4_4835_BAA2_3DE9CDC34CE7__INCLUDED_)
