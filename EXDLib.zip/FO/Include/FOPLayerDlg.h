//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLAYERDLG_H__61A91DF5_D25F_40DC_B3EB_50A446C8B777__INCLUDED_)
#define AFX_FOPLAYERDLG_H__61A91DF5_D25F_40DC_B3EB_50A446C8B777__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLayerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPLayerDlg dialog

#include "FOPListCtrl.h"
#include "FOImageButton.h"

class CFODataModel;
class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOPLayerDlg class derived from CDialog
//      F O P Layer Dialog
//===========================================================================

class FO_EXT_CLASS CFOPLayerDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer Dialog, Constructs a CFOPLayerDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		*pView---*pView, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPLayerDlg(CFODataModel *pModel,CFOPCanvasCore *pView,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPLayerDlg)
	enum { IDD = IDD_FO_LAYERDLG };
 
	// List, This member specify E-XD++ CFOPListCtrl object.  
	CFOPListCtrl	m_List;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

 
	// Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pDataModel;
 
	// View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *m_pView;

	// Init the list ctrl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial List , Call InitListCtrl after creating a new object.
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFOPListCtrl& list object (Value).
	void InitListCtrl(CFODataModel *pModel,CFOPListCtrl& list);
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Fill the list ctrl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill List , .
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFOPListCtrl& list object (Value).
	void FillListCtrl(CFODataModel *pModel,CFOPListCtrl& list);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPLayerDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPLayerDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button New, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonNew();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button Remove, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonRemove();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button Rename, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonRename();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Checkbox, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnCheckbox(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLAYERDLG_H__61A91DF5_D25F_40DC_B3EB_50A446C8B777__INCLUDED_)
