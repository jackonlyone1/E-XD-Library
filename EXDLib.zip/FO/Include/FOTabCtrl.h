//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTABCTRL_H__38B479A7_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
#define AFX_FOTABCTRL_H__38B479A7_D0E7_11D6_A665_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTabCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOTabCtrl window

#include "FOTabWndBuddy.h"

 
//===========================================================================
// Summary:
//     The CFOTabCtrl class derived from CWnd
//      F O Tab 
//===========================================================================

class FO_EXT_CLASS CFOTabCtrl : public CWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabCtrl---F O Tab , Specifies a E-XD++ CFOTabCtrl object (Value).
	DECLARE_DYNAMIC(CFOTabCtrl)
// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab , Constructs a CFOTabCtrl object.
	//		Returns A  value (Object).
	CFOTabCtrl();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab , Destructor of class CFOTabCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabCtrl();

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTabCtrl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new object.
	virtual BOOL Create(
		// Pointer of parent wnd.
		CWnd* pParentWnd,
		// Tab control style
		DWORD dwStyle = WS_CHILD | WS_VISIBLE,
		// Tab control's id
		UINT nID = AFX_IDW_PANE_FIRST);

	// Create a buddy control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Buddy , You construct a CFOTabCtrl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL CreateTemp(UINT nID);

// Attributes
public:

	// Get tab style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Style, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetTabStyle() const;

	// Set tab style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Style, Sets a specify value to current class CFOTabCtrl
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD SetTabStyle(DWORD dwStyle);

	// Enable or not tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Tab, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		bEnable---bEnable, Specifies A Boolean value.
    void EnableTab(CWnd* pWnd, BOOL bEnable = TRUE);

	// Enable or not tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Tab, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		bEnable---bEnable, Specifies A Boolean value.
    void EnableTab(int nTab, BOOL bEnable = TRUE);

	// Is specify tab enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Tab Enabled, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	BOOL IsTabEnabled(CWnd* pWnd);

	// Obtain the tab enable flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Tab Enabled, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	BOOL IsTabEnabled(int nTab);

	// Insert a new tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tab, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.
	virtual CFOTabCtrlObject* InsertTab(
		// Tab index to insert.
		int nTab,
		// Tab page wnd.
		CWnd* pWnd,
		// Label of new page.
		CString strLabel);

	// Add a new tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tab, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.
    virtual CFOTabCtrlObject* AddTab(
		// Tab page wnd.
		CWnd* pWnd,
		// Label of new page.
		CString strLabel);

	//Set draw 3d border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Client Border, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		bClient---bClient, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawClientBorder(const BOOL bClient,BOOL bRedraw = TRUE);

	// Set flat border line color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Flat Border Line Color, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetFlatBorderLineColor(const COLORREF crColor,BOOL bRedraw = TRUE);

	//Set draw client border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Flat Border, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		bFlat---bFlat, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawFlatBorder(const BOOL bFlat,BOOL bRedraw = TRUE);

	// Set inflating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Inflating, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		bInflat---bInflat, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetInflating(const BOOL bInflat,BOOL bRedraw = TRUE);

	// Set tab icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	virtual void SetTabPageIcon(
		// Specify a page index.
		int nTab, 
		// Handle of icon.
		HICON hIcon
		);

	// Set tab icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		nIDIcon---I D Icon, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		szImage---szImage, Specifies A CSize type value.  
	//		16---Specifies a 16 object(Value).
	virtual void SetTabPageIcon(
		// Index of tab page.
		int nTab, 
		// Icon resource ID.
		UINT nIDIcon,
		// Size of icon.
		CSize szImage = CSize(16,16)
		);

	// Set tab icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		szImage---szImage, Specifies A CSize type value.  
	//		16---Specifies a 16 object(Value).
	virtual void SetTabPageIcon(
		// Index of tab page.
		int nTab, 
		// Resource file name of Icon.
		LPCTSTR strResName,
		// Size of icon.
		CSize szImage = CSize(16,16)
		);

	// Remove a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    virtual void RemoveTab(
		// Pointer of tab page wnd to remove.
		CWnd* pWnd
		);

	// Remove a specify tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    virtual void RemoveTab(
		// Index of tab page to remove.
		int nTab
		);

	// Rename a specify tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename Tab, Call this function to Changes the name of the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.
    virtual void RenameTab(
		// Wnd pointer of tab page to rename.
		CWnd* pWnd, 
		// New label
		CString strLabel
		);

	virtual void InsertPage(int nTab, CString strPage);
	// Rename a specify tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename Tab, Call this function to Changes the name of the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strLabel---strLabel, Specifies A CString type value.
    virtual void RenameTab(
		// Index of a page to rename.
		int nTab,
		// New label.
		CString strLabel
		);

	// Draw vertial line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Vertical Line, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void DrawVertLine(CDC* pDC, CPoint pt, int nHeight, BOOL bRedraw = FALSE);

	// Draw horizontal line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Horizontal Line, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void DrawHorzLine(CDC* pDC, CPoint pt, int nWidth, BOOL bRedraw = FALSE);

	// Activate a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Tab, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    virtual void ActivateTab(CWnd* pWnd);

	// Activate a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Tab, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nTab---nTab, Specifies A integer value.
	virtual void ActivateTab(CWnd* pWnd, int nTab);

	// Activate a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Tab, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    virtual void ActivateTab(int nTab);

	// Clear select.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Select, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void ClearSelect();

	// activate tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Re Activate Tab, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnReActivateTab();

	// Set notify wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify Window, Sets a specify value to current class CFOTabCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNotifyWnd---Notify Window, A pointer to the CWnd or NULL if the call failed.
	virtual void SetNotifyWnd(CWnd* pNotifyWnd);

	// Get notify wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Notify Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetNotifyWnd();

	// Get total tab height or width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Total Height Or Width, Returns the specified value.
	//		Returns a int type value.
	int GetTabTotalHeightOrWidth();

	// Set total tab height or width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Total Height Or Width, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetTabTotalHeightOrWidth(const int nSize,BOOL bRedraw = TRUE);
	
	// Get tab count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	//		Returns a int type value.
    int GetTabCount();

	//Set draw money mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Money Mode, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		bMoney---bMoney, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawMoneyMode(
		// Microsoft's money 2000 style.
		const BOOL bMoney,
		// Invalidate or not.
		BOOL bRedraw = TRUE
		);

	// Get the information of a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Information, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		bSelected---bSelected, Specifies A Boolean value.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    BOOL GetTabInfo(int nTab, CString& strLabel,BOOL& bSelected, CWnd*& pWnd);

	// Find a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nTab---nTab, Specifies A integer value.
    BOOL FindTab(CWnd* pWnd, int& nTab) const;

	// Calc the tab's inside rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Inside Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void CalcInsideRect(CRect& rect) const;

	// Recalc layout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void RecalcLayout();

	// Draw mark or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Draw Mark, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsDrawMark() const;

	// Change the draw mark
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Mark, Sets a specify value to current class CFOTabCtrl
	// Parameters:
	//		bMark---bMark, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawMark(const BOOL bMark,BOOL bRedraw = TRUE);

	// Obtain the active tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    BOOL GetActiveTab(CWnd* pWnd);

	// Obtain the active tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    BOOL GetActiveTab(int& nTab);

	// Is current tab valid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Tab, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    BOOL IsValidTab(CWnd* pWnd);

	// Is current tab valid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Tab, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    BOOL IsValidTab(int nTab);

	// Get tab bundy control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab , Returns the specified value.
	//		Returns a pointer to the object CFOTabWndBuddy,or NULL if the call failed
	CFOTabWndBuddy* GetTabControl();

	// Fill rectangle.	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill Rectangle, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void DoFillRect(CDC* pDC,CPoint pt,int cx,int cy, COLORREF crColor);

	// Draw small mark.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Mark Left, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.
	void DrawMarkLeft(CDC *pDC,CPoint pt);

	// Draw small mark.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Mark Right, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.
	void DrawMarkRight(CDC *pDC,CPoint pt);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTabCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOTabCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Create, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpcs---Specifies a LPCREATESTRUCT lpcs object(Value).
	afx_msg BOOL OnNcCreate(LPCREATESTRUCT lpcs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Child Activate, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChildActivate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
    afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

    afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Font, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSetFont(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnInitialUpdate(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Tab, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSelectTab(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tab Message, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnTabMsg(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Get safe buddy.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Safe Buddy, Returns the specified value.
	//		Returns A E-XD++ CFOTabWndBuddy& value (Object).
	CFOTabWndBuddy& GetSafeBuddy() const;

	// Pointer of buddy control.
 
	// Tab Buddy , This member maintains a pointer to the object CFOTabWndBuddy.  
	CFOTabWndBuddy *m_pTabBuddyCtrl;
	
private:
	
 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTABCTRL_H__38B479A7_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
