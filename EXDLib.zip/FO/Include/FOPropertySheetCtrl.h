//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPROPERTYSHEETCTRL_H__052BC6A7_FF1A_11D5_A509_525400EA266C__INCLUDED_)
#define AFX_FOPROPERTYSHEETCTRL_H__052BC6A7_FF1A_11D5_A509_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPropertySheetCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPropertySheetCtrl

 
//===========================================================================
// Summary:
//     The CFOPropertySheetCtrl class derived from CPropertySheet
//      F O Property Sheet 
//===========================================================================

class FO_EXT_CLASS CFOPropertySheetCtrl : public CPropertySheet
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPropertySheetCtrl---F O Property Sheet , Specifies a E-XD++ CFOPropertySheetCtrl object (Value).
	DECLARE_DYNAMIC(CFOPropertySheetCtrl)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Sheet , Constructs a CFOPropertySheetCtrl object.
	//		Returns A  value (Object).
	CFOPropertySheetCtrl();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Sheet , Constructs a CFOPropertySheetCtrl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nIDCaption---I D Caption, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		iSelectPage---Select Page, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPropertySheetCtrl(
		// Resource ID of caption.
		UINT nIDCaption, 
		// Pointer of parent wnd.
		CWnd *pParentWnd = NULL,
		// Select page.
		UINT iSelectPage = 0
		);  

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Sheet , Constructs a CFOPropertySheetCtrl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pszCaption---pszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		*pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		iSelectPage---Select Page, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPropertySheetCtrl(
		// Caption.
		LPCTSTR pszCaption,
		// Pointer of parent wnd.
		CWnd *pParentWnd = NULL,
		// Select page.
		UINT iSelectPage = 0);

public:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property Sheet , Destructor of class CFOPropertySheetCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPropertySheetCtrl();

	// Creates an imbedded property sheet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Imbedded, You construct a CFOPropertySheetCtrl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual BOOL CreateImbedded(CWnd* pParentWnd,DWORD dwStyle = (DWORD)-1, DWORD dwExStyle = 0);

// Attributes
public:

	// Returns nonzero if the property sheet is imbedded.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Imbedded, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImbedded() const;

	// Compare class name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Class Name, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hWndCtl---Window Ctl, Specifies a HWND hWndCtl object(Value).  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL CompareClassName(HWND hWndCtl, LPCTSTR lpszClassName);

// Operations
public:

	// Returns the position of the active page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Page Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CRect&---Rect&, Specifies A CRect type value.
	BOOL GetActivePageRect(CRect&) const;

	// Returns the position of property pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Rectangle, Returns the specified value.
	// Parameters:
	//		CRect&---Rect&, Specifies A CRect type value.
	void GetPageRect(CRect&) const;

	// Returns the position of the tab control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab  Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CRect&---Rect&, Specifies A CRect type value.
	BOOL GetTabControlRect(CRect&) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Query Siblings, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	// Sends aPSM_QUERYSIBLINGS to all property pages.
	LRESULT QuerySiblings(WPARAM wParam, LPARAM lParam);

	// Determines if the Apply button is visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Apply Button, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		BOOL---O O L, Specifies A Boolean value.
	BOOL SetApplyButton(BOOL);

	// Sets the position of property pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Rectangle, Sets a specify value to current class CFOPropertySheetCtrl
	// Parameters:
	//		CRect---Rectangle, Specifies A CRect type value.
	void SetPageRect(CRect);

	// Sets the caption for the specified page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Title, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPage---nPage, Specifies A integer value.  
	//		strTitle---strTitle, Specifies A CString type value.
	BOOL SetPageTitle(int nPage, CString strTitle);

	// Sets the caption for the specified page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Title, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pPage---pPage, A pointer to the CPropertyPage or NULL if the call failed.  
	//		strTitle---strTitle, Specifies A CString type value.
	BOOL SetPageTitle(CPropertyPage* pPage, CString strTitle);

	// Sets the tab control position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab  Rectangle, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CRect---Rectangle, Specifies A CRect type value.
	BOOL SetTabControlRect(CRect);

	// Sends a BN_CLICKED notification to the specified control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Simulate Button Click, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SimulateButtonClick(CWnd* pParent, UINT nID);

	// Calls <mf CWnd::UpdateData> for each property page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Data For All Pages, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bSaveAndValidate---Save And Validate, Specifies A Boolean value.
	virtual BOOL UpdateDataForAllPages(BOOL bSaveAndValidate);

// @access Overridables
protected:

	// Override this member function to perform idle-time processing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Idle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lCount---lCount, Specifies A 32-bit LONG signed integer.
	virtual BOOL OnIdle(LONG lCount);

	// Called when the <m WM_INITDIALOG> message is received.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Property Sheet, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitPropertySheet();

	// Called when the Cancel button is pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnQueryCancel();

	// Called when the OK button is pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnQueryOK();

	// Called when the Escape key is pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Translate Escape Key, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL OnTranslateEscapeKey(MSG* pMsg);

	// Called when the Return key is pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Translate Return Key, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL OnTranslateReturnKey(MSG* pMsg);

// @access Data members
public:
	// Flag that indicates whether a control that has no
 
	// Disable Cmd U I If No Handler, This member sets TRUE if it is right.  
	BOOL m_bDisableCmdUIIfNoHandler;

	// Pre translate key down message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Keydown Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateKeydownMessage(MSG* pMsg);

	// Update controls state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CPropertySheet or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
	virtual void OnUpdateCmdUI(CPropertySheet* pTarget, BOOL bDisableIfNoHndler);

	// Do tab control changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tab  Select Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		NMHDR*---M H D R*, A pointer to the NMHDR or NULL if the call failed.  
	//		LRESULT*---R E S U L T*, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnTabControlSelChange(NMHDR*, LRESULT*);

	// Imbedde command message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Imbedded Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO or NULL if the call failed.
	virtual BOOL OnImbeddedCmdMsg(UINT nID, int nCode, void* pExtra,AFX_CMDHANDLERINFO* pHandlerInfo);

protected:
	// Shift right.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shift Right, .
	// Parameters:
	//		lt---Specifies A integer value.  
	//		rt---Specifies A integer value.  
	//		bHideRt---Hide Rt, Specifies A Boolean value.
	void ShiftRight(int lt, int rt, BOOL bHideRt);

	// Resize tab control to fit the page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Tab  To Fit, .

	void ResizeTabControlToFit();

	// Common construct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Common Construct, .

	void CommonConstruct();

	// Set tab control title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab  Title, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPage---nPage, Specifies A integer value.  
	//		strText---strText, Specifies A CString type value.
	BOOL SetTabControlTitle(int nPage, CString strText);

	// Set internal page title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Internal Page Title, Sets a specify value to current class CFOPropertySheetCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pPage---pPage, A pointer to the CPropertyPage or NULL if the call failed.  
	//		strCaption---strCaption, Specifies A CString type value.
	BOOL SetInternalPageTitle(CPropertyPage* pPage, CString strCaption);

// Overrides
public:
	//{{AFX_VIRTUAL(CFOPropertySheetCtrl)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO or NULL if the call failed.
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Post Nc Destroy, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PostNcDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
// Message map functions
protected:
	//{{AFX_MSG(CFOPropertySheetCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnOK(UINT);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnCancel(UINT);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Apply Now, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnApplyNow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kick Idle, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnKickIdle(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Idle Update Cmd U I, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnIdleUpdateCmdUI(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Resize Page, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnResizePage(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Menu Popup, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pPopupMenu---Popup Menu, A pointer to the CMenu or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysMenu---System Menu, Specifies A Boolean value.
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	//}}AFX_MSG
#if _MFC_VER < 0x0420
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Initial Dialog, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT HandleInitDialog(WPARAM, LPARAM);
#endif

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Has apply button or not.
 
	// Has Apply Button, This member sets TRUE if it is right.  
	BOOL m_bHasApplyButton;

	// Imbedde or not.
 
	// Imbedded, This member sets TRUE if it is right.  
	BOOL m_bImbedded;

	// Rectangle of current page.
 
	// Page Rectangle, This member sets a CRect value.  
    CRect m_rcPageRect;

	// Init tab control.
 
	// Tab  Initial, This member sets a CRect value.  
	CRect m_rcTabControlInit;

	// Rectangle of property page.
 
	// Property Page Initial, This member sets a CRect value.  
	CRect m_rcPropPageInit;

	// Initialize or not.
 
	// Initialized, This member sets TRUE if it is right.  
	BOOL m_bInitialized;

	// Command message lock or not.
 
	// Lock Cmd Message, This member sets TRUE if it is right.  
	BOOL m_bLockCmdMsg;

};

/////////////////////////////////////////////////////////////////////////////
_FOLIB_INLINE BOOL CFOPropertySheetCtrl::IsImbedded() const
{
	return m_bImbedded;
}
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPROPERTYSHEETCTRL_H__052BC6A7_FF1A_11D5_A509_525400EA266C__INCLUDED_)
