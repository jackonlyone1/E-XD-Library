//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBaseGridListCtrl.h: interface for the CFOBaseGridListCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBASEGRIDLISTCTRL_H__7BB50714_F4AC_11DD_A439_525400EA266C__INCLUDED_)
#define AFX_FOBASEGRIDLISTCTRL_H__7BB50714_F4AC_11DD_A439_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFOBaseGridListCtrl window

#define FO_GRIDROWMODE
#define FO_GRIDFIRSTCOLUMNMODE
#define FO_GRIDANYCOLUMNMODE
#define FO_GRIDCOLUMNWIDTHS
#define FO_GRIDGRIDLINEMODE

///////////////////////////////////////////////////////////////////
// Don't need either of these in "Row Mode".
#if defined FO_GRIDROWMODE
#undef FO_GRIDFIRSTCOLUMNMODE
#undef FO_GRIDANYCOLUMNMODE
#endif

///////////////////////////////////////////////////////////////////
// CFOBaseGridListCtrl class

 
//===========================================================================
// Summary:
//     The CFOBaseGridListCtrl class derived from CListCtrl
//      F O Base Grid List 
//===========================================================================

class FO_EXT_CLASS CFOBaseGridListCtrl : public CListCtrl
{
public:
	
	// Constructor - handles default initialization.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Grid List , Constructs a CFOBaseGridListCtrl object.
	//		Returns A  value (Object).
	CFOBaseGridListCtrl();
		
	// Destructor - handles cleanup and de-allocation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Grid List , Destructor of class CFOBaseGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseGridListCtrl();
	
public:
	
	// if it is a item return true, else return false.			
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Item, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL   IsItem(int nItem) const;
	
	// Return Value:		if it is a column return true, else return false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Column, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCol---nCol, Specifies A integer value.
	BOOL   IsColumn(int nCol) const;
	
	// Return Value:		the selected item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Item, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nStartItem---Start Item, Specifies A integer value.
	int    GetSelectedItem(int nStartItem = -1) const;
	
	// Return Value:		if it is be selected return true, else it will return false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Item, Call this function to select the given item.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL   SelectItem(int nItem);
	
	//Return Value:		if all is be selected return true, else it will return false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select All, Call this function to select the given item.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL   SelectAll();
	
public:
	// Get Mode First Column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mode First Column, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL   GetModeFirstColumn() const;

	// Set Mode First Column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode First Column, Sets a specify value to current class CFOBaseGridListCtrl
	// Parameters:
	//		b---Specifies A Boolean value.
	void   SetModeFirstColumn(BOOL b = TRUE);
	
	// Get Mode Any Column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mode Any Column, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL   GetModeAnyColumn() const;

	// Set Mode Any Column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode Any Column, Sets a specify value to current class CFOBaseGridListCtrl
	// Parameters:
	//		b---Specifies A Boolean value.
	void   SetModeAnyColumn(BOOL b = TRUE);
	
	// Set Mode Column Widths
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode Column Widths, Sets a specify value to current class CFOBaseGridListCtrl
	// Parameters:
	//		s---Specifies A CString type value.
	void   SetModeColumnWidths(const CString& s);

	// Set Mode Grid Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode Grid Line, Sets a specify value to current class CFOBaseGridListCtrl
	// Parameters:
	//		bHorz---bHorz, Specifies A Boolean value.  
	//		bVert---bVert, Specifies A Boolean value.
	void   SetModeGridLine(BOOL bHorz = TRUE, BOOL bVert = TRUE);

	// Get Mode Grid Line Horizon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mode Grid Line Horizontal, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL   GetModeGridLineHorz() const;

	// Get Mode Grid Line Vertical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mode Grid Line Vertical, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL   GetModeGridLineVert() const;	

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOBaseGridListCtrl)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
#if defined FO_GRIDROWMODE

	// Draw Item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
#endif
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOBaseGridListCtrl)

	//message map functions On mouse Click
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);

	//message map functions On window  Destroyed
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//}}AFX_MSG

	//message map functions On Set Font
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Font, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSetFont(WPARAM wParam,LPARAM lParam);

	//message map functions On Measure Item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	afx_msg void	MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
#ifdef FO_GRIDSORTMODE

		//message map functions On Column clicked
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Columnclick, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Function, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		lParam1---lParam1, Specifies A LPARAM value.  
	//		lParam2---lParam2, Specifies A LPARAM value.  
	//		lParamSort---Parameter Sort, Specifies A LPARAM value.
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2,LPARAM lParamSort);
#endif
	
protected:
	// Member variable
	// Whether Mode First Column
 
	// Mode First Column, This member sets TRUE if it is right.  
	BOOL      m_bModeFirstColumn;

	// Whether Mode Any Column
 
	// Mode Any Column, This member sets TRUE if it is right.  
	BOOL      m_bModeAnyColumn;

    // Column Sort
 
	// Column Sort, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int       m_nColumnSort;

	// Whether Sort Ascending
 
	// Sort Ascending, This member sets TRUE if it is right.  
	BOOL      m_bSortAscending;

	// Column Widths Key
 
	// Column Widths Key, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString   m_sColumnWidthsKey;

	// Mode Grid Line Horizon
 
	// Mode Grid Line Horizontal, This member sets TRUE if it is right.  
	BOOL      m_bModeGridLineHorz;

	//  Mode Grid Line Vertical
 
	// Mode Grid Line Vertical, This member sets TRUE if it is right.  
	BOOL      m_bModeGridLineVert;
};

//-----------------------------------------------------------------------
// Judge Whether Mode First Column
_FOLIB_INLINE BOOL CFOBaseGridListCtrl::GetModeFirstColumn() const
{ return m_bModeFirstColumn; }

//-----------------------------------------------------------------------
// Judge Whether Mode Any Column
_FOLIB_INLINE BOOL CFOBaseGridListCtrl::GetModeAnyColumn() const
{ return m_bModeAnyColumn; }

//-----------------------------------------------------------------------
// Set Mode Grid Line:horizon and vertical
_FOLIB_INLINE void CFOBaseGridListCtrl::SetModeGridLine(BOOL bHorz, BOOL bVert)
{ m_bModeGridLineHorz = bHorz;m_bModeGridLineVert = bVert; }

//-----------------------------------------------------------------------
// Judge Whether Mode Grid Line Horizon
_FOLIB_INLINE BOOL CFOBaseGridListCtrl::GetModeGridLineHorz() const
{ return m_bModeGridLineHorz; }

//-----------------------------------------------------------------------
// Judge Whether Mode Grid Line Vertical
_FOLIB_INLINE BOOL CFOBaseGridListCtrl::GetModeGridLineVert() const
{ return m_bModeGridLineVert; }

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_FOBASEGRIDLISTCTRL_H__7BB50714_F4AC_11DD_A439_525400EA266C__INCLUDED_)
