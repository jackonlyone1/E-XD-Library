//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOCompsPropAction.h: interface for the CFOCompsPropAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCOMPSPROPACTION_H__2B1FD564_9C71_11D6_A610_0050BAE30439__INCLUDED_)
#define AFX_FOCOMPSPROPACTION_H__2B1FD564_9C71_11D6_A610_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
#include "FOBaseProperties.h"

//////////////////////////////////////////////////////////////////////////////
// CFOShapeBoolAction -- action Defined for BOOL property value.
/////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOShapeBoolAction class derived from CFOAction
//      F O Shape Bool Action
//===========================================================================

class FO_EXT_CLASS CFOShapeBoolAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeBoolAction---F O Shape Bool Action, Specifies a E-XD++ CFOShapeBoolAction object (Value).
	DECLARE_ACTION(CFOShapeBoolAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Bool Action, Constructs a CFOShapeBoolAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeBoolAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Bool Action, Destructor of class CFOShapeBoolAction
	//		Returns A  value (Object).
	~CFOShapeBoolAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeBoolAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&bValue---&bValue, Specifies A Boolean value.
	void ChangePropValue(const int &nPropID,const BOOL &bValue);

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member sets TRUE if it is right.  
	BOOL			m_bNewValue;

	// Save old value.
 
	// Old Value, This member sets TRUE if it is right.  
	BOOL			m_bOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeBoolAction::ChangePropValue(const int &nPropID,const BOOL &bValue)
{
	m_nPropId = nPropID;
	m_bNewValue = bValue;
}

_FOLIB_INLINE void CFOShapeBoolAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeBoolAction::GetShape()
{
	return m_pShape;
}

//////////////////////////////////////////
//CFOShapeIntAction -- action that defined for int property value
//////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOShapeIntAction class derived from CFOAction
//      F O Shape Int Action
//===========================================================================

class FO_EXT_CLASS CFOShapeIntAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeIntAction---F O Shape Int Action, Specifies a E-XD++ CFOShapeIntAction object (Value).
	DECLARE_ACTION(CFOShapeIntAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Int Action, Constructs a CFOShapeIntAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeIntAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Int Action, Destructor of class CFOShapeIntAction
	//		Returns A  value (Object).
	~CFOShapeIntAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeIntAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&nValue---&nValue, Specifies A integer value.
	void ChangePropValue(const int &nPropID,const int &nValue);
	
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nNewValue;

	// Save old value.
 
	// Old Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeIntAction::ChangePropValue(const int &nPropID,const int &nValue)
{
	m_nPropId = nPropID;
	m_nNewValue = nValue;
}

_FOLIB_INLINE void CFOShapeIntAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeIntAction::GetShape()
{
	return m_pShape;
}

//////////////////////////////////////////////
// CFOShapeStringAction -- action that defined for String property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeStringAction class derived from CFOAction
//      F O Shape String Action
//===========================================================================

class FO_EXT_CLASS CFOShapeStringAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeStringAction---F O Shape String Action, Specifies a E-XD++ CFOShapeStringAction object (Value).
	DECLARE_ACTION(CFOShapeStringAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape String Action, Constructs a CFOShapeStringAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeStringAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape String Action, Destructor of class CFOShapeStringAction
	//		Returns A  value (Object).
	~CFOShapeStringAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeStringAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&strValue---&strValue, Specifies A CString type value.
	void ChangePropValue(const int &nPropID,const CString &strValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strNewValue;

	// Save old value.
 
	// Old Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeStringAction::ChangePropValue(const int &nPropID,const CString &strValue)
{
	m_nPropId = nPropID;
	m_strNewValue = strValue;
}

_FOLIB_INLINE void CFOShapeStringAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeStringAction::GetShape()
{
	return m_pShape;
}


//////////////////////////////////////////////
// CFOShapeFloatAction -- action that defined for float property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeFloatAction class derived from CFOAction
//      F O Shape Float Action
//===========================================================================

class FO_EXT_CLASS CFOShapeFloatAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeFloatAction---F O Shape Float Action, Specifies a E-XD++ CFOShapeFloatAction object (Value).
	DECLARE_ACTION(CFOShapeFloatAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Float Action, Constructs a CFOShapeFloatAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeFloatAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Float Action, Destructor of class CFOShapeFloatAction
	//		Returns A  value (Object).
	~CFOShapeFloatAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeFloatAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&fValue---&fValue, Specifies A float value.
	void ChangePropValue(const int &nPropID,const float &fValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fNewValue;

	// Save old value.
 
	// Old Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeFloatAction::ChangePropValue(const int &nPropID,const float &fValue)
{
	m_nPropId = nPropID;
	m_fNewValue = fValue;
}

_FOLIB_INLINE void CFOShapeFloatAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeFloatAction::GetShape()
{
	return m_pShape;
}


//////////////////////////////////////////////
// CFOShapeDoubleAction -- action that defined for double property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeDoubleAction class derived from CFOAction
//      F O Shape Double Action
//===========================================================================

class FO_EXT_CLASS CFOShapeDoubleAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeDoubleAction---F O Shape Double Action, Specifies a E-XD++ CFOShapeDoubleAction object (Value).
	DECLARE_ACTION(CFOShapeDoubleAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Double Action, Constructs a CFOShapeDoubleAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeDoubleAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Double Action, Destructor of class CFOShapeDoubleAction
	//		Returns A  value (Object).
	~CFOShapeDoubleAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeDoubleAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void ChangePropValue(const int &nPropID,const double &dValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify double object.  
	double	m_dNewValue;

	// Save old value.
 
	// Old Value, This member specify double object.  
	double	m_dOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeDoubleAction::ChangePropValue(const int &nPropID,const double &dValue)
{
	m_nPropId = nPropID;
	m_dNewValue = dValue;
}

_FOLIB_INLINE void CFOShapeDoubleAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeDoubleAction::GetShape()
{
	return m_pShape;
}


//////////////////////////////////////////////
// CFOShapeDWordAction -- action that defined for DWORD property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeDWordAction class derived from CFOAction
//      F O Shape D Word Action
//===========================================================================

class FO_EXT_CLASS CFOShapeDWordAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeDWordAction---F O Shape D Word Action, Specifies a E-XD++ CFOShapeDWordAction object (Value).
	DECLARE_ACTION(CFOShapeDWordAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape D Word Action, Constructs a CFOShapeDWordAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeDWordAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape D Word Action, Destructor of class CFOShapeDWordAction
	//		Returns A  value (Object).
	~CFOShapeDWordAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeDWordAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void ChangePropValue(const int &nPropID,const DWORD &dwValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwNewValue;

	// Save old value.
 
	// Old Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeDWordAction::ChangePropValue(const int &nPropID,const DWORD &dwValue)
{
	m_nPropId = nPropID;
	m_dwNewValue = dwValue;
}

_FOLIB_INLINE void CFOShapeDWordAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeDWordAction::GetShape()
{
	return m_pShape;
}

//////////////////////////////////////////////
// CFOShapeDateTimeAction -- action that defined for date time value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeDateTimeAction class derived from CFOAction
//      F O Shape Date Time Action
//===========================================================================

class FO_EXT_CLASS CFOShapeDateTimeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeDateTimeAction---F O Shape Date Time Action, Specifies a E-XD++ CFOShapeDateTimeAction object (Value).
	DECLARE_ACTION(CFOShapeDateTimeAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Date Time Action, Constructs a CFOShapeDateTimeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeDateTimeAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Date Time Action, Destructor of class CFOShapeDateTimeAction
	//		Returns A  value (Object).
	~CFOShapeDateTimeAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeDateTimeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).
	void ChangePropValue(const int &nPropID,const COleDateTime &dtValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify COleDateTime object.  
	COleDateTime	m_dtNewValue;

	// Save old value.
 
	// Old Value, This member specify COleDateTime object.  
	COleDateTime	m_dtOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeDateTimeAction::ChangePropValue(const int &nPropID,const COleDateTime &dtValue)
{
	m_nPropId = nPropID;
	m_dtNewValue = dtValue;
}

_FOLIB_INLINE void CFOShapeDateTimeAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeDateTimeAction::GetShape()
{
	return m_pShape;
}


//////////////////////////////////////////////
// CFOShapeColorAction -- action that defined for color property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOShapeColorAction class derived from CFOAction
//      F O Shape Color Action
//===========================================================================

class FO_EXT_CLASS CFOShapeColorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeColorAction---F O Shape Color Action, Specifies a E-XD++ CFOShapeColorAction object (Value).
	DECLARE_ACTION(CFOShapeColorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Color Action, Constructs a CFOShapeColorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOShapeColorAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Color Action, Destructor of class CFOShapeColorAction
	//		Returns A  value (Object).
	~CFOShapeColorAction();

public:

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeColorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void ChangePropValue(const int &nPropID,const COLORREF &crValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pShape;

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crNewValue;

	// Save old value.
 
	// Old Value, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOShapeColorAction::ChangePropValue(const int &nPropID,const COLORREF &crValue)
{
	m_nPropId = nPropID;
	m_crNewValue = crValue;
}

_FOLIB_INLINE void CFOShapeColorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOShapeColorAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOCOMPSPROPACTION_H__2B1FD564_9C71_11D6_A610_0050BAE30439__INCLUDED_)
