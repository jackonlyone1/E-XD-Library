//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEMNG_H__8741361B_F979_4F7F_BC4D_522EBCEC2EC9__INCLUDED_)
#define AFX_FOIMAGEMNG_H__8741361B_F979_4F7F_BC4D_522EBCEC2EC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageMNG.h : header file
//

#include "FOBitmap.h"

/////////////////////////////////////////////////////////////////////////////
// CFOMNGFrame MNG file frame

 
//===========================================================================
// Summary:
//      To use a CFOMNGFrame object, just call the constructor.
//      F O M N G Frame
//===========================================================================

class FO_EXT_CLASS CFOMNGFrame
{

protected:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O M N G Frame, Constructs a CFOMNGFrame object.
	//		Returns A  value (Object).
	CFOMNGFrame();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O M N G Frame, Constructs a CFOMNGFrame object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&src---Specifies a const CFOMNGFrame &src object(Value).
	CFOMNGFrame( const CFOMNGFrame &src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMNGFrame &operator value (Object).  
	// Parameters:
	//		&src---Specifies a const CFOMNGFrame &src object(Value).
	// Operator = 
	CFOMNGFrame &operator =( const CFOMNGFrame &src);

public:

	// Constructor.
	// pBmp -- pointer of the image.
	// nTime -- Time of the image frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O M N G Frame, Constructs a CFOMNGFrame object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pBmp---*pBmp, A pointer to the CFOBitmap  or NULL if the call failed.  
	//		nTime---nTime, Specifies A integer value.
	CFOMNGFrame( CFOBitmap *pBmp, int nTime );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O M N G Frame, Destructor of class CFOMNGFrame
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMNGFrame();

	//	Obtain the pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image, Returns the specified value.
	//		Returns a pointer to the object const CFOBitmap ,or NULL if the call failed
	const CFOBitmap *GetImage() const { return m_pSaveImage; }

	// Obtain the pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	CFOBitmap *GetImage() { return m_pSaveImage; }

	// Change the pointer of the image.
	// pBmp -- pointer of the bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image, Sets a specify value to current class CFOMNGFrame
	// Parameters:
	//		*pBmp---*pBmp, A pointer to the CFOBitmap  or NULL if the call failed.
	void SetImage(CFOBitmap *pBmp) { m_pSaveImage = pBmp; }

	//	Get the time this frame should be showed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Time, Returns the specified value.
	//		Returns a int type value.
	int GetTime() const { return m_nTime; }

	// Change the time of this frame be showing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Time, Sets a specify value to current class CFOMNGFrame
	// Parameters:
	//		&nTime---&nTime, Specifies A integer value.
	void SetTime(const int &nTime) { m_nTime = nTime; }

protected:
	// Pointer of the saving image.
 
	// Save Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *	m_pSaveImage;

	// Time of the frame to showing.
 
	// Time, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTime;
};


/////////////////////////////////////////////////////////////////////////////
// CFODrawImageMNG class

class CFOMNGFrame;
typedef CFOArray< CFOMNGFrame*> CFOMNGFrameArray;
 
//===========================================================================
// Summary:
//     The CFODrawImageMNG class derived from CFODrawImage
//      F O Draw Image M N G
//===========================================================================

class FO_EXT_CLASS CFODrawImageMNG : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImageMNG---F O Draw Image M N G, Specifies a E-XD++ CFODrawImageMNG object (Value).
	DECLARE_SERIAL(CFODrawImageMNG)

public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image M N G, Constructs a CFODrawImageMNG object.
	//		Returns A  value (Object).
	CFODrawImageMNG();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image M N G, Destructor of class CFODrawImageMNG
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImageMNG();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImageMNG &target object(Value).
	virtual BOOL operator==(const CFODrawImageMNG &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);

public:
	// Save document.
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap();

	// Obtain the image of the frame.
	// nFrame -- number of frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Image, Returns the specified value.
	//		Returns a pointer to the object const CFOBitmap ,or NULL if the call failed  
	// Parameters:
	//		nFrame---nFrame, Specifies A integer value.
	const CFOBitmap *GetFrameImage( int nFrame ) const;

	// Obtain the pointer of the image of the frame.
	// nFrame -- number of frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Image, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed  
	// Parameters:
	//		nFrame---nFrame, Specifies A integer value.
	CFOBitmap *GetFrameImage( int nFrame );

	// Clear all the image datas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();
	
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	virtual BOOL Read(UINT nID,LPCTSTR pcszResourceType);

	// load icon file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);

	// Read single frame png file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read P N G, Call this function to read the specify data from an archive.
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).
	CFOBitmap * ReadPNG( CFODataReadBase &reader );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Decode, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).  
	//		&arFrames---&arFrames, Specifies a E-XD++ CFOMNGFrameArray &arFrames object (Value).
	// Decode the mng file format.
	bool Decode( CFODataReadBase &reader, CFOMNGFrameArray &arFrames);

protected:

	// Array of the frames.
 
	// Frames, This member specify E-XD++ CFOMNGFrameArray object.  
	CFOMNGFrameArray	m_arFrames;

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEMNG_H__8741361B_F979_4F7F_BC4D_522EBCEC2EC9__INCLUDED_)
