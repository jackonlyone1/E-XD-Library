//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU(ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOGlobals.h: interface for the CFOGlobals class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOGLOBALS_H__2EEABBE7_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOGLOBALS_H__2EEABBE7_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <math.h>
#include "FODrawShadow.h"
#include "FOPVisualProxy.h"
#include "FODefines.h"
#include "FOCompProperties.h"
#include "FODefStyleData.h"

/////////////////////////////////////////////////////////////////////////////////
//
// FO_GLOBAL
/////////////////////////////////////////////////////////////////////////////////

struct FO_BRUSH_STATE
{
	CBitmap m_bmArray[41]; // Fill texture.
};

// Undo / Redo selection message.
#define WM_FO_UNDOREDO							WM_USER+500 // Undo /Redo change messages.

// picker alignment.
#define FO_ALIGNBOTTOMLEFT						0x0001	

// Default select track line style.
const int		fo_DefaultTrackSelectLineType	= PS_DASH;

// Default track line color.
const COLORREF	fo_DefaultTrackLineColor		= RGB(0,0,0);

// Default select tracker color.
const COLORREF  fo_SelectCompColor				= RGB(0,255,0);

// Default un select tracker color.
const COLORREF  fo_RotateHandleColor			= RGB(255,255,0);

// Default select shape handle size.
const CSize		fo_SelelectCompHandleSize		= CSize(3,3);

// Default dot line color.
const COLORREF  fo_DefaultDotLineColor			= RGB(0,0,255);

// Default color for focus shape.
const COLORREF  fo_crDefaultFocus				= RGB(255,0,0);

// Default fill color.
const COLORREF  fo_DefaultFillColor				= RGB(255,255,255);

// Printer page table entry
typedef struct {
	CString strName; // Index of page type
    int nPageWidth;	// Width of printer paper.
	int nPageHeight;// Height of printer paper.
} FO_PaperInfo;

//////////////////////////////////////////////////////////////////////
// FO_GLOBAL is a stand alone global item data structure class. It is
// used by the toolkit to initialize and store resource and item data shared
// by all objects.  Items include system colors, icons, fonts and OS flags.
//


//////////////////////////////////////////////////////////////////////
// FOPenInfo a struct defined for pen information.
//

 
//===========================================================================
// Summary:
//      To use a FOPenInfo object, just call the constructor.
//      O Pen Information
//===========================================================================

class FO_EXT_CLASS FOPenInfo
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Pen Information, Constructs a FOPenInfo object.
	//		Returns A  value (Object).
	FOPenInfo();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pen Information, Destructor of class FOPenInfo
	//		Returns A  value (Object).
	~FOPenInfo() {};

	// Obtain double value.
	double GetVal();

	// Pen style
 
	// Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT    lopnStyle;

	// Pen width
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int     lopnWidth;

	// Pen color
 
	// Color, This member sets A 32-bit value used as a color value.  
    COLORREF lopnColor;

};

//////////////////////////////////////////////////////////////////////
// CFOPenObject a alone class defined for Pen pointer and other information.
//

 
//===========================================================================
// Summary:
//     The CFOPenObject class derived from FOIUnknown
//      F O Pen Object
//===========================================================================

class FO_EXT_CLASS CFOPenObject : public FOIUnknown
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPenObject---F O Pen Object, Specifies a E-XD++ CFOPenObject object (Value).
	DECLARE_SERIAL(CFOPenObject)

public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pen Object, Constructs a CFOPenObject object.
	//		Returns A  value (Object).
	CFOPenObject();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pen Object, Destructor of class CFOPenObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPenObject();

	// Get Pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetPen();

	// Create Pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pen, You construct a CFOPenObject object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed
	CPen* CreatePen();

	// Get Pen info.
	// pInfo -- pen info object pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Information, Returns the specified value.
	// Parameters:
	//		*pInfo---*pInfo, A pointer to the FOPenInfo  or NULL if the call failed.
	void GetPenInfo(FOPenInfo *pInfo);

	// Set Pen info.
	// pInfo -- pen info object pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Information, Sets a specify value to current class CFOPenObject
	// Parameters:
	//		&pInfo---&pInfo, Specifies a const FOPenInfo &pInfo object(Value).
	void SetPenInfo(const FOPenInfo &pInfo);

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFOPenObject &target object(Value).
	virtual BOOL operator==(const CFOPenObject &target);

	// Obtain value.
	double GetVal() { return m_PenInfo.GetVal(); }

protected:

	// Pen handle.
 
	// Pen, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen *	m_pPen;

	// Pen information.
 
	// Pen Information, This member specify FOPenInfo object.  
	FOPenInfo m_PenInfo;

};

//////////////////////////////////////////////////////////////////////
// CFOPenCache is class derived CFOBasePenDataList,it is used for pen cache. 
//
typedef CFOSmartPtr<CFOPenObject> CFOPenObjData;
typedef CList<CFOPenObjData,CFOPenObjData> CFOBasePenDataList;
typedef CMap<double, double, CFOPenObject *,CFOPenObject *> CFOMapPen;
typedef CMap<int, int, CString ,CString &> CFOPBaseNameCache;
typedef CMap<int, int, CString ,CString &> CFOPBaseCaptionCache;
typedef CMap<int, int, int , int> CFOPMaxShapeIndex;
typedef CMap<int, int, FO_VALUE , FO_VALUE> CFOPDefValues;

//===========================================================================
// Summary:
//     The CFOPenCache class derived from CFOBasePenDataList
//      F O Pen Cache
//===========================================================================

class FO_EXT_CLASS CFOPenCache : public CFOBasePenDataList
{
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pen Cache, Constructs a CFOPenCache object.
	//		Returns A  value (Object).
	CFOPenCache();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pen Cache, Destructor of class CFOPenCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPenCache();

	// Find image by data.
	// penInfo -- pen info object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Pen, .
	//		Returns A E-XD++ CFOPenObjData value (Object).  
	// Parameters:
	//		&penInfo---&penInfo, Specifies a E-XD++ CFOPenObjData &penInfo object (Value).
	 CFOPenObjData &FindPen( CFOPenObjData &penInfo );
	
	// Remove data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Data, Call this function to remove a specify value from the specify object.

	void RemoveData();

public:
	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPenCache,or NULL if the call failed
	static CFOPenCache* GetInstance();

	// Destroy instance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.
	// This member function is a static function.
	static void DestroyInstance();

	// Refresh data.
	void RefreshData();

	// Map pens.
	CFOMapPen m_mapPens;

protected:
	
	// A pointer to the one instance of the pen cache. 
 
	// Pen Cache, This member maintains a pointer to the object CFOPenCache.  
	static CFOPenCache* m_psPenCache;
};

//////////////////////////////////////////////////////////////////////
// FOBrushInfo a struct defined for brush information.
//

 
//===========================================================================
// Summary:
//      To use a FOBrushInfo object, just call the constructor.
//      O Brush Information
//===========================================================================

class FO_EXT_CLASS FOBrushInfo
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Brush Information, Constructs a FOBrushInfo object.
	//		Returns A  value (Object).
	FOBrushInfo();
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Information, Destructor of class FOBrushInfo
	//		Returns A  value (Object).
	~FOBrushInfo() {};

	// Obtain double value.
	double GetVal();

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// Brush color.
 
	// Fill, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crFill;
};

//////////////////////////////////////////////////////////////////////
// CFOBrushObject a alone class defined for brush pointer and other information.
//

 
//===========================================================================
// Summary:
//     The CFOBrushObject class derived from FOIUnknown
//      F O Brush Object
//===========================================================================

class FO_EXT_CLASS CFOBrushObject : public FOIUnknown
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBrushObject---F O Brush Object, Specifies a E-XD++ CFOBrushObject object (Value).
	DECLARE_SERIAL(CFOBrushObject)
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Object, Constructs a CFOBrushObject object.
	//		Returns A  value (Object).
	CFOBrushObject();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Brush Object, Destructor of class CFOBrushObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBrushObject();

	// Get brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetBrush();

	// Create brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOBrushObject object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CBrush,or NULL if the call failed
	CBrush* CreateBrush();

	// Get brush info.
	// pInfo -- pointer of the brush info object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Information, Returns the specified value.
	// Parameters:
	//		*pInfo---*pInfo, A pointer to the FOBrushInfo  or NULL if the call failed.
	void GetBrushInfo(FOBrushInfo *pInfo);

	// Set brush info.
	// pInfo -- pointer of the brush info object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Information, Sets a specify value to current class CFOBrushObject
	// Parameters:
	//		&pInfo---&pInfo, Specifies a const FOBrushInfo &pInfo object(Value).
	void SetBrushInfo(const FOBrushInfo &pInfo);

	// Get bitmap point.
	// nIndex -- index of the brush pattern,it should be within 0 - 40
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFOBrushObject &target object(Value).
	virtual BOOL operator==(const CFOBrushObject &target);

	// Obtain value.
	double GetVal() { return m_BrushInfo.GetVal(); }

protected:

	// Brush handle.
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush *	m_pBrush;

	// Brush information.
 
	// Brush Information, This member specify FOBrushInfo object.  
	FOBrushInfo m_BrushInfo;

};

//////////////////////////////////////////////////////////////////////
// CFOBrushCache a class derived from CFOBaseBrushDataList,it is used for brush cache.
//
typedef CFOSmartPtr<CFOBrushObject> CFOBrushObjectData;

typedef CList<CFOBrushObjectData, CFOBrushObjectData> CFOBaseBrushDataList;
typedef CMap<double, double, CFOBrushObject *,CFOBrushObject *> CFOMapBrush;
 
//===========================================================================
// Summary:
//     The CFOBrushCache class derived from CFOBaseBrushDataList
//      F O Brush Cache
//===========================================================================

class FO_EXT_CLASS CFOBrushCache : public CFOBaseBrushDataList
{
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Cache, Constructs a CFOBrushCache object.
	//		Returns A  value (Object).
	CFOBrushCache();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Brush Cache, Destructor of class CFOBrushCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBrushCache();

	// Find image by data.
	// brInfo -- brush info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Brush, .
	//		Returns A E-XD++ CFOBrushObjectData value (Object).  
	// Parameters:
	//		&brInfo---&brInfo, Specifies a E-XD++ CFOBrushObjectData &brInfo object (Value).
	 CFOBrushObjectData &FindBrush( CFOBrushObjectData &brInfo );
	
	// Remove data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Data, Call this function to remove a specify value from the specify object.

	void RemoveData();

	// Refresh data.
	void RefreshData();

public:
	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOBrushCache,or NULL if the call failed
	static CFOBrushCache* GetInstance();

	// Destroy instance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.
	// This member function is a static function.
	static void DestroyInstance();

	// Map pens.
	CFOMapBrush		m_mapBrushs;

protected:
	
	// A pointer to the one instance of the pen cache. 
 
	// Brush Cache, This member maintains a pointer to the object CFOBrushCache.  
	static CFOBrushCache* m_psBrushCache;
};

//////////////////////////////////////////////////////////////////////////
// FO_GLOBAL -- class Global methods or params for use by all classes.
//			To change any value, please call:
//			gfxData.   ...
//////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FO_GLOBAL object, just call the constructor.
//      O_ G L O B A L
//===========================================================================

class FO_EXT_CLASS FO_GLOBAL
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O_ G L O B A L, Constructs a FO_GLOBAL object.
	//		Returns A  value (Object).
	FO_GLOBAL();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O_ G L O B A L, Destructor of class FO_GLOBAL
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FO_GLOBAL();

public:
	BOOL	m_bPrintM;
	// Basic Button colors.
	
	CArray <FOPSimplePolygon *, FOPSimplePolygon *> mptTemp;

	// Button Face, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnFace;
 
	// Button Hilite, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnHilite;
 
	// Button Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnShadow;
 
	// Button Text, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnText;
 
	// Button Dk Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnDkShadow;
 
	// Btn3d Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtn3dShadow;
 
	// Btn3d Hi Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtn3dHiLight;
 
	// Button Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBtnLight;
 
	// Face, This member sets A 32-bit value used as a color value.  
	COLORREF	m_cr3dFace;

	// Caption color.
 
	// Ac Caption, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crAcCaption;
 
	// In Ac Caption, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crInAcCaption;
 
	// In Ac Caption Text, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crInAcCaptionText;

	// Desktop color.
 
	// Desktop, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crDesktop;
 
	// Work Space, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crWorkSpace;

	// Toolbar and menu fonts:
 
	// Regular, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontRegular;
 
	// Vertical, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontVert;
 
	// Bold, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontBold;
 
	// Small, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontSmall;

	// Large font.
	CFont		fontLarge;
 
	// Status Bar, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontStatusBar;
 
	// Tab Order, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		fontTabOrder;

	// Window color.
 
	// Window Frame, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crWindowFrame;

	// Window text color.
 
	// Hi lite, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crHilite;
 
	// Window Text, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crWindowText;

	COLORREF m_dwszGrayScalePalette[256];
	// Text color.
 
	// Text Grayed, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTextGrayed;
 
	// Text Hi lite, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTextHilite;
 
	// Text Hot, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTextHot;

	// xp menu item back color.
 
	// X P Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crXPBackColor;

	// xp menu item select back color.
 
	// X P Select Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crXPSelectBackColor;

	// Ruler mark color.
	COLORREF	m_crRulerMarkColor;

	// xp toolbar item back color.
 
	// X P Button Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crXPBtnColor;

	// Xp menu light
 
	// X P Menu Item Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crXPMenuItemLight;

	// XP High light.
 
	// X P Highlight, This member sets A 32-bit value used as a color value.  
	COLORREF	m_clrXPHighlight;

	// XP high light dn
 
	// X P Highlight Dn, This member sets A 32-bit value used as a color value.  
	COLORREF	m_clrXPHighlightDn;

	// XP Check button
 
	// X P Highlight Checked, This member sets A 32-bit value used as a color value.  
	COLORREF	m_clrXPHighlightChecked;

	// Draw xp gradient dark color
 
	// X P Gradient Dark, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPGradientDark;
 
	// X P Gradient Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPGradientLight;
 
	// X P Gradient Very Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPGradientVeryLight;
 
	// X P Gradient Tool Box Dark, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPGradientToolBoxDark;

	// Border back color
 
	// X P Border Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPBorderBack;
 
	// X P More Dark, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPMoreDark;
 
	// X P Very Dark, This member sets A 32-bit value used as a color value.  
	COLORREF	m_XPVeryDark;

	// Is win ce mode.
	BOOL		m_bIsCEMode;

	// Logical pixels
 
	// Logical Pixels Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLogPixelsY;

	// Logical pixels
 
	// Logical Pixels X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLogPixelsX;

	// Size of window edge.
 
	// Edge, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxEdge;
 
	// Edge, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cyEdge;

	// Border width of window
 
	// Border, This variable specifies a 32-bit signed integer on 32-bit platforms.  OOL
	int			m_cxBorder;

	// Screen size.
	// Width of desktop screen
 
	// Screen, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxScreen;

	// Height of desktop screen
 
	// Screen, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cyScreen;

	// Vertical Scroll bar width size.
 
	// V Scroll, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxVScroll;

	// Horizontal scroll bar's thumb size.
 
	// Thumb, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxThumb;

	// Frame size.
	// Width of frame
 
	// Frame, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxFrame;

	// Height of frame.
 
	// Frame, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cyFrame;

	// cx small icon size(width).
 
	// Icon, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cxIcon;

	// cy small icon size(height).
 
	// Icon, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_cyIcon;

	// Is bitmap has loaded or not.
 
	// Bitmap Initial, This member sets TRUE if it is right.  
	BOOL		m_bBitmapInit;

	// Array of bitmap resources.
 
	// The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap		bitmap[30];

	// Windows version.
 
	// Os Ver, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strOsVer;

	// Version data.
 
	// Ver Data, This member specify OSVERSIONINFO object.  
	OSVERSIONINFO m_osVerData;
	
	// old Win32s
 
	// Is Win32s, This member sets TRUE if it is right.  
	BOOL		m_bIsWin32s;
	
	// any Windows 9x
 
	// Is Win9x, This member sets TRUE if it is right.  
	BOOL		m_bIsWin9x;
	
	// Windows 95.
 
	// Is Win95, This member sets TRUE if it is right.  
	BOOL		m_bIsWin95;

	// exactly Windows 98
 
	// Is Win98, This member sets TRUE if it is right.  
	BOOL		m_bIsWin98;

	// Windows 98 or later
 
	// Is Win98or Later, This member sets TRUE if it is right.  
	BOOL		m_bIsWin98orLater;

	// Is current operate system Microsoft(TM) NT V4.0.
 
	// Is Win N T, This member sets TRUE if it is right.  
	BOOL		m_bIsWinNT;
			
	// Windows NT 4
 
	// Is Win N T4, This member sets TRUE if it is right.  
	BOOL		m_bIsWinNT4;
	
	// exactly Windows 2000
 
	// Is Win2000, This member sets TRUE if it is right.  
	BOOL		m_bIsWin2000;

	// exactly Windows XP
 
	// Is Win X P, This member sets TRUE if it is right.  
	BOOL		m_bIsWinXP;

	// With GDI drawing text.
	BOOL		m_bWithGDIPlusText;

	// exactly window vista.
	BOOL	m_bUseSystemFont;	// Use system font for menu/toolbar/ribbons

	// Is Vista, This member sets TRUE if it is right.  
	BOOL		m_bIsVista;

	// Is windows 7
	BOOL		m_bIsWindows7;

	// Is windows 8
	BOOL		m_bIsWindows8;

	// Expand edit box from center when editing.
 
	// Expand Edit Box Center, This member sets TRUE if it is right.  
	BOOL		m_bExpandEditBoxCenter;

	// Is current palette is 8 bits.
 
	// Bits Per Pixel, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nBitsPerPixel;

	// Default dimension header size.
 
	// Dimension Header, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDimHeader;

	// Avoid no activate title bar
 
	// Need Nc Activate, This member sets TRUE if it is right.  
	BOOL		m_bNeedNcActivate;

	// Is current application with xp style.
 
	// X P Mode, This member sets TRUE if it is right.  
	BOOL		m_bXPMode;

	// System palette.
 
	// System Palette, This member specify CPalette object.  
	CPalette	m_SystemPalette;

	// With multiple records print support.
	BOOL	   m_bfoMultiPrintSupport;

	// Brush state.
 
	// Brush State, This member specify FO_BRUSH_STATE object.  
	FO_BRUSH_STATE m_BrushState;

	// Color palette bar background bitmap.
 
	// Color Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap		m_ColorBitmap;

	// Image List
 
	// This member is a collection of same-sized images.  
	CImageList  m_image;

	// current lock/unlock image list.
 
	// Layer Name, This member is a collection of same-sized images.  
	CImageList m_imgLayerName;

	// Default ruler size.
	int nfoDefaultRulerSize;

	// Color of ruler.
	COLORREF m_crDefRulerColor1;

	// Color of ruler.
	COLORREF m_crDefRulerColor2;

//	CFOOleDropTargetEx	m_DropTarget;
	// End arrow image list.
 
	// End, This member is a collection of same-sized images.  
	CImageList	m_imageEnd;

	//Image List of shadow toolbar.
 
	// Shadow Image, This member is a collection of same-sized images.  
	CImageList  m_ShadowImage;

	//Image List of shape
 
	// Shape, This member is a collection of same-sized images.  
	CImageList  m_imageShape;

	// cx,cy border.
	int cxBorder2, cyBorder2;

	// Default link hit size.
	int		m_nDefLinkHitSize;

	// bWin4.
 
	// Win4, This member sets TRUE if it is right.  
	BOOL		bWin4;

	// Arrow cursor's handle.
 
	// Arrow, This member specify HCURSOR object.  
	HCURSOR		m_hcurArrow;

	// Horizontal split cursor.
 
	// H Split, This member specify HCURSOR object.  
	HCURSOR		m_hcurHSplit;

	// Vertical split cursor
 
	// V Split, This member specify HCURSOR object.  
	HCURSOR		m_hcurVSplit;

	// Horizontal fill brush.
 
	// Horizontal, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brHorz;

	// Vertical fill brush
 
	// Vertical, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brVert;

	// Solid fill brush.
 
	// Black Fill, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
//	CBrush		m_brBlackFill;

	// brush light.
 
	// Brush Light, This member specify HBRUSH object.  
	HBRUSH		m_hBrushLight;

	// brush shadow
 
	// Brush Shadow, This member specify HBRUSH object.  
	HBRUSH		m_hBrushShadow;

	// Track pen.
 
	// Track, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penTrack;

	// Main shape border pen.
 
	// Main, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penMain;

	// Second main shape border pen.
 
	// Second, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penSecond;

	// Track select line pen.
 
	// Track Select Line, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penTrackSelectLine;

	// Ruler track color.
 
	// Ruler Track, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crRulerTrack;

	// Visio - like style mode.
 
	// Microsoft Visio style Mode, This member sets TRUE if it is right.  
	BOOL		m_bVisioMode;

	// combo box Control class name.
 
	// Combo  Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		strComboCtrlName;

	// Toolbox string, default text
 
	// Tool Box Prompt, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strToolBoxPrompt;

	// Toolbox item's caption, default text.
 
	// Tool Box Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strToolBoxCaption;

	// Color of template item background.
	COLORREF m_crModelItemBack;

	// Ruler mark type.
 
	// Ruler Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_RulerType;

	// Continue drawing or not.
 
	// Continue Drawing, This member sets TRUE if it is right.  
	BOOL		m_bContinueDrawing;

	// Need around center link or not.
 
	// Around Center Link, This member sets TRUE if it is right.  
	BOOL		m_bAroundCenterLink;

	// Enable composite shape drawing simple track line around the shape when the shape moving.
 
	// Enable Simple Track, This member sets TRUE if it is right.  
	BOOL		m_bEnableSimpleTrack;

	// If you want make your application based on inch,not based on pixels,please change the following value to TRUE.
 
	// Inch Based, This member sets TRUE if it is right.  
	BOOL		m_bInchBased;

	// With gradient color or not.
 
	// Grident Bar, This member sets TRUE if it is right.  
	BOOL		m_bGridentBar;

	// Show dim label inside or not.
 
	// Show Dimension Label Inside, This member sets TRUE if it is right.  
	BOOL		m_bShowDimLabelInside;

	// With additional items showing support.
 
	// With Additional Showing, This member sets TRUE if it is right.  
	BOOL		m_bWithAddiShowing;

	// Use custom label
 
	// Use Custom Label, This member sets TRUE if it is right.  
	BOOL		m_bUseCustomLabel;

	// With link route
 
	// Use Link Route, This member sets TRUE if it is right.  
	BOOL		m_bUseLinkRoute;

	// Link route from top.
 
	// Route From Top, This member sets TRUE if it is right.  
	BOOL		m_bRouteFromTop;

	// Link route corner size.
 
	// Route Len, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRouteLen;

	// With auto scrolling
 
	// With Automatic Scrolling, This member sets TRUE if it is right.  
	BOOL		m_bWithAutoScrolling;

	// With tool tip show or not.
 
	// With Tool Tip, This member sets TRUE if it is right.  
	BOOL		m_bWithToolTip;

	// With port tracking show.
 
	// Show Port Track Line, This member sets TRUE if it is right.  
	BOOL		m_bShowPortTrackLine;

	// Print border space.
 
	// Print Border Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nPrintBorderSpace;

	// Round corner size of link shape.
	int			nfOutLen;
 
	// Round Core Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRoundCoreSize;

	// Enable full feature of properties of port.
 
	// Full Feature Port, This member sets TRUE if it is right.  
	BOOL		m_bFullFeaturePort;

	// Font height
 
	// Standard Font Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nStandardFontHeight;

	// Default bridge style.
 
	// Default Bridge Style, This member specify FOPBridgeStyle object.  
	FOPBridgeStyle	m_DefBridgeStyle;

	// Link layout outside size, default is 40
 
	// Link Out Side Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLinkOutSideSize;

	// Not use scale all to all sub - graph shape.
 
	// Not Use Scale All, This member sets TRUE if it is right.  
	BOOL		m_bNotUseScaleAll;

	// When editing with basic shape rotating.
 
	// Editing With Rotate, This member sets TRUE if it is right.  
	BOOL		m_bEditingWithRotate;

	// With continue panning mode.
 
	// With Continue Pan, This member sets TRUE if it is right.  
	BOOL		m_bWithContinuePan;

	// Advance pan mode.
 
	// With Advance Pan Mode, This member sets TRUE if it is right.  
	BOOL		m_bWithAdvancePanMode;

	// Enable expand canvas or not.
 
	// Enable Expand Canvas, This member sets TRUE if it is right.  
	BOOL		m_bEnableExpandCanvas;

	// Enable table text editing by click.
	BOOL		m_bEnableTableLabelEditingByClick;

	// Painter modified.
	BOOL		m_bPainterModified;
	
	// Default toolbox item size.
	CSize		fo_DefaultItemSize;

	// With up right mode support.
	BOOL		m_bDefUpRightMode;

	///////////////////////////////
	// For property grid.	
	// Tool tip width.

	// Bitmaps with system colors
 
	// Down Arrow, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap		m_bmpDownArrow;

	// Line width = 1,label border pen.
 
	// High Light Pen, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData m_pHighLightPen;

	// blue pen.
 
	// Blue, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData	m_penBlue;

	// Default template file folder.
	CString			m_strDefTemplatePath;

	// blue pen.
 
	// Black, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData	m_penBlack;

	// With this param to disable all the snap features.
 
	// With Snap, This member sets TRUE if it is right.  
	BOOL			m_bWithSnap;

	// With default predefined property style supported or not.
 
	// With Style, This member sets TRUE if it is right.  
	BOOL			m_bWithStyle;

	// Radio button horizontal space.
 
	// Radio Horiz Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nRadioHorizSpace;

	// Radio button vertical space.
 
	// Radio Vertical Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nRadioVertSpace;

	// Default radio button size.
 
	// Default Radio Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_foDefaultRadioSize;

	// With shadow showing for all shapes.
 
	// Shadow Temp, This member sets TRUE if it is right.  
	BOOL			m_bShadowTemp;

	// With obtain bitmap mode
	BOOL			m_bWithGetBitmp;

	// Hide or show port index.
 
	// With Port Index Show, This member sets TRUE if it is right.  
	BOOL			m_bWithPortIndexShow;

	// With automatic generated index.
	BOOL			m_bWithAutoIndex;

	// Step length of sign link.
 
	// Sign Link Step Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSignLinkStepLength;

	// Default glue line color.
	COLORREF		m_crDefGlue;

	// Box width of sign mark.
 
	// Sign Link Box Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSignLinkBoxWidth;

	// Box height of sign mark
 
	// Sign Link Box Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSignLinkBoxHeight;

	// With hit children component allowed or not.
 
	// Allow Hit Children, This member sets TRUE if it is right.  
	BOOL			m_bAllowHitChildren;

	// Allow hit children at design time.
	BOOL			m_bAllowHitAtDesign;

	// Allow handle with child value change.
	BOOL			m_bAllowWithChildValueChange;

	// Allow hit geometry detail.
	BOOL			m_bAllFullGeometry;

	// Default property description list.
	CArray<FOP_PROP_DESC,FOP_PROP_DESC> mpDefPropScrip;

	// Stretch cursor.
 
	// Stretch, This member specify HCURSOR object.  
	HCURSOR			m_hcurStretch;
	
	// Stretch vertical cursor.
 
	// Stretch Vertical, This member specify HCURSOR object.  
	HCURSOR			m_hcurStretchVert;

	// Tool tip width.
 
	// Maximize Tool Tip Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMaxToolTipWidth;

	// With panning mode when running - mode.
 
	// With Panning Run Time, This member sets TRUE if it is right.  
	BOOL			m_bWithPanningRunTime;

	// Default data file.
 
	// Default Toolbox File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefToolboxFile;

	// Core color value.
 
	// Core Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crCoreColor;

	// Allow hit border or not.
 
	// Allow Hit Border Only, This member sets TRUE if it is right.  
	BOOL			m_bAllowHitBorderOnly;

	// For composite shape, only allow hitting the label text at top layer.
 
	// Only Allow Hit Top Label, This member sets TRUE if it is right.  
	BOOL			m_bOnlyAllowHitTopLabel;

	// With pin number showing or not.
 
	// With Pin Number Show, This member sets TRUE if it is right.  
	BOOL			m_bWithPinNumberShow;

	// With pin name showing or not.
 
	// With Pin Name Show, This member sets TRUE if it is right.  
	BOOL			m_bWithPinNameShow;

	// With CAD drawing mode.
 
	// With C A D Drawing, This member sets TRUE if it is right.  
	BOOL			m_bWithCADDrawing;

	// Allow tracking center line.
	BOOL			m_bWithTrackCenterLine;

	// Do not update shape index.
	BOOL			m_bNotUpdateIndex;

	// Pick size.
 
	// Default Snap Line Siz Pix, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				fo_DefaultSnapLineSizPix;

	// Line end style. 0 -- RoundCap, 1 -- SquareCap, 2 -- FlatCap
 
	// Line End Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nfoLineEndStyle;

	// Line end join. 0 -- RoundJoin, 1 -- bevel - join, 2 -- miter - join
 
	// Line Join, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nfoLineJoin;

	// With advance port show hide feature.
	BOOL			m_bWithAdvancePortShow;

	
	// With global dc setting.
 
	// Global D C, This member sets TRUE if it is right.  
	BOOL			m_bfoGlobalDC;

	// Composite with no rotate label.
 
	// With Fix Rotate Label, This member sets TRUE if it is right.  
	BOOL			m_bWithFixRotateLabel;

	// Composite label space size.
 
	// Default Component Label Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDefCompLabelSpace;

	// Media file path.
 
	// Default Media Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefMediaPath;

	// With GDI+ plus support or not.
 
	// Default With G D I Plus, This member sets TRUE if it is right.  
	BOOL			m_bDefWithGDIPlus;

	// With label drawing.
 
	// Draw Text, This member sets TRUE if it is right.  
	BOOL			m_bfoDrawText;

	// With OCX drawing mode.
 
	// Ocx Mode, This member sets TRUE if it is right.  
	BOOL			m_bOcxMode;

	// With advance link mode.
	BOOL			m_bDefAdvLinkMode;

	// With old link layout.
	BOOL			m_bOldLinkLayout;

	// Current shape version.
 
	// Default Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDefVersion;

	// Current model version.
 
	// Default Model Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDefModelVersion;

	// Is gis mode.
 
	// Is Gis Mode, This member sets TRUE if it is right.  
	BOOL			m_bIsGisMode;

	// Is hmi mode
	BOOL			m_bIsHMIMode;

	
	// With simple GIS lable drawing.
 
	// Is Simple label, This member sets TRUE if it is right.  
	BOOL			m_bIsSimpleLable;

	// Auto save toolbox index data file or not.
	BOOL			m_bAutoSaveData;

	// Default search property ID
	int				m_nfoDefaultSearchPropID;

	// With composite shapes sharing mode.
	BOOL			m_bWithCacheMode;

	// With share saving move.
	BOOL			m_bWithShareMode;

public:

	/*************************************************************************
	|*
	|* The following value can be initial.
	|*
	\************************************************************************/
	
	// The color that will be showed when selection a shape on the canvas.
 
	// Select Component Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crSelectCompColor;

	// Color of the no selection shape.
 
	// Un Select Component Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crUnSelectCompColor;

	// Size of the selection shapes control handle size.
 
	// Select Component Handle Size, This member sets a CSize value.  
	CSize		szSelectCompHandleSize;

	// Color of the dot line of bezier shape.
 
	// Default Dot Line Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crDefaultDotLineColor;

	// Color of the focus shape.
 
	// Default Focus, This member sets A 32-bit value used as a color value.  
	COLORREF	crDefaultFocus;

	// Color for the help line.
 
	// Default Help Line Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crDefaultHelpLineColor;
	
	// Line width of the help line.
 
	// Default Help Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nDefaultHelpLineWidth;

	// Default snap to shape size.
 
	// Glue To Shape Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nGlueToShapeSize;

	// Default paste offset.
 
	// Default Paste Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		ptDefaultPasteOffset;

	// Default tooltip description.
 
	// Tool Tips, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		strToolTips;

	// Size of the screen.
 
	// Screen Size, This member sets a CSize value.  
	CSize		szScreenSize;

	// Default upright link cross round size.
 
	// Default Round Lenght, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nDefaultRoundLenght;

	// Pointer of the map dc
 
	// Map D C, This member maintains a pointer to the object CDC.  
	CDC			*m_pMapDC;

	// Minimize split size of canvas.
	int			mfoDefaultSplit;

	// Current map mode.
 
	// Current Map Mode, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurMapMode;

	// Show gif animate at design.
 
	// Gif Animate, This member sets TRUE if it is right.  
	BOOL		m_bGifAnimate;

	// With shape script support (SVG Export, using dbname for script saving).
	BOOL		m_bWithSVGScript;

	// Width of the preview item.
 
	// Nav Item Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nNavItemWidth;

	// Width of the preview item.
 
	// Nav Item Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nNavItemHeight;

	// Brush
 
	// Image Face, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brImageFace;

	// Brush
 
	// Image Light, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brImageLight;

	// With high - light selection link mode.
 
	// High Light, This member sets TRUE if it is right.  
	BOOL		m_bHighLight;

	// High light pen color.
 
	// High Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crHighLight;

	//	handle for rich - edit - ctrl
 
	// Module, This member specify HMODULE object.  
	HMODULE		m_hModule;

	// With panning drawing mode.
 
	// With Panning Draw, This member sets TRUE if it is right.  
	BOOL		m_bWithPanningDraw;

	// Flash timer.
	int			m_nFlashTime;

	// Flash count.
	int			m_nDefFlashCount;

	// With lock // 2017
	BOOL		m_bLockUpdateComp;

	// Handle composite's children shapes
	BOOL		m_bHandleCompChildProps;

public:

	// Default port color.
	COLORREF	m_crDefPortColor;

	// Default port height
 
	// Default Port Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefPortHeight;

	// Default port width.
 
	// Default Port Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefPortWidth;

	// Default port type
 
	// Default Port Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefPortType;

	// Default port side
 
	// Default Port Side, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefPortSide;

	// Default port connect type.
 
	// Default Port Connect Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefPortConnectType;

	// Use default port or not.
 
	// Use Default Port, This member sets TRUE if it is right.  
	BOOL		m_bUseDefaultPort;

	// Default color.
	COLORREF	m_crDragBackColor;

	// Only with simple visio feature.
 
	// Simple Microsoft Visio style Draw, This member sets TRUE if it is right.  
	BOOL		m_bSimpleVisioDraw;

	// Only with simple tracking feature.
 
	// Simple Track Line, This member sets TRUE if it is right.  
	BOOL		m_bSimpleTrackLine;

	// Default shape's height.
 
	// Default Shape Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefShapeHeight;

	// Limit shapes with simple moving.
 
	// Limit Shape For Simple Move, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLimitShapeForSimpleMove;

	// List of fonts
 
	// Font Data, This member specify CObList object.  
	CObList		m_lstFontData;

	// Not hit link first.
	BOOL		m_bNotHitLinkFirst;

	// Space of label between composite shape.
 
	// Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nfopSpace;

	// Not used center port mode.
	BOOL		mbfoNotCenterPortMode;

	// Half Space of label between composite shape.
 
	// Half Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nfopHalfSpace;

	// Default skin type.
 
	// Default Skin Type, This member specify FO_GUI_TYPE object.  
	FO_GUI_TYPE m_nDefSkinType;

	// Is axis up or not.
 
	// Is Axis Up, This member sets TRUE if it is right.  
	BOOL		m_bIsAxisUp;
	
	// Enable auto split
	BOOL		m_bfoWithSplit;

	// With matlab mode.
	BOOL		m_bMATLabMode;

	// With sub - graph hit checking.
	BOOL		m_bWithSubGraphHitCheck;

	// Default chart shape axis font size.
 
	// Default Chart Axis Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nDefaultChartAxisPointSize;

	// Default chart shape's main title font size.
 
	// Default Chart Main Title Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nDefaultChartMainTitlePointSize;

	// Default chart shape's sub children title font size.
 
	// Default Chart Child Title Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nDefaultChartSubTitlePointSize;

	// With visio style sizing feature.
 
	// With Microsoft Visio style Resize, This member sets TRUE if it is right.  
	BOOL		m_bWithVisioResize;

	// Track line color.
 
	// Track Line Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTrackLineColor;

	// With help line support or nor.
 
	// Enable Help Line, This member sets TRUE if it is right.  
	BOOL		m_bEnableHelpLine;

	// With single link mode.
 
	// With Single Link, This member sets TRUE if it is right.  
	BOOL		m_bWithSingleLink;

	// Default canvas expand border.
 
	// Default Canvas Expand, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefCanvasExpand;

	// The nearest distance to port.
 
	// Default Nearest Port Dist, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefNearestPortDist;

	// Enable link to link or not.
 
	// Link On Link, This member sets TRUE if it is right.  
	BOOL		m_bfoLinkOnLink;

	// Default link line only arrow type.
 
	// Default Arrow Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultArrowType;

	// Default link shape.
 
	// Default Link Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultLinkType;

	// Default link arrow number 0 -- none, 1-- at end, 2- both showing.
 
	// Default Lnk Arrow Number, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultLnkArrowNumber;

	// Showing or hide the icon on the title bar of toolbox window.
	BOOL		fo_DefToolBoxIcon;

	// With link support.
	BOOL		fo_bWithLinkFeature;

	// Not allowing moving link end.
	BOOL		m_bNotAllowMoveLinkEnd;

public:

	///////////////////////////////////////
	// Default arrow information.

	// Default start arrow type.
 
	// Default Start Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultStartArrow;

	// Default end arrow type.
 
	// Default End Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultEndArrow;

	// Default start arrow length.
 
	// Default Arrow Start Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultArrowStartLength;

	// Default start arrow width.
 
	// Default Arrow Start Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultArrowStartWidth;

	// Default end arrow length.
 
	// Default Arrow End Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultArrowEndLength;

	// Default end arrow width.
 
	// Default Arrow End Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultArrowEndWidth;

	///////////////////////////////////////
	// Default fill information.

	// Default fill color.
 
	// Default Fill Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultFillColor;

	// Default fill pattern color.
 
	// Default Fill Pattern Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultFillPatternColor;

	// Default brush type.
 
	// Default Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultBrushType;

	///////////////////////////////////////////////////////////////////////
	// Default line information.
	
	// Default line color.
 
	// Default Line Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultLineColor;

	// Default line width.
 
	// Default Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultLineWidth;

	// Default line style.
 
	// Default Line Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultLineStyle;

	
	////////////////////////////////////////////////////////////////////////
	// Default shadow information.
	
	// Default shadow color.
 
	// Default Shadow Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultShadowColor;

	// Default shadow pattern color.
 
	// Default Shadow Pattern Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultShadowPatternColor;

	// Default shadow offset x value.
 
	// Default Shadow Offect X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultShadowOffectX;

	// Default shadow offset y value.
 
	// Default Shadow Offect Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefaultShadowOffectY;

	
	///////////////////////////////////////
	// Default font information.

	// Default font's name for all shapes.
 
	// Default Font Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strDefFontName;
	
	// Default font size for all shapes.
 
	// Default Font Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefFontSize;

	// Default font color.
 
	// Default Font Color, This member sets A 32-bit value used as a color value.  
	COLORREF	fo_DefaultFontColor;

	// Default font weight.
 
	// Defalut Font Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			fo_DefalutFontWeight;

	// With specify selected color.
	BOOL		fo_WithSpecifySelectColorMode;

	// Change specify select color.
	void SetSpecifySelectColor(const COLORREF &crNew);

	// Update DPI mode
	BOOL UpdateDPIAware();

	// Instance of user32.dll
	HINSTANCE m_hinstUser32;

	// Specify select color.
	COLORREF	fo_crSpecifyColor;

	// Table with double click editing only.
	BOOL		fo_tableDClickEdit;

	// With svg back mode.
	BOOL		fo_exportsvgback;

	CArray <CObject*, CObject*> m_tabModels;

	// Old property mode
	BOOL		m_bOldPropMode;

public:

	// Determines if MBCS is enabled or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is M B C S Enable, Determines if the given value is correct or exist.
	//		Returns a int type value.
	int IsMBCSEnable() const;

	// Remove all fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Fonts, Call this function to remove a specify value from the specify object.

	void RemoveAllFonts();

	// Refresh cache.
	void FreshCache();

	// Create validate string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Strings, You construct a FO_GLOBAL object in two steps. First call the constructor, then call Create, which creates the object.

	void CreateStrings();

	// Get current screen dimension.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Screen Dimensions, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetScreenDimensions();

	// Load bitmap resource to memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Bitmap, Call InitBitmap after creating a new object.

	void InitBitmap();

	// Load GUI type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial G U I Type, Call InitGUIType after creating a new object.
	// Parameters:
	//		&nSkinType---Skin Type, Specifies a const FO_GUI_TYPE &nSkinType = GUI_STANDARD object(Value).
	void InitGUIType(const FO_GUI_TYPE &nSkinType = GUI_STANDARD);

	// Release bitmap resource from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Bitmap, .

	void ReleaseBitmap();

	// Create validate brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Validate Brush, You construct a FO_GLOBAL object in two steps. First call the constructor, then call Create, which creates the object.

	void CreateValidateBrush();

	// Obtain white brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get White Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetWhiteBrush();

	// Com control version
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Com Ctl Version, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetComCtlVersion();

	// Obtain none client area's metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Non Client Metrics, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ncm---Specifies a NONCLIENTMETRICS& ncm object(Value).
	BOOL GetNonClientMetrics(NONCLIENTMETRICS& ncm);

	// Com control version.
 
	// Com Ctl Version, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwComCtlVersion;

	// Create border pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Border Pen, You construct a FO_GLOBAL object in two steps. First call the constructor, then call Create, which creates the object.

	void CreateBorderPen();

	// Obtain blue pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Blue Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetBluePen();

	// Obtain blue pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Black Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetBlackPen();

	// Update system metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Metrics, Called to notify a view that its document has been modified.

	void OnUpdateMetrics();

	// Update current colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	void OnSysColorChange();

	// Update fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Fonts, Call this member function to update the object.

	void UpdateFonts();

	// Obtain color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		nColor---nColor, Specifies A integer value.
	COLORREF GetColor (int nColor);

	// Get brush pattern bitmap.
	// n -- index of the bitmap within the pattern,it should be within 0-40
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap ,or NULL if the call failed  
	// Parameters:
	//		n---Specifies A integer value.
	CBitmap *GetPatternBitmap(int n);

	// Free source.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Free Source, .

	void FOFreeSource();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all data from memory.
	void Clear();

	// Register all classes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register Classes, Write a specify value to registry.
	// Parameters:
	//		hResource---hResource, Specifies a HINSTANCE hResource object(Value).
	void RegisterClasses(HINSTANCE hResource);

	// Register new window class.
	CString RegisterWndClass (LPCTSTR lpszClassName);

	// Enable continue drawing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Continue Enable Drawing, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsContinueEnableDrawing() const { return m_bContinueDrawing; }

	// Enable around center link or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Around Center Link, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAroundCenterLink() const { return m_bAroundCenterLink; }

	// Free all the objects within the cache buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Free Object Cache, .

	void FreeObjectCache();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Context R T L, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	BOOL IsContextRTL(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Context R T L, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).
	BOOL IsContextRTL(HDC hDC);
public:

	// Convert hue to rgb.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From Hue To R G B, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		m1---Specifies a double m1 object(Value).  
	//		m2---Specifies a double m2 object(Value).  
	//		h---Specifies a double h object(Value).
	static double ConvertFromHueToRGB(double m1, double m2, double h);

	// Convert hue to rgb value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From Hue To R G B, .
	// This member function is a static function.
	//		Returns An 8-bit BYTE integer that is not signed.  
	// Parameters:
	//		rm1---Specifies A float value.  
	//		rm2---Specifies A float value.  
	//		rh---Specifies A float value.
	static BYTE ConvertFromHueToRGB(float rm1, float rm2, float rh);

	// Convert HLS to rgb value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From H L Sto R G B1, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		H---H, Specifies a double H object(Value).  
	//		L---L, Specifies a double L object(Value).  
	//		S---S, Specifies a double S object(Value).
	static COLORREF ConvertFromHLStoRGB1(double H, double L, double S);

	// Convert HLS to rgb value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From H L Sto R G B2, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		H---H, Specifies a double H object(Value).  
	//		L---L, Specifies a double L object(Value).  
	//		S---S, Specifies a double S object(Value).
	static COLORREF ConvertFromHLStoRGB2(double H, double L, double S);

	// Convert RGB to HSL value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From R G Bto H S L, .
	// This member function is a static function.
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.  
	//		*H---*H, A pointer to the double  or NULL if the call failed.  
	//		*S---*S, A pointer to the double  or NULL if the call failed.  
	//		*L---*L, A pointer to the double  or NULL if the call failed.
	static void ConvertFromRGBtoHSL(COLORREF rgb, double *H, double *S, double *L);

	
	// Convert from MYK to RGB
	static COLORREF CMYKtoRGB( double fCyan, double fMagenta, double fYellow, double fKey );

	// Convert RGB to MYK
	static void RGBtoCMYK(const COLORREF &crConvert, double& fCyan, double& fMagenta, double& fYellow, double& fKey );

	// Convert from RGB value to HSV value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From R G B to H S V, .
	// This member function is a static function.
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.  
	//		*H---*H, A pointer to the double  or NULL if the call failed.  
	//		*S---*S, A pointer to the double  or NULL if the call failed.  
	//		*V---*V, A pointer to the double  or NULL if the call failed.
	static void ConvertFromRGBtoHSV(COLORREF rgb, double *H, double *S, double *V);

	// Convert from HSV value to RGB value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From H S V to R G B, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		H---H, Specifies a double H object(Value).  
	//		S---S, Specifies a double S object(Value).  
	//		V---V, Specifies a double V object(Value).
	static COLORREF ConvertFromHSVtoRGB(double H, double S, double V);

	// Pixel alpha.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Alpha Value, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crPixel---crPixel, Specifies A 32-bit COLORREF value used as a color value.  
	//		percent---Specifies A integer value.
	static COLORREF ConvertAlphaValue(COLORREF crPixel, int percent);

	// Pixel alpha.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Alpha Value, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crPixel---crPixel, Specifies A 32-bit COLORREF value used as a color value.  
	//		percentR---percentR, Specifies a double percentR object(Value).  
	//		percentG---percentG, Specifies a double percentG object(Value).  
	//		percentB---percentB, Specifies a double percentB object(Value).
	static COLORREF ConvertAlphaValue(COLORREF crPixel, double percentR, double percentG, double percentB);

	// Pixel alpha.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Alpha Value, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crPixel---crPixel, Specifies A 32-bit COLORREF value used as a color value.  
	//		dsrPixel---dsrPixel, Specifies A 32-bit COLORREF value used as a color value.  
	//		percent---Specifies A integer value.
	static COLORREF ConvertAlphaValue(COLORREF crPixel, COLORREF dsrPixel, int percent);

	// Fix color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fix Color, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		color1---Specifies A 32-bit COLORREF value used as a color value.  
	//		color2---Specifies A 32-bit COLORREF value used as a color value.  
	//		dRatio---dRatio, Specifies a double dRatio = 1. object(Value).  
	//		k1---Specifies A integer value.  
	//		k2---Specifies A integer value.
	static COLORREF FixColor(COLORREF color1, COLORREF color2,double dRatio = 1., int k1 = 1, int k2 = 1);

	
protected:

	// White brush.
 
	// White, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData m_brWhite;

};

/////////////////////////////////////////////////////////////
// CFOTrueImageList

 
//===========================================================================
// Summary:
//     The CFOTrueImageList class derived from CImageList
//      F O True Image List
//===========================================================================

class FO_EXT_CLASS CFOTrueImageList : public CImageList  
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O True Image List, Constructs a CFOTrueImageList object.
	//		Returns A  value (Object).
	CFOTrueImageList();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O True Image List, Destructor of class CFOTrueImageList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTrueImageList();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL CreateTC(UINT nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		colMask---colMask, Specifies A 32-bit COLORREF value used as a color value.
	BOOL CreateTC(UINT nID, COLORREF colMask);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.
	BOOL CreateTC(UINT nID, int cx);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		colMask---colMask, Specifies A 32-bit COLORREF value used as a color value.
	BOOL CreateTC(UINT nID, int cx, COLORREF colMask);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	BOOL CreateTC(UINT nID, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create T C, You construct a CFOTrueImageList object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		colMask---colMask, Specifies A 32-bit COLORREF value used as a color value.
	BOOL CreateTC(UINT nID, int cx, int cy, COLORREF colMask);
};

//////////////////////////////////////////////////////////////////////
// FOFontInfo a struct defined for Font information.
//

 
//===========================================================================
// Summary:
//      To use a FOFontInfo object, just call the constructor.
//      O Font Information
//===========================================================================

class FO_EXT_CLASS FOFontInfo
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Font Information, Constructs a FOFontInfo object.
	//		Returns A  value (Object).
	FOFontInfo();
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Information, Destructor of class FOFontInfo
	//		Returns A  value (Object).
	~FOFontInfo() {};

	// Change font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class FOFontInfo
	// Parameters:
	//		&nPoint---&nPoint, Specifies A integer value.
	void SetPointSize(const int &nPoint);
	
	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;

protected:
	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

};


//////////////////////////////////////////////////////////////////////
// CFOFontObject a alone class defined for Font pointer and other information.
//

 
//===========================================================================
// Summary:
//     The CFOFontObject class derived from FOIUnknown
//      F O Font Object
//===========================================================================

class FO_EXT_CLASS CFOFontObject : public FOIUnknown
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFontObject---F O Font Object, Specifies a E-XD++ CFOFontObject object (Value).
	DECLARE_SERIAL(CFOFontObject)
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Object, Constructs a CFOFontObject object.
	//		Returns A  value (Object).
	CFOFontObject();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Font Object, Destructor of class CFOFontObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontObject();

	// Get Font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont ,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont *GetFont(CDC* pDC);

	// Create Font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOFontObject object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* CreateFont(CDC* pDC);

	// Get Font info.
	// pInfo -- pointer of the Font info object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Information, Returns the specified value.
	// Parameters:
	//		*pInfo---*pInfo, A pointer to the FOFontInfo  or NULL if the call failed.
	void GetFontInfo(FOFontInfo *pInfo);

	// Set Font info.
	// pInfo -- pointer of the Font info object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Information, Sets a specify value to current class CFOFontObject
	// Parameters:
	//		&pInfo---&pInfo, Specifies a const FOFontInfo &pInfo object(Value).
	void SetFontInfo(const FOFontInfo &pInfo);

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFOFontObject &target object(Value).
	virtual BOOL operator==(const CFOFontObject &target);

protected:

	// Font handle.
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont *	m_pFont;

	// Font information.
 
	// Font Information, This member specify FOFontInfo object.  
	FOFontInfo m_FontInfo;

};

//////////////////////////////////////////////////////////////////////
// CFOFontCache a class derived from CFOBaseFontDataList,it is used for Font cache.
//
typedef CFOSmartPtr<CFOFontObject> CFOFontObjectData;

typedef CList<CFOFontObjectData,CFOFontObjectData> CFOBaseFontDataList;
 
//===========================================================================
// Summary:
//     The CFOFontCache class derived from CFOBaseFontDataList
//      F O Font Cache
//===========================================================================

class FO_EXT_CLASS CFOFontCache : public CFOBaseFontDataList
{
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Cache, Constructs a CFOFontCache object.
	//		Returns A  value (Object).
	CFOFontCache();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Font Cache, Destructor of class CFOFontCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontCache();

	// Find image by data.
	// brInfo -- Font info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Font, .
	//		Returns A E-XD++ CFOFontObjectData value (Object).  
	// Parameters:
	//		&brInfo---&brInfo, Specifies a E-XD++ CFOFontObjectData &brInfo object (Value).  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFOFontObjectData &FindFont( CFOFontObjectData &brInfo ,CDC* pDC);
	
	// Remove data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Data, Call this function to remove a specify value from the specify object.

	void RemoveData();

public:
	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOFontCache,or NULL if the call failed
	static CFOFontCache* GetInstance();

	// Destroy instance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.
	// This member function is a static function.
	static void DestroyInstance();

	// Refresh data.
	void RefreshData();

protected:
	
	// A pointer to the one instance of the pen cache. 
 
	// Font Cache, This member maintains a pointer to the object CFOFontCache.  
	static CFOFontCache* m_psFontCache;
};

////////////////////////////////////////////////////////////////
// CFOPropertyItemSet

 
//===========================================================================
// Summary:
//     The CFOPropertyItemSet class derived from FOPContainer
//      F O Property Item Set
//===========================================================================

class FO_EXT_CLASS CFOPropertyItemSet : public FOPContainer
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Item Set, Constructs a CFOPropertyItemSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFOPropertyItemSet(int nInit = 64, int nTotal = 64) : FOPContainer(1024, nInit, nTotal)	{}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property Item Set, Destructor of class CFOPropertyItemSet
	//		Returns A  value (Object).
    ~CFOPropertyItemSet();

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddHead(CObject* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	long AddTail(CObject* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOPropertyItemSet or NULL if the call failed.
	void AddHead(CFOPropertyItemSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOPropertyItemSet or NULL if the call failed.
	void AddTail(CFOPropertyItemSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();
};

//////////////////////////////////////////////////////////////////////
// CFOPPropertyCache a class derived from CFOBaseFontDataList,it is used for Font cache.
//

 
//===========================================================================
// Summary:
//      To use a CFOPPropertyCache object, just call the constructor.
//      F O P Property Cache
//===========================================================================

class FO_EXT_CLASS CFOPPropertyCache
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Property Cache, Constructs a CFOPPropertyCache object.
	//		Returns A  value (Object).
	CFOPPropertyCache();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Property Cache, Destructor of class CFOPPropertyCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPropertyCache();

	// Find property by data.
	// pProp -- property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Property, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A 32-bit long signed integer.
	CFOBaseProperties* FindProperty(const long &nIndex);

	// Find and add the property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find And Add, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	long FindAndAdd(CFOBaseProperties* pProp);

	// Clear all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize.
	void Serialize(CArchive &ar);

	// Clear and clean.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear And Clean, Remove the specify data from the list.

	void ClearAndClean();

	// Get index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index Value, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	int GetIndexValue(const int &nIndex) 
	{ 
		int nSize = m_AllIndex.GetSize();
		if(nIndex >= nSize)
		{
			return -1;
		}
		return m_AllIndex.GetAt(nIndex); 
	}

	// Change index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index Value, Sets a specify value to current class CFOPPropertyCache
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		int&nValue---int&nValue, Specifies A integer value.
	void SetIndexValue(const int &nIndex, const int&nValue) { m_AllIndex.SetAt(nIndex, nValue); }

// Attributes
public:

	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPPropertyCache,or NULL if the call failed
	static CFOPPropertyCache* GetInstance();

	// Change the instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Instance, Sets a specify value to current class CFOPPropertyCache
	// Parameters:
	//		pPropertyCache---Property Cache, A pointer to the CFOPPropertyCache or NULL if the call failed.
	void SetInstance(CFOPPropertyCache* pPropertyCache);


	// Obtain the property set.
	CFOPropertyItemSet *GetPropSet() { return &m_listProperties; }

// Operations
public:

	// Destroy instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.

	void DestroyInstance();

	// Close cache now.
 
	// Use Temp Cache, This member sets TRUE if it is right.  
	BOOL	m_bUseTempCache;

	// Property cache
 
	// Property Cache, This member maintains a pointer to the object CFOPPropertyCache.  
	static CFOPPropertyCache* m_psPropertyCache;

	// list of properties.
 
	// Properties, This member specify E-XD++ CFOPropertyItemSet object.  
	CFOPropertyItemSet m_listProperties;

	// All the index of properties.
	CArray <int, int> m_AllIndex;

	// list of properties.
 
	// Temp, This member specify E-XD++ CFOPropertyItemSet object.  
	CFOPropertyItemSet m_listTemp;
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPPropertyCache inline methods

inline CFOPPropertyCache* CFOPPropertyCache::GetInstance()
{
	return m_psPropertyCache;
}

inline void CFOPPropertyCache::SetInstance(CFOPPropertyCache* pPropertyCache)
{
	m_psPropertyCache = pPropertyCache;
}

//////////////////////////////////////////////////////////////////////
// CFOPPropertyExtCache a class derived from none,it is used for Font cache.
//

 
//===========================================================================
// Summary:
//      To use a CFOPPropertyExtCache object, just call the constructor.
//      F O P Property Extend Cache
//===========================================================================

class FO_EXT_CLASS CFOPPropertyExtCache
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Property Extend Cache, Constructs a CFOPPropertyExtCache object.
	//		Returns A  value (Object).
	CFOPPropertyExtCache();
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Property Extend Cache, Destructor of class CFOPPropertyExtCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPropertyExtCache();
	
	// Find property by data.
	// pProp -- property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Property New, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A 32-bit long signed integer.
	CFOBaseProperties* FindPropertyNew(const long &nIndex);

	// Find property by data.
	// pProp -- property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Or Add, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	CFOBaseProperties* FindOrAdd(CFOBaseProperties* pProp);

	// Find property by data.
	// pProp -- property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Or Add New, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	CFOBaseProperties* FindOrAddNew(CFOBaseProperties* pProp, int& nIndex);

	// Find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Exist, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&nValueType---Value Type, Specifies A integer value.
	BOOL FindExist(const int &nPropID, const int &nValueType);
	
	// Clear all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();

	void ClearLoad();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize.
	void Serialize(CArchive &ar);
	
	// Is modified or not.
	BOOL	m_bModified;

	// Attributes
public:
	
	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPPropertyExtCache,or NULL if the call failed
	static CFOPPropertyExtCache* GetInstance();
	
	// Change the instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Instance, Sets a specify value to current class CFOPPropertyExtCache
	// Parameters:
	//		pPropertyCache---Property Cache, A pointer to the CFOPPropertyExtCache or NULL if the call failed.
	void SetInstance(CFOPPropertyExtCache* pPropertyCache);
	
	// Open property cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Cache, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void EnableCache(BOOL bEnable);

	// Operations
public:
	
	// Destroy instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.

	void DestroyInstance();
	
	// Do not use cache.
 
	// With Cache Open, This member sets TRUE if it is right.  
	BOOL    m_bWithCacheOpen;

public:
	
	// Property cache
 
	// Property Cache, This member maintains a pointer to the object CFOPPropertyExtCache.  
	static CFOPPropertyExtCache* m_psPropertyCache;
	
	// list of properties.
 
	// Properties, This member specify E-XD++ CFOPropertyItemSet object.  
	CFOPropertyItemSet m_listProperties;

	// Properties, This member specify E-XD++ CFOPropertyItemSet object.  
	CFOPropertyItemSet m_listLoad;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPPropertyExtCache inline methods

inline CFOPPropertyExtCache* CFOPPropertyExtCache::GetInstance()
{
	return m_psPropertyCache;
}

inline void CFOPPropertyExtCache::SetInstance(CFOPPropertyExtCache* pPropertyCache)
{
	m_psPropertyCache = pPropertyCache;
}

inline void CFOPPropertyExtCache::EnableCache(BOOL bEnable)
{
	m_bWithCacheOpen = bEnable;
}


//////////////////////////////////////////////////////////////////////
// CFOPCompCache a class derived from none,it is used for Font cache.
//

 
class FO_EXT_CLASS CFOPCompCache
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Comp Cache, Constructs a CFOPCompCache object.
	//		Returns A  value (Object).
	CFOPCompCache();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Comp Cache, Destructor of class CFOPCompCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPCompCache();

	// Find Comp by data.
	// pComp -- Comp object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Comp, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A 32-bit long signed integer.
	CFODrawShape* GetCompAt(const long &nIndex);

	// Find and add the Comp.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find And Add, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.
	long FindAndAdd(CFODrawShape* pComp);

	// Clear all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize.
	void Serialize(CArchive &ar);

	// Clear and clean.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear And Clean, Remove the specify data from the list.

	void ClearAndClean();

	// Get index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index Value, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	int GetIndexValue(const int &nIndex) { return m_AllIndex.GetAt(nIndex); }

	// Change index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index Value, Sets a specify value to current class CFOPCompCache
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		int&nValue---int&nValue, Specifies A integer value.
	void SetIndexValue(const int &nIndex, const int&nValue) { m_AllIndex.SetAt(nIndex, nValue); }

// Attributes
public:

	// Returns a pointer to the one instance of the pen cache. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPCompCache,or NULL if the call failed
	static CFOPCompCache* GetInstance();

	// Change the instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Instance, Sets a specify value to current class CFOPCompCache
	// Parameters:
	//		pCompCache---Comp Cache, A pointer to the CFOPCompCache or NULL if the call failed.
	void SetInstance(CFOPCompCache* pCompCache);

	// Obtain the Comp set.
	CFODrawShapeSet *GetPropSet() { return &m_setComps; }

// Operations
public:

	// Destroy instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.

	void DestroyInstance();

	// Comp cache
 
	// Comp Cache, This member maintains a pointer to the object CFOPCompCache.  
	static CFOPCompCache* m_psCompCache;

	// list of properties.
 
	// Properties, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet m_setComps;

	// All the index of properties.
	CArray <int, int> m_AllIndex;
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPCompCache inline methods

inline CFOPCompCache* CFOPCompCache::GetInstance()
{
	return m_psCompCache;
}

inline void CFOPCompCache::SetInstance(CFOPCompCache* pCompCache)
{
	m_psCompCache = pCompCache;
}

//////////////////////////////////////////////////////////////////////
// CFOPResourceLoader a class define for resource loading.
//

 
//===========================================================================
// Summary:
//      To use a CFOPResourceLoader object, just call the constructor.
//      F O P Resource Loader
//===========================================================================

class FO_EXT_CLASS CFOPResourceLoader  
{
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Resource Loader, Constructs a CFOPResourceLoader object.
	//		Returns A  value (Object).  
	// Parameters:
	//		hInst---hInst, Specifies a HINSTANCE hInst = GetModuleHandle( NULL ) object(Value).
	CFOPResourceLoader( HINSTANCE hInst = GetModuleHandle( NULL ) );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Resource Loader, Destructor of class CFOPResourceLoader
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPResourceLoader();

		// Get data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resource Data, Returns the specified value.
	//		Returns A LPCVOID value (Object).
	LPCVOID GetResData() const { return m_pResData; }

	// Get size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Size, Returns the specified value.
	//		Returns a int type value.
	int GetTotalSize() const { return m_nSize; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		szType---szType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Load from resource id.
	BOOL Load( UINT uID, LPCTSTR szType);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		szName---szName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		szType---szType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Load from resource name.
	BOOL Load( LPCTSTR szName, LPCTSTR szType );

protected:

	// Size
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSize;

	// Load data.
 
	// Resource Data, This member specify LPVOID object.  
	LPVOID		m_pResData;
	
	// Instance
 
	// Inst, This member specify HINSTANCE object.  
	HINSTANCE	m_hInst;
};

//////////////////////////////////////////////////////////////////////
// FOVERSION IO Header that should written to file at first.
//

 
//===========================================================================
// Summary:
//      To use a FOVERSION object, just call the constructor.
//      O V E R S I O N
//===========================================================================

class FO_EXT_CLASS FOVERSION 
{
protected:
	// Major version
 
	// Major Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		 nMajorVersion;

	// Minor version
 
	// Minor Version, This member specify The float keyword designates a 32-bit floating-point number.  
	float	 fMinorVersion;

public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O V E R S I O N, Constructs a FOVERSION object.
	//		Returns A  value (Object).
	FOVERSION();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O V E R S I O N, Constructs a FOVERSION object.
	//		Returns A  value (Object).  
	// Parameters:
	//		val---Specifies a const FOVERSION& val object(Value).
	FOVERSION(const FOVERSION& val);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O V E R S I O N, Destructor of class FOVERSION
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOVERSION() {}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data from file.
	virtual void Serialize(CArchive &ar);

	// Determines if another set of VERSION is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		val---Specifies a const FOVERSION val object(Value).
	BOOL operator==(const FOVERSION &val) const;

	// =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOVERSION& value (Object).  
	// Parameters:
	//		val---Specifies a const FOVERSION& val object(Value).
	virtual FOVERSION& operator=(const FOVERSION& val);

	// Get version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Version, Returns the specified value.
	//		Returns a float value.
	float GetVersion() const { return nMajorVersion + fMinorVersion; }

	// Minor version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minor Version, Returns the specified value.
	//		Returns a float value.
	float GetMinorVersion() const { return fMinorVersion; }

	// Major version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Major Version, Returns the specified value.
	//		Returns a int type value.
	int GetMajorVersion() const { return nMajorVersion; }

	// Change major version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Major Version, Sets a specify value to current class FOVERSION
	// Parameters:
	//		&Version---&Version, Specifies A integer value.
	void SetMajorVersion(const int &Version) { nMajorVersion = Version; }
};

//////////////////////////////////////////////////////////////////////
// CFOEnumPrinters a class define for enum printers.
//

 
//===========================================================================
// Summary:
//      To use a CFOEnumPrinters object, just call the constructor.
//      F O Enum Printers
//===========================================================================

class FO_EXT_CLASS CFOEnumPrinters  
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Enum Printers, Constructs a CFOEnumPrinters object.
	//		Returns A  value (Object).
	CFOEnumPrinters();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Enum Printers, Destructor of class CFOEnumPrinters
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual			~CFOEnumPrinters();

	// returning gathered printer information
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Count, Returns the specified value.
	//		Returns a int type value.
	int				GetPrinterCount() ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		index---Specifies A integer value.
	CString			GetPrinterName(int index) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Location, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		index---Specifies A integer value.
	CString			GetPrinterLocation(int index) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Share Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		index---Specifies A integer value.
	CString			GetPrinterShareName(int index) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Port Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		index---Specifies A integer value.
	CString			GetPrinterPortName(int index) ;

	// enumerating printers on this and remote machines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Local Printers, Call this function to read the specify data from an archive.

	void			ReadLocalPrinters() ;

	// actually changing or configuring the printer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Printer, Sets a specify value to current class CFOEnumPrinters
	//		Returns A Boolean value.  
	// Parameters:
	//		hDevMode---Device Mode, Specifies a HANDLE& hDevMode object(Value).  
	//		hDevNames---Device Names, Specifies a HANDLE& hDevNames object(Value).  
	//		PrinterName---Printer Name, Specifies A CString type value.  
	//		PrinterSpooler---Printer Spooler, Specifies A CString type value.  
	//		PrinterPort---Printer Port, Specifies A CString type value.
	bool			SetNewPrinter(HANDLE& hDevMode, HANDLE& hDevNames, const CString& PrinterName, const CString& PrinterSpooler, const CString& PrinterPort) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Printer, Sets a specify value to current class CFOEnumPrinters
	//		Returns A Boolean value.  
	// Parameters:
	//		hDevMode---Device Mode, Specifies a HANDLE& hDevMode object(Value).  
	//		hDevNames---Device Names, Specifies a HANDLE& hDevNames object(Value).  
	//		index---Specifies A integer value.
	bool			SetNewPrinter(HANDLE& hDevMode, HANDLE& hDevNames, int index) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Orientation, Sets a specify value to current class CFOEnumPrinters
	//		Returns A Boolean value.  
	// Parameters:
	//		&hDevMode---Device Mode, Specifies a HANDLE &hDevMode object(Value).  
	//		mode---Specifies A integer value.
	bool			SetPrintOrientation(HANDLE &hDevMode, int mode) ;

	// saving settings too/from the registry
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Printer Selection, Call this function to save the specify data to a file.
	//		Returns A Boolean value.  
	// Parameters:
	//		&hDevMode---Device Mode, Specifies a HANDLE &hDevMode object(Value).  
	//		hDevNames---Device Names, Specifies a HANDLE& hDevNames object(Value).
	bool			SavePrinterSelection(HANDLE &hDevMode, HANDLE& hDevNames) ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Printer Selection, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&hDevMode---Device Mode, Specifies a HANDLE &hDevMode object(Value).  
	//		hDevNames---Device Names, Specifies a HANDLE& hDevNames object(Value).
	bool			RestorePrinterSelection(HANDLE &hDevMode, HANDLE& hDevNames) ;

	// debug options only
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump Handles, Dumps the contents of your object to a CDumpContext object.
	// Parameters:
	//		hDevMode---Device Mode, Specifies a HANDLE& hDevMode object(Value).  
	//		hDevNames---Device Names, Specifies a HANDLE& hDevNames object(Value).
	void			DumpHandles(HANDLE& hDevMode, HANDLE& hDevNames) ;
#endif

protected:
 
	// Number Printers, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_NumPrinters ;
 
	// Printer Name, This member supports lists of CString objects.  
	CStringList		m_PrinterName ;
 
	// Printer Location, This member supports lists of CString objects.  
	CStringList		m_PrinterLocation ;
 
	// Printer Share Name, This member supports lists of CString objects.  
	CStringList		m_PrinterShareName ;
 
	// Printer Port, This member supports lists of CString objects.  
	CStringList		m_PrinterPort ;
};

//=========================================================================
class FO_EXT_CLASS CFOAutoSave
{
	//=====================================================================
	//== class constants                                                 ==
	//=====================================================================
private:
	static const int M_NID;
	
	//=====================================================================
	//== class variables                                                 ==
	//=====================================================================
	//-- Time in minutes between autosave events
private:
	static int m_nDelay;
	
	//-- Singleton
private:
	static CFOAutoSave* m_pInstance;
	
	//=====================================================================
	//== ctor/dtor/initializing                                          ==
	//=====================================================================
private:
	CFOAutoSave();
public:
	~CFOAutoSave();
	
	//-- C++ does not guarantee a certain sequence in the creating of 
	//-- global objects, that's why the direct call of 
	//-- CRegistry functions in CFOAutoSave ctor raises errors.
	//-- Using GetInstance() creates an CFOAutoSave object only on demand 
private:
	static CFOAutoSave* GetInstance();
	
	//=====================================================================
	//== accessor/mutator                                                ==
	//=====================================================================
	//-- Returns true if the Timer is running.
public:
	static boolean IsEnabled();
	
	//-- Enables/Disables timer events
public:
	static void SetEnabled(boolean bIsEnabled);
	
	//-- Returns the delay in minutes between timer events
public:
	static int GetDelay();
	
	//-- Sets the Timer's delay, the number of minutes between
	//-- successive action events
public:
	static void SetDelay(int nTimeSpan);
	
	//=====================================================================
	//== Timer action                                                    ==
	//=====================================================================
	//-- Starts the Timer, causing it to start sending action events
	//-- to its listener window loop
public:
	static void Start();
	
	//-- Stops the Timer, causing it to stop sending action events
	//-- to its listener window
public:
	static void Stop();
};

//////////////////////////////////////////////////////////////////////

template<class Cont>	void DestroyElements(Cont cont)
{
	Cont::iterator iter;
	for(iter=cont.begin(); iter!=cont.end(); ++iter)
	{
		delete *iter;
	}
}

// For image drawing
typedef struct tagImageDraw
{
	HBITMAP m_hBmpFan;
	HBITMAP m_hBmpFanOld;
	HBITMAP m_hBmpGly;
} FOP_IMAGEDATA;


#ifndef _fottof
  #ifdef _UNICODE
	double AFXAPI _fowtof(LPCTSTR s);
    #define _fottof     _fowtof
  #else
    #define _fottof     atof
  #endif
#endif

#ifndef _fottoi
	#ifdef _UNICODE
		#define _fottoi _wtoi
	#else
		#define _fottoi atoi
	#endif
#endif
	
#ifndef _fottol
#ifdef _UNICODE
#define _fottol _wtol
#else
#define _fottol atol
#endif
#endif

#if (_MSC_VER > 1310) // VS2005
#define FOP_SCANF_S _stscanf_s
#else
#define FOP_SCANF_S _stscanf
#endif

FO_API_DECL void AFX_API FOP_STRNCPY_S(TCHAR* strDestination, const TCHAR* strSource, size_t count);
FO_API_DECL int AFX_API  FOP_SPRINTF_S(TCHAR *buffer, const TCHAR *format, ...);
FO_API_DECL void AFX_API FOP_STRCPY_S(TCHAR* strDestination, const TCHAR* strSource);
FO_API_DECL void AFX_API FOP_ITOW_S(int value, TCHAR* buffer, int radix);
FO_API_DECL void AFX_API FOP_ITOT_S(long value, TCHAR * dest, size_t size, int radix);
FO_API_DECL FILE* AFX_API FOP_FOPEN_S(const TCHAR* szFileName, const TCHAR* szMode);
FO_API_DECL TCHAR* AFX_API FOPSTRTOK_S(TCHAR* strToken, const TCHAR* strDelimit, TCHAR** context);

// This macro is similar to the MFC <f HAS_BASE> macro
// except it calls <mf CObject::IsKindOf> to make sure the pointer
// is of the correct type..
#define HAS_BASE(pObj, class_name) pObj->IsKindOf(RUNTIME_CLASS(class_name))

// Use gfxData to access the data member of FO_GLOBAL
extern FO_EXT_CLASS FO_GLOBAL gfxData;

// Use gfxCache
extern FO_EXT_CLASS CFOPPropertyCache gfxCache;

// Use gfxCache
extern FO_EXT_CLASS CFOPCompCache gfxCompCache;

// Use gfxCache
extern FO_EXT_CLASS CFOPPropertyExtCache gfxExtCache;

// Default property style.
extern FO_EXT_CLASS CFODefStyleData gfxDefStyleData;

// Default base name cache.
extern FO_EXT_CLASS CFOPBaseNameCache gfxDefBaseName;

// Default base name cache.
extern FO_EXT_CLASS CFOPBaseCaptionCache gfxDefBaseTitle;

// Maximize shape index.
extern FO_EXT_CLASS CFOPMaxShapeIndex gfxMaxShapeIndex;

// Default map
extern FO_EXT_CLASS CFOPDefValues gfxDefValues;

// Init bitmap resources.
FO_API_DECL void AFX_API FOInit(CRuntimeClass* pVisualProxy = NULL, const FO_GUI_TYPE &nSkinType = GUI_BLUE);

// Init default property description text.
FO_API_DECL void AFX_API FOInitPropTips();

// Init the ruler bars Unit.
// nType -- it must be one of the following value:
// enum FO_RULER_TYPE
// {
// 	RULER_INCH = 0,				// Show inch ruler mark.
// 	RULER_CM,					// Show cm ruler mark.
// 	RULER_MM					// Show mm ruler mark.
// };
FO_API_DECL void AFX_API FOSetUnitOfRuler(const UINT &nType);

// Init window style.
FO_API_DECL void AFX_API FOEnableXPStyle(const BOOL &bEnable);

// Init window style.
FO_API_DECL void AFX_API FOEnableGradientBar(const BOOL &bEnable);

// Change ruler type.
FO_API_DECL void AFX_API FORulerType(const UINT &nType);

// Get the pointer of active view
FO_API_DECL CView* AFX_API FOGetActiveView();

// Get the pointer of active document.
FO_API_DECL CDocument* AFX_API FOGetActiveDocument();

// Adjust dialog position.
FO_API_DECL void AFX_API FOAdjustDialogPosition(const CPoint& pt,CWnd *pParent,CDialog* pDlg);

// Update pop up menu items.
FO_API_DECL void AFX_API FOUpdatePopupMenu(CCmdTarget* pTarget, CMenu *pMenu);

// Convert string to array.
FO_API_DECL int AFX_API FOStringToStringArray(CString string,CString strSep, CStringArray& strArray);

// Convert string to array.
FO_API_DECL void AFX_API FOInsertShapeText(const int &nType, CString strTitle, CString strName);

// Convert string to array.
FO_API_DECL int AFX_API FOPGetShapeMaxIndex(int nType);

// Obtain default prop value.
FO_API_DECL FO_VALUE AFX_API FOPGetDefValue(int nPropId);

// Convert string array to string.
FO_API_DECL CString& AFX_API FOStringArrayToString(CStringArray& strArray,CString strSep, CString& string);

// Convert bitmap to dib.
FO_API_DECL HANDLE	AFX_API FOBitmapToDIB(HBITMAP hBitmap, HPALETTE hPal);

// Save dib to bitmap file.
FO_API_DECL BOOL	AFX_API FODIB2BmpFile(HANDLE hDIB,LPCTSTR BmpFileName);

// Get fonts of system.
FO_API_DECL BOOL AFX_API FOGetFonts(CStringArray *aFonts);

// Get computer name.
FO_API_DECL CString AFX_API FOGetComputerName();

// Get computer name.
FO_API_DECL CString AFX_API FOPGetBaseName(const int &nType);

// Get computer name.
FO_API_DECL CString AFX_API FOPGetBaseTitle(const int &nType);

// Get computer name.
FO_API_DECL void AFX_API FOPUpdateShapeIndex(const int &nType, int nIndex);

// Message Send
FO_API_DECL BOOL AFX_API FOPMessageSend( UINT message, WPARAM wParam = 0, LPARAM lParam = 0 );

// Get current user name.
FO_API_DECL CString AFX_API FOGetUserName();

// Is title nc activate.
FO_API_DECL BOOL AFX_API FODiscardNcActivate();

// Enable continue drawing or not.
FO_API_DECL void AFX_API FOEnableContinueDraw(const BOOL &bEnable);

// Enable around center link or not.
FO_API_DECL void AFX_API FOEnableAroundCenterLink(const BOOL &bEnable);

// Enable the composite shape to draw simple track around rectangle line or not.
FO_API_DECL void AFX_API FOEnableSimpleCompositeTrackLine(const BOOL &bEnable);

// If you want make your application based on inch,not based on pixels,please change the following value to TRUE.
FO_API_DECL void AFX_API FOEnableInchBased(const BOOL &bEnable);

// Enable gif animate at design mode or not,by default it is disabled.
FO_API_DECL void AFX_API FOEnableGifAnimate(const BOOL &bEnable);

// Delete list object
FO_API_DECL void AFX_API FOPDeleteAllListObjects(CObList& lstObjs);

// Delete all objects within array
FO_API_DECL void AFX_API FOPDeleteAllAryObjects(CObArray& aryObjs);

// Track mouse moving action
FO_API_DECL BOOL AFX_API FOPTrackMouse(LPTRACKMOUSEEVENT pTMouseTrack);

// Enable link route or not.
FO_API_DECL void AFX_API FOPEnableLinkRoute(const BOOL &bEnable);

// Enable link route from top or bottom.
FO_API_DECL void AFX_API FOPEnableRouteTop(const BOOL &bFromTop);

// Enable canvas auto scrolling or not.
FO_API_DECL void AFX_API FOPEnableAutoScrolling(const BOOL &bEnable);

// Enable canvas with tooltip showing or not.
FO_API_DECL void AFX_API FOPEnableToolTip(const BOOL &bEnable);

// Enable full feature of properties of port.
FO_API_DECL void AFX_API FOEnablePortFullProp(const BOOL &bEnable);

// Enable default style or not, by default, it uses the default style.
FO_API_DECL void AFX_API FOEnableDefStyle(const BOOL &bEnable);

// Change the default style type.
FO_API_DECL void FOSetDefaultStyle(const CString &strOption);

// Change the default style type.
FO_API_DECL void FOSetDefaultStyle2(const int &nOptionIndex);

// Enable snap feature or not, if bEnable is FALSE, it will disable all the snap feature.
FO_API_DECL void AFX_API FOEnableSnap(const BOOL &bEnable);

// Show about dialog.
FO_API_DECL void AFX_API FOPShowAboutDlg(LPCTSTR lpszAppName);

// Show about dialog.
FO_API_DECL void AFX_API FOPShowAboutDlg(UINT uiAppNameResID);

// Enable simple visio draw feature.
FO_API_DECL void AFX_API FOEnableSimpleVisioDraw(const BOOL &bEnable);

// Enable simple track line feature, if bEnable is TRUE, it will runs more quickly.
FO_API_DECL void AFX_API FOEnableSimpleTrackLine(const BOOL &bEnable);

// Enable port show feature or not.
FO_API_DECL void AFX_API FOEnablePortShow(const BOOL &bEnable);

// Enable link on link or not.
FO_API_DECL void AFX_API FOEnableLinkOnLink(const BOOL &bEnable);

// Enable single link between two ports or not.
FO_API_DECL void AFX_API FOEnableSingleLink(const BOOL &bEnable);

// Change the distance nearest port.
FO_API_DECL void AFX_API FOSetPortNearDist(const int &nDist);

// Change the space size of canvas.
FO_API_DECL void AFX_API FOSetCanvasExpand(const int &nSpace);

// Change the default font size.
FO_API_DECL void AFX_API FOSetDefaultFontSize(const int &nFont);

// Change the default shape size, width = size * 2.
FO_API_DECL void AFX_API FOSetDefaultShapeSize(const int &nSize);

// Change the default arrow type.
FO_API_DECL void AFX_API FOSetDefaultArrowType(const int &nArrow);

// Change the default media file path.
FO_API_DECL void AFX_API FOSetMediaPath(const CString &strPath);

// Change the default font face name.
FO_API_DECL void AFX_API FOSetDefaultFontFaceName(const CString &strFontName);

// Reset shape index data.
FO_API_DECL void AFX_API FOResetShapeIndex();

// Reset shape index data.
FO_API_DECL void AFX_API FOGenCacheShapes(CFODrawShapeSet *pCompSet);

#endif // !defined(AFX_FOGLOBALS_H__2EEABBE7_F19E_11DD_A432_525400EA266C__INCLUDED_)
