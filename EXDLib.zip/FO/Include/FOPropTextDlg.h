//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPropTextDlg.h: interface for the CFOPropTextDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPROPTEXTDLG_H__25CFE444_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
#define AFX_FOPROPTEXTDLG_H__25CFE444_E30F_11D5_A4B4_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFOPropTextDlg dialog
#include "FOGlobals.h"
#include "FOPDropDownColorPickerButton.h"
#include "FOFontNameCombo.h"
#include "FOStaticShape.h"
#include "FOImageButton.h"
#include "FOLabelEdit.h"

///////////////////////////////////////////////////////////
// CFOPFontSample control

class CFOPCanvasCore;

 
//===========================================================================
// Summary:
//     The CFOPFontSample class derived from CWnd
//      F O P Font Sample
//===========================================================================

class FO_EXT_CLASS CFOPFontSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Font Sample, Constructs a CFOPFontSample object.
	//		Returns A  value (Object).
	CFOPFontSample();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPFontSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

 
	// Text Shape, This member specify E-XD++ CFOStaticShape object.  
	CFOStaticShape m_TextShape;

 
	// First, This member sets TRUE if it is right.  
	BOOL bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPFontSample)
	//}}AFX_VIRTUAL

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPFontSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////
// CFOPropTextDlg dialog class

 
//===========================================================================
// Summary:
//     The CFOPropTextDlg class derived from CDialog
//      F O Property Text Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropTextDlg : public CDialog
{
// Construction
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Text Dialog, Constructs a CFOPropTextDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropTextDlg(CWnd* pParent = NULL);

	//Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property Text Dialog, Destructor of class CFOPropTextDlg
	//		Returns A  value (Object).
	~CFOPropTextDlg();

 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pCore;

	// Dialog Data
	//{{AFX_DATA(CFOPropTextDlg)
	enum { IDD = IDD_FO_PROP_TEXT };
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
 
	// Flat, This member sets TRUE if it is right.  
	BOOL	m_bFlat;
 
	// Horizontal Alignment, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nHorzAlign;
 
	// Vertical Alignment, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nVertAlign;
 
	// Lock, This member sets TRUE if it is right.  
	BOOL	m_bLock;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strName;
 
	// Visible, This member sets TRUE if it is right.  
	BOOL	m_bVisible;
 
	// Font Face Name, This member specify E-XD++ CFOFontNameCombo object.  
	CFOFontNameCombo m_FontFaceName;
	int		m_nFontArtType;
	// Size, This member specify CComboBox object.  
	CComboBox   m_cbSize;
	//}}AFX_DATA

	int		m_nOldArtType;
	// Sample, This member specify E-XD++ CFOPFontSample object.  
	CFOPFontSample m_wndSample;
	///////////////////////////////////
	// Save data.
 
	// Old Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strOldCaption;
 
	// Old Flat, This member sets TRUE if it is right.  
	BOOL				m_bOldFlat;
 
	// Old Horizontal Alignment, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nOldHorzAlign;
 
	// Old Vertical Alignment, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nOldVertAlign;
 
	// Old Lock, This member sets TRUE if it is right.  
	BOOL				m_bOldLock;
 
	// Old Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strOldName;
 
	// Old Visible, This member sets TRUE if it is right.  
	BOOL				m_bOldVisible;
 
	// Old Multiple Line, This member sets TRUE if it is right.  
	BOOL				m_bOldMultiLine;
 
	// Old Text, This member sets A 32-bit value used as a color value.  
	COLORREF			crOldText;
 
	// Old Font, This member specify FO_FONT object.  
	FO_FONT				m_OldFont;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL				m_bModify;

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	//Button Text Color
 
	// Text Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnTextColor;

	// Multi lines
 
	// Multiple Line, This member sets TRUE if it is right.  
	BOOL				m_bMultiLine;

	// Text color.
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF			crText;

	// font.
 
	// Font, This member specify FO_FONT object.  
	FO_FONT				m_Font;

	// Get font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Information, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFontSet---Font Set, A pointer to the FO_FONT or NULL if the call failed.
	virtual void GetFontInfo(FO_FONT* pFontSet);

	// Set font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Information, Sets a specify value to current class CFOPropTextDlg
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pFontSet---Font Set, A pointer to the FO_FONT  or NULL if the call failed.
	virtual void SetFontInfo(FO_FONT *pFontSet);

	// Init font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Font Size, Call InitFontSize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitFontSize();

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFOPropTextDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropTextDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Multiple Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnMultiLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Style Bold, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontStyleBold();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Style Italic, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontStyleItalic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Style Strikeout, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontStyleStrikeout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Style Underline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontStyleUnderline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Font Name Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoFontNameCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Fontsize Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoFontsizeCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Editchange Fo Fontsize Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditchangeFoFontsizeCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CFOPFontworkDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPFontworkDlg class derived from CDialog
//      F O P Fontwork Dialog
//===========================================================================

class FO_EXT_CLASS CFOPFontworkDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Fontwork Dialog, Constructs a CFOPFontworkDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPFontworkDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPFontworkDlg)
	enum { IDD = IDD_FO_FONTWORK_DLG };
 
	// Size, This member specify CComboBox object.  
	CComboBox	m_cbSize;
 
	// Combo, This member specify CComboBox object.  
	CComboBox	m_cbCombo;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strLabel;
 
	// Bold, This member sets TRUE if it is right.  
	BOOL	m_bBold;
 
	// Italic, This member sets TRUE if it is right.  
	BOOL	m_bItalic;
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nSize;
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Old Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOldLabel;
 
	// Old Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldSize;
 
	// Old Bold, This member sets TRUE if it is right.  
	BOOL m_bOldBold;
 
	// Old Italic, This member sets TRUE if it is right.  
	BOOL m_bOldItalic;
 
	// Old Font Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_sOldFontFaceName;

 
	// Modify, This member sets TRUE if it is right.  
	BOOL m_bModify;
 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pCore;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Font Face Name, .

	void fillFontFaceName();
 
	// Font Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
    CString m_sFontFaceName;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Edit, Call this member function to update the object.

	void UpdateEdit();

 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont *pFont;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPFontworkDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPFontworkDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Bold, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontBold();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Font Face Name, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoFontFaceName();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Font Face Size, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoFontFaceSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Font Italic, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFontItalic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPKeyValueDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPKeyValueDlg class derived from CDialog
//      F O P Key Value Dialog
//===========================================================================

class FO_EXT_CLASS CFOPKeyValueDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Key Value Dialog, Constructs a CFOPKeyValueDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPKeyValueDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPKeyValueDlg)
	enum { IDD = IDD_FO_PROP_KEY };
 
	// Key1, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strKey1;
 
	// Key2, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strKey2;
 
	// I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nID;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strName;
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
 
	// Old Key1, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldKey1;
 
	// Old Key2, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldKey2;
 
	// Old I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nOldID;
 
	// Old Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldName;
 
	// Modify, This member sets TRUE if it is right.  
	BOOL m_bModify;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPKeyValueDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPKeyValueDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////////////////////
// CFOPropListBox window

 
//===========================================================================
// Summary:
//     The CFOPropListBox class derived from CListBox
//      F O Property List Box
//===========================================================================

class FO_EXT_CLASS CFOPropListBox : public CListBox
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPropListBox---F O Property List Box, Specifies a E-XD++ CFOPropListBox object (Value).
	DECLARE_DYNAMIC(CFOPropListBox)
		// Construction
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property List Box, Constructs a CFOPropListBox object.
	//		Returns A  value (Object).
	//  CFOPropListBox constructor 
	CFOPropListBox();
	
	//  CFOPropListBox destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property List Box, Destructor of class CFOPropListBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPropListBox();
	
	// Operations
public:
	
	//  Adds a font to the list box. 
	
public:
	
	
	//  Draws font listbox items. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	
	
	//  Deletes an item from the font listbox. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDELETEITEMSTRUCT lpDIS object(Value).
	virtual void DeleteItem(LPDELETEITEMSTRUCT lpDIS);
	
	
	//  Returns the measurement of a listbox item. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	
	//  Draws a masked bitmap. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Masked Bitmap, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.  
	//		pbmpMask---pbmpMask, A pointer to the CBitmap or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	static void _DrawMaskedBitmap(CDC* pDC, CBitmap* pbmp, CBitmap* pbmpMask,
		int x, int y, int cx, int cy);
	
	//  Generates a sprite mask given a bitmap. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Mask From Bitmap, .
	// This member function is a static function.
	// Parameters:
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.  
	//		pbmpMask---pbmpMask, A pointer to the CBitmap or NULL if the call failed.
	static void _InitMaskFromBitmap(CBitmap* pbmp, CBitmap* pbmpMask);
	
	
protected:
	//{{AFX_MSG(CFOPropListBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:
	
	//  TrueType bitmap (used for listbox item drawing). 
 
	// True Type, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap m_bmpTrueType;
	
	
	//  TrueType bitmap sprite mask. 
 
	// Mask, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap m_bmpMask;
	
	//  TrueType bitmap (used for listbox item drawing). 
 
	// True Type2, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap m_bmpTrueType2;
	
	
	//  TrueType bitmap sprite mask. 
 
	// Mask2, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap m_bmpMask2;
};

 
//===========================================================================
// Summary:
//     The CFOPPropSettingDlg class derived from CDialog
//      F O P Property Setting Dialog
//===========================================================================

class FO_EXT_CLASS CFOPPropSettingDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Property Setting Dialog, Constructs a CFOPPropSettingDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPPropSettingDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPPropSettingDlg)
	enum { IDD = IDD_FO_DIALOG_PROP_SETTING };
 
	// List, This member specify E-XD++ CFOPropListBox object.  
	CFOPropListBox	m_myList;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strName;
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strValue;
 
	// List Workspaces, This member specify CListCtrl object.  
	CListCtrl	m_ctrlListWorkspaces;
 
	// Value, This member specify COleDateTime object.  
	COleDateTime	m_dtValue;
 
	CEdit	m_editFind;
	// Value, This member specify double object.  
	double	m_dValue;
 
	// Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwValue;
 
	// Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fValue;
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;
 
	// Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nValue;
 
	// Value, This member sets TRUE if it is right.  
	BOOL	m_bValue;
 
	// Edit , This member specify E-XD++ CFOExtendEdit object.  
	CFOExtendEdit	m_EditCtrl;
	//}}AFX_DATA
 
	// Image List, This member is a collection of same-sized images.  
	CImageList		m_ImageList;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndColor;
	// Pattern color.
 
	// Value, This member sets A 32-bit value used as a color value.  
	COLORREF m_crValue;

 
	// Save, This member sets A 32-bit value used as a color value.  
	COLORREF m_crSave;
 
	// With User, This member sets TRUE if it is right.  
	BOOL m_bWithUser;

 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *pShape;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Profile, Call this function to read a specified number of bytes from the archive.

	void LoadProfile();
 
	// Modify, This member sets TRUE if it is right.  
	BOOL m_bModify;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct I D, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		&nID---I D, Specifies A integer value.
	CString GetCorrectID(const int &nID);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct I D2, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		&nID---I D, Specifies A integer value.
	CString GetCorrectID2(const int &nID);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPropSettingDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPPropSettingDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Update, This member function is called by the framework to allow your application to handle a Windows message.
	afx_msg void OnChangeFoEditPropFind();
	afx_msg void OnButtonUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Workspacelist, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnClickWorkspacelist(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Id, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropId();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValue();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Edit Property Value Bool, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoEditPropValueBool();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Date, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Double, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDouble();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Dword, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDword();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Float, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueFloat();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Int, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueInt();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Define, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonDefine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change List Predefine, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeListPredefine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Preview, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonPreview();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Sizing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSide---nSide, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnFinishEditLabel(WPARAM wParam, LPARAM lParam);
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	
	//Has it intialize
 
	// Has Initial, This member sets TRUE if it is right.  
	BOOL m_bHasInit;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPUserPropDlg dialog

 
//===========================================================================
// Summary:
//      To use a CFOPAddUserPropInfo object, just call the constructor.
//      F O P Add User Property Information
//===========================================================================

class FO_EXT_CLASS CFOPAddUserPropInfo
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Add User Property Information, Constructs a CFOPAddUserPropInfo object.
	//		Returns A  value (Object).
	CFOPAddUserPropInfo()
	{
		nID = 0;
		strName = _T("");
	}
public:
 
	// I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nID;
 
	// This member specify FO_VALUE object.  
	FO_VALUE value;// Type and Value
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strName;
};

typedef CArray<CFOPAddUserPropInfo*, CFOPAddUserPropInfo*> CFOPAddUserPropInfoArray;

 
//===========================================================================
// Summary:
//     The CFOPUserPropDlg class derived from CDialog
//      F O P User Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOPUserPropDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P User Property Dialog, Constructs a CFOPUserPropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOPUserPropDlg(CFODrawShape *pShape);   // standard constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P User Property Dialog, Destructor of class CFOPUserPropDlg
	//		Returns A  value (Object).
	~CFOPUserPropDlg();   // standard disconstructor
	
public:
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;
 
	// Add Property Information, This member specify E-XD++ CFOPAddUserPropInfoArray object.  
	CFOPAddUserPropInfoArray m_arrAddPropInfo;
	
	// Modified or not.
	BOOL		m_bModified;

	// Dialog Data
	//{{AFX_DATA(CFOPUserPropDlg)
	enum { IDD = IDD_FO_USER_PROP_DLG };
 
	// Type, This member specify CComboBox object.  
	CComboBox	m_ctrlType;
 
	// Property List, This member specify CListCtrl object.  
	CListCtrl	m_ctrlPropList;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strLabel;
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strValue;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strName;
	//}}AFX_DATA

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Id, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nValueType---Value Type, Specifies A integer value.
	int GetUniqueId(int nValueType, int nStart) const;
	
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPUserPropDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPUserPropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fop User Property New, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFopUserPropNew();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fop User Property Delete, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFopUserPropDelete();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Fop User Property List, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnClickFopUserPropList(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fop User Property Value, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFopUserPropValue();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	afx_msg void OnEditchangeFopUserPropType();
	afx_msg void OnChangeFopUserPropName();
	afx_msg void OnSelchangeFopUserPropType();
	afx_msg void OnButtonHelp();
	afx_msg void OnDblclkFopUserPropList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
private:
 
	// Current Select, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nCurSel;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Updata Property List, .

	void UpdataPropList();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Begin Add New, .

	void BeginAddNew();
};

#include <comdef.h>
#include <COMCAT.H>

/////////////////////////////////////////////////////////////////////////////
// CFOPInsertControlDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPInsertControlDlg class derived from CDialog
//      F O P Insert  Dialog
//===========================================================================

class FO_EXT_CLASS CFOPInsertControlDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Insert  Dialog, Constructs a CFOPInsertControlDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPInsertControlDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPInsertControlDlg)
	enum { IDD = IDD_FO_INSERTOBJECT };
 
	// Server Path, This member specify CStatic object.  
	CStatic m_staticServerPath;
 
	// O K, The CButton class provides the functionality of Windows button controls.  
	CButton m_butOK;
 
	// Controls, This member specify CListBox object.  
	CListBox    m_lbControls;
	//}}AFX_DATA
	
 
	// This member specify CLSID object.  
	CLSID m_clsid;
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPInsertControlDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Implementation
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh  List, .

	void RefreshControlList();
	
 
	// Cat Information, This member specify ICatInformationPtr object.  
	ICatInformationPtr m_pCatInfo;
	CArray< CATID, CATID& > m_aImplementedCategories;
	CArray< CATID, CATID& > m_aRequiredCategories;
	CList< CLSID, CLSID& > m_lControls;
	
	// Generated message map functions
	//{{AFX_MSG(CFOPInsertControlDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Controls Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnControlsDblClk();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Controls Select Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnControlsSelChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//===========================================================================
// Summary:
//     The CFOPPropEditDlg class derived from CDialog
//      F O P Property Setting Dialog
//===========================================================================

class FO_EXT_CLASS CFOPPropEditDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Property Setting Dialog, Constructs a CFOPPropEditDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPPropEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPPropEditDlg)
	enum { IDD = IDD_FO_DIALOG_PROP_EDIT };
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strName;
	COleDateTime	m_dtTime;
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strValue;
 
	// List Workspaces, This member specify CListCtrl object.  
	CListCtrl	m_ctrlListWorkspaces;
	CDateTimeCtrl	m_DateCtrl;
	// Value, This member specify double object.  
	double	m_dValue;
 
	// Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwValue;
 
	// Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fValue;
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;
 
	// Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nValue;
 
	// Value, This member sets TRUE if it is right.  
	BOOL	m_bValue;
 
	// Edit , This member specify E-XD++ CFOExtendEdit object.  
	CFOExtendEdit	m_EditCtrl;
	//}}AFX_DATA
 
	// Image List, This member is a collection of same-sized images.  
	CImageList		m_ImageList;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndColor;
	// Pattern color.
 
	// Value, This member sets A 32-bit value used as a color value.  
	COLORREF m_crValue;

 
	// Save, This member sets A 32-bit value used as a color value.  
	COLORREF m_crSave;
 
	// With User, This member sets TRUE if it is right.  
	BOOL m_bWithUser;

 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *pShape;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Profile, Call this function to read a specified number of bytes from the archive.

	void LoadProfile();
 
	// Modify, This member sets TRUE if it is right.  
	BOOL m_bModify;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct I D, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		&nID---I D, Specifies A integer value.
	CString GetCorrectID(const int &nID);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct I D2, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		&nID---I D, Specifies A integer value.
	CString GetCorrectID2(const int &nID);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPropEditDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPPropEditDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Update, This member function is called by the framework to allow your application to handle a Windows message.
	afx_msg void OnChangeFoEditPropFind();
	afx_msg void OnButtonUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Workspacelist, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnClickWorkspacelist(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Id, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropId();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValue();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Edit Property Value Bool, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoEditPropValueBool();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Date, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Double, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDouble();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Dword, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueDword();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Float, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueFloat();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit Property Value Int, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEditPropValueInt();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Define, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonDefine();
	

	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Sizing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSide---nSide, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDatetimechangeFoDatetimeCtrl(NMHDR* pNMHDR, LRESULT* pResult);
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnFinishEditLabel(WPARAM wParam, LPARAM lParam);
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	
	//Has it intialize
 
	// Has Initial, This member sets TRUE if it is right.  
	BOOL m_bHasInit;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPChartStyleDlg dialog

class FO_EXT_CLASS CFOPChartStyleDlg : public CDialog
{
	// Construction
public:
	CFOPChartStyleDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPChartStyleDlg)
	enum { IDD = IDD_FO_INSERTOBJECT };
	int		m_nStyle;
	//}}AFX_DATA
	
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPChartStyleDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPChartStyleDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSelchangeListChart();
	afx_msg void OnDblclkListChart();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//===========================================================================
// Summary:
//     The CFOAddiPropDlg class derived from CDialog
//      F O P User Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOAddiPropDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P User Property Dialog, Constructs a CFOAddiPropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOAddiPropDlg(CFODrawShape *pShape);   // standard constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P User Property Dialog, Destructor of class CFOAddiPropDlg
	//		Returns A  value (Object).
	~CFOAddiPropDlg();   // standard disconstructor
	
public:
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;
 
	// Add Property Information, This member specify E-XD++ CFOPAddUserPropInfoArray object.  
	CFOPAddUserPropInfoArray m_arrAddPropInfo;
	
	// Modified or not.
	BOOL		m_bModified;

	// Dialog Data
	//{{AFX_DATA(CFOAddiPropDlg)
	enum { IDD = IDD_FO_USER_PROP_DLG };
 
	// Type, This member specify CComboBox object.  
	CComboBox	m_ctrlType;
 
	// Property List, This member specify CListCtrl object.  
	CListCtrl	m_ctrlPropList;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strLabel;
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strValue;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strName;
	//}}AFX_DATA

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Id, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nValueType---Value Type, Specifies A integer value.
	int GetUniqueId(int nValueType, int nStart) const;
	
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOAddiPropDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOAddiPropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fop User Property New, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFopUserPropNew();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fop User Property Delete, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFopUserPropDelete();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Fop User Property List, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnClickFopUserPropList(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fop User Property Value, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFopUserPropValue();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	afx_msg void OnEditchangeFopUserPropType();
	afx_msg void OnChangeFopUserPropName();
	afx_msg void OnSelchangeFopUserPropType();
	afx_msg void OnButtonHelp();
	afx_msg void OnDblclkFopUserPropList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
private:
 
	// Current Select, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nCurSel;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Updata Property List, .

	void UpdataPropList();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Begin Add New, .

	void BeginAddNew();
};

#endif // !defined(AFX_FOPROPTEXTDLG_H__25CFE444_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
