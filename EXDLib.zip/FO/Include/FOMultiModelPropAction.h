//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMULTIMODELPROPACTION_H__13E576BD_4FA2_4FB4_A7EB_D0D9C6A5F39B__INCLUDED_)
#define AFC_FOMULTIMODELPROPACTION_H__13E576BD_4FA2_4FB4_A7EB_D0D9C6A5F39B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Description
// Author: ucancode.net Software
///////////////////////////////////////
#include "FOActionMacro.h"
#include "FOModelPropAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOMultiModelPropAction -- action that changed multiple property values one time.

 
//===========================================================================
// Summary:
//     The CFOMultiModelPropAction class derived from CFOActionMacro
//      F O Multiple Model Property Action
//===========================================================================

class FO_EXT_CLASS CFOMultiModelPropAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiModelPropAction---F O Multiple Model Property Action, Specifies a E-XD++ CFOMultiModelPropAction object (Value).
	DECLARE_ACTION(CFOMultiModelPropAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Model Property Action, Constructs a CFOMultiModelPropAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOMultiModelPropAction(CFODataModel* pModel);
	// Attributes

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	// Add value for undo.
	virtual void Add(const FO_VALUE &Value,const int &nPropId);


	// Add bool value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bool, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddBool(const BOOL &bValue,const int &nPropId);

	// Add int value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Int, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddInt(const int &nValue,const int &nPropId);

	// Add uint value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Uint, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddUint(const UINT &nValue,const int &nPropId);

	// Add string value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add String, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddString(const CString &strValue,const int &nPropId);

	// Add float value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Float, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddFloat(const float &fValue,const int &nPropId);

	// Add double value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Double, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddDouble(const double &dValue,const int &nPropId);

	// Add dword value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add D Word, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddDWord(const DWORD &dwValue,const int &nPropId);

	// Add date time value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Date Time, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddDateTime(const COleDateTime &dtValue,const int &nPropId);

	// Add color value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Color, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddColor(const COLORREF &crValue,const int &nPropId);

	// Attributes
protected:

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFC_FOMULTIMODELPROPACTION_H__13E576BD_4FA2_4FB4_A7EB_D0D9C6A5F39B__INCLUDED_)
