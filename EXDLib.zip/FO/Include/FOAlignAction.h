//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOAlignAction.h: interface for the CFOAlignAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOALIGNACTION_H__5D3EDD16_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOALIGNACTION_H__5D3EDD16_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOActionMacro.h"

///////////////////////////////////////////////////////////////////
// Shape Alignment type.
// Define for action CFOAlignAction
///////////////////////////////////////////////////////////////////

enum AlignFlag
{
	NoneAlign,				// Align none state.
	AlignTop,				// Align top.
	AlignMiddle,			// Align horizontal center.
	AlignBottom,			// Align bottom.
	AlignLeft,				// Align left.		
	AlignCenter,			// Align vertical center.
	AlignRight				// Align right.
};

//////////////////////////////////////////////////////////////////////////////////
// CFOAlignAction -- action that align multiple shapes with the main anchor shape.

 
//===========================================================================
// Summary:
//     The CFOAlignAction class derived from CFOActionMacro
//      F O Alignment Action
//===========================================================================

class FO_EXT_CLASS CFOAlignAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAlignAction---F O Alignment Action, Specifies a E-XD++ CFOAlignAction object (Value).
	DECLARE_ACTION(CFOAlignAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Alignment Action, Constructs a CFOAlignAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOAlignAction(CFODataModel* pModel);
	// Attributes

	// The alignment type used to reposition shapes. 
 
	// Alignment, This member specify AlignFlag object.  
	AlignFlag m_nAlignment;

	// Get the main shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMainShape();

	// Set the main shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Shape, Sets a specify value to current class CFOAlignAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetMainShape(CFODrawShape *pShape);

	// Get a pointer of the move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Move Action, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOBaseAction *FindMoveAction(CFODrawShape *pShape);

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:

	// Add a shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObj---*pObj, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShape(CFODrawShape *pObj);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Gets the alignment type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Alignment Type, Returns the specified value.
	// Parameters:
	//		nAlignment---nAlignment, Specifies a AlignFlag& nAlignment object(Value).
	void GetAlignType(AlignFlag& nAlignment) const;

	// Sets the alignment type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment Type, Sets a specify value to current class CFOAlignAction
	// Parameters:
	//		nAlignment---nAlignment, Specifies a AlignFlag nAlignment object(Value).
	void SetAlignType(AlignFlag nAlignment);

	// Attributes
protected:

    // a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

     // a pointer to main shape 
 
	// Main Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*		m_pMainComp;

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

// Gets the alignment type.
_FOLIB_INLINE void CFOAlignAction::GetAlignType(AlignFlag& nAlignment) const
{
	nAlignment = m_nAlignment;
}

// Sets the alignment type.
_FOLIB_INLINE void CFOAlignAction::SetAlignType(AlignFlag nAlignment)
{
	m_nAlignment = nAlignment;
}

#endif // !defined(AFX_FOALIGNACTION_H__5D3EDD16_F259_11DD_A433_525400EA266C__INCLUDED_)
