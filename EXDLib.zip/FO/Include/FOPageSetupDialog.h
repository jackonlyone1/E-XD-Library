//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPAGESETUPDIALOG_H__75E25801_12BF_405D_A752_2E4F2C84FD4A__INCLUDED_)
#define AFX_FOPAGESETUPDIALOG_H__75E25801_12BF_405D_A752_2E4F2C84FD4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPageSetupDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPageSetupDialog dialog

#include "FOScaleUint.h"
#include "FOTabCtrl.h"
#include "FOGlobals.h"
#include "FOImageButton.h"
////////////////////////////////////////////////////////////////////////////////
// Defined for page.

typedef enum _FO_UNIT_TEMP 
{ 
	DIM_IN, 
		DIM_MM, 
		DIM_none 
} FO_UNIT_TEMP;

/////////////////////////////////////////////////////////////////////////////////
// Page size item.

 
//===========================================================================
// Summary:
//      To use a fop_PageSize object, just call the constructor.
//      Page Size
//===========================================================================

class FO_EXT_CLASS fop_PageSize
{
public:
	
	enum FO_PageIndex
	{
		_start_index = 0,
			psA0 = 0, psA1, psA2, psA3, psA4, psA5, psA6, psA7, psA8, psA9, psA10,
			psB0, psB1, psB2, psB3, psB4, psB5, psB6, psB7, psB8, psB9, psB10,
			psC0, psC1, psC2, psC3, psC4, psC5, psC6, psC7, psC8, psC9, psC10,
			psLegal, psFolio, psLetter,
			ps1_3A4, ps1_4A4, ps1_8A4, ps1_4A3, ps1_3A5,
			psEnvelope_DL, psEnvelope_C6_C5, psEnvelope_no10, psEnvelope_6x9,
			psCustom,

			_last_index
	};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Page Size, Constructs a fop_PageSize object.
	//		Returns A  value (Object).
	fop_PageSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Page Size, Constructs a fop_PageSize object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aIndex---aIndex, Specifies a FO_PageIndex aIndex object(Value).
	fop_PageSize(FO_PageIndex aIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Page Size, Constructs a fop_PageSize object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	fop_PageSize(const CString &strName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Page Size, Constructs a fop_PageSize object.
	//		Returns A  value (Object).  
	// Parameters:
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).  
	//		unit---Specifies a FO_UNIT_TEMP unit object(Value).
	fop_PageSize(double width, double height, FO_UNIT_TEMP unit);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Value, .
	//		Returns A Boolean value.  
	// Parameters:
	//		x---Specifies a double x object(Value).  
	//		y---Specifies a double y object(Value).
	bool CorrectValue(double x, double y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class fop_PageSize
	// Parameters:
	//		aIndex---aIndex, Specifies a FO_PageIndex aIndex object(Value).  
	//		unit---Specifies a FO_UNIT_TEMP unit = DIM_none object(Value).
	void SetValue(FO_PageIndex aIndex, FO_UNIT_TEMP unit = DIM_none);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class fop_PageSize
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.  
	//		unit---Specifies a FO_UNIT_TEMP unit = DIM_none object(Value).
	void SetValue(const CString &strName, FO_UNIT_TEMP unit = DIM_none);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class fop_PageSize
	// Parameters:
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).  
	//		unit---Specifies a FO_UNIT_TEMP unit = DIM_none object(Value).
	void SetValue(double width, double height, FO_UNIT_TEMP unit = DIM_none);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Width, .
	//		Returns A double value (Object).  
	// Parameters:
	//		unit---Specifies a FO_UNIT_TEMP unit object(Value).
	double Width(FO_UNIT_TEMP unit) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Height, .
	//		Returns A double value (Object).  
	// Parameters:
	//		unit---Specifies a FO_UNIT_TEMP unit object(Value).
	double Height(FO_UNIT_TEMP unit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		void---void
	inline CString GetPageName (void) const { return m_strPageName; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Name Exist, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		&szPageSizeName---Page Size Name, Specifies A CString type value.
	static bool	IsNameExist(const CString &szPageSizeName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index By Name, Returns the specified value.
	// This member function is a static function.
	//		Returns A FO_PageIndex value (Object).  
	// Parameters:
	//		&name---Specifies A CString type value.
	static FO_PageIndex GetIndexByName(const CString &name);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Name With Index, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		preDef---preDef, Specifies a FO_PageIndex preDef object(Value).
	static const CString GetNameWithIndex(FO_PageIndex preDef);
	
protected:
 
	// Page Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strPageName;
 
	// Width, This member specify double object.  
	double m_dWidth;
 
	// Height, This member specify double object.  
	double m_dHeight;
 
	// This member specify FO_UNIT_TEMP object.  
	FO_UNIT_TEMP m_unit;
};

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOPageSetupDialog class derived from CPageSetupDialog
//      F O Page Setup Dialog
//===========================================================================

class FO_EXT_CLASS CFOPageSetupDialog : public CPageSetupDialog
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPageSetupDialog---F O Page Setup Dialog, Specifies a E-XD++ CFOPageSetupDialog object (Value).
	DECLARE_DYNAMIC(CFOPageSetupDialog)

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Setup Dialog, Constructs a CFOPageSetupDialog object.
	//		Returns A  value (Object).  
	// Parameters:
	//		dwFlags---dwFlags, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	CFOPageSetupDialog(DWORD dwFlags = PSD_MARGINS | PSD_INWININIINTLMEASURE,
		CWnd* pParentWnd = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do O K, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DoOK();
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Custom Paper, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strCustomPaper;
 
	// Save Width, This member specify double object.  
	double dSaveWidth;
 
	// Save Height, This member specify double object.  
	double dSaveHeight;
 
	// Width, This member specify double object.  
	double	m_paperWidth;
 
	// Height, This member specify double object.  
	double	m_paperHeight;
 
	// Need Update, This member sets TRUE if it is right.  
	BOOL bNeedUpdate;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Paper Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		*plist---Specifies A CString type value.
	CString GetUniquePaperName(CStringList *plist) const;
 
	// User Custom Paper, This member sets TRUE if it is right.  
	BOOL bUserCustomPaper;
 
	// Current Paper, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strCurPaper;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;
	// DDX/DDV support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);	
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Page, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	virtual UINT OnDrawPage(CDC* pDC, UINT nMessage, LPRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
protected:
	//{{AFX_MSG(CFOPageSetupDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Edit Paper Height, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusEditPaperHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Edit Paper Width, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusEditPaperWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button Add, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

 
//===========================================================================
// Summary:
//     The CFOPPageSample class derived from CWnd
//      F O P Page Sample
//===========================================================================

class FO_EXT_CLASS CFOPPageSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Page Sample, Constructs a CFOPPageSample object.
	//		Returns A  value (Object).
	CFOPPageSample();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPPageSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);
	
 
	// Print, This member sets TRUE if it is right.  
	BOOL bPrint;
 
	// Vertical, This member sets TRUE if it is right.  
	BOOL bVert;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPageSample)
	//}}AFX_VIRTUAL
	
#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPPageSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPageDefineDlg0 dialog

 
//===========================================================================
// Summary:
//     The CFOPageDefineDlg0 class derived from CDialog
//      F O Page Define Dlg0
//===========================================================================

class FO_EXT_CLASS CFOPageDefineDlg0 : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Define Dlg0, Constructs a CFOPageDefineDlg0 object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPageDefineDlg0(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPageDefineDlg0)
	enum { IDD = IDD_FO_PAGE_DEFINE0 };
 
	// Ori, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOri;
 
	// Print T, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPrintT;
 
	// Draw Grid, This member sets TRUE if it is right.  
	BOOL	m_bDrawGrid;
 
	// Print Scale, This member specify double object.  
	double		m_fPrintScale;
 
	// W, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nW;
 
	// W, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_W;
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	CArray<FO_PaperInfo, FO_PaperInfo> arrayTemp;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do O K, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DoOK();
 
	// Sample, This member specify E-XD++ CFOPPageSample object.  
	CFOPPageSample m_wndSample;
 
	// Paper Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strPaperName;
 
	// Paper Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strPaperOld;
 
	// Old X, This member specify double object.  
	double		m_dOldX;
 
	// Old Y, This member specify double object.  
	double		m_dOldY;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Information, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strPaper---&strPaper, Specifies A CString type value.  
	//		&info---Specifies a FO_PaperInfo &info object(Value).
	BOOL FindInfo(const CString &strPaper, FO_PaperInfo &info);
 
	// Modify, This member sets TRUE if it is right.  
	BOOL bModify;
protected:
	
	// DDX/DDV support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);	
protected:
	//{{AFX_MSG(CFOPageDefineDlg0)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Radio1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRadio1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Radio2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRadio2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Print Radio1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPrintRadio1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Print Radio2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPrintRadio2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Paper Sizes, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoPaperSizes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Define Button, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDefineButton();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPageDefineDlg1 dialog

 
//===========================================================================
// Summary:
//     The CFOPageDefineDlg1 class derived from CDialog
//      F O Page Define Dlg1
//===========================================================================

class FO_EXT_CLASS CFOPageDefineDlg1 : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Define Dlg1, Constructs a CFOPageDefineDlg1 object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPageDefineDlg1(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPageDefineDlg1)
	enum { IDD = IDD_FO_PAGE_DEFINE1 };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	
	
	// Pages list.
 
	// Pages Combo, This member specify CComboBox object.  
	CComboBox	m_PagesCombo;
 
	// Sample, This member specify E-XD++ CFOPPageSample object.  
	CFOPPageSample m_wndSample;
 
	// Check, This member sets TRUE if it is right.  
	BOOL	m_bCheck;
 
	// Cus Horizontal, This member specify double object.  
	double	m_fCusHorz;
 
	// Custom Vertical, This member specify double object.  
	double	m_fCustVert;
 
	// Across Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nAcrossPages;
 
	// Down Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDownPages;
 
	// Fit Page, This member sets TRUE if it is right.  
	BOOL    m_bFitPage;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;
 
	// Unit Of Measure, This member specify CComboBox object.  
	CComboBox	m_cUnitOfMeasure;
 
	// Button Exchange, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton m_ButtonExchange;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Label, Call this member function to update the object.

	void UpdateLabel();
 
	// Modify, This member sets TRUE if it is right.  
	BOOL bModify;
 
	// Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strTitle;
 
	// Unit, This member specify FieldUnit object.  
	FieldUnit	m_nUnit;
 
	// Page Size, This member specify fop_PageSize object.  
	fop_PageSize					m_PageSize;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do O K, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DoOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Sample, Call this member function to update the object.

	void UpdateSample();

protected:
	
	// DDX/DDV support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show , Call this function to show the specify object.
	// Parameters:
	//		&nShowSize---Show Size, Specifies A integer value.  
	//		&nShowPrint---Show Print, Specifies A integer value.
	void ShowControl(const int &nShowSize, const int &nShowPrint);
	// Init combo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialise, Call Initialise after creating a new object.

	void Initialise();
protected:
	//{{AFX_MSG(CFOPageDefineDlg1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Do Before Defined Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangePreDefinedCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Custom Radio, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCustomRadio();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Fitpage Radio, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFitpageRadio();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Unit Of Measure, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeUnitOfMeasure();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Fo Cus Edit Hoz, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusFoCusEditHoz();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Fo Cus Edit Ver, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusFoCusEditVer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Fo Edit Across, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusFoEditAcross();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Killfocus Fo Edit Down, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillfocusFoEditDown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Exchange, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonExchange();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPageDefineDlg2 dialog

 
//===========================================================================
// Summary:
//     The CFOPageDefineDlg2 class derived from CDialog
//      F O Page Define Dlg2
//===========================================================================

class FO_EXT_CLASS CFOPageDefineDlg2 : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Define Dlg2, Constructs a CFOPageDefineDlg2 object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPageDefineDlg2(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPageDefineDlg2)
	enum { IDD = IDD_FO_PAGE_DEFINE2 };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
 
	// Scale1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_dScale1;
 
	// Scale2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_dScale2;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do O K, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DoOK();
 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nType;
 
	// Sample, This member specify E-XD++ CFOPPageSample object.  
	CFOPPageSample m_wndSample;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Defines, Call InitDefines after creating a new object.
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void InitDefines(int nType);
 
	// Modify, This member sets TRUE if it is right.  
	BOOL bModify;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Sample, Call this member function to update the object.

	void UpdateSample();
protected:
	
	// DDX/DDV support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);	
protected:
	//{{AFX_MSG(CFOPageDefineDlg2)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Combo Define, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoComboDefine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fo Combo Type, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFoComboType();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

 
//===========================================================================
// Summary:
//     The CFOPPageSetupMainDlg class derived from CDialog
//      F O P Page Setup Main Dialog
//===========================================================================

class FO_EXT_CLASS CFOPPageSetupMainDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Page Setup Main Dialog, Constructs a CFOPPageSetupMainDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPPageSetupMainDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPPageSetupMainDlg)
	enum { IDD = IDD_FO_PAGE_MAIN };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
 
	// Tab, This member specify E-XD++ CFOTabCtrl object.  
	CFOTabCtrl	m_wndTab;
 
	// Page1, This member specify E-XD++ CFOPageDefineDlg0 object.  
	CFOPageDefineDlg0 m_wndPage1;
 
	// Page2, This member specify E-XD++ CFOPageDefineDlg1 object.  
	CFOPageDefineDlg1 m_wndPage2;
 
	// Page3, This member specify E-XD++ CFOPageDefineDlg2 object.  
	CFOPageDefineDlg2 m_wndPage3;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;
 
	// Ori, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nOri;
 
	// Temp Scale, This member specify double object.  
	double dTempScale;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
 
	// Modify, This member sets TRUE if it is right.  
	BOOL bModify;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPageSetupMainDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPPageSetupMainDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Command, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Tab, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSelectTab(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPAGESETUPDIALOG_H__75E25801_12BF_405D_A752_2E4F2C84FD4A__INCLUDED_)
