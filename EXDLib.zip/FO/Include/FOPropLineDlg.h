//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPropLineDlg.h: interface for the CFOPropLineDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPROPLINEDLG_H__25CFE443_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
#define AFX_FOPROPLINEDLG_H__25CFE443_E30F_11D5_A4B4_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////

  // CFOPropLineDlg dialog
#include "FOPDropDownColorPickerButton.h"
#include "FOPDropDownLineTypeButton.h"
#include "FOPDropDownLineWidthButton.h"
#include "FOPDropDownArrowButton.h"
#include "FOLineShape.h"
#include "FOPExtLineShape.h"
#include "FOImageButton.h"
///////////////////////////////////////////////////////////
// CFOPLineSample control

class CFOPCanvasCore;

 
//===========================================================================
// Summary:
//     The CFOPLineSample class derived from CWnd
//      F O P Line Sample
//===========================================================================

class FO_EXT_CLASS CFOPLineSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Sample, Constructs a CFOPLineSample object.
	//		Returns A  value (Object).
	CFOPLineSample();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPLineSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

 
	// Line Shape, This member specify E-XD++ CFOLineShape object.  
	CFOLineShape m_LineShape;

 
	// First, This member sets TRUE if it is right.  
	BOOL bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPLineSample)
	//}}AFX_VIRTUAL

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPLineSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////
// CFOPropLineDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPropLineDlg class derived from CDialog
//      F O Property Line Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropLineDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Line Dialog, Constructs a CFOPropLineDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropLineDlg(CWnd* pParent = NULL);

	//Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Property Line Dialog, Destructor of class CFOPropLineDlg
	//		Returns A  value (Object).
	~CFOPropLineDlg();

 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pCore;

	// Dialog Data

	//{{AFX_DATA(CFOPropLineDlg)
	enum { IDD = IDD_FO_PROP_LINE };
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndColor;
 
	// Line Type, This member specify FOPDropDownLineTypeButton object.  
	FOPDropDownLineTypeButton	m_wndLineType;
 
	// Line Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineWidth;
 
	// Start Arrow, This member specify FOPDropDownArrowButton object.  
	FOPDropDownArrowButton	m_wndStartArrow;
 
	// End Arrow, This member specify FOPDropDownArrowButton object.  
	FOPDropDownArrowButton	m_wndEndArrow;
 
	// Startspin, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_Startspin;
 
	// Start Arrow Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nStartArrowWidth;
 
	// Endspin, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_Endspin;
 
	// End Arrow Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nEndArrowWidth;

 
	// Startspin Len, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_StartspinLen;
 
	// Start Arrow Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nStartArrowLength;
 
	// Endspin Len, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_EndspinLen;
 
	// End Arrow Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nEndArrowLength;

 
	// Transparent, This member sets TRUE if it is right.  
	BOOL	m_bTransparent;
	//}}AFX_DATA

 
	// Sample, This member specify E-XD++ CFOPLineSample object.  
	CFOPLineSample m_wndSample;

	//Line Color
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF m_crLine;

	//Line Type
 
	// Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineType;

	//Line Width
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineWidth;

	//Start Arrow
 
	// Start Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nStartArrow;

	//EndArrow
 
	// End Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nEndArrow;

	// Is ut Line
 
	// Line, This member sets TRUE if it is right.  
	BOOL bLine;


	// Save value.
	//Line Color
 
	// Old Line, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldLine;

	// Hatch Color
 
	// Old Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldHatch;

	//Line Type
 
	// Old Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineType;

	//Line Width
 
	// Old Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineWidth;

	//Brush Type
 
	// Old Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldBrushType;

	//Start Arrow
 
	// Old Start Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldStartArrow;

	//EndArrow
 
	// Old End Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldEndArrow;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
 
	// Old Start Arrow Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldStartArrowWidth;
 
	// Old End Arrow Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldEndArrowWidth;
 
	// Old Start Arrow Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldStartArrowLength;
 
	// Old End Arrow Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldEndArrowLength;
 
	// Old Transparent, This member sets TRUE if it is right.  
	BOOL	m_bOldTransparent;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;
 
	// Created, This member sets TRUE if it is right.  
	BOOL	m_bCreated;

	// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFOPropLineDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropLineDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Type Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineTypeChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Start Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineStartChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line End Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineEndChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit3, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit3();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit4, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit4();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CFOExtLinePropDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPTableLinePreview class derived from CWnd
//      F O P Table Line Preview
//===========================================================================

class FO_EXT_CLASS CFOPTableLinePreview : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Line Preview, Constructs a CFOPTableLinePreview object.
	//		Returns A  value (Object).
	CFOPTableLinePreview();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableLinePreview object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

 
	// First, This member sets TRUE if it is right.  
	BOOL bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPTableLinePreview)
	//}}AFX_VIRTUAL

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		&nStyle---&nStyle, Specifies A integer value.  
	//		width---Specifies A integer value.  
	//		defaultColor---defaultColor, Specifies A 32-bit COLORREF value used as a color value.
	CPen* GetBorderPen( const int &nStyle, int width, COLORREF defaultColor );

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPTableLinePreview)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////
// CFOPTableLineSetDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPTableLineSetDlg class derived from CDialog
//      F O P Table Line Set Dialog
//===========================================================================

class FO_EXT_CLASS CFOPTableLineSetDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Line Set Dialog, Constructs a CFOPTableLineSetDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPTableLineSetDlg(CWnd* pParent = NULL);

	//Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Line Set Dialog, Destructor of class CFOPTableLineSetDlg
	//		Returns A  value (Object).
	~CFOPTableLineSetDlg();

	// Dialog Data

	//{{AFX_DATA(CFOPTableLineSetDlg)
	enum { IDD = IDD_FO_TABLE_LINEDLG };
 
	// Line Left Type, This member specify FOPDropDownLineTypeButton object.  
	FOPDropDownLineTypeButton	m_wndLineLeftType;
 
	// Line Left Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineLeftWidth;
 
	// Line Top Type, This member specify FOPDropDownLineTypeButton object.  
	FOPDropDownLineTypeButton	m_wndLineTopType;
 
	// Line Top Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineTopWidth;
 
	// Line Right Type, This member specify FOPDropDownLineTypeButton object.  
	FOPDropDownLineTypeButton	m_wndLineRightType;
 
	// Line Right Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineRightWidth;
 
	// Line Bottom Type, This member specify FOPDropDownLineTypeButton object.  
	FOPDropDownLineTypeButton	m_wndLineBottomType;
 
	// Line Bottom Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineBottomWidth;
	//}}AFX_DATA

	BOOL	m_bSlant;
	BOOL	m_bOldSlant;
	// Sample, This member specify E-XD++ CFOPTableLinePreview object.  
	CFOPTableLinePreview m_wndSample;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	//Line Type
 
	// Line Left Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineLeftType;

	//Line Width
 
	// Line Left Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineLeftWidth;

	//Line Type
 
	// Old Line Left Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineLeftType;

	//Line Width
 
	// Old Line Left Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineLeftWidth;

	//Line Type
 
	// Line Top Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineTopType;

	//Line Width
 
	// Line Top Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineTopWidth;

	//Line Type
 
	// Old Line Top Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineTopType;

	//Line Width
 
	// Old Line Top Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineTopWidth;

	//Line Type
 
	// Line Right Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineRightType;

	//Line Width
 
	// Line Right Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineRightWidth;

	//Line Type
 
	// Old Line Right Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineRightType;

	//Line Width
 
	// Old Line Right Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineRightWidth;

	//Line Type
 
	// Line Bottom Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineBottomType;

	//Line Width
 
	// Line Bottom Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineBottomWidth;

	//Line Type
 
	// Old Line Bottom Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineBottomType;

	//Line Width
 
	// Old Line Bottom Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineBottomWidth;


	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;
 
	// Created, This member sets TRUE if it is right.  
	BOOL	m_bCreated;

	// Image file.
	CString strImageFile;
	CString strOldImageFile;

	// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFOPTableLineSetDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPTableLineSetDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	afx_msg void OnButtonImage();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Left Type Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineLeftTypeChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Left Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineLeftWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Top Type Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineTopTypeChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Top Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineTopWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Right Type Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineRightTypeChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Right Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineRightWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Bottom Type Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineBottomTypeChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Bottom Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineBottomWidthChange();
	
	afx_msg void OnFoSlantLine();
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

///////////////////////////////////////////////////////////
// CFOPExtLineSample control

 
//===========================================================================
// Summary:
//     The CFOPExtLineSample class derived from CWnd
//      F O P Extend Line Sample
//===========================================================================

class FO_EXT_CLASS CFOPExtLineSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Extend Line Sample, Constructs a CFOPExtLineSample object.
	//		Returns A  value (Object).
	CFOPExtLineSample();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtLineSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

 
	// Line Shape, This member specify E-XD++ CFOPExtLineShape object.  
	CFOPExtLineShape m_LineShape;

 
	// First, This member sets TRUE if it is right.  
	BOOL bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtLineSample)
	//}}AFX_VIRTUAL

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtLineSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////////////
// CFOExtLinePropDlg

 
//===========================================================================
// Summary:
//     The CFOExtLinePropDlg class derived from CDialog
//      F O Extend Line Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOExtLinePropDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Extend Line Property Dialog, Constructs a CFOExtLinePropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOExtLinePropDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOExtLinePropDlg)
	enum { IDD = IDD_FO_EXTLINE_PROP_DLG };
 
	// Dash Len, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinDashLen;
 
	// Dash, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinDash;
 
	// Dot Len, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinDotLen;
 
	// Dots, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinDots;
 
	// Distance, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_spinDistance;
 
	// Line Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton	m_wndLineWidth;
 
	// Dash, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDash;
 
	// Dash Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDashLength;
 
	// Distance, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDistance;
 
	// Dot Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDotLength;
 
	// Dots, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nDots;
	//}}AFX_DATA

 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pCore;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	//Line Width
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nLineWidth;

	//Line Width
 
	// Old Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldLineWidth;

 
	// Old Dash, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldDash;
 
	// Old Dash Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldDashLength;
 
	// Old Distance, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldDistance;
 
	// Old Dot Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldDotLength;
 
	// Old Dots, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldDots;
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

 
	// Sample, This member specify E-XD++ CFOPExtLineSample object.  
	CFOPExtLineSample m_wndSample;
 
	// Created, This member sets TRUE if it is right.  
	BOOL	m_bCreated;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOExtLinePropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOExtLinePropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Edit Dash, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoEditDash();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Edit Dash Length, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoEditDashLength();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Edit Distance, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoEditDistance();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Edit Dot Length, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoEditDotLength();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Edit Dots, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoEditDots();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();

	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_FOPROPLINEDLG_H__25CFE443_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
