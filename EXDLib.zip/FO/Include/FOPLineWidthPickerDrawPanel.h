//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLINEWIDTHPICKERDRAWPANEL_H__F575F7C7_5A14_4B89_931F_8AA64D01D7AA__INCLUDED_)
#define AFX_FOPLINEWIDTHPICKERDRAWPANEL_H__F575F7C7_5A14_4B89_931F_8AA64D01D7AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLineWidthPickerDrawPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPLineWidthPickerDrawPanel window
#include "FOPDrawControlPanel.h"

const unsigned FOP_MSG__LINEWIDTH_CHANGE	= 1;
const unsigned FOP_MSG__LINEWIDTH_CYCLE		= 2;
const unsigned FOP_MSG__LINEWIDTH_NONE		= 3;
const unsigned FOP_MSG__LINEWIDTH_CUSTOM	= 4;
const unsigned FOP_MSG__LINEWIDTH_CANCEL	= 5;
const unsigned FOP_MSG__LINEWIDTH_BUTTON2	= 6;

// Line width table entry.
struct FOPLineWidthTableEntry 
{
	// line width value.
    int			nLineWidth;

	// line width name.
    LPCTSTR		szName;
};

 
//===========================================================================
// Summary:
//     The FOPLineWidthDrawPanel class derived from FOPDrawControlPanel
//      O P Line Width Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPLineWidthDrawPanel : public FOPDrawControlPanel
{
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Width Draw Panel, Constructs a FOPLineWidthDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
					FOPLineWidthDrawPanel(HasHeaderBar ind = HeaderBarOne, 
						HasButton but = ButtonOne);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Width Draw Panel, Destructor of class FOPLineWidthDrawPanel
	//		Returns A  value (Object).
					~FOPLineWidthDrawPanel();

	// virtual functions called from FOPPickerBaseWnd

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetMainGroupName(int nIndex);

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetExtraGroupName(int nIndex);

	// Draw main group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		enabled---Specifies A Boolean value.
	// Do draw mode
	virtual void	Draw(CDC& DC, const CRect& rect, int nIndex, BOOL  transparent = FALSE, 
		BOOL  focus = FALSE, BOOL  enabled = TRUE);

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup);

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int nIndex, BOOL  IsPopup);

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int nIndex, BOOL  IsPopup);

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int nIndex, BOOL  IsPopup);

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int nIndex, BOOL  IsPopup);

	// Is main group enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL 	IsMainGroupEnabled(int nIndex);

	// Get transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetTransparency()			{	return m_bTransparent;	}

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPLineWidthDrawPanel
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void			SetTransparency(BOOL  bTransparent)		{	m_bTransparent = bTransparent;	}

	// Get pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
	int				GetPenWidth() const 		{		return m_nPenWidth;	}	

	// Set pen width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPLineWidthDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetPenWidth(int nWidth)			{		m_nPenWidth = nWidth;		}


	// assessor functions
	//Get line widths.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Widths, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const int&		GetLineWidths(int nIndex) const	{	return arLineWidths[nIndex].nLineWidth;	}

	// Get line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int				GetLineWidth();

	// Get fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetFillColor() const;

	// Set line width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class FOPLineWidthDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetLineWidth(const int& nWidth);

	// for colors not in the standard set but user-selected, e.g. via "More..."

	// Set headerbar state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPLineWidthDrawPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	void			SetHeaderBarState(HasHeaderBar ind);

	// Set sunken draw mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPLineWidthDrawPanel
	// Parameters:
	//		bSunken---bSunken, Specifies A Boolean value.
	void			SetSunkenMode(BOOL  bSunken);

	// response functions
	// Do when line width change action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Width Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void	DoWellLineWidthChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choose custom line width button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Line Width, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomLineWidth();

	// Do when choose none line width button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Width None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellLineWidthNone();

	// None line width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width None, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.
	static const int	GetLineWidthNone()		{	return (int) 0; }

	// Total number of line width.
	enum { DefaultLineWidthPickers = 9};

protected:

	// Total number of line width.
 
	// Total Pickers, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nTotalPickers;

	// line widths.
 
	// Line Widths, This member maintains a pointer to the object FOPLineWidthTableEntry.  
	FOPLineWidthTableEntry*			arLineWidths;

	// Default line widths.
 
	// Default Line Widths[ Default Line Width Pickers], This member specify FOPLineWidthTableEntry object.  
	static FOPLineWidthTableEntry	DefaultLineWidths[DefaultLineWidthPickers];

	// Transparent.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 							m_bTransparent;

	// Pen width.
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nPenWidth;
};

// DDX
void DDX_LineWidthWell(CDataExchange* pDX, FOPLineWidthDrawPanel& w, int& nWidth);

struct FOPDropLineWidthCallback
{
	// Do when line width change
	virtual void	OnWellLineWidthChange(const int& nWidth) = 0;

	// Do when cancel action.
	virtual void	OnWellCancel() = 0;

	// Do when choose custom line width button action.
	virtual void	OnWellCustomLineWidth() = 0;

	// Do when choose none line width action.
	virtual void	OnWellLineWidthNone() = 0;
};

 
//===========================================================================
// Summary:
//     The FOPDropLineWidthPickerDrawPanel class derived from FOPLineWidthDrawPanel
//      O P Drop Line Width Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPDropLineWidthPickerDrawPanel : public FOPLineWidthDrawPanel
{
protected:
	// Call back
 
	// This member maintains a pointer to the object FOPDropLineWidthCallback.  
	FOPDropLineWidthCallback* Button;
public:
	// response functions
	// Do when line width change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Width Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void DoWellLineWidthChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCancel();

	// Do when choose custom line width button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Line Width, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCustomLineWidth();

	// Do when choose none line width action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Width None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellLineWidthNone();

	// Set call back
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPDropLineWidthPickerDrawPanel
	// Parameters:
	//		button---A pointer to the FOPDropLineWidthCallback or NULL if the call failed.
	void SetButton(FOPDropLineWidthCallback* button)	{	Button = button;	}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Line Width Picker Draw Panel, Constructs a FOPDropLineWidthPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).  
	//		btn---A pointer to the FOPDropLineWidthCallback or NULL if the call failed.
	FOPDropLineWidthPickerDrawPanel(HasHeaderBar ind = HeaderBarOne,
		HasButton but = ButtonOne, FOPDropLineWidthCallback* btn = 0);

};
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLINEWIDTHPICKERDRAWPANEL_H__F575F7C7_5A14_4B89_931F_8AA64D01D7AA__INCLUDED_)
