//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOLAYERCHOOSEDLG_H__DF3025C5_DD08_4FB7_8720_9B1B51618DEF__INCLUDED_)
#define AFX_FOLAYERCHOOSEDLG_H__DF3025C5_DD08_4FB7_8720_9B1B51618DEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOLayerChooseDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOLayerChooseDlg dialog
#include "FOImageButton.h"

class CFODataModel;
class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOLayerChooseDlg class derived from CDialog
//      F O Layer Choose Dialog
//===========================================================================

class FO_EXT_CLASS CFOLayerChooseDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Layer Choose Dialog, Constructs a CFOLayerChooseDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		*pView---*pView, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOLayerChooseDlg(CFODataModel *pModel,CFOPCanvasCore *pView,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOLayerChooseDlg)
	enum { IDD = IDD_FO_LAYERSET_DLG };
 
	// Item List, This member specify CListBox object.  
	CListBox	m_ItemList;
	//}}AFX_DATA

 
	// Page Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strPageName;
 
	// Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strOld;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial List Box, Call InitListBox after creating a new object.
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	void InitListBox(CFODataModel *pModel);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOLayerChooseDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pDataModel;
 
	// View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *m_pView;

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOLayerChooseDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button New, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonNew();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOLAYERCHOOSEDLG_H__DF3025C5_DD08_4FB7_8720_9B1B51618DEF__INCLUDED_)
