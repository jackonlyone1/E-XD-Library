//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTABCTRLOBJECT_H__38B479A5_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
#define AFX_FOTABCTRLOBJECT_H__38B479A5_D0E7_11D6_A665_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTabCtrlObject.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOTabCtrlObject window


 
//===========================================================================
// Summary:
//     The CFOTabCtrlObject class derived from CObject
//      F O Tab  Object
//===========================================================================

class FO_EXT_CLASS CFOTabCtrlObject : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabCtrlObject---F O Tab  Object, Specifies a E-XD++ CFOTabCtrlObject object (Value).
	DECLARE_DYNAMIC(CFOTabCtrlObject);
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab  Object, Constructs a CFOTabCtrlObject object.
	//		Returns A  value (Object).
	CFOTabCtrlObject();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab  Object, Destructor of class CFOTabCtrlObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabCtrlObject();

public:

	// Label of tab.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strLabel;

	// Width and height.
 
	// Width And Height, This member sets a CSize value.  
	CSize m_szWidthAndHeight;

	// Copy of label.
 
	// Label Dup, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strLabelDup;

public:

	// Obtain the tab's label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Label, Returns the specified value.
	//		Returns a CString type value.
	CString GetTabLabel() const				{ return m_strLabel; }

	// Change the tab's label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Label, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetTabLabel(const CString &str)	{ m_strLabel = str; }

	// Obtain the tab label's copy string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Label Dup, Returns the specified value.
	//		Returns a CString type value.
	CString GetTabLabelDup() const			{ return m_strLabelDup; }

	// Change the tab label's copy string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Label Dup, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetTabLabelDup(const CString &str) { m_strLabelDup = str; }
	
	// Get icon handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Icon Handle, Returns the specified value.
	//		Returns A HICON value (Object).
	HICON GetIconHandle() const				{ return m_hIcon; }

	// Change the icon handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Handle, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		&hIcon---&hIcon, Specifies a const HICON &hIcon object(Value).
	void SetIconHandle(const HICON &hIcon)	{ m_hIcon = hIcon; }

	// Get tab position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Position, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTabPosition() const			{ return m_rcPosition; }

	// Change the tab position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Position, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SetTabPosition(const CRect &rc)	{ m_rcPosition = rc; }

	// Obtain the tab's select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const					{ return m_bSelected; }

	// Change the tab's select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		bSelect---bSelect, Specifies A Boolean value.
	void SetSelected(const BOOL bSelect)	{ m_bSelected = bSelect; }

	// Obtain the extra data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Data, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	LONG_PTR GetItemData() const				{ return (LONG_PTR)m_pData; }

	// Change the item data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Data, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		dData---dData, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void SetItemData(const LONG_PTR dData)		{ m_pData = (void*)dData; }

	// Obtain the tab's Menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Handle, Returns the specified value.
	//		Returns A HMENU value (Object).
	HMENU GetMenuHandle() const				{ return m_hMenu; }

	// Change the tab's menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Handle, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		hMenu---hMenu, Specifies a const HMENU hMenu object(Value).
	void SetMenuHandle(const HMENU hMenu)	{ m_hMenu = hMenu; }

	// Obtain the tab's Enable flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Tab Enable, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTabEnable() const				{ return m_bEnabled; }

	// Change the tab's enable flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Enable, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void SetTabEnable(const BOOL bEnable)	{ m_bEnabled = bEnable; }

	// Obtain the tab's tool tip flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Tool Tip, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasToolTip() const					{ return m_bToolTip; }

	// Change the tab's tool tip flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tool Tip, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		bTip---bTip, Specifies A Boolean value.
	void SetToolTip(const BOOL bTip)		{ m_bToolTip = bTip; }

	// Obtain the pointer of the wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *GetWnd() const					{ return m_pWnd; }

	// Change the pointer of the wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window, Sets a specify value to current class CFOTabCtrlObject
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetWnd(CWnd *pWnd)					{ m_pWnd = pWnd; }

protected:
	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL PtInItem(CPoint point);

	// Draw tab text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.  
	//		bFocused---bFocused, Specifies A Boolean value.
	virtual void DrawText(CDC* pDC, BOOL bActive, BOOL bFocused);

	// Draw tab icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Icon, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual int DrawIcon(CDC* pDC, BOOL bActive);

	// Draw tab frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Frame, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DrawFrame(CDC* pDC, BOOL bActive);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.  
	//		bFocused---bFocused, Specifies A Boolean value.
	// Draw tab.
	virtual void Draw(CDC* pDC, BOOL bActive = FALSE, BOOL bFocused = FALSE);

protected:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Tool tip.
 
	// Tool Tip, This member sets TRUE if it is right.  
	BOOL		m_bToolTip;

	// Is enable or not.
 
	// Enabled, This member sets TRUE if it is right.  
	BOOL		m_bEnabled;

	// Tab icon handle.
 
	// Icon, This member specify HICON object.  
	HICON		m_hIcon;

	// Tab psoition.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Select or not.
 
	// Selected, This member sets TRUE if it is right.  
	BOOL		m_bSelected;

	// Tab window handle.
 
	// Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*		m_pWnd; 

	// Menu handle.
 
	// Menu, This member specify HMENU object.  
	HMENU		m_hMenu;

	// Item data.
 
	// Data, This member maintains a pointer to the object void.  
	void*		m_pData;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTABCTRLOBJECT_H__38B479A5_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
