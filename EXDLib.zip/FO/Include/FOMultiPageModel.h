//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMultiPageModel.h: interface for the CFOMultiPageModel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMULTIPAGEMODEL_H__18CF5274_F709_11DD_A43D_525400EA266C__INCLUDED_)
#define AFX_FOMULTIPAGEMODEL_H__18CF5274_F709_11DD_A43D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODataModel.h"
#include "FOPageProperties.h"
#include "FOBitmap.h"

#define FOP_NOTIFY_MODEL_CHANGE		40988

/////////////////////////////////////////////////////////////////////////////////
//
// CFOMultiPageModel
// This class is the datamodel of Multiple Pages style application,see sample CustomMSample,
// All the datamodel is managed by class CFOMultiPageModelManager.
//
/////////////////////////////////////////////////////////////////////////////////

class CFOMultiPageModelManager;

 
//===========================================================================
// Summary:
//     The CFOMultiPageModel class derived from CFODataModel
//      F O Multiple Page Model
//===========================================================================

class FO_EXT_CLASS CFOMultiPageModel : public CFODataModel
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiPageModel---F O Multiple Page Model, Specifies a E-XD++ CFOMultiPageModel object (Value).
	DECLARE_SERIAL(CFOMultiPageModel);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page Model, Constructs a CFOMultiPageModel object.
	//		Returns A  value (Object).
	CFOMultiPageModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page Model, Constructs a CFOMultiPageModel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOMultiPageModel& source object(Value).
	CFOMultiPageModel(const CFOMultiPageModel& source);

	//-----------------------------------------------------------------------
	// Summary:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Page Model, Destructor of class CFOMultiPageModel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiPageModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMultiPageModel& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOMultiPageModel& source object(Value).
	CFOMultiPageModel& operator=(const CFOMultiPageModel& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModel,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFODataModel* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the manager pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Manager, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelManager ,or NULL if the call failed
	virtual CFOMultiPageModelManager *GetManager() const { return m_pManager; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the data model manager.
	// pMgr -- pointer of data manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data Manager, Sets a specify value to current class CFOMultiPageModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pMgr---*pMgr, A pointer to the CFOMultiPageModelManager  or NULL if the call failed.
	virtual void SetDataManager(CFOMultiPageModelManager *pMgr) { m_pManager = pMgr; }

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it is need saving property now.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Property Now, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL			DoSavePropNow();

public:

	// draw an item
	// pDC -- pointer of the DC.
	// nIndex -- index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void DrawItem(CDC *pDC,int nIndex, const BOOL &bFocus);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	// remove
	virtual void Remove();

	// Notify all the observers of this datamodel.
	// lHint -- Notify type value.
	// pHint -- Notify.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual void	NotifyObserver(LPARAM lHint, CObject*pHint = NULL);
	
public:
	// get default properties of a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Page Property, Returns the specified value.
	//		Returns a pointer to the object CFOPageProperties ,or NULL if the call failed
	CFOPageProperties *GetDefaultPageProperty() const;

	// get page item number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Number, Returns the specified value.
	//		Returns a int type value.
	int			GetPageItemNumber() const;

	// set page item number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Number, Sets a specify value to current class CFOMultiPageModel
	// Parameters:
	//		&num---Specifies A integer value.
	void		SetPageItemNumber(const int &num);

	// get the flag of page being selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Page Item Selectd, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPageItemSelectd() const;

	// set page item selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Selected, Sets a specify value to current class CFOMultiPageModel
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void		SetPageItemSelected(const BOOL &bSelect);

	// get the page item position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Position, Returns the specified value.
	//		Returns a CRect type value.
	CRect		GetPageItemPosition() const;

	// set the page item position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Position, Sets a specify value to current class CFOMultiPageModel
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void		SetPageItemPosition(const CRect &rc);

	// get the page item caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetPageItemCaption() const;

	// set page item caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Caption, Sets a specify value to current class CFOMultiPageModel
	// Parameters:
	//		&strCap---&strCap, Specifies A CString type value.
	void		SetPageItemCaption(const CString &strCap);

	// get page item back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPageItemBackColor() const;

	// set page item back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Back Color, Sets a specify value to current class CFOMultiPageModel
	// Parameters:
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPageItemBackColor(const COLORREF &crBack);

protected:

	// draw item with name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item With Name, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	virtual void DrawItemWithName(CDC *pDC,int nIndex);

	// draw item with selected state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item With Name Selected, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void DrawItemWithNameSelected(CDC *pDC,int nIndex, const BOOL &bFocus);

	// Page number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Page Number, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual	CString ComputePageNumber();

	// Page name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Page Name, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputePageName();

	// draw a gradient ring
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Gradient Ring, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual BOOL DrawGradientRing (CDC* pDC, CRect rect);

public:

	// Save document to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(
		// Specifies file name with full path.
		LPCTSTR lpszPathName
		);

	// Open document with a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(
		// Specifies file name with full path.
		LPCTSTR lpszPathName
		);

	// Get the pointer of file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*	GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release file from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// page caption
 
	// Page Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		strPageCaption;		

	// default page color
 
	// Default Page Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crDefaultPageColor; 

	// Parent data model manager.
 
	// Manager, This member maintains a pointer to the object CFOMultiPageModelManager.  
	CFOMultiPageModelManager *m_pManager;

};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOPBitmapCache -- bitmap cache, it is defined for page small view window.
//

 
//===========================================================================
// Summary:
//      To use a CFOPBitmapCache object, just call the constructor.
//      F O P Bitmap Cache
//===========================================================================

class FO_EXT_CLASS CFOPBitmapCache
{
	// The maximize size of the cache.
 
	// Maximize Size, Specify a A 32-bit signed integer.  
	LONG		            m_nMaxSize;

	// Current memory size of the cache
 
	// Current Size, Specify a A 32-bit signed integer.  
	LONG		            m_nCurSize;

	// List of entries.
 
	// Entries, This member specify FOPList object.  
	FOPList		            m_aEntries;
                            
public:                     
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Bitmap Cache, Constructs a CFOPBitmapCache object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nMaxSizeKB---Maximize Size K B, Specifies A 32-bit LONG signed integer.
				            CFOPBitmapCache(LONG nMaxSizeKB)
				              : m_nMaxSize(nMaxSizeKB), m_nCurSize(0) {}

							//-----------------------------------------------------------------------
							// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Bitmap Cache, Destructor of class CFOPBitmapCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual 	            ~CFOPBitmapCache();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		pPage---pPage, A pointer to the const CFOMultiPageModel or NULL if the call failed.  
	//		rBmp---rBmp, Specifies a E-XD++ CFOBitmap& rBmp object (Value).
	// Add new entries
	void		            Add(const CFOMultiPageModel* pPage, CFOBitmap& rBmp);

	// Obtain entries.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed  
	// Parameters:
	//		pPage---pPage, A pointer to the const CFOMultiPageModel or NULL if the call failed.
	CFOBitmap*				Get(const CFOMultiPageModel* pPage);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		pPage---pPage, A pointer to the const CFOMultiPageModel or NULL if the call failed.
	// Remove entries.
	void                    Remove(const CFOMultiPageModel* pPage);
};

///////////////////////////////////////////////////////////
// CFOMultiPageModelSet -- multiple pages model set.

 
//===========================================================================
// Summary:
//     The CFOMultiPageModelSet class derived from FOPContainer
//      F O Multiple Page Model Set
//===========================================================================

class FO_EXT_CLASS CFOMultiPageModelSet : public FOPContainer
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page Model Set, Constructs a CFOMultiPageModelSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFOMultiPageModelSet(int nInit = 16, int nTotal = 16) : FOPContainer(1024, nInit, nTotal)	{}

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Page Model Set, Destructor of class CFOMultiPageModelSet
	//		Returns A  value (Object).
    ~CFOMultiPageModelSet();

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddHead(CObject* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddTail(CObject* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOMultiPageModelSet or NULL if the call failed.
	void AddHead(CFOMultiPageModelSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOMultiPageModelSet or NULL if the call failed.
	void AddTail(CFOMultiPageModelSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();
};

// Multiple pages model list.
typedef CTypedPtrList<CObList, CFOMultiPageModel*> CFOMultiPageModelList;

// Model iterator.
typedef FOBasicListIterator<CFOMultiPageModel*> CFOMultiPageModelIterator;

#include "FOMultiPageModel.inl"

#endif // !defined(AFX_FOMULTIPAGEMODEL_H__18CF5274_F709_11DD_A43D_525400EA266C__INCLUDED_)
