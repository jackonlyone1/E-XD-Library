//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FORemoveCompsAction.h: interface for the CFORemoveCompsAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOREMOVECOMPSACTION_H__3645F723_F20C_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOREMOVECOMPSACTION_H__3645F723_F20C_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

///////////////////////////////////////////////////////////////////////////////////
// CFORemoveCompsAction -- action that remove components from canvas.

 
//===========================================================================
// Summary:
//     The CFORemoveCompsAction class derived from CFOAction
//      F O Remove Components Action
//===========================================================================

class FO_EXT_CLASS CFORemoveCompsAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveCompsAction---F O Remove Components Action, Specifies a E-XD++ CFORemoveCompsAction object (Value).
	DECLARE_ACTION(CFORemoveCompsAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Components Action, Constructs a CFORemoveCompsAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFORemoveCompsAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Components Action, Destructor of class CFORemoveCompsAction
	//		Returns A  value (Object).
	~CFORemoveCompsAction();

	// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove shape from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Clear all index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Index, Remove the specify data from the list.

	void ClearAllIndex();
	
	// Obtain index of a shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	BOOL GetIndex(CFODrawShape* pComp, int& nIndex) const;
	
	// Change the index of a shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFORemoveCompsAction
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	void SetIndex(CFODrawShape* pComp, int nIndex);
	
	// Update all shape's index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Indices, Call this member function to update the object.
	// Parameters:
	//		pCompList---Component List, A pointer to the CFODrawShapeList or NULL if the call failed.
	void UpdateIndices(CFODrawShapeList* pCompList);

	// Obtain index within list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index Within, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pCompList---Component List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	int GetIndexWithin(CFODrawShape *pShape, CFODrawShapeSet* pCompList);

	// Attributes
protected:

	// The list of shapes.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;
	
	// Shape index.
	CMap<CFODrawShape*,CFODrawShape*,int,int> m_shapeIndices;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShapeList* CFORemoveCompsAction::GetShapeList()
{
	return &m_listShapes;
}


/////////////////////////////////////////////////////////////////////////////
// CFORemoveShapesFromBackAction -- action that remove shapes from background.

 
//===========================================================================
// Summary:
//     The CFORemoveShapesFromBackAction class derived from CFOAction
//      F O Remove Shapes From Back Action
//===========================================================================

class FO_EXT_CLASS CFORemoveShapesFromBackAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveShapesFromBackAction---F O Remove Shapes From Back Action, Specifies a E-XD++ CFORemoveShapesFromBackAction object (Value).
	DECLARE_ACTION(CFORemoveShapesFromBackAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Shapes From Back Action, Constructs a CFORemoveShapesFromBackAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFORemoveShapesFromBackAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Shapes From Back Action, Destructor of class CFORemoveShapesFromBackAction
	//		Returns A  value (Object).
	~CFORemoveShapesFromBackAction();

	// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove shape from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Attributes
protected:

	// The list of shapes.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShapeList* CFORemoveShapesFromBackAction::GetShapeList()
{
	return &m_listShapes;
}

/////////////////////////////////////////////////////////////////////////////
// CFORemoveShapesFromCompositeAction -- action that remove shapes from composite.

class CFOCompositeShape;

// added action class
 
//===========================================================================
// Summary:
//     The CFORemoveShapesFromCompositeAction class derived from CFOAction
//      F O Remove Shapes From Composite Action
//===========================================================================

class FO_EXT_CLASS CFORemoveShapesFromCompositeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveShapesFromCompositeAction---F O Remove Shapes From Composite Action, Specifies a E-XD++ CFORemoveShapesFromCompositeAction object (Value).
	DECLARE_ACTION(CFORemoveShapesFromCompositeAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Shapes From Composite Action, Constructs a CFORemoveShapesFromCompositeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFORemoveShapesFromCompositeAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Shapes From Composite Action, Destructor of class CFORemoveShapesFromCompositeAction
	//		Returns A  value (Object).
	~CFORemoveShapesFromCompositeAction();

	// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove shape from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFORemoveShapesFromCompositeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Clear all index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Index, Remove the specify data from the list.

	void ClearAllIndex();
	
	// Obtain index of a shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	BOOL GetIndex(CFODrawShape* pComp, int& nIndex) const;
	
	// Change the index of a shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFORemoveShapesFromCompositeAction
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	void SetIndex(CFODrawShape* pComp, int nIndex);
	
	// Update all shape's index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Indices, Call this member function to update the object.
	// Parameters:
	//		pCompList---Component List, A pointer to the CFODrawShapeList or NULL if the call failed.
	void UpdateIndices(CFODrawShapeList* pCompList);
	
	// Attributes
protected:

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
	// Shape index.
	CMap<CFODrawShape*,CFODrawShape*,int,int> m_shapeIndices;

	// The list of shapes.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShapeList* CFORemoveShapesFromCompositeAction::GetShapeList()
{
	return &m_listShapes;
}

#endif // !defined(AFX_FOREMOVECOMPSACTION_H__3645F723_F20C_11DD_A432_525400EA266C__INCLUDED_)
