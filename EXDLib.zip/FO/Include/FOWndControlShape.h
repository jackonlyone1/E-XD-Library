//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOWndControlShape.h: interface for the CFOVertScrollBarShape class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(FO_FOWNDCONTROLSHAPE_H__4A940EAB_3046_4602_A305_ED153B74EF20__INCLUDED_)
#define AFC_FOWNDCONTROLSHAPE_H__4A940EAB_3046_4602_A305_ED153B74EF20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------
#include "FODrawShape.h"
#include "FOTextEdit.h"
#include "FOPFlatComboBox.h"

class FO_EXT_CLASS CFOPDateTimeCtrl : public CDateTimeCtrl
{
public:
	CFOPDateTimeCtrl () : m_bMonthCtrlDisplayed(false) { pParentShape = NULL; }
	
	CFODrawShape *pParentShape;
	void UpdateTime();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPDateTimeCtrl)
	afx_msg BOOL OnDateTimeChange (NMHDR* pNotifyStruct, LRESULT* pResult);
	afx_msg BOOL OnDateTimeDropDown (NMHDR* pNotifyStruct, LRESULT* pResult);
	afx_msg BOOL OnDateTimeCloseUp (NMHDR* pNotifyStruct, LRESULT* pResult);
	//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	DECLARE_MESSAGE_MAP()
		
private:
	bool m_bMonthCtrlDisplayed;
};

/////////////////////////////////////////////////////////////////////////////
// CFOWndControlShape -- shape that contains any window standard control.
//						the create method must be overrided.

 
//===========================================================================
// Summary:
//     The CFOWndControlShape class derived from CFODrawShape
//      F O Window  Shape
//===========================================================================

class FO_EXT_CLASS CFOWndControlShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOWndControlShape---F O Window  Shape, Specifies a E-XD++ CFOWndControlShape object (Value).
	DECLARE_SERIAL(CFOWndControlShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	// nCtrlID -- id of this control
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Window  Shape, Constructs a CFOWndControlShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCtlID---Ctl I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOWndControlShape(const UINT nCtlID = 1);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Window  Shape, Constructs a CFOWndControlShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOWndControlShape& src object(Value).
	CFOWndControlShape(const CFOWndControlShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Window  Shape, Destructor of class CFOWndControlShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOWndControlShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOWndControlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Set control id.
	// nID -- window control ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set  I D, Sets a specify value to current class CFOWndControlShape
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetControlID(const UINT nID);

	// Get control id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  I D, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetControlID() const;

	// Get pointer of wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Window, Returns the specified value.
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *GetCtrlWnd() const { return m_pWnd; }

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOWndControlShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	// Create a new window control
	// rcPos -- position of shape.
	BOOL Create(const CRect& rcPos);

	// Create window, override this method to create new window control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CFOWndControlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.
	virtual BOOL CreateWnd(CWnd *pParent);

	// Destroy window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DestroyWnd();

	// Set local position.
	// rcPos -- position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window Position, Sets a specify value to current class CFOWndControlShape
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	void SetWndPosition(const CRect& rcPos);

	// Is hidden.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hidden, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsHidden() const;

	// Set hidden.
	// bHidden -- hide or show
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Hidden, Sets a specify value to current class CFOWndControlShape
	// Parameters:
	//		bHidden---bHidden, Specifies A Boolean value.
	void SetHidden(const BOOL bHidden);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOWndControlShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOWndControlShape& src object(Value).
	CFOWndControlShape& operator=(const CFOWndControlShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Generate Shape Area
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	void DoUpdateWnd();

public:
	FOPRect m_rcSaveWndPos;
	BOOL m_bNeedUpdateWnd;

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// window pointer.
 
	// Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *		m_pWnd;

	// Control id.
 
	// I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nControlID;

	// Control position.
 
	// m_rc Control, This member sets a CRect value.  
	CRect		m_rcControl;

};


/////////////////////////////////////////////////////////////////////////////
// CFODateTimeShape -- shape that contains any window standard control.
//						the create method must be overrided.
// Shape ID: FO_COMP_DATETIME

class FO_EXT_CLASS CFODateTimeShape : public CFOWndControlShape  
{
protected:
	DECLARE_SERIAL(CFODateTimeShape);
public:
	
	// constructor
	CFODateTimeShape(const UINT nCtlID = 1);
	
	// Copy constructor.
	CFODateTimeShape(const CFODateTimeShape& src);
	
	// Destructor.
	virtual ~CFODateTimeShape();
	
	// Creates and returns a window object to caller. 
	virtual BOOL CreateWnd(CWnd *pParent);
	
public:
	
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Assignment operator.
	CFODateTimeShape& operator=(const CFODateTimeShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	CFOPDateTimeCtrl *GetDateCtrl();
	
	void SetTimeType(const int &nType); // 0 -- long time, 1 -- short time, 2-- time
	
	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Edit Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentEditText(CString& strResult);
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Edit Text, Sets a specify value to current class CMyHorzSliderShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentEditText(const CString& str);
	
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetCurrentText();
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOXNDateTimeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);
	
	// Set date time
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Date Time, Sets a specify value to current class CFOXNDateTimeShape
	// Parameters:
	//		Date---Date, Specifies a COleDateTime& Date object(Value).
	void SetDateTime(COleDateTime& Date);
	
	// WM_KILLFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	virtual void OnKillFocus(CWnd* pNewWnd);

	// Get date time
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Time, Returns the specified value.
	//		Returns A COleDateTime value (Object).
	COleDateTime GetDateTime();

	BOOL IsTimeStyle() const;
	void SetTimeStyle(const BOOL &bTime);
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

////////////////////////////////////////////////////////////////////
// CFOPAnimateTextShape

class FO_EXT_CLASS CFOPAnimateTextShape : public CFOWndControlShape  
{
protected:
	DECLARE_SERIAL(CFOPAnimateTextShape);
public:

	// constructor
	CFOPAnimateTextShape(const UINT nCtlID = 1);

	// Copy constructor.
	CFOPAnimateTextShape(const CFOPAnimateTextShape& src);

	// Destructor.
	virtual ~CFOPAnimateTextShape();

	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Creates and returns a window object to caller. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CMyListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.
	virtual BOOL CreateWnd(CWnd *pParent);

public:

	CFOScrollText *GetGrid();
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Assignment operator.
	CFOPAnimateTextShape& operator=(const CFOPAnimateTextShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
 
	//===========================================================================
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);
 

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};


////////////////////////////////////////////////////////////////////
// CFOPExtendComboShape

class FO_EXT_CLASS CFOPExtendComboShape : public CFOWndControlShape  
{
protected:
	DECLARE_SERIAL(CFOPExtendComboShape);
public:

	// constructor
	CFOPExtendComboShape(const UINT nCtlID = 1);

	// Copy constructor.
	CFOPExtendComboShape(const CFOPExtendComboShape& src);

	// Destructor.
	virtual ~CFOPExtendComboShape();

	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Creates and returns a window object to caller. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CMyListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.
	virtual BOOL CreateWnd(CWnd *pParent);

public:

	
	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetCurrentText();
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOXNDateTimeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);
	
	virtual void SVG_Gen(CString &strIn, int nBrushType);

	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Edit Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentEditText(CString& strResult);
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Edit Text, Sets a specify value to current class CMyHorzSliderShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentEditText(const CString& str);
	
	CFOPFlatComboBox *GetGrid();
	int FOGetNextLineExt(CString& s, CString &sLine);
	
	void DoInitTree(const int &nImageId = 0);

	
	// Get choice list,this is the choice list string of the shape CFOTabbedComboShape.
	// It return a string like this:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice List, Returns the specified value.
	//		Returns a CString type value.
	CString		GetChoiceList() const;
	
	// Change the choice list string of the shape CFOTabbedComboShape,
	// strChoice -- It must be like the following string:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CHMIAnimateTextShape
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	void		SetChoiceList(const CString &strChoice);
	
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value.
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CHMIDynamicLEDShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object.
	virtual void		SetCurrentValue(const double &nValue);
	
	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bFlat---bFlat, Specifies A Boolean value.
	virtual void OnDrawText(CDC *pDC,BOOL bFlat);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Assignment operator.
	CFOPExtendComboShape& operator=(const CFOPExtendComboShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	
public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
 
	//===========================================================================
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);
 

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};


////////////////////////////////////////////////////////////////////
// CFOPExtendListBoxShape

class FO_EXT_CLASS CFOPExtendListBoxShape : public CFOWndControlShape  
{
protected:
	DECLARE_SERIAL(CFOPExtendListBoxShape);
public:

	// constructor
	CFOPExtendListBoxShape(const UINT nCtlID = 1);

	// Copy constructor.
	CFOPExtendListBoxShape(const CFOPExtendListBoxShape& src);

	// Destructor.
	virtual ~CFOPExtendListBoxShape();

	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Creates and returns a window object to caller. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CMyListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.
	virtual BOOL CreateWnd(CWnd *pParent);

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

public:

	
	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetCurrentText();
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOXNDateTimeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);
	
	
	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Edit Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentEditText(CString& strResult);
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Edit Text, Sets a specify value to current class CMyHorzSliderShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentEditText(const CString& str);
	
	CFOComboListBox *GetGrid();
	int FOGetNextLineExt(CString& s, CString &sLine);
	
	void DoInitTree(const int &nImageId = 0);

	
	// Get choice list,this is the choice list string of the shape CFOTabbedComboShape.
	// It return a string like this:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice List, Returns the specified value.
	//		Returns a CString type value.
	CString		GetChoiceList() const;
	
	// Change the choice list string of the shape CFOTabbedComboShape,
	// strChoice -- It must be like the following string:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CHMIAnimateTextShape
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	void		SetChoiceList(const CString &strChoice);
	
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value.
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CHMIDynamicLEDShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object.
	virtual void		SetCurrentValue(const double &nValue);
	
	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bFlat---bFlat, Specifies A Boolean value.
	virtual void OnDrawText(CDC *pDC,BOOL bFlat);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Assignment operator.
	CFOPExtendListBoxShape& operator=(const CFOPExtendListBoxShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
 
	//===========================================================================
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);
 

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#endif // !defined(AFC_FOWNDCONTROLSHAPE_H__4A940EAB_3046_4602_A305_ED153B74EF20__INCLUDED_)
