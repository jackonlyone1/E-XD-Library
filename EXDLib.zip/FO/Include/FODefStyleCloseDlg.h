//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODEFSTYLECLOSEDLG_H__2888E448_D3F5_4FA9_87CA_1B677A0089D0__INCLUDED_)
#define AFX_FODEFSTYLECLOSEDLG_H__2888E448_D3F5_4FA9_87CA_1B677A0089D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODefStyleCloseDlg.h : header file
//

#include "FOPDropDownColorPickerButton.h"
#include "FOFontNameCombo.h"
#include "FOPDropDownLineWidthButton.h"
#include "FODiamondShape.h"
#include "FOLineShape.h"

class CFODefStyleDlg;

/////////////////////////////////////////////////////////////////////////////
// CFODefStyleCloseDlg dialog

 
//===========================================================================
// Summary:
//     The CFODefStyleCloseDlg class derived from CDialog
//      F O Default Style Close Dialog
//===========================================================================

class FO_EXT_CLASS CFODefStyleCloseDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Default Style Close Dialog, Constructs a CFODefStyleCloseDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFODefStyleCloseDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFODefStyleCloseDlg)
	enum { IDD = IDD_FO_DEF_STYLE_CLOSE };
 
	// Font Face Name, This member specify E-XD++ CFOFontNameCombo object.  
	CFOFontNameCombo m_FontFaceName;
 
	// Size, This member specify CComboBox object.  
	CComboBox   m_cbSize;
 
	// Shadow, This member sets TRUE if it is right.  
	BOOL		m_bShadow;
 
	// Spin, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_ctrSpin;
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nBrushType;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// Text color picker window.
 
	// Text Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnTextColor;

	// Color picker window.
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndColor;

	// Back color picker window.
 
	// B K Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndBKColor;

	// Pattern color picker window.
 
	// Pattern Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndPatternColor;

	// Shadow color picker window
 
	// Shadow Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndShadowColor;

	// Line width picker window.
 
	// Line Width, This member specify FOPDropDownLineWidthButton object.  
	FOPDropDownLineWidthButton		m_wndLineWidth;

	// Init font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Font Size, Call InitFontSize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitFontSize();

	// Text color.
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF			crText;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crBK;

	// Pattern color.
 
	// Pattern, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crPattern;

	// Shadow color
 
	// Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crShadow;

	// Font face name.
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strFaceName;

	// Font point size.
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nPointSize;

	//Line Color
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crLine;

	//Line Width
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nLineWidth;

	// Create or not.
 
	// Created, This member sets TRUE if it is right.  
	BOOL				m_bCreated;

	// Pointer of parent dialog.
 
	// Parent Dialog, This member maintains a pointer to the object CFODefStyleDlg.  
	CFODefStyleDlg *	pParentDlg;

	// Modified or not.
 
	// Modified, This member sets TRUE if it is right.  
	BOOL				m_bModified;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODefStyleCloseDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFODefStyleCloseDlg)
		// NOTE: the ClassWizard will add member functions here
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Font Name Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFontNameCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fontsize Combo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFontsizeCombo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shadow Check1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShadowCheck1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Brushtype Edit, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoBrushtypeEdit();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Background Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnBkColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Pattern Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPatternColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Shadow Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnShadowColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Width Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnLineWidthChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODEFSTYLECLOSEDLG_H__2888E448_D3F5_4FA9_87CA_1B677A0089D0__INCLUDED_)
