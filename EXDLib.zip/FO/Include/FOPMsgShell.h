//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU(ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPMsgShell.h: interface for the CFOPMsgShell class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPMSGSHELL_H__14A85705_394E_4BB1_A71C_D8BD7B10C2F6__INCLUDED_)
#define AFX_FOPMSGSHELL_H__14A85705_394E_4BB1_A71C_D8BD7B10C2F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////////
// CFOPMsgShell -- message shell.

#include "fodefines.h"
//===========================================================================
// Summary:
//     The CFOPMsgShell class derived from CWnd
//      F O P Message Shell
//===========================================================================

class FO_EXT_CLASS CFOPMsgShell : public CWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMsgShell---F O P Message Shell, Specifies a E-XD++ CFOPMsgShell object (Value).
    DECLARE_DYNAMIC(CFOPMsgShell);
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Message Shell, Constructs a CFOPMsgShell object.
	//		Returns A  value (Object).
    CFOPMsgShell();

	// Set message handled.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Message Handled, Sets a specify value to current class CFOPMsgShell
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bResect---bResect, Specifies A Boolean value.
	virtual void SetMessageHandled(BOOL bResect = TRUE);

	// Plug in
	
	//-----------------------------------------------------------------------
	// Summary:
	// Install, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
    BOOL Install(CWnd* pParentWnd);

	// Un plug message handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Un Install, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UnInstall();

	// Is plugged
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Installed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsInstalled() { return m_bMsgShell; } 

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Message Shell, Destructor of class CFOPMsgShell
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPMsgShell();

public:
    // Attributes 
    // Reserved for later usage with a PluginManager
 
	// Use Default, This member sets TRUE if it is right.  
    BOOL	m_bUseDefault; 

	// set to TRUE from within your message handler
    // if no other plugins and also not the 
    // default window message should be called
 
	// Exit Message, This member sets TRUE if it is right.  
    BOOL	m_bExitMessage;     

	// Message handled
 
	// Message Handled, This member sets TRUE if it is right.  
	BOOL	m_bMsgHandled;

	// Message RC.
 
	// Message R C, This member sets TRUE if it is right.  
	BOOL	m_bMsgRC;

	// Is plugged in or not.
 
	// Message Shell, This member sets TRUE if it is right.  
	BOOL	m_bMsgShell;

protected:
    // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SECWndPlugIn)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnWndMsg( UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO or NULL if the call failed.
	virtual BOOL OnCmdMsg( UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo );
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Default Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT DefWindowProc( UINT message, WPARAM wParam, LPARAM lParam );
	//}}AFX_VIRTUAL

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
    virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
    //{{AFX_MSG(CFOPMsgShell)
    //}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// FOPMsgHandleTool -- message handle tool

class CFOPCanvasCore;

 
//===========================================================================
// Summary:
//     The FOPMsgHandleTool class derived from CObject
//      O P Message Handle Tool
//===========================================================================

class FO_EXT_CLASS FOPMsgHandleTool : public CObject
{
public:
	
	// Constructor.
	// pCore -- pointer of the core
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Message Handle Tool, Constructs a FOPMsgHandleTool object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pCore---*pCore, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	FOPMsgHandleTool(CFOPCanvasCore *pCore = NULL);

	// Constructor.
	// pCore -- pointer of the core.
	// nID -- value of the ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Message Handle Tool, Constructs a FOPMsgHandleTool object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pCore---*pCore, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.
	FOPMsgHandleTool(CFOPCanvasCore *pCore,int nID);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Message Handle Tool, Destructor of class FOPMsgHandleTool
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPMsgHandleTool();

public:

	// Get the ID of the event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Id, Returns the specified value.
	//		Returns a int type value.
	int GetId() const;

	// Set the ID of the events,
	// nID -- It must be an unique ID for each kind of event class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Id, Sets a specify value to current class FOPMsgHandleTool
	// Parameters:
	//		nID---I D, Specifies A integer value.
	void SetId(const int nID);

	// Obtain the pointer of the wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	CWnd* GetWnd();

protected:

	// Event ID
 
	// Event I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nEventID;

public:
	
	// Allow reset after left button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Reset After L Button Up, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsResetAfterLButtonUp() { return m_bResetAfterLButtonUp; }

	// Allow reset after right button up.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Reset After R Button Up, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsResetAfterRButtonUp() { return m_bResetAfterRButtonUp; }

	// WM_LBUTTONDOWN message.
	// virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	// virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnLButtonUp(UINT nFlags, CPoint point);

	// Do Middle Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL OnMButtonDown(UINT nFlags, CPoint pt);

	// Do middle button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL OnMButtonUp(UINT nFlags, CPoint pt);

	// Do middle button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnMButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_KEYUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_SETCURSOT message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);

	// Do something when timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnTimer(UINT_PTR nIDEvent);

	// Do something when mouse wheel moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	virtual void OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	
	// WM_KILLFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL OnKillFocus(CWnd* pNewWnd);

	//	WM_SETFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	virtual  BOOL OnSetFocus(CWnd* pOldWnd);

	// Do when init data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On When Initial, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnWhenInit();

	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnCancelMode();
	
	// Do when the parent frame sizing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual void OnSize(UINT nType, int cx, int cy);

protected:

	// Pointer of the wnd.
 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore*	m_pCore;

	// Reset after left button up.
 
	// Reset After L Button Up, This member sets TRUE if it is right.  
	BOOL			m_bResetAfterLButtonUp;

	// Reset after right button up.
 
	// Reset After R Button Up, This member sets TRUE if it is right.  
	BOOL			m_bResetAfterRButtonUp;

};

#endif // !defined(AFX_FOPMSGSHELL_H__14A85705_394E_4BB1_A71C_D8BD7B10C2F6__INCLUDED_)
