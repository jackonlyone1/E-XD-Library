//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPolygonShape.h: interface for the CFOPathShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(FO_FOPATHSHAPE_H__56610423_C87D_4FA6_93E4_F2A86A5674F3__INCLUDED_)
#define AFC_FOPATHSHAPE_H__56610423_C87D_4FA6_93E4_F2A86A5674F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODrawPortsShape.h"
#include "FOPHandle.h"

// Path shape kind value.
enum FOPShapeKind 
{
	FOP_DRAW_PATH_NONE			= 0,   // None
	FOP_DRAW_PATH_LINE			= 1,   // Line shape
	FOP_DRAW_PATH_POLYGON		= 2,   // Polygon, PolyPolygon
	FOP_DRAW_PATH_PLINE			= 3,   // PolyLine
	FOP_DRAW_PATH_PATHLINE		= 4,   // Bezier curve
	FOP_DRAW_PATH_PATHFILL		= 5,   // Close Bezier curve
	FOP_DRAW_PATH_FREELINE		= 6,   // Free handle line
	FOP_DRAW_PATH_FREEFILL		= 7,   // Close free handle line
	FOP_DRAW_PATH_SPLNLINE		= 8,   // Spline
	FOP_DRAW_PATH_SPLNFILL		= 9,   // Close spline
	FOP_DRAW_PATH_PATHPOLYGON   = 10,  // Polygon/PolyPolygon
	FOP_DRAW_PATH_PATHPLINE		= 11,  // Polyline
	FOP_DRAW_PATH_OTHER
};

/////////////////////////////////////////////////////////////////////////////
// FOPPathObjGeoData -- path data

 
//===========================================================================
// Summary:
//     The FOPPathObjGeoData class derived from FOPObjGeoData
//      O P Path Object Geogmetry Data
//===========================================================================

class FOPPathObjGeoData : public FOPObjGeoData
{
public:
	// Simple composite polygon of the shape.
 
	// Path Polygon, This member specify FOPSimpleCompositePolygon object.  
	FOPSimpleCompositePolygon	m_aPathPolygon;

	// Shape style kind.
 
	// Shape Type, This member specify FOPShapeKind object.  
	FOPShapeKind				m_nShapeType;

	// Shape type.
 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nType;

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Path Object Geogmetry Data, Constructs a FOPPathObjGeoData object.
	//		Returns A  value (Object).
	FOPPathObjGeoData();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Path Object Geogmetry Data, Constructs a FOPPathObjGeoData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const FOPPathObjGeoData& src object(Value).
	FOPPathObjGeoData(const FOPPathObjGeoData& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Path Object Geogmetry Data, Destructor of class FOPPathObjGeoData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPPathObjGeoData();

	//-----------------------------------------------------------------------
	// Summary:
	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPathObjGeoData& value (Object).  
	// Parameters:
	//		src---Specifies a const FOPPathObjGeoData & src object(Value).
	virtual FOPPathObjGeoData& operator=(const FOPPathObjGeoData & src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		src---Specifies a const FOPPathObjGeoData& src object(Value).
	// Operator == 
	virtual BOOL operator ==(const FOPPathObjGeoData& src) const;

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPObjGeoData,or NULL if the call failed
	// Creates a copy of this data.
	virtual FOPObjGeoData* Copy() const;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPathShape -- this is a very powerful path shape, you can change the style of 
//				   each line segment, create composite path with multiple simple polygons.
//				   Convert any path to polygons.
//				   ID: FO_COMP_PATH 83

 
//===========================================================================
// Summary:
//     The CFOPathShape class derived from CFODrawPortsShape
//      F O Path Shape
//===========================================================================

class FO_EXT_CLASS CFOPathShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPathShape---F O Path Shape, Specifies a E-XD++ CFOPathShape object (Value).
	DECLARE_SERIAL(CFOPathShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Path Shape, Constructs a CFOPathShape object.
	//		Returns A  value (Object).
	CFOPathShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Path Shape, Constructs a CFOPathShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPathShape& src object(Value).
	CFOPathShape(const CFOPathShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Path Shape, Destructor of class CFOPathShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPathShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	// Creates the path shape from points.
	// aPathPoly -- points polygons of the shape.
	BOOL Create(const FOPSimpleCompositePolygon& aPathPoly);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).  
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	// Creates the path shape from points.
	// aPathPoly -- points of polygon.
	// nShapeType -- shape style.
	BOOL Create(FOPShapeKind nShapeType,const FOPSimpleCompositePolygon& aPathPoly);

	//-----------------------------------------------------------------------
	// Summary:
	// Creates the path shape from points.
	// aPathPoly -- points polygons of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).  
	//		aPathPoly---Path Polygon, Specifies a const FOPSimplePolygon& aPathPoly object(Value).
	BOOL Create2(FOPShapeKind nShapeType, const FOPSimplePolygon& aPathPoly);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPt1---ptPt1, Specifies A integer value.  
	//		ptPt2---ptPt2, Specifies A integer value.
	// Creates the path shape from points.
	// ptPt1 -- start point of the line.
	// ptPt2 -- end point of the line.
	BOOL Create(const FOPPoint& ptPt1, const FOPPoint& ptPt2);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lppt---Specifies A LPPOINT Points array.  
	//		cCount---cCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the path Shape from points.
	// lppt -- points list.
	// nCount -- count of points.
	// bClose -- close or not.
	// strCaption -- caption.
	virtual void Create(CONST LPPOINT lppt, int cCount, const BOOL &bClose,
		CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&mpPoints---&mpPoints, Specifies A CPoint type value.  
	//		&bClose---&bClose, Specifies A Boolean value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the path Shape from points.
	// mpPoints -- points list.
	// bClose -- close or not.
	// strCaption -- caption.
	virtual void Create(const CArray<CPoint, CPoint> &mpPoints, 
		const BOOL &bClose,  CString strCaption = _T(""), const BOOL &bSpline = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lppt---Specifies A LPPOINT Points array.  
	//		lpbTypes---lpbTypes, Specifies An 8-bit BYTE integer that is not signed.  
	//		cCount---cCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the path Shape from points.
	// lppt -- points list.
	// lpbTypes -- points style flags
	// nCount -- count of points.
	// bClose -- close or not.
	// strCaption -- caption.
	virtual void Create(CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount, 
		const BOOL &bClose, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Create default path shape with a specify rectangle position.
	// nShapeType -- type of the shape.
	//1 BEZIER_FILL
	//2 BEZIER_NOFILL
	//3 FREELINE
	//4 FREELINE_NOFILL
	//5 SIMPLEPOLYGON
	//6 SIMPLEPOLYGON_NOFILL
	//7 POLYGON
	//8 POLYGON_NOFILL
	// rcPos -- rectangle position of the shape.
	// strCaption -- caption of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies a const FOPRect &rcPos object(Value).  
	//		strCaption---strCaption, Specifies A CString type value.
	BOOL CreateDefault(const UINT &nShapeType,const FOPRect &rcPos,
		CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Create the path shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Create the path shape and initializes the data members.
	// strSVG -- SVG Text.
	// strCaption -- caption of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create With S V G, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strSVG---S V G, Specifies A CString type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual void CreateWithSVG(const CString &strSVG,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		lpPoints---lpPoints, A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		bTotalBezier---Total Bezier, Specifies A Boolean value.
	// Creates the path shape and initializes the data members.
	// rcPos -- position of shape.
	// lpPoints -- points of the shape.
	// nCount -- count of the points.
	// bTotalBizier -- all the points of this shape are bezier points.
	virtual BOOL Create(CRect &rcPos,POINT* lpPoints,int nCount,
		BOOL bTotalBezier = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Update data, this method only create polygons and not update the save points.
	// nShapeType -- style of path shape.
	// aPathPoly -- simple composite polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create No Update, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).  
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	virtual void CreateNoUpdate(FOPShapeKind nShapeType,const FOPSimpleCompositePolygon& aPathPoly);

public:
	// New path.
	void NewPath();

	//-----------------------------------------------------------------------
	// Summary:
	// Set Start, Sets a specify value to current class FOPComplexGeometry
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.
	void MoveTo(const FOPPoint& ptStart);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.
	void LineTo(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier, Adds an object to the specify list.
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.
	void BezierTo(const FOPPoint& pt1, const FOPPoint& pt2, const FOPPoint& pt3);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		szRadius---szRadius, Specifies a const FOPSize szRadius object(Value).  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		dblRotationAngle---Rotation Angle, Specifies a double dblRotationAngle = 0 object(Value).
	void ArcTo(const FOPPoint& pt, const FOPSize szRadius, 
		BOOL bIsClockwise = TRUE, BOOL bIsLargeArc = FALSE, double dblRotationAngle = 0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		nBulge---bulge value.  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	void ArcTo(const FOPPoint& pt, const double &nBulge);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		ptEnd---end point.  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	void ArcTo(const FOPPoint& ptCtrl, const FOPPoint& ptEnd);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		curveType---curveType, Specifies a FOP_CURVE_TYPE curveType object(Value).
	void Lines(const FOPointsArray& arPoints, FOP_CURVE_TYPE curveType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Closed, Sets a specify value to current class FOPComplexGeometry
	// Parameters:
	//		bIsClosed---Is Closed, Specifies A Boolean value.
	void ClosePath(BOOL bIsClosed = TRUE);

	void EndAndUpdate();
	
	// Only update, mostly it is used after CreateNoUpdate method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Only Update, This member function is called by the framework to allow your application to handle a Windows message.

	void OnlyUpdate();

	// Reset new polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset New Polygon, Called this function to empty a previously initialized CFOPathShape object.
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	void ResetNewPoly(const FOPSimpleCompositePolygon& aPathPoly);

	// Reset new tracking polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset New Track Polygon, Called this function to empty a previously initialized CFOPathShape object.
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	void ResetNewTrackPoly(const FOPSimpleCompositePolygon& aPathPoly);

	// Temp update points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Temp Update, .

	void TempUpdate();

	// Temp track update points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Temp Track Update, .

	void TempTrackUpdate();

	// Obtain the count of the points of the simple composite polygon object.
	// aPathPoly -- a specify composite polygon to calculate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count Extend, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	int GetPointCountExt(const FOPSimpleCompositePolygon& aPathPoly);

	// Get rotate handle location.
	// ptHandle -- result point value of the control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Search the simple composite polygon to find the position, it uses close FALSE.
	// nPtIndex -- search point index.
	// nIndexPoly -- index of the polygons.
	// nIndexPt -- index of the point number.
	// bSearchAll -- search all points or only the no control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search Point, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nIndexPoly---Index Polygon, Specifies A integer value.  
	//		nIndexPt---Index Point, Specifies A integer value.  
	//		bSearchAll---Search All, Specifies A Boolean value.
	BOOL SearchPoint(int nPtIndex, int& nIndexPoly, int& nIndexPt, BOOL bSearchAll = TRUE) const;

	// Search the simple composite polygon to find the position, it uses the old close state.
	// nPtIndex -- search point index.
	// nIndexPoly -- index of the polygons.
	// nIndexPt -- index of the point number.
	// bSearchAll -- search all points or only the no control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search Point Extend, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nIndexPoly---Index Polygon, Specifies A integer value.  
	//		nIndexPt---Index Point, Specifies A integer value.  
	//		bSearchAll---Search All, Specifies A Boolean value.
	BOOL SearchPointExt(int nPtIndex, int& nIndexPoly, int& nIndexPt, BOOL bSearchAll = TRUE) const;

	// Search the simple composite polygon to find the position, it uses the old close state.
	// nPtIndex -- search point index.
	// nIndexPoly -- index of the polygons.
	// nIndexPt -- index of the point number.
	// bSearchAll -- search all points or only the no control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reverse Search Point Extend, .
	// Parameters:
	//		&nPtIndex---Point Index, Specifies A integer value.  
	//		nIndexPoly---Index Polygon, Specifies A integer value.  
	//		nIndexPt---Index Point, Specifies A integer value.
	void ReverseSearchPointExt(int &nPtIndex, const int& nIndexPoly, const int& nIndexPt) const;

	// Is current shape style with close state.
	// nShapeType -- shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).
	static BOOL IsClosed(FOPShapeKind nShapeType);

	// Is current shape style line shape.
	// nShapeType -- shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Line, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).
	static BOOL IsLine(FOPShapeKind nShapeType);

	// Is current shape free handle drawing line
	// nShapeType -- shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Free Hand, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).
	static BOOL IsFreeHand(FOPShapeKind nShapeType);

	// Is current shape style bezier line shape.
	// nShapeType -- shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bezier, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).
	static BOOL IsBezier(FOPShapeKind nShapeType);

	// Is current shape style spline line shape.
	// nShapeType -- shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Spline, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).
	static BOOL IsSpline(FOPShapeKind nShapeType);

	// Is current shape with close state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Old Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOldClosed() const;

	// Is new shape with close state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClosed() const;

	// Is smoothing editing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Smooth Edit, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSmoothEdit() const;

	// Set smoothing editing mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Smooth Edit, Sets a specify value to current class CFOPathShape
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void SetSmoothEdit(const BOOL &bEnable);

	// Is current shape line shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLine() const;

	// Is current shape free handle line shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Free Hand, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFreeHand() const;

	// Is current shape bezier line shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bezier, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsBezier() const;

	// Is current shape spline shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Spline, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSpline() const;

	// Hit test if a point within the path shape or just hit the border of the shape.
	// rPnt -- hit test point.
	// nExpand -- expand for testing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Hit, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		nExpand---nExpand, Specifies a USHORT nExpand object(Value).
	CFODrawShape *CheckHit(const FOPPoint& ptPnt, USHORT nExpand) const;

	// Check if this is the correct point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Be Can Connect, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPnt---&ptPnt, Specifies A integer value.
	BOOL CheckBeCanConnect(const FOPPoint &ptPnt);

	// Obtain the connecting polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Connect Polygon, Returns the specified value.
	//		Returns a pointer to the object FOPSimplePolygon ,or NULL if the call failed
	FOPSimplePolygon *GetConnectPoly();

	// Get close.
	BOOL GetClose() { return m_bClosedObj; }

	// Set close.
	void SetClose(const BOOL &bClose);

	// Update poly points.
	void UpdatePolys();


public:

	// Connect lines.
	// pptPoints -- points
	// nCount -- count of line points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	BOOL ConnectLines(LPPOINT pptPoints, int nCount);

	// Connect lines.
	// ptArray -- points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	BOOL ConnectLines(CArray<CPoint,CPoint>* ptArray);

	// Connect the bezier line shape from points.
	// ptArray -- points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Bezier Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	BOOL ConnectBezierLine(CArray<CPoint,CPoint>* ptArray);

	// Connect arc line
	// ptStart -- start point of arc.
	// ptEnd -- end point of arc.
	// nWidth -- the width of arc curve.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Arc Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	BOOL ConnectArcLine(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	// Connect a new bezier or arc, etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Polygon, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&poly---Specifies a const FOPSimplePolygon &poly object(Value).
	BOOL ConnectPolygon(const FOPSimplePolygon &poly);

	// Add sub path.
	// poly -- children path for adding.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Child Path, Adds an object to the specify list.
	// Parameters:
	//		&poly---Specifies a const FOPSimplePolygon &poly object(Value).
	void AddSubPath(const FOPSimplePolygon &poly);

	// Combine new path.
	// path -- path data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Path, Adds an object to the specify list.
	// Parameters:
	//		&path---Specifies a const FOPSimpleCompositePolygon &path object(Value).
	void AddPath(const FOPSimpleCompositePolygon &path);

	// Remove sub path.
	// pathIndex -- index of path segment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Child Path, Call this function to remove a specify value from the specify object.
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		&pathIndex---&pathIndex, Specifies A integer value.
	FOPSimplePolygon RemoveSubPath(const int &pathIndex);

	// Get the number of sub paths in the path
	// return The number of sub paths in the path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Path Count, Returns the specified value.
	//		Returns a int type value.
    int GetSubPathCount() const;

	// Get the number of points in a sub path
	// return The number of points in the sub path or -1 if subpath out of bounds
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count Subpath, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		subpathIndex---subpathIndex, Specifies A integer value.
    int GetPointCountSubpath( int subpathIndex ) const;

	// Close sub path.
	// The subpath is closed be inserting a segment between the start and end point, makeing
    // the given point the new start point of the subpath.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Subpath, .
	// Parameters:
	//		subpathIndex---subpathIndex, Specifies A integer value.
	void CloseSubpath( int subpathIndex );

public:

	// Is close possible.
	// ptStart -- start point.
	// ptEnd -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Close Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	BOOL IsClosePossible(const CPoint &ptStart, const CPoint &ptEnd);

	// Is offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nHitSpot---Hit Spot, Specifies A integer value.  
	//		&ptNew---&ptNew, Specifies A CPoint type value.
	BOOL XOffsetPoint(const int &nHitSpot, const CPoint &ptNew);

	// Update ports of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Ports, Call this member function to update the object.
	// Parameters:
	//		&rcSave---&rcSave, Specifies A CRect type value.
	void UpdatePorts(const CRect &rcSave);

	// Obtain the control handle with a specify index.
	// nIndexHandle -- index of th handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nIndexHandle---Index Handle, Specifies A integer value.
	virtual CFOPHandle* GetHandle(int nIndexHandle) const;

	// Obtain the extend control handle.
	// aHandle -- handle object.
	// nIndexPt -- index of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extend Handle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		aHandle---aHandle, Specifies a const CFOPHandle& aHandle object(Value).  
	//		nExtNum---Extend Number, Specifies A integer value.
	virtual CFOPHandle* GetExtendHandle(const CFOPHandle& aHandle, int nExtNum) const;

	// Add to handle list.
	// lstHandle -- list of the handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Handle List, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void AddToHdlList(CFOPHandleList& lstHandle) const;

	// Close current shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Close Shape, Do a event. 
	// Parameters:
	//		bClose---bClose, Specifies A Boolean value.
	void DoCloseShape(BOOL bClose);

	// Hit test the shape.
	// ptHit -- hit test point.
	// nLength -- extend value to hit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Hit, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A integer value.  
	//		nLength---nLength, Specifies A integer value.
	virtual CFODrawShape* CheckHit(const FOPPoint& ptHit, int nLength) const;

	// Take polygon of the shape.
	// aSimplePoly -- do generate track polygon.
	// bDetail -- detail or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Track Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aSimplePoly---Simple Polygon, Specifies a FOPSimpleCompositePolygon& aSimplePoly object(Value).  
	//		bDetail---bDetail, Specifies A Boolean value.
	virtual void DoGenTrackPoly(FOPSimpleCompositePolygon& aSimplePoly, BOOL bDetail) const;

	// Obtain the total plus handle of the shape
	// nPolyIndex -- number of polygon.
	// nPt -- index of point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extend Handle Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPt---nPt, Specifies A integer value.
	virtual int GetExtendHandleCount(int nPolyIndex,int nPt) const;

	// Change point to a new point.
	// nIndexHandle -- index of handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point New, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nIndexHandle---Index Handle, Specifies A integer value.
	virtual const FOPPoint& GetPointNew(int nIndexHandle) const;

	// Change point
	// ptPt -- point value to set.
	// nIndexHandle -- index of handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Point, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptPt---ptPt, Specifies A integer value.  
	//		nIndexHandle---Index Handle, Specifies A integer value.
	virtual void DoChangePoint(const FOPPoint& ptPt, int nIndexHandle);

	// Insert point
	// ptPos -- insert point.
	// bNew -- new or not
	// bHide -- hide or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Insert Point New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		ptPos---ptPos, Specifies A integer value.  
	//		bNewObj---New Object, Specifies A Boolean value.  
	//		bHide---bHide, Specifies A Boolean value.  
	//		rInsNextAfter---Ins Next After, Specifies A Boolean value.
	virtual int DoInsertPointNew(const FOPPoint& ptPos, BOOL bNewObj, BOOL bHide, BOOL& rInsNextAfter);

	// Insert point
	// nIndex -- index of point to be inserted.
	// ptPos -- insert point.
	// bAfter -- after or not.
	// bNew -- new or not.
	// bHide -- hide or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Insert Point New X, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptPos---ptPos, Specifies A integer value.  
	//		bAfter---bAfter, Specifies A Boolean value.  
	//		bNew---bNew, Specifies A Boolean value.  
	//		bHide---bHide, Specifies A Boolean value.
	virtual int DoInsertPointNewX(int nIndex, const FOPPoint& ptPos, BOOL bAfter, BOOL bNew, BOOL bHide);

	// Delete point
	// nIndex -- index of the point that to be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Delete Point New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL DoDeletePointNew(int nIndex);

	// Do shear shape.
	// ptRef -- reference point for shear.
	// dTan -- tan value of the angle.
	// bVShear -- is vertical shear or horz shear.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shear, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptRef---ptRef, Specifies A integer value.  
	//		dTan---dTan, Specifies a double dTan object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	virtual BOOL DoShear(const FOPPoint& ptRef, double dTan, BOOL bVShear);

	// Rip point
	// nIndex -- index of point to rip.
	// nNew -- new position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rip Point New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nNew---nNew, Specifies A integer value.
	virtual CFODrawShape* DoRipPointNew(int nIndex, int& nNew);

	// Is rip point possible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rip Point Possible, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	virtual BOOL IsRipPointPossible(const int &nIndex);

	// Change the shape's polygon.
	// aPathPoly -- path polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Path Polygon, .
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	void ChangePathPolygon(const FOPSimpleCompositePolygon& aPathPoly);

	// Change path polygon
	// aPathPoly -- path polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Path Polygon, Do a event. 
	// Parameters:
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	void DoChangePathPolygon(const FOPSimpleCompositePolygon& aPathPoly);

	// Drawing shape
	// pDC -- pointer of the dc.
	// aPathPoly -- path polygon.
	// bFill -- fill the polygon or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Draw Polygon Polygon, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPathPoly---Path Polygon, Specifies a const FOPPolyPolygon& aPathPoly object(Value).  
	//		&bFill---&bFill, Specifies A Boolean value.
	void FODrawPolyPolygon(CDC *pDC,const FOPPolyPolygon& aPathPoly,const BOOL &bFill = TRUE, const BOOL &bTrack = FALSE);

	// Drawing shape
	// pDC -- pointer of the CDC.
	// pPoints -- points for drawing.
	// pPtAry -- points
	// bFill -- fill the shape or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon Polygon, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoly---nPoly, Specifies A 32-bit LONG signed integer.  
	//		pPoints---pPoints, A pointer to the const ULONG or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the FOPCONSTPOINT or NULL if the call failed.  
	//		&bFill---&bFill, Specifies A Boolean value.
	void DrawPolyPolygon(CDC *pDC,ULONG nPoly, const ULONG* pPoints, FOPCONSTPOINT* pPtAry,const BOOL &bFill = TRUE, const BOOL &bTrack = FALSE);

	// Draw shape
	// pDC -- pointer of the DC.
	// aCompPoly -- polygon for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Draw Polygon Polygon Shadow, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
	void FODrawPolyPolygonShadow(CDC *pDC,const FOPPolyPolygon& aCompPoly);

	// Draw shape.
	// pDC -- pointer of the DC.
	// nPoly -- number of the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon Polygon Shadow, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoly---nPoly, Specifies A 32-bit LONG signed integer.  
	//		pPoints---pPoints, A pointer to the const ULONG or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the FOPCONSTPOINT or NULL if the call failed.
	void DrawPolyPolygonShadow(CDC *pDC,ULONG nPoly, const ULONG* pPoints, FOPCONSTPOINT* pPtAry);

	// Toggle close the shape.
	// nDis -- distance to open
	// bOpen -- close or open
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Close Shape New, Do a event. 
	// Parameters:
	//		&bOpen---&bOpen, Specifies A Boolean value.  
	//		nDis---nDis, Specifies A 32-bit long signed integer.
	void DoCloseShapeNew(const BOOL &bOpen,long nDis);

	// Convert segment of the point.
	// nPolyIndex -- index of polygon that need to be converted.
	// nPtIndex -- index of point that need to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Segment, .
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.
	void ConvertSegment(int nPolyIndex,int nPtIndex);

	// Change the point's smooth flag.
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nFlag -- smooth flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Smooth Flag, Sets a specify value to current class CFOPathShape
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nFlag---nFlag, Specifies a FOPSimplePolyFlags nFlag object(Value).
	void SetSmoothFlag(int nPolyIndex,int nPtIndex, FOPSimplePolyFlags nFlag);

	// Change smooth flag of the point.
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nFlag -- smooth flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Smooth Flag, Do a event. 
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nFlag---nFlag, Specifies a FOPSimplePolyFlags nFlag object(Value).
	void DoChangeSmoothFlag(int nPolyIndex,int nPtIndex, FOPSimplePolyFlags nFlag);

	// Obtain the smooth flag.
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Smooth Flag, Returns the specified value.
	//		Returns A FOPSimplePolyFlags value (Object).  
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.
	FOPSimplePolyFlags GetSmoothFlag(int nPolyIndex,int nPtIndex) const;

	// Is current segment can be converted,it will return one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Convert Segment, .
	//		Returns A fopPathType value (Object).  
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.
	fopPathType CanConvertSegment(int nPolyIndex,int nPtIndex) const;

	// Obtain the segment type,it will return one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment Type, Returns the specified value.
	//		Returns A fopPathType value (Object).  
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.
	fopPathType GetSegmentType(int nPolyIndex,int nPtIndex) const;
	
	// Convert segment of the shape
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nType -- type of the path,it must be one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	// bIgnoreSmooth -- ignore smooth or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Segment, .
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nType---nType, Specifies a fopPathType nType object(Value).  
	//		bIgnoreSmooth---Ignore Smooth, Specifies A Boolean value.
	void ConvertSegment(int nPolyIndex,int nPtIndex, fopPathType nType, BOOL bIgnoreSmooth = FALSE);

	// Convert segment of the shape
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nType -- type of the path,it must be one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	// bIgnoreSmooth -- ignore smooth or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment, Do a event. 
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPtIndex---Point Index, Specifies A integer value.  
	//		nType---nType, Specifies a fopPathType nType object(Value).  
	//		bIgnoreSmooth---Ignore Smooth, Specifies A Boolean value.
	void DoConvertSegment(int nPolyIndex,int nPtIndex, fopPathType nType, BOOL bIgnoreSmooth = FALSE);

	// Convert all the segments of the shape
	// nPathType -- type of the path,it must be one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert All Segments, .
	// Parameters:
	//		nPathType---Path Type, Specifies a fopPathType nPathType object(Value).
	void ConvertAllSegments(fopPathType nPathType);

	// Refresh all segments.
	void RefreshAllSegs();

	// Convert a specify segment of the shape.
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nPathType -- type of the path,it must be one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	// bIgnoreSmooth -- ignore smooth or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment New, Do a event. 
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPointNum---Point Number, Specifies A integer value.  
	//		nPathType---Path Type, Specifies a fopPathType nPathType object(Value).  
	//		bIgnoreSmooth---Ignore Smooth, Specifies A Boolean value.
	void DoConvertSegmentNew(int nPolyIndex, int nPointNum, fopPathType nPathType, BOOL bIgnoreSmooth);

	// Change point smooth flag.
	// nPolyIndex -- index of polygon.
	// nPtIndex -- index of point.
	// nFlag -- flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Set Smooth, .
	// Parameters:
	//		nPolyIndex---Polygon Index, Specifies A integer value.  
	//		nPointNum---Point Number, Specifies A integer value.  
	//		nFlag---nFlag, Specifies a FOPSimplePolyFlags nFlag object(Value).
	void ReSetSmooth(int nPolyIndex, int nPointNum, FOPSimplePolyFlags nFlag);

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current point handle,if it is true,it will returns the handle index.
	// nIndex -- index of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Current Point Handle, Determines if the given value is correct or exist.
	//		Returns a int type value.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	int IsCurrentPointHandle(const int &nIndex);

	// Delete a specify point.
	// nIndex -- index of the point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Point, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL		DeletePoint(int nIndex);

	//////////////////////////////////////////////////
	// Insert a new point.
	// nIndex -- index of the insert position.
	// point -- new insert point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Point, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		point---Specifies A CPoint type value.
	virtual BOOL		InsertPoint(int nIndex, const CPoint& point);

	// Obtain the snap point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Point Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSnapPointCount() const;

	// Obtain the snap point.
	// nIndex -- index of the snap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual FOPPoint GetSnapPoint(int nIndex) const;

	// Obtain the handle count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetHandleCount() const;

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Force shape style kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Sort Kind, .

	void ReSortKind();

	// Create beizer polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Beizer Polygon, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A CPoint type value.  
	//		&ptCtrl1---&ptCtrl1, Specifies A CPoint type value.  
	//		&ptCtrl2---&ptCtrl2, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	FOPSimplePolygon CreateBeizerPoly(const CPoint& ptStart,const CPoint &ptCtrl1,
		const CPoint &ptCtrl2,const CPoint &ptEnd);

	// Get object style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Style, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetShapeStyle() const;

	// Create spiral.
	void CreateSpiral(const FOPRect &rcDraw, const BOOL &bClockWise = TRUE, const double &dFace = 0.9);

	// Create shape with style.
	void SetShapeStyle(const int &nType) { m_nShapeType = (FOPShapeKind)nType; }

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// calculate the correct index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Correct Index, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nInput---&nInput, Specifies A integer value.
	virtual int CalcCorrectIndex(const int &nInput);


	// calculate the correct index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Best Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&nInput---&nInput, Specifies A integer value.
	virtual CPoint GetBestPoint(const int &nInput);

	// Get the sport point of control by edit point,override this method to calc your own new control handle.
	// mpSpot -- control handles list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPointSpotLocation(CFOPHandleList& lstHandle);

	// Op.
	// Offset a specify point.
	// nIndex -- the spot index.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Op.
	// Offset a specify point.
	// nIndex -- the spot index.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPath(CFOPMarkList &maMark, CPoint ptOffset);

	// Get marks in rectangle.
	void GetMarksInRect(CFOPMarkList &arPoints, FOPRect &rc);

	// Offset the current track point.
	// nIndex -- index of the track point.
	// ptOffset -- offset point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current track point.
	// nIndex -- index of the track point.
	// ptOffset -- offset point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPath(CFOPMarkList &maMark, CPoint ptOffset);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Offset all track points.
	// ptOffset -- offset point value.
	// ptScroll -- currently not used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Obtain current shape's closed state.
	// Return values are below:
	// 0 -- no care.
	// 1 -- open
	// 2 -- closed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Closed State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetClosedState() const;
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeCircularShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetSimpleValue(const double &dValue);
	

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPathShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPathShape& src object(Value).
	CFOPathShape& operator=(const CFOPathShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the moving tracker line of the shape only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Move Track, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawMoveTrack(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	void DoDrawLineOnly(CDC *pDC);
	void DoDrawPolygonOnly(CDC *pDC);

	void DoGenLineGeo(CFOArea *pArea);
	void DoGenPolyGeo(CFOArea *pArea);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

public:
	/*************************************************************************
	|*
	|* Geo data of the shape.
	|*
	\************************************************************************/

	// Create a new copy of data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Geogmetry Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPObjGeoData,or NULL if the call failed
	virtual FOPObjGeoData* NewGeoData() const;

	// Create copying of the Geometry data of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Geogmetry Data, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aData---aData, Specifies a FOPObjGeoData& aData object(Value).
	virtual void CopyGeoData(FOPObjGeoData& aData) const;

	// Rest the Geometry data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rest Geogmetry Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aData---aData, Specifies a const FOPObjGeoData& aData object(Value).
	virtual void RestGeoData(const FOPObjGeoData& aData);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Obtain the simple polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Polygon Object, Returns the specified value.
	//		Returns A FOPSimpleCompositePolygon value (Object).
	FOPSimpleCompositePolygon *GetXPolyObject() { return &m_aPathPolygon; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get X Polygon Object, Returns the specified value.
	//		Returns A FOPSimpleCompositePolygon value (Object).
	FOPSimpleCompositePolygon *GetXNewPolyObject() { return &m_aPathPolygon; }

	// Obtain the composite of the shape.
	// aPoly -- simple composite polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& aPoly) const;

	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOPathShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }


	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOPathShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Is current point validate control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid  Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	BOOL IsValidControlPoint(const int &nIndex);

	// Obtain handle index informations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Information, Returns the specified value.
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&bIsControl---Is , Specifies A Boolean value.  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.  
	//		bAll---bAll, Specifies A Boolean value.
	void GetControlInformation(const int &nIndex, BOOL &bIsControl, int &nPoly, int &nPoint, BOOL bAll = FALSE);

	// Is current point validate control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid  Point, Returns the specified value.
	// Parameters:
	//		&nCurIndex---Current Index, Specifies A integer value.  
	//		&nIndex---&nIndex, Specifies A integer value.
	void GetValidControlPoint(const int &nCurIndex,int &nIndex);

	// Is current point can be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Delete Point Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	BOOL IsDeletePointPossible(const int &nIndex);

	// Is current point can be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Delete Point Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL IsDeletePointPossible(const int &nPoly, const int &nPoint);

	// Get valid insert point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Insert Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPnt---&nPnt, Specifies A integer value.
	BOOL IsValidInsertPoint(const int &nIndex, const int &nPoly, const int &nPnt);

	// Get valid insert point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Insert Point, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptInsert---&ptInsert, Specifies A CPoint type value.  
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL GetValidInsertPoint(CPoint &ptInsert,const int &nIndex, const int &nPoly, const int &nPoint);

	// Get valid segment of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Segment Point, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&poly---Specifies a FOPPolygon &poly object(Value).  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL GetValidSegmentPoint(FOPPolygon &poly, const int &nPoly, const int &nPoint);

	// Get segment of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment Point, Returns the specified value.
	// Parameters:
	//		<CPoint---C Point, Specifies A CArray array.  
	//		&maPoints---&maPoints, Specifies A CPoint type value.  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	void GetSegmentPoint(CArray <CPoint, CPoint> &maPoints, const int &nPoly, const int &nPoint);

	// Is change segment kind possible.
	// nIndex -- index of handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Change Segment Kind Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL IsChangeSegmentKindPossible(const int &nPoly, const int &nPoint);

	// Is approx;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Approx, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		x---Specifies a double x object(Value).  
	//		y---Specifies a double y object(Value).
	BOOL IsApprox(double x, double y);

	// Calculate other middle two points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Other Two Points, .
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&ptMiddle1---&ptMiddle1, Specifies A CPoint type value.  
	//		&ptMiddle2---&ptMiddle2, Specifies A CPoint type value.
	void CalcOtherTwoPoints(const CPoint &ptStart,const CPoint &ptEnd,CPoint &ptMiddle1,CPoint &ptMiddle2);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

protected:


	// Simple composite polygon of the shape.
	FOPComplexGeometry m_TmpGeo;

	// Path Polygon, This member specify FOPSimpleCompositePolygon object.  
	FOPSimpleCompositePolygon	m_aPathPolygon;

	FOPPolyPolygon			maDrawPolyPoly;

	// Shape style kind.
 
	// Shape Type, This member specify FOPShapeKind object.  
	FOPShapeKind				m_nShapeType;

	// Is current shape close or not.
 
	// Closed Object, This member sets TRUE if it is right.  
	BOOL						m_bClosedObj;

	// Save rectangle position.
 
	// Save Position, This member sets a CRect value.  
	CRect						m_rcSavePos;

	// Current tracking handle.
 
	// Current Track Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nCurTrackHandle;

	// Is all the same.
 
	// Is All The Same, This member sets TRUE if it is right.  
	BOOL						m_bIsAllTheSame;

};

#endif // !defined(AFX_FOPOLYGONSHAPE_H__958CDCD3_C5C6_11D5_A487_525400EA266C__INCLUDED_)
