//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPGDIPLUSPROXY_H__12DD7E81_2DFC_4773_91E8_AE16AF93F1C7__INCLUDED_)
#define AFC_FOPGDIPLUSPROXY_H__12DD7E81_2DFC_4773_91E8_AE16AF93F1C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include "FOPVisualProxy.h"

// Drawing text helper string.
class CFOPWideCharString : public CObject  
{
public:
	CFOPWideCharString();
	CFOPWideCharString(const CFOPWideCharString& wcString);
	CFOPWideCharString(LPCWSTR widestring, int len=-1);
	CFOPWideCharString(const char* lpszString, int len=-1);
	virtual ~CFOPWideCharString();
	operator LPCWSTR() const {	return m_pBuffer; }
	
	int GetLength() const { return m_nBufferLen; }
	
	CFOPWideCharString operator + (const CFOPWideCharString& wcString);
	CFOPWideCharString& operator += (const CFOPWideCharString& wcString);
	WCHAR	operator[](int index) const;
	WCHAR&	operator[](int index);
	
	CFOPWideCharString& operator = (const CFOPWideCharString& wcString);
	CFOPWideCharString& operator = (const char* lpszString);
	BOOL operator == (const CFOPWideCharString& wcString);
	BOOL operator != (const CFOPWideCharString& wcString);
	CFOPWideCharString Mid(int begin,int len=-1);
	
private:
	WCHAR*	m_pBuffer;
	int		m_nBufferLen;
};

Status FOP_DrawString(Gdiplus::Graphics *graphics, const TCHAR *str, const Gdiplus::Font &font, const Brush &brush, const PointF &origin);
Status FOP_DrawString(Gdiplus::Graphics *graphics, const TCHAR *str, const Gdiplus::Font &font, const Brush &brush, const PointF &origin, StringFormat &fmt);
Status FOP_DrawString(Gdiplus::Graphics *graphics, const TCHAR *str, const Gdiplus::Font &font, const Brush &brush, const Point &origin);
Status FOP_DrawString(Gdiplus::Graphics *graphics, const TCHAR *str, const Gdiplus::Font &font, const Brush &brush, const RectF &rect, StringFormat &fmt);
Status FOP_DrawString(Gdiplus::Graphics *graphics, const TCHAR *str, const Gdiplus::Font &font, const Brush &brush, const Rect &rect, StringFormat &fmt);
  
//===========================================================================
// Summary:
//     The CFOPGDIPlusProxy class derived from CFOPVisualProxy
//      F O P G D I Plus Proxy
//===========================================================================

class CFOPGDIPlusProxy : public CFOPVisualProxy  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPGDIPlusProxy---F O P G D I Plus Proxy, Specifies a E-XD++ CFOPGDIPlusProxy object (Value).
	DECLARE_DYNCREATE(CFOPGDIPlusProxy);
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P G D I Plus Proxy, Constructs a CFOPGDIPlusProxy object.
	//		Returns A  value (Object).
	CFOPGDIPlusProxy();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P G D I Plus Proxy, Destructor of class CFOPGDIPlusProxy
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGDIPlusProxy();

public:

	// Attach DC.
	virtual void AttachDC(CDC* pDC);

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Input transparent value.
	// nTrans -- transparent value from 0-255
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Transparent, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.
	virtual void PrepareTransX(const BYTE &nTrans);

	// Is gdi plus or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is G D I Plus, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsGDIPlus();

	// ----------------------------------------------------------------------
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPGDIPlusProxy object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bWithGDIPlus---With G D I Plus, Specifies A Boolean value.
	// Create draw context.
	virtual void Create(const BOOL &bWithGDIPlus);
	
	// ----------------------------------------------------------------------
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release C, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseC();

	// Obtain GDI+ Drawing state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get G D I Plus, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetGDIPlus();

	// Prepare graphics object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Graphics, .
	// Parameters:
	//		*pGraphics---*pGraphics, A pointer to the Graphics  or NULL if the call failed.
	void PrepareGraphics(Graphics *pGraphics);

public:
	/*************************************************************************
	|*
	|* Override the following methods to handle your own fill type.
	|* You can SetBrushType(...) that defined within class CFODrawShape to change the fill type.
	|*
	\************************************************************************/
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Close Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillCloseBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillPoly(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		lpPolyCounts---Polygon Counts, Specifies a LPINT lpPolyCounts object(Value).  
	//		nCount---nCount, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual BOOL FillPolyPolygon(CDC *pDC,LPPOINT points,LPINT lpPolyCounts,int nCount,const CRect &rcPos,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Fills the can shape held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Can Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillCanShape(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Do draw upright circle.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	virtual BOOL FillCircle(CDC *pDC, const CRect &rcPos, COLORREF crStart, COLORREF crEnd, UINT nFillType, CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill rectangle.
	// pDC-- pointer of DC
	// rc -- rectangle of round rect.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies a FOPRect rc object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillRect(CDC *pDC, FOPRect rc,	COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill ellipse.
	// pDC-- pointer of DC
	// rc -- rectangle of ellipse.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Ellipse, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillEllipse(CDC *pDC, const FOPRect &rc, COLORREF crStart,COLORREF crEnd,
		UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill round rectangle.
	// pDC-- pointer of DC
	// rc -- rectangle of round rect.
	// ptCorner -- radius of corner
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Round Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		&ptCorner---&ptCorner, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillRoundRect(CDC *pDC, const FOPRect &rc, const FOPPoint &ptCorner,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Do circle drawing.
	void FODrawCircle(CDC *pDC, const BYTE &nTrans, const CRect& rect,
		BOOL bFill, COLORREF crStart, COLORREF crEnd, UINT nFillType);

	// Draw spline.
	// pDC -- pointer of DC.
	// spline -- spline object
	virtual void DoFillComplexGeometry(CDC *pDC, const FOPComplexGeometry &geometry, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Do draw bitmap.
	// pDC -- pointer of DC.
	// pBitmap -- pointer of bitmap.
	// rcPos -- position for drawing.
	// nImageWidth -- image width.
	// nImageHeight -- image height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bitmap, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pBitmap---*pBitmap, A pointer to the CFOBitmap  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		&nImageX---Image X, Specifies A integer value.  
	//		&nImageY---Image Y, Specifies A integer value.  
	//		&nImageWidth---Image Width, Specifies A integer value.  
	//		&nImageHeight---Image Height, Specifies A integer value.  
	//		&bTrans---&bTrans, Specifies A Boolean value.  
	//		&crTrans---&crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual void DoDrawBitmap(CDC *pDC, CFOBitmap *pBitmap, CRect rcPos, const int &nImageX, const int &nImageY,const int &nImageWidth, const int &nImageHeight,
		const BOOL &bTrans = FALSE, const COLORREF &crTrans = RGB(255,255,255), int nRotateAngle = 0);

	// Do draw poly bezier line.
	// pDC -- pointer of the DC.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw New Polygon Line Bezier, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE or NULL if the call failed.
	virtual BOOL	DrawNewPolyLineBezier(CDC *pDC, ULONG nPoints, const fopPointExt* pPtAry, const BYTE* pFlgAry );

	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill New Polygon Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	FillNewPolygonBezier(CDC *pDC, const CRect &rcPos, ULONG nPoints, const fopPointExt* pPtAry,
						const BYTE* pFlgAry, COLORREF crStart, COLORREF crEnd, UINT nFillType, CBrush *pBrush);

	// Do draw polypolygon bezier.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoly -- count of the poly for drawing.
	// nPoints -- count of the points.
	// pPoints -- points count
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon Polygon Bezier, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoly---nPoly, Specifies A 32-bit LONG signed integer.  
	//		pPoints---pPoints, A pointer to the const ULONG or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt* const or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE* const or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	DrawPolyPolygonBezier(CDC *pDC, const CRect &rcPos, ULONG nPoly, const ULONG* pPoints, const fopPointExt* const* pPtAry, 
						const BYTE* const* pFlgAry, COLORREF crStart, COLORREF crEnd, UINT nFillType, CBrush *pBrush);

	// Do draw polypolygon bezier.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoly -- count of the poly for drawing.
	// nPoints -- count of the points.
	// rPolyPoly -- object of the composite polygon
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill New Polygon Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoly---nPoly, Specifies a USHORT nPoly object(Value).  
	//		rPolyPoly---Polygon Polygon, Specifies a const FOPSimpleCompositePolygon& rPolyPoly object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual BOOL	FillNewPolyPolygon(CDC *pDC, const CRect &rcPos, USHORT nPoly, const FOPSimpleCompositePolygon& rPolyPoly,
						COLORREF crStart, COLORREF crEnd, UINT nFillType, CBrush *pBrush);

	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Polygon Draw, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the POINT or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the BYTE or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	ExtPolyDraw(CDC *pDC,
		const CRect &rcPos,
		ULONG nPoints, 
		POINT* pPtAry,
		BYTE* pFlgAry,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);
public:

	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawArrowLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	// Do draw arc line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Angle Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&startAngle---&startAngle, Specifies A float value.  
	//		&endAngle---&endAngle, Specifies A float value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bFill---&bFill, Specifies A Boolean value.
	virtual void DoDrawArrowAngleArcLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd,
		const int &nWidth,const float &startAngle,const float &endAngle,const COLORREF &crFill,const BOOL &bFill);


	// Do draw polygon.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawArrowPolygon(CDC *pDC,LPPOINT points,int nCount,const COLORREF &crFill);

	// Do draw text.
	// pDC -- pointer of DC.
	// lpszText -- text for drawing.
	// lpRect -- rectangle for drawing.
	// uFormat -- text alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&strText---&strText, Specifies A CString type value.  
	//		rcRect---rcRect, Specifies A CRect type value.  
	//		uFormat---uFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawText(CDC *pDC,const CString &strText, CRect rcRect, UINT uFormat);

public:

	/*************************************************************************
	|*
	|* Other methods you can override to handle your GUI look!
	|*
	\************************************************************************/

	// Draw helper functions.
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Shadow Close Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillShadowCloseBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CPoint ptOffset,CBrush *pBrush);

	// Draw tab order.
	// rcPos -- Position of tab order.
	// crColor -- COLORREF to fill.
	// strText -- Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tab Order, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		strText---strText, Specifies A CString type value.
	virtual void DoDrawTabOrder(CDC *pDC,const CRect &rcPos,const COLORREF &crColor,CString strText);

	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	// Draw beizer line.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawBezierLine(CDC *pDC,LPPOINT points,int nCount);

	// Do draw custom port style.
	// pDC-- DC's pointer.
	// ptPort -- center point of port.
	// nPortWidth -- port width.
	// nPortHeight -- port height.
	// crStart -- start color.
	// crEnd -- end color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Port, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptPort---&ptPort, Specifies A CPoint type value.  
	//		&nPortWidth---Port Width, Specifies A integer value.  
	//		&nPortHeight---Port Height, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nBrushType---Brush Type, Specifies A integer value.  
	//		nPortType---Port Type, Specifies A integer value.
	virtual void DoDrawCustomPort(CDC *pDC,const CPoint &ptPort,const int &nPortWidth,const int &nPortHeight,
	COLORREF crStart, COLORREF crEnd, int nBrushType,int nPortType);

	// Draw custom port tracker line.
	// pDC-- DC's pointer.
	// ptPort -- center point of the port.
	// nPortWidth -- width of the port.
	// nPortHeight -- height of the port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Track Port, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptPort---&ptPort, Specifies A CPoint type value.  
	//		&nPortWidth---Port Width, Specifies A integer value.  
	//		&nPortHeight---Port Height, Specifies A integer value.
	virtual void DoDrawCustomTrackPort(CDC *pDC,const CPoint &ptPort,
		const int &nPortWidth,const int &nPortHeight);

	// Do draw arc line.
	// pDC-- DC's pointer.
	// rect -- rectangle of the arc.
	// ptStart -- start point of the arc line.
	// ptEnd -- end point of the arc line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawArcLine(CDC *pDC,const CRect &rect,const CPoint &ptStart,
		const CPoint &ptEnd);

	// Draw poly line.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolyLine(CDC *pDC,LPPOINT points,int nCount);

	// Draw PolyPolygon.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		lpPoly---lpPoly, Specifies a LPINT lpPoly object(Value).  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolyPolygon(CDC *pDC,LPPOINT points,LPINT lpPoly,int nCount);


	// Draw Polygon.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolygon(CDC *pDC,LPPOINT points,int nCount);

	// Do text out method
	// pDC -- pointer of the DC.
	// ptText -- text output point.
	// strText -- textout text label.
	// nLength -- length of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void DoDrawTextOut(CDC *pDC,const CPoint &ptText,const CString &strText,const int &nLength);

	// Do render drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Do Render Path G, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE or NULL if the call failed.
	void FOPDoRenderPathG(CDC *pDC, ULONG nPoints, const BYTE &nTrans, const fopPointExt* pPtAry, const BYTE* pFlgAry );

	// Do poly drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Draw G, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.  
	//		lppt---Specifies A LPPOINT Points array.  
	//		lpbTypes---lpbTypes, Specifies An 8-bit BYTE integer that is not signed.  
	//		cCount---cCount, Specifies A integer value.  
	//		bFill---bFill, Specifies A Boolean value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void FOPPolyDrawG(CDC *pDC, const BYTE &nTrans, CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount,
		BOOL bFill, COLORREF crStart, COLORREF crEnd, UINT nFillType);

	//--(GDI+ SUPPORTS)---
	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Polygon Draw, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the POINT or NULL if the call failed.  
	//		lpbTypes---Flag Array, A pointer to the BYTE or NULL if the call failed.  
	//      cCount -- point count
	//      bClose -- close or not
    virtual BOOL	ExtPolyDrawLine(CDC *pDC, CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount, const BOOL &bClose);
	
	// Do fill polygon.
	// pts -- points.
	// nCount -- count of points
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pts---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_FillPolygon(CDC *pDC, POINT* pts, int nCount,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);

	// Do fill ellipse.
	// lpRect -- rectangle.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Ellipse, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_Ellipse(CDC *pDC, LPCRECT lpRect,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);

	//--(GDI+ SUPPORTS)---
	// Do fill rectangle.
	// lpRect -- rectangle.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_Rect(CDC *pDC, LPCRECT lpRect,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Do fill round rectangle.
	// lpRect -- rectangle.
	// ptCorner -- corner point.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_RoundRect(CDC *pDC, LPCRECT lpRect,CPoint ptCorner, const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	// Draw curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// pTypes -- types.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		pTypes---pTypes, A pointer to the BYTE or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void S_DrawCurve(CDC *pDC, POINT* lppt, BYTE* pTypes, int nCount, const BOOL &bClose = FALSE);

	// Draw close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// pTypes -- types.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		pTypes---pTypes, A pointer to the BYTE or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void S_DrawCloseCurve(CDC *pDC, POINT* lppt, BYTE* pTypes, int nCount, const CRect &rcPos,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Draw close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void DoDrawExtCloseCurve(CDC *pDC, POINT* lppt, int nCount, const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Draw track close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	virtual void DoDrawExtTrackCurve(CDC *pDC, POINT* lppt, int nCount);

	// Generate close curve points.
	virtual void GenSplinePoints(LPPOINT lpShapePoints, int nPointCount, 
		LPPOINT& lpSplinePoints, int& nSpPtCount);

	// Create brush
	virtual	Brush*				CreatePathBrush(RectF rect);

	// Create brush
	virtual	Brush*				CreateRadialBrush(RectF rect);
	LPVOID GetGP(CDC *pDC);
protected:

	LPVOID			m_pGraphics;
	CDC * m_pCurDC;
	// transparent value
 
	// Transparent, This member sets An 8-bit integer that is not signed.  
	BYTE		m_nTransparent;

	// With GDI+ drawing.
 
	// With G D I Plus, This member sets TRUE if it is right.  
	BOOL		m_bWithGDIPlus;
};


#endif // !defined(AFC_FOPGDIPLUSPROXY_H__12DD7E81_2DFC_4773_91E8_AE16AF93F1C7__INCLUDED_)
