//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOOrderSingleAction.h: interface for the CFOOrderSingleAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOORDERSINGLEACTION_H__5D3EDD19_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOORDERSINGLEACTION_H__5D3EDD19_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
///////////////////////////////////////////////////////////////////
// 
// Define for class CFODrawShapeArray
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFODrawShapeArray class derived from CObArray
//      F O Draw Shape Array
//===========================================================================

class FO_EXT_CLASS CFODrawShapeArray : public CObArray
{
public:

	// get a shape at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFODrawShape* GetAt(int nIndex) const
	{ return (CFODrawShape*)CObArray::GetAt(nIndex); }

	// get an element at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Element At, .
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFODrawShape*& ElementAt(int nIndex)
	{ return (CFODrawShape*&)CObArray::ElementAt(nIndex); }

	// insert 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		nStartIndex---Start Index, Specifies A integer value.  
	//		pNewArray---New Array, A pointer to the CFODrawShapeArray or NULL if the call failed.
	void InsertAt(int nStartIndex, CFODrawShapeArray* pNewArray)	   
	{ CObArray::InsertAt(nStartIndex, pNewArray); }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFODrawShape* operator[](int nIndex) const
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	{ return (CFODrawShape*)CObArray::operator[](nIndex); }
	
	CFODrawShape*& operator[](int nIndex)
	{ return (CFODrawShape*&)CObArray::operator[](nIndex); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Append, .
	//		Returns a int type value.  
	// Parameters:
	//		src---Specifies a const CFODrawShapeArray& src object(Value).
	// append source
	int Append(const CFODrawShapeArray& src)	   
	{ return (int)CObArray::Append(src); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// Parameters:
	//		src---Specifies a const CFODrawShapeArray& src object(Value).
	// copy source
	void Copy(const CFODrawShapeArray& src)		
	{ CObArray::Copy(src); }

	// set 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At, Sets a specify value to current class CFODrawShapeArray
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptr---A pointer to the CFODrawShape or NULL if the call failed.
	void SetAt(int nIndex, CFODrawShape* ptr)		
	{ CObArray::SetAt(nIndex, (CObject*) ptr); }

	// set
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At Grow, Sets a specify value to current class CFODrawShapeArray
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		newElement---newElement, A pointer to the CFODrawShape or NULL if the call failed.
	void SetAtGrow(int nIndex, CFODrawShape* newElement)	   
	{ CObArray::SetAtGrow(nIndex, (CObject*) newElement); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		newElement---newElement, A pointer to the CFODrawShape or NULL if the call failed.
	// add a new element
	int Add(CFODrawShape* newElement)
	{ return (int)CObArray::Add((CObject*) newElement); }

	// insert a new element at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		newElement---newElement, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.
	void InsertAt(int nIndex, CFODrawShape* newElement, int nCount = 1)		
	{ CObArray::InsertAt(nIndex, (CObject*) newElement, nCount); }
};

enum OrderFlag
{
	OrderNone,			// Order none.
	OrderFront,			// Order front.
	OrderBack,			// Order back.
	OrderForward,		// Order forward.
	OrderBackward		// Order backward.
};

///////////////////////////////////////////////////////////////////
// 
// Define for class CFOOrderSingleAction -- action that order single shape.
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOOrderSingleAction class derived from CFOAction
//      F O Order Single Action
//===========================================================================

class FO_EXT_CLASS CFOOrderSingleAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOOrderSingleAction---F O Order Single Action, Specifies a E-XD++ CFOOrderSingleAction object (Value).
	DECLARE_ACTION(CFOOrderSingleAction)
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Order Single Action, Constructs a CFOOrderSingleAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOOrderSingleAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destuctor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Order Single Action, Destructor of class CFOOrderSingleAction
	//		Returns A  value (Object).
	~CFOOrderSingleAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOOrderSingleAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get orderment type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Order Type, Returns the specified value.
	// Parameters:
	//		nOrderment---nOrderment, Specifies a OrderFlag& nOrderment object(Value).
	void GetOrderType(OrderFlag& nOrderment) const;

	// Set orderment type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Order Type, Sets a specify value to current class CFOOrderSingleAction
	// Parameters:
	//		nOrderment---nOrderment, Specifies a OrderFlag nOrderment object(Value).
	void SetOrderType(OrderFlag nOrderment);

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;
	
	// The orderment type used to reposition shapes. 
 
	// Orderment, This member specify OrderFlag object.  
	OrderFlag m_nOrderment;

	// Order flag.
 
	// Old Orderment, This member specify OrderFlag object.  
	OrderFlag m_nOldOrderment;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOOrderSingleAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOOrderSingleAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////////////////
// 
// Define for class CFOChangeOrdNum -- change order number of shape action.
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOChangeOrdNum class derived from CFOAction
//      F O Change Ord Number
//===========================================================================

class FO_EXT_CLASS CFOChangeOrdNum : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOChangeOrdNum---F O Change Ord Number, Specifies a E-XD++ CFOChangeOrdNum object (Value).
	DECLARE_ACTION(CFOChangeOrdNum)
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Change Ord Number, Constructs a CFOChangeOrdNum object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOChangeOrdNum(CFODataModel* pModel,CFODrawShape *pShape);

	// Destuctor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Change Ord Number, Destructor of class CFOChangeOrdNum
	//		Returns A  value (Object).
	~CFOChangeOrdNum();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOChangeOrdNum
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get New Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Order Type, Returns the specified value.
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void GetNewOrderType(long& nOrder) const;

	// Set New Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Order Type, Sets a specify value to current class CFOChangeOrdNum
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void SetNewOrderType(long nOrder);

	// Get Old Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Order Type, Returns the specified value.
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void GetOldOrderType(long& nOrder) const;

	// Set Old Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Order Type, Sets a specify value to current class CFOChangeOrdNum
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void SetOldOrderType(long nOrder);

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;
	
	// The Order type used to reposition shapes. 
 
	// New Order, Specify a A 32-bit signed integer.  
	long			m_nNewOrder;

	// Order flag.
 
	// Old Order, Specify a A 32-bit signed integer.  
	long			m_nOldOrder;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOChangeOrdNum::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOChangeOrdNum::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////////////////
// 
// Define for class CFOExChangeOrdNum -- action that exchange the order number of shapes
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOExChangeOrdNum class derived from CFOAction
//      F O Ex Change Ord Number
//===========================================================================

class FO_EXT_CLASS CFOExChangeOrdNum : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOExChangeOrdNum---F O Ex Change Ord Number, Specifies a E-XD++ CFOExChangeOrdNum object (Value).
	DECLARE_ACTION(CFOExChangeOrdNum)
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Ex Change Ord Number, Constructs a CFOExChangeOrdNum object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOExChangeOrdNum(CFODataModel* pModel,CFODrawShape *pShape);

	// Destuctor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Ex Change Ord Number, Destructor of class CFOExChangeOrdNum
	//		Returns A  value (Object).
	~CFOExChangeOrdNum();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOExChangeOrdNum
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get New Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Order Type, Returns the specified value.
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void GetNewOrderType(long& nOrder) const;

	// Set New Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Order Type, Sets a specify value to current class CFOExChangeOrdNum
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void SetNewOrderType(long nOrder);

	// Get Old Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Order Type, Returns the specified value.
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void GetOldOrderType(long& nOrder) const;

	// Set Old Order type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Order Type, Sets a specify value to current class CFOExChangeOrdNum
	// Parameters:
	//		nOrder---nOrder, Specifies A 32-bit long signed integer.
	void SetOldOrderType(long nOrder);

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;
	
	// The Order type used to reposition shapes. 
 
	// New Order, Specify a A 32-bit signed integer.  
	long			m_nNewOrder;

	// Order flag.
 
	// Old Order, Specify a A 32-bit signed integer.  
	long			m_nOldOrder;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOExChangeOrdNum::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOExChangeOrdNum::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOORDERSINGLEACTION_H__5D3EDD19_F259_11DD_A433_525400EA266C__INCLUDED_)
