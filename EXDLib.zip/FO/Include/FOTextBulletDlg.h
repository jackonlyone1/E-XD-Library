//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTEXTBULLETDLG_H__47D67743_FE59_11D5_A4E6_525400EA266C__INCLUDED_)
#define AFX_FOTEXTBULLETDLG_H__47D67743_FE59_11D5_A4E6_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTextBulletDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOTextBulletDlg dialog
#include "FOPDropDownColorPickerButton.h"
#include "FOBulletTypeWnd.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOTextBulletDlg class derived from CDialog
//      F O Text Bullet Dialog
//===========================================================================

class FO_EXT_CLASS CFOTextBulletDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Text Bullet Dialog, Constructs a CFOTextBulletDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOTextBulletDlg(CWnd* pParent = NULL);   // standard constructor


	// Dialog Data
	//{{AFX_DATA(CFOTextBulletDlg)
	enum { IDD = IDD_FO_BULLET_DLG };
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndColor;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

 
	// Bulleted, This member specify E-XD++ CFOBulletTypeWnd object.  
	CFOBulletTypeWnd	m_wndBulleted;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Pattern color.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crColor;

	// Old color value.
 
	// Old Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crOldColor;

	//Brush Type
 
	// Bulleted Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nBulletedType;

	// Old bulleted type.
 
	// Old Bulleted Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nOldBulletedType;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL				m_bModify;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTextBulletDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOTextBulletDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillOK(WPARAM wParam, LPARAM lParam);
	//Select Day Cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillCancel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTEXTBULLETDLG_H__47D67743_FE59_11D5_A4E6_525400EA266C__INCLUDED_)
