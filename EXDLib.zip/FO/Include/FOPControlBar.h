//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCONTROLBAR_H__66294514_B340_4E51_9061_0E58C3930BF3__INCLUDED_)
#define AFX_FOPCONTROLBAR_H__66294514_B340_4E51_9061_0E58C3930BF3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPControlBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPControlBar window

#include "FOPDockBar.h"
#include "FOPMenuWndImpl.h"

#include "fodefines.h"
/////////////////////////////////////////////////////////////////////////////
// CFOPDrawDC

 
//===========================================================================
// Summary:
//     The CFOPDrawDC class derived from CDC
//      F O P Draw D C
//===========================================================================

class FO_EXT_CLASS CFOPDrawDC : public CDC  
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPDrawDC---F O P Draw D C, Specifies a E-XD++ CFOPDrawDC object (Value).
    DECLARE_DYNAMIC(CFOPDrawDC);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Draw D C, Constructs a CFOPDrawDC object.
	//		Returns A  value (Object).
	CFOPDrawDC();

	//-----------------------------------------------------------------------
	// Summary:
	// F O P Draw D C, Constructs a CFOPDrawDC object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
    CFOPDrawDC(CDC* pDC, const CRect& rect, const COLORREF &crColor);

	//-----------------------------------------------------------------------
	// Summary:
	// Create Extend D C, You construct a CFOPDrawDC object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual void CreateExtDC(CDC* pDC, const CRect& rect, const COLORREF &crColor);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Draw D C, Destructor of class CFOPDrawDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPDrawDC();
	
protected:

	// This member specify class object.  
	class Private;
	
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPControlBar window

class CFOPDockContext;
class CFOPGripButton;
 
//===========================================================================
// Summary:
//     The CFOPControlBar class derived from CControlBar
//      F O P  Bar
//===========================================================================

class FO_EXT_CLASS CFOPControlBar : public CControlBar
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPControlBar---F O P  Bar, Specifies a E-XD++ CFOPControlBar object (Value).
	DECLARE_SERIAL(CFOPControlBar)
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P  Bar, Constructs a CFOPControlBar object.
	//		Returns A  value (Object).
	CFOPControlBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P  Bar, Destructor of class CFOPControlBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPControlBar();

public:

	// Value
	CSize			m_szValue1;

	// Value
	CPoint			m_szValue2;

	// Value
	CSize			m_szValue3;

	// Value
	CSize			m_szValue4;

	// Value
	DWORD			m_dwValue1;

	// Value
	double			m_dValue1;

	// Value
	double			m_dValue2;

	// Value
	DWORD			m_dwValue2;

	// Value
	static BOOL		m_bValue1;

// Attributes
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPControlBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT & rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	// Create a new controlbar.
	// lpszClassName -- class name.
	// lpszWindowName -- window name
	// nID -- id of the controlbar
	// dwStyle -- style of the controlbar
	// dwExStyle -- extend controlbar style
	// rect -- rectangle of the window
	// pParentWnd -- pointer of the parent window
	// pContext -- null
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, UINT nID,
		DWORD dwStyle, DWORD dwExStyle, const RECT & rect, CWnd * pParentWnd = NULL,
		CCreateContext * pContext = NULL);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPControlBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	// Create a new controlbar.
	virtual BOOL Create(
		CWnd * pParentWnd, 
		LPCTSTR lpszWindowName, 
		DWORD dwStyle,
		DWORD dwExStyle,
		UINT nID, 
		CCreateContext * pContext = NULL
		);
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get Full Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcInside---&rcInside, Specifies A CRect type value.
	virtual void GetFullRect(CRect &rcInside) const;

	// Enable docking.
	// dwDockStyle -- dock style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Docking, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		dwDockStyle---Dock Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void EnableDocking(DWORD dwDockStyle);

	// Create dock context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Dock Context, You construct a CFOPControlBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDockContext ,or NULL if the call failed  
	// Parameters:
	//		void---void
	virtual CFOPDockContext * CreateDockContext(void);

	// Get bar extend style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ex Bar Style, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetExBarStyle() const	{ return m_dwValue2; };


	//-----------------------------------------------------------------------
	// Summary:
	//		Returns a UINT type value.  
	// Parameters:
	//		pMainWnd---Main Window, A pointer to the CFrameWnd  or NULL if the call failed.  
	//		nBaseID---Base I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static UINT MethodTempx1(CFrameWnd * pMainWnd, UINT nBaseID = 0x100);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
    virtual void DoPaint(
		// A CDC pointer that represents the current device context.
        CDC* pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw Borders, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
    virtual void DrawBorders(
		// A CDC pointer that represents the current device context.
        CDC* pDC,
		// A CRect reference that represents the border area to draw.
        CRect& rect);

	//-----------------------------------------------------------------------
	// Summary:
	void MethodTempx2();

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&nStyle---&nStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&rc---Specifies A CRect type value.
	void MethodTempx3(CDC *pDC, const DWORD &nStyle, const CRect &rc);

protected:

	//-----------------------------------------------------------------------
	// Do method
	void DoMethod1();
	
	//-----------------------------------------------------------------------
	// Do method
	void DoMethod2();

	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod3(CRect& rc, BOOL bHorz);

	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod4(CDC * pDC, CRect & rect);


	//-----------------------------------------------------------------------
	// Summary:
	// On Before Stretch, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		int&---Specifies A integer value.
	virtual void OnBeforeStretch(int& /*bSize*/) {}
	
	//-----------------------------------------------------------------------
	// Summary:
	// On After Stretch, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		int---Specifies A integer value.
	virtual void OnAfterStretch(int /*bSize*/) {}

	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod5(CDC * pDC, CRect & rect, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod5Up(CDC * pDC);

	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod6(CDC * pDC, CRect & rect, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Do method
	virtual void DoMethod6Up(CDC * pDC);

	// Do method
	virtual void DoMehtod7();

	// Do method
	virtual void DoMethod8();

	// Get color.
	virtual COLORREF GetColor1();

	// Do temp method.
	void DoTTMethod1(const CRect &rc,  BOOL bTemp);

	// Do temp method.
	void DoTTMethod2(CDC *pDC, const UINT &nTemp);

// Operations
public:

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPControlBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO  or NULL if the call failed.
	virtual INT_PTR OnToolHitTest(CPoint point, TOOLINFO * pTI) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CFrameWnd  or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
	virtual void OnUpdateCmdUI(CFrameWnd * pTarget, BOOL bDisableIfNoHndler);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Inside Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.  
	//		bHorz---bHorz, Specifies A Boolean value.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void CalcInsideRect(CRect & rect, BOOL bHorz, BOOL bVert = FALSE) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fixed Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		bStretch---bStretch, Specifies A Boolean value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Dynamic Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.  
	//		dwMode---dwMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual CSize CalcDynamicLayout(int nLength, DWORD dwMode);
	//}}AFX_VIRTUAL

public:
	//{{AFX_MSG(CFOPControlBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd * pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC * pDC);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// Gripper object.
 
	// Grip Button, This member specify E-XD++ CFOPGripButton object.  
	CFOPGripButton	m_aObject1;
	
private:
	
 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDialogBar

 
//===========================================================================
// Summary:
//     The CFOPDialogBar class derived from CFOPControlBar
//      F O P Dialog Bar
//===========================================================================

class FO_EXT_CLASS CFOPDialogBar : public CFOPControlBar
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPDialogBar---F O P Dialog Bar, Specifies a E-XD++ CFOPDialogBar object (Value).
    DECLARE_DYNAMIC(CFOPDialogBar)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Dialog Bar, Constructs a CFOPDialogBar object.
	//		Returns A  value (Object).
    CFOPDialogBar();

    //-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Dialog Bar, Destructor of class CFOPDialogBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPDialogBar();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDialogBar object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		nIDTemplate---I D Template, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwExStyle---Ex Style, Specifies a WORD dwExStyle = CBRS_FOP_SIZE object(Value).  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new dialog bar control.
	BOOL Create(CWnd * pParentWnd,
		UINT nIDTemplate, 
		UINT nStyle = WS_CHILD | WS_VISIBLE | CBRS_BOTTOM,
		WORD dwExStyle = CBRS_FOP_SIZE, 
		UINT nID = 1);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDialogBar object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		lpszTemplateName---Template Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new dialog bar control.
	BOOL Create(CWnd * pParentWnd, LPCTSTR lpszTemplateName, 
		UINT nStyle = WS_CHILD | WS_VISIBLE | CBRS_BOTTOM, 
		DWORD dwExStyle = CBRS_FOP_SIZE,
		UINT nID = 1);

protected:

#ifndef _AFX_NO_OCC_SUPPORT
	// Set dialog information.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Occ Dialog Information, Sets a specify value to current class CFOPDialogBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDialogInfo---Dialog Information, A pointer to the _AFX_OCC_DIALOG_INFO or NULL if the call failed.
	virtual BOOL SetOccDialogInfo(_AFX_OCC_DIALOG_INFO* pDialogInfo);
#endif //!_AFX_NO_OCC_SUPPORT

    //{{AFX_VIRTUAL(CFOPDialogBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fixed Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		bStretch---bStretch, Specifies A Boolean value.  
	//		bHorz---bHorz, Specifies A Boolean value.
    virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CFrameWnd or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
    virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);
    //}}AFX_VIRTUAL

    //{{AFX_MSG(CFOPDialogBar)
#ifndef _AFX_NO_OCC_SUPPORT
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Initial Dialog, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
    afx_msg LRESULT HandleInitDialog(WPARAM wParam, LPARAM lParam);
#endif //!_AFX_NO_OCC_SUPPORT
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    //}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()

protected:

#ifndef _AFX_NO_OCC_SUPPORT

	// Dialog bar information.
 
	// Extend Dialog Information, This member maintains a pointer to the object _AFX_OCC_DIALOG_INFO.  
	_AFX_OCC_DIALOG_INFO*	m_pExtDialogInfo;

	// Dialog resource template name
 
	// Template Name, This member sets A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.  
	LPCTSTR					m_lpszTemplateName;

#endif //!_AFX_NO_OCC_SUPPORT

	// Dialog bar resource id.
 
	// Resource I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nResourceID;

    // Default size of the dialog bar.
 
	// Default, This member sets a CSize value.  
	CSize					m_sizeDefault;

	// Points to parent window.
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*					m_pParentWnd;

};

/////////////////////////////////////////////////////////////////////////////
_FOLIB_INLINE BOOL CFOPDialogBar::Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, WORD dwExStyle,UINT nID) 
{
    return Create(pParentWnd, MAKEINTRESOURCE(nIDTemplate), nStyle,dwExStyle, nID);
}

/////////////////////////////////////////////////////////////////////////////
// CFOPStatusBar

 
//===========================================================================
// Summary:
//     The CFOPStatusBar class derived from CStatusBar
//      F O P Status Bar
//===========================================================================

class FO_EXT_CLASS CFOPStatusBar : public CStatusBar
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Status Bar, Constructs a CFOPStatusBar object.
	//		Returns A  value (Object).
	CFOPStatusBar();

	// Change the indicators of the status bar
	// lpIDArray -- id array of the panes.
	// nIDCount -- the count of the IDs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Indicators, Sets a specify value to current class CFOPStatusBar
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
    BOOL SetIndicators(const UINT* lpIDArray, int nIDCount);
	
	// Obtain the pane pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pane Pointer, .
	//		Returns a pointer to the object AFX_STATUSPANE,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	AFX_STATUSPANE* _GetPanePtr(int nIndex) const;
protected:

	// style size box in corner
 
	// Size Box, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cxSizeBox;   
    
	// Double click on the panel
 
	// Pane Double Click, This member sets TRUE if it is right.  
	BOOL			m_bPaneDoubleClick;

	// Size of the box
 
	// Size Box, This member sets a CRect value.  
	CRect			m_rectSizeBox;

protected:

	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL MethodTempx1() const { return FALSE; }

	// Obtain the panel width
	// nIndex -- index of the pane
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pane Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	int GetPaneWidth(int nIndex) const;

	// Change the width of the pane
	// nIndex -- indes of the pane.
	// cx -- new width of the pane
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pane Width, Sets a specify value to current class CFOPStatusBar
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		cx---Specifies A integer value.
	void SetPaneWidth (int nIndex, int cx);

	// Draw the label of the status bar
	// pDC - Pointer of the dc.
	// rcPos - status bar pos.
	// strLabel -- label of the panel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Panel Label, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&strLabel---&strLabel, Specifies A CString type value.
	void DoDrawPanelLabel(CDC *pDC,const CRect &rcPos,const CString &strLabel);

	// Draw status bar
	// pDC - Pointer of the dc.
	// rcPos - status bar pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bar, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.
	void DoDrawBar(CDC* pDC, const CRect& rcPos);

protected:

	//{{AFX_MSG(CFOPStatusBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Item, Called when a visual aspect of an owner-draw child button control, combo-box control, list-box control, or menu needs to be drawn.
	// Parameters:
	//		nIDCtl---I D Ctl, Specifies A integer value.  
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCONTROLBAR_H__66294514_B340_4E51_9061_0E58C3930BF3__INCLUDED_)
