//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODataModel.h: interface for the CFODataModel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODATAMODEL_H__2EEABBF7_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FODATAMODEL_H__2EEABBF7_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODataModelBase.h"
#include "FODrawShape.h"
#include "FOFormProperties.h"
#include "FOBackShape.h"
#include "FOGroupShape.h"
#include "FOPortShape.h"
#include "FOLinkShape.h"
#include "FOToolBoxItem.h"
#include "FOGroupShape.h"
#include "FOPreviewBitmap.h"
#include "FOCompositeShape.h"
#include "fodefines.h"
#include "FOMultiCompsPropAction.h"
#include "FOMultiModelPropAction.h"
#include "FOPHelpLine.h"
#include "FOPLayer.h"
#include "FOPCollect.h"
#include "FOPathShape.h"
#include   "winspool.h "
#ifdef _FOP_E_SOLUTION
#include "E_Form\FOPNewGridShape.h"
#include "chart\FOPChartShape.h"
#endif

#include "FOScaleUint.h"
#include "FOPRichEditShape.h"

// Default form page position,only used by form mode.
const CRect fo_DefaultPagePosition			=	CRect(0,0,500,400);

// Default page background color.
const COLORREF fo_DefaultPageBkColor		=	RGB(255,255,255);

// Default form back color.
const COLORREF fo_DefaultFormBkColor		=	::GetSysColor(COLOR_BTNFACE);

// Default form title.
const CString  fo_DefaultFormTitle			=	_T("Caption");

// Default printer font name,it used by print header or footer.
const CString  fo_DefaultPrinterFontName	=	_T("Times New Roman");

// Default printer text color,it used by print header or footer.
const COLORREF fo_DefaultPrinterTextColor	=	RGB(0,0,0);

// Default tab order mark color.
const COLORREF fo_DefaultTabOrderColor		=	RGB(0,0,128);

// Default tab order text color.
const COLORREF fo_DefaultTabOrderTextColor	=	RGB(255,255,255);

// Default line arrow type.
const int fo_DefaultArrowType				=	3;

// Default rich edit text.
const CString fo_DefaultRichText			=   _T("{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang2057{\\fonttbl{\\f0\froman\\fprq2\\fcharset0 Times New Roman;}{\\f1\\fswiss\\fprq2\\fcharset0 System;}}{\\colortbl ;\\red255\\green0\\blue0;\\red51\\green153\\blue102;\\red0\\green0\\blue255;}\\viewkind4\\uc1\\pard\\cf1\\i\\f0\\fs24 Inputted\\cf0\\i0  \\cf2\\b rich\\cf0\\b0  \\cf3 text\\cf0 !\\b\\f1\\fs20 \\par }");

// Layer not exist value.
#define FOPLAYER_NOTFOUND 0xFF

// Printer page table entry
typedef struct {
	int nPageIndex;		// Index of page type
    DWORD dwUnit;	// Unit of page.
    int nPageWidth;		// Width of printer paper.
	int nPageHeight;	// Height of printer paper.
} FO_PrinterPaperTableEntry;

// Printer color mode.
enum PrinterColorMode   
{ 
	P_GrayScale = 0,  // Gray scale
	P_Color					// Color
};

// Name of paper.
typedef TCHAR FO_PAPERNAME[64];

// Page size.
enum fopPageSize { A4, B5, Letter, Legal, Executive,
A0, A1, A2, A3, A5, A6, A7, A8, A9, B0, B1,
B10, B2, B3, B4, B6, B7, B8, B9, C5E, Comm10E,
DLE, Folio, Ledger, Tabloid, Custom, NPageSize = Custom };

class CFODataModel;

// Data model list.
typedef CTypedPtrList<CObList, CFODataModel*> CFODataModelList;

/////////////////////////////////////////////////////////////////////////////////
//
// CFODataModel -- the container that contains all the pointer of shapes in the canvas.
//
// This is the core class for data of canvas, all the shapes on the canvas stored in this class
// Call GetShapes(); method to get the list of all shapes.
// Call GetCompsCount(); to obtain the total of shapes on the canvas.
//
// If you want to add shape to canvas, just call InsertShape method (This will method will call 
// an action to do that, if you want to add shape to canvas without undo support, just call: AddChildAtTail(..)
// method.
//
// To open data from file, just call OpenDocument(..), and to save data to file, just call SaveDocument(..) method.
// 
// All the data is done with serialize to file.
/////////////////////////////////////////////////////////////////////////////////

class CFOUpRightLinkShape;

//===========================================================================
// Summary:
//     The CFODataModel class derived from CObject
//      F O Data Model
//===========================================================================

/////////////////////////////////////////////////////////////////////////////
// CFOCloneThread thread
class CFODataModel;
class FO_EXT_CLASS CFOCloneThread : public CWinThread
{
	
public:
	DECLARE_DYNCREATE(CFOCloneThread)
		CFOCloneThread(CFODataModel *pWnd);           // protected constructor used by dynamic creation
	
	// Attributes
public:
	BOOL bDelete;
	// Operations
public:
	BOOL m_bErrResult;
	CFODataModel *m_pModel;
	virtual ~CFOCloneThread();

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOCloneThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL
	
	
	// Generated message map functions
	//{{AFX_MSG(CFOCloneThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	DECLARE_MESSAGE_MAP()
protected:
	BOOL m_check;
	void SplitMe();
};

class FO_EXT_CLASS CFODataModel : public CObject,public CFOCustomDataModel
{
protected:

	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODataModel---F O Data Model, Specifies a E-XD++ CFODataModel object (Value).
	DECLARE_SERIAL(CFODataModel);

public:

	//-----------------------------------------------------------------------
	// Summary:
	//      Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Model, Constructs a CFODataModel object.
	//		Returns A  value (Object).
					CFODataModel();

	//-----------------------------------------------------------------------
	// Summary:
	//      Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Model, Constructs a CFODataModel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFODataModel& source object(Value).
					CFODataModel(const CFODataModel& source);

	//-----------------------------------------------------------------------
	// Summary:
	//      Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Model, Constructs a CFODataModel object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A ~ value (Object).
	virtual ~		CFODataModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODataModel& value (Object).  
	// Parameters:
	//		source---Specifies a const CFODataModel& source object(Value).
	CFODataModel& operator=(const CFODataModel& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModel,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFODataModel* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Call this method, to initial data of model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	Create();

	//-----------------------------------------------------------------------
	// Summary:
	// Initial data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoInitData();

public:
	/*************************************************************************
	|*
	|* Observer control
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Attach observer with current data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Observer, Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pServer---pServer, A pointer to the CFOObserver  or NULL if the call failed.
	virtual void	AttachObserver(
		// Specifies server.
		CFOObserver * pServer
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach observer from current data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pServer---pServer, A pointer to the CFOObserver  or NULL if the call failed.
	virtual void	DetachObserver( 
		// Specifies server.
		CFOObserver * pServer
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Notify all the observers of this data model.
	// lHint -- Notify type value.
	// pHint -- Notify data pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual void	NotifyObserver(LPARAM lHint, CObject*pHint = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Find observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Observer, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pObserver---pObserver, A pointer to the CFOObserver or NULL if the call failed.
	virtual BOOL	FindObserver(
		// Specifies observer.
		CFOObserver* pObserver
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove all observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Observer, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	RemoveAllObserver();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the first observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Observer, Returns the specified value.
	//		Returns a pointer to the object CFOObserver ,or NULL if the call failed
	CFOObserver *GetFirstObserver();

	//-----------------------------------------------------------------------
	// Summary:
	// Change Activate observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Observer, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObserver---*pObserver, A pointer to the CFOObserver  or NULL if the call failed.
	virtual void SetActiveObserver(CFOObserver *pObserver) { m_pActiveObserver = pObserver; }

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of all the shapes list on the canvas,it will return a pointer of CFODrawShapeSet, 
	// this is the list of all shapes on canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Form Objects, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeSet,or NULL if the call failed
	CFODrawShapeSet*		GetFormObjects();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the shapes on the canvas, it will return a pointer to the list of all children shapes on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeSet ,or NULL if the call failed
	CFODrawShapeSet *		GetShapes() { return &m_ShapeList; }

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the shapes on the canvas, it will return a pointer to the list of all child shapes on the canvas.
	// list -- list of shapes that recieved.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Shapes, Returns the specified value.
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	void					GetAllShapes(CFODrawShapeList &list);

	//-----------------------------------------------------------------------
	// Summary:
	// Get shapes count on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Components Count, Returns the specified value.
	//		Returns a int type value.
	int						GetCompsCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// returns TRUE if the document has no shapes on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL					IsEmpty() { return GetShapes()->IsEmpty(); }

	//-----------------------------------------------------------------------
	// Summary:
	// Returns TRUE, if the shape exists within the list (Canvas).
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	BOOL					FindShape(CFODrawShape *pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of all the shapes list on the canvas in view, it will return a pointer of CFODrawShapeSet.
	// Only the shapes that can be viewed will be returned.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In View Shapes, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeSet,or NULL if the call failed
	CFODrawShapeSet*		GetInViewShapes();

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of all the shapes list on the canvas in view, it will return a pointer of CFODrawShapeSet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous In View Shapes, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeSet,or NULL if the call failed
	CFODrawShapeSet*		GetPreviousInViewShapes();

	// Set rectangle dirty.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rects Dirty, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			SetRectsDirty();

public:
	/*************************************************************************
	|*
	|* Modified flag
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Title string,this is a virtual method, you can override this method to generate the title of this document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Document Title, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString		GetDocTitle();

	//-----------------------------------------------------------------------
	// Summary:
	// Change the Document Title.
	// strTitle -- title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Document Title, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strTitle---&strTitle, Specifies A CString type value.
	virtual void		SetDocTitle(const CString &strTitle);

	//-----------------------------------------------------------------------
	// Summary:
	// Update title, modify this method to add * modified flag on the child frame window.
	// When execute each action,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Title, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		UpdateTitle();

	//-----------------------------------------------------------------------
	// Summary:
	// Modify frame title,this method will add * modified flag to a specify document.
	// By default,you can call this method within the override UpdateTile virtual method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Modify Frame Title, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDocument---*pDocument, A pointer to the CDocument  or NULL if the call failed.
	virtual void		ModifyFrameTitle(CDocument *pDocument);

	//-----------------------------------------------------------------------
	// Summary:
	// Do action change,override this method to do something before an action is excuted.
	// It will call this method after execute each action,you can override this method
	// to do some more things than the default.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Action Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pAction---pAction, A pointer to the const CFOBaseAction or NULL if the call failed.
	virtual void		DoActionChange(
		// Specifies action.
		const CFOBaseAction* pAction
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified Flag.
	// bModified -- modified flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified Flag, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bModified---&bModified, Specifies A Boolean value.
	virtual void		SetModifiedFlag(const BOOL &bModified = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Is current model Modified or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		IsModified();

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape order number within current datamodel's shape list,move the old number index's shape to the new
	// order number index within the data model's list.
	// nOldNum -- old number of the shape.
	// nNewNum -- new number of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Order Number, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&nOldNum---Old Number, Specifies A 32-bit long signed integer.  
	//		&nNewNum---New Number, Specifies A 32-bit long signed integer.
	virtual CFODrawShape* ChangeShapeOrderNumber(const long &nOldNum, const long &nNewNum);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape order number within current datamodel's shape list,move the old number index's shape to the new
	// order number index within the data model's list.
	// nOldNum -- old number of the shape.
	// nNewNum -- new number of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ex Change Shape Order Number, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nFirst---&nFirst, Specifies A 32-bit long signed integer.  
	//		&nSecond---&nSecond, Specifies A 32-bit long signed integer.
	virtual void ExChangeShapeOrderNumber(const long &nFirst, const long &nSecond);

	//-----------------------------------------------------------------------
	// Summary:
	// Get list of the all the shapes.
	// lShape -- list container of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get List Shapes, Returns the specified value.
	// Parameters:
	//		*lShape---*lShape, A pointer to the FOPContainer  or NULL if the call failed.
	void GetListShapes(FOPContainer *lShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate the shapes order number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Shapes Ord Nums, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcShapesOrdNums();

	//-----------------------------------------------------------------------
	// Summary:
	// Generate all ports index
	// list -- list of the shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Shapes Indexs, .
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	void GenShapesIndexs(const CFODrawShapeSet& list);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get shapes that can be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Deleting Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void		GetDeletingShapes(
		// List of shapes to be deleted.
		CFODrawShapeList* pShapeList
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get shapes that can be printed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printable Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void		GetPrintableShapes(
		// List of shapes to be printed.
		CFODrawShapeList* pShapeList
		);

	// Get shapes that can be tab ordered.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Order Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void		GetTabOrderShapes(
		// List of shapes to be tab ordered.
		CFODrawShapeList* pShapeList
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Is current shape support hit border.
	// pShape -- pointer of the shape for considering
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Allow Hit Border, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL		DoAllowHitBorder(CFODrawShape *pShape);

public:
	/*************************************************************************
	|*
	|* Hit testing
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Hit test, return the hit test shape pointer, call this method to check if a point is hitted on a shape on the canvas.
	// If it is not hitted, the return pointer will be NULL.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	// point -- HitTest logical point.
	virtual CFODrawShape *	HitTest(
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit test, return the hit test shape pointer, call this methd to check if it is hitted on a link shape or not.
	// ptHit -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test On Link, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual CFODrawShape *	HitTestOnLink(
		// Mouse hit point.
		const CPoint &ptHit,
		// Link shape.
		CFOLinkShape *pLink = NULL
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it is hitted on a shape or not at run time, if it is hitted a shape, it will returns it's pointer, or it will return NULL
	// We have inflate the position of current shape 10 pixels for hit testing. 
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Run Time, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFODrawShape *	HitTestRunTime(
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test on composite or sub - graph shape, if it is hitted on a shape, it will returns the pointer of this shape, or
	// it will returns NULL.
	// We have inflate the position of current shape 10 pixels for hit testing. 
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Composite, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFODrawShape *	HitTestComposite(
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test with simple method, it is used for quick checking if shape is hitted or not.
	// We have inflate the position of current shape 10 pixels for hit testing. 
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Simple, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFODrawShape *	HitTestSimple(
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test tab Order,only validate with Tab Order editing mode. (Not with tab order protected.
	// return the pointer of shape of current tab order.
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Order, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFODrawShape *	HitTestOrder(
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, ports are the shapes that link together, this method is used to check if a point is hitted on a shape or not.
	// return the pointer of current shape's port shape, mostly, you can call this method for port connecting.
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&bUseExt---Use Extend, Specifies A Boolean value.  
	//		&nExp---&nExp, Specifies A integer value.
	virtual CFOPortShape*   HitTestPort(
		// Mouse hit point.
		CPoint point,
		// Use extend border hit or not
		const BOOL &bUseExt = TRUE,
		// Hit expand value.
		const int &nExp = 30
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port,ports are the shapes that link together.
	// return the pointer of current shape's port shape.
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port Extend, Hit test on this object, this method will return a list that will contains all the shapes that this point is hitted.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed.
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&m_TempList---Temp List, Specifies a E-XD++ CFODrawShapeList &m_TempList object (Value).  
	//		&bUseExt---Use Extend, Specifies A Boolean value.
	virtual CFOPortShape*   HitTestPortExt(
		// Mouse hit point.
		CPoint point,
		// List that contains all the shapes.
		CFODrawShapeList &m_TempList,
		// Use extend border hit or not
		const BOOL &bUseExt = TRUE
		);


	//-----------------------------------------------------------------------
	// Summary:
	// Hit test, return the hit test shape pointer, it will only check this shapes that contains within m_TempList, do not use
	// this method to check if a shape on the canvas will be hitted or not.
	// point -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test2, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&m_TempList---Temp List, Specifies a const CFODrawShapeList &m_TempList object(Value).  
	//		point---Specifies A CPoint type value.
	virtual CFODrawShape *	HitTest2(
		// Previous list.
		const CFODrawShapeList &m_TempList,
		// Mouse hit point.
		CPoint point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the nearest port point, this is a helper method, do not call it outside.
	// pPort -- pointer of shape.
	// ptHit -- hit point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CPoint PortPoint(CFOPortShape *pPort, const CPoint &ptHit);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest port, this is a helper method do not call it out side.
	// pShape -- pointer of shape.
	// ptHit -- hit test point
	// bestPort -- best port that find.
	// bestDist -- best dist that find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Port1, .
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		*bestPort---*bestPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		&bestDist---&bestDist, Specifies A float value.
	CFOPortShape *PickNearestPort1(CFODrawShape *pShape, const CPoint &ptHit, CFOPortShape *bestPort, float &bestDist);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest port, this is a helper method, do not call it outside.
	// pShape -- pointer of shape.
	// ptHit -- hit test point
	// bestPort -- best port that find.
	// bestDist -- best dist that find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Port Helper, .
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		*bestPort---*bestPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		&bestDist---&bestDist, Specifies A float value.
	CFOPortShape *PickNearestPortHelper(CFODrawShape *pShape, const CPoint &ptHit, CFOPortShape *bestPort, float &bestDist);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest point,this is used for glue mode,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points, this is a system method, do not call it outside.
	// m_SelectList -- List of shapes for glue.
	// ptPick -- nearest glue point,this is a return point.
	// ptHit -- HitTest logical point.
	// bWithSelection -- if it is true,itself will be used for glue.
	// For Canvas Only: the main snap virtual for canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_SelectList---Select List, Specifies a const CFODrawShapeList &m_SelectList object(Value).  
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		bWithSelection---With Selection, Specifies A Boolean value.
	virtual BOOL			PickNearestPoint(const CFODrawShapeList &m_SelectList,
		// Nearest point.
		CPoint &ptPick,
		// Mouse hit point.
		const CPoint &ptHit,BOOL bWithSelection = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest point,this is used for glue mode,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points, this is a system method, do not call it outside.
	// m_SelectList -- List of shapes for glue.
	// ptPick -- nearest glue point,this is a return point.
	// ptHit -- HitTest logical point.
	// bWithSelection -- if it is true,itself will be used for glue.
	// For Canvas Only: the main snap virtual for canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point Only For Move, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_SelectList---Select List, Specifies a const CFODrawShapeList &m_SelectList object(Value).  
	//		&ptCenter---&ptCenter, Specifies A integer value.  
	//		&ptOldOffset---Old Offset, Specifies A integer value.  
	//		&rcCheck---&rcCheck, Specifies a const FOPRect &rcCheck object(Value).  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptNear---&ptNear, Specifies A integer value.  
	//		&ptGetH---Get H, Specifies A CPoint type value.  
	//		&ptGetV---Get V, Specifies A CPoint type value.  
	//		&bHorz---&bHorz, Specifies A Boolean value.  
	//		&bVert---&bVert, Specifies A Boolean value.  
	//		bWithSelection---With Selection, Specifies A Boolean value.
	virtual BOOL			PickNearestPointOnlyForMove(const CFODrawShapeList &m_SelectList, const FOPPoint &ptCenter,
		const FOPPoint &ptOldOffset,
		// Nearest point.
		const FOPRect &rcCheck,
		// Mouse hit point.
		CPoint &ptOffset, FOPPoint &ptNear, 
		CPoint &ptGetH,
		CPoint &ptGetV,
		BOOL &bHorz, 
		BOOL &bVert,
		BOOL bWithSelection = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest point,this is used for glue mode,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points, this is a system method, do not call it outside.
	// m_SelectList -- List of shapes for glue.
	// ptPick -- nearest glue point,this is a return point.
	// ptHit -- HitTest logical point.
	// bWithSelection -- if it is true,itself will be used for glue.
	// For Canvas Only: the main snap virtual for canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point Only For Move, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_SelectList---Select List, Specifies a const CFODrawShapeList &m_SelectList object(Value).  
	//		&ptCenter---&ptCenter, Specifies A integer value.  
	//		&ptOldOffset---Old Offset, Specifies A integer value.  
	//		&rcCheck---&rcCheck, Specifies a const FOPRect &rcCheck object(Value).  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptNear---&ptNear, Specifies A integer value.  
	//		&ptGetH---Get H, Specifies A CPoint type value.  
	//		&ptGetV---Get V, Specifies A CPoint type value.  
	//		&bHorz---&bHorz, Specifies A Boolean value.  
	//		&bVert---&bVert, Specifies A Boolean value.  
	//		bWithSelection---With Selection, Specifies A Boolean value.
	virtual BOOL			PickNearestPortOnlyForMove(const CFODrawShapeList &m_SelectList, const FOPPoint &ptCenter,
		const FOPPoint &ptOldOffset,
		// Nearest point.
		const FOPRect &rcCheck,
		// Mouse hit point.
		CPoint &ptOffset, FOPPoint &ptNear, 
		CPoint &ptGetH,
		CPoint &ptGetV,
		BOOL &bHorz, 
		BOOL &bVert,
		BOOL bWithSelection = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Get nearest shape's point,this is used to connect line to line,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	// ptHit -- HitTest logical point.
	// For Canvas Only: It is used within canvas view for free form drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual CFODrawShape*	GetNearestPtShape(const CPoint &ptHit,CFODrawShape *pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Get nearest shape's point,this is used to connect line to line,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	// ptHit -- HitTest logical point.
	// For Canvas Only: It is used within canvas view for free form drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point Shape Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nSpotIndex---Spot Index, Specifies A integer value.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual CFODrawShape*	GetNearestPtShapeExt(const CPoint &ptHit,int &nSpotIndex,CFODrawShape *pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Pick nearest rect,this is used for glue mode,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	// m_SelectList -- List of shapes for glue.
	// rRect -- rectangle for snap
	// rDX -- snap offset x value.
	// rDY -- snap offset y value.
	// bWithSelection -- if it is true,itself will be used for glue.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_SelectList---Select List, Specifies a const CFODrawShapeList &m_SelectList object(Value).  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		rDX---D X, Specifies A 32-bit long signed integer.  
	//		rDY---D Y, Specifies A 32-bit long signed integer.  
	//		bWithSelection---With Selection, Specifies A Boolean value.
	virtual BOOL			PickNearestRect(const CFODrawShapeList &m_SelectList,const FOPRect& rRect,
		long& rDX, long& rDY,
		BOOL bWithSelection = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Do snap action for a list of shapes, it is used for snap feature of E-XD++.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Snap, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_ShapeList---Shape List, Specifies a const CFODrawShapeSet &m_ShapeList object(Value).  
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	BOOL			DoSnap(const CFODrawShapeSet &aShapeList,
		// Nearest point.
		CPoint &ptPick,
		// Mouse hit point.
		const CPoint &ptHit);

	//-----------------------------------------------------------------------
	// Summary:
	// Check snap for a list of shapes,this is system method, do not call it outside.
	// m_ShapeList -- list of the shapes.
	// rPt -- point for hit test.
	// nBestXSnap -- the best x snap offset value.
	// nBestYSnap -- the best y snap offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Snap, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&aShapeList---Shape List, Specifies a const CFODrawShapeSet &m_ShapeList object(Value).  
	//		rPt---rPt, Specifies A integer value.  
	//		nBestXSnap---Best X Snap, Specifies A 32-bit long signed integer.  
	//		nBestYSnap---Best Y Snap, Specifies A 32-bit long signed integer.
	virtual BOOL CheckSnap(const CFODrawShapeSet &aShapeList,const FOPPoint& rPt,
		long& nBestXSnap, long& nBestYSnap);

	//-----------------------------------------------------------------------
	// Summary:
	// Snap to intersect of the shape's polygon,when the shape is snap to intersect lines,
	// this method will be called,override this method
	// to handle your own control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To Intersect Lines,  this is system method, do not call it outside.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_SelectList---Select List, Specifies a const CFODrawShapeSet &m_SelectList object(Value).  
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToIntersectLines(const CFODrawShapeSet &m_SelectList,
		// Nearest point.
		CPoint &ptPick,
		// Mouse hit point.
		const CPoint &ptHit);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate the editing label text, override it to generate editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Editing Label, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.  
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void DoGenEditingLabel(const int &nType, CString &strLabel);

	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate rectangles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Rects.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcRects();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the object's bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Object Bound Rectangle, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	const FOPRect& GetAllObjBoundRect() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the visible object's bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Visible Object Bound Rectangle, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	FOPRect GetAllVisibleObjBoundRect() const;
public:
	/*************************************************************************
	|*
	|* Measure scale and unit
	|*
	\************************************************************************/
	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the UI unit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get U I Unit, Returns the specified value.
	//		Returns A FieldUnit value (Object).
	FieldUnit        GetUIUnit() const								{ return m_nUIUnit; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the UI unit
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	//  FUNIT_LOGPOINT		//10
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set U I Unit, Sets a specify value to current class CFODataModel
	// Parameters:
	//		eUnit---eUnit, Specifies a FieldUnit eUnit object(Value).
	void             SetUIUnit(FieldUnit eUnit);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the printer paper.
	// sizePaper -- size of paper based on pixel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printer Paper Size, Sets a specify value to current class CFODataModel
	// Parameters:
	//		sizePaper---sizePaper, Specifies A CSize type value.
	void SetPrinterPaperSize(CSize sizePaper);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the printer's paper size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Paper Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetPrinterPaperSize() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the UI Scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get U I Scale, Returns the specified value.
	//		Returns A const FOPFraction& value (Object).
	const FOPFraction&  GetUIScale() const    { return m_aUIScale; }

	//-----------------------------------------------------------------------
	// Summary:
	// Default drawing scale,Default 1/1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set U I Scale, Sets a specify value to current class CFODataModel
	// Parameters:
	//		aScale---aScale, Specifies a const FOPFraction& aScale object(Value).
	void             SetUIScale(const FOPFraction& aScale, const BOOL &bScaleShape = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the UI Unit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set U I Unit, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&eUnit---&eUnit, Specifies a const FieldUnit &eUnit object(Value).  
	//		aScale---aScale, Specifies a const FOPFraction& aScale object(Value).
	void             SetUIUnit(const FieldUnit &eUnit, const FOPFraction& aScale);

	//-----------------------------------------------------------------------
	// Summary:
	// Get unit string
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// rStr -- return string value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Unit String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rStr---rStr, Specifies A CString type value.
	virtual void TakeUnitStr(CString& rStr);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert current UI value to logical value,
	// such as convert 1mm to point
	// dValue -- value to be converted.
	// bVertical -- vertical or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// I To Logical, .
	// Parameters:
	//		&dValue---&dValue, Specifies a double &dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	void UIToLog(double &dValue,const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert logical value to current UI measure value.
	// such as convert point to mm
	// dValue -- value to be converted.
	// bVertical -- vertical or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Logical To U I, .
	// Parameters:
	//		&dValue---&dValue, Specifies a double &dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	void LogToUI(double &dValue,const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert current shape's size to UI value.
	// pComp -- shape to be used.
	// width -- result width of the shape.
	// height -- result height of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Shape Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		width---Specifies a double& width object(Value).  
	//		height---Specifies a double& height object(Value).
	virtual void MeasureShapeSize(CFODrawShape* pComp, double& width, double& height);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert current shape's position to UI value
	// pComp -- shape to be used.
	// x -- result x pos of the shape.
	// y -- result y pos of the shape.
	// nControlPoint -- control handle of the shape,it should be one of the following value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Shape Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		x---Specifies a double& x object(Value).  
	//		y---Specifies a double& y object(Value).  
	//		nControlPoint---Point, Specifies A integer value.
	virtual void MeasureShapePos(CFODrawShape* pComp, double& x, double& y,
		const FO_CONTROL_HANDLE nControlPoint = foTopLeft);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert current CSize size value to UI value.
	// size -- size to be converted.
	// width -- result width.
	// height -- result height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure C Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		size---Specifies A CSize type value.  
	//		width---Specifies a double& width object(Value).  
	//		height---Specifies a double& height object(Value).
	virtual void MeasureCSize(const CSize& size, double& width, double& height);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert current CPoint point value position to UI value
	// pt -- point to be converted.
	// x -- result x value.
	// y -- result y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure C Point Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&pt---Specifies A CPoint type value.  
	//		x---Specifies a double& x object(Value).  
	//		y---Specifies a double& y object(Value).
	virtual void MeasureCPointPos(const CPoint &pt, double& x, double& y);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert point from UI value to logical value.
	// pt -- the result point value.
	// xValue -- value for convert.
	// yValue -- value for convert.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point U I To Logical, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&pt---Specifies A CPoint type value.  
	//		&xValue---&xValue, Specifies a const double &xValue object(Value).  
	//		&yValue---&yValue, Specifies a const double &yValue object(Value).
	virtual void PointUIToLog(CPoint &pt,const double &xValue,const double &yValue);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert size from UI value to logical value.
	// sz -- the result CSize value.
	// xValue -- value for convert.
	// yValue -- value for convert.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size U I To Logical, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&sz---Specifies A CSize type value.  
	//		&xValue---&xValue, Specifies a const double &xValue object(Value).  
	//		&yValue---&yValue, Specifies a const double &yValue object(Value).
	virtual void SizeUIToLog(CSize &sz,const double &xValue,const double &yValue);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert rectangle from UI value to logical value.
	// rect -- the result CSize value.
	// xValue -- value for convert,it is the left border position of the rectangle
	// yValue -- value for convert,it is the top border position of the rectangle.
	// dWidth -- value for convert,it is the width size of the rectangle.
	// dHeight -- value for convert,it is the height size of the rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle U I To Logical, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.  
	//		&xValue---&xValue, Specifies a const double &xValue object(Value).  
	//		&yValue---&yValue, Specifies a const double &yValue object(Value).  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a const double &dHeight object(Value).
	virtual void RectUIToLog(CRect &rc,const double &xValue,const double &yValue,
		const double &dWidth,const double &dHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale rectangle to current UI
	// aRect -- rectangle for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect& aRect object(Value).
	virtual void		ScaleRect( FOPRect& aRect);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale size to current UI
	// aSize -- size value for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aSize---aSize, Specifies a FOPSize& aSize object(Value).
	virtual void		ScaleSize( FOPSize& aSize);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale point to current UI
	// aPoint -- point value for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoint---aPoint, Specifies A integer value.
	virtual void		ScalePoint( FOPPoint& aPoint);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the canvas.
	// dWidth -- width of the canvas,it is the value with the current UI measure setting.
	// dHeight -- height of the canvas,it is the value with the current UI measure setting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a const double &dHeight object(Value).
	virtual void	SetCanvasSize(const double &dWidth,const double &dHeight); 

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the grid.
	// dWidth -- width of the grid,it is the value with the current UI measure setting.
	// dHeight -- height of the grid,it is the value with the current UI measure setting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a const double &dHeight object(Value).
	virtual void	SetGridSize(const double &dWidth,const double &dHeight); 

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the margin.
	// dLeft -- left space of the margin,it is the value with the current UI measure setting.
	// dTop -- top space of the margin,it is the value with the current UI measure setting.
	// dRight -- right space of the margin,it is the value with the current UI measure setting.
	// dBottom -- bottom space of the margin,it is the value with the current UI measure setting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dLeft---&dLeft, Specifies a const double &dLeft object(Value).  
	//		&dTop---&dTop, Specifies a const double &dTop object(Value).  
	//		&dRight---&dRight, Specifies a const double &dRight object(Value).  
	//		&dBottom---&dBottom, Specifies a const double &dBottom object(Value).
	virtual void	SetMarginSize(const double &dLeft,const double &dTop,const double &dRight,const double &dBottom); 

	//-----------------------------------------------------------------------
	// Summary:
	// Update progress bar's information with the following method
	// nCurPos -- value from 0 - 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Progress, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nCurPos---Current Position, Specifies A integer value.
	virtual void UpdateProgress(const int &nCurPos);

	// Do something after shape is removed.
	// pCurRemove -- shape that will be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Remove, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCurRemove---Current Remove, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoAfterRemove(CFODrawShape *pCurRemove);

	// doing after shape removed.
	virtual void DoWhenRemoved(CFODrawShape *pCurRemove);

	// Do something after shape is added.
	// pCurAdd -- shape that just added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Add, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCurAdd---Current Add, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoAfterAdd(CFODrawShape *pCurAdd);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Show or hide all the ports on the canvas.
	// bShow -- show or hide the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show All Ports, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	virtual void			ShowAllPorts(
		// Specifies to show or not.
		BOOL bShow
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the main anchor shape of the shapes list,for alignment or sizment action,it need a main shape for align or size.
	// And if there are more than one main shapes,it will only limit to one main shape.
	// pShapeList -- the total shapes list.
	// pMain -- new anchor shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Main Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		*pMain---*pMain, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual CFODrawShape*	ChangeMainShape(CFODrawShapeList* pShapeList,
		CFODrawShape *pMain);

public:
	/*************************************************************************
	|*
	|* Creating new shapes
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Adjusts component so it falls within diagram boundaries.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Within Boundaries, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void SetWithinBoundaries(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Call before create shape new shape,this method will be called after each new shape is created,
	// You can override this method to do something before shape created.
	// pShape -- the pointer of shape that created.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Create Shape, Call before create shape new shape,this method will be called after each new shape is created, You can override this method to do something before shape created.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void			DoInitCreateShape(CFODrawShape *pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Shapes that doesn't effect with style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Effect, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL			IsShapeEffect(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Create shapes for E-Form Solution only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Do Create Gauge_ Solution, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.
	CFODrawShape *FOPDoCreateGauge_Solution(UINT m_drawshape,
												const CRect &rcCreate);

	//-----------------------------------------------------------------------
	// Summary:
	// Create shapes for E-Form Solution only.
	// m_drawshape -- type id of shape.
	// rcCreate -- position of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Do Create E Form_ Solution, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.
	CFODrawShape *FOPDoCreateEForm_Solution(UINT m_drawshape,
												const CRect &rcCreate);

	//-----------------------------------------------------------------------
	// Summary:
	// Do create a new shape,override this method to add your own custom shape creating.See sample UserDefine shows.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	// pCurItem -- if being drag and drop from toolbox,this is the pointer of current toolbox item.
	virtual CFODrawShape *	DoCreateShapeByType(UINT m_drawshape,
		CRect &rcCreate,
		CString strFileName = _T(""),
		CFOToolBoxItem *pCurItem = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Do create a new path shape,override this method to add your own custom shape creating.See sample UserDefine shows.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	// pCurItem -- if being drag and drop from toolbox,this is the pointer of current toolbox item.
	virtual CFODrawShape *	DoCreatePathShapeByType(UINT m_drawshape,
		CRect &rcCreate,
		CString strFileName = _T(""),
		CFOToolBoxItem *pCurItem = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	/// Create shape from a pointer of Toolbox item.
	// pCurItem -- pointer of toolbox item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Shape From Toolbox Item, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pCurItem---Current Item, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual CFODrawShape * CreateShapeFromToolboxItem(CFOToolBoxItem *pCurItem);

	//-----------------------------------------------------------------------
	// Summary:
	// Assign where the toolbox item can be obtained.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Select Toolbox Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	virtual CFOToolBoxItem *DoGetSelectToolboxItem();

	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type to the canvas,this is a system method,by default,you need not override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		strFileName---File Name, Specifies A CString type value.
	virtual CFODrawShape*		AddShapeByType(UINT m_drawshape,
		CRect &rcCreate,
		CString strFileName = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By Type to the canvas,by default,you need not override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// arInitPorts -- array of ports.
	// strFileName -- if being resource file,this is the file name of trs.
	// nResID -- if being resource id,this is the resource id value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape By Type, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		CArray<FOPORTVALUE---Array< F O P O R T V A L U E, Specifies A CArray array.  
	//		*arInitPorts---Initial Ports, A pointer to the FOPORTVALUE>  or NULL if the call failed.  
	//		strFileName---File Name, Specifies A CString type value.  
	//		nResID---Resource I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CFODrawShape*	AddCompositeShapeByType(UINT m_drawshape,
		CRect &rcCreate,
		CArray<FOPORTVALUE,FOPORTVALUE> *arInitPorts,
		CString strFileName = _T(""),UINT nResID = 0);

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By Type to the canvas, this method will support undo / redo.
	// nResId -- resource ID of composite shape
	// rcCreate -- init position of shape.
	// bAutoSize -- if it is TRUE, it means it will take the rectangle of this sid resource file automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&nResId---Resource Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		&bAutoSize---Automatic Size, Specifies A Boolean value.
	virtual CFOCompositeShape*	AddCompositeShape(const UINT &nResId, CRect &rcCreate, const BOOL &bAutoSize = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By file name to the canvas, this method will support undo / redo.
	// strFileName -- resource file name of composite shape
	// rcCreate -- init position of shape.
	// bAutoSize -- if it is TRUE, it means it will take the rectangle of this sid resource file automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&strFileName---File Name, Specifies A CString type value.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		&bAutoSize---Automatic Size, Specifies A Boolean value.
	virtual CFOCompositeShape*	AddCompositeShape(const CString &strFileName, CRect &rcCreate, const BOOL &bAutoSize = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By Type to the canvas, this method doesn't support undo / redo.
	// nResId -- resource ID of composite shape
	// rcCreate -- init position of shape.
	// bAutoSize -- if it is TRUE, it means it will take the rectangle of this sid resource file automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape Without Undo, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&nResId---Resource Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		&bAutoSize---Automatic Size, Specifies A Boolean value.
	virtual CFOCompositeShape*	AddCompositeShapeWithoutUndo(const UINT &nResId, CRect &rcCreate, const BOOL &bAutoSize = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By Type to the canvas, this method doesn't support undo / redo.
	// nResId -- resource ID of composite shape
	// rcCreate -- init position of shape.
	// bAutoSize -- if it is TRUE, it means it will take the rectangle of this sid resource file automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape Without Undo, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&nResId---Resource Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		&bAutoSize---Automatic Size, Specifies A Boolean value.
	virtual CFOCompositeShape*	AddCompShapeWithTemplateFile(const CString &strFileName, CRect &rcCreate, const BOOL &bAutoSize = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add composite Shape By file name to the canvas, this method doesn't support undo / redo.
	// strFileName -- resource file name of composite shape
	// rcCreate -- init position of shape.
	// bAutoSize -- if it is TRUE, it means it will take the rectangle of this sid resource file automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape Without Undo, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&strFileName---File Name, Specifies A CString type value.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		&bAutoSize---Automatic Size, Specifies A Boolean value.
	virtual CFOCompositeShape*	AddCompositeShapeWithoutUndo(const CString &strFileName, CRect &rcCreate, const BOOL &bAutoSize = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Do create a new composite shape,if you want to use a new custom composite shape instead,please override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	// pCurItem -- if being drag and drop from toolbox,this is the pointer of current toolbox item.
	virtual CFOCompositeShape *DoCreateCompositeShapeByType(UINT m_drawshape,
		CRect &rcCreate,
		CArray<FOPORTVALUE,FOPORTVALUE> *arInitPorts,
		CString strFileName = _T(""),
		UINT nResID = 0,
		CFOToolBoxItem *pCurItem = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Do create a new ole drop composite shape.
	// rcCreate -- init position of shape.
	// pCurItem -- if being drag and drop from toolbox,this is the pointer of current toolbox item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Ole Composite Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed  
	// Parameters:
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		*pCurItem---Current Item, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual CFOCompositeShape *DoCreateOleCompositeShape(const CRect &rcCreate,CFOToolBoxItem *pCurItem);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new Line Shape,if you want to use a new custom line shape instead,please override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// pptPoints -- init position of shape.
	// nCount -- count of points.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual void			AddLineShape(UINT m_drawshape,
		LPPOINT ppts, 
		int nCount,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new Line Shape,if you want to use a new custom line shape instead,please override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// pptPoints -- init position of shape.
	// nCount -- count of points.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line Shape2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddLineShape2(UINT m_drawshape,
		LPPOINT ppts, 
		int nCount,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new port Shape,defined for class CFOPortShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptCenter -- init position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Port Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawPortsShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptCenter---ptCenter, Specifies A CPoint type value.
	virtual CFODrawPortsShape*	AddPortShape(UINT m_drawshape,
		CPoint ptCenter,  CFODrawPortsShape *pParentBox = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Searching for hitting test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search In Composite, .
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	CFODrawPortsShape *SearchInComposite(CFOCompositeShape *pComp, const CPoint &ptHit);

public:

	/*************************************************************************
	|*
	|* The following methods are defined for E-Form solution.
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Search in composite shape for all e-form shapes.
	// pComp -- Composite shape.
	// listShapes -- list of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search For E Form Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual void SearchForEFormShape(CFOCompositeShape *pComp, CFODrawShapeList &listShapes);

	//-----------------------------------------------------------------------
	// Summary:
	// Search for all e-form shapes.
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search For All E Form Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual void SearchForAllEFormShapes(CFODrawShapeList &listShapes);


	//-----------------------------------------------------------------------
	// Summary:
	// Search in composite shape for all e-form shapes.
	// pComp -- Composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move With Component, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoMouseMoveWithComp(CFOCompositeShape *pComp, UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search for all e-form shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoMouseMove(UINT nFlags, CPoint point);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new dimension Line Shape,defined for class CFODimLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Dimension Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddDimLineShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new horz dimension Line Shape,defined for class CFODimLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true, it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Horizontal Dimension Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddHorzDimLineShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new vertical dimension Line Shape,defined for class CFODimLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Vertical Dimension Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddVertDimLineShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new radius dimension Line Shape,defined for class CFODimLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Radius Dimension Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddRadiusDimLineShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,
		BOOL bArrow = FALSE);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type to the canvas,this is a system method,by default,you need not override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type New, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		strFileName---File Name, Specifies A CString type value.
	virtual CFODrawShape*		AddShapeByTypeNew(UINT m_drawshape,
		CRect &rcCreate,
		CString strFileName = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Find shape by caption.
	// str -- caption of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&str---Specifies A CString type value.
	CFODrawShape* FindShapeByCaption(const CString &str);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape by name.
	// str -- name of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&str---Specifies A CString type value.
	CFODrawShape* FindShapeByName(const CString &str);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape by ID.
	// nID -- ID value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&nID---I D, Specifies A 32-bit long signed integer.
	CFODrawShape* FindShapeByID(const long &nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Obtain shape at specify index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	long GetShapeAt(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type to the canvas,this is a system method,by default,you need not override this method.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcCreate -- init position of shape.
	// strFileName -- if being image shape,this is the image file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Shape By Type New, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcCreate---&rcCreate, Specifies A CRect type value.  
	//		strFileName---File Name, Specifies A CString type value.
	virtual CFODrawShape*		CreateShapeByTypeNew(UINT m_drawshape,
		CRect &rcCreate,
		CString strFileName = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Add new Callout Shape,defined for class CFOCaptionShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Callout Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddCalloutShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,int nHeight,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new Caption Line Shape,defined for class CFOCaptionShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Caption Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddCaptionShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,int nHeight,
		BOOL bArrow = FALSE);

	// Get require points for move.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Move Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual BOOL LimitMovePoint(CArray<CPoint,CPoint> *arPoints);

	// Get require points for move.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Move Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aryPoints---aryPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual BOOL LimitMovePoint(LPPOINT aryPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new round callout Line Shape,defined for class CFOCaptionShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Round Callout Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	virtual CFODrawShape*			AddRoundCalloutShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,int nHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new rect callout Line Shape,defined for class CFOCaptionShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle Callout Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	virtual CFODrawShape*			AddRectCalloutShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,int nHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new cloud callout Line Shape,defined for class CFOCaptionShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset dim width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Cloud Callout Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	virtual CFODrawShape*			AddCloudCalloutShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,int nHeight);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new arc Line Shape,defined for class CFOPArcShape.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- Offset arc width.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddArcLineShape(UINT m_drawshape,
		const CPoint &ptStart, const CPoint &ptEnd,
		int nWidth,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a Extend new arc Line Shape,defined for class CFOPArcShape2
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- bounding rectangle.
	// ptStart -- start point.
	// ptEnd -- end point.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc Line2 Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddArcLine2Shape(UINT m_drawshape,
		const CRect &rcPos,
		const CPoint &ptStart, const CPoint &ptEnd,
		BOOL bArrow = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new pie Shape,defined for class CFOPPieShape,
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- bounding rectangle.
	// ptStart -- start point.
	// ptEnd -- end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual CFODrawShape*			AddPieShape(UINT m_drawshape,
		const CRect &rcPos,
		const CPoint &ptStart, const CPoint &ptEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new ring Shape,defined for class CFOPPieShape,
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- bounding rectangle.
	// ptStart -- start point.
	// ptEnd -- end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add ring Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual CFODrawShape*			AddRingShape(UINT m_drawshape,
		const CRect &rcPos,
		const CPoint &ptStart, const CPoint &ptEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new ellipse chord Shape,defined for class CFOPChordShape.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- bounding rectangle.
	// ptStart -- start point.
	// ptEnd -- end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ellipse Chord Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual CFODrawShape*			AddEllipseChordShape(UINT m_drawshape,
		const CRect &rcPos,
		const CPoint &ptStart, const CPoint &ptEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new grid table Shape,defined for class CFOGridShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	// nRows -- grid rows.
	// nCols -- grid cols.
	// bFixRow -- if being true,it has fix row header.
	// bFixCol -- if being true,it has fix col header.
	// bShowGrid -- if being true,it has grid line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tabel Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nRows---&nRows, Specifies A integer value.  
	//		&nCols---&nCols, Specifies A integer value.  
	//		&bFixRow---Fix Row, Specifies A Boolean value.  
	//		&bFixCol---Fix Column, Specifies A Boolean value.  
	//		&bShowGrid---Show Grid, Specifies A Boolean value.
	virtual CFODrawShape*			AddTabelShape(UINT m_drawshape,const CRect &rcPos,
		const int &nRows, const int &nCols,const BOOL &bFixRow = TRUE,
		const BOOL &bFixCol = TRUE,const BOOL &bShowGrid = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new table Shape,defined for class CFOPTableShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	// nRows -- grid rows.
	// nCols -- grid cols.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Tabel Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nRows---&nRows, Specifies A integer value.  
	//		&nCols---&nCols, Specifies A integer value.
	virtual CFODrawShape*			AddNewTabelShape(UINT m_drawshape,const CRect &rcPos,
		const int &nRows, const int &nCols);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new table Shape,defined for class CFOPTableShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	// nRows -- grid rows.
	// nCols -- grid cols.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Tabel Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nRows---&nRows, Specifies A integer value.  
	//		&nCols---&nCols, Specifies A integer value.
	virtual CFODrawShape*			AddXNewTableShape(UINT m_drawshape,const CRect &rcPos,
		const int &nRows, const int &nCols);


	// Do something when switch to design or undesign mode.
	virtual void DoModelSwitch(const BOOL &bDesign);


#ifdef _FOP_E_SOLUTION
	//-----------------------------------------------------------------------
	// Summary:
	// Add a new grid Shape,defined for class CFOGridShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Grid Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPNewGridShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual CFOPNewGridShape* AddNewGridShape(UINT m_drawshape,const CRect &rcPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new grid Shape,defined for class CFOGridShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	// aryColumns -- init data of the columns of the grid.
	// nRows -- rows of the grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Grid Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPNewGridShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&aryColumns---&aryColumns, Specifies a const FOPInitColsData &aryColumns object(Value).  
	//		nRows---nRows, Specifies A integer value.
	virtual CFOPNewGridShape* AddNewGridShape(UINT m_drawshape,const CRect &rcPos,const FOPInitColsData &aryColumns,
		int nRows);

#endif

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new rich edit shape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// rcPos -- position of grid shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Rich Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPRichEditShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual CFOPRichEditShape* AddNewRichShape(UINT m_drawshape,CRect &rcPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Polyline Shape,defined for class CFOLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- init position of shape.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polyline Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual void			AddPolylineShape(UINT m_drawshape,
		CArray<CPoint,CPoint> *arPoints,
		BOOL bArrow = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Polyline Shape,defined for class CFOLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- init position of shape.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polyline Shape2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddPolylineShape2(UINT m_drawshape,
		CArray<CPoint,CPoint> *arPoints,
		BOOL bArrow = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Free line Shape,defined for class CFOFreeLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- init position of shape.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Free Line Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddFreeLineShape(UINT m_drawshape,
		CArray<CPoint,CPoint> *arPoints,
		BOOL bArrow = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Create link between two ports.
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Link, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFODrawShape* CreateLink(UINT m_drawshape,
		CFOPortShape *pFrom,
		CFOPortShape *pTo);

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it can be linked with two points
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Be Linked, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL ToBeLinked(CFOPortShape *pFrom, CFOPortShape *pTo);

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it need to be exchanged or not
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Need Exchange, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL NeedExchange(CFOPortShape *pFrom, CFOPortShape *pTo);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	// nArrowType -- if being true,it has an arrow else it doesn't has an arrow.
	//			 0-None arrow.
	//			 1-One arrow at the end.
	//			 2- Two arrow,start arrow and end arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		nArrowType---Arrow Type, Specifies A integer value.
	virtual BOOL			AddLinkShape(UINT m_drawshape,
		CArray<CPoint,CPoint> *arPoints,
		CFOPortShape *pFrom = NULL,
		CFOPortShape *pTo = NULL,
		int nArrowType = 0);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	// nArrowType -- if being true,it has an arrow else it doesn't has an arrow.
	//			 0-None arrow.
	//			 1-One arrow at the end.
	//			 2- Two arrow,start arrow and end arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		nArrowType---Arrow Type, Specifies A integer value.
	virtual CFODrawShape*			AddLinkShape2(UINT m_drawshape,
		CArray<CPoint,CPoint> *arPoints,
		CFOPortShape *pFrom = NULL,
		CFOPortShape *pTo = NULL,
		int nArrowType = 0);
	

	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Shape,defined for class CFOPolygonShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual void			AddPolygonShape(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Shape,defined for class CFOPolygonShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Shape2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual CFODrawShape*			AddPolygonShape2(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints);

	// Add Bezier Shape,defined for class CFOBezierLineShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	// bArrow -- if being true,it has an arrow else it doesn't has an arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.  
	//		bArrow---bArrow, Specifies A Boolean value.
	virtual CFODrawShape*			AddBezierShape(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints,BOOL bArrow = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Close Bezier Shape,defined for class CFOCloseBezierShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Close Bezier Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual void			AddCloseBezierShape(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Close Bezier Shape,defined for class CFOCloseBezierShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// arPoints -- Init position of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Close Bezier Shape2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual CFODrawShape*			AddCloseBezierShape2(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints);

	// Add path Shape,defined for class CFOCloseBezierShape
	// m_drawshape -- Shape Type id start from FO_COMP_CUSTOM
	// nShapeType -- type of the path shape,it must be one of the following value:
	// enum FOPShapeKind 
	// {
	// 	FOP_DRAW_PATH_NONE			= 0,   // None
	// 	FOP_DRAW_PATH_LINE			= 1,   // Line shape
	// 	FOP_DRAW_PATH_POLYGON		= 2,   // Polygon, PolyPolygon
	// 	FOP_DRAW_PATH_PLINE			= 3,   // PolyLine
	// 	FOP_DRAW_PATH_PATHLINE		= 4,   // Bezier curve
	// 	FOP_DRAW_PATH_PATHFILL		= 5,   // Close Bezier curve
	// 	FOP_DRAW_PATH_FREELINE		= 6,   // Free handle line
	// 	FOP_DRAW_PATH_FREEFILL		= 7,   // Close free handle line
	// 	FOP_DRAW_PATH_SPLNLINE		= 8,   // Spline
	// 	FOP_DRAW_PATH_SPLNFILL		= 9,   // Close spline
	// 	FOP_DRAW_PATH_PATHPOLYGON   = 10,  // Polygon/PolyPolygon
	// 	FOP_DRAW_PATH_PATHPLINE		= 11,  // Polyline
	// 	FOP_DRAW_PATH_OTHER
	// };
	//aPathPoly -- polygon of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Path Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		m_drawshape---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nShapeType---Shape Type, Specifies a const FOPShapeKind &nShapeType object(Value).  
	//		aPathPoly---Path Polygon, Specifies a const FOPSimpleCompositePolygon& aPathPoly object(Value).
	virtual CFODrawShape*			AddPathShape(UINT m_drawshape,const FOPShapeKind &nShapeType,
		const FOPSimpleCompositePolygon& aPathPoly);

	// Get value with current map mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value With Map Mode, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	int GetValueWithMapMode(int &nValue);

	// Add new chart shape.
	// Memory data.
	// For example:
	// 		CFOPChartData* pMemChart = new CFOPChartData(5, 4);
	// 		
	// 		pMemChart->SetMainTitle(_T("Main Title"));
	// 		pMemChart->SetSubTitle(_T("Child Title"));
	// 		pMemChart->SetXAxisTitle(_T("X axis title"));
	// 		pMemChart->SetYAxisTitle(_T("Y axis title"));
	// 		pMemChart->SetZAxisTitle(_T("Z axis title"));
	// 		
	// 		for( short nCol = 0; nCol < 5; nCol++ )
	// 		{
	// 			pMemChart->SetColText( nCol, pMemChart->GetDefaultColumnText( nCol ));
	// 			
	// 			for( short nRow = 0; nRow < 4; nRow++ )
	// 			{
	// 				pMemChart->SetData( nCol, nRow, fDefaultArrX[ nRow ][ nCol ] );
	// 				pMemChart->SetRowText( nRow, pMemChart->GetDefaultRowText( nRow ));
	// 			}
	// 		}
	CFOPChartShape *AddChart(CFOPChartData* pMemData, const FOPRect & rcPos, const FOP_CHART_STYLE &nChartStyle = FOP_CHSTYLE_2D_BAR);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// used to snap link to nearest port,when create or moving link line,this method will be called for hit testing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A CPoint type value.  
	//		nRadius---nRadius, Specifies A integer value.
	virtual CFOPortShape*	PickNearestPort(
		// Mouse hit point.
		CPoint ptPoint, 
		// Within radius.
		int nRadius  = 20
		);

	// Drawing PanWnd window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Pan Window Objects, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawPanWndObjects(CDC* pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a child object to the Model.
    // pShape - the object to add
    // Objects at the "Head" are drawn first, thereby making them the object visually in the back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Child At Head, Adds an object to the specify list.
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	void				AddChildAtHead(CFODrawShape* pShape);
    
	//-----------------------------------------------------------------------
	// Summary:
	// Add a child object to the Model.
    // pShape - the object to add
    // Objects at the "Tail" are drawn last, thereby making them the object visually in the front.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Child At Tail, Adds an object to the specify list.
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
    void				AddChildAtTail(CFODrawShape* pShape);
    
	//-----------------------------------------------------------------------
	// Summary:
	// Add a child shape after a specify shape to the model.
	// pAdd -- shape being added.
	// pAfter -- shape after being insterted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Shape After, Inserts a child object at the given index..
	// Parameters:
	//		pAdd---pAdd, A pointer to the CFODrawShape or NULL if the call failed.  
	//		pAfter---pAfter, A pointer to the CFODrawShape or NULL if the call failed.
	void					InsertShapeAfter(CFODrawShape* pAdd, CFODrawShape* pAfter);

	//-----------------------------------------------------------------------
	// Summary:
	// Replace a specify shape with a new shape.
	// pReplaced -- being replaced shape.
	// pNew -- new shape.
	// Warning! Shape pNew must not be in the data model before replacing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Shape, .
	// Parameters:
	//		*pReplaced---*pReplaced, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		*pNew---*pNew, A pointer to the CFODrawShape  or NULL if the call failed.
	void					ReplaceShape(CFODrawShape *pReplaced,CFODrawShape *pNew);

	//-----------------------------------------------------------------------
	// Summary:
	// Find the shape after the specify shape.
	// pAfter -- specify after shape.
	// return NULL if cann't find it.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape After, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pAfter---pAfter, A pointer to the CFODrawShape or NULL if the call failed.
	CFODrawShape*			FindShapeAfter(CFODrawShape* pAfter);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the child object at the head of the Model's list.
    //Returns pos = NULL if there are no objects.
    //<p>
    //Example: 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Child Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.
    // POSITION pos = GetFirstChildPos();
    // while (pos) {
    // CFODrawShape* pObj = GetNextChild(pos);
    //    ... pObj ...
    // }
    long				GetFirstChildPos() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get the next object.
    // pos - the POSITION of the object in the list
    // Returns pos = NULL if there are no more objects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pos---Specifies A 32-bit long signed integer.
    CFODrawShape*			GetNextChild(const long& pos) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Sends object visually to the back.
    // pShape - the object to push
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Object To Back, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void			SendObjectToBack(CFODrawShape* pShape);

    //-----------------------------------------------------------------------
	// Summary:
	// Brings the object visually to the front.
    // pShape - the object to pop
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bring Object To Front, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
    virtual void			BringObjectToFront(CFODrawShape* pShape);
    
	//-----------------------------------------------------------------------
	// Summary:
	// Move object one step forward.
    // pShape - the object to pop
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Object Forward, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void			MoveObjectForward(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Move object one step backward.
    // pShape - the object to pop
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Object Backward, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void			MoveObjectBackward(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert new shape.
	// pShape -- the pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Shape, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void			InsertShape(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Add new shape
	// pShape -- the pointer of new shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL			AddShape(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Add new shape
	// pShape -- the pointer of new shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Shape At, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		&nIndex---&nIndex, Specifies A integer value.
	virtual BOOL			InsertShapeAt(CFODrawShape* pShape, const int &nIndex);

	//-----------------------------------------------------------------------
	// Summary:
	// Add new shapes to canvas.
	// list -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	virtual BOOL			AddShapes(const CFODrawShapeList& list);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove a specify shape.
	// pShape -- the pointer shape to remove.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL			RemoveShape(CFODrawShape* pShape);

	// Remove a list of shapes
	// list -- the list of shapes to remove.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	virtual BOOL			RemoveShapes(const CFODrawShapeList& list);

	//-----------------------------------------------------------------------
	// Summary:
	// Move shape.
	// pShapeItem -- pointer of shape.
	// szOffset -- offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShapeItem---Shape Item, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		szOffset---szOffset, Specifies A CSize type value.
	virtual BOOL			MoveShape(CFODrawShape *pShapeItem, CSize szOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Move a list of shapes
	// list -- list of shapes.
	// szOffset -- offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		szOffset---szOffset, Specifies A CSize type value.
	virtual BOOL			MoveShapes(const CFODrawShapeList& list,CSize szOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Limit a list of shapes within a specify rectangle.
	// lipstShapes -- list of shapes that to be positioned.
	// rRect -- New position area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Shapes Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*listShapes---*listShapes, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		rRect---rRect, Specifies A CRect type value.
	virtual void			LimitShapesArea(CFODrawShapeList *listShapes,const CRect& rRect);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape size.
	// Change shape size Spot
	// pShape -- pointer of shape.
	// nIndex -- the index of point of current shape.
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Spot, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeSpot(CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape size.
	// Change shape size Spot
	// pShape -- pointer of shape.
	// nIndex -- the index of point of current shape.
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Spot2, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeSpot2(CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape size.
	// Change shape size Spot
	// pShape -- pointer of shape.
	// nIndex -- the index of point of current shape.
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Center Spot, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeCenterSpot(CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's ext anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Extend Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeExtAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's Third anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Third Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeThirdAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's Four anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Four Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeFourAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's Five anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Five Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeFiveAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's text anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Text Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeTextAnchor(CFODrawShape *pShape,CPoint ptOffset);


	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's user anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape User Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeUserAnchor(CFODrawShape *pShape, const int &nPtIndex, CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's visio handle position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual BOOL			ScaleVisioShape(CFODrawShape *pShape,CPoint ptOffset, int handle);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape's Five anchor position.
	// Change shape size Spot
	// ptOffset -- offset position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape Center Anchor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL			SizeShapeCenterAnchor(CFODrawShape *pShape,CPoint ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the canvas and scale all the shapes on the canvas.
	// szNewCanvas -- new size of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Canvas And Scale All Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&szNewCanvas---New Canvas, Specifies A CSize type value.
	virtual BOOL			ScaleCanvasAndScaleAllShapes(const CSize &szNewCanvas);

	// Scale all the shapes on the canvas.
	// dXScale -- horizontal scale value.
	// dYScale -- vertical scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale All Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&dXScale---X Scale, Specifies a const double &dXScale object(Value).  
	//		&dYScale---Y Scale, Specifies a const double &dYScale object(Value).
	virtual BOOL ScaleAllShapes(const double &dXScale, const double &dYScale);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale a list of shapes by using each shape's own CONTROL_HANDLE.
	// list -- a list of shapes.
	// dX -- x scale.
	// dY -- y scale.
	// nControl -- drag handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nControl---nControl, Specifies a FO_CONTROL_HANDLE nControl object(Value).
	virtual BOOL	ScaleShapes(const CFODrawShapeList& list, double dX, double dY, FO_CONTROL_HANDLE nControl);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		rRef -- point reference.
	//		xFact---xFact, Specifies a double dX object(Value).  
	//		yFact---yFact, Specifies a double dY object(Value).  
	virtual BOOL	ScaleShapes(const CFODrawShapeList& list, const FOPPoint& rRef, const FOPFraction& xFact,
		const FOPFraction& yFact);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale shape by using shape's its own control handle point.
	// pShape -- the pointer of shape.
	// dX -- x scale.
	// dY -- y scale.
	// nControl -- drag handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nControl---nControl, Specifies a FO_CONTROL_HANDLE nControl object(Value).
	virtual BOOL			ScaleShape(CFODrawShape *pShape, double dX, double dY, FO_CONTROL_HANDLE nControl);

	void FOX_ZOrderSort(CFODrawShapeSet* pList, int nLower, int nUpper);
	void FOX_ZOrderSort(CFODrawShapeSet* pList);
	void FOX_ZOrderSortExt(CFODrawShapeList* pList);

	//-----------------------------------------------------------------------
	// Summary:
	// Scale shapes by using a specify same origin point.
	// list -- list of shapes.
	// dOrgX -- origin point x value.
	// dOrgY -- origin point y value.
	// dX -- x scale.
	// dY -- y scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape Extend, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&dOrgX---Org X, Specifies a const double &dOrgX object(Value).  
	//		&dOrgY---Org Y, Specifies a const double &dOrgY object(Value).  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	virtual BOOL			ScaleShapeExt(const CFODrawShapeList& list,const double &dOrgX,const double &dOrgY,double dX, double dY);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Group, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	// Add a list of shapes to a group shape.
	// list -- a list of shapes.
	// pGroup -- the pointer of group shape.
	virtual BOOL			Group(const CFODrawShapeList& list, CFOCompositeShape* pGroup, int nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ungroup, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	// Ungroup a group shape.
	// pGroup -- the pointer of group shape.
	virtual BOOL			Ungroup(CFOCompositeShape* pGroup, FOPShapeOrderMap* pIndexMap = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Rotate a list of shapes, rotating shapes by around each shape's own center.
	// list -- a list of shapes.
	// nAngle -- the rotate angle (from 0 to 360)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		nAngle---nAngle, Specifies A integer value.
	virtual BOOL			RotateShapes(const CFODrawShapeList& list, int nAngle);

	//-----------------------------------------------------------------------
	// Summary:
	// Rotate a specify shape by its own center point.
	// pShape -- the pointer of shape.
	// dXStart -- origin start point x.
	// dYStart -- origin start point y.
	// nAngle -- the rotate angle (from 0 to 360)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		dXStart---X Start, Specifies a double dXStart object(Value).  
	//		dYStart---Y Start, Specifies a double dYStart object(Value).  
	//		nAngle---nAngle, Specifies A integer value.
	virtual BOOL			RotateShape(CFODrawShape *pShape,double dXStart,double dYStart, int nAngle);

	//-----------------------------------------------------------------------
	// Summary:
	// Rotate a specify shapes,rotate the shapes by arounding a specify same center point.
	// list -- the list of shapes.
	// dXStart -- origin center point x.
	// dYStart -- origin center point y.
	// nAngle -- the rotate angle (from 0 to 360)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape Extend, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		dXStart---X Start, Specifies a double dXStart object(Value).  
	//		dYStart---Y Start, Specifies a double dYStart object(Value).  
	//		nAngle---nAngle, Specifies A integer value.
	virtual BOOL			RotateShapeExt(const CFODrawShapeList& list,const CFODrawShapeList& listCenter,
		double dXStart,double dYStart, int nAngle);

	//-----------------------------------------------------------------------
	// Summary:
	// skewing shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual BOOL			SkewXShapes(const CFODrawShapeList& list,int nAngle, double dOX, double dOY);

	//-----------------------------------------------------------------------
	// Summary:
	// skewing shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual BOOL			SkewYShapes(const CFODrawShapeList& list,int nAngle, double dOX, double dOY);

	//-----------------------------------------------------------------------
	// Summary:
	// Mirror a list of specify shapes.
	// list -- the list of shapes.
	// ptRef1 -- Mirror first ref point.
	// ptRef2 -- Mirror end ref point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	virtual BOOL			MirrorShapes(const CFODrawShapeList& list,const CFODrawShapeList& listCenter,
		const CPoint &ptRef1,const CPoint &ptRef2);

	// Mirror shapes with horizontal.
	void MirrorShapesHorizontal(const CFODrawShapeList& list);

	// Mirror shapes with vertical.
	void MirrorShapesVertical(const CFODrawShapeList& list);

	virtual void DoGenNameOfGroup(CFODrawShape *pShape);

	// Align shapes with bounding or snap,it will align shapes but it do not need the main shape.
	// eHor -- horizontal type,it must be one of the following value:
	// 	enum FOPHorzAlign  
	// {
	// 	FOPHALIGN_NONE,
	// 	FOPHALIGN_LEFT,
	// 	FOPHALIGN_RIGHT,
	// 	FOPHALIGN_CENTER
	// };
	// eVert -- vertical type.
	// 	enum FOPVertAlign 
	// {
	// 	FOPVALIGN_NONE,
	// 	FOPVALIGN_TOP,
	// 	FOPVALIGN_BOTTOM,
	// 	FOPVALIGN_CENTER
	// };
	// bBoundRects -- use bounding rectangle or snap rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alignment Marked Objects Without Main, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		eHor---eHor, Specifies a FOPHorzAlign eHor object(Value).  
	//		eVert---eVert, Specifies a FOPVertAlign eVert object(Value).  
	//		bBoundRects---Bound Rects, Specifies A Boolean value.
	virtual void AlignShapesWithoutMain(const CFODrawShapeList& list, FOPHorzAlign eHor, FOPVertAlign eVert, BOOL bBoundRects=FALSE);


	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	virtual BOOL			MirrorShapes(const CFODrawShapeList& list, const CPoint &ptRef1,const CPoint &ptRef2);

	//-----------------------------------------------------------------------
	// Summary:
	// Change shape size,
	// pShape -- the pointer of shape.
	// rcNew -- the new position of shape.
	// dX -- x scale value.
	// dY -- y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		rcNew---rcNew, Specifies A CRect type value.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	virtual BOOL			SizeShape(CFODrawShape *pShape,CRect rcNew,double dX,double dY);

	// Change form position.
	// pShape -- the form back shape.
	// rcNew -- the new position of form.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Form Size Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		rcNew---rcNew, Specifies A CRect type value.
	virtual BOOL			FormSizeChange(CRect rcNew);

	//-----------------------------------------------------------------------
	// Summary:
	// Change form name and position.
	// Change form position.
	// pShape -- the form back shape.
	// strName -- the new caption of form
	// rcNew -- the new position of form.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Form Name Size Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		strName---strName, Specifies A CString type value.  
	//		rcNew---rcNew, Specifies A CRect type value.
	virtual BOOL			FormNameSizeChange(CFODrawShape *pShape,CString strName,CRect rcNew);

	//-----------------------------------------------------------------------
	// Summary:
	// Change form back color and caption text color.
	// pShape -- the form back shape.
	// crBack -- new back color of form.
	// crText -- new caption color of form.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Form Color Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.
	virtual BOOL			FormColorChange(CFODrawShape *pShape,COLORREF crBack,COLORREF crText);

	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate the tab order of shapes.
	// nOrder -- the start tab order to recalculate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Order, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nOrder---nOrder, Specifies A integer value.
	virtual void			RecalcOrder(int nOrder);

	// Reset all select mode of select.
	virtual void ResetAllShapeSelectMode();

	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize tab Order
	// return the maximize tab order of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Order, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int				GetMaxOrder();

	//-----------------------------------------------------------------------
	// Summary:
	// Calculate the unique tab order.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Tab Order, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int				GetUniqueTabOrder();

	//-----------------------------------------------------------------------
	// Summary:
	// Get current tab order shape.
	// list -- shapes list.
	// nTabOrder -- current tab order.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Tab Order, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&nTabOrder---Tab Order, Specifies A integer value.
	virtual CFODrawShape *	FindShapeWithTabOrder(const CFODrawShapeList& list,const int &nTabOrder);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the pointer of next tab order.
	// list -- shapes list.
	// nCurTabOrder -- current tab order.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Tab Order Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&nCurTabOrder---Current Tab Order, Specifies A integer value.  
	//		nCellIndex---Cell Index, Specifies A integer value.
	virtual CFODrawShape *  GetNextTabOrderShape(const CFODrawShapeSet& list,const int &nCurTabOrder, int nCellIndex = -1);

	// Obtain the pointer of previous tab order.
	// list -- shapes list.
	// nCurTabOrder -- current tab order.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Tab Order Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&nCurTabOrder---Current Tab Order, Specifies A integer value.
	virtual CFODrawShape *  GetPrevTabOrderShape(const CFODrawShapeSet& list,const int &nCurTabOrder);

	//-----------------------------------------------------------------------
	// Summary:
	// Get next tab order shape.
	// Get max rectangle of all link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&lstUpdate---&lstUpdate, Specifies a E-XD++ CFODrawShapeList &lstUpdate object (Value).
	virtual void			GetAllLinkedShape(const CFODrawShapeList& list, CFODrawShapeList &lstUpdate);

	// Obtain all the data updated shapes.
	virtual void			GetAllUpdateShape(CFODrawShapeList &lstUpdate);

	//-----------------------------------------------------------------------
	// Summary:
	// Get maximize rectangle of all link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Links Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect			GetMaxLinksRect();

	//-----------------------------------------------------------------------
	// Summary:
	// Get maximize rectangle of a list shapes, it's the maximize bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Bounds Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&bOnlyVisible---Only Visible, Specifies A Boolean value.
	virtual CRect			GetMaxBoundsRect(
		// List of shapes.
		const CFODrawShapeList& list,
		const BOOL &bOnlyVisible = TRUE
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get total bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CRect					GetTotalSnapRect(const CFODrawShapeList& list) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get maximize rectangle of a list shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Bounds Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&bOnlyVisible---Only Visible, Specifies A Boolean value.
	virtual CRect			GetMaxBoundsRect(
		// List of shapes.
		const CFODrawShapeSet& list,
		const BOOL &bOnlyVisible = TRUE
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get total snap rectangle of a list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	CRect					GetTotalSnapRect(const CFODrawShapeSet& list) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Convert current component to bitmap.
	// bmp -- output bitmap handle.
	// cx -- width of the output bitmap.
	// cy -- height of the output bitmap.
	// crBack -- back color of the output bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bmp---Specifies a CBitmap &bmp object(Value).  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual void GetBitmap(CBitmap &bmp, int cx, int cy,COLORREF crBack = RGB(255,255,255));

	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bmp---Specifies a CBitmap &bmp object(Value).  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual void GetBitmapOfShapes(CFODrawShapeSet *pListShapes, CBitmap &bmp, int cx, int cy,COLORREF crBack = RGB(255,255,255));

	// Scale all the shapes on the canvas.
	// dXScale -- horizontal scale value.
	// dYScale -- vertical scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale All Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&dXScale---X Scale, Specifies a const double &dXScale object(Value).  
	//		&dYScale---Y Scale, Specifies a const double &dYScale object(Value).
	virtual BOOL ScaleAllShapesWith(CFODrawShapeSet *pListShapes, const FOPPoint &ptRef, const double &dXScale, const double &dYScale);

	//-----------------------------------------------------------------------
	// Summary:
	// get the preview thumbnail bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Preview Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pBitmap---*pBitmap, A pointer to the CFOPreviewBitmap  or NULL if the call failed.
    virtual void			GetPreviewBitmap(
		// Thumbnail bitmap.
		CFOPreviewBitmap *pBitmap
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Display preview image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Display Preview Bitmap, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pBitmap---pBitmap, A pointer to the CFOPreviewBitmap  or NULL if the call failed.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255---Specifies a 255 object(Value).
	virtual void			DisplayPreviewBmp(
		// Device dc.
		CDC * pDC, 
		// Rectangle to be draw within.
		CRect rcPos,
		// Thumbnail bitmap,using GetPreviewBitmap instead.
		CFOPreviewBitmap * pBitmap,
		// Back color.
		COLORREF crBack = RGB(255,255,255)
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Validate offset point for moving shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Valid Move Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pList---pList, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nXOffset---X Offset, Specifies A integer value.  
	//		&nYOffset---Y Offset, Specifies A integer value.
	virtual BOOL			ValidMoveShape(
		// List of shapes.
		CFODrawShapeList* pList, 
		// X offset value.
		int& nXOffset, 
		// Y offset value.
		int &nYOffset
		);

	BOOL CheckNearPoints(const FOPPoint &pt1, const FOPPoint &pt2);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Tab order.
	// nOrder -- the new tab order.
	// pSel -- the pointer of shape to change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Tab, .
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nOrder---nOrder, Specifies A integer value.  
	//		*pSel---*pSel, A pointer to the CFODrawShape  or NULL if the call failed.
	CFODrawShape*			ChangeTab(int nOrder,CFODrawShape *pSel);

	//-----------------------------------------------------------------------
	// Summary:
	// Add an empty shape.
	// this function add a new shape to the modal at first and then remove it from the list.
	// pShape -- the pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Empty Shape, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	BOOL					AddEmptyShape(CFODrawShape *pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Full Link, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aShapes---aShapes, Specifies a FOPContainer aShapes object(Value).  
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void			RebuildFullLink(const FOPContainer &aShapes,
		// List of shapes.
		const CFODrawShapeSet& list
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Link For Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void			RebuildLinkForModel(
		// List of shapes.
		const CFODrawShapeSet& list
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Restore all the connections of the data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore All Connections, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			RestoreAllConnections();

	//-----------------------------------------------------------------------
	// Summary:
	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Form, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void			CheckForm(CFOPortShape *pPort);

	//-----------------------------------------------------------------------
	// Summary:
	// Find port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		strName---strName, Specifies A CString type value.
	virtual CFOPortShape *	FindPortName(
		// Specifies the list of shapes to find.
		const CFODrawShapeList& list,
		// Specifies the name of port to find
		const CString strName
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get all ports of the list shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search All Ports, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLstPorts---Lst Ports, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&list---Specifies a const CFODrawShapeList &list object(Value).
	virtual void			SearchAllPorts(CFODrawShapeList *pLstPorts,const CFODrawShapeList &list);

	//-----------------------------------------------------------------------
	// Summary:
	// Find port with specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		&point---Specifies A CPoint type value.
	virtual CFOPortShape *	FindPort(
		// Specifies the point.
		const CPoint &point
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Check all links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Full Link, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&m_listPorts---&m_listPorts, Specifies a E-XD++ CFODrawShapeList &m_listPorts object (Value).
	virtual void			ClearFullLink(
		// Specifies the list of shapes.
		const CFODrawShapeList& list,
		// Ports of the list of shapes.
		CFODrawShapeList &m_listPorts
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it is need saving property now.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Property Now, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL			DoSavePropNow();

	//-----------------------------------------------------------------------
	// Summary:
	// Check all property indexes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Property Index, Called this function to empty a previously initialized CFODataModel object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void			ResetAllPropIndex(const CFODrawShapeSet& list);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check all links.
	// list -- list of shapes.
	// bNeedProp -- need property or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Link Names, Called this function to empty a previously initialized CFODataModel object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&bNeedProp---Need Property, Specifies A Boolean value.
	virtual void			ResetLinkNames(const CFODrawShapeSet& list, const BOOL &bNeedProp = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Check all links.
	// list -- list of shapes.
	// bNeedProp -- need property or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Link Names, Called this function to empty a previously initialized CFODataModel object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&bNeedProp---Need Property, Specifies A Boolean value.
	virtual void			ResetCacheShapes(const CFODrawShapeSet& list, const BOOL &bNeedProp = TRUE);


	//-----------------------------------------------------------------------
	// Summary:
	// Do change link port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Link Port Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	virtual void			DoChangeLinkPortName(const CFODrawShapeList& list);

	//-----------------------------------------------------------------------
	// Summary:
	// Create base shape name, assign a base name for a specify shape,override this method to asign a base shape name
	// for your own custom shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Base Name, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString			CreateBaseName(
		// Type of shape.
		UINT nType
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Create base shape caption, assign a base caption for a specify shape,override this method to asign a base shape
	// caption for your own custom shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Base Caption, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString			CreateBaseCaption(
		// Type of shape
		UINT nType
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Serializes the xdg file data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Xdg File Shapes, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).  
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeSet &listShapes object (Value).  
	//		&bShowRuler---Show Ruler, Specifies A Boolean value.
	virtual void SerializeXdgShapes(CArchive& ar,CFODrawShapeSet &listShapes, BOOL &bShowRuler);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the pointer of sub - graph shape that contains the list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Contain Child Graph Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&rcAll---&rcAll, Specifies A CRect type value.
	virtual CFOCompositeShape *GetContainSubGraphShape(CFODrawShapeList* pShapeList, const CRect &rcAll);

	// Serializes the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Sid file Shapes, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).  
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeSet &listShapes object (Value).
	virtual void SerializeSidShapes(CArchive& ar,CFODrawShapeSet &listShapes);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Sid file, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeSid(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Sid file, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeSimple(CArchive &ar);

	// Printer unit convert.
	int FOPrinterUnitConvert(const int val, DWORD dwOld, DWORD dwNew);

	// Obtain printer margins.
	void FOGetPrinterMargins(CWinApp* pApp, CRect& rcMagins, const DWORD dwUnit);

	// Compare two rectangle.
	void FOPCompareTwoRect(const FOPRect &rc1, const FOPRect& rc2, CPoint &ptRetRc1, CPoint &ptRetRc2);

	// Compare two rectangle y value.
	int FOPCompareTwoRectY(const FOPRect &rc1, const FOPRect& rc2);

	// Compare two rectangle x value.
	int FOPCompareTwoRectX(const FOPRect &rc1, const FOPRect& rc2);
	void UpdateAllClones();
	void StartClone();
	void EndClone();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Draw all the shapes on the canvas to device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shape, Draw all the shapes on the canvas to device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void			OnDrawShape(
		// DC.
		CDC *pDC,
		// Client rectangle of view
		const CRect &rcView
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw all the shapes on the canvas to device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check All Within View, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			CheckAllWithinView();

	//-----------------------------------------------------------------------
	// Summary:
	// Draw all the shape's database name that connected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw All Shape D B Name, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void			OnDrawAllShapeDBName(
		// DC.
		CDC *pDC,
		// Client rectangle of view
		const CRect &rcView
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw all the shapes on the canvas to device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Pan Shape, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void			OnDrawPanShape(
		// DC.
		CDC *pDC,
		// Client rectangle of view
		const CRect &rcView
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Print all the shapes on the canvas to printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print Shape, Print all the shapes on the canvas to printer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void			OnPrintShape(
		// DC.
		CDC *pDC,
		// Client rectangle of view
		const CRect &rcView
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw shapes with all of its ports.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shape Normal, Draw all the shapes on the canvas to device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void			OnDrawShapeNormal(CDC *pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw shape ports.
	// pShape -- ports shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ports, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void			DoDrawPorts(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw  Tab Order
	// pDC -- pointer of the DC.
	// rcView -- validate view rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Tab Order, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void			OnDrawTabOrder(CDC *pDC,const CRect &rcView);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw Back ground.
	// pDC -- pointer of the DC.
	// rcClip -- clip rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Back, Draw the background of this canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	virtual void			OnDrawBack(CDC *pDC,const CRect &rcClip);

	//-----------------------------------------------------------------------
	// Summary:
	// Correct position.
	// rc -- normal rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Normal Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void			NormalRect(CRect &rc);

	//-----------------------------------------------------------------------
	// Summary:
	// Find the index of shape within all the list of the shapes on the canvas.
	// pFind -- pointer of the shape to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape Position, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		*pFind---*pFind, A pointer to the CFODrawShape  or NULL if the call failed.
	int						FindShapePosition(CFODrawShape *pFind);


	// update order index after.
	virtual void UpdateOrderIndexAfter(const int &nAfter);

	//-----------------------------------------------------------------------
	// Summary:
	// 
	// Find Shape with its Caption
	// if find return true,else return false.
	// str -- Caption of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Component Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&str---Specifies A CString type value.
	virtual BOOL			FindCompCaption(const CString &str);

	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape with its name
	// if find return true,else return false.
	// str -- name of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Component Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&str---Specifies A CString type value.
	virtual BOOL			FindCompName(const CString &str);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate name and caption.
	// Find Shape with its Caption
	// if find return the pointer of the shape,else return NULL.
	// str -- caption of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Component With Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&str---Specifies A CString type value.
	virtual CFODrawShape*	FindCompWithCaption(const CString &str);

	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape its name
	// if find return the pointer of the shape,else return NULL.
	// strName -- name of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Component With Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	virtual CFODrawShape*	FindCompWithName(const CString &strName);

	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with name, it will search all the children in all depths.
	// strName -- name of this shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Name In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	CFODrawShape *FindShapeWithNameInAllDepth(const CString &strName);

	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value.
	// strKey -- the first key value of this shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	virtual CFODrawShape *FindShapeWithKey1(const CString &strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- the first key value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key1 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	virtual CFODrawShape *FindShapeWithKey1InAllDepth(const CString &strKey);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value.
	// strKey -- the key value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key2, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey2(const CString &strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- the key value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key2 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey2InAllDepth(const CString &strKey);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value.
	// strKey -- the key value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key3, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey3(const CString &strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- the key value of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key3 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey3InAllDepth(const CString &strKey);


	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Name,this will check all the shapes on the canvas,and generate the unique name.
	// nType -- type of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString			GetUniqueName(UINT nType);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Caption,this will check all the shapes on the canvas,and generate the unique caption.
	// nType -- type of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Caption, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString			GetUniqueCaption(UINT nType);

	//-----------------------------------------------------------------------
	// Summary:
	// Reset the content.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Content, Reset the content and clear all the data of this data model.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			ResetContent();

	//-----------------------------------------------------------------------
	// Summary:
	// Reset the content.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Content, Reset the content and clear all the data of this data model.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			ResetContent2();

	//-----------------------------------------------------------------------
	// Summary:
	// Clear All shapes from the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			ClearAll();

	//-----------------------------------------------------------------------
	// Summary:
	// Get the maximize Size of all shapes on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Most Form Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize			GetMostFormSize();

	//-----------------------------------------------------------------------
	// Summary:
	// Find shape with in a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With In, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcWithIn---With In, Specifies A CRect type value.
	virtual BOOL			FindShapeWithIn(
		// Specify rectangle.
		const CRect &rcWithIn
		);

	// Set page size.
	void SetPageSizeW(const fopPageSize &szType);

	//-----------------------------------------------------------------------
	// Summary:
	//	Get the line's interest point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Intersect Upright, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pLineShape---Line Shape, A pointer to the CFOUpRightLinkShape or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	BOOL DoIntersectUpright(CFOUpRightLinkShape* pLineShape,const CRect &rcView);

	//-----------------------------------------------------------------------
	// Summary:
	//	Get the line's interest point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Intersect Upright_ New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&A---&A, Specifies A CPoint type value.  
	//		&B---&B, Specifies A CPoint type value.  
	//		CArray<float---Array<float, Specifies A CArray array.  
	//		&v---Specifies A float value.  
	//		&rcView---&rcView, Specifies A CRect type value.  
	//		*pLink---*pLink, A pointer to the CFOUpRightLinkShape  or NULL if the call failed.
	virtual int DoIntersectUpright_New(const CPoint &A, const CPoint &B, CArray<float,float> &v, const CRect &rcView, 
		CFOUpRightLinkShape *pLink);

	//-----------------------------------------------------------------------
	// Summary:
	//	Get the line's interest point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Intersect Links, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&mLinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &mLinkList object (Value).  
	//		&nCurIndex---Current Index, Specifies A integer value.  
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void DoGetIntersectLinks(CFODrawShapeSet &mLinkList, int &nCurIndex, CFOLinkShape *pLink);

	//-----------------------------------------------------------------------
	// Summary:
	//	Get the line's interest point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Intersect Test Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&mLinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &mLinkList object (Value).  
	//		&nCurIndex---Current Index, Specifies A integer value.  
	//		*lineConnect---*lineConnect, A pointer to the CFOLineConnect  or NULL if the call failed.  
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual int DoIntersectTestLine(CFODrawShapeSet &mLinkList,const int &nCurIndex,
		CFOLineConnect *lineConnect, CFOLinkShape *pLink);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate all ports indexes
	// list -- list of the shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Up Right Link List, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a E-XD++ CFODrawShapeSet& list object (Value).  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		*pLink---*pLink, A pointer to the CFOUpRightLinkShape  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.  
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nCurIndex---Current Index, Specifies A integer value.
	virtual void GenUpRightLinkList(CFODrawShapeSet& list, CFODrawShape *pShape, CFOUpRightLinkShape *pLink, const CRect &rcView, int &nIndex, int &nCurIndex);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Within Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Within Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		bFullSelect---Full Select, Specifies A Boolean value.  
	//		bWithIn---With In, Specifies A Boolean value.
	virtual int		GetShapesWithinRect(
		// List of shapes.
		CFODrawShapeList* pShapeList, 
		// A specify rectangle.
		const CRect &rect,
		// Full select.
		BOOL bFullSelect,
		BOOL bWithIn
		);


	// Obtain shapes within bounding rectangle.
	virtual int		GetShapesWithinBoundRect(
		// List of shapes.
		CFODrawShapeList* pShapeList,const CRect &rect);
	
	//-----------------------------------------------------------------------
	// Summary:
	//Get Shapes Within ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Within Ellipse, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&rcEllipse---&rcEllipse, Specifies A CRect type value.  
	//		bFullSelect---Full Select, Specifies A Boolean value.  
	//		bWithIn---With In, Specifies A Boolean value.
	virtual int		GetShapesWithinEllipse(
		// List of shapes.
		CFODrawShapeList* pShapeList, 
		// A specify rectangle for ellipse
		const CRect &rcEllipse,
		// Full select.
		BOOL bFullSelect,
		BOOL bWithIn
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the maximize rectangle of all view shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Shapes Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
	FOPRect GetViewShapesRect();

	//-----------------------------------------------------------------------
	// Summary:
	// Build in view links.
	// rcView -- position of view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate In View Links, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcView---&rcView, Specifies a const FOPRect &rcView object(Value).
	virtual void DoGenInViewLinks(const FOPRect &rcView);

	//-----------------------------------------------------------------------
	// Summary:
	// Build in view links.
	// rcView -- position of view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate In View Links, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcView---&rcView, Specifies a const FOPRect &rcView object(Value).
	virtual void DoGenInViewInvalid(const FOPRect &rcView, BOOL bZoomOut);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate links in view.
	// pShape -- pointer of shape.
	// rcView -- position of view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Generate In View Links, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies a const FOPRect &rcView object(Value).
	virtual void FOPGenInViewLinks(CFODrawShape *pShape, const FOPRect &rcView);

	//-----------------------------------------------------------------------
	// Summary:
	// Clear links in view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear In View Links, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoClearInViewLinks();

	// Check shape in.
	void DoCheckShapeIn(CFODrawShape *pShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Save with cache mode.
	void FOSerializeCaches(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize S2, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).  
	//		&bShowRuler---Show Ruler, Specifies A Boolean value.
	virtual void SerializeS2(CArchive &ar, BOOL &bShowRuler);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize page setup data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Page Setup, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializePageSetup(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Save Document to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	//-----------------------------------------------------------------------
	// Summary:
	// Open Document from a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	//-----------------------------------------------------------------------
	// Summary:
	// Save Document to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument2(LPCTSTR lpszPathName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document from a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument2(LPCTSTR lpszPathName);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of File.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//-----------------------------------------------------------------------
	// Summary:
	// Release File from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	//-----------------------------------------------------------------------
	// Summary:
	// Export To S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	virtual void ExportToSVG(CString);

	// Find helper
	CFODrawPortsShape *fopFindInHelper(CFOCompositeShape *pGroup, const int &nIndex);
	
	// Find in
	CFODrawPortsShape *fopFindIn(const FOPContainer& m_List, const int &nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check port to link shape.
	virtual void			RebuildFullLinkx(const CFODrawShapeSet& m_List);
	
	// Add group shape
	CFOCompositeShape *AddGroupShape(UINT m_drawshape, CRect rc);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Clear all the properties of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Property, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			ClearAllProp();

	//-----------------------------------------------------------------------
	// Summary:
	// Opera for properties,obtain the pointer to the list of properties of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property List, Returns the specified property value.
	//		Returns a pointer to the object CFOBasePropertiesList ,or NULL if the call failed
	CFOBasePropertiesList *	GetPropList();
	

	/////////////////////////////////////
	// Model's properties.
	//////////////////////////////////////

	//-----------------------------------------------------------------------
	// Summary:
	// Put model prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Model Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL			PutModelPropValue(
		// Specifies the ID of property.
		const int &nPropId,
		// Specifies the value of property
		const FO_VALUE &Value
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Put model prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL			GetModelPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specifies the ID of property.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Model Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnModelPropertyChange(const int &nPropId, CFOBaseProperties* prop);


	//-----------------------------------------------------------------------
	// Summary:
	// Take the id value of the property items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Model Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeModelValue(CArray<int, int> &arValues);

	//-----------------------------------------------------------------------
	// Summary:
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Property Item Name, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakePropertyItemName(int nValueId, CString& strItemName);

	//-----------------------------------------------------------------------
	// Summary:
	// Do model prop change actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Multiple Model Property Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiModelPropAction,or NULL if the call failed  
	// Parameters:
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual CFOMultiModelPropAction* DoMultiModelPropAction(
		// Specifies the value to change.
		const FO_VALUE &Value,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get model's actions by create a new action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Property Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiModelPropAction,or NULL if the call failed
	virtual CFOMultiModelPropAction* GetModelPropAction();


	///////////////////////////////////////////////////
	// Use the following methods to change the properties,it will support undo/redo actions.

	//-----------------------------------------------------------------------
	// Summary:
	// Change bool value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Bool Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelBoolProp(
		// Specifies the new value of property.
		const BOOL &bValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change CString value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model String Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelStringProp(
		// Specifies the new value of property.
		const CString &strValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Int Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelIntProp(
		// Specifies the new value of property.
		const int &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change UINT value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model U I N T Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelUINTProp(
		// Specifies the new value of property.
		const UINT &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change float value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Float Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelFloatProp(
		// Specifies the new value of property.
		const float &fValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Double Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelDoubleProp(
		// Specifies the new value of property.
		const double &dValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Date Time value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Date Time Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelDateTimeProp(
		// Specifies the new value of property.
		const COleDateTime &dtValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change COLOR value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Color Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelColorProp(
		// Specifies the new value of property.
		const COLORREF &crValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change DWORD value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model D Word Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeModelDWordProp(
		// Specifies the new value of property.
		const DWORD &dwValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);


	/////////////////////////////////////
	// Shape's properties.
	//////////////////////////////////////

	//////////////////////////////////////
	//-----------------------------------------------------------------------
	// Summary:
	// Put shape prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shape Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual void PutShapePropValue(
		// Specifies the pointer of shape
		CFODrawShape *pShape,
		// Specifies the ID of property which you want to change.
		const int &nPropId,
		// Specifies the new value
		const FO_VALUE &Value
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Put shape prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FO_VALUE value (Object).  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual FO_VALUE GetShapePropValue(
		// Specifies the pointer of shape
		CFODrawShape *pShape,
		// Specifies the ID of property which you want to get.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Do multi shapes prop change actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Multiple Shape Property Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiShapePropAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual CFOMultiShapePropAction* DoMultiShapePropAction(
		// Specifies the list of shapes.
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const FO_VALUE &Value,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Do multi shapes prop change actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Multiple Shape Property Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiShapePropAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual CFOMultiShapePropAction* DoMultiShapePropAction(
		// Specifies the list of shapes.
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const FO_VALUE &Value,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get shapes prop actions by create a new action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Property Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiShapePropAction,or NULL if the call failed
	virtual CFOMultiShapePropAction* GetShapesPropAction();

	///////////////////////////////////////////////////
	// Use the following methods to change the properties,it will support undo/redo actions.

	//-----------------------------------------------------------------------
	// Summary:
	/// Change bool value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Bool Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesBoolProp(
		// Specifies the list of shape.
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const BOOL &bValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change CString value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes String Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesStringProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const CString &strValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Int Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesIntProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const int &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change UINT value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes U I N T Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesUINTProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const UINT &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change float value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Float Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesFloatProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const float &fValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Double Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDoubleProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const double &dValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Date Time value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Date Time Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDateTimeProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const COleDateTime &dtValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change COLOR value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Color Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesColorProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const COLORREF &crValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change DWORD value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes D Word Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDWordProp(
		// Specifies the list of shape
		CFODrawShapeList* pShapeList,
		// Specifies the new value.
		const DWORD &dwValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);


	///////////////////////////////////////////////////
	// Use the following methods to change the properties,it will support undo/redo actions.

	//-----------------------------------------------------------------------
	// Summary:
	// Change bool value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Bool Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesBoolProp(
		// Specifies the list of shape.
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const BOOL &bValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change CString value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes String Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesStringProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const CString &strValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Int Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesIntProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const int &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change UINT value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes U I N T Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesUINTProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const UINT &nValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change float value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Float Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesFloatProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const float &fValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Double Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDoubleProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const double &dValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Date Time value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Date Time Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDateTimeProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const COleDateTime &dtValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change COLOR value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Color Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesColorProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const COLORREF &crValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change DWORD value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes D Word Property, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void ChangeShapesDWordProp(
		// Specifies the list of shape
		CFODrawShapeSet* pShapeList,
		// Specifies the new value.
		const DWORD &dwValue,
		// Specifies the ID of property which you want to change.
		const int &nPropId
		);

	/////////////////////////////////////////////////////
	//-----------------------------------------------------------------------
	// Summary:
	// Add a new property
	// prop -- the new property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Property, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---Specifies a E-XD++ CFOBaseProperties& prop object (Value).
	virtual BOOL AddNewProperty(CFOBaseProperties& prop);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new property,and do not use delete to release the pProp,it delete by this method.
	// pProp -- the pointer of new property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Property Pointer, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pProp---*pProp, A pointer to the CFOBaseProperties  or NULL if the call failed.
	virtual BOOL AddNewPropertyPtr(CFOBaseProperties *pProp);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove a property
	// nId -- the id of property to remove.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Property, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nId---nId, Specifies A integer value.
	virtual BOOL RemoveProperty(const int nId);

	//-----------------------------------------------------------------------
	// Summary:
	// Add new bool user define property value for this shape.
	// nPropID -- the ID of this property value.
	// bValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bool User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		bValue---bValue, Specifies A Boolean value.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddBoolUserProperty(long nPropID, BOOL bValue, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new string user define property value for this shape.
	// nPropID -- the ID of this property value.
	// strValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add String User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddStringUserProperty(long nPropID, LPCTSTR strValue, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new int user define property value for this shape.
	// nPropID -- the ID of this property value.
	// nValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Int User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddIntUserProperty(long nPropID, long nValue, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new float user define property value for this shape.
	// nPropID -- the ID of this property value.
	// fValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Float User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		fValue---fValue, Specifies A float value.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddFloatUserProperty(long nPropID, float fValue, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new double user define property value for this shape.
	// nPropID -- the ID of this property value.
	// dValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Double User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddDoubleUserProperty(long nPropID, double dValue, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new date time user define property value for this shape.
	// nPropID -- the ID of this property value.
	// dtValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Date User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dtTime---dtTime, Specifies a DATE dtTime object(Value).  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddDateUserProperty(long nPropID, DATE dtTime, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new color user define property value for this shape.
	// nPropID -- the ID of this property value.
	// crValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Color User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddColorUserProperty(long nPropID, COLORREF crColor, const CString &strPropName = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add new dword user define property value for this shape.
	// nPropID -- the ID of this property value.
	// dwValue -- value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add D Word User Property, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dwData---dwData, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&strPropName---Property Name, Specifies A CString type value.
	BOOL AddDWordUserProperty(long nPropID, DWORD dwData, const CString &strPropName = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Value Extend, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropValueExt(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Bool Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropBoolValue(
		// Return value.
		BOOL &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property String Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropStringValue(
		// Return value.
		CString &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Int Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropIntValue(
		// Return value.
		int &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Float Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropFloatValue(
		// Return value.
		float &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Double Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a double &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropDoubleValue(
		// Return value.
		double &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Date Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a DATE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropDateValue(
		// Return value.
		COleDateTime &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Color Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropColorValue(
		// Return value.
		COLORREF &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property D Word Value, Returns the specified property value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies A 32-bit long signed integer.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetPropDWordValue(
		// Return value.
		long &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Bool Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A Boolean value.
	virtual BOOL PutPropBoolValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const BOOL &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property String Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL PutPropStringValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const LPCTSTR &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Int Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A integer value.
	virtual BOOL PutPropIntValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const int &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Float Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A float value.
	virtual BOOL PutPropFloatValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const float &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Double Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const double &Value object(Value).
	virtual BOOL PutPropDoubleValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const double &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Date Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const DATE &Value object(Value).
	virtual BOOL PutPropDateValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const COleDateTime &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property Color Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A 32-bit COLORREF value used as a color value.
	virtual BOOL PutPropColorValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const COLORREF &Value
		);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Property D Word Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies A integer value.
	virtual BOOL PutPropDWordValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const int &Value
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Find property.
	// nId -- ID of this property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Property, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A integer value.
	virtual CFOBaseProperties* FindProperty(int nId) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Find property.
	// nId -- ID of this property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Property, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A integer value.
	virtual CFOBaseProperties* FindProperty2(const CString &strName) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Property
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Property, Returns the specified value.
	//		Returns a pointer to the object CFOFormProperties ,or NULL if the call failed
	CFOFormProperties *GetDefaultProperty() const;


	//-----------------------------------------------------------------------
	// Summary:
	// Init default printer setting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Printer, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CreateDefaultPrinter();

	//-----------------------------------------------------------------------
	// Summary:
	// Change Form Position,only limited for form design mode application.
	// it will call SetPagePosition(..) by default.
	// rc -- position of the form,its top left corner must be 0,0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Form Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void ChangeFormPos(CRect &rc);

	//-----------------------------------------------------------------------
	// Summary:
	// Change Form Position And Name,only limited for form design mode application.
	// rc -- position of the form,its top left corner must be 0,0
	// strName -- name of the form
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Form Position And Name, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void ChangeFormPosAndName(CRect &rc,CString &strName);

	// Returns the pointer to the background shape of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Draw Component, Returns the specified value.
	//		Returns a pointer to the object CFOBackShape ,or NULL if the call failed
	CFOBackShape *GetBackDrawComp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change the canvas's background shape,override this method to change the shape of the background.
	// m_pBack -- must be a validate pointer to the background shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Back Draw Component, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*m_pBack---*m_pBack, A pointer to the CFOBackShape  or NULL if the call failed.
	virtual void SetBackDrawComp( CFOBackShape *m_pBack);

	// Find shape within temp link list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find With In Temp List, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	BOOL FindWithInTempList(CFOLinkShape *pLink);

	// Generate value from expression.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Value From Expression, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		&strExp---&strExp, Specifies A CString type value.
	virtual CString DoGenValueFromExpression(const CString &strExp);

	// Do sort shape with.
	// nSortType -- 0 is Name, 1 is Caption, 2 is Key1, 3 is key2, 4 is key3
	virtual void DoSortShapeWith(FOPContainer *lShape, int nSortType = 0);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get the Printer page Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPrintPosition()				{ return m_rcPrintPage; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the Printer page Position
	// rcPage -- page position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Position, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPage---&rcPage, Specifies A CRect type value.
	virtual void SetPrintPosition(CRect &rcPage);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the Printer Page Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Page Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect	GetPrintPageSize();

	// Update Printer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Printer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePrinter();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the name of the default printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Printer2, Returns the specified value.
	//		Returns a CString type value.
	CString GetDefaultPrinter2();

	//-----------------------------------------------------------------------
	// Summary:
	// Change to new default printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Printer2, Sets a specify value to current class CFODataModel
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpPrinterName---Printer Name, Specifies A integer value.
	BOOL SetDefaultPrinter2(LPTSTR lpPrinterName);

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer paper size.
	// nMode must be one of the following value that defined at the header of FODataModel.cpp
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Page Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMode---nMode, Specifies a short nMode object(Value).
	virtual BOOL SetPrintPageSize(short nMode);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the name of the printer driver.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Driver Name, Returns the specified value.
	//		Returns A LPTSTR value (Object).
	LPTSTR GetPrintDriverName();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the name of the printer device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Device Name, Returns the specified value.
	//		Returns A LPTSTR value (Object).
	LPTSTR GetPrintDeviceName();

	// Obtain the paper size from paper name.
	// szPaperName -- paper name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Size, Returns the specified value.
	//		Returns A short value (Object).  
	// Parameters:
	//		szPaperName---Paper Name, Specifies a FO_PAPERNAME szPaperName object(Value).
	short GetPaperSize(FO_PAPERNAME szPaperName);

	// Change paper size with name
	// szPaperName -- for example A4, A1
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Paper Size, Sets a specify value to current class CFODataModel
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		szPaperName---Paper Name, Specifies a FO_PAPERNAME szPaperName object(Value).
	BOOL SetPaperSize(FO_PAPERNAME szPaperName);

	// Obtain printer information.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Information, Returns the specified value.
	//		Returns a pointer to the object PRINTER_INFO_2 ,or NULL if the call failed
	PRINTER_INFO_2 *GetPrinterInfo();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the name of the output.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Output Name, Returns the specified value.
	//		Returns A LPTSTR value (Object).
	LPTSTR GetPrintOutputName();


	//-----------------------------------------------------------------------
	// Summary:
	// Obtain printer's orientation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Orientation, Returns the specified value.
	//		Returns A short value (Object).
	short GetPrintOrientation() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer orientation.
	// mode must be one of the following value:
	// DMORIENT_LANDSCAPE or DMORIENT_PORTRAIT
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Orientation, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		mode---Specifies a short mode object(Value).
	virtual BOOL SetPrintOrientation(short mode);

	//-----------------------------------------------------------------------
	// Summary:
	// Get print paper length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Paper Length, Returns the specified value.
	//		Returns A short value (Object).
	short GetPrintPaperLength() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get print paper name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetPaperName() const;


	//-----------------------------------------------------------------------
	// Summary:
	// Obtain printer's color mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Color Mode, Returns the specified value.
	//		Returns a int type value.
	PrinterColorMode GetPrinterColorMode();

	// Change printer params.
	// bUseColor -- use gray scale or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printer Grayscale Mode, Sets a specify value to current class CFODataModel
	// Parameters:
	//		bUseGray---Use Gray, Specifies A Boolean value.
	void SetPrinterGrayscaleMode(BOOL bUseGray);

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer params.
	// mode -- use color or not, it is DMCOLOR_COLOR or DMCOLOR_MONOCHROME
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printer Color Mode, Sets a specify value to current class CFODataModel
	// Parameters:
	//		mode---Specifies a short mode object(Value).
	void SetPrinterColorMode(short mode);


	//-----------------------------------------------------------------------
	// Summary:
	// Change printer params.
	// copies -- number of copies
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printer copies, Sets a specify value to current class CFODataModel
	// Parameters:
	//		copies---Specifies a short mode object(Value).
	void SetPrinterCopies(short copies);

	//-----------------------------------------------------------------------
	// Summary:
	// Add custom paper
	// strPaperName -- new paper name.
	// szPaper = size of paper
	// rcMargin -- margin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Custom Paper, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strPaperName---Paper Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		szPaper---szPaper, Specifies a SIZE szPaper object(Value).  
	//		rcMargin---rcMargin, Specifies a RECT rcMargin object(Value).
	BOOL  AddCustomPaper(LPCTSTR strPaperName, SIZE szPaper, RECT rcMargin);

	// Obtain all the forms of a printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Paper Forms, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_array---Specifies A CString type value.
	BOOL GetAllPaperForms(CStringArray &m_array);

	// Obtain all the forms of a printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Paper Forms2, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<FO_PaperInfo---Array< F O_ Paper Information, Specifies A CArray array.  
	//		&m_array---Specifies a FO_PaperInfo> &m_array object(Value).
	BOOL GetAllPaperForms2(CArray<FO_PaperInfo, FO_PaperInfo> &m_array);

	//-----------------------------------------------------------------------
	// Summary:
	// Delete custom paper
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Custom Paper, Deletes the given object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strPaperName---Paper Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL   DeleteCustomPaper(LPCTSTR strPaperName);

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer's paper length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Paper Length, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nPaperLength---Paper Length, Specifies a const short nPaperLength object(Value).
	virtual void SetPrintPaperLength(const short nPaperLength);

	//-----------------------------------------------------------------------
	// Summary:
	// Get print paper width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Paper Width, Returns the specified value.
	//		Returns A short value (Object).
	short GetPrintPaperWidth() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer's paper width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Paper Width, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nPaperWidth---Paper Width, Specifies a const short nPaperWidth object(Value).
	virtual void SetPrintPaperWidth(const short nPaperWidth);

	//-----------------------------------------------------------------------
	// Summary:
	// Add printer user paper size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add User Printer Paper Size, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPaperWidth---Paper Width, Specifies a const short &nPaperWidth object(Value).  
	//		&nPaperHeight---Paper Height, Specifies a const short &nPaperHeight object(Value).
	virtual void AddUserPrinterPaperSize(const short &nPaperWidth, const short &nPaperHeight);


	//-----------------------------------------------------------------------
	// Summary:
	// Get print paper width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Number Copies, Returns the specified value.
	//		Returns A short value (Object).
	short GetPrintNumCopies() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer's number of copies.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Number Copies, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nNumCopies---Number Copies, Specifies a const short nNumCopies object(Value).
	virtual void SetPrintNumCopies(const short nNumCopies);

	//-----------------------------------------------------------------------
	// Summary:
	// Get printer duplex.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Duplex Mode, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetDuplexMode() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change printer's duplex mode.
	// nMode -- it should be DMDUP_SIMPLEX DMUP_HORIZONTAL DMUP_VERTICAL
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Duplex Mode, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nMode---nMode, Specifies a const short nMode object(Value).
	virtual void SetPrintDuplexMode(const short nMode);

	//-----------------------------------------------------------------------
	// Summary:
	// Does current printer valid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Printer O K, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsPrinterOK() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the printer page's margin.
	// rcMargin -- Margin rectangle of the paper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printer Page Margin, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargin---rcMargin, Specifies A CRect type value.
	virtual void SetPrinterPageMargin(const CRect& rcMargin);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the Print Dialog
	// printDlg -- PRINTDLG object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Dialog, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		printDlg---printDlg, Specifies A integer value.
	virtual void GetPrintDlg(PRINTDLG& printDlg);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the Page Setup Dialog
	// pageSetupDlg -- PAGESETUPDLG object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Setup Dialog, Returns the specified value.
	// Parameters:
	//		pageSetupDlg---Setup Dialog, Specifies a PAGESETUPDLG& pageSetupDlg object(Value).
	void GetPageSetupDlg(PAGESETUPDLG& pageSetupDlg);

	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Setup Dialog
	// pageSetupDlg -- PAGESETUPDLG object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Setup Dialog, Sets a specify value to current class CFODataModel
	// Parameters:
	//		pageSetupDlg---Setup Dialog, Specifies a const PAGESETUPDLG& pageSetupDlg object(Value).
	void SetPageSetupDlg(const PAGESETUPDLG& pageSetupDlg);

	//-----------------------------------------------------------------------
	// Summary:
	// ReCalulate Print Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Cal Print Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReCalPrintPosition();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the printer information.
	// pResult-- result printer informations.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Informations, Returns the specified value.
	// Parameters:
	//		pResult---pResult, A pointer to the CPrintInfo or NULL if the call failed.
	void GetPrintInformations(CPrintInfo* pResult);

	//-----------------------------------------------------------------------
	// Summary:
	// Create printer dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Printer D C, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HDC value (Object).
	HDC CreatePrinterDC();

	//-----------------------------------------------------------------------
	// Summary:
	// Get unit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unit, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetUnit() const;

	//-----------------------------------------------------------------------
	// Summary:
	/// Convert value with specify map mode.
	// nMode -- map mode,it must be one of the following values:
	// MM_TWIPS
	// MM_HIMETRIC
	// MM_LOMETRIC
	// MM_HIENGLISH
	// MM_LOENGLISH
	// MM_TEXT
	// MM_ISOTROPIC
	// MM_ANISOTROPIC
	// cx -- convert to x value
	// cy -- convert to y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Convert Value, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nMode---&nMode, Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	BOOL FOConvertValue(const int &nMode, int& cx, int& cy);

public:

	// Do unlog shape in view.
	void DoUnLogShapeInView(CFODrawShape *pShape);

	// Do log shape in view.
	void DoLogShapeInView(CFODrawShape *pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Show or hide ports on the screen.
	// bShow -- show or hide.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Port, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void			ShowPort(const BOOL &bShow)			{ m_bShowPort = bShow; }

	//-----------------------------------------------------------------------
	// Summary:
	// bShow -- show or hide the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Port Show, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsPortShow() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the size of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize	GetCanvasSize() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the canvas,it is defined for form mode application.
	// size -- new size of the canvas,it is the pixel of the value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&size---Specifies A CSize type value.
	virtual void	SetCanvasSize(const CSize &size);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the Rectangle of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect	GetPagePosition() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the page width and page height of canvas.
	// dWidth -- width of canvas.
	// dHeight -- height of canvas
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Position New, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dWidth---&dWidth, Specifies a double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a double &dHeight object(Value).
	virtual void GetPagePositionNew(double &dWidth, double &dHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Change page origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Origin, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetPageOrigin(int x,int y);

	//-----------------------------------------------------------------------
	// Summary:
	// Change page origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual void SetPageSize(int cx, int cy);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the position of the canvas,if your canvas be 400 X 600,you need call the following code:
	// CRect rc = CRect(0,0,400,600);
	// SetPagePosition(rc);
	//
	// rc -- new position of the canvas,its top left must be "0,0"
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Position New, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void	SetPagePositionNew(const CRect &rc);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the position of the canvas,if your canvas be 400 X 600,you need call the following code:
	// CRect rc = CRect(0,0,400,600);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Position, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a const double &dHeight object(Value).
	// SetPagePosition(rc);
	//
	// rc -- new position of the canvas,its top left must be "0,0"
	virtual void	SetPagePosition(const double &dWidth, const double &dHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Change the size of the canvas's page
	// fHorzMMValue -- MM value of the width.
	// fVertMMValue -- MM value of the height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&fHorzMMValue---Horizontal M M Value, Specifies A float value.  
	//		&fVertMMValue---Vertical M M Value, Specifies A float value.
	virtual void	SetPageSize(const float &fHorzMMValue,const float &fVertMMValue);

	//-----------------------------------------------------------------------
	// Summary:
	// Get page width with pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Width With Print Pages, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int		GetPageWidthWithPrintPages();

	//-----------------------------------------------------------------------
	// Summary:
	// Change the canvas width with whole number printer paper width,by sometime,we want the size of the canvas just to be whole number of printer
	// paper size,this method is defined for this case,you can define a canvas that has width of whole number the
	// printer paper width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Width With Print Pages, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nNumber---&nNumber, Specifies A integer value.
	virtual void	SetPageWidthWithPrintPages(const int &nNumber);

	//-----------------------------------------------------------------------
	// Summary:
	// Get page height with pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Height With Print Pages, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int		GetPageHeightWithPrintPages();

	//-----------------------------------------------------------------------
	// Summary:
	// Change the canvas height with whole number printer paper height,by sometime,we want the size of the canvas just to be whole number of printer
	// paper size,this method is defined for this case,you can define a canvas that has height of whole number the printer paper height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Height With Print Pages, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nNumber---&nNumber, Specifies A integer value.
	virtual void	SetPageHeightWithPrintPages(const int &nNumber);

	//-----------------------------------------------------------------------
	// Summary:
	// Change canvas's size with whole number printer paper size,by sometime,we want the size of the canvas just to be whole number of printer
	// paper size,this method is defined for this case,you can define a canvas that has width of whole number the
	// printer paper width and has height of whole number the printer paper height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Position With Pages, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nHorzPages---Horizontal Pages, Specifies A integer value.  
	//		&nVertPages---Vertical Pages, Specifies A integer value.
	virtual void	ChangePositionWithPages(
		// Specifies the horz number of pages
		const int &nHorzPages,
		// Specifies the vert number of pages.
		const int &nVertPages
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Change map mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Map Mode, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMap---&nMap, Specifies A integer value.
	virtual void	SetMapMode(const int &nMap) { m_nMapMode = nMap; }

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the map mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Map Mode, Returns the specified value.
	//		Returns a int type value.
	int GetMapMode() const { return m_nMapMode; }

	//-----------------------------------------------------------------------
	// Summary:
	// Prepare container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare List, .

	void PrepareList();

	//-----------------------------------------------------------------------
	// Summary:
	// Prepare container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare List Extend, .

	void PrepareListExtend();

	//-----------------------------------------------------------------------
	// Summary:
	// End list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End List, .

	void EndList();

	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle for limit shape moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drag Limit Rectangle, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	const FOPRect&   GetDragLimitRect()              { return m_rcLimit; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the rectangle for limiting shape moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drag Limit Rectangle, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&rcLimit---&rcLimit, Specifies a const FOPRect &rcLimit object(Value).
	void SetDragLimitRect(const FOPRect &rcLimit)    { m_rcLimit = rcLimit; }

	//-----------------------------------------------------------------------
	// Summary:
	/// Recalculate font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Recalculate page size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Page, Do a event. 

	void DoUpdatePage();

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do update in view shape list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Shape Inview, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoUpdateShapeInview();

public:
	/*************************************************************************
	|*
	|* Editing the background
	|*
	\************************************************************************/
	// Below is defined for editing the background shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare before editing,it need to backup the shapes on the canvas and the actions of the datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enter Editing Back, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EnterEditingBack();

	//-----------------------------------------------------------------------
	// Summary:
	// Do when end editing the back shape,it need restore the actions and the shapes of the datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Editing Back, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bUpdate---&bUpdate, Specifies A Boolean value.
	virtual void EndEditingBack(const BOOL &bUpdate = TRUE);
	
public:
	/*************************************************************************
	|*
	|* Layers control codes.
	|*
	\************************************************************************/
	// Below is defined for layers.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert a new layer in the data model.
	// pLayer -- pointer of the layer.
	// nPos -- insert position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Layer, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pLayer---pLayer, A pointer to the CFOPLayer or NULL if the call failed.  
	//		nPos---nPos, Specifies a USHORT nPos = 0xFFFF object(Value).
	virtual void InsertLayer(CFOPLayer* pLayer, USHORT nPos = 0xFFFF);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove the layer at a specify position.
	// nPos -- position of the layer to be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Layer, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		nPos---nPos, Specifies a USHORT nPos object(Value).
	virtual CFOPLayer* RemoveLayer(USHORT nPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Clear all the layers of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Layer, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearLayer();

	//-----------------------------------------------------------------------
	// Summary:
	// Create a new layer.
	// rName -- name of the layer
	// nPos -- pos of the new layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Layer, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		rName---rName, Specifies A CString type value.  
	//		nPos---nPos, Specifies a USHORT nPos = 0xFFFF object(Value).
	virtual CFOPLayer* NewLayer(const CString& rName, USHORT nPos = 0xFFFF);

	//-----------------------------------------------------------------------
	// Summary:
	// Delete a specify layer.
	// pLayer -- pointer of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Layer, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pLayer---pLayer, A pointer to the CFOPLayer or NULL if the call failed.
	virtual void DeleteLayer(CFOPLayer* pLayer);

	//-----------------------------------------------------------------------
	// Summary:
	// Move layer.
	// pLayer -- pointer of the layer to be moved.
	// nNewPos -- new position of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Layer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pLayer---pLayer, A pointer to the CFOPLayer or NULL if the call failed.  
	//		nNewPos---New Position, Specifies a USHORT nNewPos = 0xFFFF object(Value).
	virtual void MoveLayer(CFOPLayer* pLayer, USHORT nNewPos = 0xFFFF);

	//-----------------------------------------------------------------------
	// Summary:
	// Move layer
	// nPos -- layer position that will to be moved.
	// nNewPos -- moved to new position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Layer, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		nPos---nPos, Specifies a USHORT nPos object(Value).  
	//		nNewPos---New Position, Specifies a USHORT nNewPos object(Value).
	virtual CFOPLayer* MoveLayer(USHORT nPos, USHORT nNewPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the counts of the layers.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer Count, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetLayerCount() const
	{
		return USHORT(m_aryLayer.Count());
	}

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the layer at a specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer, Returns the specified value.
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		i---Specifies a USHORT i object(Value).
	CFOPLayer* GetLayer(USHORT i)
	{
		return (CFOPLayer *) (m_aryLayer.GetObject(i));
	}

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the layer at a specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer, Returns the specified value.
	//		Returns a pointer to the object const CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		i---Specifies a USHORT i object(Value).
	const CFOPLayer* GetLayer(USHORT i) const
	{
		return (CFOPLayer *) (m_aryLayer.GetObject(i));
	}

	//-----------------------------------------------------------------------
	// Summary:
	// Get position of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer Position, Returns the specified value.
	//		Returns A USHORT value (Object).  
	// Parameters:
	//		pLayer---pLayer, A pointer to the CFOPLayer or NULL if the call failed.
	USHORT GetLayerPos(CFOPLayer* pLayer) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Find the layer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer, Returns the specified value.
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	CFOPLayer* GetLayer(const CString& rName)
	{
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer, Returns the specified value.
	//		Returns a pointer to the object const CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
		return (CFOPLayer *) (((const CFODataModel *)this)->GetLayer(rName));
	}

	//-----------------------------------------------------------------------
	// Summary:
	// Find the layer.
	const CFOPLayer* GetLayer(const CString& rName) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Find layer with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Layer, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPLayer* FindLayer(const UINT& nID);

	//-----------------------------------------------------------------------
	// Summary:
	// Rename the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename Layer, Call this function to Changes the name of the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLayer---*pLayer, A pointer to the CFOPLayer  or NULL if the call failed.  
	//		&strNewName---New Name, Specifies A CString type value.
	virtual void RenameLayer(CFOPLayer *pLayer,const CString &strNewName);

	//-----------------------------------------------------------------------
	// Summary:
	// Find the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Layer I D, Returns the specified value.
	//		Returns A FOPLayerID value (Object).  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	FOPLayerID GetLayerID(const CString& rName) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Calculate the unique layer ID value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Layer I D, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPLayerID value (Object).
	virtual FOPLayerID GetUniqueLayerID() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Calculate the unique layer name value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Layer Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetUniqueLayerName() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get active layer.
	// Find the layer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Layer, Returns the specified value.
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed
	CFOPLayer* GetActiveLayer()
	{
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Layer, Returns the specified value.
	//		Returns a pointer to the object const CFOPLayer,or NULL if the call failed
		return (CFOPLayer *) (((const CFODataModel *)this)->GetActiveLayer());
	}

	// Find the layer.
	const CFOPLayer* GetActiveLayer() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get active layer ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Layer I D, Returns the specified value.
	//		Returns A FOPLayerID value (Object).
	FOPLayerID GetActiveLayerID();

	//-----------------------------------------------------------------------
	// Summary:
	// Change active layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Active Layer, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	virtual BOOL ActiveLayer(const CString &strName);

	//-----------------------------------------------------------------------
	// Summary:
	// Find all the shapes with a specify layer id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shapes With Layer I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShapesList---Shapes List, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&nID---I D, Specifies a const FOPLayerID &nID object(Value).
	virtual void FindShapesWithLayerID(CFODrawShapeList *pShapesList,const FOPLayerID &nID);

	// Get validate layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Valid Layer, Returns the specified value.
	//		Returns a pointer to the object CFOPLayer ,or NULL if the call failed
	CFOPLayer *GetValidLayer();

	//-----------------------------------------------------------------------
	// Summary:
	// Get copying of the all the layers.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Copying Layers, Returns the specified value.
	// Parameters:
	//		*lLayer---*lLayer, A pointer to the FOPContainer  or NULL if the call failed.
	void GetCopyingLayers(FOPContainer *lLayer);

	//-----------------------------------------------------------------------
	// Summary:
	// Set all layers to be printable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set All Layers Printable, Sets a specify value to current class CFODataModel
	// Parameters:
	//		bPrn---bPrn, Specifies A Boolean value.
	void SetAllLayersPrintable(BOOL bPrn = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Is layer printable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Layer Printable, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	BOOL IsLayerPrintable(const CString& rName);

	//-----------------------------------------------------------------------
	// Summary:
	// Change layer to be printed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer Printable, Sets a specify value to current class CFODataModel
	// Parameters:
	//		rName---rName, Specifies A CString type value.  
	//		bPrn---bPrn, Specifies A Boolean value.
	void SetLayerPrintable(const CString& rName, BOOL bPrn = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Change layer to be locked
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer Locked, Sets a specify value to current class CFODataModel
	// Parameters:
	//		rName---rName, Specifies A CString type value.  
	//		bLock---bLock, Specifies A Boolean value.
	void SetLayerLocked(const CString& rName, BOOL bLock = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Is layer locked
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Layer Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	BOOL IsLayerLocked(const CString& rName);

	//-----------------------------------------------------------------------
	// Summary:
	// Set all layers to be locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set All Layers Locked, Sets a specify value to current class CFODataModel
	// Parameters:
	//		bLock---bLock, Specifies A Boolean value.
	void SetAllLayersLocked(BOOL bLock = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Change layer to be visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer Visible, Sets a specify value to current class CFODataModel
	// Parameters:
	//		rName---rName, Specifies A CString type value.  
	//		bShow---bShow, Specifies A Boolean value.
	void SetLayerVisible(const CString& rName, BOOL bShow = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Is layer visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Layer Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	BOOL IsLayerVisible(const CString& rName);

	//-----------------------------------------------------------------------
	// Summary:
	// Change all layers to be visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set All Layers Visible, Sets a specify value to current class CFODataModel
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void SetAllLayersVisible(BOOL bShow = TRUE);

public:
	/*************************************************************************
	|*
	|* Help lines.
	|*
	\************************************************************************/
	// Below is defined for help lines.
	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the help line objects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Help Lines, Returns the specified value.
	//		Returns A const CFOPHelpLineSet& value (Object).
	const CFOPHelpLineSet& GetHelpLines() const   { return aHelpLines; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get count of help lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count Help Lines, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int		GetCountHelpLines() const { return (int)aHelpLines.GetCount(); }

	//-----------------------------------------------------------------------
	// Summary:
	// Add new help line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Help Line, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLine---*pLine, A pointer to the CFOPHelpLine  or NULL if the call failed.
	virtual void	AddNewHelpLine(CFOPHelpLine *pLine);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove help line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Help Line, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLine---*pLine, A pointer to the CFOPHelpLine  or NULL if the call failed.
	virtual void	RemoveHelpLine(CFOPHelpLine *pLine);

	// Draw all help line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw All Help Lines, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&szHorz---&szHorz, Specifies A CSize type value.  
	//		&szVert---&szVert, Specifies A CSize type value.
	virtual void	OnDrawAllHelpLines(CDC *pDC,const CSize &szHorz,const CSize &szVert);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit test all help lines.
	// rPnt -- hit test point.
	// nTolLog -- total log offset
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Help Line, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHelpLine ,or NULL if the call failed  
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.  
	//		nTolLog---Tol Logical, Specifies A integer value.
	virtual CFOPHelpLine *HitTestHelpLine(const CPoint& rPnt, int nTolLog);

	//-----------------------------------------------------------------------
	// Summary:
	// Is help line visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Help Line Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsHlpLineVisible() const { return bHlplVisible; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set help line visible.
	// bV -- visible or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Help Line Visible, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bV---&bV, Specifies A Boolean value.
	void			SetHlpLineVisible(const BOOL &bV) { bHlplVisible = bV; }

	//-----------------------------------------------------------------------
	// Summary:
	// Snap position,when the shape is snap to help lines,this method will be called,override this method
	// to handle your own control.
	// rPnt -- point after the snap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To Help Lines, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.
	virtual BOOL	SnapToHelpLines(CPoint& rPnt) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Snap position,when the shape is snap to page border,this method will be called,override this method
	// to handle your own control.
	// rPnt -- point after the snap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap Page Border, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.
	virtual BOOL	SnapPageBorder(CPoint& rPnt) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Clear all the help lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Help Lines, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearAllHelpLines();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsSelected();

	//-----------------------------------------------------------------------
	// Summary:
	// Select Form
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Form, Call this function to select the given item.
	// Parameters:
	//		&bSe---&bSe, Specifies A Boolean value.
	void			SelectForm(const BOOL &bSe);

	//-----------------------------------------------------------------------
	// Summary:
	// Get all the children shape's count + the count of all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Shapes Count In Depth, Returns the specified value.
	//		Returns a int type value.
	int	GetAllShapesCountInDepth();

public:

	/*************************************************************************
	|*
	|* Basic properties,these properties only validate with Form Edit Mode.
	|* You can call SetFormMode(..),that defined within class CFODataModel.
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Define for form mode only.
	// deciding if being 3d border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has3 D Border, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		Has3DBorder() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change to 3d border mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set3 D Border, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		Set3DBorder(const BOOL &bHas);


	//-----------------------------------------------------------------------
	// Summary:
	// deciding if there being close button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Close Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasCloseButton() const;
 
	//-----------------------------------------------------------------------
	// Summary:
	// Change to close button mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Close Button, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetCloseButton(const BOOL &bHas);


    //-----------------------------------------------------------------------
	// Summary:
	// deciding if there being min button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Minimize Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasMinButton() const;
 
	//-----------------------------------------------------------------------
	// Summary:
	// Change to min button mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimize Button, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetMinButton(const BOOL &bHas);


	//-----------------------------------------------------------------------
	// Summary:
	// deciding if there being max button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Maximize Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasMaxButton() const;
 
	//-----------------------------------------------------------------------
	// Summary:
	// Change to max button mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Button, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetMaxButton(const BOOL &bHas);


	//-----------------------------------------------------------------------
	// Summary:
	// deciding if there being help button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Help Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasHelpButton() const;

	// Change to show help button mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Help Button, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetHelpButton(const BOOL &bHas);


	//-----------------------------------------------------------------------
	// Summary:
	// deciding if there being icon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Icon, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasIcon() const;

	//-----------------------------------------------------------------------
	// Summary:
	// show diloag top left icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Icon, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		ShowIcon(const BOOL &bHas);


	//-----------------------------------------------------------------------
	// Summary:
	// deciding if there being title bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Title Bar, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasTitleBar() const;

	//-----------------------------------------------------------------------
	// Summary:
	// show title bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Title Bar, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		ShowTitleBar(const BOOL &bHas);


    //-----------------------------------------------------------------------
	// Summary:
	// deciding if there being margin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Margin, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		HasMargin() const;

	//-----------------------------------------------------------------------
	// Summary:
	// show margin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Margin, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		ShowMargin(const BOOL &bHas);

public:
	/*************************************************************************
	|*
	|* Grid setting properties.
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Grid property.
	// get grid of x
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid X2, Returns the specified value.
	//		Returns A double value (Object).
	double			GetGridX2() const;

	//-----------------------------------------------------------------------
	// Summary:
	// get grid of x
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid X, Returns the specified value.
	//		Returns a int type value.
	int			GetGridX() const;

	//-----------------------------------------------------------------------
	// Summary:
	// change grid of x
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid X, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&x---Specifies a const double &x object(Value).
	void		SetGridX(const double &x);

	//-----------------------------------------------------------------------
	// Summary:
	// get grid of y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Y2, Returns the specified value.
	//		Returns A double value (Object).
	double			GetGridY2() const;


	//-----------------------------------------------------------------------
	// Summary:
	// get grid of y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Y, Returns the specified value.
	//		Returns a int type value.
	int			GetGridY() const;

	//-----------------------------------------------------------------------
	// Summary:
	// change grid of y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Y, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&y---Specifies a const double &y object(Value).
	void		SetGridY(const double &y);

	//-----------------------------------------------------------------------
	// Summary:
	// get grid color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetGridColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// change grid color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetGridColor(const COLORREF &cr);

	//-----------------------------------------------------------------------
	// Summary:
	// Is grid printable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Grid Printable, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsGridPrintable() const { return m_bGridPrintable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set grid printable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Printable, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		SetGridPrintable(const BOOL &bEnable) { m_bGridPrintable = bEnable; }

public:
	
	/*************************************************************************
	|*
	|* printing properties
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Return Print X Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print X Scale, Returns the specified value.
	//		Returns a float value.
	float GetPrintXScale() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Print X Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print X Scale, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetPrintXScale( const float &fValue );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Return Print Y Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Y Scale, Returns the specified value.
	//		Returns a float value.
	float GetPrintYScale() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Print Y Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Y Scale, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetPrintYScale( const float &fValue );

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Enable insert port within ports shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Insert Port Within, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableInsertPortWithin() const { return m_bEnableInsertPort; }

	//-----------------------------------------------------------------------
	// Summary:
	// Enable insert port within ports shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Insert Port Within, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableInsertPortWithin(const BOOL &bEnable) { m_bEnableInsertPort = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// get grid line type,it will return one of the following value:
	// enum FO_GRIDLINE_TYPE
	// {
	// 	GRID_CROSSLINE = 0,			// Cross grid line
	// 	GRID_DOT,					// Dot grid.
	// 	GRID_RECTANGLE				// Rectangle grid line.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Line Type, Returns the specified value.
	//		Returns A FO_GRIDLINE_TYPE value (Object).
	FO_GRIDLINE_TYPE GetGridLineType() const;

	//-----------------------------------------------------------------------
	// Summary:
	// set grid line type.
	// nType -- It must be one of the following value:
	// enum FO_GRIDLINE_TYPE
	// {
	// 	GRID_CROSSLINE = 0,			// Cross grid line
	// 	GRID_DOT,					// Dot grid.
	// 	GRID_RECTANGLE				// Rectangle grid line.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Type, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nType---&nType, Specifies a const FO_GRIDLINE_TYPE &nType object(Value).
	void		SetGridLineType(const FO_GRIDLINE_TYPE &nType);

	//-----------------------------------------------------------------------
	// Summary:
	// deciding if being grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Grid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsGrid() const;

	//-----------------------------------------------------------------------
	// Summary:
	// show grid or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Grid, Call this function to show the specify object.
	// Parameters:
	//		&bS---&bS, Specifies A Boolean value.
	void		ShowGrid(BOOL const &bS);

	// Enable rebuild view shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Rebuild, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableRebuild(const BOOL &bEnable = TRUE);

	// Enable update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Update, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableUpdate(const BOOL &bEnable = TRUE);

	// Reset all.
	void DoClearViewAll();

public:

	/*************************************************************************
	|*
	|* Snap features of the data model.
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// get snap to grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Snap To Grid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsSnapToGrid() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change to snap to grid mode or not,when it is on,when you moving,resizing,or creating new shape,it
	// will automatic snap to the grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap To Grid, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bSnap---&bSnap, Specifies A Boolean value.
	void		SetSnapToGrid(const BOOL &bSnap);

	//-----------------------------------------------------------------------
	// Summary:
	// Return snap to dynamic grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap Dyn Grid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapDynGrid() const { return m_bSnapToDynGrid; }

	//-----------------------------------------------------------------------
	// Summary:
	// Enable snap to dyn grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap Dyn Grid, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapDynGrid(const BOOL &bEnable) { m_bSnapToDynGrid = bEnable; }

	///-----------------------------------------------------------------------
	// Summary:
	// Return snap to shape aid line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap Aid Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapAidLine() const { return m_bSnapAidLine; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change snap to aid line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap Aid Line, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapAidLine(const BOOL &bEnable) { m_bSnapAidLine = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Return Snap To Control Handle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To  Handle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapToControlHandle() const				{ return m_bSnapToControlHandle;}

	//-----------------------------------------------------------------------
	// Summary:
	// Change Snap To Control Handle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To  Handle, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapToControlHandle( const BOOL &bEnable ) {m_bSnapToControlHandle = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Return Snap To Spot value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Spot, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapToSpot() const						{ return m_bSnapToSpot;}

	//-----------------------------------------------------------------------
	// Summary:
	// Change Snap To Spot value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Spot, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapToSpot( const BOOL &bEnable )			{m_bSnapToSpot = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Return Snap To Intersect Point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Intersect Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapToIntersectPoint() const			{ return m_bSnapToIntersectPoint;}

	//-----------------------------------------------------------------------
	// Summary:
	// Change Snap To Intersect Point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Intersect Point, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapToIntersectPoint( const BOOL &bEnable ) {m_bSnapToIntersectPoint = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Return Snap To Help Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Help Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapToHelpLine() const					{ return m_bSnapToHelpLine;}

	//-----------------------------------------------------------------------
	// Summary:
	// Change Snap To Help Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Help Line, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapToHelpLine( const BOOL &bEnable )		{m_bSnapToHelpLine = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Return snap to page margin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Page Border, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableSnapToPageBorder() const				{ return m_bSnapToPageBorder; }

	//-----------------------------------------------------------------------
	// Summary:
	// Enable to snap to page margin or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Page Boder, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableSnapToPageBoder(const BOOL &bEnable)		{ m_bSnapToPageBorder = bEnable; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is allow hole link,mostly,when we move mouse over the connection ports,we want to 
	// click the mouse to start creating links from this port right now.This method is defined for this kind
	// of case,if it allows hole link,it will return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Hole Link, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsAllowHoleLink() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change to allow hole link mode,mostly,when we move mouse over the connection ports,we want to 
	// click the mouse to start creating links from this port right now.This method is defined for this kind
	// of case,you can change the value of bAllow to switch to allow link or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Hole Link, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bAllow---&bAllow, Specifies A Boolean value.
	void		SetAllowHoleLink(const BOOL &bAllow);

	// Is enable drag or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Disable Drag, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsDisableDrag() const { return m_bDisableDrag; };

	// Enable drag or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Disable Drag, .
	// Parameters:
	//		&bDisable---&bDisable, Specifies A Boolean value.
	void DisableDrag(const BOOL &bDisable) { m_bDisableDrag = bDisable; }

	// Add temp links.
	void DoAddTempLink(CFODrawShapeList *pList);

	// Obtain hit tree.
	virtual CFOPHitHelper *GetHitTree();

	// Resize with fixed page width.
	BOOL DoResizeForm();

	// Resize with fixed width.
	BOOL DoResizeNormal();

	// Rebuild tree.
	virtual void RebuildStore(const FOPRect & rcNew);

	// Obtain all shapes that hitted by this point.
	// pList -- list of shapes.
	// ptCheck -- point for checking.
	// nExt -- expand size.
	int ShapesAtPt(CFODrawShapeSet* pList, const CPoint &ptCheck, const int &nExt);
	
	// Obtain shapes in a specify rectangle.
	// pList -- list of shapes.
	// rcCheck -- rectangle for checking.
	int ShapesInRect(CFODrawShapeSet* pList, const CRect &rcCheck);
	
	// Obtain shapes that intersecting rectangle.
	// pList -- list of shapes.
	// rcCheck -- rectangle for checking.
	int ShapesOutRect(CFODrawShapeSet* pList, const CRect &rcCheck);

public:

	/*************************************************************************
	|*
	|* Change margin of the form,it only works with Form Edit Mode.
	|*
	\************************************************************************/

	// Define for margin of form
	//-----------------------------------------------------------------------
	// Summary:
	// get margin x-start
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin X Start, Returns the specified value.
	//		Returns a int type value.
	int			GetMarginXStart() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change margin start X value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin X Start, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&x---Specifies A integer value.
	void		SetMarginXStart(const int &x);

	//-----------------------------------------------------------------------
	// Summary:
	// get margin y-start
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin Y Start, Returns the specified value.
	//		Returns a int type value.
	int			GetMarginYStart() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change form start Y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin Y Start, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&y---Specifies A integer value.
	void		SetMarginYStart(const int &y);

	//-----------------------------------------------------------------------
	// Summary:
	// get margin x-end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin X End, Returns the specified value.
	//		Returns a int type value.
	int			GetMarginXEnd() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change margin end x value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin X End, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&x---Specifies A integer value.
	void		SetMarginXEnd(const int &x);

	//-----------------------------------------------------------------------
	// Summary:
	// get margin y-end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin Y End, Returns the specified value.
	//		Returns a int type value.
	int			GetMarginYEnd() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change margin end y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin Y End, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&y---Specifies A integer value.
	void		SetMarginYEnd(const int &y);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name,returns the name of the data model,the object name is not used for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectName()	const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name,change the name of the data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Name, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectName(
		// Specify the name of data model.
		const CString &str
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Define for text.
	// Get Object Caption,this is also the label of some data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption,you can also call this method to change the label of datamodel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(
		// Specify the new caption.
		const CString &str
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Enable unique caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Unique Caption, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableUniqueCaption(const BOOL &bEnable) { m_bEnableUniqueCaption = bEnable; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is enable unique name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Unique Name, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableUniqueName() const { return m_bEnableUniqueName; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is enable unique caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Unque Caption, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableUnqueCaption() const { return m_bEnableUniqueCaption; }

	//-----------------------------------------------------------------------
	// Summary:
	// Show with unique name and caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Unique Name, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bUniqueName---Unique Name, Specifies A Boolean value.
	void		EnableUniqueName(const BOOL &bUniqueName);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Type,this is not used by the system.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetType()	const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the type of the data model,this is not used by the system.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetType(const UINT &nT);

	//-----------------------------------------------------------------------
	// Summary:
	// deciding if being design mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Design Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsDesignMode()	const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change to design mode,with design mode you can modify the shapes on the canvas,such as Moving,Resizing... etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Design Mode, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bDesign---&bDesign, Specifies A Boolean value.
	void		SetDesignMode(const BOOL &bDesign);

	//-----------------------------------------------------------------------
	// Summary:
	// deciding if being locked,not used by the system,this is a temp property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsLock() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change to lock mode,not used by the system,this is a temp property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Component, .
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void		LockComp(const BOOL &bL);

public:

	//-----------------------------------------------------------------------
	// Summary:
	/// Form back color.
	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	//-----------------------------------------------------------------------
	// Summary:
	// get the outside of the page back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPageBkColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the outside of the canvas back color.
	// crBkColor -- new page background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Background Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPageBkColor(const COLORREF &crBkColor);

	//-----------------------------------------------------------------------
	// Summary:
	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	//-----------------------------------------------------------------------
	// Summary:
	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the brush pattern Color,if the brush type is 2,canvas use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	// cr -- color of the pattern.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties for background.
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFODataModel
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change font Point Size
	// nPointSize -- font point size.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font Height.
	// nHeight -- new font height.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the Font Color
	// crColor -- new font color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	//-----------------------------------------------------------------------
	// Summary:
	// Get font Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font italic property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	//-----------------------------------------------------------------------
	// Summary:
	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font underline property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	//-----------------------------------------------------------------------
	// Summary:
	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the font strikeout property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

public:
	// Define for print page header and footer setting.
	/*************************************************************************
	|*
	|* Print page header and footer setting
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Get header left text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Left Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetHeaderLeftText() const { return m_strHeaderLeft; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set header left text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Left Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetHeaderLeftText(const CString &strText) { m_strHeaderLeft = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get header Center text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Center Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetHeaderCenterText() const { return m_strHeaderCenter; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set header Center text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Center Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetHeaderCenterText(const CString &strText) { m_strHeaderCenter = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	/// Get header Right text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Right Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetHeaderRightText() const { return m_strHeaderRight; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set header Right text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Right Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetHeaderRightText(const CString &strText) { m_strHeaderRight = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	// Print.
	// Get Footer left text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Footer Left Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFooterLeftText() const { return m_strFooterLeft; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer left text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer Left Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetFooterLeftText(const CString &strText) { m_strFooterLeft = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get Footer Center text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Footer Center Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFooterCenterText() const { return m_strFooterCenter; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer Center text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer Center Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetFooterCenterText(const CString &strText) { m_strFooterCenter = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get Footer Right text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Footer Right Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFooterRightText() const { return m_strFooterRight; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer Right text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Footer Right Text, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void		SetFooterRightText(const CString &strText) { m_strFooterRight = strText; }

	//-----------------------------------------------------------------------
	// Summary:
	// Define for font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetPrintFaceName() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer font face name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Face Name, Sets a specify value to current class CFODataModel
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetPrintFaceName(LPCTSTR lpszFaceName);

	//-----------------------------------------------------------------------
	// Summary:
	// GetPrint point size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPrintPointSize() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change font point size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Point Size, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPrintPointSize(const int &nPointSize, CDC* pDC = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Print font height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Height, Returns the specified value.
	//		Returns a int type value.
	int			GetPrintHeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change printer font height
	// nHeight -- height of the printer.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Height, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPrintHeight(const int &nHeight, CDC* pDC = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the print font color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPrintFontColor() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the print font color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Font Color, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPrintFontColor(const COLORREF &crColor);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the print font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetPrintWeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the print font weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Weight, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetPrintWeight(const int &nWeight);

	//-----------------------------------------------------------------------
	// Summary:
	/// Obtain the print font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPrintItalic() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the print font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Italic, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetPrintItalic(const BOOL &bItalic);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the print font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPrintUnderline() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the print font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Underline, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetPrintUnderline(const BOOL &bUnderline);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the print font strikeout flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPrintStrikeout() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the print font strikeout flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Strikeout, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetPrintStrikeout(const BOOL &bStrikeout);

public:
	//-----------------------------------------------------------------------
	// Summary:
	//Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Print Font, You construct a CFODataModel object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*		CreatePrintFont(CDC* pDC = NULL);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*		GetPrintFont(CDC* pDC = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Print Font Object, .

	void		ReleasePrintFontObject();

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Compute text.
	// Page number,override this method to assign page number for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Page Number, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual	CString ComputePageNumber();

	//-----------------------------------------------------------------------
	// Summary:
	// Page name,override this method to assign page name for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Page Name, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputePageName();

	//-----------------------------------------------------------------------
	// Summary:
	// Total printed pages,override this method to assign total pages for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Total Pages, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeTotalPages();

	//-----------------------------------------------------------------------
	// Summary:
	// Current time,override this method to assign current time for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Current Time, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeCurrentTime();

	//-----------------------------------------------------------------------
	// Summary:
	// Current date (short).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Current Date Short, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeCurrentDateShort();

	//-----------------------------------------------------------------------
	// Summary:
	// Current date (long),override this method to assign current long data for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Current Date Long, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeCurrentDateLong();

	//-----------------------------------------------------------------------
	// Summary:
	// File name,override this method to assign file name for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute File Name, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeFileName();

	//-----------------------------------------------------------------------
	// Summary:
	// File extension,override this method to assign file extension for printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute File Extension, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeFileExtension();

	//-----------------------------------------------------------------------
	// Summary:
	// File name and extension,override this method to assign file name and extension.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute File Name And Extend, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ComputeFileNameAndExt();


	//-----------------------------------------------------------------------
	// Summary:
	// Compute function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Type, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual CString ComputeType(CString str);

public:

	/*************************************************************************
	|*
	|* Printer paper setting
	|*
	\************************************************************************/

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain current printer's paper size.
	// hDevMode -- handle of current printer device.
	// dwUnit -- unit of printer's paper size.
	// ptSize -- size of current printer's paper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Paper Size, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hDevMode---Device Mode, Specifies a HGLOBAL hDevMode object(Value).  
	//		dwUnit---dwUnit, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		ptSize---ptSize, Specifies a POINT& ptSize object(Value).
	BOOL GetPrinterPaperSize(HGLOBAL hDevMode, DWORD& dwUnit, POINT& ptSize);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy printer name,create a copy of current device name.
	// hDevNames -- handle of the device name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dup Printer Names, .
	//		Returns A HGLOBAL value (Object).  
	// Parameters:
	//		hDevNames---Device Names, Specifies a HGLOBAL hDevNames object(Value).
	HGLOBAL DupPrinterNames(HGLOBAL hDevNames);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy printer mode,create a copy of current device mode.
	// hDevMode -- handle of the device mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dup Printer Mode, .
	//		Returns A HGLOBAL value (Object).  
	// Parameters:
	//		hDevMode---Device Mode, Specifies a HGLOBAL hDevMode object(Value).
	HGLOBAL DupPrinterMode(HGLOBAL hDevMode);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the current printer paper's margin size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Margin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPrinterMargin();

	//-----------------------------------------------------------------------
	// Summary:
	// determine printer margins measure, if it is inches based, it returns TRUE, or returns FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Margins Measure Inches, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsMarginsMeasureInches();

	//-----------------------------------------------------------------------
	// Summary:
	// Get min margin of current printer paper.
	// rcMin -- rectangle of the printer margin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Minimize Margin, Returns the specified value.
	// Parameters:
	//		rcMin---rcMin, Specifies A CRect type value.
	void GetPrinterMinMargin(CRect& rcMin) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the printer measure type.
	// dwUnit -- new printer measure type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Printer Unit, .
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwUnit---dwUnit, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD ChangePrinterUnit(const DWORD dwUnit);

	//-----------------------------------------------------------------------
	// Summary:
	// Get print setup dialog.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Set Dialog, Returns the specified value.
	//		Returns A PAGESETUPDLG value (Object).
	PAGESETUPDLG GetPageSetDlg() const		{ return m_printDlg; }

	//-----------------------------------------------------------------------
	// Summary:
	// Reset app printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Application Printer, Called this function to empty a previously initialized CFODataModel object.

	void ResetAppPrinter();

	//-----------------------------------------------------------------------
	// Summary:
	// Offset the full canvas.
	// ptOffset -- offset value of canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Canvas, .
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	void OffsetCanvas(const CPoint &ptOffset);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain current physical margin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current physical Margin, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCurPhyMargin() const { return m_rcPhysicalMargin; }

protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Get the current printer physics's margin size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Physical Margin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		&bWithPageMargin---With Page Margin, Specifies A Boolean value.
	virtual CRect GetPrinterPhysicalMargin(const BOOL &bWithPageMargin = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the current printer physics's margin size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Physical Margin Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPrinterPhysicalMarginExt();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// change to logical axis,convert value from point to log.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// from logical size to point size, convert value from log to point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Obtain the express value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Express Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		&strExpress---&strExpress, Specifies A CString type value.
	virtual CString GetExpressValue(const CString &strExpress) { return strExpress; }

	// Update template load.
	virtual BOOL UpdaterSaveLoad(CFOCompositeShape *pComp, const int &nType);

	// Clear all save and load shapes.
	void ClearAllSaveLoad();

	// Reset save load.
	void ResetSaveLoad();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Is Form Mode or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Form Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsFormMode() const		{ return m_bFormMode; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set Form Mode,by default,the canvas of the system has two status,if it is form editor mode,it will
	// be showing as a dialog editor.With this method,you can switch between them.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Form Mode, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bForm---&bForm, Specifies A Boolean value.
	virtual void	SetFormMode(const BOOL &bForm);


	//-----------------------------------------------------------------------
	// Summary:
	// Is lock with pages,when we create a new canvas,sometime,we want the size of the canvas
	// always be the same size of one or multiple printer pages,it also means that the size of the canvas will
	// be changed with the page size of the printer.This method is defined for this case.If the size of the canvas be 
	// Locked,it will return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock With Pages, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsLockWithPages() const { return m_bLockWithPages; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set lock with pages or not,when we create a new canvas,sometime,we want the size of the canvas
	// always be the same size of one or multiple printer pages,it also means that the size of the canvas will
	// be changed with the page size of the printer.This method is defined for this case.
	//
	// bLock -- lock or not.
	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lock With Pages, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bLock---&bLock, Specifies A Boolean value.
	virtual void	SetLockWithPages(const BOOL &bLock) { m_bLockWithPages = bLock; }


	//-----------------------------------------------------------------------
	// Summary:
	// Is back form resizable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Form Free Size, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsFormFreeSize() const	{ return m_bFormFreeSize; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set Form Mode, with form mode, call this method to allow or not allow the background form be resizing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Form Free Size, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bFree---&bFree, Specifies A Boolean value.
	virtual void	SetFormFreeSize(const BOOL &bFree);

	//-----------------------------------------------------------------------
	// Summary:
	// Is point limit within page, when we move the mouse on the canvas,mostly we want that the mouse cursor
	// only showing within the canvas,this method is defined for this case.If it returns TRUE,this point is limited
	// within the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Point Limit With Page, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsPointLimitWithPage() { return m_bLimitPointWithinPage; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set point limit with page, when we move the mouse on the canvas,mostly we want that the mouse cursor
	// only showing within the canvas,this method is defined for this case.If bLimit is TRUE,this cursor will
	// be limited within the canvas.
	// bLimit -- limit or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Limit With Page, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bLimit---&bLimit, Specifies A Boolean value.
	void			SetPointLimitWithPage(const BOOL &bLimit) { m_bLimitPointWithinPage = bLimit; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is page border show,by default,the background of the canvas will show a page shadow border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Border Show, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsBorderShow() const	{ return m_bShowPageBorder; }

	//-----------------------------------------------------------------------
	// Summary:
	// Show page border or not,by default, the background of the canvas will show a page shadow border,but
	// you can call this method to show or hide this shadow border.
	// bShow -- TRUE for showing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Show, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void			SetBorderShow(const BOOL &bShow) { m_bShowPageBorder = bShow; }

	//-----------------------------------------------------------------------
	// Summary:
	// Validate current Printer setting, call this method to update the printer device,if it updates successful,
	// it will return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Validate Printer, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	ValidatePrinter();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Print Pages, Returns the specified value.
	//		Returns a int type value.
	int GetTotalPrintPages() const { return m_nTotalPrintPages; }

	// Change total print pages, this is only defined for creating the output string on the Header or the Footer
	// of the print page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Print Pages, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTotal---&nTotal, Specifies A integer value.
	virtual void	SetTotalPrintPages( const int &nTotal)	{ m_nTotalPrintPages = nTotal; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change current print page, this is only defined for creating the output string on the Header or the Footer
	// of the print page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Print Pages, Sets a specify value to current class CFODataModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nCur---&nCur, Specifies A integer value.
	virtual void	SetCurrentPrintPages( const int &nCur)	{ m_nCurPrintPage = nCur; }

	// Show line property or not.
	//-----------------------------------------------------------------------
	// Summary:
	// Show line prop,with this method,you can change the data model to support line properties or not,
	// if it is true,this data model will create the pen object.
	// bShow -- show or hide the pen properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Line Property, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void			ShowLineProp(const BOOL &bShow)			{ m_bLineProp = bShow; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is line property show,if current data model allows line properties,it will be return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Line Property Show, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsLinePropShow() const					{ return m_bLineProp; }

	// Show font property or not.
	//-----------------------------------------------------------------------
	// Summary:
	// Show Font prop,with this method,you can change the data model to support font properties or not,
	// if it is true,this data model will create the font object.
	// bShow -- show or hide the font properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Font Property, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void			ShowFontProp(const BOOL &bShow)			{ m_bFontProp = bShow; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is Font property show,if current data model allows font properties,it will be return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Font Property Show, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsFontPropShow() const					{ return m_bFontProp; }


	//-----------------------------------------------------------------------
	// Summary:
	// Get size form shape, when the system be form mode, a resizing shape will be showed on the background,
	// you can size this shape to change the size of the form size on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size Form Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *	GetSizeFormShape() const				{ return m_pSizeFormComp; }


	//-----------------------------------------------------------------------
	// Summary:
	// Get version of data model,the version of data model had been serialized to file.
	// m_vVersion -- FOVERSION object is defined within file foglobals.h.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Version, Returns the specified value.
	//		Returns A FOVERSION value (Object).
	FOVERSION		GetModelVersion() const					{ return m_vVersion; }

	//-----------------------------------------------------------------------
	// Summary:
	// Is it it's own drag and drop,this method is only defined for drag and drop status.
	// If it is true,the drag status only limited within the same datamodel.If it is false,
	// it means that you had dragged to another canvas or another datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Own Drag, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOwnDrag() const { return m_bIsOwnDrag; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change it's own drag flag,this method is only defined for change drag and drop status.
	// If it is true,the drag status only limited within the same datamodel.If it is false,
	// it means that you had dragged to another canvas or another datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Own Drag, Sets a specify value to current class CFODataModel
	// Parameters:
	//		&bDrag---&bDrag, Specifies A Boolean value.
	void SetOwnDrag(const BOOL &bDrag) { m_bIsOwnDrag = bDrag; }

	//-----------------------------------------------------------------------
	// Summary:
	// Convert value to map logical value
	// nUint -- unit to converting
	// dValue -- value
	// bVertical -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Map Logical, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double& dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void ConvertToMapLog(const FieldUnit &nUint,double& dValue, const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert value from map logical value
	// nUint -- unit to converting
	// dValue -- value
	// bVertical -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Map Logical To, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double& dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void ConvertMapLogTo(const FieldUnit &nUint,double& dValue, const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert value to map logical value
	// nUint -- unit to converting
	// dValue -- value
	// bVertical -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Map Logical Without U I Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double& dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void ConvertToMapLogWithoutUIScale(const FieldUnit &nUint,double& dValue, const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert value from map logical value
	// nUint -- unit to converting
	// dValue -- value
	// bVertical -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Map Logical To Without U I Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double& dValue object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void ConvertMapLogToWithoutUIScale(const FieldUnit &nUint,double& dValue, const BOOL bVertical = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate hit rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Generate Hit Rectangle, .
	//		Returns a CRect type value.  
	// Parameters:
	//		&ptPoint---&ptPoint, Specifies A CPoint type value.  
	//		&nExp---&nExp, Specifies A integer value.
	CRect FOPGenHitRect(const CPoint &ptPoint,const int &nExp = 4);

	//-----------------------------------------------------------------------
	// Summary:
	// Snap intersect point
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Snap Interest Point, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<FOP_LineObject---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&m_arLines---&m_arLines, Specifies a FOP_LineObject> &m_arLines object(Value).  
	//		&object---Specifies a const FOP_LineObject &object object(Value).  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&ptPick---&ptPick, Specifies A CPoint type value.
	BOOL FOSnapInterestPoint(const CArray<FOP_LineObject,FOP_LineObject> &m_arLines,
								  const FOP_LineObject &object,const CPoint &ptHit,CPoint &ptPick);

	// Obtain all the nodes and links on the canvas.
	void GetAllNodesAndLinks(CFODrawShapeSet *m_pNodes,CFODrawShapeSet *m_pLinks);

	// Do new layout with all nodes and links.
	virtual void DoNewLayout(CFODrawShapeSet *m_pNodes,CFODrawShapeSet *m_pLinks);
protected:

	// Layout level
	void SetNewLayoutLevel(CFODrawShapeSet *m_pNodes, int level,
		CArray<CDWordArray*, CDWordArray*>& aGraph);

	// Layout location.
	int SetNewLayoutLocation(CFODrawShapeSet *m_pNodes, int level, int xStart, int yStart,
		int nLevelWidth, CArray<CDWordArray*, CDWordArray*>& aGraph);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Update shape's view state.
 
	// Need Update, This member sets TRUE if it is right.  
	BOOL				m_bNeedUpdate;

	// Full canvas's view position.
 
	// Full View, This member specify FOPRect object.  
	FOPRect				m_rcFullView;

	// Rectangle for clip.
 
	// Current Clipboard, This member specify FOPRect object.  
	FOPRect				m_rcCurClip;

	// For re creating tree
 
	// Need Re Create Tree, This member sets TRUE if it is right.  
	BOOL				m_bNeedReCreateTree;

	BOOL				m_bNeedUpdateAddRemove;

	// Need update the page setting
 
	// Need Update Canvas, This member sets TRUE if it is right.  
	BOOL				m_bNeedUpdateCanvas;

	// Rotating out length.
 
	// Out Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nOutLength;

	// Current snap handle size.
 
	// Default Snap Line Siz Pix, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					fo_DefaultSnapLineSizPix;

	// With ports feature.
	
	// With Port, This member sets TRUE if it is right.  
	BOOL			m_bfoWithPort;

public:
	/*************************************************************************
	|*
	|* id or name of composite shape.
	|*
	\************************************************************************/
	
	// Name of composite shape by default.
 
	// Default State Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefStateText;

	// Id of composite shape by default.
 
	// Default Component I D1, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefCompID1;

	// Id of composite shape by default.
 
	// Default Component I D2, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefCompID2;

	// Id of composite shape by default.
 
	// Default Component I D3, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strDefCompID3;

	// With document opening.
	BOOL			m_bOpenDoc;
	
	// Current symbols file.
	CString				m_strSymbolFile;

	CMap<int,int,CFODrawShape*,CFODrawShape*> mapSaveShape; // 2017

	// With old style.
	BOOL			m_bOldStyle;

	// Drag mode.
	BOOL		m_bDragStart;
protected:

	// Hit test helper method, do not call it outside.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Do Hit Composite, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pHitComp---Hit Component, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		&point---Specifies A CPoint type value.  
	//		&rcHittest---&rcHittest, Specifies A CRect type value.
	virtual CFODrawShape *FODoHitComposite(CFOCompositeShape *pHitComp, const CPoint &point, const CRect &rcHittest);

protected:

	// Background shape.
 
	// Size Form Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *		m_pSizeFormComp;

	// Current open file.
 
	// Current Open Form File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				strCurOpenFormFile;

	// List of the layers.
 
	// Layer, This member specify FOPContainer object.  
	FOPContainer		m_aryLayer;
	
//	CFOCloneThread *m_pThread;
protected:
	// Enable to Snap To Control Handle.
 
	// Snap To  Handle, This member sets TRUE if it is right.  
	BOOL                m_bSnapToControlHandle;

	// Enable to snap to dynamic grid.
 
	// Snap To Dyn Grid, This member sets TRUE if it is right.  
	BOOL				m_bSnapToDynGrid;

	// Enable to Snap To Spot point.
 
	// Snap To Spot, This member sets TRUE if it is right.  
	BOOL                m_bSnapToSpot;

	// Enable to Snap To Intersect Point.
 
	// Snap To Intersect Point, This member sets TRUE if it is right.  
	BOOL                m_bSnapToIntersectPoint;

	// Enable to Snap To Help Line.
 
	// Snap To Help Line, This member sets TRUE if it is right.  
	BOOL                m_bSnapToHelpLine;

	// Enable to snap to page margin
 
	// Snap To Page Border, This member sets TRUE if it is right.  
	BOOL				m_bSnapToPageBorder;

	// Enable to snap to center.
 
	// Snap Aid Line, This member sets TRUE if it is right.  
	BOOL				m_bSnapAidLine;

	// Lock page width or height with page numbers.
 
	// Lock With Pages, This member sets TRUE if it is right.  
	BOOL				m_bLockWithPages;

	// Show page border or not.
 
	// Show Page Border, This member sets TRUE if it is right.  
	BOOL				m_bShowPageBorder;

	// Limit point within page.
 
	// Limit Point Within Page, This member sets TRUE if it is right.  
	BOOL				m_bLimitPointWithinPage;

	// Show with unique name.
 
	// Enable Unique Name, This member sets TRUE if it is right.  
	BOOL				m_bEnableUniqueName;

	// Do use unique caption.
 
	// Enable Unique Caption, This member sets TRUE if it is right.  
	BOOL				m_bEnableUniqueCaption;

	// Is form free resizing.
 
	// Form Free Size, This member sets TRUE if it is right.  
	BOOL				m_bFormFreeSize;

	// Is grid printable.
 
	// Grid Printable, This member sets TRUE if it is right.  
	BOOL				m_bGridPrintable;

	// Rectangle had been changed.
 
	// Rects Dirty, This member sets TRUE if it is right.  
	BOOL				bRectsDirty;

	// Current moving temp link list.
 
	// Temp Link List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_TempLinkList;

	// Tree for hit checking.
	CFOPHitHelper			m_HitTree;

protected:

	// Total print pages.
	
	// Total Print Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTotalPrintPages;

	// Current print page no.
 
	// Current Print Page, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCurPrintPage;

	// Title.
 
	// Title Org, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strTitleOrg;

	// The list pointer of wnd.
 
	// Observer List, This member specify CPtrList object.  
	CPtrList			m_ObserverList;

	// If or not modified.
 
	// Has Modified, This member sets TRUE if it is right.  
	BOOL				m_bHasModified;

	// Form position.
 
	// Position, This member sets a CRect value.  
	FOPRect				m_rectPosition;

	// Select.
 
	// Select, This member sets TRUE if it is right.  
	BOOL				m_bSelect;

	// Current print page size.
 
	// Print Page, This member sets a CRect value.  
	FOPRect				m_rcPrintPage;

	// Is form design mode.
 
	// Form Mode, This member sets TRUE if it is right.  
	BOOL				m_bFormMode;

	// The list of properties.
 
	// List, This member specify E-XD++ CFOBasePropertiesList object.  
	CFOBasePropertiesList m_propList;

	//The list of Form.
 
	// Shape List, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet	m_ShapeList;

	//Back Shape
 
	// Draw Back Component, This member maintains a pointer to the object CFOBackShape.  
	CFOBackShape*		m_pDrawBackComp;

	//Print Dialog
 
	// Dialog, This member specify PAGESETUPDLG object.  
	PAGESETUPDLG		m_printDlg;

	//Print.
	// Header left string.
 
	// Header Left, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strHeaderLeft;

	// Header center string.
 
	// Header Center, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strHeaderCenter;

	// Header right string.
 
	// Header Right, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strHeaderRight;

	// Footer left string.
 
	// Footer Left, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strFooterLeft;

	// Footer center string.
 
	// Footer Center, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strFooterCenter;

	// Footer right string.
 
	// Footer Right, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strFooterRight;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_printstrFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_printnPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_printnHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_printcrColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_printnWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL				m_printbItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL				m_printbUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL				m_printbStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*				m_printpFont;

	// Horz page width.
 
	// Horizontal Number Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nHorzNumberPages;

	// Vert page height.
 
	// Vertical Number Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nVertNumberPages;

	// Show line property.
 
	// Line Property, This member sets TRUE if it is right.  
	BOOL				m_bLineProp;

	// Show font property.
 
	// Font Property, This member sets TRUE if it is right.  
	BOOL				m_bFontProp;

	// Show or hide port.
 
	// Show Port, This member sets TRUE if it is right.  
	BOOL				m_bShowPort;

	
	// Current view map mode.
 
	// Map Mode, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nMapMode;
	
	// Version of datamodel
 
	// Version, This member specify FOVERSION object.  
	FOVERSION			m_vVersion;

	// Help lines list.
 
	// Help Lines, This member specify E-XD++ CFOPHelpLineSet object.  
	CFOPHelpLineSet		aHelpLines;

	// Show or hide help line.
 
	// Hlpl Visible, This member sets TRUE if it is right.  
	BOOL				bHlplVisible;

	// Is it's own drag and drop.
 
	// Is Own Drag, This member sets TRUE if it is right.  
	BOOL				m_bIsOwnDrag;

	// Shape list container
 
	// Shapes, This member specify FOPContainer object.  
	FOPContainer		m_aShapes;

	// Shape list container
 
	// Akt Shapes, This member specify FOPContainer object.  
	FOPContainer		m_aAktShapes;

	// Shape list container
 
	// In View Links, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet		m_aInViewLinks;

	// Limit shapes moving within the specify rectangle.
 
	// Limit, This member specify FOPRect object.  
	FOPRect				m_rcLimit;

	// Measure unit for the UI.
 
	// U I Unit, This member specify FieldUnit object.  
	FieldUnit			m_nUIUnit;

	// UI Scale value.
 
	// U I Scale, This member specify FOPFraction object.  
	FOPFraction			m_aUIScale;

	// Size of the printer paper
 
	// Paper, This member sets a CSize value.  
	CSize				m_sizePaper;

	// Enable insert port into ports shape.
 
	// Enable Insert Port, This member sets TRUE if it is right.  
	BOOL				m_bEnableInsertPort;

	// Current physical margin.
 
	// Physical Margin, This member sets a CRect value.  
	CRect				m_rcPhysicalMargin;

	// Not use default arrow type.
 
	// Not Use Default, This member sets TRUE if it is right.  
	BOOL				m_bNotUseDefault;

	// Need rebuild in view shape list.
 
	// Need Rebuild, This member sets TRUE if it is right.  
	BOOL				m_bNeedRebuild;

	// Canvas width.
 
	// Page Width, This member specify double object.  
	double				m_dPageWidth;

	// Canvas height.
 
	// Page Height, This member specify double object.  
	double				m_dPageHeight;
	
	// Current activate observer.
 
	// Active Observer, This member maintains a pointer to the object CFOObserver.  
	CFOObserver			*m_pActiveObserver;

	// Bounding rectangle of all shapes.
 
	// Maximize Shape Bound, This member specify FOPRect object.  
	FOPRect				m_rcMaxShapeBound;

	// Bounding rectangle of all visible shapes.
 
	// Maximize Visible Bound, This member specify FOPRect object.  
	FOPRect				m_rcMaxVisibleBound;

	// Version 
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nVersion;

	// Disable drag or not.
 
	// Disable Drag, This member sets TRUE if it is right.  
	BOOL				m_bDisableDrag;

	// set for drawing.
	CFODrawShapeSet		m_setDraw;

	
};

/////////////////////////////////////////////////////////////
// CFOShapeFactory

class FO_EXT_CLASS CFOShapeFactory
{
public:

	// Constructor.
	CFOShapeFactory() {};

	// Destructor
	~ CFOShapeFactory() {};
	
public:

	// Make new shape.
	static CFODrawShape *	MakeNewShape(FOPRect rc, UINT m_drawshape,
		CRect &rcCreate,
		const CString &strName,
		const CString &strCaption,
		CString strFileName = _T(""),
		CFOToolBoxItem *pCurItem = NULL);

};

///////////////////////////////////////////////////////////////
// CFOPTemplateObject

class FO_EXT_CLASS CFOPTemplateObject : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, None Description.
	//		Returns A  value.  
	// Parameters:
	//		CFOPTemplateObject---M B File Object, Specifies a CFOPTemplateObject object.
	DECLARE_SERIAL(CFOPTemplateObject);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// M B File Object, Constructs a CFOPTemplateObject object.
	//		Returns A  value.
	CFOPTemplateObject();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C M B File Object, Destructor of class CFOPTemplateObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CFOPTemplateObject();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();
public:
	
	// Serializes the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Template, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object.
	virtual void SerializeTemplate(CArchive &ar);
	
	// Serializes the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Template2, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object.
	virtual void SerializeTemplate2(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Template Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveTemplateDoc(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Template Document, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenTemplateDoc(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Template Document With Data, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenTemplateDocWithData(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Temp File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetTempFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Temp File, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseTempFile(CFile* pFile, BOOL bAbort);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate First Page Bitmap, None Description.

	void GenFirstPageBitmap();
	
public:
	
	// Model Manager, This member maintains a pointer to the object CExtTabModelManager.  
	CFODataModel *pModelManager;
 
	// m_pBitmap, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap			*m_pBitmap;

	// Shapes.
	CFODrawShapeSet m_ShapeList;

	// Caption.
	CString m_strCaption;


	// Description.
	CString m_strDesc;
};

// Multiple pages model list.
typedef CTypedPtrList<CObList, CFODataModel*> CFODataModelList;

#include "FODataModel.inl"

#endif // !defined(AFX_FODATAMODEL_H__2EEABBF7_F19E_11DD_A432_525400EA266C__INCLUDED_)
