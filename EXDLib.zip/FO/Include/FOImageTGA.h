//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGETGA_H__6732CB74_BD6F_47D7_A9F2_3D753BD5F76E__INCLUDED_)
#define AFX_FOIMAGETGA_H__6732CB74_BD6F_47D7_A9F2_3D753BD5F76E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageTGA.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageTGA window

#include "FOBitmap.h"

 
//===========================================================================
// Summary:
//     The CFOImageTGA class derived from CFOBitmap
//      F O Image T G A
//===========================================================================

class FO_EXT_CLASS CFOImageTGA : public CFOBitmap
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageTGA---F O Image T G A, Specifies a E-XD++ CFOImageTGA object (Value).
    DECLARE_SERIAL(CFOImageTGA)

#pragma pack(1)
typedef struct tagTgaHeader
{
    BYTE   IdLength;            // Image ID Field Length
    BYTE   CmapType;            // Color Map Type
    BYTE   ImageType;           // Image Type

    WORD   CmapIndex;           // First Entry Index
    WORD   CmapLength;          // Color Map Length
    BYTE   CmapEntrySize;       // Color Map Entry Size

    WORD   X_Origin;            // X-origin of Image
    WORD   Y_Origin;            // Y-origin of Image
    WORD   ImageWidth;          // Image Width
    WORD   ImageHeight;         // Image Height
    BYTE   PixelDepth;          // Pixel Depth
    BYTE   ImagDesc;            // Image Descriptor
} TGAHEADER;
#pragma pack()

public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image T G A, Constructs a CFOImageTGA object.
	//		Returns A  value (Object).
	CFOImageTGA();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image T G A, Destructor of class CFOImageTGA
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOImageTGA();

public:
	// Save document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    void Serialize(CArchive &ar);
	// Operations

protected:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Decode, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).
	// Decode tga file format.
	bool Decode(CFODataReadBase &reader);

	// Expand compressed line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Expand Line, Do a event. 
	//		Returns An 8-bit BYTE integer that is not signed.  
	// Parameters:
	//		pDest---pDest, A pointer to the BYTE or NULL if the call failed.  
	//		ptgaHead---ptgaHead, A pointer to the TGAHEADER or NULL if the call failed.  
	//		*hFile---*hFile, A pointer to the CFODataReadBase  or NULL if the call failed.  
	//		width---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		rleLeftover---rleLeftover, Specifies An 8-bit BYTE integer that is not signed.
	BYTE DoExpandLine(BYTE* pDest,TGAHEADER* ptgaHead,CFODataReadBase *hFile,int width, int y, BYTE rleLeftover);

	// Expand compressed line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Expand Un Line, Do a event. 
	// Parameters:
	//		pDest---pDest, A pointer to the BYTE or NULL if the call failed.  
	//		ptgaHead---ptgaHead, A pointer to the TGAHEADER or NULL if the call failed.  
	//		*hFile---*hFile, A pointer to the CFODataReadBase  or NULL if the call failed.  
	//		width---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		xoffset---Specifies A integer value.
	void DoExpandUnLine(BYTE* pDest,TGAHEADER* ptgaHead,CFODataReadBase *hFile,int width, int y, int xoffset);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID,LPCTSTR pcszResourceType);

	// load icon file
	// strFileName -- file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);

};


/////////////////////////////////////////////////////////////////////////////
// CFODrawImageTGA class

 
//===========================================================================
// Summary:
//     The CFODrawImageTGA class derived from CFODrawImage
//      F O Draw Image T G A
//===========================================================================

class FO_EXT_CLASS CFODrawImageTGA : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImageTGA---F O Draw Image T G A, Specifies a E-XD++ CFODrawImageTGA object (Value).
	DECLARE_SERIAL(CFODrawImageTGA)
public:

	// Image pointer.
 
	// Image T G A, This member specify E-XD++ CFOImageTGA object.  
	CFOImageTGA m_ImageTGA;

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap() { return &m_ImageTGA; }


public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image T G A, Constructs a CFODrawImageTGA object.
	//		Returns A  value (Object).
	CFODrawImageTGA();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image T G A, Destructor of class CFODrawImageTGA
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImageTGA();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImageTGA &target object(Value).
	virtual BOOL operator==(const CFODrawImageTGA &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGETGA_H__6732CB74_BD6F_47D7_A9F2_3D753BD5F76E__INCLUDED_)
