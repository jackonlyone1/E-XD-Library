//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOListCtrlShape.h: interface for the CFOListCtrlShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOLISTCTRLSHAPE_H__70D7EFCE_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOLISTCTRLSHAPE_H__70D7EFCE_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FODrawPortsShape.h"

class CFOListItem;
// List items.
typedef CTypedPtrList<CObList, CFOListItem*> CFOListItemList;

////////////////////////////////////////////////////////////////////
// CFOListItem -- item of list control shape.

 
//===========================================================================
// Summary:
//     The CFOListItem class derived from CObject
//      F O List Item
//===========================================================================

class FO_EXT_CLASS CFOListItem : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOListItem---F O List Item, Specifies a E-XD++ CFOListItem object (Value).
	DECLARE_SERIAL(CFOListItem);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Item, Constructs a CFOListItem object.
	//		Returns A  value (Object).
	CFOListItem();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Item, Constructs a CFOListItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOListItem& source object(Value).
	CFOListItem(const CFOListItem& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOListItem& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOListItem& source object(Value).
	CFOListItem& operator=(const CFOListItem& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItem,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOListItem* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Item, Destructor of class CFOListItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOListItem();
	
public:

	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	// Draw the object with normal state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.
	virtual void DrawNormal(CDC *pDC,BOOL bEditing);
	
	// Draw the object with select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Select, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.
	virtual void DrawSelect(CDC *pDC,BOOL bEditing);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.
	// Draw the object.
	virtual void Draw(CDC *pDC,BOOL bEditing);

	// get an object from a list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Objects, Returns the specified value.
	//		Returns a pointer to the object CFOListItemList,or NULL if the call failed
	CFOListItemList* GetObjects()		{ return &m_objects; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		pObj---pObj, A pointer to the CFOListItem or NULL if the call failed.
	// add an object.
	// pObj -- children item that will be added.
	void		Add(CFOListItem* pObj);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		pObj---pObj, A pointer to the CFOListItem or NULL if the call failed.
	// remove an object
	// pObj -- children item that will be removed.
	void		Remove(CFOListItem* pObj);

	// Calc label with width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Force Label Width, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&str---Specifies A CString type value.  
	//		nWidth---nWidth, Specifies A integer value.
	void ForceLabelWidth(CDC *pDC,CString &str,int nWidth);

	// Obtain the text width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&str---Specifies A CString type value.
	int GetWidth(CDC *pDC,const CString &str);

	// FODO:Add your properties items below.
	// Get Text Horizon Alignment
	// The alignment of text is one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Horizontal Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextHorzAlignment() const;

	// Set Text Horizon Alignment.
	// nT -- It must be one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOListItem
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextHorzAlignment(const UINT &nT);

	// Hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOListItem,or NULL if the call failed  
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	CFOListItem*	HitTest(CPoint &pt);

	// Change icon resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Resource, Sets a specify value to current class CFOListItem
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetIconRes(const UINT &nRes) { m_nIconID = nRes; }

	// Change icon width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Width, Sets a specify value to current class CFOListItem
	// Parameters:
	//		&nW---&nW, Specifies A integer value.
	void SetIconWidth(const int &nW) { m_nIconWidth = nW; }

	// Is current item a separate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Item Separate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsItemSeparate() const { return m_bSeparate; }
	
	// Chagne item to a separate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Separate, Sets a specify value to current class CFOListItem
	// Parameters:
	//		&bSep---&bSep, Specifies A Boolean value.
	void SetItemSeparate(const BOOL &bSep) { m_bSeparate = bSep; }

public:

	// Is Select
 
	// Select, This member sets TRUE if it is right.  
	BOOL			bSelect;

	// Position Rectangle
 
	// Position, This member sets a CRect value.  
	CRect			rcPosition;

	// Type
 
	// Item Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nItemIndex;

	// Caption string
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;

	// Text Color
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF		crTextColor;
	
	// Back Color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF		crBackColor;

	// Text alignment.
 
	// Text Horizontal Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextHorzAlignment;

	// Children items.
 
	// This member specify E-XD++ CFOListItemList object.  
	CFOListItemList	m_objects;

	// Id of the icon.
 
	// Icon I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nIconID;

	// Icon item width and height.
 
	// Icon Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nIconWidth;

	// Is this item separate.
 
	// Separate, This member sets TRUE if it is right.  
	BOOL			m_bSeparate;
};

_FOLIB_INLINE	UINT CFOListItem::GetTextHorzAlignment()	const
{ 
	return m_nTextHorzAlignment;
}

_FOLIB_INLINE void CFOListItem::SetTextHorzAlignment(const UINT &nT)	
{ 
	m_nTextHorzAlignment = nT;
}

////////////////////////////////////////////////////////////////////
// CFOListPortShape -- Port shape of list control

 
//===========================================================================
// Summary:
//     The CFOListPortShape class derived from CFOPortShape
//      F O List Port Shape
//===========================================================================

class FO_EXT_CLASS CFOListPortShape : public CFOPortShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOListPortShape---F O List Port Shape, Specifies a E-XD++ CFOListPortShape object (Value).
	DECLARE_SERIAL(CFOListPortShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Port Shape, Constructs a CFOListPortShape object.
	//		Returns A  value (Object).
	CFOListPortShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Port Shape, Constructs a CFOListPortShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOListPortShape& src object(Value).
	CFOListPortShape(const CFOListPortShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Port Shape, Destructor of class CFOListPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOListPortShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOListPortShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		*pParent---*pParent, A pointer to the CFODrawShape  or NULL if the call failed.
	// Creates the port shape from a CPoint object.
	// point -- point of port.
	// pParent -- parent shape.
	virtual void Create(CPoint point,CFODrawShape *pParent);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOListPortShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOListPortShape& src object(Value).
	CFOListPortShape& operator=(const CFOListPortShape& src);

	// Generate up - right link directions.
	virtual CSize DoGenDirs(CFOLinkShape *pLink, const CPoint& ptEnd,
		const CRect& rcBound, CFOPortShape *pOtherPort);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	// pRgn -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

	// Get item's index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Index, Returns the specified value.
	//		Returns a int type value.
	int GetItemIndex() const { return m_nIndexItem; }

	// Change item's index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Index, Sets a specify value to current class CFOListPortShape
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetItemIndex(const int &nIndex) { m_nIndexItem = nIndex; }

	// Is left port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Left, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLeft() const { return m_bLeft; }

	// Set left or right.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left, Sets a specify value to current class CFOListPortShape
	// Parameters:
	//		&bLeft---&bLeft, Specifies A Boolean value.
	void SetLeft(const BOOL &bLeft) { m_bLeft = bLeft;}

	// Is top port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Top, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTop() const { return m_bTop; }

	// Set top port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top, Sets a specify value to current class CFOListPortShape
	// Parameters:
	//		&bTop---&bTop, Specifies A Boolean value.
	void SetTop(const BOOL &bTop) { m_bTop = bTop; }

	// Is bottom port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bottom, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsBottom() const { return m_bBottom; }

	// Set bottom port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bottom, Sets a specify value to current class CFOListPortShape
	// Parameters:
	//		&bBottom---&bBottom, Specifies A Boolean value.
	void SetBottom(const BOOL &bBottom) { m_bBottom = bBottom; }

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Index of the list item.
 
	// Index Item, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nIndexItem;

	// Is left or right.
 
	// Left, This member sets TRUE if it is right.  
	BOOL		m_bLeft;

	// Is top port style
 
	// Top, This member sets TRUE if it is right.  
	BOOL		m_bTop;

	// Is bottom port style.
 
	// Bottom, This member sets TRUE if it is right.  
	BOOL		m_bBottom;
};


////////////////////////////////////////////////////////////////
// CFOListCtrlShape -- list control shape, a shape with multiple items can be choosed.
//                    ID: FO_COMP_LISTCTRL 15
//

 
//===========================================================================
// Summary:
//     The CFOListCtrlShape class derived from CFODrawPortsShape
//      F O List  Shape
//===========================================================================

class FO_EXT_CLASS CFOListCtrlShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOListCtrlShape---F O List  Shape, Specifies a E-XD++ CFOListCtrlShape object (Value).
	DECLARE_SERIAL(CFOListCtrlShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List  Shape, Constructs a CFOListCtrlShape object.
	//		Returns A  value (Object).
	CFOListCtrlShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List  Shape, Constructs a CFOListCtrlShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOListCtrlShape& src object(Value).
	CFOListCtrlShape(const CFOListCtrlShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List  Shape, Destructor of class CFOListCtrlShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOListCtrlShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the list ctrl shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strList---&strList, Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the list ctrl shape from a CRect object.
	// strList -- items list string, please use "\r\n" for new items.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const CString &strList, CRect &rcPos,CString strCaption = _T(""));

public:

	// Get next line of the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Next Line Extend, .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A CString type value.  
	//		&sLine---&sLine, Specifies A CString type value.
	int FOGetNextLineExt(CString& s, CString &sLine);

	// get an object from a list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Objects, Returns the specified value.
	//		Returns a pointer to the object CFOListItemList,or NULL if the call failed
	CFOListItemList* GetObjects()		{ return &m_objects; }

	//Create Default Port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create List Port, You construct a CFOListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListPortShape,or NULL if the call failed  
	// Parameters:
	//		&nListIndex---List Index, Specifies A integer value.  
	//		&bLeft---&bLeft, Specifies A Boolean value.
	virtual CFOListPortShape* CreateListPort(const int &nListIndex,const BOOL &bLeft);

	// Create other Default Port that can be layout at the top or bottom border.
	// nPortIndex -- index of the port for searching.
	// bTop -- top or bottom.
	// dScale -- scale value from 0.0 to 1.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Other List Port, You construct a CFOListCtrlShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListPortShape,or NULL if the call failed  
	// Parameters:
	//		&nPortIndex---Port Index, Specifies A integer value.  
	//		&bTop---&bTop, Specifies A Boolean value.  
	//		&dScale---&dScale, Specifies a const double &dScale object(Value).
	virtual CFOListPortShape* CreateOtherListPort(const int &nPortIndex,const BOOL &bTop,const double &dScale);

	// Obtain the port from index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port From Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListPortShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		bLeft---bLeft, Specifies A Boolean value.
	virtual CFOListPortShape* FindPortFromIndex(const int& nIndex,BOOL bLeft);

	// Obtain the port from index.
	// nIndex -- port index of top or bottom port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Other Port From Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListPortShape,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFOListPortShape* FindOtherPortFromIndex(const int& nIndex);

	// Layout all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout All Ports, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void LayoutAllPorts(const CRect &rcPos);

	// Offset all points,call this method to moving the shape.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);
	
	// Set current scroll record nodes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scrolled, Sets a specify value to current class CFOListCtrlShape
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	void    SetScrolled(long n);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scrolled, .
	//		Returns A 32-bit long signed integer.
	// Scrolled nodes.
    long    Scrolled();

	// Scroll down one node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Down, .

    void    ScrollDown();

	// Scroll up one node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Up, .

    void    ScrollUp();

	// # nodes that be visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Fields, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long    GetTotalFields();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOListCtrlShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOListCtrlShape& src object(Value).
	CFOListCtrlShape& operator=(const CFOListCtrlShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the min height of all the items;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Items, Returns the specified value.
	//		Returns a int type value.
	int GetAllItems();

	// Create other Default Port that can be layout at the top or bottom border.
	// nPortIndex -- index of the port for searching.
	// bTop -- top or bottom.
	// dScale -- scale value from 0.0 to 1.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Other Port, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListPortShape,or NULL if the call failed  
	// Parameters:
	//		&nPortIndex---Port Index, Specifies A integer value.  
	//		&bTop---&bTop, Specifies A Boolean value.  
	//		&dScale---&dScale, Specifies a const double &dScale object(Value).
	virtual CFOListPortShape* AddOtherPort(const int &nPortIndex,const BOOL &bTop,const double &dScale);

	// add port at top border
	// Please call layout method when you changed all the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Top Port, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPortIndex---Port Index, Specifies A integer value.  
	//		&dScale---&dScale, Specifies a const double &dScale object(Value).
	virtual void AddTopPort(const int &nPortIndex,const double &dScale);

	// add port at bottom border
	// Please call layout method when you changed all the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bottom Port, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPortIndex---Port Index, Specifies A integer value.  
	//		&dScale---&dScale, Specifies a const double &dScale object(Value).
	virtual void AddBottomPort(const int &nPortIndex,const double &dScale);

	// Add new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItem ,or NULL if the call failed  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.  
	//		bLeftPort---Left Port, Specifies A Boolean value.  
	//		bRightPort---Right Port, Specifies A Boolean value.  
	//		&str---Specifies A CString type value.
	virtual CFOListItem *AddNewItem(const int &nItemIndex,BOOL bLeftPort,BOOL bRightPort,const CString &str = _T(" "));
	
	// Add new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOListItem  or NULL if the call failed.  
	//		&nItemIndex---Item Index, Specifies A integer value.  
	//		bLeftPort---Left Port, Specifies A Boolean value.  
	//		bRightPort---Right Port, Specifies A Boolean value.
	virtual void AddNewItem(CFOListItem *pItem,const int &nItemIndex,BOOL bLeftPort,BOOL bRightPort);

	// Add new separate item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Separate, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItem ,or NULL if the call failed  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual CFOListItem *AddNewSeparate(const int &nItemIndex);

	// Remove item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual BOOL RemoveItem(const int &nItemIndex);

	// Remove only port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Only Ports, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual void RemoveOnlyPorts(const int &nItemIndex);

	// Set left port
	// Please call layout method when you changed all the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Port, Sets a specify value to current class CFOListCtrlShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual void SetLeftPort(const int &nItemIndex);

	// Set right port
	// Please call layout method when you changed all the ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Right Port, Sets a specify value to current class CFOListCtrlShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual void SetRightPort(const int &nItemIndex);


	// Change item's string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Item String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.  
	//		&strItem---&strItem, Specifies A CString type value.
	virtual void ChangeItemString(const int &nItemIndex, const CString &strItem);

	// Remove item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItem ,or NULL if the call failed  
	// Parameters:
	//		&nItemIndex---Item Index, Specifies A integer value.
	virtual CFOListItem *FindItem(const int &nItemIndex);
	
	// Remove all items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllItem();
	
	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
    virtual CFOListItem *HitTestGrid(CPoint pt);
    
	// Change cell text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Cell Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strCell---&strCell, Specifies A CString type value.
	virtual void ChangeCellText(const CString &strCell);

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD GenEditingLabelAlign();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GenLabelAlign();

	// Obtain the item height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Height, Returns the specified value.
	//		Returns a int type value.
	int GetItemHeight() const;

	// Change the item height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Height, Sets a specify value to current class CFOListCtrlShape
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.
	void SetItemHeight(const int &nHeight) { m_nItemHeight = nHeight; }

	// Change icon resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Resource, Sets a specify value to current class CFOListCtrlShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetIconRes(const UINT &nRes) { m_nIconID = nRes; }

	// Change icon width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Width, Sets a specify value to current class CFOListCtrlShape
	// Parameters:
	//		&nW---&nW, Specifies A integer value.
	void SetIconWidth(const int &nW) { m_nIconWidth = nW; }

	// Has bottom line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bottom Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsBottomLine() const { return m_bBottomLine; }

	// Showing bottom line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Bottom Line, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowBottomLine(const BOOL &bShow) { m_bBottomLine = bShow; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Hit test child shape, return TRUE if hitted.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Up Button, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL HitTestUpButton(const CPoint &ptHit);

	// Hit test child shape, return TRUE if hitted.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Down Button, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL HitTestDownButton(const CPoint &ptHit);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Do draw spin buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Spins, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcMax---&rcMax, Specifies A CRect type value.
	virtual void OnDrawSpins(CDC *pDC, const CRect &rcMax);

	// Obtain current item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Item, Returns the specified value.
	//		Returns a pointer to the object CFOListItem ,or NULL if the call failed
	CFOListItem *GetCurrentItem();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:

	// Items list
 
	// This member specify E-XD++ CFOListItemList object.  
	CFOListItemList		m_objects;	// list of objects

	// Current hit item.
 
	// Current Hit, This member maintains a pointer to the object CFOListItem.  
	CFOListItem *		pCurHit;

	// Item height.
 
	// Item Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nItemHeight;

	// number of fields that are scrolled/hidden.
 
	// Scrolled, Specify a A 32-bit signed integer.  
	long                m_nScrolled;

	// # of fields visible
 
	// Fields Visible, Specify a A 32-bit signed integer.  
	long                m_nFieldsVisible;

	// rectangle of the up arrow.
 
	// Up, This member sets a CRect value.  
	CRect				m_rcUp;

	// rectangle of the down arrow.
 
	// Down, This member sets a CRect value.  
	CRect				m_rcDown;

protected:
	// Id of the icon.
 
	// Icon I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nIconID;

	// Icon item width and height.
 
	// Icon Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nIconWidth;

	// With bottom line for each item.
 
	// Bottom Line, This member sets TRUE if it is right.  
	BOOL				m_bBottomLine;
};

#endif // !defined(AFX_FOLISTCTRLSHAPE_H__70D7EFCE_F31E_11DD_A436_525400EA266C__INCLUDED_)
