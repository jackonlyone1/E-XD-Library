//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOUSERPROPERTIES_H__DB142DB3_6A58_4DB1_B7B6_BFBF00B6FD5C__INCLUDED_)
#define AFC_FOUSERPROPERTIES_H__DB142DB3_6A58_4DB1_B7B6_BFBF00B6FD5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseProperties.h"

//************************************************************
// CFOUserProperties, this class is very important for property define.
// You can use it to define any kind of custom property values.
//************************************************************

 
//===========================================================================
// Summary:
//     The CFOUserProperties class derived from CFOBaseProperties
//      F O User Properties
//===========================================================================

class FO_EXT_CLASS CFOUserProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOUserProperties---F O User Properties, Specifies a E-XD++ CFOUserProperties object (Value).
	DECLARE_SERIAL(CFOUserProperties)

// Construction/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O User Properties, Constructs a CFOUserProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOUserProperties(int nCurID = -1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O User Properties, Constructs a CFOUserProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOUserProperties& propShape object(Value).
	CFOUserProperties(const CFOUserProperties& propShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O User Properties, Destructor of class CFOUserProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOUserProperties();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of properties.
	virtual CFOBaseProperties* Copy();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Put value, change the property value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get value, obtain the property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	//-----------------------------------------------------------------------
	// Summary:
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Variable Value, Returns the specified value.
	//		Returns A FO_VALUE value (Object).
	FO_VALUE GetVarValue() const { return m_vValue; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Variable Value, Sets a specify value to current class CFOUserProperties
	// Parameters:
	//		&vValue---&vValue, Specifies a const FO_VALUE &vValue object(Value).
	void SetVarValue(const FO_VALUE &vValue) { m_vValue = vValue; }

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is equal or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	//-----------------------------------------------------------------------
	// Summary:
	// Sets this set of this properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOUserProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOUserProperties& propEdit object(Value).
	virtual CFOUserProperties& operator=(const CFOUserProperties& propEdit);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	//-----------------------------------------------------------------------
	// Summary:
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOUserProperties propEdit object(Value).
	virtual BOOL operator==(const CFOUserProperties &propEdit) const;

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Current data.
 
	// Value, This member specify FO_VALUE object.  
	FO_VALUE m_vValue;

};

_FOLIB_INLINE CFOBaseProperties* CFOUserProperties::Copy()
{
	return new CFOUserProperties(*this);
}


#endif // !defined(AFC_FOUSERPROPERTIES_H__DB142DB3_6A58_4DB1_B7B6_BFBF00B6FD5C__INCLUDED_)
