//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLINEHANDLE_H__EC78C178_C243_461E_B534_01F86DDE30B6__INCLUDED_)
#define AFX_FOPLINEHANDLE_H__EC78C178_C243_461E_B534_01F86DDE30B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// FOPLineHandle.h : header file
//

#include "FOArea.h"
#include "FOPUtil.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPLineHandle line
//
// This class is the mirror line object.
// When we mirror a list of shapes, a mirror line will be showed.
//
/////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPLineHandle class derived from CObject
//      F O P Line Handle
//===========================================================================

class FO_EXT_CLASS CFOPLineHandle : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLineHandle---F O P Line Handle, Specifies a E-XD++ CFOPLineHandle object (Value).
	DECLARE_SERIAL(CFOPLineHandle);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Handle, Constructs a CFOPLineHandle object.
	//		Returns A  value (Object).
	CFOPLineHandle();

	// Copy constructor. 
	// ptRef1 -- first point of the mirror line.
	// ptRef2 -- second point of the mirror line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Handle, Constructs a CFOPLineHandle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptRef1---ptRef1, Specifies A integer value.  
	//		&ptRef2---&ptRef2, Specifies A integer value.
	CFOPLineHandle(const FOPPoint& ptRef1, const FOPPoint &ptRef2);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Handle, Constructs a CFOPLineHandle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPLineHandle& source object(Value).
	CFOPLineHandle(const CFOPLineHandle& source);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPLineHandle object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptRef1---ptRef1, Specifies A integer value.  
	//		&ptRef2---&ptRef2, Specifies A integer value.
	// Create the line control.
	// ptRef1 -- first point of the mirror line.
	// ptRef2 -- second point of the mirror line.
	virtual void Create(const FOPPoint& ptRef1, const FOPPoint &ptRef2);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Line Handle, Destructor of class CFOPLineHandle
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLineHandle();
	
	// Assignment operator.
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPLineHandle& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPLineHandle& source object(Value).
	CFOPLineHandle& operator=(const CFOPLineHandle& source);

	// == operator.
	// rCmp -- compare line handle object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rCmp---rCmp, Specifies a const CFOPLineHandle& rCmp object(Value).
	BOOL operator==(const CFOPLineHandle& rCmp) const;

	// != operator.
	// rCmp -- compare line handle object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rCmp---rCmp, Specifies a const CFOPLineHandle& rCmp object(Value).
	BOOL operator!=(const CFOPLineHandle& rCmp) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).
	// Draw the object.
	// pDC -- pointer of the DC.
	// szHdl -- size of the handle
	virtual void Draw(CDC *pDC,const FOPSize& szHdl);

	// Draw the object.
	// pDC -- pointer of the DC
	// ptOffset -- offset point.
	// szHdl -- size of the handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Track, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).
	virtual void DrawTrack(CDC *pDC,const CPoint &ptOffset,const FOPSize& szHdl);

	// Draw the object.
	// pDC -- pointer of the DC
	// ptOffset -- offset point.
	// szHdl -- size of the handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Track Start, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).
	virtual void DrawTrackStart(CDC *pDC,const CPoint &ptOffset,const FOPSize& szHdl);

	// Draw the object.
	// pDC -- pointer of the DC
	// ptOffset -- offset point.
	// szHdl -- size of the handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Track End, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).
	virtual void DrawTrackEnd(CDC *pDC,const CPoint &ptOffset,const FOPSize& szHdl);

	// Is handle Visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsVisible() const			{	return m_bVisible;	}

	// Set Visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOPLineHandle
	// Parameters:
	//		bJa---bJa, Specifies A Boolean value.
	void SetVisible(BOOL bJa = TRUE);

	// Change ref1 handle position.
	// ptPnt -- new reference point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ref1 Position, Sets a specify value to current class CFOPLineHandle
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.
	void SetRef1Pos(const FOPPoint& ptPnt);

	// Get ref1 handle point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ref1 Position, Returns the specified value.
	//		Returns a CPoint type value.
	const CPoint& GetRef1Pos() const	{	return m_ptRef1;	}

	// Change ref2 handle position.
	// ptPnt -- new reference point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ref2 Position, Sets a specify value to current class CFOPLineHandle
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.
	void SetRef2Pos(const FOPPoint& ptPnt);

	// Get ref2 handle point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ref2 Position, Returns the specified value.
	//		Returns a CPoint type value.
	const CPoint& GetRef2Pos() const	{	return m_ptRef2;	}


	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	// Translate the line.
	// ptOffset -- offset point
	void Translate(const CPoint &ptOffset);

	// Translate the line.
	// ptOffset -- offset point
	// bStart -- start point or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		bStart---bStart, Specifies A Boolean value.
	void OffsetPoint(const CPoint &ptOffset,BOOL bStart);

	// Is hit.
	// rPnt -- point for hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hit, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		&nSpace---&nSpace, Specifies A integer value.
	virtual BOOL IsHit(const FOPPoint& rPnt,const int &nSpace);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  GeometryUpdated(CFOArea* pArea);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();
	
	// Get current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Area, .
	//		Returns A const CFOArea value (Object).
	const CFOArea &GetShapeArea() const;

	// Get snap position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetSnapRect() const;

	// Draw rotating center circle.
	// pDC -- pointer of the DC
	// rcPos -- position for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rotating Center, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void DrawRotatingCenter(CDC *pDC,const CRect &rcPos);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Position of ref1 point.
 
	// Ref1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptRef1;

	// Position of ref2 point.
 
	// Ref2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptRef2;

	// Compute area.
 
	// Shape Area, This member specify E-XD++ CFOArea object.  
	CFOArea			m_ShapeArea;

	// Select or not.
 
	// Visible, This member sets TRUE if it is right.  
	BOOL			m_bVisible;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLINEHANDLE_H__EC78C178_C243_461E_B534_01F86DDE30B6__INCLUDED_)
