//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTABPAGEMODEL_H__1E4323A2_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
#define FO_FOTABPAGEMODEL_H__1E4323A2_F9E3_11D5_A4DE_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "fodatamodel.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOTabPageModel
//
// This is the class defined for Visio App style application,it is the data model of
// this kind of application.
//
// Most the control methods is defined with its parent class CFODataModel,all the data model
// is managed by class CFOTabModelManager.
//
/////////////////////////////////////////////////////////////////////////////////

class CFOTabModelManager;

 
//===========================================================================
// Summary:
//     The CFOTabPageModel class derived from CFODataModel
//      F O Tab Page Model
//===========================================================================

class FO_EXT_CLASS CFOTabPageModel : public CFODataModel
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabPageModel---F O Tab Page Model, Specifies a E-XD++ CFOTabPageModel object (Value).
	DECLARE_SERIAL(CFOTabPageModel);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Page Model, Constructs a CFOTabPageModel object.
	//		Returns A  value (Object).
	CFOTabPageModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	// source -- target data model object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Page Model, Constructs a CFOTabPageModel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOTabPageModel& source object(Value).
	CFOTabPageModel(const CFOTabPageModel& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Page Model, Destructor of class CFOTabPageModel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabPageModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	// source -- target data model object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTabPageModel& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOTabPageModel& source object(Value).
	CFOTabPageModel& operator=(const CFOTabPageModel& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModel,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFODataModel* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the manager pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Manager, Returns the specified value.
	//		Returns a pointer to the object CFOTabModelManager ,or NULL if the call failed
	virtual CFOTabModelManager *GetManager() const { return m_pDataManager; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the data model manager.
	// pMgr -- pointer of the data model manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data Manager, Sets a specify value to current class CFOTabPageModel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pMgr---*pMgr, A pointer to the CFOTabModelManager  or NULL if the call failed.
	virtual void SetDataManager(CFOTabModelManager *pMgr) { m_pDataManager = pMgr; }

	//-----------------------------------------------------------------------
	// Summary:
	// Check if it is need saving property now.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Property Now, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL			DoSavePropNow();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Tab page item caption.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString     m_strCaption;

	// Pointer of the data model manager.
 
	// Data Manager, This member maintains a pointer to the object CFOTabModelManager.  
	CFOTabModelManager	*m_pDataManager;
};

#endif // !defined(FO_FOTABPAGEMODEL_H__1E4323A2_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
