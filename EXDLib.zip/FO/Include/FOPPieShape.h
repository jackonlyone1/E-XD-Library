//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPPIESHAPE_H__80C653FE_7E3A_4B48_9070_59C4206E71FA__INCLUDED_)
#define AFC_FOPPIESHAPE_H__80C653FE_7E3A_4B48_9070_59C4206E71FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOPPieShape -- pie shape, it has two anchor points,
//				ID: FO_COMP_PIE 48
// Author: ucancode.net Software.
//------------------------------------------------------

#include "FODrawPortsShape.h"

 
//===========================================================================
// Summary:
//     The CFOPPieShape class derived from CFODrawPortsShape
//      F O P Pie Shape
//===========================================================================

class FO_EXT_CLASS CFOPPieShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPPieShape---F O P Pie Shape, Specifies a E-XD++ CFOPPieShape object (Value).
	DECLARE_SERIAL(CFOPPieShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Pie Shape, Constructs a CFOPPieShape object.
	//		Returns A  value (Object).
	CFOPPieShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Pie Shape, Constructs a CFOPPieShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPPieShape& src object(Value).
	CFOPPieShape(const CFOPPieShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Pie Shape, Destructor of class CFOPPieShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPieShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPPieShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		bMore---bMore, Specifies A Boolean value.
	// Creates the pie shape from points.
	// rcPos -- bounding position of the pie.
	// ptStart -- start point.
	// ptEnd -- end point.
	// bMore -- drawing more smooth.
	BOOL Create(const CRect &rcPos,const CPoint &ptStart,const CPoint &ptEnd,BOOL bMore = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPPieShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the pie shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPPieShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcPos---rcPos, Specifies a const FOPRect& rcPos object(Value).  
	//		nNewStartAngle---New Start Angle, Specifies A 32-bit long signed integer.  
	//		nNewEndAngle---New End Angle, Specifies A 32-bit long signed integer.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// nNewStartAngle -- start angle of the shape.(From 0 - 36000)
	// nNewEndAngle -- end angle of the shape.(From 0 - 36000)
	// strCaption -- caption of shape.
	virtual BOOL Create(const FOPRect& rcPos,long nNewStartAngle, long nNewEndAngle,CString strCaption = _T(""));

public:
	
	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetExtAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetExtAnchorPoint(CPoint ptOffset);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dCenterX---Center X, Specifies a double &dCenterX object(Value).  
	//		&dCenterY---Center Y, Specifies a double &dCenterY object(Value).
	virtual void GetRotateCenter(double &dCenterX,double &dCenterY) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// mpSpot -- result of the spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetRotateCenterSpotLocation(CFOPHandleList& lstHandle);

	// Scales the shape about its center to the size specified. 
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);

	// Rest the geometry data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rest Geogmetry Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aData---aData, Specifies a const FOPObjGeoData& aData object(Value).
	virtual void RestGeoData(const FOPObjGeoData& aData);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPPieShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPPieShape& src object(Value).
	CFOPPieShape& operator=(const CFOPPieShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect		GetMaxRect();

	// Obtain the simple polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Polygon Object, Returns the specified value.
	//		Returns A FOPSimplePolygon value (Object).
	FOPSimplePolygon *GetXPolyObject() { return &aXPoly; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	// Define for track line.
	// fX -- x track scale of shape.
	// fY -- y track scale of shape.
	// fOX -- x track origin of shape.
	// fOY -- y track origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dY, double dOX, double dOY);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Save position.
 
	// Save Position, This member sets a CRect value.  
	CRect		m_rcSavePos;

	// Save start point.
 
	// Save Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveStart;

	// Save end point.
 
	// Save End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveEnd;

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

	// Simple polygon object.
 
	// Track X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aTrackXPoly;
};

//===========================================================================
// Summary:
//     The CFOPRingShape class derived from CFODrawPortsShape
//      F O P Ring Shape
//===========================================================================

class FO_EXT_CLASS CFOPRingShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRingShape---F O P Pie Shape, Specifies a E-XD++ CFOPRingShape object (Value).
	DECLARE_SERIAL(CFOPRingShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Pie Shape, Constructs a CFOPRingShape object.
	//		Returns A  value (Object).
	CFOPRingShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Pie Shape, Constructs a CFOPRingShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRingShape& src object(Value).
	CFOPRingShape(const CFOPRingShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Pie Shape, Destructor of class CFOPRingShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPRingShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRingShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		bMore---bMore, Specifies A Boolean value.
	// Creates the pie shape from points.
	// rcPos -- bounding position of the pie.
	// ptStart -- start point.
	// ptEnd -- end point.
	// bMore -- drawing more smooth.
	BOOL Create(const CRect &rcPos,const CPoint &ptStart,const CPoint &ptEnd,BOOL bMore = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRingShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the pie shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRingShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcPos---rcPos, Specifies a const FOPRect& rcPos object(Value).  
	//		nNewStartAngle---New Start Angle, Specifies A 32-bit long signed integer.  
	//		nNewEndAngle---New End Angle, Specifies A 32-bit long signed integer.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// nNewStartAngle -- start angle of the shape.(From 0 - 36000)
	// nNewEndAngle -- end angle of the shape.(From 0 - 36000)
	// strCaption -- caption of shape.
	virtual BOOL Create(const FOPRect& rcPos,long nNewStartAngle, long nNewEndAngle,CString strCaption = _T(""));

public:
	
	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetExtAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetExtAnchorPoint(CPoint ptOffset);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dCenterX---Center X, Specifies a double &dCenterX object(Value).  
	//		&dCenterY---Center Y, Specifies a double &dCenterY object(Value).
	virtual void GetRotateCenter(double &dCenterX,double &dCenterY) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// mpSpot -- result of the spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetRotateCenterSpotLocation(CFOPHandleList& lstHandle);

	// Scales the shape about its center to the size specified. 
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);

	// Rest the geometry data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rest Geogmetry Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aData---aData, Specifies a const FOPObjGeoData& aData object(Value).
	virtual void RestGeoData(const FOPObjGeoData& aData);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPRingShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRingShape& src object(Value).
	CFOPRingShape& operator=(const CFOPRingShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect		GetMaxRect();

	// Obtain the simple polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Polygon Object, Returns the specified value.
	//		Returns A FOPSimplePolygon value (Object).
	FOPSimplePolygon *GetXPolyObject() { return &aXPoly; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	// Define for track line.
	// fX -- x track scale of shape.
	// fY -- y track scale of shape.
	// fOX -- x track origin of shape.
	// fOY -- y track origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dY, double dOX, double dOY);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	void UpdateRing();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Save position.
 
	// Save Position, This member sets a CRect value.  
	CRect		m_rcSavePos;

	// Save start point.
 
	// Save Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveStart;

	// Save end point.
 
	// Save End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveEnd;

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

	// Simple polygon object.
 
	// Track X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aTrackXPoly;
};

#endif // !defined(AFC_FOPPIESHAPE_H__80C653FE_7E3A_4B48_9070_59C4206E71FA__INCLUDED_)
