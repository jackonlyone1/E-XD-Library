//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPFLATCOMBOBOX_H__383858C9_8253_470A_89D9_EC9A5594D6DC__INCLUDED_)
#define AFX_FOPFLATCOMBOBOX_H__383858C9_8253_470A_89D9_EC9A5594D6DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPFlatComboBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPFlatComboBox window

#include "FODrawShape.h"
//===========================================================================
// Summary:
//     The CFOPFlatComboBox class derived from CComboBox
//      F O P Flat Combo Box
//===========================================================================

class FO_EXT_CLASS CFOPFlatComboBox : public CComboBox
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPFlatComboBox---F O P Flat Combo Box, Specifies a E-XD++ CFOPFlatComboBox object (Value).
    DECLARE_DYNAMIC(CFOPFlatComboBox)

public:
    
    // Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Flat Combo Box, Constructs a CFOPFlatComboBox object.
	//		Returns A  value (Object).
    CFOPFlatComboBox();

    // Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Flat Combo Box, Destructor of class CFOPFlatComboBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPFlatComboBox();

	CFODrawShape *m_pShape;
protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.

	// Init all gdi handles.
	void Init();

	// Drawing combobox
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Combo, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		0---Specifies a 0 object(Value).  
	//		200---Specifies a 200 object(Value).  
	//		200)---Specifies a 200) object(Value).
    void DoDrawCombo(CDC* pDC,UINT nStyle,CRect rcPos = CRect(0,0,200,200));

	// Drawing method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void DoDraw(CDC* pDC);

	// Clean all gdi handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clean Up, .

	void CleanUp();

	// Adjust layout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Layout, .

	void AdjustLayout();
public:
	COLORREF m_crTrueBack;
	COLORREF m_crTrueText;
//	COLORREF m_crTrueLine;
public:
	
	// Is flat or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Flat Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFlatMode();

	// Show flat border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Flat Mode, Sets a specify value to current class CFOPFlatComboBox
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
    void SetFlatMode(const BOOL &bShow);

	// With focus.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Focus, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL HasFocus() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Input, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bWith---&bWith, Specifies A Boolean value.
	// Input
    virtual void Input(const BOOL &bWith);

    // Ignore:
	//{{AFX_VIRTUAL(CFOPFlatComboBox)
    public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
    virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		lpCompareItemStruct---Compare Item Struct, Specifies a LPCOMPAREITEMSTRUCT lpCompareItemStruct object(Value).
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDeleteItemStruct---Delete Item Struct, Specifies a LPDELETEITEMSTRUCT lpDeleteItemStruct object(Value).
	virtual void DeleteItem(LPDELETEITEMSTRUCT lpDeleteItemStruct);
    //}}AFX_VIRTUAL

    // Ignore:
	//{{AFX_MSG(CFOPFlatComboBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Update, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctl Color, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Paint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnNcPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Select, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEndSel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Border, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDrawBorder(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.

    afx_msg void OnSetFocus();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.

    afx_msg void OnKillFocus();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()
protected:

	// Style
 
	// Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD			m_dwStyle;

	// With focus or not.
 
	// Focus, This member sets TRUE if it is right.  
	BOOL			m_bFocus;

	// Pointer of edit.
 
	// Window Edit, This member maintains a pointer to the object CEdit.  
	CEdit*			m_pWndEdit;

	// With extend style.
 
	// Other Style, This member sets TRUE if it is right.  
	BOOL			m_bOtherStyle;

	// Rectangle of combobox
 
	// Combo, This member sets a CRect value.  
	CRect			m_rectCombo;

	// Rectangle of button.
 
	// Button, This member sets a CRect value.  
	CRect			m_rectButton;

	// Show flat mode.
 
	// Flat, This member sets TRUE if it is right.  
	BOOL			m_bFlat;

	// Time separator.
 
	// Time Separator, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strTimeSeparator;
 
	// Previous Digit, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_iPrevDigit;
 
	// Selected Part, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_iSelectedPart;

	// Is key down.
 
	// Key Down, This member sets TRUE if it is right.  
	BOOL			m_bKeyDown;

	// Be captured.
 
	// Captured, This member sets TRUE if it is right.  
	BOOL			m_bCaptured;

	// Do drawing state.
 
	// Drawing, This member sets TRUE if it is right.  
	BOOL			m_bDrawing;

};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CFOPImageListBox window

 
//===========================================================================
// Summary:
//     The CFOPImageListBox class derived from CListBox
//      F O P Image List Box
//===========================================================================

class FO_EXT_CLASS CFOPImageListBox : public CListBox
{
// Construction
public:
	// Constructs.
	CFOPImageListBox(int cx=GetSystemMetrics(SM_CXSMICON),
		int cy=GetSystemMetrics(SM_CYSMICON), 
		UINT nFlags=ILC_COLOR24|ILC_MASK);

// Attributes
public:

// Operations
public:
	// Retrieves the background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.
	virtual COLORREF GetBkColor() const { return m_clrBackground; }
	
	// Sets the background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOPImageListBox
	// Parameters:
	//		clrBackground---clrBackground, Specifies A 32-bit COLORREF value used as a color value.
	void SetBkColor(COLORREF clrBackground) ;

	// Retrieves the Highlight color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Highlight Color, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.
	virtual COLORREF GetHighlightColor() const { return m_clrHighlight; }
	
	// Sets the Highlight color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Highlight Color, Sets a specify value to current class CFOPImageListBox
	// Parameters:
	//		clrHighlight---clrHighlight, Specifies A 32-bit COLORREF value used as a color value.
	void SetHighlightColor(COLORREF clrHighlight) ;

	// Retrieves pointer to the internal image list that contains 
	// images displayed in the list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List, Returns the specified value.
	//		Returns a pointer to the object inline CImageList,or NULL if the call failed
	inline CImageList* GetImageList() { return &m_imageList; }


	// Removes all images displayed in the list box. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty Image List, .

	void EmptyImageList();


	//	Sets new image list as a source of images to be displayed in the 
	//	list box. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image List, Sets a specify value to current class CFOPImageListBox
	//		Returns a int type value.  
	// Parameters:
	//		pImageList---Image List, A pointer to the CImageList or NULL if the call failed.
	int SetImageList(CImageList* pImageList);

	// Adds new images to be displayed in the list box. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image List, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		pImageList---Image List, A pointer to the CImageList or NULL if the call failed.
	int AddImageList(CImageList* pImageList);
	

	// Adds one or more images or an icon to the internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		pbmImage---pbmImage, A pointer to the CBitmap or NULL if the call failed.  
	//		pbmMask---pbmMask, A pointer to the CBitmap or NULL if the call failed.
	int AddImage(CBitmap* pbmImage, CBitmap* pbmMask);

	// Adds one or more images or an icon to the internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		pbmImage---pbmImage, A pointer to the CBitmap or NULL if the call failed.  
	//		crMask---crMask, Specifies A 32-bit COLORREF value used as a color value.
	int AddImage(CBitmap* pbmImage, COLORREF crMask);

	// Adds one or more images or an icon to the internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	int AddImage(HICON hIcon);


	// Replaces an image in the internal image list with a new image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Image, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		pbmImage---pbmImage, A pointer to the CBitmap or NULL if the call failed.  
	//		pbmMask---pbmMask, A pointer to the CBitmap or NULL if the call failed.
	BOOL ReplaceImage(int nImage, CBitmap* pbmImage, CBitmap* pbmMask=NULL);

	// Replaces an image in the internal image list with a new image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Image, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	BOOL ReplaceImage(int nImage, HICON hIcon);

	// Removes an image from the list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Image, Call this function to remove a specify value from the specify object.
	//		Returns inline BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.
	inline BOOL RemoveImage(int nImage) { return DeleteString(nImage); }

	
	// Retrieves information about an image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Information, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		pImageInfo---Image Information, A pointer to the IMAGEINFO or NULL if the call failed.
	BOOL GetImageInfo(int nImage, IMAGEINFO* pImageInfo) const;


	//	Creates an icon based on an image and its related mask in the 
	//	internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Icon, Returns the specified value.
	//		Returns A HICON value (Object).  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.
	HICON GetIcon(int nImage);

	// Creates an icon of the selected image in the list box based on 
	// an image and its related mask in the internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Icon, Returns the specified value.
	//		Returns A HICON value (Object).
	HICON GetSelectedIcon();


	// Clears the current contents of the list box and populate it with 
	//	icons loaded from the specified executable file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icons From File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bSmallIcon---Small Icon, Specifies A Boolean value.
	BOOL LoadIconsFromFile(LPCTSTR lpszFileName=NULL, BOOL bSmallIcon=TRUE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPImageListBox)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	// --- In  :	
	// --- Out : 
	// --- Returns:	
	// --- Effect:	Destructs the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Image List Box, Destructor of class CFOPImageListBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPImageListBox();

protected:
	// Initializes the list box. Advanced overridable, can be used
	//	to initialize internal data in the derived classes. This
	//	function is called right after the control has been created 
	//	or subclassed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize Image List Box, Call InitializeImageListBox after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL InitializeImageListBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPImageListBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete String, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteString(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Reset Content, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnResetContent(WPARAM wParam, LPARAM lParam);

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// inernal image list that contains images that is displayed in the list box
 
	// List, This member is a collection of same-sized images.  
	CImageList m_imageList;

	// default width of images displayed in the list box
 
	// Orig Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOrigWidth;

	// default height of images displayed in the list box
 
	// Orig Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOrigHeight;

	// control's background color 
 
	// Background, This member sets A 32-bit value used as a color value.  
	COLORREF m_clrBackground;

	// control's Highlight color
 
	// Highlight, This member sets A 32-bit value used as a color value.  
	COLORREF m_clrHighlight;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPFLATCOMBOBOX_H__383858C9_8253_470A_89D9_EC9A5594D6DC__INCLUDED_)
