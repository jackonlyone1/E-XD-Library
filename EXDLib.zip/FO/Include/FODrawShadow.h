//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODRAWSHADOW_H__4856CB84_96D2_45F2_B639_545F9F57024E__INCLUDED_)
#define AFX_FODRAWSHADOW_H__4856CB84_96D2_45F2_B639_545F9F57024E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODrawShadow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFODrawShadow -- this is a helper class that designed for drawing shadow.

 
//===========================================================================
// Summary:
//      To use a CFODrawShadow object, just call the constructor.
//      F O Draw Shadow
//===========================================================================

class FO_EXT_CLASS CFODrawShadow
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Shadow, Constructs a CFODrawShadow object.
	//		Returns A  value (Object).
	CFODrawShadow();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Shadow, Destructor of class CFODrawShadow
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawShadow();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).
	// Restore dc.
	BOOL Restore(CDC & dc);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).
	// Draw
	BOOL Draw( CDC & dc );

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		rcWndArea---Window Area, Specifies A CRect type value.  
	//		nShadowSize---Shadow Size, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bEnableCapture---Enable Capture, Specifies A Boolean value.
	// Draw
	BOOL Draw(CDC & dc,const CRect & rcWndArea,UINT nShadowSize = 4,
		BOOL bEnableCapture = TRUE	);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy, Call this function to destroy an existing object.

	// Destroy.
	void Destroy();

protected:

	// Release win objects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Win Objects, .

	void ReleaseWinObjects();

	// Do over shadow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Over Shadow, Do a event. 
	// Parameters:
	//		nPercent---nPercent, Specifies A integer value.  
	//		nPosX---Position X, Specifies A integer value.  
	//		nPosY---Position Y, Specifies A integer value.
	void DoOverShadow(int nPercent,int nPosX,int nPosY);

	// Make image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Picture, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		dcMemory---dcMemory, Specifies a CDC & dcMemory object(Value).
	BOOL MakePicture(CDC & dc, CDC & dcMemory);

	// Do paint to lower.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint To Lower, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).
	BOOL DoPaintToLower(CDC & dc);

	// Do paint to high.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint To High, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).
	BOOL DoPaintToHigh(CDC & dc);

protected:

	// min brightness percents [0..100]
 
	// Minimize Percents, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nMinPercents;

	// max brightness percents [0..100]
 
	// Maximize Percents, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nMaxPercents;		

	// bitmap of right & bottom shadow parts to save/restore
 
	// Start, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap			m_bmpStart;	

	// Save bitmap.
 
	// End, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap			m_bmpEnd;

	// Helper dib surface.
 
	// Color Help, This member maintains a pointer to the object COLORREF.  
	COLORREF *		m_pColorHelp;

	// window are not including shadow
 
	// Window Area, This member sets a CRect value.  
	CRect			m_rcWndArea;		

	// basic area
 
	// Start Area, This member sets a CRect value.  
	CRect			m_rcStartArea;		

	// combined area
 
	// End Area, This member sets a CRect value.  
	CRect			m_rcEndArea;		

	// shadow size (in pixels)
 
	// Shadow Size, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nShadowSize;		

	
	// use photo bitmaps
 
	// Enable Capture, This member sets TRUE if it is right.  
	BOOL			m_bEnableCapture;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODRAWSHADOW_H__4856CB84_96D2_45F2_B639_545F9F57024E__INCLUDED_)
