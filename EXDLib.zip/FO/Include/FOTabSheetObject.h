//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOTabSheetObject.h: interface for the CFOTabSheetObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOTABSHEETOBJECT_H__CB8CC9E7_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
#define AFX_FOTABSHEETOBJECT_H__CB8CC9E7_FAA6_11D5_A4DF_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOTabPageModel.h"

 
//===========================================================================
// Summary:
//     The CFOTabSheetObject class derived from CObject
//      F O Tab Sheet Object
//===========================================================================

class FO_EXT_CLASS CFOTabSheetObject: public CObject
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Sheet Object, Constructs a CFOTabSheetObject object.
	//		Returns A  value (Object).
	CFOTabSheetObject();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Sheet Object, Destructor of class CFOTabSheetObject
	//		Returns A  value (Object).
	~CFOTabSheetObject();

protected:

	// Caption of page.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString     m_strCaption;

	// Specify selection.
 
	// Select, This member sets TRUE if it is right.  
	BOOL        m_bSelect;

	// Page wnd handle.
 
	// Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*		m_pWnd;

	// Specify menu handle.
 
	// Menu, This member specify HMENU object.  
	HMENU       m_hMenu;

	// Page model pointer.
 
	// Model, This member maintains a pointer to the object CFOTabPageModel.  
	CFOTabPageModel* m_pModel;

public:

	// Obtain the tab's label string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Label, Returns the specified value.
	//		Returns a CString type value.
	CString GetTabLabel() const				{ return m_strCaption; }

	// Change the tab's label string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Label, Sets a specify value to current class CFOTabSheetObject
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetTabLabel(const CString &str)	{ m_strCaption = str; }

	// Obtain the Select state flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const					{ return m_bSelect; }

	// Change the select state flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOTabSheetObject
	// Parameters:
	//		bSelect---bSelect, Specifies A Boolean value.
	void SetSelected(const BOOL bSelect)	{ m_bSelect = bSelect; }

	// Obtain the pointer of the wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *GetWnd() const					{ return m_pWnd; }

	// Change the pointer of the wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window, Sets a specify value to current class CFOTabSheetObject
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetWnd(CWnd *pWnd)					{ m_pWnd = pWnd; }

	// Obtain the Menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Handle, Returns the specified value.
	//		Returns A HMENU value (Object).
	HMENU GetMenuHandle() const				{ return m_hMenu; }

	// Change the menu handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Handle, Sets a specify value to current class CFOTabSheetObject
	// Parameters:
	//		hMenu---hMenu, Specifies a const HMENU hMenu object(Value).
	void SetMenuHandle(const HMENU hMenu)	{ m_hMenu = hMenu; }

	// Obtain the pointer of the datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Model, Returns the specified value.
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed
	CFOTabPageModel* GetTabModel() const		{ return m_pModel; }

	// Change the pointer of the datamodel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Model, Sets a specify value to current class CFOTabSheetObject
	// Parameters:
	//		pModel---pModel, A pointer to the CFOTabPageModel or NULL if the call failed.
	void SetTabModel(CFOTabPageModel* pModel)	{ m_pModel = pModel; }

public:

	// Specify if it use back color.
 
	// Back Color, This member sets TRUE if it is right.  
	BOOL		m_bBackColor;

	// Specify if it use  active color.
 
	// Active Color, This member sets TRUE if it is right.  
	BOOL		m_bActiveColor;

	// Width of page.
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nWidth;

	// Vert scrollbar info.
 
	// Information Vertical, This member specify SCROLLINFO object.  
	SCROLLINFO  sbInfoVert;

	// Horz scrollbar info.
 
	// Information Horizontal, This member specify SCROLLINFO object.  
	SCROLLINFO  sbInfoHorz;

	// Specify unactive color.
 
	// Un Active, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crUnActive;

	// Specify active color.
 
	// Active, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crActive;


	// Auto remove wnd handle.
 
	// Automatic Remove, This member sets TRUE if it is right.  
	BOOL        m_bAutoRemove;

};

#endif // !defined(AFX_FOTABSHEETOBJECT_H__CB8CC9E7_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
