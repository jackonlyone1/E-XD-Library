//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPPICKERBASEWND_H__6D0596E7_7702_40A1_92E6_0368B1475344__INCLUDED_)
#define AFX_FOPPICKERBASEWND_H__6D0596E7_7702_40A1_92E6_0368B1475344__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPPickerBaseWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPPickerBaseWnd window
#include "FOPDrawPickerBase.h"

 
//===========================================================================
// Summary:
//     The FOPPickerBaseWnd class derived from CWnd
//      O P Picker Base Window
//===========================================================================

class FO_EXT_CLASS FOPPickerBaseWnd : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPPickerBaseWnd---O P Picker Base Window, Specifies a FOPPickerBaseWnd object(Value).
	DECLARE_DYNCREATE(FOPPickerBaseWnd)

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Picker Base Window, Constructs a FOPPickerBaseWnd object.
	//		Returns A  value (Object).
	FOPPickerBaseWnd();
	
	// Actions type.
	enum ActionType 
	{
		FOPMOUSEMOVE, 
		FOPKEYMOVE, 
		FOPSELECTFINISH
	};

	// Popup state.
	enum FOPPopupState
	{
		PopupNone,
		PopupCreated,
		PopupCancelled
	};

	
protected:

	// Initial size of the tip window.
 
	// Window, This member sets a CRect value.  
	CRect				m_rcWindow;

	// Initial size of the tip window shadow.
 
	// Shadow, This member sets a CRect value.  
	CRect				m_rcShadow;

	// data
 
	// Tool Tip, This member specify CToolTipCtrl object.  
    CToolTipCtrl		ToolTip;

	// Dither brush.
 
	// Dither Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush				DitherBrush;

	// Grey brush.
 
	// Grey Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush				GreyBrush;

	// array of rectangles for all well elements
 
	// Well Position, This member maintains a pointer to the object CRect.  
	CRect*				arWellPosition;		
	
	// Rectangles.
 
	// Rects, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nRects;


	// count of different items cached
 
	// Header Bars, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nHeaderBars;	
	
	// main group wells.
 
	// Wells Main Group, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nWellsMainGroup;

	// Extra group wells.
 
	// Wells Extra Group, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nWellsExtraGroup;

	// Buttons.
 
	// Buttons, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nButtons;

	// gap at edge of control
 
	// Edge Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint				m_ptEdgeSize;	
	
	// size of well
 
	// Cell Default, This member sets a CSize value.  
	CSize				m_szCellDefault;	
	
	// wells per row
 
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCols;	
	
	// Edge rectangle.
 
	// Edge, This member sets a CRect value.  
	CRect				m_rcEdge;	

	// where to put separator between wells and buttons
 
	// Edge, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_flgEdge;

	// indicates last selected well / headerbar / button (-1 == none)
 
	// Selected Well, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nSelectedWell;		

	// indicates presently selected well / headerbar / button (-1 == none)
 
	// Over Which Well, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nOverWhichWell;		

	// indicates well / headerbar / button mouse landed on (-1 == none)
 
	// Mouse Down Well, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nMouseDownWell;	
	
	// whether mouse up or down
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL 				m_bMouseDown;		
	
	// Key down or not.
 
	// Key Down, This member sets TRUE if it is right.  
	BOOL 				m_bKeyDown;

	// Focue or not
 
	// Focused, This member sets TRUE if it is right.  
	BOOL 				m_bFocused;

	// Dlg control id.
 
	// Dialog  Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDlgCtrlId;

	// flag describing both state and type of control
 
	// Popup State, This member specify FOPPopupState object.  
	FOPPopupState		PopupState;			

	// pointer to object providing behaviour and persistenc for the control
 
	// Draw Impl, This member maintains a pointer to the object FOPDrawPickerBase.  
	FOPDrawPickerBase*	DrawImpl;			

	// Disable bitmap
 
	// Disabled, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap				m_bmDisabled;

	// Sub list drop down wnd.
 
	// Drop Child Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*				m_pDropSubWnd;

protected:

	// assessory Drawing functions: NB. These are NOT virtual functions
	// new UI functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Disabled Bitmap, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		memDC---D C, Specifies a CDC& memDC object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawDisabledBitmap(CDC& dc, CDC& memDC, CRect& rect);

	// Draw selected state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Selected, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawSelected(CDC& dc, CRect& rect);

	// Draw depressed state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Depressed, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawDepressed(CDC& dc, CRect& rect);

	// Draw extrude.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extrude, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawExtrude(CDC& dc, CRect& rect);

	// for drawing sunken wells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Sunken Over, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawSunkenOver(CDC& dc, CRect& rect);

	// Draw sunken
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Sunken, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
	void				DrawSunken(CDC& dc, CRect& rect);

	// Get disabled bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Disabled Bitmap, Returns the specified value.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.
	void				GetDisabledBitmap(CDC& dc, const CRect& rcRect);

	// Draw focus rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Focus Rectangle, Draws current object to the specify device.

	void				DrawFocusRect();

	// Draw buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Buttons, Draws current object to the specify device.
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.
	void				DrawButtons(CDC& DC, const CRect& rcRect);

	// This member function will draw a shadow rect to the device context
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Shadow Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rectect---Specifies A CRect type value.
	void				DrawShadowRect(CDC *pDC,const CRect& rectect);

	// Draw background
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Background, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		clientRect---clientRect, Specifies A CRect type value.
	void				DrawBackground(CDC& dc, CRect& clientRect);

	// Draw all wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw All Wells, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.
	void				DrawAllWells(CDC& dc, const CRect& rcRect);

	// Draw well states.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Well States, Draws current object to the specify device.
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.
	void				DrawWellStates(CDC& DC, const CRect& rcRect);

	// Draw well grey outlines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Well Grey Outlines, Draws current object to the specify device.
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.  
	//		GreyBrush---Grey Brush, Specifies a CBrush& GreyBrush object(Value).
	void				DrawWellGreyOutlines(CDC& DC, const CRect& rcRect, CBrush& GreyBrush);

	// Draw well faces.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Well Faces, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rcRect---rcRect, Specifies A CRect type value.
	void				DrawWellFaces(CDC& dc, const CRect& rcRect);

	// Create dither brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Dither Brush, You construct a FOPPickerBaseWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HBRUSH value (Object).  
	// Parameters:
	//		cr1---Specifies A 32-bit COLORREF value used as a color value.  
	//		cr2---Specifies A 32-bit COLORREF value used as a color value.
	HBRUSH				CreateDitherBrush(COLORREF cr1, COLORREF cr2);

	// Has focus rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Focus Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL 		HasFocusRectangle() const;

	// functions used during creation
	//helper func for CreateToolTips()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Tool Tip Add Tool, .
	// Parameters:
	//		&text---Specifies A CString type value.  
	//		iIndex---iIndex, Specifies A integer value.
	void				ToolTipAddTool(const CString &text, int iIndex);

	// Calculate size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Size, .
	//		Returns a CRect type value.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		useDialogBaseUnits---Dialog Base Units, Specifies A Boolean value.
	CRect				CalculateSize(CWnd* pParentWnd, int x, int y, BOOL  useDialogBaseUnits);

	// Init system colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial System Colors, Call InitSysColors after creating a new object.

	void				InitSysColors();

	// Set draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Impl, Sets a specify value to current class FOPPickerBaseWnd
	// Parameters:
	//		d---A pointer to the FOPDrawPickerBase or NULL if the call failed.
	void				SetDrawImpl(FOPDrawPickerBase* d)	{	DrawImpl = d; }

	// Get class style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Class Style, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT		GetClassStyle() const;

	// Cache items count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cache Items Count, .

	void				CacheItemsCount();

	// functions for well geometry
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Well Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	int					GetWellIndex(int x, int y) const;

	// Get max cols
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Maximize, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		row---Specifies A integer value.
	int					GetColMax(int row) const;

	// Get max rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Maximize, Returns the specified value.
	//		Returns a int type value.
	int					GetRowMax() const;

	// Get main group rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Rows, Returns the specified value.
	//		Returns a int type value.
	int					GetMainGroupRows()			const	{	return((m_nWellsMainGroup - 1 + m_nCols) / m_nCols);			}

	// Get extra group rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Rows, Returns the specified value.
	//		Returns a int type value.
	int					GetExtraGroupRows()			const	{	return((m_nWellsExtraGroup - 1 + m_nCols) / m_nCols);			}

	// Is  button well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Well Button, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	BOOL 				IsWellButton(int iIndex)	const	{	return iIndex >= m_nHeaderBars + m_nWellsMainGroup + m_nWellsExtraGroup;	}

	// Is headerbar well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Well Header Bar, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	BOOL 				IsWellHeaderBar(int iIndex)	const	{	return iIndex < m_nHeaderBars;				}

	// Get main group wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getm_n Wells Main Group, Returns the specified value.
	//		Returns a int type value.
	int					Getm_nWellsMainGroup()		const	{	return(m_nWellsMainGroup);				}

	// Get extra group wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getm_n Wells Extra Group, Returns the specified value.
	//		Returns a int type value.
	int					Getm_nWellsExtraGroup()		const	{	return(m_nWellsExtraGroup);				}

	// Get headerbars
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getm_n Header Bars, Returns the specified value.
	//		Returns a int type value.
	int					Getm_nHeaderBars()			const	{	return(m_nHeaderBars);					}

	// Get buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getm_n Buttons, Returns the specified value.
	//		Returns a int type value.
	int					Getm_nButtons()				const	{	return(m_nButtons);						}

	// Get over which well.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Over Which Well, Returns the specified value.
	// Parameters:
	//		x---A pointer to the int or NULL if the call failed.  
	//		y---A pointer to the int or NULL if the call failed.
	void				GetOverWhichWell(int* x, int* y);

	// Get main group bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Bounding Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect				GetMainGroupBoundingRect() const;

	// Get extra group bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Bounding Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect				GetExtraGroupBoundingRect() const;

	// UI functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Selection Change, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		newOverWhichWell---Over Which Well, Specifies A integer value.  
	//		type---Specifies a ActionType type object(Value).
	BOOL 				HandleSelectionChange(int newOverWhichWell, ActionType type);

	// Sliding from button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ignore Sliding From Button, .
	//		Returns a int type value.  
	// Parameters:
	//		newOverWhichWell---Over Which Well, Specifies A integer value.
	int					IgnoreSlidingFromButton(int newOverWhichWell);

	// Hit test rectangles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Rects, Hit test on this object.
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	int					HitTestRects(const CPoint& point);

	// Handle button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Button Up, .
	// Parameters:
	//		newOverWhichWell---Over Which Well, Specifies A integer value.
	void				HandleButtonUp(int newOverWhichWell);

	// Handle button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Button Down, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void				HandleButtonDown(const CPoint& point);

	// Pre translate messages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	BOOL				PreTranslateMessage(MSG* pMsg);

public:
// inlines
	// Is mouse tracking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse Tracking, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL  				IsMouseTracking()	const	{	return(DrawImpl->GetDefMouseTracking() && m_bMouseDown); }

	// Is popup created.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Popup Created, Determines if the given value is correct or exist.
	//		Returns A FOPPopupState value (Object).
	FOPPopupState		IsPopupCreated()	const	{	return PopupState;									}

	// Is popup
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Popup, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 				IsPopup()			const	{	return PopupState == PopupCreated;					}

	// Has focus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Focus, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 				HasFocus()			const	{	return m_bFocused;										}

	// Get dlg ctrl ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dialog  Id, Returns the specified value.
	//		Returns a int type value.
	int					GetDlgCtrlId()		const	{	return m_nDlgCtrlId;									}

	// Get cell size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&		GetCellSize()		const	{	return m_szCellDefault;								}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns a pointer to the object FOPDrawPickerBase,or NULL if the call failed
	FOPDrawPickerBase* 	GetDrawImpl()		const	{	return DrawImpl;									}

	// Create tool tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Tool Tips, You construct a FOPPickerBaseWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		CreateToolTips();

	// Recreate disabled bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Recreate Disabled Bitmap, .

	void				RecreateDisabledBitmap()	{	m_bmDisabled.DeleteObject();						}

	// Do realize palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Realize Palette, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		foreground---Specifies A Boolean value.
	int					DoRealizePalette(BOOL  foreground);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a FOPPickerBaseWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		tl---Specifies A CPoint type value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		imp---A pointer to the FOPDrawPickerBase or NULL if the call failed.  
	//		useDialogBaseUnits---Dialog Base Units, Specifies A Boolean value.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// create function for e.g. dialog control or for placing in window
	virtual BOOL		Create(DWORD dwStyle,
								const CPoint& tl,						// Top left corner
								CWnd* pParentWnd,
								UINT nID,
								FOPDrawPickerBase* imp,
								BOOL  useDialogBaseUnits = FALSE,
								CCreateContext* pContext = NULL);

	// create function for floating popup / dropdown window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Popup, You construct a FOPPickerBaseWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		buttonRect---buttonRect, Specifies A CRect type value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		imp---A pointer to the FOPDrawPickerBase or NULL if the call failed.  
	//		dropHoriz---dropHoriz, Specifies A Boolean value.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	virtual BOOL		CreatePopup(DWORD dwStyle,
								CRect& buttonRect,
								CWnd* pParentWnd,
								UINT nID,
								FOPDrawPickerBase* imp,
								BOOL  dropHoriz = FALSE,
								CCreateContext* pContext = NULL);

	// calls CreatePopup and does not return from private message loop until control is dismissed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Modal Popup, Calls a modal dialog box and returns when done.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		buttonRect---buttonRect, Specifies A CRect type value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		imp---A pointer to the FOPDrawPickerBase or NULL if the call failed.  
	//		dropHoriz---dropHoriz, Specifies A Boolean value.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	virtual BOOL		DoModalPopup(DWORD dwStyle,
								CRect& buttonRect,
								CWnd* pParentWnd,
								UINT nID,
								FOPDrawPickerBase* imp,
 								BOOL  dropHoriz = FALSE,
 								CCreateContext* pContext = NULL);

	// Handle cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Cancel, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		HandleCancel();

	// Set selected well.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected Well, Sets a specify value to current class FOPPickerBaseWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newSelectedWell---Selected Well, Specifies A integer value.
	virtual void		SetSelectedWell(int newSelectedWell);

	// Calculate well rectangles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Well Rects, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize		CalculateWellRects();

protected:



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPPickerBaseWnd)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Post Nc Destroy, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PostNcDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Float Status, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	LRESULT OnFloatStatus(WPARAM wParam, LPARAM);
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Picker Base Window, Destructor of class FOPPickerBaseWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPPickerBaseWnd();

// Generated message map functions
protected:
	//{{AFX_MSG(FOPPickerBaseWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query New Palette, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL OnQueryNewPalette();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Palette Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pFocusWnd---Focus Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Display Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnDisplayChange(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void OnEnable( BOOL bEnable );
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

// Sub colors to grey.
HBITMAP FOSubColorsToGrey(CDC& dc, const CSize& sz, int cntCell, COLORREF* pCol, int cnt);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPPICKERBASEWND_H__6D0596E7_7702_40A1_92E6_0368B1475344__INCLUDED_)
