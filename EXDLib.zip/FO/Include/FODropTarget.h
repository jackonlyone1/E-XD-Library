//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODropTarget.h: interface for the CFODropTarget class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODROPTARGET_H__971B27D7_F28B_11DD_A434_525400EA266C__INCLUDED_)
#define AFX_FODROPTARGET_H__971B27D7_F28B_11DD_A434_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXOLE_H__
#include <afxole.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// CFODropTarget action target

// Deafault auto scroll move steps.
const int nDefaultOffsetPos			= 20;

// Default auto scroll delay time.
const int nAutoScrollDelay			= 80;

// Auto scroll timer id
#define nDeafultAutoScrollItmerID	  9092

/////////////////////////////////////////////////////////////////////////////////
//
// CFODropTarget -- ole drag - target class.
/////////////////////////////////////////////////////////////////////////////////

class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFODropTarget class derived from COleDropTarget
//      F O Drop Target
//===========================================================================

class FO_EXT_CLASS CFODropTarget : public COleDropTarget
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Target, Constructs a CFODropTarget object.
	//		Returns A  value (Object).
	CFODropTarget();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Target, Destructor of class CFODropTarget
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropTarget();

// Attributes
public:

	// The Pointer to  Owner View
 
	// Canvas Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore*		m_pCanvasCore;

	// Timer started.
 
	// Timer Start, This member sets TRUE if it is right.  
	BOOL				m_bTimerStart;

	// Timer should stop.
 
	// Timer Stop, This member sets TRUE if it is right.  
	BOOL				m_bTimerStop;

// Operations
public:

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register, Write a specify value to registry.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pOwner---*pOwner, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	// Register wnd.
	BOOL Register (CFOPCanvasCore *pOwner);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODropTarget)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Enter, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragEnter(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Leave, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void OnDragLeave(CWnd* pWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Over, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragOver(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drop Ex, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropDefault---dropDefault, Specifies a DROPEFFECT dropDefault object(Value).  
	//		dropList---dropList, Specifies a DROPEFFECT dropList object(Value).  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDropEx(CWnd* pWnd, COleDataObject* pDataObject,
		DROPEFFECT dropDefault, DROPEFFECT dropList, CPoint point);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CFODropTarget)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOToolBoxDropTarget -- drag - drop target object for toolbox window.
/////////////////////////////////////////////////////////////////////////////////

class CFOToolBoxPageWnd;
 
//===========================================================================
// Summary:
//     The CFOToolBoxDropTarget class derived from COleDropTarget
//      F O Tool Box Drop Target
//===========================================================================

class FO_EXT_CLASS CFOToolBoxDropTarget : public COleDropTarget
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Drop Target, Constructs a CFOToolBoxDropTarget object.
	//		Returns A  value (Object).
	CFOToolBoxDropTarget();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Box Drop Target, Destructor of class CFOToolBoxDropTarget
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolBoxDropTarget();

// Attributes
public:

	// The Pointer to  Owner View
 
	// Canvas Core, This member maintains a pointer to the object CFOToolBoxPageWnd.  
	CFOToolBoxPageWnd*	m_pCanvasCore;

// Operations
public:

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register, Write a specify value to registry.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pOwner---*pOwner, A pointer to the CFOToolBoxPageWnd  or NULL if the call failed.
	// Register wnd.
	BOOL Register (CFOToolBoxPageWnd *pOwner);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOToolBoxDropTarget)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Enter, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragEnter(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Leave, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void OnDragLeave(CWnd* pWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Over, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragOver(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drop Ex, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropDefault---dropDefault, Specifies a DROPEFFECT dropDefault object(Value).  
	//		dropList---dropList, Specifies a DROPEFFECT dropList object(Value).  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDropEx(CWnd* pWnd, COleDataObject* pDataObject,
		DROPEFFECT dropDefault, DROPEFFECT dropList, CPoint point);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CFOToolBoxDropTarget)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_FODROPTARGET_H__971B27D7_F28B_11DD_A434_525400EA266C__INCLUDED_)
