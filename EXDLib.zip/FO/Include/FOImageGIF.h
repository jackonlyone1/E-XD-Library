//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEGIF_H__1888A1AC_D637_440B_9F67_CEC72DE1B389__INCLUDED_)
#define AFX_FOIMAGEGIF_H__1888A1AC_D637_440B_9F67_CEC72DE1B389__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageGIF.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageGIF window

#include "FOBitmap.h"

enum FOPDisposal
{
	FOP_DISPOSE_NOT,
	FOP_DISPOSE_BACK,
	FOP_DISPOSE_FULL,
	FOP_DISPOSE_PREVIOUS 
};

/////////////////////////////////////////////////////////////////////////////
// Gif Frame

 
//===========================================================================
// Summary:
//      To use a CFOGifFrame object, just call the constructor.
//      F O Gif Frame
//===========================================================================

class FO_EXT_CLASS CFOGifFrame
{
protected:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Gif Frame, Constructs a CFOGifFrame object.
	//		Returns A  value (Object).
	CFOGifFrame();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Gif Frame, Constructs a CFOGifFrame object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&src---Specifies a const CFOGifFrame &src object(Value).
	CFOGifFrame( const CFOGifFrame &src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOGifFrame &operator value (Object).  
	// Parameters:
	//		&src---Specifies a const CFOGifFrame &src object(Value).
	// Operator =.
	CFOGifFrame &operator =( const CFOGifFrame &src);

public:
	// Constructor.
	// pImage -- pointer of CFOBitmap object.
	// nTime -- timer time.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Gif Frame, Constructs a CFOGifFrame object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pImage---*pImage, A pointer to the CFOBitmap  or NULL if the call failed.  
	//		nTime---nTime, Specifies A integer value.  
	//		nLeft---nLeft, Specifies A integer value.  
	//		nTop---nTop, Specifies A integer value.  
	//		_eDisposal---_eDisposal, Specifies a FOPDisposal _eDisposal = FOP_DISPOSE_NOT object(Value).  
	//		bTransparent---bTransparent, Specifies A Boolean value.
	CFOGifFrame( CFOBitmap *pImage, int nTime,int nLeft,int nTop,
		FOPDisposal _eDisposal = FOP_DISPOSE_NOT,
		BOOL bTransparent = FALSE);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Gif Frame, Destructor of class CFOGifFrame
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOGifFrame();

	//	Obtain the image pointer of the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image, Returns the specified value.
	//		Returns a pointer to the object const CFOBitmap ,or NULL if the call failed
	const CFOBitmap *GetImage() const	{ return m_pSaveImage; }

	// Obtain the image pointer of the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	CFOBitmap *GetImage()				{ return m_pSaveImage; }

	// Change image of the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		*pBmp---*pBmp, A pointer to the CFOBitmap  or NULL if the call failed.
	void SetImage(CFOBitmap *pBmp)		{ m_pSaveImage = pBmp; }

	//	Get the time this frame to showing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Time, Returns the specified value.
	//		Returns a int type value.
	int GetTime() const					{ return m_nTimer; }

	// Change the time of the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Time, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		&nTime---&nTime, Specifies A integer value.
	void SetTime(const int &nTime)		{ m_nTimer = nTime; }


	// Get left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left, Returns the specified value.
	//		Returns a int type value.
	int GetLeft() const					{ return m_nLeft; }

	// Set left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		&nLeft---&nLeft, Specifies A integer value.
	void SetLeft(const int &nLeft)		{ m_nLeft = nLeft; }

	// Get top
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top, Returns the specified value.
	//		Returns a int type value.
	int GetTop() const					{ return m_nTop; }

	// Set top
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		&nTop---&nTop, Specifies A integer value.
	void SetTop(const int &nTop)		{ m_nTop = nTop; }

	// Get disposal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Disposal, Returns the specified value.
	//		Returns A FOPDisposal value (Object).
	FOPDisposal GetDisposal() const		{ return eDisposal; }

	// Set disposal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Disposal, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		&disposal---Specifies a const FOPDisposal &disposal object(Value).
	void SetDisposal(const FOPDisposal &disposal) { eDisposal = disposal; }

	// Get transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetTransparent() const			{ return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOGifFrame
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void SetTransparent(const BOOL &bTransparent) { m_bTransparent = bTransparent; }

protected:

	// Pointer of the image of the frame.
 
	// Save Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *		m_pSaveImage;

	// Time.
 
	// Timer, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTimer;

	// Left
 
	// Left, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLeft;

	// Top.
 
	// Top, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTop;

	// Disposal
 
	// Disposal, This member specify FOPDisposal object.  
	FOPDisposal		eDisposal;

	// Transparent.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

};


/////////////////////////////////////////////////////////////////////////////
// CFOImageGIF class

class CFOGifFrame;
typedef CFOArray< CFOGifFrame*> CFOGifFrameArray;
 
//===========================================================================
// Summary:
//     The CFODrawImageGIF class derived from CFODrawImage
//      F O Draw Image G I F
//===========================================================================

class FO_EXT_CLASS CFODrawImageGIF : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImageGIF---F O Draw Image G I F, Specifies a E-XD++ CFODrawImageGIF object (Value).
	DECLARE_SERIAL(CFODrawImageGIF)

public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image G I F, Constructs a CFODrawImageGIF object.
	//		Returns A  value (Object).
	CFODrawImageGIF();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image G I F, Destructor of class CFODrawImageGIF
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImageGIF();

public:

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap();

	// Clear all image data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Decode, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).  
	//		&arFrames---&arFrames, Specifies a E-XD++ CFOGifFrameArray &arFrames object (Value).
	// Decode gif file format.
	bool Decode( CFODataReadBase &reader,CFOGifFrameArray &arFrames);

	// Obtain the bitmap of the frame
	// nFrame -- number of the frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Image, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed  
	// Parameters:
	//		nFrame---nFrame, Specifies A integer value.
	virtual CFOBitmap *GetFrameImage( int nFrame );

	//	Get the number of frames available.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetFrameCount() const;

	//	Get the number of milliseconds a frame shoudl be displayed for.
	// nFrame -- number of the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Time, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetFrameTime( UINT nFrame ) const;

	// Get left of the image.
	// nFrame -- number of the frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetLeft( UINT nFrame ) const;

	// Get top of the image.
	// nFrame -- number of the frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetTop( UINT nFrame ) const;

	// Get golbals size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Image Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetTotalImageSize() const { return maGlobalSize; }

	// Is current gif transparent or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTransparent() const;

public:

	// Save document.
	// lpszPathName -- full path file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID,LPCTSTR pcszResourceType);

	// load icon file
	// strFileName -- file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);


	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImageGIF &target object(Value).
	virtual BOOL operator==(const CFODrawImageGIF &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);

protected:

	// Array of the frames of the gif image.
 
	// Frames, This member specify E-XD++ CFOGifFrameArray object.  
	CFOGifFrameArray	m_arFrames;

	// Get size of globals.
 
	// Global Size, This member sets a CSize value.  
	CSize				maGlobalSize;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEGIF_H__1888A1AC_D637_440B_9F67_CEC72DE1B389__INCLUDED_)
