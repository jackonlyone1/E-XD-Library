//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBulletTypeControl.h: interface for the CFOBulletTypeControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBULLETTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FOBULLETTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

   // include header file
#include "FOBulletTypeCellObj.h"
#include "FOGlobals.h"

// Define Total  of  Arrow Type CELLS
#define FO_TOTAL_BULLETTYPE_CELLS		8

// Arrow type message.
#define WM_FO_SELECTBULLETTYPEOK				WM_USER+270 // Select arrow ok.
#define WM_FO_SELECTBULLETTYPECANCEL			WM_USER+271 // Select arrow cancel.
#define WM_FO_SELECTBULLETTYPECUSTOM			WM_USER+272 // Select arrow custom.
#define WM_FO_SELECTBULLETTYPECHANGE			WM_USER+273 // Select arrow change.

 
//===========================================================================
// Summary:
//     The CFOBulletTypeControl class derived from CObject
//      F O Bullet Type 
//===========================================================================

class FO_EXT_CLASS CFOBulletTypeControl : public CObject
{
protected:

	// DECLARE SERIA CLASS
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBulletTypeControl---F O Bullet Type , Specifies a E-XD++ CFOBulletTypeControl object (Value).
	DECLARE_SERIAL(CFOBulletTypeControl);
public:
	
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bullet Type , Constructs a CFOBulletTypeControl object.
	//		Returns A  value (Object).
	CFOBulletTypeControl();
    
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bullet Type , Destructor of class CFOBulletTypeControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBulletTypeControl();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBulletTypeControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		nDefaultType---Default Type, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bPopup---bPopup, Specifies A Boolean value.
	// Creates the shape and initializes the data members.
	virtual void Create(CWnd *pWnd,int nDefaultType,CRect &rcPos,BOOL bPopup = FALSE);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize the data to file
	virtual void Serialize(CArchive &ar);
	
	// Initialize control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial , Call InitControl after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitControl();

	// Adjust Cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Cells, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual void AdjustCells(CRect rcPos);
	
	// Compute Cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Cells, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ComputeCells();

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);
	
	// Update All Objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateAll();

	// Get Arrow Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bullet Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBulletType () const				{	return m_nCurBulletType; }

	// Set Arrow Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bullet Type, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void		SetBulletType(int nType);

	// Get Old Cell Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect		GetOldCellRect();
	
	// Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBulletTypeCellObj,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFOBulletTypeCellObj* HitTest(CPoint point);
	
	// Judge whether popup style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Popup Style, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPopupStyle() const		{ return m_bPopup; }
	
	// Set popup style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Popup Style, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&bPopup---&bPopup, Specifies A Boolean value.
	void		SetPopupStyle(const BOOL &bPopup)	{ m_bPopup = bPopup; }
	
	// Define for WM_TFC_SELECTOK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectOK(WPARAM wParam, LPARAM lParam);
	
	// Define for WM_TFC_SELECTCANCEL message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectCancel(WPARAM wParam, LPARAM lParam);
	
protected:
	
	// Member variable ,a array of Arrow Type of CELLS
 
	// Cells[ F O_ T O T A L_ B U L L E T T Y P E_ C E L L S], This member specify E-XD++ CFOBulletTypeCellObj object.  
	CFOBulletTypeCellObj m_crCells[FO_TOTAL_BULLETTYPE_CELLS];
	
public:
	// virtual void Serialize(CArchive &ar);

	// Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get the pointer to file lpszFileName
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release File 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Set wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetWnd(CWnd *pWnd)					{ m_pParent = pWnd; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	// Invalidates this gadget.
	void Invalidate(BOOL bRedraw = FALSE);
	
	// Update the given rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	void InvalRect(CRect rcPos);
	
	// Capture the mouse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Capture Mouse, .
	// Parameters:
	//		bCapture---bCapture, Specifies A Boolean value.
	void CaptureMouse(BOOL bCapture);
	
	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnRButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();
	
	// Get rectangle of position 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Panel Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetPanelRect() const						{ return m_rcPosition; }

	// Set rectangle of position 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Panel Rectangle, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void  SetPanelRect(const CRect &rc)				{ m_rcPosition = rc; }
	
	// Set Custom Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Text, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void  SetCustomText(const CString &strText )	{ strCustom = strText; }
	
	// Get Custom Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Custom Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetCustomText() const				{ return strCustom; }
	
	// Set Custom Bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Bar, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&bCustom---&bCustom, Specifies A Boolean value.
	void SetCustomBar(const BOOL &bCustom);

	// et MainBorder Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Border Size, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetMainBorderSize(const int &nBorder);

	// Get MainBorder Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Border Size, Returns the specified value.
	//		Returns a int type value.
	int  GetMainBorderSize() const				{ return nMainBorderSize; }

	// Set CellBorder Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder);

	// Get CellBorder Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Border Size, Returns the specified value.
	//		Returns a int type value.
	int GetCellBorderSize() const				{ return nCellBorderSize; }

    // Set Border Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Type, Sets a specify value to current class CFOBulletTypeControl
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBorderType(const UINT &nType)		{ nBorderType = nType; }

    // Get Border Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetBorderType() const					{ return nBorderType; }

	// Update Custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Custom, Call this member function to update the object.

	void UpdateCustom();

public:
	
	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// Draw Custom 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bHasColor---Has Color, Specifies A Boolean value.
	virtual void OnCustomDraw(CDC *pDC,BOOL bHasColor);
	
    // Draw  Custom Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnCustomDrawSelect(CDC *pDC);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
    // Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);
	
protected:
	
	// Member Variable
	// The rectangle of cells
 
	// Cells, This member sets a CRect value.  
	CRect				rcCells;
	
	// The rectangle of Position
 
	// Position, This member sets a CRect value.  
	CRect				m_rcPosition;
	
	// The rectangle of Custom
 
	// Custom, This member sets a CRect value.  
	CRect				rcCustom;
	
	// The rectangle of Custom saved 
 
	// Custom Save, This member sets a CRect value.  
	CRect				rcCustomSave;
	
	// The type of current arrow
 
	// Current Bullet Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCurBulletType;
	
	//  The pointer to parent window
 
	// Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*				m_pParent;
	
	// The style of popup
 
	// Popup, This member sets TRUE if it is right.  
	BOOL				m_bPopup;
	
	// Whether the custom selected
 
	// Custom Select, This member sets TRUE if it is right.  
	BOOL				m_bCustomSelect;
	
	// The string of custom
 
	// Custom, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				strCustom;

	// Whether Has CustomBar 
 
	// Has Custom Bar, This member sets TRUE if it is right.  
	BOOL				bHasCustomBar;

	// The size of MainBorder
 
	// Main Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nMainBorderSize;

	// The size of CellBorder
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nCellBorderSize;

	// The type of border
 
	// Border Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				nBorderType;

	// The list pf image
 
	// Image, This member is a collection of same-sized images.  
	CImageList			*m_pImage;

	// Rows
 
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nRows;

	// Columns
 
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCols;

};

//Define type CTypedPtrList
typedef CTypedPtrList<CObList, CFOBulletTypeControl*> CFOBulletTypeControlList;

#endif // !defined(AFX_FOBULLETTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_)
