//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPARCLINKSHAPE_H__99193BC3_FEAD_48C8_A5A1_A3CD028A3726__INCLUDED_)
#define FO_FOPARCLINKSHAPE_H__99193BC3_FEAD_48C8_A5A1_A3CD028A3726__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------
#include "FOPExtBezierLinkShape.h"

///////////////////////////////////////////////////////////////////////////////////
// CFOPArcLinkShape -- Arc like link line, ID: FOP_ARC_LINK_SHAPE 250

 
//===========================================================================
// Summary:
//     The CFOPArcLinkShape class derived from CFOPExtBezierLinkShape
//      F O P Arc Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPArcLinkShape : public CFOPExtBezierLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPArcLinkShape---F O P Arc Link Shape, Specifies a E-XD++ CFOPArcLinkShape object (Value).
	DECLARE_SERIAL(CFOPArcLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Arc Link Shape, Constructs a CFOPArcLinkShape object.
	//		Returns A  value (Object).
	CFOPArcLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Arc Link Shape, Constructs a CFOPArcLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPArcLinkShape& src object(Value).
	CFOPArcLinkShape(const CFOPArcLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Arc Link Shape, Destructor of class CFOPArcLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPArcLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPArcLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the arc link shape from points.
	// ptArray -- array of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPArcLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the arc link shape from points.
	// pptPoints -- points.
	// nCount -- count of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPArcLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPArcLinkShape& src object(Value).
	CFOPArcLinkShape& operator=(const CFOPArcLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	//-----------------------------------------------------------------------
	// Summary:
	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
public:

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re layout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Re layout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Get distance from anchor to line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetDistance() const;

	// Get distance from tracker anchor to tracker line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetTrackDistance();

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

};


///////////////////////////////////////////////////////////////////
// CFOPVertDynamicLinkShape -- Vertical Dynamic link line, ID: FO_VERT_DYNAMIC_LINK_SHAPE 259

 
//===========================================================================
// Summary:
//     The CFOPVertDynamicLinkShape class derived from CFOPExtBezierLinkShape
//      F O P Vertical Dynamic Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPVertDynamicLinkShape : public CFOPExtBezierLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPVertDynamicLinkShape---F O P Vertical Dynamic Link Shape, Specifies a E-XD++ CFOPVertDynamicLinkShape object (Value).
	DECLARE_SERIAL(CFOPVertDynamicLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Vertical Dynamic Link Shape, Constructs a CFOPVertDynamicLinkShape object.
	//		Returns A  value (Object).
	CFOPVertDynamicLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Vertical Dynamic Link Shape, Constructs a CFOPVertDynamicLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPVertDynamicLinkShape& src object(Value).
	CFOPVertDynamicLinkShape(const CFOPVertDynamicLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Vertical Dynamic Link Shape, Destructor of class CFOPVertDynamicLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPVertDynamicLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPVertDynamicLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the arc link shape from points.
	// ptArray -- array of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPVertDynamicLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the arc link shape from points.
	// pptPoints -- points.
	// nCount -- count of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPVertDynamicLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPVertDynamicLinkShape& src object(Value).
	CFOPVertDynamicLinkShape& operator=(const CFOPVertDynamicLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re layout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Re layout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Get distance from anchor to line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetDistance() const;

	// Get distance from tracker anchor to tracker line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetTrackDistance();

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

};


///////////////////////////////////////////////////////////////////
// CFOPHorzDynamicLinkShape -- Horizontal Dynamic link line, 
//					ID: FO_HORZ_DYNAMIC_LINK_SHAPE 260

 
//===========================================================================
// Summary:
//     The CFOPHorzDynamicLinkShape class derived from CFOPExtBezierLinkShape
//      F O P Horizontal Dynamic Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPHorzDynamicLinkShape : public CFOPExtBezierLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHorzDynamicLinkShape---F O P Horizontal Dynamic Link Shape, Specifies a E-XD++ CFOPHorzDynamicLinkShape object (Value).
	DECLARE_SERIAL(CFOPHorzDynamicLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Horizontal Dynamic Link Shape, Constructs a CFOPHorzDynamicLinkShape object.
	//		Returns A  value (Object).
	CFOPHorzDynamicLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Horizontal Dynamic Link Shape, Constructs a CFOPHorzDynamicLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHorzDynamicLinkShape& src object(Value).
	CFOPHorzDynamicLinkShape(const CFOPHorzDynamicLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Horizontal Dynamic Link Shape, Destructor of class CFOPHorzDynamicLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHorzDynamicLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPHorzDynamicLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the horizontal dynamic link shape from points.
	// ptArray -- array of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPHorzDynamicLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the horizontal dynamic link shape from points.
	// pptPoints -- points.
	// nCount -- count of points.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPHorzDynamicLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHorzDynamicLinkShape& src object(Value).
	CFOPHorzDynamicLinkShape& operator=(const CFOPHorzDynamicLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	//-----------------------------------------------------------------------
	// Summary:
	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
public:

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re layout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Re layout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Get distance from anchor to line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetDistance() const;

	// Get distance from tracker anchor to tracker line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetTrackDistance();

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

};


/////////////////////////////////////////////////////////////////
// CFOPSideLinkShape -- side link line shape, ID FO_SIDE_LINK_SHAPE 261

 
//===========================================================================
// Summary:
//     The CFOPSideLinkShape class derived from CFOLinkShape
//      F O P Side Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPSideLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSideLinkShape---F O P Side Link Shape, Specifies a E-XD++ CFOPSideLinkShape object (Value).
	DECLARE_SERIAL(CFOPSideLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Side Link Shape, Constructs a CFOPSideLinkShape object.
	//		Returns A  value (Object).
	CFOPSideLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Side Link Shape, Constructs a CFOPSideLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSideLinkShape& src object(Value).
	CFOPSideLinkShape(const CFOPSideLinkShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Side Link Shape, Destructor of class CFOPSideLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSideLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSideLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the side link shape from points.
	// ptArray -- points array.
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSideLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the side link shape from points.
	// pptPoints -- points.
	// nCount -- count of points
	// pFrom -- pointer of from port.
	// pTo -- pointer of to port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSideLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPSideLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSideLinkShape& src object(Value).
	CFOPSideLinkShape& operator=(const CFOPSideLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re layout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Re layout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);
	
	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLabelPoint();
	
	// Get the line total distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Distance, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetTotalDistance();

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Compute scaling ratio.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Ratio, Call this member function to update the object.

	void UpdateRatio();
	
	// Compute scaling ratio.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Track Ratio, Call this member function to update the object.

	void UpdateTrackRatio();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Anchor ratio.
 
	// Anchor Ratio, This member specify double object.  
	double m_dAnchorRatio;
};

#endif // !defined(FO_FOPARCLINKSHAPE_H__99193BC3_FEAD_48C8_A5A1_A3CD028A3726__INCLUDED_)
