//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOFORMPROPDLG_H__900D5BB7_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FOFORMPROPDLG_H__900D5BB7_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOFormPropDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOFormPropDlg dialog
#include "FOPDropDownColorPickerButton.h"
#include "FOGlobals.h"
#include "FOFillSampleButton.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOFormPropDlg class derived from CDialog
//      F O Form Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOFormPropDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Form Property Dialog, Constructs a CFOFormPropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOFormPropDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOFormPropDlg)
	enum { IDD = IDD_FO_PAGE_SETTING_EXT };
 
	// Close Button, This member sets TRUE if it is right.  
	BOOL	m_bCloseButton;
 
	// Help Button, This member sets TRUE if it is right.  
	BOOL	m_bHelpButton;
 
	// Maximize Button, This member sets TRUE if it is right.  
	BOOL	m_bMaxButton;
 
	// Minimize Button, This member sets TRUE if it is right.  
	BOOL	m_bMinButton;
 
	// Show Title, This member sets TRUE if it is right.  
	BOOL	m_bShowTitle;
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
 
	// D, This member sets TRUE if it is right.  
	BOOL	m_b3D;
 
	// Has Icon, This member sets TRUE if it is right.  
	BOOL	m_bHasIcon;
	//}}AFX_DATA
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnColor;
 
	// Background, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnBackground;

	// Page background color.
 
	// Page Back, This member sets A 32-bit value used as a color value.  
	COLORREF m_crPageBack;

	// Page background color.
 
	// Old Page Back, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldPageBack;

	// The font color.
 
	// Font, This member sets A 32-bit value used as a color value.  
	COLORREF	crFont;

 
	// This member specify LOGFONT object.  
	LOGFONT		m_lf;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Color select button.
 
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	

	// Pattern color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crFG;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBK;

	//Brush Type
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nBrushType;

	// Get font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Information, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFontSet---Font Set, A pointer to the FO_FONT or NULL if the call failed.
	virtual void GetFontInfo(FO_FONT* pFontSet);

	// Set font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Information, Sets a specify value to current class CFOFormPropDlg
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pFontSet---Font Set, A pointer to the FO_FONT  or NULL if the call failed.
	virtual void SetFontInfo(FO_FONT *pFontSet);

	// Save data.
 
	// Old Close Button, This member sets TRUE if it is right.  
	BOOL	m_bOldCloseButton;
 
	// Old Help Button, This member sets TRUE if it is right.  
	BOOL	m_bOldHelpButton;
 
	// Old Maximize Button, This member sets TRUE if it is right.  
	BOOL	m_bOldMaxButton;
 
	// Old Minimize Button, This member sets TRUE if it is right.  
	BOOL	m_bOldMinButton;
 
	// Old Show Title, This member sets TRUE if it is right.  
	BOOL	m_bOldShowTitle;
 
	// Old Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldCaption;
 
	// Old3 D, This member sets TRUE if it is right.  
	BOOL	m_bOld3D;
 
	// Old Has Icon, This member sets TRUE if it is right.  
	BOOL	m_bOldHasIcon;

	// Pattern color.
 
	// Old F G, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crOldFG;

	// Background color.
 
	// Old B K, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crOldBK;

	//Brush Type
 
	// Old Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nOldBrushType;

	// The font color.
 
	// Old Font, This member sets A 32-bit value used as a color value.  
	COLORREF	crOldFont;

 
	// Old Font, This member specify FO_FONT object.  
	FO_FONT		m_OldFont;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL		m_bModify;

	//
 
	// Is Axis Up, This member sets TRUE if it is right.  
	BOOL	m_bIsAxisUp;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do O K, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DoOK();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOFormPropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOFormPropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Form Font, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFormFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Fill Effect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFillEffect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Single Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSingleColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Gad Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGadColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Show3d, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShow3d();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelectColorChange();
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOFORMPROPDLG_H__900D5BB7_F3E6_11DD_A438_525400EA266C__INCLUDED_)
