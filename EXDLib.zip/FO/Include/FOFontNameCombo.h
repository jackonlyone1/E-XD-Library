//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOFONTNAMECOMBO_H__D314CA73_4121_11D6_A558_525400EA266C__INCLUDED_)
#define AFX_FOFONTNAMECOMBO_H__D314CA73_4121_11D6_A558_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOFontNameCombo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPFontData

 
//===========================================================================
// Summary:
//     The CFOPFontData class derived from CObject
//      F O P Font Data
//===========================================================================

class FO_EXT_CLASS CFOPFontData : public CObject
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Font Data, Constructs a CFOPFontData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpszName---lpszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszScript---lpszScript, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nCharSet---Char Set, Specifies An 8-bit BYTE integer that is not signed.  
	//		nPitchAndFamily---Pitch And Family, Specifies An 8-bit BYTE integer that is not signed.  
	//		nType---nType, Specifies A integer value.
	CFOPFontData(LPCTSTR lpszName, LPCTSTR lpszScript, BYTE nCharSet,BYTE nPitchAndFamily, int nType) :
	  m_strName (lpszName),
		  m_strScript (lpszScript),
		  m_nCharSet (nCharSet),
		  m_nPitch (nPitchAndFamily),
	
	//-----------------------------------------------------------------------
	// Summary:
	// m_nType, .
	//		Returns A  value (Object).  
	// Parameters:
	//		nType---nType, Specifies a nType object(Value).
		  m_nType (nType)	{}
	  
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Font Data, Constructs a CFOPFontData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPFontData& src object(Value).
	  CFOPFontData (const CFOPFontData& src) :
	  m_strName (src.m_strName),
		  m_strScript (src.m_strScript),
		  m_nCharSet (src.m_nCharSet),
		  m_nPitch (src.m_nPitch),
	
	//-----------------------------------------------------------------------
	// Summary:
	// m_nType, .
	//		Returns A  value (Object).  
	// Parameters:
	//		src.m_nType---src.m_nType, Specifies a src.m_nType object(Value).
		  m_nType (src.m_nType) { }
	  
	  // Face name of the font
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	  const CString		m_strName;

	  // Description of font
 
	// Script, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	  const CString		m_strScript;

	  // Font char set
 
	// Char Set, This member sets An 8-bit integer that is not signed.  
	  const BYTE		m_nCharSet;

	  // Font pitch and famity
 
	// Pitch, This member sets An 8-bit integer that is not signed.  
	  const BYTE		m_nPitch;

	  // Type of font
 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	  const int			m_nType;
	  
	  // Face name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	  CString GetFaceName() const;
	  
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Boolean value.  
	// Parameters:
	//		other---Specifies a const CFOPFontData& other object(Value).
	  // operator ==
	  bool operator == (const CFOPFontData& other);
	  
};

/////////////////////////////////////////////////////////////////////////////
// CFOFontNameCombo

 
//===========================================================================
// Summary:
//     The CFOFontNameCombo class derived from CComboBox
//      F O Font Name Combo
//===========================================================================

class FO_EXT_CLASS CFOFontNameCombo : public CComboBox
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Name Combo, Constructs a CFOFontNameCombo object.
	//		Returns A  value (Object).
	CFOFontNameCombo();
	
	// Attributes
public:
	// Current font height.
 
	// Font Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nFontHeight;
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOFontNameCombo)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		lpCompareItemStruct---Compare Item Struct, Specifies a LPCOMPAREITEMSTRUCT lpCompareItemStruct object(Value).
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Font Name Combo, Destructor of class CFOFontNameCombo
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontNameCombo();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOFontNameCombo)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Dropdown, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnDropdown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
		// Operations
public:
	// Gen fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Fonts, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFontType---Font Type, Specifies A integer value.  
	//		nCharSet---Char Set, Specifies An 8-bit BYTE integer that is not signed.  
	//		nPitchAndFamily---Pitch And Family, Specifies An 8-bit BYTE integer that is not signed.
	BOOL GenFonts(int nFontType = DEVICE_FONTTYPE | RASTER_FONTTYPE | TRUETYPE_FONTTYPE,
		BYTE nCharSet = DEFAULT_CHARSET,
		BYTE nPitchAndFamily = DEFAULT_PITCH);

	// Set current font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Select, Sets a specify value to current class CFOFontNameCombo
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pData---pData, A pointer to the CFOPFontData or NULL if the call failed.
	BOOL SetCurFontSel(CFOPFontData* pData);

	// Set current font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Select, Sets a specify value to current class CFOFontNameCombo
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszName---lpszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nCharSet---Char Set, Specifies An 8-bit BYTE integer that is not signed.
	BOOL SetCurFontSel(LPCTSTR lpszName, BYTE nCharSet = DEFAULT_CHARSET);
	
	// Get cur font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Select, Returns the specified value.
	//		Returns a pointer to the object CFOPFontData,or NULL if the call failed
	CFOPFontData* GetCurFontSel() const;
	
	// Enum fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enum Fam Basic Call Back Ex, .
	// This member function is a static function.
	//		Returns BOOL CALLBACK AFX_EXPORTvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONTEX or NULL if the call failed.  
	//		NEWTEXTMETRICEX*---E W T E X T M E T R I C E X*, A pointer to the NEWTEXTMETRICEX or NULL if the call failed.  
	//		FontType---Font Type, Specifies A integer value.  
	//		pThis---pThis, Specifies a LPVOID pThis object(Value).
	static BOOL CALLBACK AFX_EXPORT EnumFamBasicCallBackEx(ENUMLOGFONTEX* pelf, NEWTEXTMETRICEX* /*lpntm*/, 
		int FontType,
		LPVOID pThis);

	// Enum fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enum Fam Extend Call Back Ex, .
	// This member function is a static function.
	//		Returns BOOL CALLBACK AFX_EXPORTvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONTEX or NULL if the call failed.  
	//		NEWTEXTMETRICEX*---E W T E X T M E T R I C E X*, A pointer to the NEWTEXTMETRICEX or NULL if the call failed.  
	//		FontType---Font Type, Specifies A integer value.  
	//		pThis---pThis, Specifies a LPVOID pThis object(Value).
	static BOOL CALLBACK AFX_EXPORT EnumFamExtendCallBackEx(ENUMLOGFONTEX* pelf, NEWTEXTMETRICEX* /*lpntm*/, 
		int FontType, 
		LPVOID pThis);
	
	// Add font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Font, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONT or NULL if the call failed.  
	//		nType---nType, Specifies A integer value.  
	//		lpszScript---lpszScript, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL AddFont(ENUMLOGFONT* pelf, int nType, LPCTSTR lpszScript);

protected:

	// Init font data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Font Data, Call InitFontData after creating a new object.

	void InitFontData();

	// Clear all font cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache, Remove the specify data from the list.

	void ClearCache();

	// Build fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Fonts, .

	void BuildFonts();

	
protected:
	
	// Crrent font image list.
 
	// Font Name, This member is a collection of same-sized images.  
	CImageList		m_imgFontName;	
	
	// Pitch
 
	// Pitch, This member sets An 8-bit integer that is not signed.  
	BYTE			m_nPitch;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOFONTNAMECOMBO_H__D314CA73_4121_11D6_A558_525400EA266C__INCLUDED_)
