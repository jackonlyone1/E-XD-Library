//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
// FOFormColorChangeAction.h: interface for the CFOFormColorChangeAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOFORMCOLORCHANGEACTION_H__BE0E7354_F6B7_11DD_A43C_525400EA266C__INCLUDED_)
#define AFX_FOFORMCOLORCHANGEACTION_H__BE0E7354_F6B7_11DD_A43C_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOFormColorChangeAction -- action that defined for changing the color of canvas.

 
//===========================================================================
// Summary:
//     The CFOFormColorChangeAction class derived from CFOAction
//      F O Form Color Change Action
//===========================================================================

class FO_EXT_CLASS CFOFormColorChangeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFormColorChangeAction---F O Form Color Change Action, Specifies a E-XD++ CFOFormColorChangeAction object (Value).
	DECLARE_ACTION(CFOFormColorChangeAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Form Color Change Action, Constructs a CFOFormColorChangeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.
	CFOFormColorChangeAction(CFODataModel* pModel,CFODrawShape *pShape,COLORREF crBack,COLORREF crText);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Form Color Change Action, Destructor of class CFOFormColorChangeAction
	//		Returns A  value (Object).
	~CFOFormColorChangeAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOFormColorChangeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get the current back color of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetCurrentBackColor() { return m_crBackNew; }

	// Set the current back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Back Color, Sets a specify value to current class CFOFormColorChangeAction
	// Parameters:
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.
	void SetCurrentBackColor(COLORREF crBack) { m_crBackNew = crBack; }

	// Get the current text color of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetCurrentTextColor() { return m_crTextNew; }

	// Set the current back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Color, Sets a specify value to current class CFOFormColorChangeAction
	// Parameters:
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.
	void SetCurrentTextColor(COLORREF crText) { m_crTextNew = crText; }

protected:
	// Background shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*		m_pShape;		

	// New back color.
 
	// Back New, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crBackNew;    

	// Old back color.
 
	// Back Old, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crBackOld;    

	// New text color.
 
	// Text New, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crTextNew;    

	// Old text color.
 
	// Text Old, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crTextOld;    

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOFormColorChangeAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOFormColorChangeAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOFORMCOLORCHANGEACTION_H__BE0E7354_F6B7_11DD_A43C_525400EA266C__INCLUDED_)
