//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTOOLBOXITEM_H__1374EBF3_B7C8_11D5_A475_525400EA266C__INCLUDED_)
#define AFX_FOTOOLBOXITEM_H__1374EBF3_B7C8_11D5_A475_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOToolBoxItem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOToolBoxItem window
#include "FOImageJPEG.h"
#include "FOCompositeShape.h"

#define VIEW_ST_ICON_NAME		1000
#define VIEW_ST_NAME			1001
#define VIEW_ST_ICON_DETAIL		1002

 
//===========================================================================
// Summary:
//     The CFOToolBoxItem class derived from CObject
//      F O Tool Box Item
//===========================================================================

class FO_EXT_CLASS CFOToolBoxItem : public CObject
{ 
protected: 
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOToolBoxItem---F O Tool Box Item, Specifies a E-XD++ CFOToolBoxItem object (Value).
	DECLARE_SERIAL(CFOToolBoxItem);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Item, Constructs a CFOToolBoxItem object.
	//		Returns A  value (Object).
	CFOToolBoxItem();

	// Constructor.
	// strIFile -- the specify file name.
	// crTrans -- transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Item, Constructs a CFOToolBoxItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		strIFile---I File, Specifies A CString type value.  
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	CFOToolBoxItem(CString strIFile,COLORREF crTrans= RGB(255,255,255));

	// Constructor.
	// nIconID -- the specify icon id.
	// crTrans -- transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Item, Constructs a CFOToolBoxItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nIconID---Icon I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	CFOToolBoxItem(UINT nIconID,COLORREF crTrans= RGB(255,255,255));

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Box Item, Destructor of class CFOToolBoxItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolBoxItem();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Serialize ole data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Ole Data, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeOleData(CArchive &ar);

	// Clear cache data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache Data, Remove the specify data from the list.

	void ClearCacheData();

	// Build index for composite's property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Build Property Index, Do a event. 

	void DoBuildPropIndex();

	BOOL UpdateType();
public:

	// Obtain the selected flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void	SetSelected(const BOOL &bSelect);

	void SetTracked(const BOOL &bTrack) { m_bTracked = bTrack; }

	BOOL IsTracked() const { return m_bTracked; }


	// Change the selection flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsSelected() const					{ return m_bSelected; }

	// Get view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Style, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetViewStyle() const { return m_nViewStyle; }

	// Set view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Style, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&nStyle---&nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetViewStyle(const UINT &nStyle) { m_nViewStyle = nStyle; }

	// Obtain the caption of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Caption, Returns the specified value.
	//		Returns a CString type value.
	CString GetCaption() const;

	// Change the caption of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Caption, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetCaption(const CString &str);

	// Obtain the prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Prompt, Returns the specified value.
	//		Returns a CString type value.
	CString GetPrompt() const { return m_strPrompt; }

	// Change the item's prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Prompt, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void	SetPrompt(const CString &strText) { m_strPrompt = strText; }

	// Obtain the transparent color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetTransparentColor() const;

	// Change the transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent Color, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetTransparentColor(const COLORREF &cr);

	// Obtain the item's rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const;

	// Change the item's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&cr---Specifies A CRect type value.
	void	SetItemRect(const CRect &cr);

	// Calculate text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOEditBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,CRect rcBox,CStringArray& arLines);

	// Update icon image.
	void UpdateImage(CFODrawShape *pShape);

	// Update icon image.
	void UpdateImage();

	// Obtain the item's type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a int type value.
	int		GetType() const;

	// Obtain the item's type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&num---Specifies A integer value.
	void	SetType(const int &num);

	// Change bitmap.
	void ChangeBitmap(CBitmap *pBitmap);

	// load icon file for the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL	LoadIconFile(CString strFile,COLORREF cr= RGB(255,255,255));

	// Load icon from resource ID for the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon I D, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL	LoadIconID(UINT nID,COLORREF cr= RGB(255,255,255));

	// Get the pointer of text box item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed
	CFOCompositeShape* GetShape() { return m_pCompositeShape; }

	// Change the pointer of composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	void SetShape(CFOCompositeShape *pComp);

	// Slip tips text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Split Tips Text, .
	// Parameters:
	//		&strTitle---&strTitle, Specifies A CString type value.  
	//		&strTips---&strTips, Specifies A CString type value.
	void SplitTipsText(CString &strTitle, CString &strTips);

	// Get item text position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Text Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetItemTextRect() const;

	// Is composite shape be splited.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Composite Split, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCompositeSplit() const;

	// Is single composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Single Composite, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSingleComposite();

	// Set composite shape split.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Composite Split, Sets a specify value to current class CFOToolBoxItem
	// Parameters:
	//		&bSplit---&bSplit, Specifies A Boolean value.
	void SetCompositeSplit(const BOOL &bSplit) { m_bCompositeSplit = bSplit; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Track, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoDrawTrack(CDC *pDC);

	int  m_nItemImage;
public:

	// Update all data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All, Call this member function to update the object.

	void	UpdateAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	// Init
	virtual void Init(CWnd* pWnd);

	// Get font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	CSize GetFontSize(CDC *pDC);


public:

	// Draw view icon mode.
	// Drawing with the state VIEW_ST_ICON_NAME
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Icon, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawIcon(CDC *pDC);

	// Obtain the bitmap of this item.
	virtual void GetBitmap(CBitmap &bmp);

	// Draw view icon mode select.
	// Drawing with the state VIEW_ST_ICON_NAME
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Icon Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void OnDrawIconSelect(CDC *pDC, const BOOL &bFocus);

	// Draw view icon name mode.
	// Drawing with the state VIEW_ST_ICON_DETAIL
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Icon Name, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawIconName(CDC *pDC);

	// Draw view icon name mode select.
	// Drawing with the state VIEW_ST_ICON_DETAIL
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Icon Name Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void OnDrawIconNameSelect(CDC *pDC, const BOOL &bFocus);

	// Draw view name mode.
	// Drawing with the state VIEW_ST_NAME
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Name, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawName(CDC *pDC);

	// Draw view name mode select.
	// Drawing with the state VIEW_ST_NAME
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Name Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void OnDrawNameSelect(CDC *pDC, const BOOL &bFocus);
	
	// Draw view mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draw view mode select.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void OnDrawSelect(CDC *pDC, const BOOL &bFocus);

	// draw transparent bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Transparent Bitmap, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.  
	//		pbmpMask---pbmpMask, A pointer to the CBitmap or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	static void DrawTransparentBitmap(CDC* pDC, CBitmap* pbmp, CBitmap* pbmpMask,
	                              int x, int y, int cx, int cy);

	// Init transparent bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Transparent Bitmap, Call InitTransBitmap after creating a new object.
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.
	static COLORREF InitTransBitmap(CBitmap* pbmp);

	// Edit tool bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Edit Tool Bitmap, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EditToolBitmap();

	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);

public:
	// object of class
 
	// Image, This member specify E-XD++ CFOImageIcon object.  
	CFOImageIcon	m_Image;            

	// Draw image
 
	// Select Image, This member specify E-XD++ CFOPImageTransDrawHelper object.  
	CFOPImageTransDrawHelper	m_SelectImage;

protected:

	// Position of text.
 
	int  m_nStateCount;

	// Text, This member sets a CRect value.  
	CRect			m_rcText;

	// caption	
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;		

	// type of item
 
	// Item Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nItemType;	
	
	// file of icon
 
	// Icon File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strIconFile;	
	
	// color :transparent
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crTransparent;	

	// position:
 
	// Position, This member sets a CRect value.  
	CRect			m_rectPosition;		

	// flag of being selected
 
	// Selected, This member sets TRUE if it is right.  
	BOOL			m_bSelected;		

	// 
	BOOL			m_bTracked;

	// Back shape.
 
	// Composite Shape, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape*	m_pCompositeShape;

	// Prompt text.
 
	// Prompt, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strPrompt;

	// parent window
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			pParentWnd;		
	
	// size of image
 
	// Image, This member sets a CSize value.  
	CSize			szImage;			

	// View style.
 
	// View Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nViewStyle;

	// Version of shape.
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nVersion;

	// Composite shapes to be split.
 
	// Composite Split, This member sets TRUE if it is right.  
	BOOL			m_bCompositeSplit;

	// Height of the item's icon.
 
	// Item Single Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nItemSingleHeight;

	// transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF		crTransparent;

	// Drawing bitmap.
 
	// Draw Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap *		m_pDrawBitmap;

};


////////////////////////////////////////////////////////////////
// CFOToolBoxItemSet

 
//===========================================================================
// Summary:
//     The CFOToolBoxItemSet class derived from FOPContainer
//      F O Tool Box Item Set
//===========================================================================

class FO_EXT_CLASS CFOToolBoxItemSet : public FOPContainer
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Item Set, Constructs a CFOToolBoxItemSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFOToolBoxItemSet(int nInit = 32, int nTotal = 32) : FOPContainer(1024, nInit, nTotal)	{}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Box Item Set, Destructor of class CFOToolBoxItemSet
	//		Returns A  value (Object).
    ~CFOToolBoxItemSet();

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddHead(CObject* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddTail(CObject* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOToolBoxItemSet or NULL if the call failed.
	void AddHead(CFOToolBoxItemSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOToolBoxItemSet or NULL if the call failed.
	void AddTail(CFOToolBoxItemSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();
};

typedef CTypedPtrList<CObList, CFOToolBoxItem*> CFOToolBoxItemList;
typedef FOBasicListIterator<CFOToolBoxItem*> CFOToolBoxItemIterator;

///////////////////////////////////////////////////////
_FOLIB_INLINE CString CFOToolBoxItem::GetCaption() const
{
	return m_strCaption;
}

_FOLIB_INLINE COLORREF CFOToolBoxItem::GetTransparentColor() const
{
	return m_crTransparent;
}

_FOLIB_INLINE int CFOToolBoxItem::GetType() const
{
	return m_nItemType;
}
	
_FOLIB_INLINE void CFOToolBoxItem::SetCaption(const CString &str)
{
	m_strCaption = str;
}

_FOLIB_INLINE void CFOToolBoxItem::SetTransparentColor(const COLORREF &cr)
{
	m_crTransparent = cr;
}

_FOLIB_INLINE void CFOToolBoxItem::SetType(const int &nType) 
{
	m_nItemType = nType;
}

_FOLIB_INLINE CRect CFOToolBoxItem::GetItemRect() const
{
	return m_rectPosition;
}

_FOLIB_INLINE void CFOToolBoxItem::SetItemRect(const CRect &cr)
{
	m_rectPosition = cr;
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTOOLBOXITEM_H__1374EBF3_B7C8_11D5_A475_525400EA266C__INCLUDED_)
