//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODropSource.h: interface for the CFODropSource class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODROPSOURCE_H__971B27D6_F28B_11DD_A434_525400EA266C__INCLUDED_)
#define AFX_FODROPSOURCE_H__971B27D6_F28B_11DD_A434_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFOToolBoxItem;
/////////////////////////////////////////////////////////////////////////////////
//
// CFODropSource -- ole drag - drop source class.
/////////////////////////////////////////////////////////////////////////////////
typedef struct
{
	SIZE sizeDragImage; // OUT - The length and Width of the
	// rendered image
	POINT ptOffset; // OUT - The Offset from the mouse cursor to
	// the upper left corner of the image
	HBITMAP hbmpDragImage; // OUT - The Bitmap containing the rendered
	// drag images
	COLORREF crColorKey; // OUT - The COLORREF that has been blitted
	// to the background of the images
} FODRAGIMAGE, *LPFODRAGIMAGE;

// {DE5BF786-477A-11d2-839D-00C04FD918D0}
extern "C" const GUID __declspec(selectany) IID_FOIDragSourceHelper =
{ 0xde5bf786, 0x477a, 0x11d2, {0x83, 0x9d, 0x0, 0xc0, 0x4f, 0xd9, 0x18, 0xd0}};

// {4657278A-411B-11d2-839A-00C04FD918D0}
extern "C" const GUID __declspec(selectany) CLSID_FODragDropHelper = 
{ 0x4657278a, 0x411b, 0x11d2, { 0x83, 0x9a, 0x0, 0xc0, 0x4f, 0xd9, 0x18, 0xd0 }};

struct FOIDragSourceHelper : public IUnknown
{
	// IUnknown methods
	STDMETHOD (QueryInterface)(THIS_ REFIID riid, void **ppv) PURE;
	STDMETHOD_(ULONG, AddRef) ( THIS ) PURE;
	STDMETHOD_(ULONG, Release) ( THIS ) PURE;
	
	// FOIDragSourceHelper
	STDMETHOD (InitializeFromBitmap)(THIS_ LPFODRAGIMAGE pshdi,
		IDataObject* pDataObject) PURE;
	STDMETHOD (InitializeFromWindow)(THIS_ HWND hwnd, POINT* ppt,
		IDataObject* pDataObject) PURE;
}; 

MIDL_INTERFACE("4657278B-411B-11D2-839A-00C04FD918D0")
FOIDropTargetHelper : public IUnknown
{
public:
	virtual HRESULT STDMETHODCALLTYPE DragEnter( 
		/* [annotation][in] */ 
		 HWND hwndTarget,
		/* [annotation][in] */ 
		 IDataObject *pDataObject,
		/* [annotation][in] */ 
		 POINT *ppt,
		/* [annotation][in] */ 
		 DWORD dwEffect) = 0;
	
	virtual HRESULT STDMETHODCALLTYPE DragLeave( void) = 0;
	
	virtual HRESULT STDMETHODCALLTYPE DragOver( 
		/* [annotation][in] */ 
		 POINT *ppt,
		/* [annotation][in] */ 
		 DWORD dwEffect) = 0;
	
	virtual HRESULT STDMETHODCALLTYPE Drop( 
		/* [annotation][in] */ 
		  IDataObject *pDataObject,
		/* [annotation][in] */ 
		  POINT *ppt,
		/* [annotation][in] */ 
		  DWORD dwEffect) = 0;
	
	virtual HRESULT STDMETHODCALLTYPE Show( 
		/* [annotation][in] */ 
		  BOOL fShow) = 0;
	
    };

#define CF_CSV_STR					_T("CSV")
#define CF_HTML_STR					_T("HTML Format")
#define CF_RTF_STR					_T("Rich Text Format")

// Vista: FO_DROPDESCRIPTION and FILE_ATTRIBUTES_ARRAY (ShlObj.h)
#if !defined(NTDDI_VERSION) || (NTDDI_VERSION < NTDDI_VISTA)

// Vista: FO_DROPDESCRIPTION type member
// NOTE: DROPIMAGE_NOIMAGE has been added with Windows 7
typedef enum  { 
  DROPIMAGE_INVALID  = -1,
  DROPIMAGE_NONE     = 0,
  DROPIMAGE_COPY     = DROPEFFECT_COPY,
  DROPIMAGE_MOVE     = DROPEFFECT_MOVE,
  DROPIMAGE_LINK     = DROPEFFECT_LINK,
  DROPIMAGE_LABEL    = 6,
  DROPIMAGE_WARNING  = 7,
  DROPIMAGE_NOIMAGE  = 8
} FO_DROPIMAGETYPE;

// Vista: FO_DROPDESCRIPTION structure
typedef struct _FO_DROPDESCRIPTION {
  FO_DROPIMAGETYPE type;
  WCHAR         szMessage[MAX_PATH];
  WCHAR         szInsert[MAX_PATH];
} FO_DROPDESCRIPTION;

#endif

// Vista: FOIDragSourceHelper2 interface (ShObjIdl.h)
// Interface definition for older SDK / Visual Studio versions
//#if !defined(NTDDI_VERSION) || (NTDDI_VERSION < NTDDI_VISTA)
#ifndef __FOIDragSourceHelper2_INTERFACE_DEFINED__
// 
// typedef /* [v1_enum] */ 
// enum DSH_FLAGS
//     {	DSH_ALLOWFO_DROPDESCRIPTIONTEXT	= 0x1
//     } 	DSH_FLAGS;

#undef INTERFACE
#define INTERFACE FOIDragSourceHelper2

DECLARE_INTERFACE_( FOIDragSourceHelper2, FOIDragSourceHelper )
{
    // IUnknown methods
    STDMETHOD (QueryInterface)(THIS_ REFIID riid, void **ppv) PURE;
    STDMETHOD_(ULONG, AddRef) ( THIS ) PURE;
    STDMETHOD_(ULONG, Release) ( THIS ) PURE;

    // FOIDragSourceHelper
    STDMETHOD (InitializeFromBitmap)(THIS_ LPFODRAGIMAGE pshdi,
                                     IDataObject* pDataObject) PURE;
    STDMETHOD (InitializeFromWindow)(THIS_ HWND hwnd, POINT* ppt,
                                     IDataObject* pDataObject) PURE;
    // FOIDragSourceHelper2
    STDMETHOD (SetFlags)(THIS_ DWORD) PURE;
};

static const IID IID_FOIDragSourceHelper2 = 
	{ 0x83E07D0D, 0x0C5F, 0x4163, 0xBF, 0x1A, 0x60, 0xB2, 0x74, 0x05, 0x1E, 0x40 };

#endif

class FO_EXT_CLASS CFODragDropHelper
{
public:
	static inline CLIPFORMAT RegisterFormat(LPCTSTR lpszFormat)
	{ return static_cast<CLIPFORMAT>(::RegisterClipboardFormat(lpszFormat)); }

	static unsigned PopCount(unsigned n);
	static bool		IsRegisteredFormat(CLIPFORMAT cfFormat, LPCTSTR lpszFormat, bool bRegister = false);
	static HGLOBAL	CopyGlobalMemory(HGLOBAL hDst, HGLOBAL hSrc, size_t nSize);
	static bool		GetGlobalData(LPDATAOBJECT pIDataObj, LPCTSTR lpszFormat, FORMATETC& FormatEtc, STGMEDIUM& StgMedium);
	static DWORD	GetGlobalDataDWord(LPDATAOBJECT pIDataObj, LPCTSTR lpszFormat);
	static bool		SetGlobalDataDWord(LPDATAOBJECT pIDataObj, LPCTSTR lpszFormat, DWORD dwData, bool bForce = true);
//	static FO_DROPIMAGETYPE DropEffectToDropImage(DROPEFFECT dwEffect);
//	static bool		ClearDescription(FO_DROPDESCRIPTION *pFO_DROPDESCRIPTION);
	static size_t	GetWideLength(LPCWSTR lpszText, size_t nSize);
	static size_t	GetMultiByteLength(LPCSTR lpszText, size_t nSize);
	static LPWSTR	MultiByteToWideChar(LPCSTR lpszAnsi, int nLen, UINT nCP = CP_THREAD_ACP);
	static LPSTR	WideCharToMultiByte(LPCWSTR lpszWide, int nLen, UINT nCP = CP_THREAD_ACP);
	static UINT		GetCodePage(LCID nLCID, bool bOem);
#ifndef _UNICODE
	static bool		CompareCodePages(UINT nCP1, UINT nCP2);
	static LPSTR	MultiByteToMultiByte(LPCSTR lpszAnsi, int nLen, UINT nCP, UINT nOutCP = CP_THREAD_ACP);
#endif
};

// CFOOleDropSourceEx results
#define DRAG_RES_NOT_STARTED		0		// drag not started
#define DRAG_RES_STARTED			1		// drag started (timeout expired or mouse left the start rect)
#define DRAG_RES_CANCELLED			2		// cancelled (may be started or not)
#define DRAG_RES_RELEASED			4		// left mouse button released (may be started or not)
#define DRAG_RES_DROPPED			8		// data has been dropped (return effect not DROPEEFECT_NONE)
// Possible combinations:
// DRAG_RES_RELEASED: 
//  Drag has not been started because mouse button was released before leaving the start rect or the
//  time out expired. The button down handler that started the drag operation may simulate a single click
//  by passing the original message to the default handler and send a button up message afterwards.
// DRAG_RES_CANCELLED: 
//  Drag has not been started because another mouse button was activated or the ESC key has been
//  pressed before leaving the start rect or the time out expired.
// DRAG_RES_STARTED | DRAG_RES_CANCELLED: 
//  Drag has been started but whas cancelled by ESC or activating other mouse button.
// DRAG_RES_STARTED | DRAG_RES_RELEASED:
//  Drag has been finished by releasing the mouse button but the target did not drop
//  (return value is DROPEFFECT_NONE).
// DRAG_RES_STARTED | DRAG_RES_RELEASED | DRAG_RES_DROPPED:
//  Drag has been finished by releasing the mouse button and the target dropped the data
//  (return value is not DROPEFFECT_NONE).

// COleDropSource derived class to support FO_DROPDESCRIPTION
class FO_EXT_CLASS CFOOleDropSourceEx : public COleDropSource
{
public:
	CFOOleDropSourceEx(); 
#ifdef _DEBUG
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	bool			m_bSetCursor;					// internal flag set when Windows cursor must be set
	int				m_nResult;						// drag result flags
	LPDATAOBJECT	m_pIDataObj;					// set by CFOOleDataSourceEx to its IDataObject
	//	const CFO_DROPDESCRIPTION *m_pFO_DROPDESCRIPTION;		// set by CFOOleDataSourceEx to its CFO_DROPDESCRIPTION member
	
	bool			SetDragImageCursor(DROPEFFECT dwEffect);
	
	virtual BOOL	OnBeginDrag(CWnd* pWnd);
	virtual SCODE	QueryContinueDrag(BOOL bEscapePressed, DWORD dwKeyState);
	virtual SCODE	GiveFeedback(DROPEFFECT dropEffect);
	
public:
	friend class CFOOleDataSourceEx;
};

class CFOOleDataSourceEx;
typedef BOOL (CALLBACK* OnRenderDataFunc)(CWnd*, const CFOOleDataSourceEx*, LPFORMATETC, LPSTGMEDIUM);

class FO_EXT_CLASS CFOOleDataSourceEx : public COleDataSource
{
public:
	CFOOleDataSourceEx(CWnd *pWnd = NULL, OnRenderDataFunc pOnRenderData = NULL);
	virtual ~CFOOleDataSourceEx();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	inline bool WasDragStarted() const { return m_nDragResult & DRAG_RES_STARTED; }
	inline int GetDragResult() const { return m_nDragResult; }

	DROPEFFECT DoDragDropEx(DROPEFFECT dwEffect, LPCRECT lpRectStartDrag = NULL);

	// Drop description functions
	bool AllowFO_DROPDESCRIPTIONText();
// 	bool SetFO_DROPDESCRIPTIONText(FO_DROPIMAGETYPE nType, LPCWSTR lpszText, 
// 		LPCWSTR lpszText1, LPCWSTR lpszInsert = NULL);

	// Drag image functions
	bool SetDragImageWindow(HWND hWnd, POINT* pPoint);
	bool SetDragImage(HBITMAP hBitmap, const CPoint* pPoint, COLORREF clr);
	// Set drag image from CBitmap. NOTE: This will use the HBITMAP from the CBitmap and detach!
	inline bool SetDragImage(CBitmap& Bitmap, const CPoint* pPoint, COLORREF clr)
	{ return SetDragImage(static_cast<HBITMAP>(Bitmap.Detach()), pPoint, clr); }

	bool InitDragImage(int nResBM, const CPoint* pPoint, COLORREF clr);
	bool InitDragImage(LPCTSTR lpszExt, int nScale = 0, const CPoint* pPoint = NULL, UINT nFlags = 0);
	bool InitDragImage(CWnd* pWnd, LPCTSTR lpszText, const CPoint *pPoint = NULL, bool bHiLightColor = false);
	bool InitDragImage(CWnd* pWnd, LPCRECT lpRect, int nScale, const CPoint *pPoint = NULL, COLORREF clr = CLR_INVALID);
	bool InitDragImage(HBITMAP hBitmap, int nScale, const CPoint *pPoint = NULL, COLORREF clrBk = CLR_INVALID);
	bool InitDrawImageExt(CWnd *pWnd, CFOToolBoxItem *pItem, const CPoint* pPoint, COLORREF clr);

	// Data caching functions
	bool CacheLocale(LCID nLCID = 0);
#ifndef _UNICODE
	bool CacheUnicode(CLIPFORMAT cfFormat, LPCSTR lpszAnsi, DWORD dwTymed = TYMED_HGLOBAL);
#endif
	bool CacheMultiByte(LPCTSTR lpszFormat, LPCWSTR lpszData, UINT nCP = CP_THREAD_ACP, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheMultiByte(CLIPFORMAT cfFormat, LPCWSTR lpszData, UINT nCP = CP_THREAD_ACP, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheText(LPCTSTR lpszText, bool bClipboard, bool bOem = false, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheRtfFromText(LPCTSTR lpszText, CWnd *pWnd = NULL, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheHtml(LPCTSTR lpszHtml, CWnd *pWnd = NULL, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheBitmap(HBITMAP hBitmap, bool bClipboard, HPALETTE hPal = NULL, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheDib(HBITMAP hBitmap, bool bV5, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheBitmapFromText(LPCTSTR lpszText, CWnd *pWnd);
	bool CacheBitmapAsFile(HBITMAP hBitmap, LPCTSTR lpszFileName, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheDdb(HBITMAP hBitmap, HPALETTE hPal, bool bCopyObjects);
	bool CacheImage(HBITMAP hBitmap, LPCTSTR lpszFormat, DWORD dwTymed = TYMED_HGLOBAL);
	bool CacheImage(HBITMAP hBitmap, CLIPFORMAT cfFormat, DWORD dwTymed = TYMED_HGLOBAL);
	inline bool CacheTiff(HBITMAP hBitmap, DWORD dwTymed = TYMED_HGLOBAL) 
	{ return CacheImage(hBitmap, CF_TIFF, dwTymed); }
	inline bool CacheMimeBmp(HBITMAP hBitmap, DWORD dwTymed = TYMED_HGLOBAL) 
	{ return CacheImage(hBitmap, _T("image/bmp"), dwTymed); }
	inline bool CacheMimePng(HBITMAP hBitmap, DWORD dwTymed = TYMED_HGLOBAL) 
	{ return CacheImage(hBitmap, _T("image/png"), dwTymed); }
	inline bool CacheMimeJpeg(HBITMAP hBitmap, DWORD dwTymed = TYMED_HGLOBAL) 
	{ return CacheImage(hBitmap, _T("image/jpeg"), dwTymed); }
	inline bool CacheMimeGif(HBITMAP hBitmap, DWORD dwTymed = TYMED_HGLOBAL) 
	{ return CacheImage(hBitmap, _T("image/gif"), dwTymed); }
#ifdef OBJ_SUPPORT
	bool CacheObjectData(CObject& Obj, LPCTSTR lpszFormat);
#endif
	bool CacheSingleFileAsHdrop(LPCTSTR lpszFileName);

#ifdef UNICODE
	inline bool CacheRtf(LPCTSTR lpszRtf, DWORD dwTymed = TYMED_HGLOBAL)
	{ return CacheMultiByte(CF_RTF_STR, lpszRtf, 20127, dwTymed); }	// 20127 is US-ASCII
	inline bool CacheCsv(LPCTSTR lpszCsv, DWORD dwTymed = TYMED_HGLOBAL)
	{ return CacheMultiByte(CF_CSV_STR, lpszCsv, CP_THREAD_ACP, dwTymed); }
#else
	inline bool CacheRtf(LPCTSTR lpszRtf, DWORD dwTymed = TYMED_HGLOBAL)
	{ return CacheString(CF_RTF_STR, lpszRtf, dwTymed); }
	inline bool CacheCsv(LPCTSTR lpszCsv, DWORD dwTymed = TYMED_HGLOBAL)
	{ return CacheString(CF_CSV_STR, lpszCsv, dwTymed); }
#endif

	// Render data functions

	virtual BOOL OnRenderData(LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium);

	bool RenderText(CLIPFORMAT cfFormat, LPCTSTR lpszText, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	bool RenderUnicode(LPCTSTR lpszText, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	bool RenderMultiByte(LPCTSTR lpszText, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium, UINT nCP = CP_THREAD_ACP) const;
	bool RenderHtml(LPCTSTR lpszHtml, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium, CWnd *pWnd) const;
	bool RenderBitmap(HBITMAP hBitmap, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	bool RenderDdb(HBITMAP hBitmap, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	bool RenderDib(HBITMAP hBitmap, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	size_t RenderImage(HBITMAP hBitmap, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	size_t RenderImage(HBITMAP hBitmap, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium, const GUID& FileType) const;
	// Render string as OEM text.
//	inline bool RenderOEM(LPCTSTR lpszText, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const
//	{ return RenderMultiByte(lpszText, lpFormatEtc, lpStgMedium, GetOEMCodePage()); }

	bool BitmapFromText(CBitmap& Bitmap, CWnd* pWnd, LPCTSTR lpszText) const;

	static BOOL BitmapFromWnd(CWnd *pWnd, CBitmap &Bitmap, CPalette *pPal, LPCRECT lpRect = NULL, COLORREF *lpBkClr = NULL, int nScale = 0);
	static BOOL BitmapFromWnd(CWnd *pWnd, CBitmap &Bitmap);
	static BOOL PrintWndToBitmap(CWnd *pWnd, CBitmap &Bitmap, bool bClient);

protected:
	bool				m_bSetDescriptionText;		// Description text string(s) has been specified
	int					m_nDragResult;				// DoDragDropEx result flags
	FOIDragSourceHelper*	m_pDragSourceHelper;		// Drag image helper
	FOIDragSourceHelper2*	m_pDragSourceHelper2;		// Drag image helper 2 (SetFlags function)
//	CFO_DROPDESCRIPTION	m_FO_DROPDESCRIPTION;			// Optional text descriptions
	CWnd				*m_pWnd;					// Associated window
	OnRenderDataFunc	m_pOnRenderData;			// RenderData callback function

	CString		CreateTempFileName(LPCTSTR lpszExt = NULL) const;
	LPOLESTR	CreateOleString(LPCTSTR lpszStr) const;
	DWORD		GetLowestColorBit(DWORD dwBitField) const;
	HBITMAP		ReplaceBlack(HBITMAP hBitmap) const;
	HGLOBAL		CreateDib(HBITMAP hBitmap, size_t& nSize, bool bV5, bool bFile) const;
	bool		CacheString(LPCTSTR lpszFormat, LPCTSTR lpszText, DWORD dwTymed = TYMED_HGLOBAL);
	bool		CacheString(CLIPFORMAT cfFormat, LPCTSTR lpszText, DWORD dwTymed = TYMED_HGLOBAL);
	bool		CacheFromBuffer(CLIPFORMAT cfFormat, LPCVOID lpData, size_t nSize, DWORD dwTymed, LPFORMATETC lpFormatEtc = NULL);
	bool		CacheFromGlobal(CLIPFORMAT cfFormat, HGLOBAL hGlobal, size_t nSize, DWORD dwTymed, LPFORMATETC lpFormatEtc = NULL);
	bool		RenderFromBuffer(LPCVOID lpData, size_t nSize, LPCVOID lpPrefix, size_t nPrefixSize, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	bool		RenderFromGlobal(HGLOBAL hGlobal, size_t nSize, LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium) const;
	UINT		GetDibColorTable(HBITMAP hBitmap, UINT nColors, RGBQUAD* pColors) const;

	static int	ScaleSize(int nScale, CSize& size, HDC hDC = NULL);

public:
	// Drag source helper support.
	// See http://www.codeproject.com/Articles/3530/DragSourceHelper-MFC
	// Helper methods to fix IDropSourceHelper.
	// Must implement all pure virtual functions.
	BEGIN_INTERFACE_PART(DataObjectEx, IDataObject)
		INIT_INTERFACE_PART(CFOOleDataSourceEx, DataObjectEx)
		// IDataObject
		STDMETHOD(GetData)(LPFORMATETC, LPSTGMEDIUM);
		STDMETHOD(GetDataHere)(LPFORMATETC, LPSTGMEDIUM);
		STDMETHOD(QueryGetData)(LPFORMATETC);
		STDMETHOD(GetCanonicalFormatEtc)(LPFORMATETC, LPFORMATETC);
		STDMETHOD(SetData)(LPFORMATETC, LPSTGMEDIUM, BOOL);
		STDMETHOD(EnumFormatEtc)(DWORD, LPENUMFORMATETC*);
		STDMETHOD(DAdvise)(LPFORMATETC, DWORD, LPADVISESINK, LPDWORD);
		STDMETHOD(DUnadvise)(DWORD);
		STDMETHOD(EnumDAdvise)(LPENUMSTATDATA*);
	END_INTERFACE_PART(DataObjectEx)

	DECLARE_INTERFACE_MAP()
};
//const GUID FAR CLSID_DragDropHelper = {0x4657278a, 0x411b, 0x11d2, {0x83, 0x9a, 0x0, 0xc0, 0x4f, 0xd9, 0x18, 0xd0}};
const GUID IID_FOIDropTargetHelper = {0x4657278b, 0x411b, 0x11d2, {0x83, 0x9a, 0x0, 0xc0, 0x4f, 0xd9, 0x18, 0xd0}};

// User defined messages for drag events.
#define WM_APP_DRAG_ENTER	(WM_APP + 1)			// WPARAM: COleDataObject*, LPARAM: DragParameters* 
#define WM_APP_DRAG_LEAVE	(WM_APP + 2)			// WPARAM: unused,          LPARAM: unused 
#define WM_APP_DRAG_OVER	(WM_APP + 3)			// WPARAM: COleDataObject*, LPARAM: DragParameters* 
#define WM_APP_DROP_EX		(WM_APP + 4)			// WPARAM: COleDataObject*, LPARAM: DragParameters* 
#define WM_APP_DROP			(WM_APP + 5)			// WPARAM: COleDataObject*, LPARAM: DragParameters* 
#define WM_APP_DRAG_SCROLL	(WM_APP + 6)			// WPARAM: dwKeyState,      LPARAM: point 
#define WM_APP_DO_SCROLL	(WM_APP + 7)			// WPARAM: vertical steps,  LPARAM: horizonal steps 

// Auto scroll mode flags
#define AUTO_SCROLL_HORZ_BAR	0x00001				// Auto scroll when over horizontal scroll bar
#define AUTO_SCROLL_VERT_BAR	0x00002				// Auto scroll when over vertical scroll bar
#define AUTO_SCROLL_INSET_HORZ	0x00004				// Auto scroll when over horizontal inset region
#define AUTO_SCROLL_INSET_VERT	0x00008				// Auto scroll when over vertical inset region
#define AUTO_SCROLL_INSET_BAR	0x00010				// Auto scroll when over inset region and bar visible
#define AUTO_SCROLL_MASK		0x0FFFF
#define AUTO_SCROLL_DEFAULT		0x10000				// Use default handling (no OnDragScroll() handler required)

#define AUTO_SCROLL_BARS		(AUTO_SCROLL_HORZ_BAR | AUTO_SCROLL_VERT_BAR)
#define AUTO_SCROLL_INSETS		(AUTO_SCROLL_INSET_HORZ | AUTO_SCROLL_INSET_VERT)

// Callback function prototypes
typedef DROPEFFECT	(CALLBACK* OnDragEnterFunc)(CWnd*, COleDataObject*, DWORD, CPoint);
typedef DROPEFFECT	(CALLBACK* OnDragOverFunc)(CWnd*, COleDataObject*, DWORD, CPoint);
typedef DROPEFFECT	(CALLBACK* OnDropExFunc)(CWnd*, COleDataObject*, DROPEFFECT, DROPEFFECT, CPoint);
typedef BOOL		(CALLBACK* OnDropFunc)(CWnd*, COleDataObject*, DROPEFFECT, CPoint);
typedef void		(CALLBACK* OnDragLeaveFunc)(CWnd*);    
typedef DROPEFFECT	(CALLBACK* OnDragScrollFunc)(CWnd*, DWORD, CPoint);
typedef void	    (CALLBACK* ScrollFunc)(CWnd*, int, int);

class FO_EXT_CLASS CFOOleDropTargetEx : public COleDropTarget
{
// Construction
public:
	CFOOleDropTargetEx();

	typedef struct tagDragParameters				// data passed with drag event messages
	{
		DWORD			dwKeyState;					// WM_APP_DRAG_ENTER, WM_APP_DRAG_OVER
		CPoint			point;
		DROPEFFECT		dropEffect;					// dropDefault parameter with WM_APP_DROP_EX
		DROPEFFECT		dropList;					// with WM_APP_DROP_EX only
	} DragParameters;
	// Attributes
public:
	
	// The Pointer to  Owner View
	// Operations
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register, Write a specify value to registry.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pOwner---*pOwner, A pointer to the CFOToolBoxPageWnd  or NULL if the call failed.
	// Register wnd.
	BOOL SetRegWnd(CObject *pOwner);
	
	// Timer started.
	
	// Timer Start, This member sets TRUE if it is right.  
	BOOL				m_bTimerStart;
	
	// Timer should stop.
	
	// Timer Stop, This member sets TRUE if it is right.  
	BOOL				m_bTimerStop;

	// Canvas Core, This member maintains a pointer to the object CFOToolBoxPageWnd.  
	CObject*	m_pCanvasCore;

	// Overrides
	virtual DROPEFFECT OnDragEnter(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	virtual DROPEFFECT OnDragOver(CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	virtual DROPEFFECT OnDropEx(CWnd* pWnd, COleDataObject* pDataObject, DROPEFFECT dropDefault, DROPEFFECT dropList, CPoint point);
	virtual BOOL OnDrop(CWnd* pWnd, COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	virtual void OnDragLeave(CWnd* pWnd);    
	virtual DROPEFFECT OnDragScroll(CWnd* pWnd, DWORD dwKeyState, CPoint point);

	// Implementation
public:
	virtual ~CFOOleDropTargetEx();
#ifdef _DEBUG
	virtual void Dump(CDumpContext& dc) const;
#endif

	inline void SetUseMsg()							{ m_bUseMsg = true; }
	inline bool GetUseFO_DROPDESCRIPTION() const		{ return m_bUseFO_DROPDESCRIPTION; }
	inline void SetScrollMode(unsigned nMode, ScrollFunc p = NULL)	
	{ m_nScrollMode = nMode; m_pScrollFunc = p; }

	// Pass callback functions.
	inline void SetOnDragEnter(OnDragEnterFunc p)	{ m_pOnDragEnter = p; }
	inline void SetOnDragOver(OnDragOverFunc p)		{ m_pOnDragOver = p; }
	inline void SetOnDropEx(OnDropExFunc p)			{ m_pOnDropEx = p; }
	inline void SetOnDrop(OnDropFunc p)				{ m_pOnDrop = p; }
	inline void SetOnDragLeave(OnDragLeaveFunc p)	{ m_pOnDragLeave = p; }
	inline void SetOnDragScroll(OnDragScrollFunc p)	{ m_pOnDragScroll = p; }

	DROPEFFECT GetDropEffect(DWORD dwKeyState, DROPEFFECT dwDefault = DROPEFFECT_MOVE) const;
	DROPEFFECT FilterDropEffect(DROPEFFECT dwEffect) const;
	// Preferred drop effect specified by the drag source.
	// If this it not DROPEFFECT_NONE, it should be used by the target
	//  in the drop effect selection decision.
	inline DROPEFFECT GetPreferredDropEffect() const { return m_nPreferredDropEffect; }
	// True when drop description text is shown by the drag source.
	inline bool IsTextAllowed() const { return m_bTextAllowed; }
	// True when drop descriptions can be used (Vista or later and visual styles enabled).
	inline bool CanShowDescription() const { return m_bCanShowDescription; }
	// Drop effects passed to DoDragDrop by drop source
	inline DROPEFFECT GetDropEffects() const { return m_nDropEffects; }

// 	bool SetFO_DROPDESCRIPTIONText(FO_DROPIMAGETYPE nType, LPCWSTR lpszText, 
// 		LPCWSTR lpszText1, LPCWSTR lpszInsert = NULL);

	bool SetDropInsertText(LPCWSTR lpszDropInsert);
// 	bool SetFO_DROPDESCRIPTION(FO_DROPIMAGETYPE nImageType, LPCWSTR lpszText, bool bCreate);
// 	bool SetFO_DROPDESCRIPTION(DROPEFFECT dwEffect);
// 	inline bool ClearFO_DROPDESCRIPTION()
// 	{ return SetFO_DROPDESCRIPTION(DROPIMAGE_INVALID, NULL, false); }

	// COleDataObject access functions.

	// Standard text formats
	UINT GetCodePage(COleDataObject* pDataObject, CLIPFORMAT cfFormat = CF_TEXT) const;
	CLIPFORMAT GetBestTextFormat(COleDataObject* pDataObject) const;
	LPTSTR GetString(CLIPFORMAT cfFormat, COleDataObject* pDataObject, UINT nCP = 0) const;
	LPTSTR GetText(COleDataObject* pDataObject) const;
	LPSTR  GetHtmlUtf8String(COleDataObject* pDataObject, bool bAll) const;
	LPTSTR GetHtmlString(COleDataObject* pDataObject, bool bAll) const;
	LPCSTR GetHtmlData(COleDataObject* pDataObject, size_t& nSize) const;

	size_t GetCharCount(COleDataObject* pDataObject, unsigned *pnLines) const;
	size_t GetCharCount(CLIPFORMAT cfFormat, COleDataObject* pDataObject, unsigned *pnLines, UINT nCP = 0) const;

	// CF_HDROP
	CString GetSingleFileName(COleDataObject* pDataObject) const;
	unsigned GetFileNameCount(COleDataObject* pDataObject) const;
	LPTSTR GetFileListAsText(COleDataObject* pDataObject) const;
	size_t GetFileListAsTextLength(COleDataObject* pDataObject, unsigned *pnLines) const;

	// Bitmaps
	HBITMAP GetBitmap(COleDataObject* pDataObject) const;
	HPALETTE GetPalette(COleDataObject* pDataObject) const;
	HBITMAP GetBitmapFromDDB(COleDataObject* pDataObject) const;
	HBITMAP GetBitmapFromDIB(COleDataObject* pDataObject) const;
	HBITMAP GetBitmapFromImage(COleDataObject* pDataObject) const;
	HBITMAP GetBitmapFromImage(COleDataObject* pDataObject, CLIPFORMAT cfFormat) const;
	HBITMAP GetDragImageBitmap(COleDataObject* pDataObject) const;

	LPVOID GetData(COleDataObject* pDataObject, CLIPFORMAT cfFormat, size_t& nSize, LPFORMATETC lpFormatEtc = NULL) const;
	HGLOBAL GetDataAsGlobal(COleDataObject* pDataObject, CLIPFORMAT cfFormat, size_t& nSize, LPFORMATETC lpFormatEtc /*= NULL*/) const;

protected:
	void		ClearStateFlags();
	void		OnPostDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	DROPEFFECT	DoDefaultScroll(CWnd *pWnd, DWORD dwKeyState, CPoint point);
	void		SetScrollPos(const CWnd* pWnd, int nStep, int nBar) const;


	size_t GetFileListAsTextLength(HDROP hDrop, unsigned& nLines) const;

protected:
	bool				m_bUseMsg;					// Call window handlers by sending messages
	unsigned			m_nScrollMode;				// Auto scroll handling
	FOIDropTargetHelper*	m_pDropTargetHelper;		// Drag image helper
	OnDragEnterFunc		m_pOnDragEnter;				// Callback function pointers
	OnDragOverFunc		m_pOnDragOver;
	OnDropExFunc		m_pOnDropEx;
	OnDropFunc			m_pOnDrop;
	OnDragLeaveFunc		m_pOnDragLeave;
	OnDragScrollFunc	m_pOnDragScroll;
	ScrollFunc			m_pScrollFunc;
//	CFO_DROPDESCRIPTION	m_FO_DROPDESCRIPTION;			// User defined default drop description text
private:
	bool				m_bCanShowDescription;		// Set when drop descriptions can be used (Vista or later)
	bool				m_bUseFO_DROPDESCRIPTION;		// If true, drop descriptions are updated by this class
	bool				m_bDescriptionUpdated;		// Internal flag to detect if drop description has been updated
	bool				m_bEntered;					// Set when entered the target. Use by OnDragScroll().
	bool				m_bHasDragImage;			// Cached "DragWindow" data object exists state
	bool				m_bTextAllowed;				// Cached "DragSourceHelperFlags" data object
	DROPEFFECT			m_nPreferredDropEffect;		// Cached "Preferred DropEffect" data object
	DROPEFFECT			m_nDropEffects;				// Drop effects passed to DoDragDrop

// Interface Maps
public:
	BEGIN_INTERFACE_PART(DropTargetEx, IDropTarget)
		INIT_INTERFACE_PART(CFOOleDropTargetEx, DropTargetEx)
		STDMETHOD(DragEnter)(LPDATAOBJECT, DWORD, POINTL, LPDWORD);
		STDMETHOD(DragOver)(DWORD, POINTL, LPDWORD);
		STDMETHOD(DragLeave)();
		STDMETHOD(Drop)(LPDATAOBJECT, DWORD, POINTL, LPDWORD);
	END_INTERFACE_PART(DropTargetEx)

	DECLARE_INTERFACE_MAP()

};

 
//===========================================================================
// Summary:
//     The CFODropSource class derived from COleDropSource
//      F O Drop Source
//===========================================================================

class FO_EXT_CLASS CFODropSource : public CFOOleDropSourceEx
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Source, Constructs a CFODropSource object.
	//		Returns A  value (Object).
	CFODropSource();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Source, Destructor of class CFODropSource
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropSource();

// Attributes
public:

	// Is Delete On Drop Or Not
 
	// Delete On Drop, This member sets TRUE if it is right.  
	BOOL	m_bDeleteOnDrop;

	// Is  Escape Pressed Or Not 
 
	// Escape Pressed, This member sets TRUE if it is right.  
	BOOL	m_bEscapePressed;

	// Is Drag Started Or Not
 
	// Drag Started, This member sets TRUE if it is right.  
	BOOL	m_bDragStarted;

	// Delete Cursor
 
	// Delete, This member specify HCURSOR object.  
	HCURSOR	m_hcurDelete;

	// Move Cursor
 
	// Move, This member specify HCURSOR object.  
	HCURSOR	m_hcurMove;

	// Copy Cursor
 
	// Copy, This member specify HCURSOR object.  
	HCURSOR	m_hcurCopy;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODropSource)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Give Feedback, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A SCODE value (Object).  
	// Parameters:
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).
	virtual SCODE GiveFeedback(DROPEFFECT dropEffect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Query Continue Drag, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A SCODE value (Object).  
	// Parameters:
	//		bEscapePressed---Escape Pressed, Specifies A Boolean value.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual SCODE QueryContinueDrag(BOOL bEscapePressed, DWORD dwKeyState);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Drag, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL OnBeginDrag(CWnd* pWnd);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFODropSource)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////////
//
// CFOViewDropSource
/////////////////////////////////////////////////////////////////////////////////

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOViewDropSource class derived from COleDropSource
//      F O View Drop Source
//===========================================================================

class FO_EXT_CLASS CFOViewDropSource : public COleDropSource
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O View Drop Source, Constructs a CFOViewDropSource object.
	//		Returns A  value (Object).
	CFOViewDropSource();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O View Drop Source, Destructor of class CFOViewDropSource
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOViewDropSource();

// Attributes
public:

	// Is Delete On Drop Or Not
 
	// Delete On Drop, This member sets TRUE if it is right.  
	BOOL	m_bDeleteOnDrop;

	// Is  Escape Pressed Or Not 
 
	// Escape Pressed, This member sets TRUE if it is right.  
	BOOL	m_bEscapePressed;

	// Is Drag Started Or Not
 
	// Drag Started, This member sets TRUE if it is right.  
	BOOL	m_bDragStarted;

	// Delete Cursor
 
	// Delete, This member specify HCURSOR object.  
	HCURSOR	m_hcurDelete;

	// Move Cursor
 
	// Move, This member specify HCURSOR object.  
	HCURSOR	m_hcurMove;

	// Copy Cursor
 
	// Copy, This member specify HCURSOR object.  
	HCURSOR	m_hcurCopy;

	// Pointer of the data model.
 
	// Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pDataModel;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOViewDropSource)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Give Feedback, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A SCODE value (Object).  
	// Parameters:
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).
	virtual SCODE GiveFeedback(DROPEFFECT dropEffect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Query Continue Drag, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A SCODE value (Object).  
	// Parameters:
	//		bEscapePressed---Escape Pressed, Specifies A Boolean value.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual SCODE QueryContinueDrag(BOOL bEscapePressed, DWORD dwKeyState);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Drag, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL OnBeginDrag(CWnd* pWnd);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOViewDropSource)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


#endif // !defined(AFX_FODROPSOURCE_H__971B27D6_F28B_11DD_A434_525400EA266C__INCLUDED_)
