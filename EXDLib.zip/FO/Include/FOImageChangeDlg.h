//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGECHANGEDLG_H__DCE06136_60B2_4952_B7AE_246EBB3E9585__INCLUDED_)
#define AFX_FOIMAGECHANGEDLG_H__DCE06136_60B2_4952_B7AE_246EBB3E9585__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageChangeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageChangeDlg WINDOW

#include "FOImageShape.h"
#include "FOImageButton.h"

///////////////////////////////////////////////////////////
// CFOPImageSample control

 
//===========================================================================
// Summary:
//     The CFOPImageSample class derived from CWnd
//      F O P Image Sample
//===========================================================================

class FO_EXT_CLASS CFOPImageSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image Sample, Constructs a CFOPImageSample object.
	//		Returns A  value (Object).
	CFOPImageSample();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPImageSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	// dwStyle -- style of the window.
	// rcPos -- position for the window
	// pParent -- pointer of the parent window
	// nID -- id value
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

	// Blue value
 
	// Blue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nBlue;

	// Bright value.
 
	// Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nBright;

	// Cont value.
 
	// Cont, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nCont;

	// Gamma value.
 
	// Gamma, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fGamma;

	// Green value
 
	// Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nGreen;

	// Red value
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRed;

	// pointer of the origin bitmap
 
	// Org Bitmap, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *			pOrgBitmap;

	// Drawing image.
 
	// Draw Image, This member specify FOImageObj object.  
	FOImageObj			m_DrawImage;

 
	// First, This member sets TRUE if it is right.  
	BOOL bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPImageSample)
	//}}AFX_VIRTUAL

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPImageSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////
// CFOImageChangeDlg Dialog

 
//===========================================================================
// Summary:
//     The CFOImageChangeDlg class derived from CDialog
//      F O Image Change Dialog
//===========================================================================

class FO_EXT_CLASS CFOImageChangeDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Change Dialog, Constructs a CFOImageChangeDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOImageChangeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOImageChangeDlg)
	enum { IDD = IDD_FO_IMAGE_CHANGE };
 
	// Slider Red, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderRed;
 
	// Slider Green, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderGreen;
 
	// Slider Gamma, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderGamma;
 
	// Slider Cont, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderCont;
 
	// Slider Bright, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderBright;
 
	// Slider Blue, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderBlue;
 
	// Blue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nBlue;
 
	// Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nBright;
 
	// Cont, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nCont;
 
	// Gamma, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fGamma;
 
	// Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nGreen;
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRed;
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Saved blue value
 
	// Old Blue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldBlue;

	// Saved bright value
 
	// Old Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldBright;

	// Saved cont value.
 
	// Old Cont, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldCont;

	// Saved gamma value
 
	// Old Gamma, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fOldGamma;

	// Saved green value
 
	// Old Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldGreen;

	// Saved red value.
 
	// Old Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldRed;

	// Sample window
 
	// Sample, This member specify E-XD++ CFOPImageSample object.  
	CFOPImageSample m_wndSample;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOImageChangeDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOImageChangeDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Blue, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageBlue(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Bright, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageBright(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Cont, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageCont(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Gamma, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageGamma(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Green, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageGreen(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Red, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageRed(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	// Note , following message is outside the AFX_MSG
	// block because the above block will be deleted and
	// recreated when you add new messages through the Wizard
	
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll Slider, Called when the user clicks the horizontal scroll bar of CWnd.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnHScrollSlider(WPARAM wParam, LPARAM lParam);

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGECHANGEDLG_H__DCE06136_60B2_4952_B7AE_246EBB3E9585__INCLUDED_)
