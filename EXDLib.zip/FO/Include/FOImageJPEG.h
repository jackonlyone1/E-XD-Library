//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEJPEG_H__01709443_6379_4984_9BF3_A765DDF4C193__INCLUDED_)
#define AFX_FOIMAGEJPEG_H__01709443_6379_4984_9BF3_A765DDF4C193__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageJPEG.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageJPEG window

#include "FOBitmap.h"
#include "FOGlobals.h"

 
//===========================================================================
// Summary:
//     The CFOImageJPEG class derived from CFOBitmap
//      F O Image J P E G
//===========================================================================

class FO_EXT_CLASS CFOImageJPEG : public CFOBitmap
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageJPEG---F O Image J P E G, Specifies a E-XD++ CFOImageJPEG object (Value).
    DECLARE_SERIAL(CFOImageJPEG)
		
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image J P E G, Constructs a CFOImageJPEG object.
	//		Returns A  value (Object).
	CFOImageJPEG();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image J P E G, Destructor of class CFOImageJPEG
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOImageJPEG();

public:
	// Save document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    void Serialize(CArchive &ar);
	// Operations

	
	//-----------------------------------------------------------------------
	// Summary:
	// Decode, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).  
	//		*pImage---*pImage, A pointer to the CFOBitmap  or NULL if the call failed.
	// Decode jpeg image file.
	bool Decode(CFODataReadBase &reader, CFOBitmap *pImage);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID,LPCTSTR pcszResourceType);

	// load icon file
	// strFileName -- file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);

};

/////////////////////////////////////////////////////////////////////////////
// CFODrawImageJPEG

 
//===========================================================================
// Summary:
//     The CFODrawImageJPEG class derived from CFODrawImage
//      F O Draw Image J P E G
//===========================================================================

class FO_EXT_CLASS CFODrawImageJPEG : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImageJPEG---F O Draw Image J P E G, Specifies a E-XD++ CFODrawImageJPEG object (Value).
	DECLARE_SERIAL(CFODrawImageJPEG)
public:

	// Image pointer.
 
	// Image J P E G, This member specify E-XD++ CFOImageJPEG object.  
	CFOImageJPEG m_ImageJPEG;

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap() { return &m_ImageJPEG; }


public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image J P E G, Constructs a CFODrawImageJPEG object.
	//		Returns A  value (Object).
	CFODrawImageJPEG();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image J P E G, Destructor of class CFODrawImageJPEG
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImageJPEG();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImageJPEG &target object(Value).
	virtual BOOL operator==(const CFODrawImageJPEG &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CFOPImageTransDrawHelper

 
//===========================================================================
// Summary:
//     The CFOPImageTransDrawHelper class derived from CObject
//      F O P Image Transparent Draw Helper
//===========================================================================

class FO_EXT_CLASS CFOPImageTransDrawHelper : public CObject
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image Transparent Draw Helper, Constructs a CFOPImageTransDrawHelper object.
	//		Returns A  value (Object).
	CFOPImageTransDrawHelper();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Image Transparent Draw Helper, Destructor of class CFOPImageTransDrawHelper
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPImageTransDrawHelper();

// Operations:
public:

	// Change image item size.
	// sz -- size of the image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Size, Sets a specify value to current class CFOPImageTransDrawHelper
	// Parameters:
	//		sz---Specifies A CSize type value.
	void SetImageSize(const CSize& sz) { m_szImage = sz; }

	// Obtain the image item size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Size, Returns the specified value.
	//		Returns A SIZE value (Object).  
	// Parameters:
	//		bDest---bDest, Specifies A Boolean value.
	SIZE GetImageSize(BOOL bDest = FALSE) const	{ return bDest ? m_szImageDest : m_szImage; }
	
	// Obtain the count of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Count, Returns the specified value.
	//		Returns a int type value.
	int GetImageCount() const {	return m_nImageCount; }

	// Change the transparent color.
	// crTrans -- transparent color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent Color, Sets a specify value to current class CFOPImageTransDrawHelper
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		&crTrans---&crTrans, Specifies A 32-bit COLORREF value used as a color value.
	COLORREF SetTransparentColor(const COLORREF &crTrans);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uiResID---Resource I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		hinstRes---hinstRes, Specifies a HINSTANCE hinstRes = NULL object(Value).  
	//		bAdd---bAdd, Specifies A Boolean value.
	// Load from resource
	// uiResID -- resource ID
	BOOL Load(UINT uiResID, HINSTANCE hinstRes = NULL, BOOL bAdd = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszBmpFileName---Bitmap File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Load from bitmap resource file
	BOOL Load(LPCTSTR lpszBmpFileName);

	// Is valid or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValidate() const;

	// Prepare draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Draw, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ds---Specifies a FOP_IMAGEDATA& ds object(Value).  
	//		&szImage---&szImage, Specifies A CSize type value.  
	//		0)---Specifies a 0) object(Value).  
	//		bFade---bFade, Specifies A Boolean value.
	BOOL PrepareDraw(FOP_IMAGEDATA& ds,const CSize &szImage = CSize(0, 0),BOOL bFade = FALSE);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		iImageIndex---Image Index, Specifies A integer value.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		bLight---bLight, Specifies A Boolean value.  
	//		bDisabled---bDisabled, Specifies A Boolean value.  
	//		bIndeterminate---bIndeterminate, Specifies A Boolean value.  
	//		bShadow---bShadow, Specifies A Boolean value.  
	//		bInactive---bInactive, Specifies A Boolean value.
	BOOL DoDraw(CDC* pDC, 
				int x, int y,
				int iImageIndex,
				COLORREF crText,
				BOOL bLight = FALSE, 
				BOOL bDisabled = FALSE,
				BOOL bIndeterminate = FALSE,
				BOOL bShadow = FALSE,
				BOOL bInactive = FALSE);

	// End draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Draw, .
	// Parameters:
	//		ds---Specifies a FOP_IMAGEDATA& ds object(Value).
	void EndDraw(FOP_IMAGEDATA& ds);

	// Gray rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Gray Rectangle, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		nPercentage---nPercentage, Specifies A integer value.  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.
	BOOL DrawGrayRect(CDC *pDC,	CRect rect,int nPercentage = -1,COLORREF crTransparent = (COLORREF)-1);

	// High light rectangle.
	BOOL DrawLightRect(CDC *pDC,CRect rect,
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		COLORREF)-1---O L O R R E F)-1, Specifies A 32-bit COLORREF value used as a color value.
						int nPercentage = -1,
						COLORREF crTrans = (COLORREF)-1,
						int nTolerance = 0,
						COLORREF clrBlend =(COLORREF)-1);

	// Add bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		hbmp---Specifies a HBITMAP hbmp object(Value).  
	//		bSetBitPerPixel---Set Bit Per Pixel, Specifies A Boolean value.
	int AddImage(HBITMAP hbmp, BOOL bSetBitPerPixel = FALSE);

	// Add icon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Icon, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).  
	//		bAlphaBlend---Alpha Blend, Specifies A Boolean value.
	int AddIcon(HICON hIcon, BOOL bAlphaBlend = FALSE);

	// Update image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Image, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nImage---&nImage, Specifies A integer value.  
	//		hbmp---Specifies a HBITMAP hbmp object(Value).
	BOOL UpdateImage(const int &nImage, HBITMAP hbmp);

	// Delete image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Image, Deletes the given object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nImage---&nImage, Specifies A integer value.
	BOOL DeleteImage(const int &nImage);

	// Extract icon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extract Icon, .
	//		Returns A HICON value (Object).  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	HICON ExtractIcon(const int &nIndex);

	// Create from image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image List, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		imageList---imageList, Specifies a const CImageList& imageList object(Value).
	BOOL AddImageList(const CImageList& imageList);

	// Gray images
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Gray, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nGrayPercentage---Gray Percentage, Specifies A integer value.
	BOOL DoGray(int nGrayPercentage);

	// Sys color change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update System Color, Call this member function to update the object.

	void UpdateSysColor();

	// Map colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Map Color, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bUseRGBQUAD---Use R G B Q U A D, Specifies A Boolean value.  
	//		clrSrc---clrSrc, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrDest---clrDest, Specifies A 32-bit COLORREF value used as a color value.
	BOOL DoMapColor(BOOL bUseRGBQUAD = TRUE,COLORREF clrSrc =(COLORREF)-1,COLORREF clrDest =(COLORREF)-1);

	// Clean up
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clean Up, .
	// This member function is a static function.
	static void CleanUp();

	// RTL support or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable R T L, Call this member function to enable or disable the specify object for this command.
	// This member function is a static function.
	// Parameters:
	//		bIsRTL---Is R T L, Specifies A Boolean value.
	static void EnableRTL(BOOL bIsRTL = TRUE);

	// Is RTL support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is R T L, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	static BOOL IsRTL()	{ return m_bIsRTL; }

	// Clear all the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty, .

	void Empty();

	// Obtain bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	//		Returns A HBITMAP value (Object).
	HBITMAP GetBitmap();

protected:

	// Res ids
	CList<UINT, UINT>	m_lstOrigResIds;

	// list of res instances
	CList<HINSTANCE, HINSTANCE>	m_lstOrigResInstances;

	// map of res
	CMap<UINT, UINT, int, int> m_mapOrigResOffsets;

protected:
	
	// Transparent blt.
	static void DrawTransparent(HDC hdcDest, int nXDest, int nYDest, int nWidth, 
								int nHeight, CDC* pDcSrc, int nXSrc, int nYSrc,
								COLORREF crTransparent,COLORREF crText = RGB(255,255,255),
								int nWidthDest = -1, int nHeightDest = -1);
protected:

	// Create mask
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Mask Bitmap, .
	// Parameters:
	//		&nImage---&nImage, Specifies A integer value.  
	//		bHilite---bHilite, Specifies A Boolean value.  
	//		bHiliteShadow---Hilite Shadow, Specifies A Boolean value.
	void GenMaskBmp(const int &nImage,BOOL bHilite,BOOL bHiliteShadow);

	// Update image count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Calculate Images, .

	void ReCalcImages();

	// Update light image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh Light, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL RefreshLight();

	// Pre multiply alpha
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Alpha, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hbmp---Specifies a HBITMAP hbmp object(Value).
	BOOL PrepareAlpha(HBITMAP hbmp);

	// Map bitmap to colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Map Bitmap Color, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hBmp---hBmp, Specifies a HBITMAP& hBmp object(Value).  
	//		bUseRGBQUAD---Use R G B Q U A D, Specifies A Boolean value.  
	//		crSrc---crSrc, Specifies A 32-bit COLORREF value used as a color value.  
	//		crDest---crDest, Specifies A 32-bit COLORREF value used as a color value.
	static BOOL MapBmpColor(HBITMAP& hBmp, BOOL bUseRGBQUAD = TRUE,COLORREF crSrc =(COLORREF)-1,COLORREF crDest =(COLORREF)-1);

protected:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes:
protected:
	// Size of image
 
	// Image, This member sets a CSize value.  
	CSize				m_szImage;

	// Size of dest image
 
	// Image Dest, This member sets a CSize value.  
	CSize				m_szImageDest;

	// Bitmap handle
 
	// Bitmap Well, This member specify HBITMAP object.  
	HBITMAP				m_hBmpWell;

	// Bitmap handle
 
	// Bitmap Light, This member specify HBITMAP object.  
	HBITMAP				m_hBmpLight;

	// Use image list or not
 
	// Image List, This member sets TRUE if it is right.  
	BOOL				m_bImageList;

	// Memory dc handle
 
	// Memory Buffer, This member specify CDC object.  
	CDC					m_dcMemBuffer;

	// Memory bitmap handle
 
	// Memory, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap				m_bmpMemory;

	// Original bitmap pointer.
 
	// Bitmap Save, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*			m_pBitmapSave;

	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crTrans;
	
	// Gray percent.
 
	// Gray Percent, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nGrayPercent;

	// Enable RTL or not.
 
	// Is R T L, This member sets TRUE if it is right.  
	static BOOL			m_bIsRTL;

	// UDL Path
 
	// U D L Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strUDLPath;
	
	// Count of images
 
	// Image Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nImageCount;

	// Color or shadow.
 
	// Shadow, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crShadow;

	// Fade inactive or not
 
	// In Fade, This member sets TRUE if it is right.  
	BOOL				m_bInFade;

	// Bits pixel
 
	// Bits Per Pixel, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nBitsPerPixel;

	// MSI MG DLL
 
	// Dll M S I, This member specify HINSTANCE object.  
	static HINSTANCE	m_hDllMSI;

	// Alpha blend
 
	// Alpha Blend, This member specify FOPALPHABLEND object.  
	static FOPALPHABLEND	m_pfAlphaBlend;

	// Is gray or not
 
	// Is Gray, This member sets TRUE if it is right.  
	BOOL				m_bIsGray;

	// Stretch or not
 
	// Stretch, This member sets TRUE if it is right.  
	BOOL				m_bStretch;
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEJPEG_H__01709443_6379_4984_9BF3_A765DDF4C193__INCLUDED_)
