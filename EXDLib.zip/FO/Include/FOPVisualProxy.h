//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPVISUALPROXY_H__700783E5_CB1B_41BB_AE5B_4F4288B61FF4__INCLUDED_)
#define FO_FOPVISUALPROXY_H__700783E5_CB1B_41BB_AE5B_4F4288B61FF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: ucancode software.
//------------------------------------------------------

// Default date time format.
const CString foDefaultDateFormat =			_T("##/##/####");
#include "FOPLineInfo.h"
#include "FOPPolygon.h"
#include "FOScaleUint.h"
#include "FODefines.h"
#include "FOPSimplePolygon.h"
#include "FOBitmap.h"
#include "FOBaseProperties.h"

class CFODrawShape;
#define FOP_CUSTOM_GRADIENT_TYPE		110

typedef BOOL (__stdcall * FOPALPHABLEND)(HDC,int,int,int,int,HDC,int,int,int,int,BLENDFUNCTION);

// Default port scale values
struct FOP_PortScale
{
	double xScale; // The scale value of the x direction,range (0.0 - 1.0)
	double yScale; // The scale value of the y direction,range (0,0 - 1.0)
};


// Default port scale values
struct FOP_CUST_PROP
{
	int nPropId; // The id of custom property.
	FO_VALUE valDefault; // Default value type and value.
	CString strName;
};


// Default port scale values
struct FOP_PROP_DESC
{
	int nPropId; // The id of custom property.
	CString strTip; // Default value type and value.
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPLineParam,this class is used for generate the dash line.
/////////////////////////////////////////////////////////////////////////////////

class CFOPortShape;
class CFOPHandle;
class CFOPHandleList;
 
//===========================================================================
// Summary:
//      To use a FOPLineParam object, just call the constructor.
//      O P Line Parameter
//===========================================================================

class FO_EXT_CLASS FOPLineParam
{
public:
	// Line pattern
 
	// Pattern Segement, Specify a A 32-bit signed integer.  
	long		m_nPatSegement;

	// Line remain pattern
 
	// Pattern Remain, Specify a A 32-bit signed integer.  
	long		m_nPatRemain;

	// Has Join or not
 
	// Has Join, This member sets TRUE if it is right.  
	BOOL		m_bHasJoin;

	// Use join or not
 
	// Use Join, This member sets TRUE if it is right.  
	BOOL		m_bUseJoin;

	// First join point.
 
	// First Join, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint	m_ptFirstJoin;

	// Second join point
 
	// Second Join, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint	m_ptSecondJoin;

	// Third join point
 
	// Third Join, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint	m_ptThirdJoin;

	// Length
 
	// Line Length, This member specify double object.  
	double		m_dLineLength;

	// x value of line
 
	// Line Dx, Specify a A 32-bit signed integer.  
	long		m_nLineDx;

	// x value of line
 
	// Line Dy, Specify a A 32-bit signed integer.  
	long		m_nLineDy;

	// W value of line
 
	// Dx W, Specify a A 32-bit signed integer.  
	long		m_nDxW;

	// H value of line
 
	// Dy W, Specify a A 32-bit signed integer.  
	long		m_nDyW;

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Parameter, Constructs a FOPLineParam object.
	//		Returns A  value (Object).
	FOPLineParam()	{}

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Parameter, Destructor of class FOPLineParam
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPLineParam() {}

	//-----------------------------------------------------------------------
	// Summary:
	// Init data of the line.
	// ptP1 -- starting point of the line.
	// ptP2 -- end point of the line.
	// nWidth -- width of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Data, Call InitData after creating a new object.
	// Parameters:
	//		ptP1---ptP1, Specifies A integer value.  
	//		ptP2---ptP2, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	void InitData(const FOPPoint& ptP1, const FOPPoint& ptP2, long nWidth);
};

////////////////////////////////////////////////
// CFOPBitmapData -- bitmap data object.

 
//===========================================================================
// Summary:
//      To use a CFOPBitmapData object, just call the constructor.
//      F O P Bitmap Data
//===========================================================================

class FO_EXT_CLASS CFOPBitmapData
{
protected:
	// pointer to the bitmap
 
	// The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap *		m_bitmap; 

	// ID
 
	// I D, Specify a A 32-bit signed integer.  
	long			m_ID;

	// Resource string.
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strid;

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Bitmap Data, Constructs a CFOPBitmapData object.
	//		Returns A  value (Object).
	CFOPBitmapData();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Bitmap Data, Destructor of class CFOPBitmapData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPBitmapData();

public:
	// Change Id of bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set I D, Sets a specify value to current class CFOPBitmapData
	// Parameters:
	//		ID---D, Specifies A 32-bit long signed integer.
	void SetID(long ID) { m_ID = ID; }

	// Obtain ID of bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetID() { return m_ID; }

	// Obtain the pointer of bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap ,or NULL if the call failed
	CBitmap *GetBitmap();

	// Change the pointer of bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap, Sets a specify value to current class CFOPBitmapData
	// Parameters:
	//		*pBitmap---*pBitmap, A pointer to the CBitmap  or NULL if the call failed.
	void SetBitmap(CBitmap *pBitmap);

	// Change bitmap resource string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set String I D, Sets a specify value to current class CFOPBitmapData
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetStrID(const CString &str) { strid = str; }

	// Obtain bitmap resource string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String I D, Returns the specified value.
	//		Returns a CString type value.
	CString GetStrID() { return strid; }

	// image list.
 
	// List, This member is a collection of same-sized images.  
	CImageList		m_imageList;
};

////////////////////////////////////////////////
// CFOPImageListData -- image list data.

 
//===========================================================================
// Summary:
//      To use a CFOPImageListData object, just call the constructor.
//      F O P Image List Data
//===========================================================================

class FO_EXT_CLASS CFOPImageListData
{
protected:
	//pointer to the image list
 
	// This member is a collection of same-sized images.  
	CImageList * m_imagelist; 

	// ID.
 
	// I D, Specify a A 32-bit signed integer.  
	long		 m_ID;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construtor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image List Data, Constructs a CFOPImageListData object.
	//		Returns A  value (Object).
	CFOPImageListData() { m_ID = 0; m_imagelist = NULL; }

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Image List Data, Destructor of class CFOPImageListData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPImageListData() { if(m_imagelist != NULL) delete m_imagelist; m_imagelist = NULL; }

public:
	// Change resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set I D, Sets a specify value to current class CFOPImageListData
	// Parameters:
	//		ID---D, Specifies A 32-bit long signed integer.
	void SetID(long ID) { m_ID = ID; }

	// Obtain resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetID() { return m_ID; }

	// Obtain image list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List, Returns the specified value.
	//		Returns a pointer to the object CImageList ,or NULL if the call failed
	CImageList *GetImageList() 
	{ 
		if(m_imagelist == NULL)
			m_imagelist = new CImageList;

		return m_imagelist; 
	}

	//	Sets new image list as a source of images to be displayed in the 
	//	list box. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image List, Sets a specify value to current class CFOPImageListData
	//		Returns a int type value.  
	// Parameters:
	//		pImageList---Image List, A pointer to the CImageList or NULL if the call failed.
	int SetImageList(CImageList* pImageList);

	// Adds new images to be displayed in the list box. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image List, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		pImageList---Image List, A pointer to the CImageList or NULL if the call failed.
	int AddImageList(CImageList* pImageList);

	// Add image to image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		bmpAdd---bmpAdd, A pointer to the CBitmap or NULL if the call failed.  
	//		bmpMask---bmpMask, A pointer to the CBitmap or NULL if the call failed.
	int AddImage(CBitmap* bmpAdd, CBitmap* bmpMask);

	// Add image to image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		bmpAdd---bmpAdd, A pointer to the CBitmap or NULL if the call failed.  
	//		crMask---crMask, Specifies A 32-bit COLORREF value used as a color value.
	int AddImage(CBitmap* bmpAdd, COLORREF crMask);

	// Add image to image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	int AddImage(HICON hIcon);

	// Replaces an image in the internal image list with a new image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Image, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		bmpReplace---bmpReplace, A pointer to the CBitmap or NULL if the call failed.  
	//		pbmMask---pbmMask, A pointer to the CBitmap or NULL if the call failed.
	BOOL ReplaceImage(int nImage, CBitmap* bmpReplace, CBitmap* pbmMask=NULL);

	// Replaces an image in the internal image list with a new image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Image, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	BOOL ReplaceImage(int nImage, HICON hIcon);

	// Retrieves information about an image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Information, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.  
	//		pImageInfo---Image Information, A pointer to the IMAGEINFO or NULL if the call failed.
	BOOL GetImageInfo(int nImage, IMAGEINFO* pImageInfo) const;

	// Creates an icon based on an image and its related mask in the 
	// internal image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Icon, Returns the specified value.
	//		Returns A HICON value (Object).  
	// Parameters:
	//		nImage---nImage, Specifies A integer value.
	HICON GetIcon(int nImage);

	// Image width
 
	// Current Image Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nCurImageWidth;

	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTransparent;
};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOPVisualProxy -- visual proxy, with this class, all the drawing features of E-XD++ can be customized.
//					  See sample, VisioApp.
/////////////////////////////////////////////////////////////////////////////////
typedef BOOL (__stdcall * FOP_TRANSPARENTBLT)(HDC hdcDest, int xDest, int yDest, int nDestWidth, int nDestHeight,
										  HDC hdcSrc, int xSrc, int ySrc, int nSrcWidth, int nSrcHeight, 
										  UINT clrTransparent);

typedef BOOL (__stdcall* FOP_PFNGRADIENTFILL)(HDC, PTRIVERTEX, ULONG, PVOID, ULONG, ULONG);


#ifndef _UXTHEME_H_

// From uxtheme.h:
// This is the handle of Theme
typedef HANDLE HTHEME;          
#endif // THEMEAPI

// Handle for paint buffer.
typedef HANDLE FOP_HPAINTBUFFER;
typedef HRESULT (__stdcall * FOP_DRAWTHEMEPARENTBACKGROUND)(HWND hWnd, HDC hdc,const RECT *pRec);

// FOP_BP_BUFFERFORMAT
typedef enum _FOP_BP_BUFFERFORMAT
{
	// Compatible bitmap.
    FOP_BPBF_COMPATIBLEBITMAP,    // Compatible bitmap
		// Dib
		FOP_BPBF_DIB,                 // Device-independent bitmap

		// Top down dib
		FOP_BPBF_TOPDOWNDIB,

		// Top down monochrome dib.
		FOP_BPBF_TOPDOWNMONODIB
} FOP_BP_BUFFERFORMAT;

// Buffer composited.
#define FOP_BP_BUFFERFORMATBPBF_COMPOSITED FOP_BP_BUFFERFORMATBPBF_DIB

// Paint params
typedef struct _FOP_BP_PAINTPARAMS
{
	// Size.
    DWORD                       cbSize;

	// Flags.
    DWORD                       dwFlags;

	// Exclude
    const RECT *                prcExclude;

	// Blend function.
    const BLENDFUNCTION *       pBlendFunction;
} FOP_BP_PAINTPARAMS;

// Callback process.
typedef int (WINAPI *FOPDTT_CALLBACK_PROC)
(
 HDC							hdc,
 LPWSTR							pszText,
 int							cchText,
 LPRECT							prc,
 UINT							dwFlags,
 LPARAM							lParam
 );

// DT Top ts.
typedef struct _FOPDTTOPTS 
{
    DWORD						dwSize;
    DWORD						dwFlags;
    COLORREF					crText;
    COLORREF					crBorder;
    COLORREF					crShadow;
    int							iTextShadowType;
    POINT						ptShadowOffset;
    int							iBorderSize;
    int							iFontPropId;
    int							iColorPropId;
    int							iStateId;
    BOOL						fApplyOverlay;
    int							iGlowSize;
    FOPDTT_CALLBACK_PROC		pfnDrawTextCallback;
    LPARAM						lParam;
} FOPDTTOPTS;

// BeginBufferedPaint.
typedef FOP_HPAINTBUFFER (__stdcall * FOP_BEGINBUFFEREDPAINT)(	HDC hdcTarget, const RECT* rcTarget, FOP_BP_BUFFERFORMAT dwFormat, FOP_BP_PAINTPARAMS *pPaintParams, HDC *phdc);

// Buffered paint.
typedef HRESULT (__stdcall *	FOP_BUFFEREDPAINTSETALPHA)(FOP_HPAINTBUFFER hBufferedPaint, const RECT *prc, BYTE alpha);

// End buffered paint.
typedef HRESULT (__stdcall *	FOP_ENDBUFFEREDPAINT)(FOP_HPAINTBUFFER hBufferedPaint, BOOL fUpdateTarget);

// Draw theme text.
typedef HRESULT (__stdcall *	FOP_DRAWTHEMETEXTEX)(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, DWORD dwFlags, LPRECT pRect, const FOPDTTOPTS *pOptions);

// Draw theme icon.
typedef HRESULT (__stdcall *	FOP_DRAWTHEMEICON)(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, HIMAGELIST himl, int iImageIndex);
typedef HTHEME (__stdcall *		FOP_OPENTHEMEDATA)(HWND hwnd, LPCWSTR pszClassList);
typedef HRESULT (__stdcall *	FOP_CLOSETHEMEDATA)(HTHEME hTheme);
//===========================================================================
// Summary:
//     The CFOPVisualProxy class derived from CObject
//      F O P Visual Proxy
//===========================================================================

class FO_EXT_CLASS CFOPVisualProxy : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPVisualProxy---F O P Visual Proxy, Specifies a E-XD++ CFOPVisualProxy object (Value).
	DECLARE_DYNCREATE(CFOPVisualProxy);
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Visual Proxy, Constructs a CFOPVisualProxy object.
	//		Returns A  value (Object).
	CFOPVisualProxy();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Visual Proxy, Destructor of class CFOPVisualProxy
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPVisualProxy();

	//-----------------------------------------------------------------------
	// Summary:
	// Get instance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPVisualProxy,or NULL if the call failed
	static CFOPVisualProxy* GetInstance();

	//-----------------------------------------------------------------------
	// Summary:
	// Create visual proxy.
	// pVisualProxy -- proxy of the class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Visual Proxy, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pVisualProxy---Visual Proxy, A pointer to the CRuntimeClass or NULL if the call failed.
	static BOOL ChangeVisualProxy(CRuntimeClass* pVisualProxy);

	//-----------------------------------------------------------------------
	// Summary:
	// Destroy instance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Instance, Call this function to destroy an existing object.
	// This member function is a static function.
	static void DestroyInstance();

	//-----------------------------------------------------------------------
	// Summary:
	// Input transparent value.
	// nTrans -- transparent value from 0-255
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Transparent, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.
	virtual void PrepareTransparent(const BYTE &nTrans);

	//-----------------------------------------------------------------------
	// Summary:
	// Input transparent value.
	// nTrans -- transparent value from 0-255
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Transparent, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.
	virtual void PrepareTransX(const BYTE &nTrans);

	//-----------------------------------------------------------------------
	// Summary:
	// Prepare gradient value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Gradient, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&grad---Specifies a const FOPGradient &grad object(Value).
	virtual void PrepareGradient(const FOPGradient &grad);

	//-----------------------------------------------------------------------
	// Summary:
	// Is gdi plus or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is G D I Plus, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsGDIPlus();

	// ----------------------------------------------------------------------
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPVisualProxy object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bWithGDIPlus---With G D I Plus, Specifies A Boolean value.
	// Create draw context.
	virtual void Create(const BOOL &bWithGDIPlus);
	
	// Attach DC.
	virtual void AttachDC(CDC* pDC);

	// Obtain dc.
	CDC *GetDC();

	// ----------------------------------------------------------------------
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release C, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseC();

	// Obtain GDI+ Drawing state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get G D I Plus, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetGDIPlus();

	// Create gradient handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild, .

	void Rebuild();

public:
	/*************************************************************************
	|*
	|* Override the following methods to handle your own fill type.
	|* You can SetBrushType(...) that defined within class CFODrawShape to change the fill type.
	|*
	\************************************************************************/
	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Close Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillCloseBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillPoly(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillPolyGradient(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,const FOPGradient &aXGradient);

	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void XFillPoly(CDC *pDC,FOPFloat* points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void XFillPolyGradient(CDC *pDC,FOPFloat* points,int nCount,COLORREF crStart,COLORREF crEnd,const FOPGradient &aXGradient);


	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		lpPolyCounts---Polygon Counts, Specifies a LPINT lpPolyCounts object(Value).  
	//		nCount---nCount, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual BOOL FillPolyPolygon(CDC *pDC,LPPOINT points,LPINT lpPolyCounts,int nCount,
		const CRect &rcPos,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fills the can shape held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Can Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillCanShape(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill rectangle.
	// pDC-- pointer of DC
	// rc -- rectangle of round rect.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies a FOPRect rc object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillRect(CDC *pDC, FOPRect rc,	COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill round rectangle.
	// pDC-- pointer of DC
	// rc -- rectangle of round rect.
	// ptCorner -- radius of corner
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Round Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		&ptCorner---&ptCorner, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillRoundRect(CDC *pDC, const FOPRect &rc, const FOPPoint &ptCorner,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill ellipse.
	// pDC-- pointer of DC
	// rc -- rectangle of ellipse.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Ellipse, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillEllipse(CDC *pDC, const FOPRect &rc, COLORREF crStart,COLORREF crEnd,
		UINT nFillType,CBrush *pBrush);

	// Do draw upright circle.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	virtual BOOL FillCircle(CDC *pDC, const CRect &rcPos, COLORREF crStart, COLORREF crEnd, UINT nFillType, CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fill with a simple polygon.
	// pDC-- pointer of DC
	// poly -- poly.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Simple Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rRect1---&rRect1, Specifies a const FOPRect &rRect1 object(Value).  
	//		*poly---A pointer to the FOPSimplePolygon  or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillSimplePolygon(CDC *pDC, const FOPRect &rRect1, const FOPSimplePolygon &poly,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Draw meter ellipse border.
	virtual BOOL DrawMeterEllipseBorder(CDC *pDC, const FOPRect &rcOut, const int &nBorderSize = 6,
		COLORREF crStart = RGB(255,255,255), COLORREF crEnd = RGB(191,191,191), BOOL bHorz = TRUE);

public:

	/*************************************************************************
	|*
	|* Other methods you can override to handle your GUI look!
	|*
	\************************************************************************/

	//--(GDI+ SUPPORTS)---
	// Draw helper functions.
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Shadow Close Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillShadowCloseBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CPoint ptOffset,CBrush *pBrush);
	
	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Shadow Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillShadowPoly(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CPoint ptOffset,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Shadow Polygon Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		lpPolyCounts---Polygon Counts, Specifies a LPINT lpPolyCounts object(Value).  
	//		nCount---nCount, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual BOOL FillShadowPolyPolygon(CDC *pDC,LPPOINT points,LPINT lpPolyCounts,int nCount,const CRect &rcPos,COLORREF crStart,COLORREF crEnd,UINT nFillType,CPoint ptOffset,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Fills a polygon held in an array of points according to a style
	// points -- the points of paint area.
	// nCount -- the count of points of paint area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Shadow Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void FillShadowBezier(CDC *pDC,LPPOINT points,int nCount,COLORREF crStart,COLORREF crEnd,UINT nFillType,CPoint ptOffset,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Draw Polygon.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolygon(CDC *pDC,LPPOINT points,int nCount);

	//--(GDI+ SUPPORTS)---
	// Draw Polygon.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void XDoDrawPolygon(CDC *pDC,FOPFloat* points,int nCount);

	//--(GDI+ SUPPORTS)---
	// Do draw polygon.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawArrowPolygon(CDC *pDC,LPPOINT points,int nCount,const COLORREF &crFill);

	//--(GDI+ SUPPORTS)---
	// Draw ring with angle.
	// pDC -- pointer of the DC.
	// rcBound -- bounding rectangle
	// innerRadius -- inner radius.
	// start angle -- start angle.
	// angles -- angles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ring, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcBound---&rcBound, Specifies A CRect type value.  
	//		innerRadius---innerRadius, Specifies A integer value.  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		angles---Specifies a double angles object(Value).
	virtual void DoDrawRing(CDC *pDC, const CRect &rcBound,
        int innerRadius,
        double startAngle,
        double angles);

	//--(GDI+ SUPPORTS)---
	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Polygon Draw, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the POINT or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the BYTE or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	ExtPolyDraw(CDC *pDC,
		const CRect &rcPos,
		ULONG nPoints, 
		POINT* pPtAry,
		BYTE* pFlgAry,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);


	//--(GDI+ SUPPORTS)---
	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Polygon Draw, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the POINT or NULL if the call failed.  
	//		lpbTypes---Flag Array, A pointer to the BYTE or NULL if the call failed.  
	//      cCount -- point count
	//      bClose -- close or not
    virtual BOOL	ExtPolyDrawLine(CDC *pDC, CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount, const BOOL &bClose);
	
	//--(GDI+ SUPPORTS)---
	// Do draw polypolygon bezier.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoly -- count of the poly for drawing.
	// nPoints -- count of the points.
	// pPoints -- points count
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon Polygon Bezier, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoly---nPoly, Specifies A 32-bit LONG signed integer.  
	//		pPoints---pPoints, A pointer to the const ULONG or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt* const or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE* const or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	DrawPolyPolygonBezier(CDC *pDC,
		const CRect &rcPos,
		ULONG nPoly, 
		const ULONG* pPoints, 
		const fopPointExt* const* pPtAry, 
		const BYTE* const* pFlgAry,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);
	
	//--(GDI+ SUPPORTS)---
	// Do draw polypolygon bezier.
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoly -- count of the poly for drawing.
	// nPoints -- count of the points.
	// rPolyPoly -- object of the composite polygon
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill New Polygon Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoly---nPoly, Specifies a USHORT nPoly object(Value).  
	//		rPolyPoly---Polygon Polygon, Specifies a const FOPSimpleCompositePolygon& rPolyPoly object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual BOOL	FillNewPolyPolygon(CDC *pDC, 
		const CRect &rcPos,
		USHORT nPoly, 
		const FOPSimpleCompositePolygon& rPolyPoly,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);

	
	//--(GDI+ SUPPORTS)---
	// Do fill polygon.
	// pts -- points.
	// nCount -- count of points
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pts---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_FillPolygon(CDC *pDC, POINT* pts, int nCount,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Do fill ellipse.
	// lpRect -- rectangle.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Ellipse, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_Ellipse(CDC *pDC, LPCRECT lpRect,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Do fill rectangle.
	// lpRect -- rectangle.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_Rect(CDC *pDC, LPCRECT lpRect,const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Do fill round rectangle.
	// lpRect -- rectangle.
	// ptCorner -- corner point.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_RoundRect(CDC *pDC, LPCRECT lpRect,CPoint ptCorner, const COLORREF &crFill, const BOOL &bNullBrush = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Draw curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// pTypes -- types.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		pTypes---pTypes, A pointer to the BYTE or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void S_DrawCurve(CDC *pDC, POINT* lppt, BYTE* pTypes, int nCount, const BOOL &bClose = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Draw close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// pTypes -- types.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		pTypes---pTypes, A pointer to the BYTE or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void S_DrawCloseCurve(CDC *pDC, POINT* lppt, BYTE* pTypes, int nCount, const CRect &rcPos, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Draw close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void DoDrawExtCloseCurve(CDC *pDC, POINT* lppt, int nCount, const CRect &rcPos,COLORREF crStart,
		COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	//--(GDI+ SUPPORTS)---
	// Draw track close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	virtual void DoDrawExtTrackCurve(CDC *pDC, POINT* lppt, int nCount);

	//--(GDI+ SUPPORTS)---
	// Draw track close curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Close Curve, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	virtual void DoDrawExtTrackCurveCAD(CDC *pDC, POINT* lppt, int nCount);

	// Generate close curve points.
	virtual void GenSplinePoints(LPPOINT lpShapePoints, int nPointCount, 
		LPPOINT& lpSplinePoints, int& nSpPtCount);

public:
	// Added up v17.0.

	// draw poly polygon.
	virtual void fDrawPolyPolygon(CDC *pDC, int nPoly, const int* pPoints,
								   fopPointExt* pPtAry,
								   const CRect &rcPos,COLORREF crStart,
								   COLORREF crEnd,UINT nFillType,CBrush *pBrush);
	
	// Draw polyline
	virtual void fDrawPolyLine(CDC *pDC,  const FOPPolygon& rPoly );

	// Draw polygon.
	virtual void fDrawPolygon(CDC *pDC,  const FOPPolygon& rPoly, const CRect &rcPos,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);

public:
	/*************************************************************************
	|*
	|* GDI+ supported.
	|*
	\************************************************************************/

	// Do fill polygon.
	// pts -- points.
	// nCount -- count of points
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Fill Polygon Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pts---A pointer to the POINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_FillPolygonTrack(CDC *pDC, POINT* pts, int nCount,const COLORREF &crFill);
	
	// Do fill ellipse.
	// lpRect -- rectangle.
	// crFill -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Ellipse Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.
	virtual void S_EllipseTrack(CDC *pDC, LPCRECT lpRect,const COLORREF &crFill);
	
	// Draw curve, like path.
	// pDC -- pointer of dc.
	// lppt -- points.
	// pTypes -- types.
	// nCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// S_ Draw Curve Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppt---A pointer to the POINT or NULL if the call failed.  
	//		pTypes---pTypes, A pointer to the BYTE or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void S_DrawCurveTrack(CDC *pDC, POINT* lppt, BYTE* pTypes, int nCount, const BOOL &bClose = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	//--(GDI+ SUPPORTS)---
	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void XDoDrawLine(CDC *pDC,const FOPFloat &ptStart,const FOPFloat &ptEnd);

	//--(GDI+ SUPPORTS)---
	// Do draw spline.
	// pDC-- DC's pointer.

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw spline, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void DoDrawSplineSimple(CDC *pDC, FOXSplineGen *pGen);

	// Draw arc line shape.
	virtual void DrawArcLine(CDC *pDC, const FOPPoint& cp, double radius,
		double a1, double a2,
		const FOPPoint& p1, const FOPPoint& p2,
                           bool reversed);

	//--(GDI+ SUPPORTS)---
	// Do draw line.
	// pDC-- DC's pointer.

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void DoDrawLineSimple(CDC *pDC,int x1, int y1, int x2, int y2);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDILine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Rect, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIRect(CDC *pDC, LPRECT pRect);


	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIEllipse(CDC *pDC, LPRECT pRect);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIPolygon(CDC *pDC, POINT* pts, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void XGDIPolygon(CDC *pDC, FOPFloat* pts, int nCount, COLORREF crFill);


	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw polyline, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIPolyline(CDC *pDC, POINT* pts, int nCount);


	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw polyline, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDITrackPolyline(CDC *pDC, POINT* pts, int nCount, const BOOL &bClose = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw polyline, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDITrackPolyline2(CDC *pDC, CArray<CPoint,CPoint>* arHandles, const BOOL &bClose = FALSE);


	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw bezier poly, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIPolyBezier(CDC *pDC, POINT* pts, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw bezier poly, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIFillRect(CDC *pDC, LPRECT rc, CBrush *pBrush);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw pie, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIPie(CDC *pDC, LPRECT rc, const FOPPoint &pt1,  const FOPPoint &pt2);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDIText(CDC *pDC, const CString &str, LPRECT rc,  const UINT &nFlags);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void GDI3dRect(CDC *pDC, LPRECT rc,  const COLORREF &cr1,  const COLORREF &cr2);

	// Do text out method
	// pDC -- pointer of the DC.
	// ptText -- text output point.
	// strText -- textout text label.
	// nLength -- length of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void GDITextOut(CDC *pDC,const int &xPos, const int &yPos, const CString &strText);


	// Draw GDI path
	virtual void GDIPath(const FOPSimplePolygon &path, CDC *pDC);


	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void GDIRichText(CDC* pDC, CRichEditCtrl* pRich, CString &strText, CRect& rcBox, 
								   CRect& rcPage, long nZoom,int nAction,bool *bOver);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void GDIPrintRotateRichText(CDC* pDC, CRichEditCtrl* pRich, CRect &rcDraw, CString &strText, 
								   CRect& rcPage, long nZoom, int nRotate, int nAction,bool *bOver);

	// Draw GDI rotate rich text.
	void GDIRotateRichText(CDC *pDC,CDC *pMemDC, BOOL bToMap, CString strText, CRect rc, CPoint ptCenter,
		CRect rcRotated, long nZoom,long nAngle,BOOL bAntialiase,BOOL bPrint);

protected:
	// Help method for rich text
	CRichEditCtrl * RichTextHelper1(CDC *pDC, CString strText,CRect rc,BOOL bPrinting);

	// Help method for rich text
	void RichTextHelper2(CDC *pDC,CRichEditCtrl *pRichCtrl,long nLineIndex,long *nLine,
		long *nLineHeight,long *nLineBeginY,BOOL bAntialiase);


	// Help method for rich text
	void RichTextHelper3(DWORD dwFormat,CHARFORMAT cfDefault,LOGFONT &aFont,
		BOOL bAntialiase);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void DoRichTextHelper(CDC* pDC, CRichEditCtrl* pRich, CString &strText, 
										 CRect& rcBox, CRect& rcPage,
										 int nDo,bool *bOver);

	//--(GDI+ SUPPORTS)---
	// Do draw circle.
	// pDC-- DC's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw circle, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void DoDrawCircleSimple(CDC *pDC, int x, int y,  int radius);

	//--(GDI+ SUPPORTS)---
	// Do draw rectangle.
	// pDC-- DC's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw rectangle, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void DoDrawRectSimple(CDC *pDC, int x1, int y1, int x2, int y2);

	//--(GDI+ SUPPORTS)---
	// Do draw marker.
	// pDC-- DC's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw marker, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	virtual void DoDrawMarker(CDC *pDC, int x, int y, int mode, int size = 6);

	//--(GDI+ SUPPORTS)---
	// Draw beizer line.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawBezierLine(CDC *pDC,LPPOINT points,int nCount);

	// Do draw arc line.
	// pDC-- DC's pointer.
	// rect -- rectangle of the arc.
	// ptStart -- start point of the arc line.
	// ptEnd -- end point of the arc line.

	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawArcLine(CDC *pDC,const CRect &rect,const CPoint &ptStart,
		const CPoint &ptEnd);

	// Do draw arc line.
	// pDC-- DC's pointer.
	// rect -- rectangle of the arc.
	// ptStart -- start point of the arc line.
	// ptEnd -- end point of the arc line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void XDoDrawArcLine(CDC *pDC,const CRect &rect,const FOPFloat &ptStart,
		const FOPFloat &ptEnd);

	//--(GDI+ SUPPORTS)---
	// Draw with a simple polygon.
	// pDC-- pointer of DC
	// poly -- poly.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Simple Polyline, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*poly---A pointer to the FOPSimplePolygon  or NULL if the call failed.
	virtual void DrawSimplePolyline(CDC *pDC, FOPSimplePolygon *poly);

	//--(GDI+ SUPPORTS)---
	// Draw poly line.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolyLine(CDC *pDC,LPPOINT points,int nCount);

	//--(GDI+ SUPPORTS)---
	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	virtual void DoDrawArrowLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	//--(GDI+ SUPPORTS)---
	// Do draw arc line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Angle Arc Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&startAngle---&startAngle, Specifies A float value.  
	//		&endAngle---&endAngle, Specifies A float value.  
	//		&crFill---&crFill, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bFill---&bFill, Specifies A Boolean value.
	virtual void DoDrawArrowAngleArcLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd,
		const int &nWidth,const float &startAngle,const float &endAngle,const COLORREF &crFill,const BOOL &bFill);
	
	//--(GDI+ SUPPORTS)---
	// Do draw arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*center---A pointer to the CPoint  or NULL if the call failed.  
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).  
	//		angle1---Specifies a double angle1 object(Value).  
	//		angle2---Specifies a double angle2 object(Value).
	virtual void DoDrawArc(CDC *pDC, CPoint *center,double width, 
		double height,double angle1, double angle2);
	
	//--(GDI+ SUPPORTS)---
	// Do draw arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*startpoint---A pointer to the CPoint  or NULL if the call failed.  
	//		*endpoint---A pointer to the CPoint  or NULL if the call failed.  
	//		*midpoint---A pointer to the CPoint  or NULL if the call failed.
	virtual void DoDrawArcNew(CDC *pDC,CPoint *startpoint,CPoint *endpoint,CPoint *midpoint);
	
	//--(GDI+ SUPPORTS)---
	// Do draw arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc New2, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		radiusX---radiusX, Specifies a double radiusX object(Value).  
	//		radiusY---radiusY, Specifies a double radiusY object(Value).  
	//		dblStartAngle---Start Angle, Specifies a double dblStartAngle object(Value).  
	//		dblFinishAngle---Finish Angle, Specifies a double dblFinishAngle object(Value).  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.
	virtual void DoDrawArcNew2(CDC *pDC, FOPPoint ptCenter,double radiusX, double radiusY,
		double dblStartAngle, double dblFinishAngle, 
		BOOL bIsClockwise);
	
	//--(GDI+ SUPPORTS)---
	// Do draw arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc New3, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ptFrom---ptFrom, Specifies A integer value.  
	//		ptTo---ptTo, Specifies A integer value.  
	//		sizeRadius---sizeRadius, Specifies a const FOPSize sizeRadius object(Value).  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.
	virtual void DoDrawArcNew3(CDC *pDC, 
		const FOPPoint& ptFrom, const FOPPoint& ptTo, const FOPSize sizeRadius, 
		BOOL bIsClockwise, BOOL bIsLargeArc);

	//--(GDI+ SUPPORTS)---
	// Draw rounded polyline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*points---A pointer to the CPoint  or NULL if the call failed.  
	//		num_points---Specifies A integer value.  
	//		radius---Specifies a double radius object(Value).
	virtual void DoDrawRoundLine(CDC *pDC,CPoint *points, int num_points,double radius);

	//--(GDI+ SUPPORTS)---
	// Draw arc with given 3 points.
	// startpoint -- start point.
	// endpoint -- end point
	// midpoint -- midpoint
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Arc With3 Points, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*startpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*endpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*midpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void DrawArcWith3Points(CDC *pDC, 
		FOPPoint *startpoint, 
		FOPPoint *endpoint,
		FOPPoint *midpoint, const BOOL &bTrack = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Draw arc with given 3 points.
	// startpoint -- start point.
	// endpoint -- end point
	// midpoint -- midpoint
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Arc With3 Points2, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*startpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*endpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*midpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void DrawArcWith3Points2(CDC *pDC, 
		FOPPoint *startpoint, 
		FOPPoint *endpoint,
		FOPPoint *midpoint, const BOOL &bTrack = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Draw pie with given 3 points.
	// startpoint -- start point.
	// endpoint -- end point
	// midpoint -- midpoint
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Pie With3 Points, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*startpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*endpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*midpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void DrawPieWith3Points(CDC *pDC, 
		FOPPoint *startpoint, 
		FOPPoint *endpoint,
		FOPPoint *midpoint, COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush, const BOOL &bTrack = FALSE);
	
	//--(GDI+ SUPPORTS)---
	// Draw phase path, total range is 300.
	// pDC -- pointer of DC.
	// min -- minimize value.
	// max -- maximize value.
	// rcA -- all bounding rectangle.
	// nSplit -- split
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Phase Path, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		min---Specifies a double min object(Value).  
	//		max---Specifies a double max object(Value).  
	//		&rcA---&rcA, Specifies a const FOPRect &rcA object(Value).  
	//		&dSplit---&dSplit, Specifies a const double &dSplit = 20.0 object(Value).
	void DrawPhasePath(CDC *pDC, double min, double max, const COLORREF &crBack, const FOPRect &rcA, const double &dSplit = 20.0);
	void SVG_PhasePath(CString &strIn, double min, double max, const COLORREF &crBack, const FOPRect &rcA, const double &dSplit = 20.0);
	//--(GDI+ SUPPORTS)---
	// Do draw poly bezier line.
	// pDC -- pointer of the DC.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw New Polygon Line Bezier, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE or NULL if the call failed.
	virtual BOOL	DrawNewPolyLineBezier(CDC *pDC,
		ULONG nPoints, 
		const fopPointExt* pPtAry, 
		const BYTE* pFlgAry );

	// Draw ellipse.
	virtual void DrawEllipse(CDC *pDC,const FOPPoint& cp,
		double radius1, double radius2,
		double angle,
		double a1, double a2,
                             bool reversed);

	// Draw ellipse.
	virtual void SVG_DrawEllipse(CString &strIn,const FOPPoint& cp,
		double radius1, double radius2,
		double angle,
		double a1, double a2,
                             bool reversed, COLORREF crLine, COLORREF crFill, int nLineWidth);

	// Draw ellipse.
	virtual void DrawTrackEllipse(CDC *pDC,const FOPPoint& cp,
		double radius1, double radius2,
		double angle,
		double a1, double a2,
                             bool reversed);
	//--(GDI+ SUPPORTS)---
	// Do draw poly bezier line.
	// pDC -- pointer of the DC.
	// poly -- count of the points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Simple Polygon Line, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*poly---A pointer to the FOPSimplePolygon  or NULL if the call failed.
	virtual BOOL	DrawSimplePolyLine(CDC *pDC,
		FOPSimplePolygon *poly );
	
	//--(GDI+ SUPPORTS)---
	// Do draw polygon bezier
	// pDC -- pointer of the DC.
	// rcPos -- rectangle of the drawing.
	// nPoints -- count of the points.
	// pPtAry -- points array.
	// pFlgAry -- flag array.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill New Polygon Bezier, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nPoints---nPoints, Specifies A 32-bit LONG signed integer.  
	//		pPtAry---Point Array, A pointer to the const fopPointExt or NULL if the call failed.  
	//		pFlgAry---Flg Array, A pointer to the const BYTE or NULL if the call failed.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
    virtual BOOL	FillNewPolygonBezier(CDC *pDC,
		const CRect &rcPos,
		ULONG nPoints, 
		const fopPointExt* pPtAry,
		const BYTE* pFlgAry,
		COLORREF crStart,
		COLORREF crEnd,
		UINT nFillType,
		CBrush *pBrush);
public:
	
	/*************************************************************************
	|*
	|* GDI+ not supported.
	|*
	\************************************************************************/

	// Fill gradient.
	// rcPos -- the points of paint area.
	// crStart -- start color value.
	// crEnd -- end color value.
	// nFillType -- the fill brush type from 0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient With Type, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A integer value.
	virtual void FillGradientWithType(CDC *pDC,CRect rcPos, COLORREF crStart, COLORREF crEnd, int nType);

	// Draw tab order.
	// rcPos -- Position of tab order.
	// crColor -- COLORREF to fill.
	// strText -- Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tab Order, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		strText---strText, Specifies A CString type value.
	virtual void DoDrawTabOrder(CDC *pDC,const CRect &rcPos,const COLORREF &crColor,CString strText);

	// Draws custom tracker.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Track Custom, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawTrackCustom(CDC *pDC,LPPOINT points,int nCount);

	// Draws visio simple custom tracker.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Simple Track Custom, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.  
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoDrawSimpleTrackCustom(CDC *pDC,LPPOINT points,int nCount, const BOOL &bClose, const UINT &nShapeType);
	
	// Draw alpha
	static void DrawAlpha(CDC* pDstDC, const CRect& rectDst, CDC* pSrcDC, 
		const CRect& rectSrc, BYTE nOpacity = 255);

	// Do draw custom port style.
	// pDC-- DC's pointer.
	// ptPort -- center point of port.
	// nPortWidth -- port width.
	// nPortHeight -- port height.
	// crStart -- start color.
	// crEnd -- end color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Port, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptPort---&ptPort, Specifies A CPoint type value.  
	//		&nPortWidth---Port Width, Specifies A integer value.  
	//		&nPortHeight---Port Height, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nBrushType---Brush Type, Specifies A integer value.  
	//		nPortType---Port Type, Specifies A integer value.
	virtual void DoDrawCustomPort(CDC *pDC,const CPoint &ptPort,const int &nPortWidth,const int &nPortHeight,
	COLORREF crStart, COLORREF crEnd, int nBrushType,int nPortType);

	// Draw custom port tracker line.
	// pDC-- DC's pointer.
	// ptPort -- center point of the port.
	// nPortWidth -- width of the port.
	// nPortHeight -- height of the port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Track Port, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptPort---&ptPort, Specifies A CPoint type value.  
	//		&nPortWidth---Port Width, Specifies A integer value.  
	//		&nPortHeight---Port Height, Specifies A integer value.
	virtual void DoDrawCustomTrackPort(CDC *pDC,const CPoint &ptPort,
		const int &nPortWidth,const int &nPortHeight);

	
	// Draw PolyPolygon.
	// pDC-- DC's pointer.
	// points -- points for drawing.
	// nCount -- total of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Polygon, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		lpPoly---lpPoly, Specifies a LPINT lpPoly object(Value).  
	//		nCount---nCount, Specifies A integer value.
	virtual void DoDrawPolyPolygon(CDC *pDC,LPPOINT points,LPINT lpPoly,int nCount);


	
	// Resign page setting's predefine name.
	// nID -- Resign page ID.
	// strName -- Name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Page Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignPageName(int nID,CString &strName);

	// Resign drop arrow's tips name.
	// nID -- Arrow's ID.
	// strName -- Name of arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Arrow Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignArrowTipName(int nID,CString &strName);

	// Resign drop color picker's tips name.
	// nID -- Arrow's ID.
	// strName -- Name of color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Color Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignColorTipName(int nID,CString &strName);

	// Resign drop line type picker's tips name.
	// nID -- Arrow's ID.
	// strName -- Name of line type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Line Type Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignLineTypeTipName(int nID,CString &strName);

	// Resign drop line width picker's tips name.
	// nID -- Arrow's ID.
	// strName -- Name of line width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Line Width Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignLineWidthTipName(int nID,CString &strName);

	// Resign drop shadow picker's tips name.
	// nID -- Arrow's ID.
	// strName -- Name of shadow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Shadow Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignShadowTipName(int nID,CString &strName);

	// Resign fill mode cell's tips name.
	// nIndex -- index of cell.
	// strName -- name of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Fill Cell Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignFillCellTipName(int nIndex,CString &strName);

	// Resign gradient mode cell's tips name.
	// nIndex -- index of cell.
	// strName -- name of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Gradient Cell Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignGradientCellTipName(int nIndex,CString &strName);

	// Resign Texture mode cell's tips name.
	// nIndex -- index of cell.
	// strName -- name of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resign Texture Cell Tip Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoResignTextureCellTipName(int nIndex,CString &strName);

	// When header and footer dialog's help button click execute this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Exe Button Help, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoExeBtnHelp(UINT nID);

	// Generate dimension text.
	// nLength -- length of the dim line shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Dimension Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	virtual CString GenerateDimText(int nLength);

	// Correct the date string format of the date time shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Date Format, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strDate---&strDate, Specifies A CString type value.  
	//		&date---Specifies a const COleDateTime &date object(Value).
	virtual void CorrectDateFormat(CString &strDate,const COleDateTime &date);

	// Obtain the date format string.
	// strDate -- date text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Format, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strDate---&strDate, Specifies A CString type value.
	virtual void GetDateFormat(CString &strDate);

	// Obtain the date format string.
	// strState -- new state text that generated.
	// strOld -- old state text.
	// nShapeType -- shape type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strState---&strState, Specifies A CString type value.  
	//		&strOld---&strOld, Specifies A CString type value.  
	//		nShapeType---Shape Type, Specifies A integer value.
	virtual void GetDefaultState(CString &strState, const CString &strOld, int nShapeType);

	// Obtain the default state string.
	// strState -- new state text that generated.
	// strOld -- old state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strState---&strState, Specifies A CString type value.  
	//		&strOld---&strOld, Specifies A CString type value.
	virtual void GetCurrentState(CString &strState, const CString &strOld);

	// Obtain the space value to link the border of the shape,override this method to change the space
	// that between link point to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Space To Border, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nSpace---&nSpace, Specifies A integer value.
	virtual void GetLinkSpaceToBorder(int &nSpace);

	// Update line data,this method must be called before DrawPolygonLine method.
	// Params:
	// aLineDash -- line dash style,it must be initialed with the following type.
	//  FOPLineInfo rDash;
	//  rDash.SetDashLen(40);
	//  rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	//  rDash.SetDistance(20);
	//  rDash.SetDotLen(15);
	//  rDash.SetDistance(10);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Line Data, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void UpdateLineData(FOPLineInfo &aLineDash);

	// Drawing pipe line.
	// pDC -- pointer of DC.
	// points -- points for drawing.
	// nPtCount -- count of points.
	// iSegments -- width of pipe, it should be 2 * iSegments width.
	// crStart -- start color of pipe.
	// crEnd -- end color of pipe.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Pipe Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nPtCount---Point Count, Specifies A integer value.  
	//		&nLineWidth---Line Width, Specifies A integer value.  
	//		iSegments---iSegments, Specifies A integer value.  
	//		&crLine---&crLine, Specifies A 32-bit COLORREF value used as a color value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawPipeLine(CDC* pDC, LPPOINT points, int nPtCount,
		const int &nLineWidth,
		int iSegments, const COLORREF &crLine, COLORREF crStart, COLORREF crEnd);

	// Do page setup help.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Page Setup Help, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoPageSetupHelp(UINT nID);

	// Obtain the interesting point.
	// p1 -- first point.
	// p2 -- second point.
	// result -- result point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Best Intersect Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p1---Specifies A CPoint type value.  
	//		&p2---Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*pPoints---*pPoints, A pointer to the CPoint>  or NULL if the call failed.
	virtual BOOL GetBestIntersectPoint(const CPoint &p1, const CPoint &p2, CPoint &result, CArray<CPoint, CPoint> *pPoints);

	// Obtain the point that near to polyline path
	// poly -- points of polygon.
	// npoints -- count of points.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Near Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		poly---Specifies A LPPOINT Points array.  
	//		npoints---Specifies A integer value.  
	//		&bOutLine---Out Line, Specifies A Boolean value.  
	//		line_width---Specifies a double line_width object(Value).  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	virtual CPoint GenNearPoint(LPPOINT poly, int npoints, const BOOL &bOutLine, double line_width, 
		const CPoint *point);

	// Correct two rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Two Rects, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rc1---Specifies A CRect type value.  
	//		&rc2---Specifies A CRect type value.
	virtual BOOL CorrectTwoRects(const CRect &rc1, const CRect &rc2);


public:

	/*************************************************************************
	|*
	|* Visual drawing with more new features for line drawing.
	|*
	\************************************************************************/

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	// FOPPolygon poly(2);
	// poly[0] = CPoint(20,20);
	// poly[1] = CPoint(100,200);
	// CFOPVisualProxy::GetInstance()->UpdateLineData(rDash);
	// CFOPVisualProxy::GetInstance()->DrawPolygonLine(pDC,poly,rDash,TRUE,TRUE);
	// aPoly -- polygon object.
	// bClosePoly -- close or not.
	// nLineWidth -- line width.
	// bShowBorder -- showing border around the line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Imp_ Draw Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		bClosePoly---Close Polygon, Specifies A Boolean value.
	virtual void Imp_DrawPolygonLine(CDC *pDC,const FOPPolygon& aPoly,
		FOPLineInfo &aLineDash,BOOL bClosePoly = FALSE);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rStart---rStart, Specifies A integer value.  
	//		rEnd---rEnd, Specifies A integer value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void FOP_DrawLine(CDC *pDC,const FOPPoint& rStart, const FOPPoint& rEnd,
		FOPLineInfo &aLineDash);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void FOP_DrawPolygon(CDC *pDC,LPPOINT points,int nCount,
		FOPLineInfo &aLineDash);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rPoly---rPoly, Specifies a const FOPPolygon& rPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawPolyLine(CDC *pDC,const FOPPolygon& rPoly,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw rectangle object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawRectangle(CDC *pDC,const FOPRect& rRect,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw round rectangle object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Roun Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		nHorz---nHorz, Specifies A 32-bit LONG signed integer.  
	//		nVert---nVert, Specifies A 32-bit LONG signed integer.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawRounRect(CDC *pDC,const FOPRect& rRect, 
								 ULONG nHorz, ULONG nVert,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw arc pie or chord object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Arc, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&ePolyStyle---Polygon Style, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawArc(CDC *pDC,const FOPRect& rRect, const FOPPoint& ptStart, const FOPPoint& ptEnd,
		FOPLineInfo &aLineDash, const UINT &ePolyStyle = FOP_POLY_TYPE_ARC, const BOOL &bClose = FALSE);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawPolyLine(CDC *pDC,LPPOINT points,int nCount,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Bezier Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawBezierLine(CDC *pDC,LPPOINT points,int nCount,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Simple Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rPoly---rPoly, Specifies a const FOPSimplePolygon& rPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void FOP_DrawSimplePolyLine(CDC *pDC,const FOPSimplePolygon& rPoly,
		FOPLineInfo &aLineDash,const BOOL &bClose = FALSE);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Simple Polygon Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rPolyPoly---Polygon Polygon, Specifies a const FOPSimpleCompositePolygon& rPolyPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void FOP_DrawSimplePolyPolyLine(CDC *pDC,const FOPSimpleCompositePolygon& rPolyPoly,
		FOPLineInfo &aLineDash);

	// Draw line around the polygon object,you must call UpdateLineData before call this method,the following is the
	// sample codes to call this method:
	// FOPLineInfo rDash;
	// rDash.SetDashLength(400);
	// rDash.SetDashStyle(FOP_LINE_DASH_RECT);
	// rDash.SetDistance(0);
	// rDash.SetDotLength(0);
	// rDash.SetDistance(0);
	// rDash.SetLineColor(GetLineWidth());
	// rDash.SetFillColor(RGB(255,0,0));
	// rDash.SetLineWidth(40);
	// rDash.SetPenStyle(GetPenStyle());
	// rDash.SetPenWidth(GetLineWidth());
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Polygon Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rPoly---rPoly, Specifies a const FOPPolyPolygon& rPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void FOP_DrawPolyPolyLine(CDC *pDC,const FOPPolyPolygon& rPoly,
		FOPLineInfo &aLineDash);

	// Is null pen used.
	BOOL IsNullPenUsed(CDC *pDC);
	
public:

	// Do draw arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Track Arc, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*center---A pointer to the CPoint  or NULL if the call failed.  
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).  
	//		angle1---Specifies a double angle1 object(Value).  
	//		angle2---Specifies a double angle2 object(Value).
	virtual void DoDrawTrackArc(CDC *pDC, CPoint *center,double width, double height,double angle1, double angle2);
	
	// Draw rounded polyline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Track Round Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*points---A pointer to the CPoint  or NULL if the call failed.  
	//		num_points---Specifies A integer value.  
	//		radius---Specifies a double radius object(Value).
	virtual void DoDrawTrackRoundLine(CDC *pDC,CPoint *points, int num_points,double radius);
	
	
	// Calculate minimize radius for round corner.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Calculate_min_radius, .
	//		Returns A double value (Object).  
	// Parameters:
	//		*p1---A pointer to the CPoint  or NULL if the call failed.  
	//		*p2---A pointer to the CPoint  or NULL if the call failed.  
	//		*p3---A pointer to the CPoint  or NULL if the call failed.
	double FOPCalculate_min_radius( CPoint *p1, CPoint *p2, CPoint *p3 );
	
	
	// Convert number to currency
	// chSymbol -- symbol
	// strText -- text convert.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Number To Currency, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		chSymbol---chSymbol, Specifies a TCHAR chSymbol object(Value).  
	//		&strText---&strText, Specifies A CString type value.
	virtual CString ConvertNumberToCurrency(TCHAR chSymbol,const CString &strText);

	// Get unit string
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// rStr -- return string value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Unit String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&eUnit---&eUnit, Specifies a const FieldUnit &eUnit object(Value).  
	//		rStr---rStr, Specifies A CString type value.
	virtual void TakeUnitStr(const FieldUnit &eUnit, CString& rStr);

	// Get full description unit string
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// rStr -- return string value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Detail Unit String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&eUnit---&eUnit, Specifies a const FieldUnit &eUnit object(Value).  
	//		rStr---rStr, Specifies A CString type value.
	virtual void TakeDetailUnitStr(const FieldUnit &eUnit, CString& rStr);

	// Do text out method
	// pDC -- pointer of the DC.
	// ptText -- text output point.
	// strText -- textout text label.
	// nLength -- length of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void DoDrawTextOutX(CDC *pDC,const int &xPos, const int &yPos, const CString &strText);

	// Do text out method
	// pDC -- pointer of the DC.
	// ptText -- text output point.
	// strText -- textout text label.
	// nLength -- length of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Out, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptText---&ptText, Specifies A CPoint type value.  
	//		&strText---&strText, Specifies A CString type value.  
	//		&nLength---&nLength, Specifies A integer value.
	virtual void DoDrawTextOut(CDC *pDC,const CPoint &ptText,const CString &strText,const int &nLength);

	// Generate the ports scales value of the CFODrawPortsShape
	// mpSpot -- list of the default ports
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Default Ports, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<FOP_PortScale---Array< F O P_ Port Scale, Specifies A CArray array.  
	//		mpSpot---mpSpot, A pointer to the FOP_PortScale> or NULL if the call failed.  
	//		&nShapeType---Shape Type, Specifies A integer value.
	virtual void GenerateDefaultPorts(CArray<FOP_PortScale,FOP_PortScale>* mpSpot,const int &nShapeType);

	// Obtain the angle string
	// nAngle -- angle value -- from 0 - 360
	// rStr -- text that generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Angle String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.  
	//		rStr---rStr, Specifies A CString type value.
	virtual void TakeAngleStr(long nAngle, CString& rStr) const;

	// Convert current file to bitmap.
	// strFile -- file name.
	// bmp -- output bitmap handle.
	// cx -- width of the output bitmap.
	// cy -- height of the output bitmap.
	// crBack -- back color of the output bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&bmp---Specifies a E-XD++ CFOBitmap &bmp object (Value).  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual BOOL GetBitmap(const CString &strFile,CFOBitmap &bmp, int cx, int cy, COLORREF crBack = RGB(255,255,255));

	
	// Convert current file to bitmap.
	// strFile -- file name.
	// bmp -- output bitmap handle.
	// cx -- width of the output bitmap.
	// cy -- height of the output bitmap.
	// crBack -- back color of the output bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&bmp---Specifies a E-XD++ CFOBitmap &bmp object (Value).  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual BOOL GetTempBitmap(const CString &strFile,CFOBitmap &bmp, int cx, int cy, CString &strDesc, COLORREF crBack = RGB(255,255,255));

	// Do draw bitmap.
	// pDC -- pointer of DC.
	// pBitmap -- pointer of bitmap.
	// rcPos -- position for drawing.
	// nImageWidth -- image width.
	// nImageHeight -- image height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bitmap, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pBitmap---*pBitmap, A pointer to the CFOBitmap  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		&nImageX---Image X, Specifies A integer value.  
	//		&nImageY---Image Y, Specifies A integer value.  
	//		&nImageWidth---Image Width, Specifies A integer value.  
	//		&nImageHeight---Image Height, Specifies A integer value.  
	//		&bTrans---&bTrans, Specifies A Boolean value.  
	//		&crTrans---&crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual void DoDrawBitmap(CDC *pDC, CFOBitmap *pBitmap, CRect rcPos, const int &nImageX, const int &nImageY, const int &nImageWidth, const int &nImageHeight,
		const BOOL &bTrans = FALSE, const COLORREF &crTrans = RGB(255,255,255), int nRotateAngle = 0);

	// Fill bitmap type.
	// pDC -- pointer of the DC.
	// rect -- position to fill.
	// bTitle -- title or not.
	// nType -- fill type.
	// pRgn -- clip rgn.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Bitmap With Type, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bTitle---bTitle, Specifies A Boolean value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pRgn---*pRgn, A pointer to the CRgn  or NULL if the call failed.
	virtual void FillBitmapWithType(CDC *pDC, CRect rect,BOOL bTitle, UINT nType,CRgn *pRgn = NULL);


	// Fill with custom type.
	// pDC -- pointer of the DC.
	// rect -- position to fill.
	// bTitle -- title or not.
	// nType -- fill type.
	// pRgn -- clip region.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Custom With Type, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bTitle---bTitle, Specifies A Boolean value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&crFirst---&crFirst, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crSecond---&crSecond, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bClip---&bClip, Specifies A Boolean value.  
	//		*pRgn---*pRgn, A pointer to the CRgn  or NULL if the call failed.  
	//		*aGradient---*aGradient, A pointer to the FOPGradient  or NULL if the call failed.
	virtual void FillCustomWithType(CDC *pDC, CRect rect,BOOL bTitle, UINT nType,const COLORREF &crFirst,
		const COLORREF &crSecond, const BOOL &bClip = TRUE, CRgn *pRgn = NULL, FOPGradient *aGradient = NULL);

	// Obtain handle at a specify index.
	// nHandle -- index of handle.
	// rcSnap -- rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nHandle---nHandle, Specifies A integer value.  
	//		&rcSnap---&rcSnap, Specifies A CRect type value.
	virtual CFOPHandle* GetHandle(int nHandle,const CRect &rcSnap) const;

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).  
	//		&rcSnap---&rcSnap, Specifies A CRect type value.  
	//		&nShapeType---Shape Type, Specifies A integer value.  
	//		&bWidthProt---Width Prot, Specifies A Boolean value.  
	//		&bHeightProt---Height Prot, Specifies A Boolean value.
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle,const CRect &rcSnap,
		const int &nShapeType,
		const BOOL &bWidthProt = FALSE, 
		const BOOL &bHeightProt = FALSE);

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).  
	//		*pts---A pointer to the const FOPPoint  or NULL if the call failed.  
	//		&nShapeType---Shape Type, Specifies A integer value.  
	//		&bInvert---&bInvert, Specifies A Boolean value.  
	//		&nAngle---&nAngle, Specifies A integer value.  
	//		&bWidthProt---Width Prot, Specifies A Boolean value.  
	//		&bHeightProt---Height Prot, Specifies A Boolean value.  
	//		&bLimitW---Limit W, Specifies A Boolean value.  
	//		&bLimitH---Limit H, Specifies A Boolean value.
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle,const FOPPoint *pts,
		const int &nShapeType,const BOOL &bInvert, const int &nAngle,
		const BOOL &bWidthProt = FALSE, 
		const BOOL &bHeightProt = FALSE, const BOOL &bLimitW = FALSE, const BOOL &bLimitH = FALSE);


	// Do generate the tooltip text of additional icons.
	// strGen -- tooltip text that generated.
	// nType -- icon type ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Additional Tool Tips, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strGen---&strGen, Specifies A CString type value.  
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoGenAddiToolTips(CString &strGen, const UINT &nType);

	// Drawing selection additional type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Additional With Type, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoDrawAddiWithType(CDC *pDC,const CRect &rcPos,const UINT &nType);

	// Build track pen of the shape.
	// Override this method for changing the pen of tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Track Pen, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CPen ,or NULL if the call failed  
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	virtual CPen *BuildTrackPen(const int &nWidth);

	// Drawing customized table cell, it is designed for drawing table shape (CFOPTableShape) 's cell.
	// pDC -- pointer of DC.
	// rcCell -- cell position.
	// nRow -- row index.
	// nCol -- column index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Table Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcCell---&rcCell, Specifies A CRect type value.  
	//		&nRow---&nRow, Specifies A integer value.  
	//		&nCol---&nCol, Specifies A integer value.
	virtual void DoDrawTableCell(CDC *pDC, const CRect &rcCell,const int &nRow,const int &nCol);

	// Draw bitmap within a rectangle.
	// pDC -- pointer of DC.
	// bitmap -- bitmap for drawing.
	// rect -- rectangle for drawing.
	// nWidth -- width.
	// nHeight -- height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Bitmap, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bitmap---Specifies a CBitmap& bitmap object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	virtual void DrawBitmap(CDC* pDC, CBitmap& bitmap, const CRect& rect, int nWidth,  int nHeight);

	// Do draw gripper of toolbox's title bar
	// pDC -- pointer of DC.
	// rectGripper -- position of gripper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tool Box Gipper, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rectGripper---&rectGripper, Specifies A CRect type value.
	virtual void DoDrawToolBoxGipper(CDC* pDC, const CRect &rectGripper);

	// Draw title bar face of toolbox window.
	// dc -- handle of DC.
	// rcTitle -- title bar position.
	// bMouseOver -- mouse over state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tool Box Title Bar, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dc---Specifies a CDC &dc object(Value).  
	//		&rcTitle---&rcTitle, Specifies A CRect type value.  
	//		&bMouseOver---Mouse Over, Specifies A Boolean value.  
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crPattern---&crPattern, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawToolBoxTitleBar(CDC &dc, const CRect &rcTitle, const BOOL &bMouseOver, 
		const COLORREF &crBack, const COLORREF &crPattern);

	// Draw background of toolbox window.
	// pDC -- pointer of DC.
	// rcToolBox -- toolbox window position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tool Box Back, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcToolBox---Tool Box, Specifies A CRect type value.  
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crPattern---&crPattern, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawToolBoxBack(CDC *pDC, const CRect &rcToolBox, const COLORREF &crBack, const COLORREF &crPattern);

	// Draw toolbar face.
	// pDC -- pointer of DC.
	// rcBtn -- toolbar button position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tool Bar Face, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcBtn---&rcBtn, Specifies A CRect type value.  
	//		&bVert---&bVert, Specifies A Boolean value.
	virtual void DoDrawToolBarFace(CDC *pDC, const CRect &rcBtn,const BOOL &bVert);

	// Draw toolbar face.
	// pDC -- pointer of DC.
	// rcBtn -- toolbar button position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tool Bar Button Face, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcBtn---&rcBtn, Specifies A CRect type value.  
	//		&bVert---&bVert, Specifies A Boolean value.
	virtual void DoDrawToolBarButtonFace(CDC *pDC, const CRect &rcBtn,const BOOL &bVert);

	// Draw control bar title.
	// pDC -- pointer of DC.
	// rc -- position for drawing.
	// bVert -- vertical or horizontal bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw  Bar Title, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies A CRect type value.  
	//		&bVert---&bVert, Specifies A Boolean value.
	virtual void DoDrawControlBarTitle(CDC *pDC, const CRect &rc, const BOOL &bVert);

	// Draw check box shape's check style.
	// pDC -- pointer of DC.
	// rc -- rectangle.
	// nType -- style of check box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Check Style, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies A CRect type value.  
	//		&nType---&nType, Specifies A integer value.
	virtual void DoDrawCheckStyle(CDC *pDC, const CRect &rc, const int &nType);

	// Generate shape's text position.
	// nShapeType -- shape type id.
	// rcShapeSnap -- snap rectangle.
	// nLabelPos -- label position.
	// szText -- text size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		&nShapeType---Shape Type, Specifies A integer value.  
	//		&rcShapeSnap---Shape Snap, Specifies A CRect type value.  
	//		&nLabelPos---Label Position, Specifies A integer value.  
	//		&szText---&szText, Specifies A CSize type value.
	virtual CRect GenLabelPosition(const int &nShapeType, const CRect &rcShapeSnap, 
		const int &nLabelPos, const CSize &szText);

	// Drawing sign mark.
	// pDC -- pointer of DC.
	// rcPos -- position of this sign mark for drawing.
	// nType -- type id.
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Sign Mark, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nType---&nType, Specifies A integer value.  
	//		&bVert---&bVert, Specifies A Boolean value.
	virtual void DoDrawCustomSignMark(CDC *pDC, const CRect &rcPos, const int &nType, const BOOL &bVert = FALSE);

	// Init default property values, override this method to add new global property values.
	// mpProp -- add new FOP_CUST_PROP object to this array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Default Property, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<FOP_CUST_PROP---Array< F O P_ C U S T_ P R O P, Specifies A CArray array.  
	//		&mpProp---&mpProp, Specifies a FOP_CUST_PROP> &mpProp object(Value).
	virtual void DoInitDefaultProp(CArray<FOP_CUST_PROP,FOP_CUST_PROP> &mpProp);

	// Do draw port index label.
	// pDC -- pointer of DC.
	// ptPort -- point of port.
	// nPortIndex -- port index.
	// nPortConnectType -- Connect type.
	// nPortAllowNumber -- maximize allow port number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Port Index Label, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptPort---&ptPort, Specifies A CPoint type value.  
	//		&nPortIndex---Port Index, Specifies A integer value.  
	//		&nPortConnectType---Port Connect Type, Specifies A integer value.  
	//		&nPortAllowNumber---Port Allow Number, Specifies A integer value.
	virtual void DoDrawPortIndexLabel(CDC *pDC, const CPoint &ptPort, const int &nPortIndex, 
		const int &nPortConnectType, const int &nPortAllowNumber);

	// Init default property description list, override this method to add new global property description.
	// mpDefScrip -- default property description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Default Property Description, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<FOP_PROP_DESC---Array< F O P_ P R O P_ D E S C, Specifies A CArray array.  
	//		&mpDefScrip---Default Scrip, Specifies a FOP_PROP_DESC> &mpDefScrip object(Value).
	virtual void DoInitDefaultPropDescription(CArray<FOP_PROP_DESC,FOP_PROP_DESC> &mpDefScrip);

	// Customize the menu bitmap ID.
	// nNewId -- new image id.
	// nOldId -- old image id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Custom Menu Image Id, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nNewId---New Id, Specifies A integer value.  
	//		&nOldId---Old Id, Specifies A integer value.
	virtual void DoCustomMenuImageId(int &nNewId, const int &nOldId);

	// Generate fat line style.
	// nPenWidth -- width of pen.
	// nPenStyle -- style of pen.
	// output -- output array data.
	// nSize -- size of array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Line Style, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nPenWidth---Pen Width, Specifies A integer value.  
	//		nPenStyle---Pen Style, Specifies A integer value.  
	//		*output---A pointer to the DWORD  or NULL if the call failed.  
	//		&nSize---&nSize, Specifies A integer value.
	virtual void GenerateLineStyle(int nPenWidth,int nPenStyle,DWORD *output, int &nSize);

	// Fill high bar's area.
	// pDC--pointer of DC.
	// rc -- area for drawing.
	// nStyle -- 0 From bottom to up@1 From top to bottom@2 From right to left@3 From left to right
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill High Bar Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		&nStyle---&nStyle, Specifies A integer value.  
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.
	virtual void FillHighBarShape(CDC *pDC, const FOPRect &rc, const int &nStyle, const COLORREF &crBack);

	// generate the position of the ellipse scale position.
	// nType--type of drawing.
	// rcOld -- area for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Scale Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.  
	//		&rcOld---&rcOld, Specifies a const FOPRect &rcOld object(Value).
	virtual FOPRect GenScalePosition(const int &nType, const FOPRect &rcOld);

	// Draw border of rectangle.
	// pDC--pointer of DC
	// rcPos -- position of rectangle.
	// nBorder -- border size.
	// crColor -- color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies a const FOPRect &rcPos object(Value).  
	//		nBorder---nBorder, Specifies A integer value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawBorder(CDC *pDC, const FOPRect &rcPos, const int nBorder, const COLORREF &crColor);

	// Do shape clone informations.
	// pClone -- pointer of shape that new cloned.
	// nShapeID -- the shape ID of shape that to be cloned.
	// strName -- the shape name of shape that to be cloned.
	// strKey1 -- the shape key1 of shape that to be cloned.
	// strKey2 -- the shape key2 of shape that to be cloned.
	virtual void DoCloneShape(CFODrawShape *pClone, const int &nShapeID, const CString &strName, const CString &strKey1, const CString &strKey2);

	// Do shape disconnect outside data informations.
	// pShape -- pointer of shape that new cloned.
	virtual void DoDisconnectData(CFODrawShape *pShape);

	// SVG Ext text.
	virtual CString ExtSVGOut(CFODrawShape *pShape);

	// Generate path shape.
	virtual CFODrawShape* DoGenPathShape(UINT m_drawshape,CArray<CPoint,CPoint> *arPoints,BOOL bArrow);

	// Is shape support around center.
	// nShape -- type of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Support Around, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nShape---&nShape, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL IsShapeSupportAround(const UINT &nShape);

	// Handle your own port control.
	// pPort -- pointer of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Own Port Start, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL HandleOwnPortStart(CFOPortShape *pPort);

	// Generate the nearest point.
	// pPort -- pinter of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Nearest Link Point Start, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CPoint DoGenerateNearestLinkPointStart(CFOPortShape *pPort);

	// Handle your own port control.
	// pPort -- pointer of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Own Port End, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL HandleOwnPortEnd(CFOPortShape *pPort);
	
	// Generate the nearest point.
	// pPort -- pinter of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Nearest Link Point End, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CPoint DoGenerateNearestLinkPointEnd(CFOPortShape *pPort);

	// Do draw text.
	// pDC -- pointer of DC.
	// lpszText -- text for drawing.
	// lpRect -- rectangle for drawing.
	// uFormat -- text alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&strText---&strText, Specifies A CString type value.  
	//		rcRect---rcRect, Specifies A CRect type value.  
	//		uFormat---uFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawText(CDC *pDC,const CString &strText, CRect rcRect, UINT uFormat);

	// draw bar border
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Bar Border, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rectBorder---&rectBorder, Specifies A CRect type value.  
	//		crBorder---crBorder, Specifies A 32-bit COLORREF value used as a color value.  
	//		&rectBorderSize---Border Size, Specifies A CRect type value.  
	//		4---Specifies a 4 object(Value).  
	//		4---Specifies a 4 object(Value).  
	//		4)---Specifies a 4) object(Value).
	virtual void OnDrawBarBorder(CDC* pDC,const CRect &rectBorder, COLORREF crBorder, const CRect &rectBorderSize = CRect(4,4,4,4));

public:

	// Calculate width line.
	// ptEnd -- end point of the line.
	// ptNext -- next point of the next line.
	// aParam -- line style.
	// nLineWidth -- line width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Width Line, .
	// Parameters:
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		ptNext---ptNext, Specifies A integer value.  
	//		aParam---aParam, Specifies a FOPLineParam& aParam object(Value).  
	//		&nLineWidth---Line Width, Specifies A integer value.
	void CalcWidthLine(const FOPPoint& ptEnd, const FOPPoint& ptNext, 
		FOPLineParam& aParam,const int &nLineWidth);

	// Draw line with width larger than 1.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// ptNext -- next point of the line.
	// aParam -- line style.
	// nLineWidth -- width of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Width Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		pNext---pNext, A pointer to the const FOPPoint or NULL if the call failed.  
	//		aParam---aParam, Specifies a FOPLineParam& aParam object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void DoDrawWidthLine(CDC *pDC,const FOPPoint& ptStart, const FOPPoint& ptEnd, 
		const FOPPoint* pNext,
		FOPLineParam& aParam,FOPLineInfo &aLineDash);

	// Draw line with width larger than 1.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// ptNext -- next point of the line.
	// aParam -- line style.
	// nLineWidth -- width of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Width Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		pNext---pNext, A pointer to the const FOPPoint or NULL if the call failed.  
	//		aParam---aParam, Specifies a FOPLineParam& aParam object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void GenPolygonsHelper(CArray <FOPPolygon, FOPPolygon> &mptTemp,const FOPPoint& ptStart, const FOPPoint& ptEnd, 
		const FOPPoint* pNext,
		FOPLineParam& aParam,FOPLineInfo &aLineDash);

	// Draw polygon style line.
	// aPoly-- polygon for drawing.
	// bClosePoly -- close polygon or not.
	// nLineWidth -- width of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		bClosePoly---Close Polygon, Specifies A Boolean value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void DoGenPipePolgon(CArray <FOPPolygon, FOPPolygon> &mptTemp, const FOPPolygon& aPoly,
		BOOL bClosePoly,FOPLineInfo &aLineDash);

	//-----------------------------------------------------------------------
	// Summary:
	// Imp_ Draw Polygon Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).  
	//		bClosePoly---Close Polygon, Specifies A Boolean value.
	virtual void GenDrawPolygon(CPoint *ptsStart, CPoint *ptsEnd, FOPPolygon& aPolyOut,const FOPPolygon& aPoly,
		FOPLineInfo &aLineDash);

	// Draw polygon style line.
	// aPoly-- polygon for drawing.
	// bClosePoly -- close polygon or not.
	// nLineWidth -- width of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		bClosePoly---Close Polygon, Specifies A Boolean value.  
	//		&aLineDash---Line Dash, Specifies a FOPLineInfo &aLineDash object(Value).
	virtual void DoDrawPolygonLine(CDC *pDC,const FOPPolygon& aPoly,
		BOOL bClosePoly,FOPLineInfo &aLineDash);

	// Draw line with width smaller than 1.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// ptNext -- next point of the line.
	// aParam -- line style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Mini Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		aParam---aParam, Specifies a FOPLineParam& aParam object(Value).
	virtual void DoDrawMiniLine(CDC *pDC,const FOPPoint& ptStart,
		const FOPPoint& ptEnd, FOPLineParam& aParam);

	// Draw spline.
	// pDC -- pointer of DC.
	// spline -- spline object
	virtual void DoDrawSpline(CDC *pDC, const FOPSplineGeometry &spline);

	// Draw spline.
	// pDC -- pointer of DC.
	// spline -- spline object
	virtual void DoDrawComplexGeometry(CDC *pDC, const FOPComplexGeometry &geometry);

	// Draw spline.
	// pDC -- pointer of DC.
	// spline -- spline object
	virtual void DoFillComplexGeometry(CDC *pDC, const FOPComplexGeometry &geometry, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Draw spline.
	// pDC -- pointer of DC.
	// spline -- spline object
	virtual void DoFillComplexGeometry2(CDC *pDC, FOPComplexGeometry &geometry, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Fill spline.
	//		pDC -- pointer of DC.
	//		spline -- spline object
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void DoFillSpline(CDC *pDC, const FOPSplineGeometry &spline, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);

	// Draw pie shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Pie, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ellipse---Specifies a const FOPEllipse& ellipse object(Value).  
	//		dblStartAngle---Start Angle, Specifies a double dblStartAngle object(Value).  
	//		dblFinishAngle---Finish Angle, Specifies a double dblFinishAngle object(Value).  
	//		dblOffsetFromCenter---Offset From Center, Specifies a double dblOffsetFromCenter = 0. object(Value).
	virtual void DoDrawPie( CDC *pDC,
		const FOPEllipse& ellipse, 
		double dblStartAngle, double dblFinishAngle, 
		double dblOffsetFromCenter = 0.);
	
	// Draw Doughnut shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Doughnut, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcEllipse---rcEllipse, Specifies a const FOPEllipse& rcEllipse object(Value).  
	//		dHolePercent---Hole Percent, Specifies a double dHolePercent object(Value).  
	//		dStartAngle---Start Angle, Specifies a double dStartAngle object(Value).  
	//		dFinishAngle---Finish Angle, Specifies a double dFinishAngle object(Value).  
	//		dOffsetFromCenter---Offset From Center, Specifies a double dOffsetFromCenter = 0. object(Value).
	virtual void DoDrawDoughnut(CDC *pDC, 
		const FOPEllipse& rcEllipse, 
		double dHolePercent,	/* 0 - 1 */
		double dStartAngle, double dFinishAngle, 
		double dOffsetFromCenter = 0.);
	
	// Draw pie shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill Pie, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ellipse---Specifies a const FOPEllipse& ellipse object(Value).  
	//		dblStartAngle---Start Angle, Specifies a double dblStartAngle object(Value).  
	//		dblFinishAngle---Finish Angle, Specifies a double dblFinishAngle object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.  
	//		dblOffsetFromCenter---Offset From Center, Specifies a double dblOffsetFromCenter = 0. object(Value).
	virtual void DoFillPie( CDC *pDC,
		const FOPEllipse& ellipse, 
		double dblStartAngle, double dblFinishAngle, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush,
		double dblOffsetFromCenter = 0.);
	
	// Draw Doughnut shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill Doughnut, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcEllipse---rcEllipse, Specifies a const FOPEllipse& rcEllipse object(Value).  
	//		dHolePercent---Hole Percent, Specifies a double dHolePercent object(Value).  
	//		dStartAngle---Start Angle, Specifies a double dStartAngle object(Value).  
	//		dFinishAngle---Finish Angle, Specifies a double dFinishAngle object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.  
	//		dOffsetFromCenter---Offset From Center, Specifies a double dOffsetFromCenter = 0. object(Value).
	virtual void DoFillDoughnut(CDC *pDC, 
		const FOPEllipse& rcEllipse, 
		double dHolePercent,	/* 0 - 1 */
		double dStartAngle, double dFinishAngle,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush,
		double dOffsetFromCenter = 0.);
	
	// Draw fill polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDC*pDC---D C*p D C, A pointer to the CDC or NULL if the call failed.  
	//		pts---Specifies A integer value.
	virtual void XDrawPolygon(CDC*pDC, const FOPointsArray& pts);
	
	// Draw fill polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDC*pDC---D C*p D C, A pointer to the CDC or NULL if the call failed.  
	//		pts---Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.
	virtual void XFillPolygon(CDC*pDC, const FOPointsArray& pts,
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush);
	
	// Draw 3d pie.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw3 D Pie, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ellipse---Specifies a const FOPEllipse& ellipse object(Value).  
	//		dblHeight---dblHeight, Specifies a const double dblHeight object(Value).  
	//		dblStartAngle---Start Angle, Specifies a double dblStartAngle object(Value).  
	//		dblFinishAngle---Finish Angle, Specifies a double dblFinishAngle object(Value).  
	//		dblOffsetFromCenter---Offset From Center, Specifies a double dblOffsetFromCenter = 0. object(Value).  
	//		nDrawingFlags---Drawing Flags, Specifies A integer value.
	virtual void DoDraw3DPie(CDC *pDC, 
		const FOPEllipse& ellipse, 
		const double dblHeight,
		double dblStartAngle, double dblFinishAngle, 
		double dblOffsetFromCenter = 0.,
		int nDrawingFlags = 0xFFFF);
	
	// Draw 3d Doughnut shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw3 D Doughnut, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcEllipse---rcEllipse, Specifies a const FOPEllipse& rcEllipse object(Value).  
	//		dHolePercent---Hole Percent, Specifies a const double dHolePercent object(Value).  
	//		dHeight---dHeight, Specifies a const double dHeight object(Value).  
	//		dStartAngle---Start Angle, Specifies a double dStartAngle object(Value).  
	//		dFinishAngle---Finish Angle, Specifies a double dFinishAngle object(Value).  
	//		dOffsetFromCenter---Offset From Center, Specifies a double dOffsetFromCenter = 0. object(Value).  
	//		nFlags---nFlags, Specifies A integer value.
	virtual void DoDraw3DDoughnut(CDC *pDC,
		const FOPEllipse& rcEllipse, 
		const double dHolePercent,	/* 0 - 1 */
		const double dHeight,
		double dStartAngle, double dFinishAngle, 
		double dOffsetFromCenter = 0.,
		int nFlags = 0xFFFF);
	
	// Draw 3d pie.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill3 D Pie, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		ellipse---Specifies a const FOPEllipse& ellipse object(Value).  
	//		dblHeight---dblHeight, Specifies a const double dblHeight object(Value).  
	//		dblStartAngle---Start Angle, Specifies a double dblStartAngle object(Value).  
	//		dblFinishAngle---Finish Angle, Specifies a double dblFinishAngle object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.  
	//		dblOffsetFromCenter---Offset From Center, Specifies a double dblOffsetFromCenter = 0. object(Value).  
	//		nDrawingFlags---Drawing Flags, Specifies A integer value.
	virtual void DoFill3DPie(CDC *pDC, 
		const FOPEllipse& ellipse, 
		const double dblHeight,
		double dblStartAngle, double dblFinishAngle, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush,
		double dblOffsetFromCenter = 0.,
		int nDrawingFlags = 0xFFFF);
	
	// Draw 3d Doughnut shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill3 D Doughnut, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcEllipse---rcEllipse, Specifies a const FOPEllipse& rcEllipse object(Value).  
	//		dHolePercent---Hole Percent, Specifies a const double dHolePercent object(Value).  
	//		dHeight---dHeight, Specifies a const double dHeight object(Value).  
	//		dStartAngle---Start Angle, Specifies a double dStartAngle object(Value).  
	//		dFinishAngle---Finish Angle, Specifies a double dFinishAngle object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pBrush---*pBrush, A pointer to the CBrush  or NULL if the call failed.  
	//		dOffsetFromCenter---Offset From Center, Specifies a double dOffsetFromCenter = 0. object(Value).  
	//		nFlags---nFlags, Specifies A integer value.
	virtual void DoFill3DDoughnut(CDC *pDC,
		const FOPEllipse& rcEllipse, 
		const double dHolePercent,	/* 0 - 1 */
		const double dHeight,
		double dStartAngle, double dFinishAngle, 
		COLORREF crStart,COLORREF crEnd,UINT nFillType,CBrush *pBrush,
		double dOffsetFromCenter = 0.,
		int nFlags = 0xFFFF);

	// Do get view.
	virtual CView *GetActView();

public:
	/////////////////////////////////////////////
	// For bitmap, it is designed for CFOPBitmapBoxShape

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bitmap, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	int AddBitmap( UINT resourceID);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bitmap, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		&strid---Specifies A CString type value.
	int AddBitmap( const CString &strid);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Bitmap, Call this function to remove a specify value from the specify object.
	//		Returns a int type value.  
	// Parameters:
	//		index---Specifies A integer value.
	int RemoveBitmap(int index);

	// Remove bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Bitmap2, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void RemoveBitmap2(UINT resourceID);

	// Remove bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Bitmap3, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		&strid---Specifies A CString type value.
	void RemoveBitmap3(const CString &strid);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Bitmaps, Remove the specify data from the list.
	//		Returns a int type value.
	int ClearAllBitmaps();

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CBitmap* GetBitmap(UINT resourceID);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap2, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		&strid---Specifies A CString type value.
	CBitmap* GetBitmap2(const CString &strid);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap3, Returns the specified value.
	//		Returns a pointer to the object CFOPBitmapData,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CFOPBitmapData* GetBitmap3(int index);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap4, Returns the specified value.
	//		Returns a pointer to the object CFOPBitmapData,or NULL if the call failed  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPBitmapData* GetBitmap4(UINT resourceID);

	// Add bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap5, Returns the specified value.
	//		Returns a pointer to the object CFOPBitmapData,or NULL if the call failed  
	// Parameters:
	//		&strid---Specifies A CString type value.
	CFOPBitmapData* GetBitmap5(const CString &strid);


	// Obtain current drawing gradient type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gradient, Returns the specified value.
	//		Returns a pointer to the object FOPGradient ,or NULL if the call failed
	FOPGradient *GetGradient() { return &m_aGradient; }
	
	// Title bitmap.
	// pDC -- pointer of the DC.
	// rect -- rectangle for drawing.
	// bTitle -- title the bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill With Bitmap, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bTitle---bTitle, Specifies A Boolean value.  
	//		uResourceID---Resource I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL FillWithBitmap(CDC *pDC, CRect rect,BOOL bTitle, UINT uResourceID );
	
	// Fill vector gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Vertor Gradient, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void FillVertorGradient(CDC *pDC,LPCRECT lpRect, COLORREF crStart,
		COLORREF crEnd, UINT nType);
	
	// Gradient fill.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gradient Fill, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrLeft---clrLeft, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrRight---clrRight, Specifies A 32-bit COLORREF value used as a color value.  
	//		dwMode---dwMode, Specifies A 32-bit LONG signed integer.
	BOOL GradientFill(CDC* pDC, LPCRECT lpRect, COLORREF clrLeft, COLORREF clrRight, ULONG dwMode);
	
	// Four points gradient fill.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Four Point Gradient Fill, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrBottomLeft---Bottom Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrBottomRight---Bottom Right, Specifies A 32-bit COLORREF value used as a color value.
	BOOL FourPointGradientFill(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight,
		COLORREF clrBottomLeft, COLORREF clrBottomRight);
	
	// Gradient fill x.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gradient Fill X, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		pVertex---pVertex, Specifies a PTRIVERTEX pVertex object(Value).  
	//		dwNumVertex---Number Vertex, Specifies A 32-bit LONG signed integer.  
	//		pMesh---pMesh, Specifies a PVOID pMesh object(Value).  
	//		dwNumMesh---Number Mesh, Specifies A 32-bit LONG signed integer.  
	//		dwMode---dwMode, Specifies A 32-bit LONG signed integer.
	BOOL GradientFillX(HDC hdc, PTRIVERTEX pVertex, ULONG dwNumVertex, PVOID pMesh, ULONG dwNumMesh, ULONG dwMode);
	
	// Fast gradient fill
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gradient Fill Fast, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		crFrom---crFrom, Specifies A 32-bit COLORREF value used as a color value.  
	//		crTo---crTo, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	void GradientFillFast(CDC* pDC, LPCRECT lpRect, COLORREF crFrom, COLORREF crTo, BOOL bHorz);
	
	// Extend gradient fill.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gradient Fill X Extend, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		crFrom---crFrom, Specifies A 32-bit COLORREF value used as a color value.  
	//		crTo---crTo, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	void GradientFillXExt(CDC* pDC, LPCRECT lpRect, COLORREF crFrom, COLORREF crTo, BOOL bHorz);

	// Fill vector gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Vertor Gradient Extend, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void FillVertorGradientExt(CDC *pDC,LPCRECT lpRect, COLORREF crStart,
		COLORREF crEnd, UINT nType);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient Extend, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	void FillAngleGradientExt(CDC *pDC,CRect rcPos, COLORREF crStart, 
		COLORREF crEnd, int nAngle);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	void FillAngleGradient(CDC *pDC,const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd, int nAngle);

	// Is gradient ok or not.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Gradient O K, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	BOOL IsGradientOK(CDC *pDC);

	// Is transparent OK
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent Bitblt O K, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	BOOL IsTransparentBltOK(CDC *pDC);


	// Fill two parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Two Part Gradient, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillTwoPartGradient(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);

	// Fill three parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Three Part Gradient, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillThreePartGradient(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);

	// Fill three parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Three Part Gradient2, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillThreePartGradient2(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);


	// Fill three parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Three Part Gradient3, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillThreePartGradient3(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);
	

	// Fill three parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Three Part Gradient4, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillThreePartGradient4(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);
	
	// Fill two parts of gradient.
	// pDC -- pointer of the DC.
	// lpRect -- position for drawing.
	// clrTopLeft -- start color for gradient drawing.
	// clrTopRight -- end color for gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Two Part Gradient2, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clrTopLeft---Top Left, Specifies A 32-bit COLORREF value used as a color value.  
	//		clrTopRight---Top Right, Specifies A 32-bit COLORREF value used as a color value.
	void FillTwoPartGradient2(CDC* pDC, LPCRECT lpRect,
		COLORREF clrTopLeft, COLORREF clrTopRight);

	// Draw radial gradient.
	// pDC -- pointer of the DC.
	// x -- center point's x value.
	// y -- center point's y value.
	// r -- radius value.
	// c1 -- start color for gradient drawing.
	// c2 -- end color for gradient drawing.
	// segments -- for triangles. Default is 16
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Radial Gradient, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		r---Specifies A integer value.  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		segments---Specifies A integer value.
	BOOL FillRadialGradient(
		CDC* pDC, 
		int x, 
		int y, 
		int r,
		COLORREF c1,
		COLORREF c2,
		int segments );

	// Transparent blt.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transparent Bitblt, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nXDest---X Dest, Specifies A integer value.  
	//		nYDest---Y Dest, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		pDcSrc---Dc Source, A pointer to the CDC or NULL if the call failed.  
	//		nXSrc---X Source, Specifies A integer value.  
	//		nYSrc---Y Source, Specifies A integer value.  
	//		colorTransparent---colorTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		nWidthDest---Width Dest, Specifies A integer value.  
	//		nHeightDest---Height Dest, Specifies A integer value.
	void TransparentBlt (CDC *pDC, int nXDest, int nYDest, int nWidth, 
								int nHeight, CDC* pDcSrc, int nXSrc, int nYSrc,
								COLORREF colorTransparent,
								int nWidthDest = -1, int nHeightDest = -1);

	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardFormatNew() const;


	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardTableCell() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardSdrTableCell() const;

	// Draw theme text.
	BOOL DoDrawThemeText(CDC* pDC, CString strText, CRect rect, DWORD dwFlags,
		int nGlowSize = 0, COLORREF clrText = (COLORREF)-1);

	// Draw theme icon.
	BOOL DoDrawThemeIcon(CDC* pDC, HICON hIcon, CRect rect);

	// Prepare poly drawing.
	void FOPPreparePolyDraw(  BOOL	bCloseFigures,
		ULONG 						nPoly,
		const ULONG* 				pPoints,
		const fopPointExt* const*	pPtAry,
		const BYTE* const* 			pFlgAry,
		POINT* 						pWinPointAry,
        BYTE* 						pWinFlagAry		);

	// Render path.
	void FOPDoRenderPath( HDC hdc, ULONG nPoints, const fopPointExt* pPtAry, const BYTE* pFlgAry );

	// Obtain visio handle.
	CFOPHandle* FOP_VisioGetHandle(int nHandle,const FOPPoint *pts, const BOOL &bInvert, int nAngle);

	// Convert degree to radius
	double fop_deg2rad(double dwCur);

	// Radius to degree.
	double fop_rad2deg(double dwCur);
	
	// Angle.
	double fop_angle (double dx, double dy);

	// Distance point to point.
	double FOPDistance_point_point(const CPoint *p1, const CPoint *p2);

	// Minimize value.
	double FOPMinX(double a, double b);

	// Draw header sort arrow.
	void FOPDoDrawHeaderSortArrow (CDC* pDC, CRect rect, BOOL bIsUp, BOOL bDlgCtrl);

	// Normalize degree.
	// value
	double fop_normalize_deg(double dwCur);

	// Cool extend text out.
	virtual void CoolExTextOut(CDC* pDC, CRect rect, UINT nOptions, CRect rctClip,
				LPCTSTR lpszString, UINT nCount,int nArtFontType, const COLORREF &crShadow);

	// Do extent text out
	virtual void DoExtTextOut(CDC* pDC, int X, int Y, UINT fuOptions, CRect rctClip, 
		LPCTSTR lpString, UINT cbCount, LPINT lpDxWidths);

	// Fill gradient ring.
	virtual BOOL FillGradRing(CDC* pDC,const FOPRect &rcDraw,
		const COLORREF &crStart, const COLORREF &crEnd,
		const COLORREF &crLine,
		int nAngle,	int nBrdWidth, const COLORREF &crFace = (COLORREF) -1);

public:
	/////////////////////////////////////////////
	// For CImageList, it is designed for CFOPImageListBoxShape shape.

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Image List, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&crTrans---&crTrans, Specifies A 32-bit COLORREF value used as a color value.
	int AddImageList( UINT resourceID, const int &nWidth, const COLORREF &crTrans);

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Image List, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void RemoveImageList(UINT resourceID);

	// Remove ImageList
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Image List2, Call this function to remove a specify value from the specify object.
	//		Returns a int type value.  
	// Parameters:
	//		index---Specifies A integer value.
	int RemoveImageList2(int index);

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Image Lists, Remove the specify data from the list.
	//		Returns a int type value.
	int ClearAllImageLists();

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List, Returns the specified value.
	//		Returns a pointer to the object CImageList,or NULL if the call failed  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&crTrans---&crTrans, Specifies A 32-bit COLORREF value used as a color value.
	CImageList* GetImageList(UINT resourceID, const int &nWidth, const COLORREF &crTrans);

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List2, Returns the specified value.
	//		Returns a pointer to the object CFOPImageListData,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CFOPImageListData* GetImageList2(int index);

	// Add ImageList.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List3, Returns the specified value.
	//		Returns a pointer to the object CFOPImageListData,or NULL if the call failed  
	// Parameters:
	//		resourceID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPImageListData* GetImageList3(UINT resourceID);

protected:
	// Convert text to number
	// strText -- text for converting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Text To Number, .
	//		Returns A double value (Object).  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	double	ConvertTextToNumber(CString strText);

	
	// Segmented radial gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Segmented Radial Gradient_, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		ctr---Specifies a const POINT& ctr object(Value).  
	//		radius---Specifies A integer value.  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		segments---Specifies A integer value.  
	//		alpha1---Specifies An 8-bit BYTE integer that is not signed.  
	//		alpha2---Specifies An 8-bit BYTE integer that is not signed.
	bool SegmentedRadialGradient_(
		HDC hdc, 
		const POINT& ctr, 
		int radius,
		double startAngle,
		COLORREF c1,
		COLORREF c2,
		int segments,
		BYTE alpha1 = 0xFF,
		BYTE alpha2 = 0xFF
		);
	
	// Draw rectangle gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Gradient, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		&rc---Specifies a const RECT &rc object(Value).  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		isVertical---isVertical, Specifies A Boolean value.  
	//		alpha1---Specifies An 8-bit BYTE integer that is not signed.  
	//		alpha2---Specifies An 8-bit BYTE integer that is not signed.
	bool RectGradient(
		HDC hDC,
		const RECT &rc, 
		COLORREF c1, 
		COLORREF c2,
		BOOL isVertical,
		BYTE alpha1 = 0xFF,
		BYTE alpha2 = 0xFF
		);
	
	// Draw radial gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Radial Gradient, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		r---Specifies A integer value.  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		segments---Specifies A integer value.  
	//		alpha1---Specifies An 8-bit BYTE integer that is not signed.  
	//		alpha2---Specifies An 8-bit BYTE integer that is not signed.
	bool RadialGradient(
		HDC hdc, 
		int x, 
		int y, 
		int r,
		COLORREF c1,
		COLORREF c2,
		int segments,
		BYTE alpha1 = 0xFF,
		BYTE alpha2 = 0xFF
		);
	
	// Draw angular gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Angular Gradient, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		&rc---Specifies a const RECT &rc object(Value).  
	//		angle---Specifies a double angle object(Value).  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		alpha1---Specifies An 8-bit BYTE integer that is not signed.  
	//		alpha2---Specifies An 8-bit BYTE integer that is not signed.
	bool AngularGradient(
		HDC hdc,
		const RECT &rc,
		double angle,
		COLORREF c1,
		COLORREF c2,
		BYTE alpha1 = 0xFF,
		BYTE alpha2 = 0xFF
		);

	// Draw angular gradient helper
	
	//-----------------------------------------------------------------------
	// Summary:
	// Angular Gradient_, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		rc---Specifies a const RECT& rc object(Value).  
	//		angle---Specifies a double angle object(Value).  
	//		c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		c2---Specifies A 32-bit COLORREF value used as a color value.  
	//		alpha1---Specifies An 8-bit BYTE integer that is not signed.  
	//		alpha2---Specifies An 8-bit BYTE integer that is not signed.
	bool AngularGradient_(
		HDC hdc,
		const RECT& rc,
		double angle,
		COLORREF c1,
		COLORREF c2,
		BYTE alpha1 = 0xFF,
		BYTE alpha2 = 0xFF
		);


public:

	// rotate
	POINT foxRotate(POINT pt, const POINT& ptCenter, long nAngle);

	// rotate.
	void foxRotate(POINT pt[], long nCount, const POINT& ptCenter, long nAngle);

public:

	// Open theme.
	HTHEME OpenThemeData(HWND hWnd, LPCTSTR lpszClassList);

	// Obtain theme system color.
	COLORREF GetThemeSysColor(HTHEME hTheme, int iColorID);

	// Obtain window theme.
	HTHEME GetWindowTheme(HWND hWnd);

	// Draw theme background.
	BOOL DrawThemeBackground(HTHEME hTheme, HDC hdc, int iPartId, int iStateId,
		LPCRECT pRect, LPCRECT pClipRect);

	// Draw theme text.
	BOOL DrawThemeText(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, LPCTSTR lpszText, 
		int iCharCount, DWORD dwTextFlags, DWORD dwTextFlags2, LPCRECT pRect);	

	// Is theme loaded.
	BOOL IsUxThemeLoaded();
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes:
protected:

	// Line patterns
 
	// Line Pattern, This member maintains a pointer to the object long.  
	long*						m_pLinePattern;
	
	// Line patterns count
 
	// Total Pattern, This member specify USHORT object.  
	USHORT						m_nTotalPattern;
	
	// Showing border or not.
 
	// With Border Show, This member sets TRUE if it is right.  
	BOOL						m_bWithBorderShow;

	// Visual proxy
 
	// Vis Proxy, This member maintains a pointer to the object CFOPVisualProxy.  
	static CFOPVisualProxy*		m_pVisProxy;

	// bitmap list
 
	// List, This member maintains a pointer to the object CFOPCachePtrList.  
	CFOPCachePtrList			*m_bitmapList;

	// image list
 
	// List, This member maintains a pointer to the object CFOPCachePtrList.  
	CFOPCachePtrList			*m_imageList;

	// Prebuild gradient type.
 
	// Gradient, This member specify FOPGradient object.  
	FOPGradient					m_aGradient;

	// Clipboard support.
	
	// Cf Draw, This member specify CLIPFORMAT object.  
	static CLIPFORMAT			m_foCfDraw; 
	
	// Cf Draw, This member specify CLIPFORMAT object.  
	static CLIPFORMAT			m_foCfTable; 

	// Cf Draw, This member specify CLIPFORMAT object.  
	static CLIPFORMAT			m_foCfSdrTable; 
	
public:
	// Handle of image DLL
 
	// Ms Img Dll, This member specify HMODULE object.  
	HMODULE						m_hMsImgDll;

	// Handle of theme dll.
	HINSTANCE					m_hinstUXThemeDLL;
	// Transparent bitblt
 
	// Transparent Bitblt, This member specify FOP_TRANSPARENTBLT object.  
	FOP_TRANSPARENTBLT			m_pfnTransparentBlt;

	// Gradient fill.
 
	// Fast Gradient Fill, This member specify FOP_PFNGRADIENTFILL object.  
	FOP_PFNGRADIENTFILL			m_pfnFastGradientFill;

	// Alpha blend
	
	// Alpha Blend, This member specify FOPALPHABLEND object.  
	static FOPALPHABLEND	m_pfAlphaBlend;

	// Draw theme background.
	FOP_DRAWTHEMEPARENTBACKGROUND		m_pfDrawThemeBackground;

	// Draw theme text.
	FOP_DRAWTHEMETEXTEX					m_pfDrawThemeTextEx;

	// Draw theme icon
	FOP_DRAWTHEMEICON					m_pfDrawThemeIcon;

	// Begin buffered paint.
	FOP_BEGINBUFFEREDPAINT				m_pfBeginBufferedPaint;

	// Buffered paint set alpha.
	FOP_BUFFEREDPAINTSETALPHA			m_pfBufferedPaintSetAlpha;

	// End buffered paint.
	FOP_ENDBUFFEREDPAINT				m_pfEndBufferedPaint;

	// Open theme.
	FOP_OPENTHEMEDATA					m_pfOpenThemeData;

	// Close theme
	FOP_CLOSETHEMEDATA					m_pfCloseThemeData;

	// Theme button.
	HTHEME								m_hThemeButton;
	
	// Theme window.
	HTHEME								m_hThemeWindow;

	// Theme of combo box.
	HTHEME								m_hThemeComboBox;

	// Theme of track
	HTHEME								m_hThemeTrack;

	// Is initialized or not.
 
	// Initialized, This member sets TRUE if it is right.  
	BOOL								m_bInitialized;

	// Current dc.
	CDC*								m_pDrawDC;

	// Predefined cos values.
	static double						m_foCOS[360];

	// Predefined sin values
	static double						m_foSIN[360];

	static CDC							*pDCGlyphs;
};

// Init bitmap resources.
FO_API_DECL CFOPVisualProxy* AFX_API XDDraw();

#endif // !defined(FO_FOPVISUALPROXY_H__700783E5_CB1B_41BB_AE5B_4F4288B61FF4__INCLUDED_)
