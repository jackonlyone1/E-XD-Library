//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOADDLINKACTION_H__DF116C82_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
#define AFC_FOADDLINKACTION_H__DF116C82_DD9D_11D5_A4AC_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action
///////////////////////////////////////
#include "FOPortShape.h"
#include "FOAction.h"

class CFOCompositeShape;
//////////////////////////////////////////////////////////////////////////////////
// CFOAddLinkAction -- action that create link between shapes.

 
//===========================================================================
// Summary:
//     The CFOAddLinkAction class derived from CFOAction
//      F O Add Link Action
//===========================================================================

class FO_EXT_CLASS CFOAddLinkAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddLinkAction---F O Add Link Action, Specifies a E-XD++ CFOAddLinkAction object (Value).
	DECLARE_ACTION(CFOAddLinkAction)

public:
	
	// member
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Link Action, Constructs a CFOAddLinkAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOAddLinkAction(CFODataModel* pModel, CFODrawShape* pShape);

	// member
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Link Action, Destructor of class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAddLinkAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

    // Set shape member variable m_pShape to the pointer of pShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	//  Returns a pointer to the Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set To Port, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetToPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetToPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set From Port, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetFromPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetFromPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Third Port, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetThirdPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Third Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetThirdPort();

	// Obtain the composite shape's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();


	// Obtain the lay on link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lay Link, Returns the specified value.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed
	CFOLinkShape *GetLayLink() { return m_pLayOnLink; }
	
	// Set the lay on link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lay Link, Sets a specify value to current class CFOAddLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void SetLayLink(CFOLinkShape *pLink) { m_pLayOnLink = pLink; }

// Attributes
protected:

	// member variable ,a pointer to the Shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	// member variable ,a pointer to the destiny Shape
 
	// To Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pToPort;

	// member variable ,a pointer to the source Shape
 
	// From Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pFromPort;

	// The pointer of third port.
 
	// Third Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *	m_pThirdPort;

	// Lay on link shape.
 
	// Lay On Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *  m_pLayOnLink;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
	// Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

  //  Returns a pointer to the Shape	
_FOLIB_INLINE CFODrawShape *CFOAddLinkAction::GetShape()
{
	return m_pShape;
}
   //  Set shape member variable m_pToPort to the pointer of pShape
_FOLIB_INLINE void CFOAddLinkAction::SetToPort(CFOPortShape *pShape)
{
	m_pToPort = pShape;
}
   //  Get   the pointer to the destiny Shape
_FOLIB_INLINE CFOPortShape *CFOAddLinkAction::GetToPort()
{
	return m_pToPort;
}
  //Set shape member variable m_pFromPort to the pointer of pShape
_FOLIB_INLINE void CFOAddLinkAction::SetFromPort(CFOPortShape *pShape)
{
	m_pFromPort = pShape;
}
  //  Get   the pointer to the source Shape
_FOLIB_INLINE CFOPortShape *CFOAddLinkAction::GetFromPort()
{
	return m_pFromPort;
}


_FOLIB_INLINE void CFOAddLinkAction::SetThirdPort(CFOPortShape *pShape)
{
	m_pThirdPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFOAddLinkAction::GetThirdPort()
{
	return m_pThirdPort;
}

#endif // !defined(AFC_FOADDLINKACTION_H__DF116C82_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
