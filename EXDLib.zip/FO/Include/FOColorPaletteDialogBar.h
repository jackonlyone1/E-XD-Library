//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOColorPaletteDialogBar.h: interface for the CFOColorPaletteDialogBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCOLORPALETTEDIALOGBAR_H__845667C3_F58E_11DD_A43A_525400EA266C__INCLUDED_)
#define AFX_FOCOLORPALETTEDIALOGBAR_H__845667C3_F58E_11DD_A43A_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFOColorPaletteDialogBar window
#include "FOColorPaletteControl.h"

 
//===========================================================================
// Summary:
//     The CFOColorPaletteDialogBar class derived from CDialogBar
//      F O Color Palette Dialog Bar
//===========================================================================

class FO_EXT_CLASS CFOColorPaletteDialogBar : public CDialogBar
{

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Color Palette Dialog Bar, Constructs a CFOColorPaletteDialogBar object.
	//		Returns A  value (Object).
	CFOColorPaletteDialogBar();

// Attributes
public:

	// Init palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Palette, Call InitPalette after creating a new object.

	void InitPalette();

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color , Returns the specified value.
	//		Returns a pointer to the object CFOColorPaletteControl ,or NULL if the call failed
	CFOColorPaletteControl *GetColorControl() { return m_pColorControl; }

protected:

	// Set Text Colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Colors, Sets a specify value to current class CFOColorPaletteDialogBar
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.
	virtual void SetColors(COLORREF crText,COLORREF crBack);

public:

	// Update Action 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CFrameWnd or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

	// Color Change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bLine---bLine, Specifies A Boolean value.
	virtual void OnColorChange(COLORREF crColor,BOOL bLine);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOColorPaletteDialogBar)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Color Palette Dialog Bar, Destructor of class CFOColorPaletteDialogBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOColorPaletteDialogBar();

	// Draw line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnLineDraw(CDC *pDC);

	// Draw Line Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnLineDrawSelect(CDC *pDC);

	// Draw back
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Back Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnBackDraw(CDC *pDC);

	// Draw back selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Back Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnBackDrawSelect(CDC *pDC);

	// Generated message map functions
protected:

	//{{AFX_MSG(CFOColorPaletteDialogBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Day O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnSelectDayOK(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Day Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnSelectDayCancel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Custom, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnSelectCustom(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	// The pointer to ColorPaletteControl
 
	// Color , This member maintains a pointer to the object CFOColorPaletteControl.  
	CFOColorPaletteControl *m_pColorControl;

	// Bitmap
 
	// Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap					m_Bitmap;

	// CDC
 
	// Memory D C, This member specify CDC object.  
	CDC						m_MemDC;

	// Text Rectangle
 
	// Text, This member sets a CRect value.  
	CRect					m_rcText;

	// Back Rectangle
 
	// Back, This member sets a CRect value.  
	CRect					m_rcBack;

	// line color.
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crText;
	
	// back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crBack;  
	
	// If true is in line,else it is in back.
 
	// Select Line, This member sets TRUE if it is right.  
	BOOL					bSelectLine;

	// The pointer to Notify Window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*					pNotifyWnd;
};

#endif // !defined(AFX_FOCOLORPALETTEDIALOGBAR_H__845667C3_F58E_11DD_A43A_525400EA266C__INCLUDED_)
