//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPCOLORPICKERDRAWPANEL_H__E8943F09_F49D_4879_A2F7_05EAA8D8943E__INCLUDED_)
#define AFX_FOPDROPCOLORPICKERDRAWPANEL_H__E8943F09_F49D_4879_A2F7_05EAA8D8943E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropColorPickerDrawPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDropColorPickerDrawPanel window
#include "FOPDrawControlPanel.h"

const unsigned FOP_MSG__COLOR_CHANGE	= 1;
const unsigned FOP_MSG__COLOR_CYCLE		= 2;
const unsigned FOP_MSG__COLOR_NONE		= 3;
const unsigned FOP_MSG__COLOR_CUSTOM	= 4;
const unsigned FOP_MSG__COLOR_CANCEL	= 5;
const unsigned FOP_MSG__COLOR_BUTTON2	= 6;

// Color table entry
struct FOPColorTableEntry 
{
	// Color value.
    COLORREF	crColor;

	// Color name.
    LPCTSTR		szName;
};

 
//===========================================================================
// Summary:
//     The FOPColorPickerDrawPanel class derived from FOPDrawControlPanel
//      O P Color Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPColorPickerDrawPanel : public FOPDrawControlPanel
{
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Color Picker Draw Panel, Constructs a FOPColorPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarBoth object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
					FOPColorPickerDrawPanel(HasHeaderBar ind = HeaderBarBoth, 
						HasButton but = ButtonOne);
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Color Picker Draw Panel, Destructor of class FOPColorPickerDrawPanel
	//		Returns A  value (Object).
					~FOPColorPickerDrawPanel();

	// Default number of colors.
	enum { DefaultTotalColorPickers = 70};
	
	// virtual functions called from FOPPickerBaseWnd

	// Create palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Palette, You construct a FOPColorPickerDrawPanel object in two steps. First call the constructor, then call Create, which creates the object.

	void			CreatePalette();

	// Select palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Palette, Call this function to select the given item.
	//		Returns a pointer to the object CPalette,or NULL if the call failed  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		realize---Specifies A Boolean value.
	CPalette*		SelectPalette(CDC& dc, BOOL  realize);

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetMainGroupName(int nIndex);

	// Get extra group name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetExtraGroupName(int nIndex);

	// Draw main group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw extra grouo face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw headerbar face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Header Bar Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawHeaderBarFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup);

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int nIndex, BOOL  IsPopup);

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int nIndex, BOOL  IsPopup);

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int nIndex, BOOL  IsPopup);

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int nIndex, BOOL  IsPopup);

	// Is main group enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL 	IsMainGroupEnabled(int nIndex);

	// assessor functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Use Palette, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetUsePalette() const		{	return m_bUsePalette;			}

	// Get extra color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const COLORREF& GetExtraColor(int nIndex) const	{	return arExtraColorsArray[nIndex]->crColor;		}

	// Get colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Colors, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const COLORREF& GetColors(int nIndex) const		{	return arColors[nIndex].crColor;	}

	// Get number of extra colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Extra Colors, Returns the specified value.
	//		Returns a int type value.
	int				GetNumExtraColors()			{	return (int)arExtraColorsArray.GetSize();		}

	// Get color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetColor();

	// mutator functions
	//
	//				For safety reasons this function does not take ownership of the "set" at a slight
	//				performance cost, i.e. separate copies
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Color Set, .
	// Parameters:
	//		set---A pointer to the const FOPColorTableEntry  or NULL if the call failed.  
	//		count---Specifies A integer value.
	void			ReplaceColorSet(const FOPColorTableEntry * set, int count);

	// Set use palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use Palette, Sets a specify value to current class FOPColorPickerDrawPanel
	// Parameters:
	//		bUse---bUse, Specifies A Boolean value.
	void			SetUsePalette(BOOL  bUse)		{	 m_bUsePalette = bUse;			}

	// Set color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class FOPColorPickerDrawPanel
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void			SetColor(const COLORREF& color);

	// for colors not in the standard set but user-selected, e.g. via "More..."
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Extra Colors, Adds an object to the specify list.
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void			AddToExtraColors(const COLORREF& color);

	// Remove extra colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Extra Colors, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		NoReserveSpace---No Reserve Space, Specifies A Boolean value.
	void			RemoveExtraColors(BOOL  NoReserveSpace = FALSE);

	// Set headerbar state,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPColorPickerDrawPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	void			SetHeaderBarState(HasHeaderBar ind);

	// Set sunken mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPColorPickerDrawPanel
	// Parameters:
	//		bSunken---bSunken, Specifies A Boolean value.
	void			SetSunkenMode(BOOL  bSunken);

	// response functions

	// Do when color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void	DoWellColorChange(const COLORREF& color);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choose custom color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Color, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomColor();

	// Do when choose color none
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellColorNone();

	// Do when choose color automatic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color Automatic, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellColorAuto();

	// Do when choose button two.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Button Two, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellButtonTwo();

	// Get automatic color string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Automatic Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetAutomaticText() const { return m_strAuto; }

	// Set automatic color string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Text, Sets a specify value to current class FOPColorPickerDrawPanel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void	SetAutomaticText(const CString &strValue) { m_strAuto = strValue; }

	// Automatic color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Automatic Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetAutomaticColor()	{	return m_crAutomatic; }

	// Set automatic color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Color, Sets a specify value to current class FOPColorPickerDrawPanel
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetAutomaticColor(const COLORREF &crColor) { m_crAutomatic = crColor; }

	// None color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color None, Returns the specified value.
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.
	static const COLORREF	GetColorNone()	{	return (COLORREF) 0xFEFFFFFF; }

protected:

	// Extra colors.
	CTypedPtrArray<CPtrArray,FOPColorTableEntry*> arExtraColorsArray;

	// Number of colors.
 
	// Total Color Pickers, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nTotalColorPickers;

	// Use palette or not,
 
	// Use Palette, This member sets TRUE if it is right.  
	BOOL 						m_bUsePalette;

	// index of last added extra color
 
	// Total Extra Add Pickers, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nTotalExtraAddPickers;	
	
	// Colors
 
	// Colors, This member maintains a pointer to the object FOPColorTableEntry.  
	FOPColorTableEntry*			arColors;

	// Replace color set.
 
	// Replacement Color Set, This member maintains a pointer to the object FOPColorTableEntry.  
	FOPColorTableEntry*			arReplacementColorSet;

	// Default colors.
 
	// Default Colors[ Default Total Color Pickers], This member specify FOPColorTableEntry object.  
	static FOPColorTableEntry	m_DefaultColors[DefaultTotalColorPickers];

	// Palette
 
	// Palette, This member specify CPalette object.  
	CPalette					m_Palette;

	// display when disabled
 
	// Greyed Palette, This member specify CPalette object.  
	CPalette					m_GreyedPalette;		
	
	// Automatic color value.
 
	// Automatic, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crAutomatic;

	// Automatic color string value.
 
	// Automatic, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strAuto;
};

// DDX
void DDX_ColorWell(CDataExchange* pDX, FOPColorPickerDrawPanel& w, COLORREF& color);

struct FOPDropColorPickerCallback
{
	// Do when value change.
	virtual void	OnWellColorChange(const COLORREF& color) = 0;

	// Do when cancel action.
	virtual void	OnWellCancel() = 0;

	// Do when choose custom color button.
	virtual void	OnWellCustomColor() = 0;

	// Do when choose color none button.
	virtual void	OnWellColorNone() = 0;

	// Do when choose color automatic button.
	virtual void	OnWellColorAuto() = 0;

	// Do when choose button two.
	virtual void	OnWellButtonTwo() = 0;
};

 
//===========================================================================
// Summary:
//     The FOPDropColorPickerDrawPanel class derived from FOPColorPickerDrawPanel
//      O P Drop Color Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPDropColorPickerDrawPanel : public FOPColorPickerDrawPanel
{

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Color Picker Draw Panel, Constructs a FOPDropColorPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarBoth object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).  
	//		btn---A pointer to the FOPDropColorPickerCallback or NULL if the call failed.
	FOPDropColorPickerDrawPanel(HasHeaderBar ind = HeaderBarBoth,HasButton but = ButtonOne,
		FOPDropColorPickerCallback* btn = 0);

	// response functions
	// Do when color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void	DoWellColorChange(const COLORREF& color);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choose custom color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Color, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomColor();

	// Do when choose color none
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellColorNone();

	// Do when choose color automatic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Color Automatic, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellColorAuto();

	// Do when choose button two.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Button Two, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellButtonTwo();

	// Set button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPDropColorPickerDrawPanel
	// Parameters:
	//		button---A pointer to the FOPDropColorPickerCallback or NULL if the call failed.
	void SetButton(FOPDropColorPickerCallback* button)	{	Button = button;	}

	
protected:
	// Button.
 
	// This member maintains a pointer to the object FOPDropColorPickerCallback.  
	FOPDropColorPickerCallback* Button;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPCOLORPICKERDRAWPANEL_H__E8943F09_F49D_4879_A2F7_05EAA8D8943E__INCLUDED_)
