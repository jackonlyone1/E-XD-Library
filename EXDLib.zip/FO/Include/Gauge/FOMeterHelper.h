//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMETERHELPER_H__253EAB6C_499E_4B9D_8F63_2C06EB3DC63A__INCLUDED_)
#define FO_FOMETERHELPER_H__253EAB6C_499E_4B9D_8F63_2C06EB3DC63A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODrawShape.h"

// Meter scale classes:
// CFOPMeterScale
// CFOPMeterEllipticalScale

// Meter indicator classes:
// CFOPIndicatorBar -- can be added as many FOPPhase as you want.
// CFOPIndicatorElliptical
// CFOPIndicatorSlider -- slider with bar linear fopBar and fopTriangles
// CFOPIndicatorSliderElliptical -- slider with elliptical
// CFOPIndicatorNeedle -- needle with fpBar, fpKite, fpLine
// CFOPIndicatorKnob

// Style of scale linear shape
enum FOPScaleLinearStyle
{
        // Fields
   fopAlternateStartLeft = 2,
   fopAlternateStartRight = 3,
   fopLeft = 0,
   fopRight = 1
};

// Style of scale mark shape
enum FOPScaleMarkStyle
{
	// Fields
	fopMarkRect = 0,
		fopMarkTriangle = 1,
		fopMarkDiamond = 2,
		fopMarkTrapezoid = 3,
		fopMarkLine = 4,
		fopMarkCicle = 5
};

//////////////////////////////////////////////////////////////////////////////////
// CFOPMeterScale -- meter scale object.

 
//===========================================================================
// Summary:
//     The CFOPMeterScale class derived from CObject
//      F O P Meter Scale
//===========================================================================

class FO_EXT_CLASS CFOPMeterScale : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMeterScale---F O P Meter Scale, Specifies a E-XD++ CFOPMeterScale object (Value).
	DECLARE_SERIAL(CFOPMeterScale);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Meter Scale, Constructs a CFOPMeterScale object.
	//		Returns A  value (Object).
	CFOPMeterScale();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Meter Scale, Constructs a CFOPMeterScale object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPMeterScale& source object(Value).
	CFOPMeterScale(const CFOPMeterScale& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPMeterScale& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPMeterScale& source object(Value).
	CFOPMeterScale& operator=(const CFOPMeterScale& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPMeterScale,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPMeterScale* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Meter Scale, Destructor of class CFOPMeterScale
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMeterScale();

public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	// Draw the object.
	// pDC -- pointer of CDC
	virtual void Draw(CDC *pDC);

	// Obtain meter base shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMeterShape() { return m_pShape; }

	// Set meter base shape pointer.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Meter Shape, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	void SetMeterShape(CFODrawShape *pShape) { m_pShape = pShape; }

	// Obtain meter shape's rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPRect type value.
	virtual FOPRect GetMeterRect();

	// Obtain true meter rectangle.
	FOPRect GetTrueMeterRect();

	// Start point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.
	virtual FOPFloat GetStartPoint();

	// End point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.
	virtual FOPFloat GetEndPoint();

	// SVG_Arrow.
	virtual CString SVG_PolyGen(FOPFloat* m_lpShapePoints, int m_nCompPtCount);
	
	
	// SVG_Gen();
	virtual void SVG_Poly(CString &str, FOPFloat* m_lpShapePoints, int m_nCompPtCount, COLORREF crLine, COLORREF crFill, int nLineWidth);
	
	// SVG_Gen();
	virtual void SVG_Rect(CString &str, const FOPRect &rc, COLORREF crLine, COLORREF crFill, int nLineWidth);
	
	// SVG_Gen();
	virtual void SVG_Ellipse(CString &str, const FOPRect &rc, COLORREF crLine, COLORREF crFill, int nLineWidth);
	
	// SVG_Fill
	CString SVG_Fill(COLORREF color, int GrayScale);
	CString		  SVG_SimpleText(const CString &strText, int x, int y, BOOL bUnderline, BOOL bStrike);
	CString       SVG_HtmlFilter(CString sInput);
	virtual void SVG_Gen(CString &strIn);
	CString       SVG_AddTextHeader(COLORREF crFont, int nFontSize, CString strTitle);
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL,int x, int y, COLORREF crFont, int nFontSize, CString strTitle);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_GenRect(const FOPRect &rect);
	
	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_GenEllipse(const FOPRect &rect);

public:
	// Obtain tick width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Width, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickWidth() const { return myTickWidth; }

	// Change tick width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Width, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fWidth---&fWidth, Specifies a const double &fWidth object(Value).
	void SetTickWidth(const double &fWidth) { myTickWidth = fWidth; }

	// Obtain tick unit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Unit, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickUnit() const { return myTickUnit; }

	// Change tick unit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Unit, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fUnit---&fUnit, Specifies a const double &fUnit object(Value).
	void SetTickUnit(const double &fUnit) { myTickUnit = fUnit; }
	
	// Obtain tick major width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Major Width, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickMajorWidth() const { return myTickMajorWidth; }

	// Change tick major width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Major Width, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fWidth---&fWidth, Specifies a const double &fWidth object(Value).
	void SetTickMajorWidth(const double &fWidth) { myTickMajorWidth = fWidth; }


	// Obtain tick color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetTickColor() const { return myTickColor; }
	
	// Change tick color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Color, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetTickColor(const COLORREF &crColor) { myTickColor = crColor; }


	// Obtain tick color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Major Tick Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetMajorTickColor() const { return myMajorTickColor; }
	
	// Change tick color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Major Tick Color, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetMajorTickColor(const COLORREF &crColor) { myMajorTickColor = crColor; }

	// Obtain tick major length ratio
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Major Length Ratio, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickMajorLengthRatio() const { return myTickMajorLengthRatio; }

	// Change tick major length ratio.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Major Length Ratio, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fMajorLengthRatio---Major Length Ratio, Specifies a const double &fMajorLengthRatio object(Value).
	void SetTickMajorLengthRatio(const double &fMajorLengthRatio) { myTickMajorLengthRatio = fMajorLengthRatio; }

	// Obtain tick major frequency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Major Frequency, Returns the specified value.
	//		Returns a int type value.
	int GetTickMajorFrequency() const { return myTickMajorFrequency; }

	// Change tick major frequency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Major Frequency, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&nFreq---&nFreq, Specifies A integer value.
	void SetTickMajorFrequency(const int &nFreq) { myTickMajorFrequency = nFreq; }
	
	// Obtain tick length right.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Length Right, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickLengthRight() const { return myTickLengthRight; }

	// Change tick length right
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Length Right, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fTickLengthRight---Tick Length Right, Specifies a const double &fTickLengthRight object(Value).
	void SetTickLengthRight(const double &fTickLengthRight) { myTickLengthRight = fTickLengthRight; AdjustTickOffset(); }

	// Obtain the tick length left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Length Left, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickLengthLeft() const { return myTickLengthLeft; }

	// Change tick length left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Length Left, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fTickLengthLeft---Tick Length Left, Specifies a const double &fTickLengthLeft object(Value).
	void SetTickLengthLeft(const double &fTickLengthLeft) { myTickLengthLeft = fTickLengthLeft; AdjustTickOffset(); }

	// Is tick label showing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Labels, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetTickLabels() const { return myTickLabels; }
	
	// Showing tick leabel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Labels, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&bLabel---&bLabel, Specifies A Boolean value.
	void SetTickLabels(const BOOL &bLabel) { myTickLabels = bLabel; }

	// Obtain tick base
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Base, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickBase() const { return myTickBase; }

	// Change tick base.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Base, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fTickBase---Tick Base, Specifies a const double &fTickBase object(Value).
	void SetTickBase(const double &fTickBase) { myTickBase = fTickBase; }

	// Obtain range
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Range, Returns the specified value.
	//		Returns A double value (Object).
	double GetRange() { return (myMax - myMin); }

	// Obtain minimum value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum, Returns the specified value.
	//		Returns A double value (Object).
	double GetMinimum() const { return myMin; }

	// Change minimum value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimum, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fMinimum---&fMinimum, Specifies a const double &fMinimum object(Value).
	void SetMinimum(const double &fMinimum) { myMin = fMinimum; }

	// Obtain maximum value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximum, Returns the specified value.
	//		Returns A double value (Object).
	double GetMaximum() const { return myMax; }

	// Change maximum value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximum, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fMaximum---&fMaximum, Specifies a const double &fMaximum object(Value).
	void SetMaximum(const double &fMaximum) { myMax = fMaximum; }

	// Obtain scale style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scale Style, Returns the specified value.
	//		Returns A FOPScaleLinearStyle value (Object).
	FOPScaleLinearStyle GetScaleStyle() const { return myLabelStyle; }


	// Obtain scale mark style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mark Style, Returns the specified value.
	//		Returns A FOPScaleMarkStyle value (Object).
	FOPScaleMarkStyle GetMarkStyle() const { return myMarkStyle; }

	// Change mark style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mark Style, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&style---Specifies a const FOPScaleMarkStyle &style object(Value).
	void SetMarkStyle(const FOPScaleMarkStyle &style) { myMarkStyle = style; }

	// Obtain scale mark style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Major Mark Style, Returns the specified value.
	//		Returns A FOPScaleMarkStyle value (Object).
	FOPScaleMarkStyle GetMajorMarkStyle() const { return myMajorMarkStyle; }
	
	// Change mark style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Major Mark Style, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&style---Specifies a const FOPScaleMarkStyle &style object(Value).
	void SetMajorMarkStyle(const FOPScaleMarkStyle &style) { myMajorMarkStyle = style; }


	// Change scale style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scale Style, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&style---Specifies a const FOPScaleLinearStyle &style object(Value).
	void SetScaleStyle(const FOPScaleLinearStyle &style) { myLabelStyle = style; }

	// Obtain label frequency.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Frequency, Returns the specified value.
	//		Returns a int type value.
	int GetLabelFrequency() const { return myLabelFrequency; }

	// Change label frequency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Frequency, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&nFreq---&nFreq, Specifies A integer value.
	void SetLabelFrequency(const int &nFreq) { myLabelFrequency = nFreq; }
	
	// Obtain label distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Distance, Returns the specified value.
	//		Returns A double value (Object).
	double GetLabelDistance() const { return myLabelDistance; }

	// Change label distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Distance, Sets a specify value to current class CFOPMeterScale
	// Parameters:
	//		&fLabelDist---Label Dist, Specifies a const double &fLabelDist object(Value).
	void SetLabelDistance(const double &fLabelDist) { myLabelDistance = fLabelDist; }

	// Compute ticks
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Ticks, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<FOP_XLine---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&myMajorTicks---Major Ticks, Specifies a FOP_XLine> &myMajorTicks object(Value).  
	//		CArray<FOP_XLine---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&myMinorTicks---Minor Ticks, Specifies a FOP_XLine> &myMinorTicks object(Value).  
	//		CArray<FOPFloat---Array< C Point, Specifies A CArray array.  
	//		&myLabelPoints---Label Points, Specifies A FOPFloat type value.  
	//		CArray<CString---Array< C String, Specifies A CString type value.  
	//		&myLabelStrings---Label Strings, Specifies A CString type value.
	virtual void ComputeTicks(CArray<FOP_XLine,FOP_XLine> &myMajorTicks, 
										CArray<FOP_XLine,FOP_XLine> &myMinorTicks,
										CArray<FOPFloat,FOPFloat> &myLabelPoints,
										CArray<CString,CString> &myLabelStrings);

	// Obtain tick length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Length, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetTickLength();

	// Obtain cpoint from value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get C Pointor Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.  
	// Parameters:
	//		val---Specifies a double val object(Value).
	virtual FOPFloat GetFOPFloatorValue(double val);

	// Get tick ends
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Ends, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		v---Specifies a double v object(Value).  
	//		isMajor---isMajor, Specifies A Boolean value.  
	//		&p1---Specifies A FOPFloat type value.  
	//		&p2---Specifies A FOPFloat type value.
	virtual void GetTickEnds(double v, BOOL isMajor, FOPFloat &p1, FOPFloat &p2);

	// Adjust tick offset
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Tick Offset, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AdjustTickOffset();

	// Get value at point
	// Note: this method returns the value at specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value At Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		p---Specifies A FOPFloat type value.
	virtual double GetValueAtPoint(FOPFloat p);

	// Get label center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.  
	// Parameters:
	//		val---Specifies a double val object(Value).  
	//		drawLeft---drawLeft, Specifies A Boolean value.
	virtual FOPFloat GetLabelCenter(double val, BOOL drawLeft);

	// intersection with line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection With Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		p1---Specifies A FOPFloat type value.  
	//		p2---Specifies A FOPFloat type value.  
	//		&val---Specifies a double &val object(Value).
	virtual BOOL IntersectionWithLine(FOPFloat p1, FOPFloat p2, double &val);

	// Update shape's area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void GeometryUpdated(FOPRect &rcBound);

public:

	// With label show.
	BOOL		myShowLabel;

	// Label distance
 
	// Label Distance, This member specify double object.  
	double		myLabelDistance;

	// label frequency
 
	// Label Frequency, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			myLabelFrequency;

	// label style
 
	// Label Style, This member specify FOPScaleLinearStyle object.  
	FOPScaleLinearStyle myLabelStyle;

	// Mark style.
 
	// Mark Style, This member specify FOPScaleMarkStyle object.  
	FOPScaleMarkStyle	myMarkStyle;

	// Major mark style.
 
	// Major Mark Style, This member specify FOPScaleMarkStyle object.  
	FOPScaleMarkStyle	myMajorMarkStyle;

	// tick width
 
	// Tick Width, This member specify double object.  
	double		myTickWidth;

	// tick unit
 
	// Tick Unit, This member specify double object.  
	double		myTickUnit;

	// tick major width.
 
	// Tick Major Width, This member specify double object.  
	double		myTickMajorWidth;

	// tick major length ratio
 
	// Tick Major Length Ratio, This member specify double object.  
	double		myTickMajorLengthRatio;

	// tick major frequency.
 
	// Tick Major Frequency, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			myTickMajorFrequency;

	// tick length right
 
	// Tick Length Right, This member specify double object.  
	double		myTickLengthRight;

	// tick length left.
 
	// Tick Length Left, This member specify double object.  
	double		myTickLengthLeft;

	// tick label showing or not
 
	// Tick Labels, This member sets TRUE if it is right.  
	BOOL		myTickLabels;

	// tick base
 
	// Tick Base, This member specify double object.  
	double		myTickBase;

	// maximum value.
 
	// Maximize, This member specify double object.  
	double		myMax;

	// max label height
 
	// Maximize Label Height, This member specify double object.  
	double		myMaxLabelHeight;

	// max label width.
 
	// Maximize Label Width, This member specify double object.  
	double		myMaxLabelWidth;

	// minimum value
 
	// Minimize, This member specify double object.  
	double		myMin;

	// left tick offset value
 
	// Left Tick Offset, This member sets a CSize value.  
	FOPFloat		myLeftTickOffset;

	// right tick offset value.
 
	// Right Tick Offset, This member sets a CSize value.  
    FOPFloat		myRightTickOffset;

	// tick color
 
	// Tick Color, This member sets A 32-bit value used as a color value.  
	COLORREF	myTickColor;

	// major tick color.
 
	// Major Tick Color, This member sets A 32-bit value used as a color value.  
	COLORREF	myMajorTickColor;

	// Pointer to CFODrawShape object.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape	*m_pShape;
};


//////////////////////////////////////////////////////////////////////////////////
// CFOPMeterEllipticalScale -- elliptical meter scale object.

 
//===========================================================================
// Summary:
//     The CFOPMeterEllipticalScale class derived from CFOPMeterScale
//      F O P Meter Elliptical Scale
//===========================================================================

class FO_EXT_CLASS CFOPMeterEllipticalScale : public CFOPMeterScale  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMeterEllipticalScale---F O P Meter Elliptical Scale, Specifies a E-XD++ CFOPMeterEllipticalScale object (Value).
	DECLARE_SERIAL(CFOPMeterEllipticalScale);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Meter Elliptical Scale, Constructs a CFOPMeterEllipticalScale object.
	//		Returns A  value (Object).
	CFOPMeterEllipticalScale();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Meter Elliptical Scale, Constructs a CFOPMeterEllipticalScale object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPMeterEllipticalScale& source object(Value).
	CFOPMeterEllipticalScale(const CFOPMeterEllipticalScale& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPMeterEllipticalScale& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPMeterEllipticalScale& source object(Value).
	CFOPMeterEllipticalScale& operator=(const CFOPMeterEllipticalScale& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPMeterScale,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPMeterScale* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Meter Elliptical Scale, Destructor of class CFOPMeterEllipticalScale
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMeterEllipticalScale();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	// Obtain SweepAngle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sweep Angle, Returns the specified value.
	//		Returns A double value (Object).
	double GetSweepAngle() const { return mySweepAngle; }

	// Change sweep angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sweep Angle, Sets a specify value to current class CFOPMeterEllipticalScale
	// Parameters:
	//		&dAngle---&dAngle, Specifies a const double &dAngle object(Value).
	void SetSweepAngle(const double &dAngle);

	// Obtain Start Angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Angle, Returns the specified value.
	//		Returns A double value (Object).
	double GetStartAngle() const { return myStartAngle; }

	// Change Start angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start Angle, Sets a specify value to current class CFOPMeterEllipticalScale
	// Parameters:
	//		&dAngle---&dAngle, Specifies a const double &dAngle object(Value).
	void SetStartAngle(const double &dAngle);

	// Obtain tick length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Length, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetTickLength();

	// Obtain cpoint from value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get C Pointor Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.  
	// Parameters:
	//		val---Specifies a double val object(Value).
	virtual FOPFloat GetFOPFloatorValue(double val);

	// Get tick ends
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Ends, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		v---Specifies a double v object(Value).  
	//		isMajor---isMajor, Specifies A Boolean value.  
	//		&p1---Specifies A FOPFloat type value.  
	//		&p2---Specifies A FOPFloat type value.
	virtual void GetTickEnds(double v, BOOL isMajor, FOPFloat &p1, FOPFloat &p2);

	// Adjust tick offset
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Tick Offset, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AdjustTickOffset();

	// Get value at point
	// Note: this method returns the value at specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value At Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		p---Specifies A FOPFloat type value.
	virtual double GetValueAtPoint(FOPFloat p);

	// Get label center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a FOPFloat type value.  
	// Parameters:
	//		val---Specifies a double val object(Value).  
	//		drawLeft---drawLeft, Specifies A Boolean value.
	virtual FOPFloat GetLabelCenter(double val, BOOL drawLeft);

	// intersection with line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection With Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		p1---Specifies A FOPFloat type value.  
	//		p2---Specifies A FOPFloat type value.  
	//		&val---Specifies a double &val object(Value).
	virtual BOOL IntersectionWithLine(FOPFloat p1, FOPFloat p2, double &val);

	// Update shape's area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void GeometryUpdated(FOPRect &rcBound);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC);

	virtual void SVG_Gen(CString &strIn);
	// Compute ticks
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Ticks, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<FOP_XLine---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&myMajorTicks---Major Ticks, Specifies a FOP_XLine> &myMajorTicks object(Value).  
	//		CArray<FOP_XLine---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&myMinorTicks---Minor Ticks, Specifies a FOP_XLine> &myMinorTicks object(Value).  
	//		CArray<FOPFloat---Array< C Point, Specifies A CArray array.  
	//		&myLabelPoints---Label Points, Specifies A FOPFloat type value.  
	//		CArray<CString---Array< C String, Specifies A CString type value.  
	//		&myLabelStrings---Label Strings, Specifies A CString type value.
	virtual void ComputeTicks(CArray<FOP_XLine,FOP_XLine> &myMajorTicks, 
										CArray<FOP_XLine,FOP_XLine> &myMinorTicks,
										CArray<FOPFloat,FOPFloat> &myLabelPoints,
										CArray<CString,CString> &myLabelStrings);

	// Draw the object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Double Ellipse, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcBound---&rcBound, Specifies A FOPRect type value.  
	//		&dStart---&dStart, Specifies a const double &dStart object(Value).  
	//		&dEnd---&dEnd, Specifies a const double &dEnd object(Value).  
	//		&crMiddle---&crMiddle, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crBorder---&crBorder, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nFrame---&nFrame, Specifies A integer value.  
	//		&bFull---&bFull, Specifies A Boolean value.
	virtual void DrawDoubleEllipse(CDC *pDC, const FOPRect &rcBound, const double &dStart, 
		const double &dEnd, const COLORREF &crMiddle, const COLORREF &crBorder, 
		const int &nFrame = 6,
		const BOOL &bFull = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get C Pointor Value, .
	//		Returns a FOPFloat type value.  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A FOPRect type value.  
	//		val---Specifies a double val object(Value).
	FOPFloat XGetFOPFloatorValue(const FOPRect &rcBound, double val);

public:

	// Border colors.
 
	// Border Color1, This member sets A 32-bit value used as a color value.  
	COLORREF		myBdrColor1;

	// Border colors.
 
	// Border Color2, This member sets A 32-bit value used as a color value.  
	COLORREF		myBdrColor2;

	// Border colors.
 
	// Arc Color, This member sets A 32-bit value used as a color value.  
	COLORREF		myArcColor;

	// Arc offset distance.
 
	// Arc Distance, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				myArcDistance;

	// With or without border.
 
	// Show Border, This member sets TRUE if it is right.  
	BOOL			m_bShowBorder;

	// Show arc line.
 
	// Show Arc Line, This member sets TRUE if it is right.  
	BOOL			m_bShowArcLine;

protected:
	// Start angle value.
 
	// Start Angle, This member specify double object.  
	double			myStartAngle;

	// sweep angle value.
 
	// Sweep Angle, This member specify double object.  
	double			mySweepAngle;

	
};

////////////////////////////////////////////////////////////////////////////////
// CFOPIndicator -- indicator of dashboard shape.

 
//===========================================================================
// Summary:
//     The CFOPIndicator class derived from CObject
//      F O P Indicator
//===========================================================================

class FO_EXT_CLASS CFOPIndicator : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicator---F O P Indicator, Specifies a E-XD++ CFOPIndicator object (Value).
	DECLARE_SERIAL(CFOPIndicator);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator, Constructs a CFOPIndicator object.
	//		Returns A  value (Object).
	CFOPIndicator();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator, Constructs a CFOPIndicator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicator& source object(Value).
	CFOPIndicator(const CFOPIndicator& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicator& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicator& source object(Value).
	CFOPIndicator& operator=(const CFOPIndicator& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator, Destructor of class CFOPIndicator
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicator();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Obtain quantize base
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Quantize Base, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetQuantizeBase() { return myQuantBase; }

	// Change quantize base
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Quantize Base, Sets a specify value to current class CFOPIndicator
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetQuantizeBase(const double &dValue) { myQuantBase = dValue; }

	// Obtain quantize Unit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Quantize Unit, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetQuantizeUnit() { return myQuantUnit; }

	// Change quantize base
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Quantize Unit, Sets a specify value to current class CFOPIndicator
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetQuantizeUnit(const double &dValue) { myQuantUnit = dValue; }


	// Obtain value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetValue() { return myValue; }

	// Change value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class CFOPIndicator
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetValue(const double &dValue) { myValue = dValue; ValidValue(myValue); }

	// Valid value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Valid Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		val---Specifies a double val object(Value).
	virtual double ValidValue(double val);

	// Quantize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quantize Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		val---Specifies a double val object(Value).
	virtual double QuantizeValue(double val);

	// Check if point within this indicator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	// SVG_Arrow.
	virtual CString SVG_PolyGen(FOPFloat* m_lpShapePoints, int m_nCompPtCount);
	
	// SVG_Gen();
	virtual void SVG_Poly(CString &str, FOPFloat* m_lpShapePoints, int m_nCompPtCount, COLORREF crLine, COLORREF crFill, int nLineWidth);
	// Export data to svg file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export To S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strOut---strOut, Specifies A CString type value.
	virtual void ExportToSVG(CString* strOut, CFOPMeterScale *pScale);

	// SVG_Fill
	CString SVG_Fill(COLORREF color, int GrayScale);
	CString		  SVG_SimpleText(const CString &strText, int x, int y, BOOL bUnderline, BOOL bStrike);
	CString       SVG_HtmlFilter(CString sInput);
	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);
	CString       SVG_AddTextHeader(COLORREF crFont, int nFontSize, CString strTitle);
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL,int x, int y, COLORREF crFont, int nFontSize, CString strTitle);

public:

	// Position Rectangle
 
	// Position, This member sets a FOPRect value.  
	FOPRect			rcPosition;

	// Quantize base.
 
	// Quant Base, This member specify double object.  
	double			myQuantBase;

	// Quantize unit
 
	// Quant Unit, This member specify double object.  
	double			myQuantUnit;

	// value.
 
	// Value, This member specify double object.  
	double			myValue;

	// Pointer of the scale ticks.
 
	// Scale, This member maintains a pointer to the object CFOPMeterScale.  
	CFOPMeterScale *m_pScale;

};

/////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorBar -- bar style indicator.

struct FOPPhase
{
	// Min value
	double		myMin;

	// Max value.
	double		myMax;
	
	// Color value
	COLORREF	myColor;

	// Constructor
	FOPPhase() {myMin = 0; myMax = 100; myColor = RGB(0,0,0); }

	// Constructor
	FOPPhase(double min, double max, COLORREF color)
	{
		myMin = min;
		myMax = max;
		myColor = color;
	}

	// Obtain minimize value.
	double GetMin() { return myMin; }

	// Change minimize value.
	void SetMin(const double &value) { myMin = value; }

	// Obtain maximize value.
	double GetMax() { return myMax; }

	// Change maximize.
	void SetMax(const double &value) { myMax = value; }

	// Obtain color
	COLORREF GetColor() { return myColor; }

	// Change color
	void SetColor(const COLORREF &value) { myColor = value; }
};

///////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorBar -- bar indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorBar class derived from CFOPIndicator
//      F O P Indicator Bar
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorBar : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorBar---F O P Indicator Bar, Specifies a E-XD++ CFOPIndicatorBar object (Value).
	DECLARE_SERIAL(CFOPIndicatorBar);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Bar, Constructs a CFOPIndicatorBar object.
	//		Returns A  value (Object).
	CFOPIndicatorBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Bar, Constructs a CFOPIndicatorBar object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorBar& source object(Value).
	CFOPIndicatorBar(const CFOPIndicatorBar& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorBar& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorBar& source object(Value).
	CFOPIndicatorBar& operator=(const CFOPIndicatorBar& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Bar, Destructor of class CFOPIndicatorBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorBar();
	
	virtual void SVG_GenHelper(CString &strIn, double min, double max, const COLORREF &crBack);
	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Phase Path, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		min---Specifies a double min object(Value).  
	//		max---Specifies a double max object(Value).
	virtual void DrawPhasePath(CDC *pDC, double min, double max, const COLORREF &crBack);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Obtain phase count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Phase Count, .
	//		Returns a int type value.
	int PhaseCount() { return myPhases.GetSize(); }

	// Change phase at an index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Phase, Sets a specify value to current class CFOPIndicatorBar
	// Parameters:
	//		i---Specifies A integer value.  
	//		p---Specifies a FOPPhase p object(Value).
	void SetPhase(int i, FOPPhase p)
	{
		FOPPhase phase1 = myPhases.GetAt(i);
		if (phase1.myColor != p.myColor &&
			phase1.myMax != p.myMax &&
			phase1.myMin != p.myMin)
		{
			myPhases[i].myColor = p.myColor;
			myPhases[i].myMax = p.myMax;
			myPhases[i].myMin = p.myMin;
		}
	}
	
	// Add phase
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Phase, Adds an object to the specify list.
	// Parameters:
	//		p---Specifies a FOPPhase p object(Value).
	void AddPhase(FOPPhase p)
	{
		myPhases.Add(p);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	// Obtain tickness.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tickness, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickness() const { return myThickness; }

	// Change tickness.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tickness, Sets a specify value to current class CFOPIndicatorBar
	// Parameters:
	//		&value---Specifies a const double &value object(Value).
	void SetTickness(const double &value) { myThickness = value; }

public:
	//  Start offset
 
	// Start Offset, This member sets a CSize value.  
	CSize myStartOffset;

	// Tickness
 
	// Thickness, This member specify double object.  
	double myThickness;

	// Phases
	CArray<FOPPhase,FOPPhase> myPhases;
};

///////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorElliptical -- elliptical indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorElliptical class derived from CFOPIndicatorBar
//      F O P Indicator Elliptical
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorElliptical : public CFOPIndicatorBar  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorElliptical---F O P Indicator Elliptical, Specifies a E-XD++ CFOPIndicatorElliptical object (Value).
	DECLARE_SERIAL(CFOPIndicatorElliptical);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Elliptical, Constructs a CFOPIndicatorElliptical object.
	//		Returns A  value (Object).
	CFOPIndicatorElliptical();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Elliptical, Constructs a CFOPIndicatorElliptical object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorElliptical& source object(Value).
	CFOPIndicatorElliptical(const CFOPIndicatorElliptical& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorElliptical& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorElliptical& source object(Value).
	CFOPIndicatorElliptical& operator=(const CFOPIndicatorElliptical& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Elliptical, Destructor of class CFOPIndicatorElliptical
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorElliptical();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	// Drawing phase path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Phase Path, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		min---Specifies a double min object(Value).  
	//		max---Specifies a double max object(Value).
	virtual void DrawPhasePath(CDC *pDC, double min, double max, const COLORREF &crBack);

	// Contains point or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	virtual void SVG_GenHelper(CString &strIn, double min, double max, const COLORREF &crBack);
public:
	// Fill with clockwise or not.
 
	// Fill Clockwise, This member sets TRUE if it is right.  
	BOOL myFillClockwise;

	// Width of this bar.
 
	// Bar Width, This member specify double object.  
	double m_dBarWidth;

	// With full mode.
 
	// With Full Mode, This member sets TRUE if it is right.  
	BOOL	m_bWithFullMode;
};



enum FOPIndicatorSliderStyle
    {
        // Fields
        fopBar = 0,
        fopTriangles = 1,
		fopDiamond =2
    };

//////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorSlider -- slider indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorSlider class derived from CFOPIndicator
//      F O P Indicator Slider
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorSlider : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorSlider---F O P Indicator Slider, Specifies a E-XD++ CFOPIndicatorSlider object (Value).
	DECLARE_SERIAL(CFOPIndicatorSlider);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Slider, Constructs a CFOPIndicatorSlider object.
	//		Returns A  value (Object).
	CFOPIndicatorSlider();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Slider, Constructs a CFOPIndicatorSlider object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorSlider& source object(Value).
	CFOPIndicatorSlider(const CFOPIndicatorSlider& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorSlider& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorSlider& source object(Value).
	CFOPIndicatorSlider& operator=(const CFOPIndicatorSlider& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Slider, Destructor of class CFOPIndicatorSlider
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorSlider();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Contains point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	// Get slider style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Slider Style, Returns the specified value.
	//		Returns A FOPIndicatorSliderStyle value (Object).
	FOPIndicatorSliderStyle GetSliderStyle() const { return myStyle; }

	// Set slider style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Slider Style, Sets a specify value to current class CFOPIndicatorSlider
	// Parameters:
	//		&style---Specifies a const FOPIndicatorSliderStyle &style object(Value).
	void SetSliderStyle(const FOPIndicatorSliderStyle &style) { myStyle = style; }

public:
	// Dimensions
 
	// Dimensions, This member sets a CSize value.  
	CSize					myDimensions;

	// Slider style.
 
	// Style, This member specify FOPIndicatorSliderStyle object.  
	FOPIndicatorSliderStyle myStyle;

	// Color of the background.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crBack;
};

////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorSliderElliptical -- elliptical slider indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorSliderElliptical class derived from CFOPIndicatorSlider
//      F O P Indicator Slider Elliptical
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorSliderElliptical : public CFOPIndicatorSlider  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorSliderElliptical---F O P Indicator Slider Elliptical, Specifies a E-XD++ CFOPIndicatorSliderElliptical object (Value).
	DECLARE_SERIAL(CFOPIndicatorSliderElliptical);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Slider Elliptical, Constructs a CFOPIndicatorSliderElliptical object.
	//		Returns A  value (Object).
	CFOPIndicatorSliderElliptical();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Slider Elliptical, Constructs a CFOPIndicatorSliderElliptical object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorSliderElliptical& source object(Value).
	CFOPIndicatorSliderElliptical(const CFOPIndicatorSliderElliptical& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorSliderElliptical& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorSliderElliptical& source object(Value).
	CFOPIndicatorSliderElliptical& operator=(const CFOPIndicatorSliderElliptical& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Slider Elliptical, Destructor of class CFOPIndicatorSliderElliptical
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorSliderElliptical();
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	// pDC -- pointer of DC.
	// pScale -- pointer of scale.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);

public:

};

////////////////////////////////////////////
//
enum FOPIndicatorNeedleStyle
    {
        // Fields
	fpUserStyle7 = 11,
	fpUserStyle6 = 10,
	fpUserStyle5 = 9,
	fpUserStyle4 = 8,
		fpUserStyle3 = 7,
		fpUserStyle2 = 6,
	    fpUserStyle1 = 5,
		fpLargeCircle = 4,
		fpCoolLine = 3,
        fpBar = 2,
        fpKite = 1,
        fpLine = 0
    };

/////////////////////////////////////////////////////////////////////
// CFOPIndicatorNeedle -- needle indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorNeedle class derived from CFOPIndicator
//      F O P Indicator Needle
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorNeedle : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorNeedle---F O P Indicator Needle, Specifies a E-XD++ CFOPIndicatorNeedle object (Value).
	DECLARE_SERIAL(CFOPIndicatorNeedle);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Needle, Constructs a CFOPIndicatorNeedle object.
	//		Returns A  value (Object).
	CFOPIndicatorNeedle();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Needle, Constructs a CFOPIndicatorNeedle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorNeedle& source object(Value).
	CFOPIndicatorNeedle(const CFOPIndicatorNeedle& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorNeedle& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorNeedle& source object(Value).
	CFOPIndicatorNeedle& operator=(const CFOPIndicatorNeedle& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Needle, Destructor of class CFOPIndicatorNeedle
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorNeedle();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);


	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Contain point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	// Obtain tickness.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tickness, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickness() const { return myThickness; }

	// Change ticks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tickness, Sets a specify value to current class CFOPIndicatorNeedle
	// Parameters:
	//		&value---Specifies a const double &value object(Value).
	void SetTickness(const double &value) { myThickness = value; }

	// Obtain the needle style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Needle Style, Returns the specified value.
	//		Returns A FOPIndicatorNeedleStyle value (Object).
	FOPIndicatorNeedleStyle GetNeedleStyle() const { return myStyle; }

	// Change the needle style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Needle Style, Sets a specify value to current class CFOPIndicatorNeedle
	// Parameters:
	//		&style---Specifies a const FOPIndicatorNeedleStyle &style object(Value).
	void SetNeedleStyle(const FOPIndicatorNeedleStyle &style) { myStyle = style; }

	// Obtain the length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns a float value.
	float GetLength() const { return myLength; }

	// Change the length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Length, .
	// Parameters:
	//		&length---Specifies A float value.
	void ChangeLength(const float &length) { myLength = length; }

public:

	// Ticks
 
	// Thickness, This member specify double object.  
	double					myThickness;

	// Needle style
 
	// Style, This member specify FOPIndicatorNeedleStyle object.  
	FOPIndicatorNeedleStyle myStyle;

	// Constant length
 
	// Constant Length, This member sets TRUE if it is right.  
	BOOL					myConstantLength;

	// length
 
	// Length, This member specify The float keyword designates a 32-bit floating-point number.  
	float					myLength;

	// pivot point.
 
	// Pivot Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat					myPivotPoint;

	// Color of the background.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF				myColor;

	// Center's color.
 
	// Brd Center Color, This member sets A 32-bit value used as a color value.  
	COLORREF				myBrdCenterColor;
};

//===========================================================================
// Summary:
//     The CFOPIndicatorExtBar class derived from CFOPIndicator
//      F O P Indicator Needle
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorExtBar : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorExtBar---F O P Indicator Needle, Specifies a E-XD++ CFOPIndicatorExtBar object (Value).
	DECLARE_SERIAL(CFOPIndicatorExtBar);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Needle, Constructs a CFOPIndicatorExtBar object.
	//		Returns A  value (Object).
	CFOPIndicatorExtBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Needle, Constructs a CFOPIndicatorExtBar object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorExtBar& source object(Value).
	CFOPIndicatorExtBar(const CFOPIndicatorExtBar& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorExtBar& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorExtBar& source object(Value).
	CFOPIndicatorExtBar& operator=(const CFOPIndicatorExtBar& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Needle, Destructor of class CFOPIndicatorExtBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorExtBar();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);


	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Contain point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	// Obtain tickness.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tickness, Returns the specified value.
	//		Returns A double value (Object).
	double GetTickness() const { return myThickness; }

	// Change ticks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tickness, Sets a specify value to current class CFOPIndicatorExtBar
	// Parameters:
	//		&value---Specifies a const double &value object(Value).
	void SetTickness(const double &value) { myThickness = value; }

	// Obtain the needle style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Needle Style, Returns the specified value.
	//		Returns A FOPIndicatorNeedleStyle value (Object).
	FOPIndicatorNeedleStyle GetNeedleStyle() const { return myStyle; }

	// Change the needle style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Needle Style, Sets a specify value to current class CFOPIndicatorExtBar
	// Parameters:
	//		&style---Specifies a const FOPIndicatorNeedleStyle &style object(Value).
	void SetNeedleStyle(const FOPIndicatorNeedleStyle &style) { myStyle = style; }

	// Obtain the length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns a float value.
	float GetLength() const { return myLength; }

	// Change the length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Length, .
	// Parameters:
	//		&length---Specifies A float value.
	void ChangeLength(const float &length) { myLength = length; }

public:

	// Ticks
 
	// Thickness, This member specify double object.  
	double					myThickness;

	// Needle style
 
	// Style, This member specify FOPIndicatorNeedleStyle object.  
	FOPIndicatorNeedleStyle myStyle;

	// Constant length
 
	// Constant Length, This member sets TRUE if it is right.  
	BOOL					myConstantLength;

	// length
 
	// Length, This member specify The float keyword designates a 32-bit floating-point number.  
	float					myLength;

	// pivot point.
 
	// Pivot Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat					myPivotPoint;

	// Color of the background.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF				myColor;

	// Center's color.
 
	// Brd Center Color, This member sets A 32-bit value used as a color value.  
	COLORREF				myBrdCenterColor;

	// Is horizontal or not.
	BOOL					myHorzMode;
};


/////////////////////////////////////////////////////////////////////
// CFOPIndicatorKnob -- knob indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorKnob class derived from CFOPIndicator
//      F O P Indicator Knob
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorKnob : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorKnob---F O P Indicator Knob, Specifies a E-XD++ CFOPIndicatorKnob object (Value).
	DECLARE_SERIAL(CFOPIndicatorKnob);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Knob, Constructs a CFOPIndicatorKnob object.
	//		Returns A  value (Object).
	CFOPIndicatorKnob();

	//-----------------------------------------------------------------------
	// Summary:
	/// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Knob, Constructs a CFOPIndicatorKnob object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorKnob& source object(Value).
	CFOPIndicatorKnob(const CFOPIndicatorKnob& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorKnob& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorKnob& source object(Value).
	CFOPIndicatorKnob& operator=(const CFOPIndicatorKnob& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Knob, Destructor of class CFOPIndicatorKnob
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorKnob();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	// pDC -- pointer of DC.
	// pScale -- pointer of meter scale.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Contains point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &ptHit);

public:

	// Color of the background.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// with border showing.
 
	// With Border, This member sets TRUE if it is right.  
	BOOL		m_bWithBorder;

	// With dot style.
 
	// Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nStyle; 
};


////////////////////////////////////////////////////////////////////////////////
// CFOPIndicatorNumber -- number indicator.

 
//===========================================================================
// Summary:
//     The CFOPIndicatorNumber class derived from CFOPIndicator
//      F O P Indicator Number
//===========================================================================

class FO_EXT_CLASS CFOPIndicatorNumber : public CFOPIndicator  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPIndicatorNumber---F O P Indicator Number, Specifies a E-XD++ CFOPIndicatorNumber object (Value).
	DECLARE_SERIAL(CFOPIndicatorNumber);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Number, Constructs a CFOPIndicatorNumber object.
	//		Returns A  value (Object).
	CFOPIndicatorNumber();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Indicator Number, Constructs a CFOPIndicatorNumber object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorNumber& source object(Value).
	CFOPIndicatorNumber(const CFOPIndicatorNumber& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPIndicatorNumber& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPIndicatorNumber& source object(Value).
	CFOPIndicatorNumber& operator=(const CFOPIndicatorNumber& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPIndicator* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Indicator Number, Destructor of class CFOPIndicatorNumber
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPIndicatorNumber();
	
public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	virtual void SVG_Gen(CString &strIn, CFOPMeterScale *pScale);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pScale---*pScale, A pointer to the CFOPMeterScale  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC, CFOPMeterScale *pScale);

	// Contains point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p---Specifies A FOPFloat type value.
	virtual BOOL ContainsPoint(const FOPFloat &p);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw X, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dwChar---dwChar, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nCol---nCol, Specifies A integer value.
	void DrawX( CDC* pDC, DWORD dwChar, int nCol);
	// Operations
public:
    // Create all fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Font, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void    AdjustFont();
    
    // Release the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void    ReleaseFont();
    
	// Init fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Fonts, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DoInitFonts();
    
	// Sets font size, style, and typeface
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font, Sets a specify value to current class CFOPIndicatorNumber
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A integer value.  
	//		FaceName---Face Name, Specifies A CString type value.
	virtual BOOL SetFont(int nSize,int nStyle,CString FaceName);

	// Calculate metrics
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Metrics, .

	void CalculateMetrics();
	
public:

	// Last amount.
 
	// Last Amount, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLastAmount;
	
	// Bar height.
 
	// Bar Height, This member specify unsigned short object.  
	unsigned short m_nBarHeight;
	
	// Draw fade.
 
	// Draw Faded Notches, Specify A Boolean value.  
	bool		m_bDrawFadedNotches;

	// Got metrics
 
	// Got Metrics, Specify A Boolean value.  
	bool		m_bGotMetrics;

	// with specify fade color
 
	// Specified Fade Colour, Specify A Boolean value.  
	bool		m_bSpecifiedFadeColour;

	// Notch width.
 
	// Notch Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nNotchWidth;

	// Notch length.
 
	// Notch Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nNotchLength;

	// Margin.
 
	// Margin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nMargin;
	
	// Background color.
 
	// Background, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBackground;

	// foreground color.
 
	// Foreground, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crForeground;

	// dimension foreground color.
 
	// Dimension Foreground, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crDimForeground;

	// Dimensions
 
	// Dimensions, This member sets a CSize value.  
	CSize		myDimensions;

	// pivot point.
 
	// Pivot Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat		myPivotPoint;

	// Color of text.
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF	myTextColor;

	// Font size -- negative numbers set sizes in pixels, positive numbers set sizes in points
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSize;

	// Style of font
 
	// Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nStyle;

	// Font typeface
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strFaceName;

	// Bold font
 
	// Bold Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*      m_pBoldFont;

	// Color of the background.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// With simple text mode.
 
	// With Simple Text, This member sets TRUE if it is right.  
	BOOL		m_bWithSimpleText;

	// Blank padding.
 
	// Blank Padding, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nBlankPadding;

	// With background or not.
 
	// With Back, This member sets TRUE if it is right.  
	BOOL		m_bWithBack;
};

#endif // !defined(FO_FOMETERHELPER_H__253EAB6C_499E_4B9D_8F63_2C06EB3DC63A__INCLUDED_)
