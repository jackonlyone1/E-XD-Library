//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTIMECHARTSHAPE_H__F27364FB_5606_411C_B2E7_D789DC3BFA6A__INCLUDED_)
#define FO_FOTIMECHARTSHAPE_H__F27364FB_5606_411C_B2E7_D789DC3BFA6A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include <Gauge\FOTimeChartData.h>
#include "FORectShape.h"

using namespace std;

class CFOTimeChart;

#define FOC_HORIZ		   0x01
#define FOC_VERT		   0x02
#define FOC_LEGEND		   0x04
#define FOC_ADJUSTSMOOTH   0x08

const COLORREF FO_BASECOLORTABLE[12] = 
{
	RGB(128,0,0),
		RGB(255,0,0),
		RGB(128,128,0),
		RGB(255,255,0),
		RGB(0,128,0),
		RGB(0,255,0),
		RGB(0,128,128),
		RGB(0,255,255),
		RGB(0,0,128),
		RGB(0,0,255),
		RGB(128,0,128),
		RGB(255,0,255)
};

//////////////////////////////////////////////////////////////////////
// CFOTimeChartShape

 
//===========================================================================
// Summary:
//     The CFOTimeChartShape class derived from CFORectShape
//      F O Time Chart Shape
//===========================================================================

class FO_EXT_CLASS CFOTimeChartShape : public CFORectShape  
{
 
	// F O Time Chart Axis, This member specify friend class object.  
	friend class CFOTimeChartAxis;
 
	// F O Time Chart Logical Axis, This member specify friend class object.  
	friend class CFOTimeChartLogAxis;
 
	// F O Time Chart Data Serie, This member specify friend class object.  
	friend class CFOTimeChartDataSerie;
 
	// F O Time Chart Label, This member specify friend class object.  
	friend class CFOTimeChartLabel;

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartShape---F O Time Chart Shape, Specifies a E-XD++ CFOTimeChartShape object (Value).
	DECLARE_SERIAL(CFOTimeChartShape);
	enum { VERSION = 105 };
	
public:
	
	enum EOperation
	{
		opNone,
			opZoom,
			opReset,
			opPan,
			opCursor,
			opMoveObject,
			opEditObject,
			opEditCurve,
			opMeasure
	};
	
	enum EAlignment
	{
		left,
			right,
			top,
			bottom
	};
	
	typedef struct tagNM_POINTMOVING
	{
		long    nCurve;
		long	nIndex;
		double  dOldVal;
		double  dNewVal;
	} NM_POINTMOVING;
	
	typedef struct tagMeasureDef
	{
		long nCurve1;
		long nIndex1;
		long nCurve2;
		long nIndex2;
	} MeasureDef;

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Shape, Constructs a CFOTimeChartShape object.
	//		Returns A  value (Object).
	CFOTimeChartShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Shape, Constructs a CFOTimeChartShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOTimeChartShape& src object(Value).
	CFOTimeChartShape(const CFOTimeChartShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Shape, Destructor of class CFOTimeChartShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTimeChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data, Sets a specify value to current class CFOTimeChartShape
	//		Returns A E-XD++ CFOTimeChartDataSerie& value (Object).  
	// Parameters:
	//		pValues---pValues, A pointer to the FOP_DATAPOINT or NULL if the call failed.  
	//		nCount---nCount, Specifies A 32-bit long signed integer.  
	//		nCurve---nCurve, Specifies A integer value.  
	//		nXAxis---X Axis, Specifies A integer value.  
	//		nYAxis---Y Axis, Specifies A integer value.  
	//		bAutoDelete---Automatic Delete, Specifies A Boolean value.
	CFOTimeChartDataSerie& SetData(FOP_DATAPOINT* pValues, long nCount, int nCurve = 0, 
		int nXAxis = 0, int nYAxis = 0, bool bAutoDelete = false);
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Axis, Returns the specified value.
	//		Returns A E-XD++ CFOTimeChartAxis& value (Object).  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	CFOTimeChartAxis& GetXAxis(int nAxis);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Axis, Returns the specified value.
	//		Returns A E-XD++ CFOTimeChartAxis& value (Object).  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	CFOTimeChartAxis& GetYAxis(int nAxis);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Curve, Returns the specified value.
	//		Returns A E-XD++ CFOTimeChartDataSerie& value (Object).  
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.
	CFOTimeChartDataSerie& GetCurve(int nCurve);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Curve, Deletes the given object.
	//		Returns A Boolean value.  
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.
	bool DeleteCurve(int nCurve);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete X Axis, Deletes the given object.
	//		Returns A Boolean value.  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	bool DeleteXAxis(int nAxis);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Y Axis, Deletes the given object.
	//		Returns A Boolean value.  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	bool DeleteYAxis(int nAxis);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Data Notation, Inserts a child object at the given index..
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.  
	//		nIndex---nIndex, Specifies A integer value.
	void InsertDataNotation(int nCurve, int nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Linear Trend, Adds an object to the specify list.
	// Parameters:
	//		serie---Specifies a E-XD++ CFOTimeChartDataSerie& serie object (Value).
	void AddLinearTrend(CFOTimeChartDataSerie& serie);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Cubic Trend, Adds an object to the specify list.
	// Parameters:
	//		serie---Specifies a E-XD++ CFOTimeChartDataSerie& serie object (Value).
	void AddCubicTrend(CFOTimeChartDataSerie& serie);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Axis Count, Returns the specified value.
	//		Returns a int type value.
	int  GetXAxisCount() { return m_XAxis.size(); };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Axis Count, Returns the specified value.
	//		Returns a int type value.
	int  GetYAxisCount() { return m_YAxis.size(); };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Curve Count, Returns the specified value.
	//		Returns a int type value.
	int  GetCurveCount() { return m_Data.size(); };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Curve, Call this function to select the given item.
	//		Returns A Boolean value.  
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.
	bool SelectCurve(int nCurve);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select X Axis, Call this function to select the given item.
	//		Returns A Boolean value.  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	bool SelectXAxis(int nAxis);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Y Axis, Call this function to select the given item.
	//		Returns A Boolean value.  
	// Parameters:
	//		nAxis---nAxis, Specifies A integer value.
	bool SelectYAxis(int nAxis);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Back Color, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetBackColor(COLORREF color)		 { m_crBackColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Graph Color, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetGraphColor(COLORREF color)		 { m_crGraphColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Inner Color, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetInnerColor(COLORREF color)		 { m_crInnerColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Double Buffer, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetDoubleBuffer(bool bValue)		 { m_bDoubleBuffer = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Legend, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetShowLegend(bool bValue)			 { m_bShowLegend = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Interaction, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetInteraction(bool bValue)		     { m_bInteraction = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Legend Alignment, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		align---Specifies a EAlignment align object(Value).
	inline void SetLegendAlignment(EAlignment align) { m_LegendAlignment = align; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap Cursor, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetSnapCursor(bool bValue)			 { m_bSnapCursor = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap Range, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void SetSnapRange(int nValue)			 { m_nSnapRange = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Header, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		cHeader---cHeader, Specifies A CString type value.
	inline void SetPrintHeader(CString cHeader)      { m_cPrintHeader = cHeader; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Footer, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		cFooter---cFooter, Specifies A CString type value.
	inline void SetPrintFooter(CString cFooter)      { m_cPrintFooter = cFooter; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cursor, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		point---Specifies A CPoint type value.
	inline void SetCursor(CPoint point)              { m_CurrentPoint = point; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cursor Flags, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	inline void SetCursorFlags(UINT nFlags)			 { m_nCursorFlags = nFlags; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF   GetBackColor()		{ return m_crBackColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Graph Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF   GetGraphColor()		{ return m_crGraphColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Inner Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF   GetInnerColor()		{ return m_crInnerColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Double Buffer, Returns the specified value.
	//		Returns A Boolean value.
	inline bool		  GetDoubleBuffer()		{ return m_bDoubleBuffer; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Legend, Returns the specified value.
	//		Returns A Boolean value.
	inline bool		  GetShowLegend()		{ return m_bShowLegend; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Interaction, Returns the specified value.
	//		Returns A Boolean value.
	inline bool       GetInteraction()      { return m_bInteraction; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Legend Alignment, Returns the specified value.
	//		Returns A inline EAlignment value (Object).
	inline EAlignment GetLegendAlignment()	{ return m_LegendAlignment; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Cursor, Returns the specified value.
	//		Returns A Boolean value.
	inline bool		  GetSnapCursor()		{ return m_bSnapCursor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Range, Returns the specified value.
	//		Returns a int type value.
	inline int		  GetSnapRange()		{ return m_nSnapRange; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cursor, Returns the specified value.
	//		Returns a CPoint type value.
	inline CPoint     GetCursor()           { return m_CurrentPoint; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operation, Returns the specified value.
	//		Returns A inline EOperation value (Object).
	inline EOperation GetOperation()        { return m_opOperation; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Autoscale, .
	// Parameters:
	//		nXAxis---X Axis, Specifies A integer value.  
	//		nYAxis---Y Axis, Specifies A integer value.  
	//		nCurve---nCurve, Specifies A integer value.
	void Autoscale(int nXAxis, int nYAxis, int nCurve);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Measures, Deletes the given object.

	inline void DeleteMeasures()                     { m_Measures.clear(); };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Force Snap, .
	// Parameters:
	//		nCurve---nCurve, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	inline void ForceSnap(UINT nCurve)              { m_nForcedSnapCurve = nCurve; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All, Called this function to empty a previously initialized CFOTimeChartShape object.

	void ResetAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cursor Absolute, Returns the specified value.
	//		Returns A FOP_DATAPOINT value (Object).  
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.
	FOP_DATAPOINT GetCursorAbsolute(int nCurve);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cursor Absolute, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.  
	//		vPoint---vPoint, Specifies A integer value.  
	//		bForceVisible---Force Visible, Specifies A Boolean value.
	void SetCursorAbsolute(int nCurve, FOP_DATAPOINT vPoint, bool bForceVisible = false);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save, Call this function to save the specify data to a file.
	//		Returns A Boolean value.  
	// Parameters:
	//		cFile---cFile, Specifies A CString type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	bool Save(const CString cFile, UINT nFlags = 0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	//		Returns A Boolean value.  
	// Parameters:
	//		cFile---cFile, Specifies A CString type value.
	bool Load(const CString cFile);

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	void OnPaint(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoDraw(CDC *pDC);


	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Label, Inserts a child object at the given index..
	//		Returns A E-XD++ CFOTimeChartLabel& value (Object).  
	// Parameters:
	//		cText---cText, Specifies A CString type value.
	CFOTimeChartLabel& InsertLabel(CString cText = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Label, Inserts a child object at the given index..
	//		Returns A E-XD++ CFOTimeChartLabel& value (Object).  
	// Parameters:
	//		rect---Specifies A CRect type value.  
	//		cText---cText, Specifies A CString type value.
	CFOTimeChartLabel& InsertLabel(CRect rect, CString cText = _T(""));
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Graph Margins, Sets a specify value to current class CFOTimeChartShape
	// Parameters:
	//		nLeft---nLeft, Specifies A integer value.  
	//		nTop---nTop, Specifies A integer value.  
	//		nRight---nRight, Specifies A integer value.  
	//		nBottom---nBottom, Specifies A integer value.
	void SetGraphMargins(int nLeft, int nTop, int nRight, int nBottom);

	// Do generate x axis text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate X Axis Text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		&nCount---&nCount, Specifies A integer value.  
	//		&nCur---&nCur, Specifies A integer value.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&strFormat---&strFormat, Specifies A CString type value.
	virtual CString DoGenXAxisText(const int &nCount, const int &nCur, const double &dValue, const CString &strFormat);

 
	// Draw Fn[8], This member specify lpfoDrawFunc object.  
	lpfoDrawFunc  m_pDrawFn[8];
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOTimeChartShape& src object(Value).
	CFOTimeChartShape& operator=(const CFOTimeChartShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Point To Data, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void AdjustPointToData(CPoint& point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Empty Label, Inserts a child object at the given index..

	void InsertEmptyLabel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Maximize For Data, Returns the specified value.
	// Parameters:
	//		serie---Specifies a E-XD++ CFOTimeChartDataSerie& serie object (Value).  
	//		fXMin---X Minimize, Specifies a double& fXMin object(Value).  
	//		fXMax---X Maximize, Specifies a double& fXMax object(Value).  
	//		fYMin---Y Minimize, Specifies a double& fYMin object(Value).  
	//		fYMax---Y Maximize, Specifies a double& fYMax object(Value).
	void GetMinMaxForData (CFOTimeChartDataSerie& serie, double& fXMin, double& fXMax, double& fYMin, double& fYMax);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		pAxis---pAxis, A pointer to the CFOTimeChartAxis or NULL if the call failed.
	int GetAxisIndex(CFOTimeChartAxis* pAxis);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Curve Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		pSerie---pSerie, A pointer to the CFOTimeChartDataSerie or NULL if the call failed.
	int GetCurveIndex(CFOTimeChartDataSerie* pSerie);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Legend, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		ChartRect---Chart Rectangle, Specifies A CRect type value.
	void DrawLegend(CFOChartDC *pDC, CRect& ChartRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Cursor Legend, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	void DrawCursorLegend (CFOChartDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Background Bitmap, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.  
	//		clChartRect---Chart Rectangle, Specifies A CRect type value.
	void DrawBackgroundBitmap(CFOChartDC* pDC, CRect clChartRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Zoom, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	void DrawZoom(CFOChartDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Measure, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.  
	//		measureRect---measureRect, Specifies A CRect type value.
	void DrawMeasure(CFOChartDC* pDC, CRect measureRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Measures, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	void DrawMeasures(CFOChartDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Cursor, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	void DrawCursor(CFOChartDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Linear Trend, .

	void LinearTrend();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cubic Trend, .

	void CubicTrend();

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	// Serializes the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize2, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void Serialize2(CArchive &ar, UINT nFlags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	typedef struct tagSelectByMarker 
	{
		
		CRect markerRect;
		CFOTimeChartObject* pObject;
		
	} SelectByMarker;
	
 
	// Current Point Moving, This member specify NM_POINTMOVING object.  
	static NM_POINTMOVING		m_nmCurrentPointMoving;
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crBackColor;
 
	// Graph Color, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crGraphColor;
 
	// Inner Color, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crInnerColor;
 
	// Double Buffer, Specify A Boolean value.  
	bool						m_bDoubleBuffer;
 
	// Show Legend, Specify A Boolean value.  
	bool						m_bShowLegend;
 
	// Interaction, Specify A Boolean value.  
	bool						m_bInteraction;
 
	// Tmp D C, Specify A Boolean value.  
	bool						m_bTmpDC;
 
	// Legend Alignment, This member specify EAlignment object.  
	EAlignment					m_LegendAlignment;
 
	// Snap Cursor, Specify A Boolean value.  
	bool						m_bSnapCursor;
 
	// Snap Range, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nSnapRange;
 
	// Cursor Flags, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT						m_nCursorFlags;
	
 
	// Inner Rectangle, This member sets a CRect value.  
	CRect                       m_clInnerRect;
 
	// Current Measure, This member sets a CRect value.  
	CRect                       m_clCurrentMeasure;
 
	// Old Cursor Rectangle, This member sets a CRect value.  
	CRect                       m_OldCursorRect;
 
	// Print Rectangle, This member sets a CRect value.  
	CRect                       m_clPrintRect;
 
	// Old Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint                      m_OldPoint;
 
	// Operation, This member specify EOperation object.  
	EOperation                  m_opOperation;
 
	// Snapped Curve, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                         m_nSnappedCurve;
 
	// Snapped Curve1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                         m_nSnappedCurve1;
	int                         m_nLeftMargin,
								m_nTopMargin,
								m_nRightMargin,
								m_nBottomMargin;
 
	// Axis Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                         m_nAxisSpace;
 
	// Bitmap Flags, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                         m_nBitmapFlags;
 
	// Forced Snap Curve, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nForcedSnapCurve;
 
	// Current Zoom, This member sets a CRect value.  
	CRect                       m_clCurrentZoom;
	CPoint						m_MouseDownPoint,
								m_oldCursorPoint,
								m_MouseUpPoint,
								m_CurrentPoint;
 
	// L Button Down, Specify A Boolean value.  
	bool 						m_bLButtonDown;
 
	// R Button Down, Specify A Boolean value.  
	bool 						m_bRButtonDown;
 
	// Object Selected, Specify A Boolean value.  
	bool						m_bObjectSelected;
 
	// Current Edit Value, This member specify double object.  
	double						m_fCurrentEditValue;
 
	// Data Point Moving, Specify A Boolean value.  
	bool						m_bDataPointMoving;
 
	// Selected Serie, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				            m_nSelectedSerie;
	double                      m_fSnappedXVal,
		m_fSnappedYVal;
 
	// Print Header, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                     m_cPrintHeader;
 
	// Print Footer, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                     m_cPrintFooter;
 
	// Cursor Label, This member specify E-XD++ CFOTimeChartLabel object.  
	CFOTimeChartLabel                m_CursorLabel;
 
	// Measure Default, This member specify MeasureDef object.  
	MeasureDef                  m_MeasureDef;
	
 
	// Measures, This member specify vector <MeasureDef> object.  
	vector <MeasureDef>         m_Measures;
 
	// Select By Marker, This member specify vector <SelectByMarker> object.  
	vector <SelectByMarker>     m_SelectByMarker;
 
	// Data, This member specify vector <CFOTimeChartDataSerie> object.  
	vector <CFOTimeChartDataSerie>	m_Data;
 
	// X Axis, This member specify vector <CFOTimeChartAxis> object.  
	vector <CFOTimeChartAxis>		m_XAxis;
 
	// Y Axis, This member specify vector <CFOTimeChartAxis> object.  
	vector <CFOTimeChartAxis>		m_YAxis;
 
	// Objects, This member specify CObList object.  
	CObList				        m_Objects;
 
	// Current Object, This member maintains a pointer to the object CFOTimeChartObject.  
	CFOTimeChartObject*          m_pCurrentObject;
};

#endif // !defined(FO_FOTIMECHARTSHAPE_H__F27364FB_5606_411C_B2E7_D789DC3BFA6A__INCLUDED_)
