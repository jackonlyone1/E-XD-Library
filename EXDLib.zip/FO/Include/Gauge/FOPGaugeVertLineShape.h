// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPGAUGEVERTLINESHAPE_H__51F1E2A4_1821_4297_9364_2D7F0AACC8A7__INCLUDED_)
#define FO_FOPGAUGEVERTLINESHAPE_H__51F1E2A4_1821_4297_9364_2D7F0AACC8A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include "FORectShape.h"
#include "FOMeterHelper.h"
#include "FOHyLinkShape.h"

////////////////////////////////////////////////////////////////////////
// CFOPGaugeVertLineShape -- vertical line gauge shape.
//				ID: FOP_GAUGE_VERTLINE_SHAPE 242

 
//===========================================================================
// Summary:
//     The CFOPGaugeVertLineShape class derived from CFORectShape
//      F O P Gauge Vertical Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPGaugeVertLineShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPGaugeVertLineShape---F O P Gauge Vertical Line Shape, Specifies a E-XD++ CFOPGaugeVertLineShape object (Value).
	DECLARE_SERIAL(CFOPGaugeVertLineShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Gauge Vertical Line Shape, Constructs a CFOPGaugeVertLineShape object.
	//		Returns A  value (Object).
	CFOPGaugeVertLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Gauge Vertical Line Shape, Constructs a CFOPGaugeVertLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPGaugeVertLineShape& src object(Value).
	CFOPGaugeVertLineShape(const CFOPGaugeVertLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Gauge Vertical Line Shape, Destructor of class CFOPGaugeVertLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGaugeVertLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPGaugeVertLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of gauge dashboard
	// strCaption -- caption.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get button background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetButtonBackColor();
	
	// calculates the parameters that define the shape of the button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Sphere Radius, .
	//		Returns a CSize type value.  
	// Parameters:
	//		nSphereExtRadius---Sphere Extend Radius, Specifies A integer value.  
	//		nSphereIntRadius---Sphere Int Radius, Specifies A integer value.
	CSize CalcSphereRadius(int nSphereExtRadius, int nSphereIntRadius);
	
	
	// Draw button background
	void DrawButtonBackground(CDC* pDC, CRect buttonRect);
	
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);
	
	// Draw a rectangle	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);
	
	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// new virtual function used to draw the button background in particular
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button Background1, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		buttonRect---buttonRect, Specifies A CRect type value.
	virtual void DrawButtonBackground1(CDC* pDC, CRect buttonRect);
	
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPGaugeVertLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPGaugeVertLineShape& src object(Value).
	CFOPGaugeVertLineShape& operator=(const CFOPGaugeVertLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Get the rotating angle, override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Calculate the label start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
	/*************************************************************************
	|*
	|* The following virtual methods defined for meter classes.
	|*
	\************************************************************************/

	// Gen meter's start point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Start Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetMeterStartPoint(CObject *pObj);

	// Gen meter's end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter End Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetMeterEndPoint(CObject *pObj);

	// Gen meter's bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMeterRect(CObject *pObj);

	// Get meter scale object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Scale, Returns the specified value.
	//		Returns a pointer to the object CFOPMeterScale ,or NULL if the call failed
	CFOPMeterScale *GetMeterScale();

	// Gen meter scale class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Meter Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPMeterScale ,or NULL if the call failed
	virtual CFOPMeterScale *GenMeterScale();

	// Get indicator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Indicator, Returns the specified value.
	//		Returns a pointer to the object CFOPIndicator ,or NULL if the call failed
	CFOPIndicator *GetIndicator();

	// Gen indicator class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Indicator, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator ,or NULL if the call failed
	virtual CFOPIndicator *GenIndicator();

public:

	//Draw flat status.
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );

	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();

	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();

	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOPGaugeVertLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);

	// Obtain current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	//		Returns A double value (Object).
	double GetCurrentValue() const { return m_dCurValue; }
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPGaugeVertLineShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetCurrentValue(const double &dValue);
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeVertLineShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetSimpleValue(const double &dValue);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;

	// scale.
 
	// Scale, This member maintains a pointer to the object CFOPMeterScale.  
	CFOPMeterScale		*m_pScale;

	// Indicator.
 
	// Indicator, This member maintains a pointer to the object CFOPIndicator.  
	CFOPIndicator		*m_pIndicator;

	// Update slider state.
 
	// Slider, This member sets TRUE if it is right.  
	BOOL			m_updateSlider;
	
};

////////////////////////////////////////////////////////////////////////
// CFOPGaugeHorizLineShape -- vertical line gauge shape.
//				ID: FOP_GAUGE_HORIZ_SHAPE 351

 
//===========================================================================
// Summary:
//     The CFOPGaugeHorizLineShape class derived from CFORectShape
//      F O P Gauge Vertical Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPGaugeHorizLineShape : public CFOPBorderShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPGaugeHorizLineShape---F O P Gauge Vertical Line Shape, Specifies a E-XD++ CFOPGaugeHorizLineShape object (Value).
	DECLARE_SERIAL(CFOPGaugeHorizLineShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Gauge Vertical Line Shape, Constructs a CFOPGaugeHorizLineShape object.
	//		Returns A  value (Object).
	CFOPGaugeHorizLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Gauge Vertical Line Shape, Constructs a CFOPGaugeHorizLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPGaugeHorizLineShape& src object(Value).
	CFOPGaugeHorizLineShape(const CFOPGaugeHorizLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Gauge Vertical Line Shape, Destructor of class CFOPGaugeHorizLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGaugeHorizLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPGaugeHorizLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of gauge dashboard
	// strCaption -- caption.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get button background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetButtonBackColor();
	
	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorderX(CDC *pDC,CRect &rcPos,UINT nType);

	// calculates the parameters that define the shape of the button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Sphere Radius, .
	//		Returns a CSize type value.  
	// Parameters:
	//		nSphereExtRadius---Sphere Extend Radius, Specifies A integer value.  
	//		nSphereIntRadius---Sphere Int Radius, Specifies A integer value.
	CSize CalcSphereRadius(int nSphereExtRadius, int nSphereIntRadius);
	
	
	// Draw button background
	void DrawButtonBackground(CDC* pDC, CRect buttonRect);
	
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPGaugeHorizLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPGaugeHorizLineShape& src object(Value).
	CFOPGaugeHorizLineShape& operator=(const CFOPGaugeHorizLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Get the rotating angle, override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Calculate the label start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
	/*************************************************************************
	|*
	|* The following virtual methods defined for meter classes.
	|*
	\************************************************************************/

	// Gen meter's start point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Start Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetMeterStartPoint(CObject *pObj);

	// Gen meter's end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter End Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetMeterEndPoint(CObject *pObj);

	// Gen meter's bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMeterRect(CObject *pObj);

	// Get meter scale object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Meter Scale, Returns the specified value.
	//		Returns a pointer to the object CFOPMeterScale ,or NULL if the call failed
	CFOPMeterScale *GetMeterScale();

	// Gen meter scale class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Meter Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPMeterScale ,or NULL if the call failed
	virtual CFOPMeterScale *GenMeterScale();

	// Get indicator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Indicator, Returns the specified value.
	//		Returns a pointer to the object CFOPIndicator ,or NULL if the call failed
	CFOPIndicator *GetIndicator();

	// Gen indicator class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Indicator, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator ,or NULL if the call failed
	virtual CFOPIndicator *GenIndicator();

public:

	//Draw flat status.
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );

	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();

	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();

	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOPGaugeHorizLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);

	// Obtain current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	//		Returns A double value (Object).
	double GetCurrentValue() const { return m_dCurValue; }
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPGaugeHorizLineShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetCurrentValue(const double &dValue);
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeHorizLineShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetSimpleValue(const double &dValue);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;

	// scale.
 
	// Scale, This member maintains a pointer to the object CFOPMeterScale.  
	CFOPMeterScale		*m_pScale;

	// Indicator.
 
	// Indicator, This member maintains a pointer to the object CFOPIndicator.  
	CFOPIndicator		*m_pIndicator;

	// Update slider state.
 
	// Slider, This member sets TRUE if it is right.  
	BOOL			m_updateSlider;
	
};


///////////////////////////////////////////////////////////////////////////////
// CFOPNewGaugeMultiPhaseBarShape -- Multiple phase bars linear gauge shape, ID: FO_MULTI_BAR_GAUGE_SHAPE 279
// This is a scale linear dashboard shape.

 
//===========================================================================
// Summary:
//     The CFOPNewGaugeMultiPhaseBarShape class derived from CFOPGaugeVertLineShape
//      F O P New Gauge Multiple Phase Bar Shape
//===========================================================================

class FO_EXT_CLASS CFOPNewGaugeMultiPhaseBarShape : public CFOPGaugeVertLineShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewGaugeMultiPhaseBarShape---F O P New Gauge Multiple Phase Bar Shape, Specifies a E-XD++ CFOPNewGaugeMultiPhaseBarShape object (Value).
	DECLARE_SERIAL(CFOPNewGaugeMultiPhaseBarShape);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Gauge Multiple Phase Bar Shape, Constructs a CFOPNewGaugeMultiPhaseBarShape object.
	//		Returns A  value (Object).
	CFOPNewGaugeMultiPhaseBarShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Gauge Multiple Phase Bar Shape, Constructs a CFOPNewGaugeMultiPhaseBarShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewGaugeMultiPhaseBarShape& src object(Value).
	CFOPNewGaugeMultiPhaseBarShape(const CFOPNewGaugeMultiPhaseBarShape& src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Gauge Multiple Phase Bar Shape, Destructor of class CFOPNewGaugeMultiPhaseBarShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewGaugeMultiPhaseBarShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewGaugeMultiPhaseBarShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewGaugeMultiPhaseBarShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewGaugeMultiPhaseBarShape& src object(Value).
	CFOPNewGaugeMultiPhaseBarShape& operator=(const CFOPNewGaugeMultiPhaseBarShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// Gen meter scale class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Meter Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPMeterScale ,or NULL if the call failed
	virtual CFOPMeterScale *GenMeterScale();
	
	// Gen indicator class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Indicator, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPIndicator ,or NULL if the call failed
	virtual CFOPIndicator *GenIndicator();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

///////////////////////////////////////////////////////////////////
// CFOHighShape

 
//===========================================================================
// Summary:
//     The CFOHighShape class derived from CFORectShape
//      F O High Shape
//===========================================================================

class FO_EXT_CLASS CFOHighShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOHighShape---F O High Shape, Specifies a E-XD++ CFOHighShape object (Value).
	DECLARE_SERIAL(CFOHighShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O High Shape, Constructs a CFOHighShape object.
	//		Returns A  value (Object).
	CFOHighShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O High Shape, Constructs a CFOHighShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHighShape& src object(Value).
	CFOHighShape(const CFOHighShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O High Shape, Destructor of class CFOHighShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOHighShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOHighShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the progress shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOHighShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHighShape& src object(Value).
	CFOHighShape& operator=(const CFOHighShape& src);

	// Update saved size.
	void UpdateSaveData();
	
	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOHighShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:
	// Update slider state.
 
	// Slider, This member sets TRUE if it is right.  
	BOOL			m_updateSlider;
	

	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;
};

#endif // !defined(FO_FOPGAUGEVERTLINESHAPE_H__51F1E2A4_1821_4297_9364_2D7F0AACC8A7__INCLUDED_)
