//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTIMECHARTDATA_H__84BAED73_890D_4ABA_8FB0_68CAD82CCBC9__INCLUDED_)
#define FO_FOTIMECHARTDATA_H__84BAED73_890D_4ABA_8FB0_68CAD82CCBC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Creates a pen within the constructor,
// selects the pen into the DC and
// restores everything when the destructor is called

#pragma warning (disable : 4244)
#pragma warning (disable : 4800)
#pragma warning (disable : 4018)
#pragma warning (disable : 4010)
#pragma warning (disable : 4663)

#include <vector>

using namespace std;

#define FO_MAX_DEGREE 21

typedef struct tagDataPoint
{
	double fXVal;
	double fYVal;
} FOP_DATAPOINT;

typedef struct tagFO_HITTEST
{
	POINT p1;
	POINT p2;
} FO_HITTEST;


#ifdef _WIN32_WCE// ~X~
#ifndef _TCHAR
typedef char            _TCHAR;
#endif
#endif

// Clipboard data
typedef struct tagFOP_CFDATASERIE
{
	long			nCount;
	long            nFirstVisible;
	long            nLastVisible;
	int				nXAxis;
	int				nYAxis;
	int             nIndex;
	int				nLineSize;
	int             nFillStyle;
	int             nMarkerType;
	int             nMarker;
	int             nMarkerSize;
	UINT			nLineStyle;
	bool			bAutoDelete;
	bool			bShowMarker;
	bool            bFillBeneath;
	short           nFillCurve;
	bool            bFillTransparent;
	COLORREF        crFillColor;
	_TCHAR          cLabel[_MAX_PATH];
	int			    gtType;
	
} FOP_CFDATASERIE;


typedef struct tagFOP_COLORRANGE
{
	double   fMin;
	double   fMax;
	COLORREF crMinColor;
	COLORREF crMaxColor;
	UINT     nStyle;
	_TCHAR   szLabel[_MAX_PATH];
} FOP_COLORRANGE;


typedef struct tagFOP_AXISMARKER
{
	double   fValue;
	COLORREF crColor;
	bool     bVisible;
	bool	 bShowValue;
	UINT     nStyle;
	short    nSize;
	LOGFONT  lfFont;
	CString  szLabel;
	
} FOP_AXISMARKER, *PFOP_AXISMARKER;

class CFOTimeChartShape;

////////////////////////////////////////////////////////////
// CFOChartDC

 
//===========================================================================
// Summary:
//     The CFOChartDC class derived from CDC
//      F O Chart D C
//===========================================================================

class FO_EXT_CLASS CFOChartDC : public CDC
{
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Chart D C, Constructs a CFOChartDC object.
	//		Returns A  value (Object).
	CFOChartDC ();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Chart D C, Destructor of class CFOChartDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOChartDC();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare, .
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).
	void Prepare(HDC hdc);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Ratio, .
	// Parameters:
	//		rect---Specifies a RECT& rect object(Value).
	void AdjustRatio(RECT& rect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Ratio, .
	// Parameters:
	//		point---Specifies A integer value.
	void AdjustRatio(POINT& point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Ratio, .
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	void AdjustRatio(int& x, int& y);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Color, Sets a specify value to current class CFOChartDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual COLORREF SetTextColor(COLORREF crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOChartDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual COLORREF SetBkColor(COLORREF crColor);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To, .
	//		Returns a CPoint type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	CPoint MoveTo(int x, int y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To, .
	//		Returns a CPoint type value.  
	// Parameters:
	//		point---Specifies A integer value.
	CPoint MoveTo(POINT point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line To, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	BOOL   LineTo(int x, int y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line To, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A integer value.
	BOOL   LineTo(POINT point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Rectangle, .
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		pBrush---pBrush, A pointer to the CBrush or NULL if the call failed.
	void   FillRect(LPCRECT lpRect, CBrush* pBrush);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Focus Rectangle, Draws current object to the specify device.
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void   DrawFocusRect(LPCRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ellipse, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		x1---Specifies A integer value.  
	//		y1---Specifies A integer value.  
	//		x2---Specifies A integer value.  
	//		y2---Specifies A integer value.
	BOOL   Ellipse(int x1, int y1, int x2, int y2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ellipse, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	BOOL   Ellipse(LPCRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Polygon, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	BOOL   Polygon(LPPOINT lpPoints, int nCount);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		x1---Specifies A integer value.  
	//		y1---Specifies A integer value.  
	//		x2---Specifies A integer value.  
	//		y2---Specifies A integer value.
	BOOL   Rectangle(int x1, int y1, int x2, int y2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	BOOL   Rectangle(LPCRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text, Draws current object to the specify device.
	//		Returns a int type value.  
	// Parameters:
	//		str---Specifies A CString type value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	int    DrawText(const CString& str, LPRECT lpRect, UINT nFormat);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Solid Rectangle, .
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		clr---Specifies A 32-bit COLORREF value used as a color value.
	void   FillSolidRect(LPCRECT lpRect, COLORREF clr);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Solid Rectangle, .
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		clr---Specifies A 32-bit COLORREF value used as a color value.
	void   FillSolidRect(int x, int y, int cx, int cy, COLORREF clr);
	
public:
 
	// Prepared, Specify A Boolean value.  
	bool   m_bPrepared;
 
	// Mono, Specify A Boolean value.  
	bool   m_bMono;
 
	// Printing, Specify A Boolean value.  
	bool   m_bPrinting;
 
	// Print Preview, Specify A Boolean value.  
	bool   m_bPrintPreview;
	float  m_fScaleX,
		   m_fScaleY;

};

typedef void  (*lpfoDrawFunc) (CPoint, int, COLORREF, bool, CFOChartDC*);

void foDrawRect(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawCircle(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawCross(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawLeftTriangle(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawUpTriangle(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawRightTriangle(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawDownTriangle(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
void foDrawRhombus(CPoint point, int nSize, COLORREF color, bool bInvert, CFOChartDC* pDC);
CSize foGetTextExtentEx(CFOChartDC *pDC, CString cTxt);

///////////////////////////////////////////////////
// CFOPenSelector

 
//===========================================================================
// Summary:
//      To use a CFOPenSelector object, just call the constructor.
//      F O Pen Selector
//===========================================================================

class FO_EXT_CLASS CFOPenSelector
{
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pen Selector, Constructs a CFOPenSelector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.  
	//		nSize---nSize, Specifies A integer value.  
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPenSelector(COLORREF color, int nSize, CFOChartDC *pDC, UINT nStyle = PS_SOLID)
	{
		m_pDC = pDC;
		if (!m_pDC->m_bPrepared)
			m_pDC->Prepare(m_pDC->m_hDC);
		
		m_pPen = (CPen*) new CPen(nStyle, pDC->m_bPrinting && nStyle == PS_SOLID ? (int)(pDC->m_fScaleX * nSize) : nSize,  color);
		m_poPen = m_pDC->SelectObject(m_pPen);
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pen Selector, Destructor of class CFOPenSelector
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPenSelector()
	{
		m_pDC->SelectObject(m_poPen);
		m_pPen->DeleteObject();
		delete m_pPen;
	};
protected:
	CPen *m_pPen, *m_poPen;
 
	// D C, This member maintains a pointer to the object CFOChartDC.  
	CFOChartDC  *m_pDC;
};

///////////////////////////////////////////////////
// CFOBrushSelector

 
//===========================================================================
// Summary:
//      To use a CFOBrushSelector object, just call the constructor.
//      F O Brush Selector
//===========================================================================

class FO_EXT_CLASS CFOBrushSelector
{
public:
	
#ifndef _WIN32_WCE
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Selector, Constructs a CFOBrushSelector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	CFOBrushSelector(COLORREF color, int nIndex, CFOChartDC *pDC)
	{
		m_pDC = pDC;
		m_pBrush = (CBrush*) new CBrush(nIndex, color );
		m_poBrush = m_pDC->SelectObject(m_pBrush);
	}
#endif
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Selector, Constructs a CFOBrushSelector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.  
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	CFOBrushSelector(COLORREF color, CFOChartDC *pDC)
	{
		m_pDC = pDC;
		m_pBrush = (CBrush*) new CBrush(color);
		m_poBrush = m_pDC->SelectObject(m_pBrush);
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Brush Selector, Destructor of class CFOBrushSelector
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBrushSelector()
	{
		m_pDC->SelectObject(m_poBrush);
		m_pBrush->DeleteObject();
		delete m_pBrush;
	};
protected:
	CBrush *m_pBrush, *m_poBrush;
 
	// D C, This member maintains a pointer to the object CFOChartDC.  
	CFOChartDC  *m_pDC;
};

///////////////////////////////////////////////
// CFOQuickFont

 
//===========================================================================
// Summary:
//     The CFOQuickFont class derived from CFont
//      F O Quick Font
//===========================================================================

class FO_EXT_CLASS CFOQuickFont : public CFont
{
public :
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Quick Font, Constructs a CFOQuickFont object.
	//		Returns A  value (Object).  
	// Parameters:
	//		cFontName---Font Name, Specifies A CString type value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bUnderLine---Under Line, Specifies A Boolean value.
	CFOQuickFont(CString cFontName, int nHeight, int nWidth, bool bUnderLine = false)
	{
		CreateFont(nHeight,0,0,0, nWidth, 0,bUnderLine ? 1 : 0,0, DEFAULT_CHARSET,
			       OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
				    DEFAULT_PITCH | FF_DONTCARE, cFontName);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Quick Font, Constructs a CFOQuickFont object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpLogFont---Logical Font, A pointer to the LOGFONT or NULL if the call failed.
	CFOQuickFont(LOGFONT* lpLogFont)
	{
		CreateFontIndirect(lpLogFont);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Quick Font, Destructor of class CFOQuickFont
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOQuickFont()
	{
		DeleteObject();
	};
};

// Selects a font into the DC when the constructor is called and
// restores everything when the destructor is called

 
//===========================================================================
// Summary:
//      To use a CFOFontSelector object, just call the constructor.
//      F O Font Selector
//===========================================================================

class FO_EXT_CLASS CFOFontSelector
{
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Selector, Constructs a CFOFontSelector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pFont---pFont, A pointer to the CFont or NULL if the call failed.  
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		bAdjust---bAdjust, Specifies A Boolean value.
	CFOFontSelector(CFont* pFont, CFOChartDC *pDC, bool bAdjust = true)
	{
			m_pDC = pDC;
		if (!m_pDC->m_bPrepared)
			m_pDC->Prepare(m_pDC->m_hDC);

		if (pDC->m_bPrinting && bAdjust)
		{
			LOGFONT logFont;
			pFont->GetLogFont (&logFont);
			logFont.lfHeight = (int)((logFont.lfHeight-1) * pDC->m_fScaleY);
			logFont.lfWidth = (int)(logFont.lfWidth *pDC->m_fScaleX);
			m_PrintFont.CreateFontIndirect(&logFont);
			m_pFont = m_pDC->SelectObject(&m_PrintFont);
		}
		else
			m_pFont = m_pDC->SelectObject(pFont);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Font Selector, Destructor of class CFOFontSelector
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontSelector()
	{
		m_pDC->SelectObject(m_pFont);
		if (m_pDC->m_bPrinting)
			m_PrintFont.DeleteObject();
	}
protected:
 
	// Print Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont  m_PrintFont;
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont *m_pFont;
 
	// D C, This member maintains a pointer to the object CFOChartDC.  
	CFOChartDC   *m_pDC;
};

///////////////////////////////////////////////////////////////////////////
// CFOTimeChartObject

 
//===========================================================================
// Summary:
//     The CFOTimeChartObject class derived from CObject
//      F O Time Chart Object
//===========================================================================

class FO_EXT_CLASS CFOTimeChartObject : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartObject---F O Time Chart Object, Specifies a E-XD++ CFOTimeChartObject object (Value).
    DECLARE_SERIAL(CFOTimeChartObject)
		
 
	// F O Time Chart Shape, This member specify friend class object.  
	friend class CFOTimeChartShape;
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Object, Constructs a CFOTimeChartObject object.
	//		Returns A  value (Object).
	CFOTimeChartObject();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Object, Constructs a CFOTimeChartObject object.
	//		Returns A  value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartObject& copy object(Value).
	CFOTimeChartObject(const CFOTimeChartObject& copy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartObject& value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartObject& copy object(Value).
	CFOTimeChartObject& operator=(const CFOTimeChartObject& copy);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTimeChartObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOTimeChartObject* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Object, Destructor of class CFOTimeChartObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartObject();
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	virtual void Draw(CFOChartDC *pDC) { pDC; } ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Edit, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Edit() {} ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Edit, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EndEdit() {} ;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Begin Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BeginSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EndSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invoke Properties, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InvokeProperties() {} ;
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CFOTimeChartObject
	// Parameters:
	//		rect---Specifies A CRect type value.
	inline  void SetRect(CRect rect) { m_clRect = rect; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOTimeChartObject
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline  void SetSelected(bool bValue) { m_bSelected = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOTimeChartObject
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline  void SetVisible(bool bValue) { m_bVisible = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOTimeChartObject
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline  void SetColor(COLORREF color) { m_crColor = color; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	inline  CRect GetRect() const { return m_clRect; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	//		Returns A Boolean value.
	inline  bool  GetSelected() const { return m_bSelected; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Visible, Returns the specified value.
	//		Returns A Boolean value.
	inline  bool  GetVisible() const { return m_bVisible; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline  COLORREF GetColor() const { return m_crColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Graph, Returns the specified value.
	//		Returns a pointer to the object inline  CFOTimeChartShape,or NULL if the call failed
	inline  CFOTimeChartShape* GetGraph() const { return m_pGraph; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	virtual void Serialize( CArchive& archive );

protected:
 
	// Rectangle, This member sets a CRect value.  
	CRect    m_clRect;
 
	// Selected, Specify A Boolean value.  
	bool     m_bSelected;
 
	// Editing, Specify A Boolean value.  
	bool     m_bEditing;
 
	// Can Resize, Specify A Boolean value.  
	bool     m_bCanResize;
 
	// Can Move, Specify A Boolean value.  
	bool     m_bCanMove;
 
	// Sizing, Specify A Boolean value.  
	bool     m_bSizing;
 
	// Visible, Specify A Boolean value.  
	bool     m_bVisible;
 
	// Can Edit, Specify A Boolean value.  
	bool     m_bCanEdit;
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crColor;
 
	// Graph, This member maintains a pointer to the object CFOTimeChartShape.  
	CFOTimeChartShape* m_pGraph;
 
	// Tracker, This member sets a CRect value.  
	CRectTracker m_Tracker;

};


///////////////////////////////////////////////////////////////////////////
// CFOTimeChartLabel

 
//===========================================================================
// Summary:
//     The CFOTimeChartLabel class derived from CFOTimeChartObject
//      F O Time Chart Label
//===========================================================================

class FO_EXT_CLASS CFOTimeChartLabel : public CFOTimeChartObject  
{
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartLabel---F O Time Chart Label, Specifies a E-XD++ CFOTimeChartLabel object (Value).
	DECLARE_SERIAL( CFOTimeChartLabel )
 
	// F O Time Chart Shape, This member specify friend class object.  
	friend class CFOTimeChartShape;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Label, Constructs a CFOTimeChartLabel object.
	//		Returns A  value (Object).
	CFOTimeChartLabel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Label, Constructs a CFOTimeChartLabel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartLabel& copy object(Value).
	CFOTimeChartLabel(const CFOTimeChartLabel& copy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartLabel& operator value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartLabel& copy object(Value).
	CFOTimeChartLabel& operator =(const CFOTimeChartLabel& copy);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTimeChartObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOTimeChartObject* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Label, Destructor of class CFOTimeChartLabel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartLabel();
	
protected:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	virtual void Draw(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Edit, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Edit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Edit, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EndEdit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invoke Properties, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InvokeProperties();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		pLogFont---Logical Font, A pointer to the LOGFONT or NULL if the call failed.
	void SetFont(LOGFONT* pLogFont);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		cText---cText, Specifies A CString type value.
	inline void SetText(CString cText) { m_cText = cText; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetColor(COLORREF color) { m_crColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Color, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetTextColor(COLORREF color) { m_crTextColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetBorder(bool bValue) { m_bBorder = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetTransparent(bool bValue) { m_bTransparent = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		nValue---nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	inline void SetAlignment(UINT nValue) { m_nAlignment = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Curve, Sets a specify value to current class CFOTimeChartLabel
	// Parameters:
	//		nCurve---nCurve, Specifies A integer value.
	inline void SetCurve(int nCurve) { m_nCurve = nCurve; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text, Returns the specified value.
	//		Returns a CString type value.
	inline CString GetText() const { return m_cText; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF GetColor() const { return m_crColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF GetTextColor() const { return m_crTextColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetBorder() const { return m_bBorder; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetTransparent() const { return m_bTransparent; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Alignment, Returns the specified value.
	//		Returns a UINT type value.
	inline UINT GetAlignment() const { return m_nAlignment; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Curve, Returns the specified value.
	//		Returns a int type value.
	inline int  GetCurve() const { return m_nCurve; };
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	virtual void Serialize( CArchive& archive );
	
protected:
 
	// Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString  m_cText;
 
	// Edit, This member specify CEdit object.  
	CEdit    m_Edit;
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont    m_Font;
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crColor;
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTextColor;
 
	// Border, Specify A Boolean value.  
	bool     m_bBorder;
 
	// Transparent, Specify A Boolean value.  
	bool     m_bTransparent;
 
	// Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT     m_nAlignment;
 
	// Curve, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int      m_nCurve;
	
};

///////////////////////////////////////////////////////////////////////////
// CFOPolynomialSolver

 
//===========================================================================
// Summary:
//      To use a CFOPolynomialSolver object, just call the constructor.
//      F O Polynomial Solver
//===========================================================================

class FO_EXT_CLASS CFOPolynomialSolver
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Polynomial Solver, Constructs a CFOPolynomialSolver object.
	//		Returns A  value (Object).
	CFOPolynomialSolver() {;};
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Polynomial Solver, Destructor of class CFOPolynomialSolver
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPolynomialSolver() {;};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Solve, .
	//		Returns A Boolean value.  
	// Parameters:
	//		a[]---Specifies a double a[] object(Value).  
	//		b[]---Specifies a double b[] object(Value).  
	//		n---Specifies A integer value.
	bool Solve(double a[], double b[], int n);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Polyfit, .
	//		Returns A Boolean value.  
	// Parameters:
	//		nRows---nRows, Specifies A integer value.  
	//		nOrder---nOrder, Specifies A integer value.  
	//		*pData---*pData, A pointer to the FOP_DATAPOINT  or NULL if the call failed.
	bool Polyfit(int nRows, int nOrder, FOP_DATAPOINT *pData);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		fX---fX, Specifies a double fX object(Value).
	double GetValue(double fX);

 
	// Global O, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int     m_nGlobalO;
 
	// C[ F O_ M A X_ D E G R E E], This member specify double object.  
	double  m_fC[FO_MAX_DEGREE];
};

///////////////////////////////////////////////////////////////////////////
// CFOTimeChartDataSerie

 
//===========================================================================
// Summary:
//     The CFOTimeChartDataSerie class derived from CFOTimeChartObject
//      F O Time Chart Data Serie
//===========================================================================

class FO_EXT_CLASS CFOTimeChartDataSerie : public CFOTimeChartObject
{

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartDataSerie---F O Time Chart Data Serie, Specifies a E-XD++ CFOTimeChartDataSerie object (Value).
	DECLARE_SERIAL( CFOTimeChartDataSerie )

 
	// F O Time Chart Shape, This member specify friend class object.  
	friend class CFOTimeChartShape;
 
	// F O Time Chart Axis, This member specify friend class object.  
	friend class CFOTimeChartAxis;
 
	// F O Time Chart Label, This member specify friend class object.  
	friend class CFOTimeChartLabel;

private :

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Line, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt0---Specifies a POINT pt0 object(Value).  
	//		pt1---Specifies a POINT pt1 object(Value).  
	//		ptMouse---ptMouse, Specifies a POINT ptMouse object(Value).  
	//		nWidth---nWidth, Specifies A integer value.
	BOOL HitTestLine(POINT pt0, POINT pt1, POINT ptMouse, int nWidth);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Curve Grip Rgn, You construct a CFOTimeChartDataSerie object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		oldPoint---oldPoint, Specifies A CPoint type value.  
	//		point---Specifies A CPoint type value.
	void CreateCurveGripRgn(CPoint oldPoint, CPoint point);

public:

	enum EGraphType
	{
		gtLine,
		gtScatter
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Data Serie, Constructs a CFOTimeChartDataSerie object.
	//		Returns A  value (Object).
	CFOTimeChartDataSerie();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Data Serie, Constructs a CFOTimeChartDataSerie object.
	//		Returns A  value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartDataSerie& copy object(Value).
	CFOTimeChartDataSerie(const CFOTimeChartDataSerie& copy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartDataSerie& operator value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartDataSerie& copy object(Value).
	CFOTimeChartDataSerie& operator =(const CFOTimeChartDataSerie& copy);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTimeChartObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOTimeChartObject* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Data Serie, Destructor of class CFOTimeChartDataSerie
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartDataSerie();

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	virtual void	Draw(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Marker, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	void			DrawMarker(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Visible Range, Called this function to empty a previously initialized CFOTimeChartDataSerie object.

	void            ResetVisibleRange();

public:

 
	// P S, This member specify E-XD++ CFOPolynomialSolver object.  
	CFOPolynomialSolver m_PS;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Clipboard, .
	// Parameters:
	//		serie---Specifies a FOP_CFDATASERIE& serie object(Value).
	void			PrepareClipboard(FOP_CFDATASERIE& serie);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Graph, Returns the specified value.
	//		Returns a pointer to the object CFOTimeChartShape,or NULL if the call failed
	CFOTimeChartShape*		GetGraph() { return m_pGraph; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Linear Trend, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		nPoints---nPoints, Specifies A 32-bit long signed integer.
	FOP_DATAPOINT*     GetLinearTrend(long nPoints = 0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cubic Trend, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		nPoints---nPoints, Specifies A 32-bit long signed integer.
	FOP_DATAPOINT*		GetCubicTrend(long nPoints = 0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polynomial Trend, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		nDegree---nDegree, Specifies A integer value.  
	//		nPoints---nPoints, Specifies A integer value.
	FOP_DATAPOINT*     GetPolynomialTrend(int nDegree, int nPoints = 0);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Simple Moving Average, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		span---Specifies A integer value.
	FOP_DATAPOINT*		GetSimpleMovingAverage(int span);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Exponential Moving Average, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		span---Specifies A integer value.
	FOP_DATAPOINT*     GetExponentialMovingAverage(int span);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Linear Moving Average, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		span---Specifies A integer value.
	FOP_DATAPOINT*		GetLinearMovingAverage(int span);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Triangular Moving Average, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		span---Specifies A integer value.
	FOP_DATAPOINT*     GetTriangularMovingAverage(int span);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sine Weighted Moving Average, Returns the specified value.
	//		Returns a pointer to the object FOP_DATAPOINT,or NULL if the call failed  
	// Parameters:
	//		span---Specifies A integer value.
	FOP_DATAPOINT*		GetSineWeightedMovingAverage(int span);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Size, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void     SetLineSize(int nValue) { m_nLineSize = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Style, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void     SetFillStyle(int nValue) { m_nFillStyle = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Marker Type, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void     SetMarkerType(int nValue) { m_nMarkerType = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Marker, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void     SetMarker(int nValue) { m_nMarker = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Marker Size, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void     SetMarkerSize(int nValue) { m_nMarkerSize = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Style, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nValue---nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	inline void     SetLineStyle(UINT nValue) { m_nLineStyle = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Marker, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void     SetShowMarker(bool bValue) { m_bShowMarker = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Color, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	inline void     SetFillColor(COLORREF crColor) { m_crFillColor = crColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Curve, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		nCurve---nCurve, Specifies a short nCurve object(Value).
	inline void     SetFillCurve(short nCurve) { m_nFillCurve = nCurve;};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Beneath, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.  
	//		nCurve---nCurve, Specifies a short nCurve = -1 object(Value).
	inline void     SetFillBeneath(bool bValue, short nCurve = -1 ) { m_bFillBeneath = bValue; m_nFillCurve = nCurve;};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Transparent, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void     SetFillTransparent(bool bValue) { m_bFillTransparent = bValue; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		cValue---cValue, Specifies A CString type value.
	inline void     SetLabel(CString cValue) { m_cLabel = cValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOTimeChartDataSerie
	// Parameters:
	//		type---Specifies a EGraphType type object(Value).
	inline void     SetType(EGraphType type) { m_gtType = type; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	inline long     GetCount() const { return m_nCount; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns a int type value.
	inline int      GetIndex() const { return m_nIndex; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Axis, Returns the specified value.
	//		Returns a int type value.
	inline int      GetXAxis() const { return m_nXAxis; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Axis, Returns the specified value.
	//		Returns a int type value.
	inline int      GetYAxis() const { return m_nYAxis; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Size, Returns the specified value.
	//		Returns a int type value.
	inline int      GetLineSize() const { return m_nLineSize; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Style, Returns the specified value.
	//		Returns a int type value.
	inline int      GetFillStyle() const { return m_nFillStyle; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Marker Type, Returns the specified value.
	//		Returns a int type value.
	inline int      GetMarkerType() const { return m_nMarkerType; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Marker, Returns the specified value.
	//		Returns a int type value.
	inline int      GetMarker() const { return m_nMarker; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Marker Size, Returns the specified value.
	//		Returns a int type value.
	inline int      GetMarkerSize() const { return m_nMarkerSize; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Style, Returns the specified value.
	//		Returns a UINT type value.
	inline UINT     GetLineStyle() const { return m_nLineStyle; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Marker, Returns the specified value.
	//		Returns A Boolean value.
	inline bool     GetShowMarker() const { return m_bShowMarker; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Beneath, Returns the specified value.
	//		Returns A Boolean value.
	inline bool     GetFillBeneath() const { return m_bFillBeneath; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Curve, Returns the specified value.
	//		Returns A inline short value (Object).
	inline short    GetFillCurve() const { return m_nFillCurve; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Transparent, Returns the specified value.
	//		Returns A Boolean value.
	inline bool     GetFillTransparent() const { return m_bFillTransparent; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label, Returns the specified value.
	//		Returns a CString type value.
	inline CString  GetLabel() const { return m_cLabel; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns A inline EGraphType value (Object).
	inline EGraphType GetType() const { return m_gtType; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	virtual void Serialize( CArchive& archive );

	
protected:
	
 
	// Data, This member maintains a pointer to the object FOP_DATAPOINT.  
	FOP_DATAPOINT*		m_pData;
 
	// Count, Specify a A 32-bit signed integer.  
	long			m_nCount;
 
	// First Visible, Specify a A 32-bit signed integer.  
	long            m_nFirstVisible;
 
	// Last Visible, Specify a A 32-bit signed integer.  
	long            m_nLastVisible;
 
	// X Axis, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nXAxis;
 
	// Y Axis, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nYAxis;
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nIndex;
 
	// Line Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineSize;
 
	// Fill Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nFillStyle;
 
	// Marker Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nMarkerType;
 
	// Marker, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nMarker;
 
	// Marker Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nMarkerSize;
 
	// Line Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nLineStyle;
 
	// Automatic Delete, Specify A Boolean value.  
	bool			m_bAutoDelete;
 
	// Show Marker, Specify A Boolean value.  
	bool			m_bShowMarker;
 
	// Fill Beneath, Specify A Boolean value.  
	bool            m_bFillBeneath;
 
	// Fill Transparent, Specify A Boolean value.  
	bool            m_bFillTransparent;
 
	// Fill Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crFillColor;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_cLabel;
 
	// Type, This member specify EGraphType object.  
	EGraphType      m_gtType;
	
 
	// Fill Curve, This member specify short object.  
	short           m_nFillCurve;
	
 
	// Curve Regions, This member specify vector<FO_HITTEST> object.  
	vector<FO_HITTEST> m_CurveRegions;	

};

///////////////////////////////////////////////////////////////////////////
// CFOTimeChartDataNotation

 
//===========================================================================
// Summary:
//     The CFOTimeChartDataNotation class derived from CFOTimeChartObject
//      F O Time Chart Data Notation
//===========================================================================

class FO_EXT_CLASS CFOTimeChartDataNotation : public CFOTimeChartObject  
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartDataNotation---F O Time Chart Data Notation, Specifies a E-XD++ CFOTimeChartDataNotation object (Value).
	DECLARE_SERIAL( CFOTimeChartDataNotation )
 
	// F O Time Chart Shape, This member specify friend class object.  
	friend class CFOTimeChartShape;
public:
 
	// X Value, This member specify double object.  
	double  m_fXVal;
 
	// Y Value, This member specify double object.  
	double  m_fYVal;
 
	// Curve, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nCurve;
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int     m_nIndex;
 
	// Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_cText;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Data Notation, Constructs a CFOTimeChartDataNotation object.
	//		Returns A  value (Object).
	CFOTimeChartDataNotation();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Data Notation, Constructs a CFOTimeChartDataNotation object.
	//		Returns A  value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartDataNotation& copy object(Value).
	CFOTimeChartDataNotation(const CFOTimeChartDataNotation& copy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartDataNotation& operator value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartDataNotation& copy object(Value).
	CFOTimeChartDataNotation& operator =(const CFOTimeChartDataNotation& copy);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTimeChartObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOTimeChartObject* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Data Notation, Destructor of class CFOTimeChartDataNotation
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartDataNotation();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	virtual void Draw(CFOChartDC *pDC);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	virtual void Serialize( CArchive& archive );
	
protected:
	
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont m_Font;
 
	// Positioned, Specify A Boolean value.  
	bool  m_bPositioned;

};

///////////////////////////////////////////////////////////////////////////
// CFOTimeChartAxis

 
//===========================================================================
// Summary:
//     The CFOTimeChartAxis class derived from CFOTimeChartObject
//      F O Time Chart Axis
//===========================================================================

class FO_EXT_CLASS CFOTimeChartAxis : public CFOTimeChartObject 
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTimeChartAxis---F O Time Chart Axis, Specifies a E-XD++ CFOTimeChartAxis object (Value).
	DECLARE_SERIAL( CFOTimeChartAxis )

 
	// F O Time Chart Shape, This member specify friend class object.  
	friend class CFOTimeChartShape;
 
	// F O Time Chart Data Serie, This member specify friend class object.  
	friend class CFOTimeChartDataSerie;

public:

	enum EAxisPlacement
	{
		apLeft,
		apRight,
		apAutomatic
	};

	enum EAxisType 
	{
		atLog,
		atLinear
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Axis, Constructs a CFOTimeChartAxis object.
	//		Returns A  value (Object).
	CFOTimeChartAxis();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Time Chart Axis, Constructs a CFOTimeChartAxis object.
	//		Returns A  value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartAxis& copy object(Value).
	CFOTimeChartAxis(const CFOTimeChartAxis& copy);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTimeChartObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOTimeChartObject* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Time Chart Axis, Destructor of class CFOTimeChartAxis
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTimeChartAxis();

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTimeChartAxis& operator value (Object).  
	// Parameters:
	//		copy---Specifies a const CFOTimeChartAxis& copy object(Value).
	CFOTimeChartAxis& operator = (const CFOTimeChartAxis& copy);

protected:

	enum EAxisKind {
		xAxis,
		yAxis
	};

	enum EDirection {

		left,
		up,
		right,
		down,
		circle,
		circleClosed,
		rect,
		rectClosed
	};

 
	// Color Ranges, This member specify vector <FOP_COLORRANGE> object.  
	vector <FOP_COLORRANGE> m_ColorRanges;
 
	// Axis Markers, This member specify vector <FOP_AXISMARKER> object.  
	vector <FOP_AXISMARKER> m_AxisMarkers;

 
	// Minimize, This member specify double object.  
	double m_fMin;
 
	// Maximize, This member specify double object.  
	double m_fMax;
 
	// Current Minimize, This member specify double object.  
	double m_fCurMin;
 
	// Current Maximize, This member specify double object.  
	double m_fCurMax;
 
	// Step, This member specify double object.  
	double m_fStep;
 
	// Spare Range, This member specify double object.  
	double m_fSpareRange;
 
	// Marker Spare Size, This member specify double object.  
	double m_fMarkerSpareSize;
 
	// Range, This member specify double object.  
	double m_fRange;
	
 
	// Time Step Table[], This member specify double object.  
	static double TimeStepTable[];
	
 
	// Top, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int   m_nTop;
 
	// Left, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int   m_nLeft;
 
	// Range, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int   m_nRange;
 
	// Chart, This member sets a CRect value.  
	CRect m_clChart;
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont m_Font;
 
	// Title Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont m_TitleFont;
	
 
	// Axis Kind, This member specify EAxisKind object.  
	EAxisKind m_AxisKind;
 
	// Axis Type, This member specify EAxisType object.  
	EAxisType m_AxisType;

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	virtual void Draw(CFOChartDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Logical, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CFOChartDC or NULL if the call failed.
	void   DrawLog(CFOChartDC* pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Round Double, .
	//		Returns A double value (Object).  
	// Parameters:
	//		doValue---doValue, Specifies a double doValue object(Value).  
	//		nPrecision---nPrecision, Specifies A integer value.
	double RoundDouble(double doValue, int nPrecision);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adapt Axis, .
	// Parameters:
	//		fStart---fStart, A pointer to the double or NULL if the call failed.  
	//		fEnd---fEnd, A pointer to the double or NULL if the call failed.  
	//		fStep---fStep, Specifies a double fStep object(Value).
	void   AdaptAxis(double* fStart, double* fEnd, double fStep);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adapt Time Axis, .
	// Parameters:
	//		pfStart---pfStart, A pointer to the double  or NULL if the call failed.  
	//		pfEnd---pfEnd, A pointer to the double  or NULL if the call failed.  
	//		fStep---fStep, Specifies a double fStep object(Value).
	void   AdaptTimeAxis(double * pfStart, double * pfEnd, double fStep);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fit Time Scale, .
	// Parameters:
	//		*fStepWidth---Step Width, A pointer to the double  or NULL if the call failed.  
	//		nBestCount---Best Count, Specifies A integer value.  
	//		fStart---fStart, Specifies a double fStart object(Value).  
	//		fEnd---fEnd, Specifies a double fEnd object(Value).
	void   FitTimeScale(double *fStepWidth, int nBestCount, double fStart, double fEnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fit Scale, .
	// Parameters:
	//		*fStepWidth---Step Width, A pointer to the double  or NULL if the call failed.  
	//		nBestCount---Best Count, Specifies A integer value.  
	//		fStart---fStart, Specifies a double fStart object(Value).  
	//		fEnd---fEnd, Specifies a double fEnd object(Value).
	void   FitScale (double *fStepWidth, int nBestCount, double fStart, double fEnd);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Axis Markers, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	void   DrawAxisMarkers(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Color Ranges, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	void   DrawColorRanges(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Arc, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.  
	//		direction---Specifies a EDirection direction object(Value).  
	//		nSize---nSize, Specifies A integer value.
	void   DrawArc(CFOChartDC *pDC, CPoint point, EDirection direction, int nSize);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Marker, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.  
	//		nMarker---nMarker, Specifies A integer value.  
	//		nSize---nSize, Specifies A integer value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bSymbol---bSymbol, Specifies A Boolean value.
	void   DrawMarker(CFOChartDC *pDC, CPoint point, int nMarker, int nSize, COLORREF crColor, bool bSymbol = false);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Curve Markers, Draws current object to the specify device.
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.  
	//		bDraw---bDraw, Specifies A Boolean value.
	int	   DrawCurveMarkers(CFOChartDC *pDC, bool bDraw = true);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Label Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	int    GetMaxLabelWidth(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Label Height, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	int    GetMaxLabelHeight(CFOChartDC *pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index By X Value, Returns the specified value.
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.  
	//		x---Specifies a double x object(Value).  
	//		nCurve---nCurve, Specifies A integer value.
	void   GetIndexByXVal(long& nIndex, double x, int nCurve);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Automatic Scale, .
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	void   AutoScale(CFOChartDC *pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Best Step, Sets a specify value to current class CFOTimeChartAxis

	void   SetBestStep();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Size, Returns the specified value.
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CFOChartDC  or NULL if the call failed.
	CSize  GetTitleSize(CFOChartDC *pDC);


public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Axis Type, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		type---Specifies a EAxisType type object(Value).
	inline void SetAxisType(EAxisType type){ m_AxisType = type; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis Type, Returns the specified value.
	//		Returns A inline EAxisType value (Object).
	inline EAxisType GetAxisType(){ return m_AxisType; };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Marker, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetShowMarker(bool bValue) { m_bShowMarker = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Date Time, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetDateTime(bool bValue) { m_bDateTime = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Grid, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetShowGrid(bool bValue) { m_bShowGrid = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Scale, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	inline void SetAutoScale(bool bValue) { m_bAutoScale = bValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arc Size, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void SetArcSize(int nValue) { m_nArcSize = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Marker Size, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void SetMarkerSize(int nValue) { m_nMarkerSize = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tick Size, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	inline void SetTickSize(int nValue) { m_nTickSize = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Style, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nValue---nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	inline void SetGridStyle(UINT nValue) { m_nGridStyle = nValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		cValue---cValue, Specifies A CString type value.
	inline void SetLabel(CString cValue) { m_cLabel = cValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Display Fmt, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		cValue---cValue, Specifies A CString type value.
	inline void SetDisplayFmt(CString cValue) { m_cDisplayFmt = cValue; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Color, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	inline void SetGridColor(COLORREF color) { m_crGridColor = color; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Placement, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		placement---Specifies a EAxisPlacement placement object(Value).
	inline void SetPlacement(EAxisPlacement placement) { m_Placement = placement; };
	 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Placement, Returns the specified value.
	//		Returns A inline EAxisPlacement value (Object).
	inline EAxisPlacement GetPlacement() const { return m_Placement; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Marker, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetShowMarker() const { return m_bShowMarker; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Time, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetDateTime() const { return m_bDateTime; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Grid, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetShowGrid() const { return m_bShowGrid; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Automatic Scale, Returns the specified value.
	//		Returns A Boolean value.
	inline bool GetAutoScale() const { return m_bAutoScale; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arc Size, Returns the specified value.
	//		Returns a int type value.
	inline int GetArcSize() const { return m_nArcSize; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Marker Size, Returns the specified value.
	//		Returns a int type value.
	inline int GetMarkerSize() const { return m_nMarkerSize; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tick Size, Returns the specified value.
	//		Returns a int type value.
	inline int GetTickSize() const { return m_nTickSize; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Style, Returns the specified value.
	//		Returns a UINT type value.
	inline UINT GetGridStyle() const { return m_nGridStyle; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label, Returns the specified value.
	//		Returns a CString type value.
	inline CString GetLabel() const { return m_cLabel; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Display Fmt, Returns the specified value.
	//		Returns a CString type value.
	inline CString GetDisplayFmt() const { return m_cDisplayFmt; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	inline COLORREF GetGridColor() const { return m_crGridColor; };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis Marker Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	inline long GetAxisMarkerCount() { return m_AxisMarkers.size(); };

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point For Value, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		point---A pointer to the FOP_DATAPOINT or NULL if the call failed.
	CPoint GetPointForValue(FOP_DATAPOINT* point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value For Position, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	double GetValueForPos(int nPos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Axis Marker, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nMarker---nMarker, Specifies A integer value.  
	//		fValue---fValue, Specifies a double fValue object(Value).  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetAxisMarker(int nMarker, double fValue, COLORREF crColor, UINT nStyle = PS_SOLID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Axis Marker, Deletes the given object.
	// Parameters:
	//		nMarker---nMarker, Specifies A integer value.
	void DeleteAxisMarker(int nMarker);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis Marker, .
	//		Returns A FOP_AXISMARKER value (Object).  
	// Parameters:
	//		nMarker---nMarker, Specifies A integer value.
	FOP_AXISMARKER &GetAxisMarker(int nMarker);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color Range, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		nRange---nRange, Specifies A integer value.  
	//		fMin---fMin, Specifies a double fMin object(Value).  
	//		fMax---fMax, Specifies a double fMax object(Value).  
	//		crMinColor---Minimize Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		crMaxColor---Maximize Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		cLabel---cLabel, Specifies A CString type value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetColorRange(int nRange, double fMin, double fMax, COLORREF crMinColor, COLORREF crMaxColor, CString cLabel, UINT nStyle = 6);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Color Range, Deletes the given object.
	// Parameters:
	//		nRange---nRange, Specifies A integer value.
	void DeleteColorRange(int nRange);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Color Ranges, Deletes the given object.

	void DeleteAllColorRanges();
		
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOTimeChartAxis object.

	void Reset();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range, Sets a specify value to current class CFOTimeChartAxis
	//		Returns A Boolean value.  
	// Parameters:
	//		fMin---fMin, Specifies a double fMin object(Value).  
	//		fMax---fMax, Specifies a double fMax object(Value).
	bool SetRange(double fMin, double fMax);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Range, Sets a specify value to current class CFOTimeChartAxis
	//		Returns A Boolean value.  
	// Parameters:
	//		fMin---fMin, Specifies a double fMin object(Value).  
	//		fMax---fMax, Specifies a double fMax object(Value).  
	//		fStep---fStep, Specifies a double fStep = 0.0 object(Value).
	bool SetCurrentRange(double fMin, double fMax, double fStep = 0.0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		cFontName---Font Name, Specifies A CString type value.  
	//		nFontHeight---Font Height, Specifies A integer value.  
	//		nFontStyle---Font Style, Specifies A integer value.
	void SetFont(CString cFontName, int nFontHeight, int nFontStyle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		pLogFont---Logical Font, Specifies a LPLOGFONT pLogFont object(Value).
	void SetFont(LPLOGFONT pLogFont);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Font, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		pLogFont---Logical Font, Specifies a LPLOGFONT pLogFont object(Value).
	void SetTitleFont(LPLOGFONT pLogFont);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Font, Sets a specify value to current class CFOTimeChartAxis
	// Parameters:
	//		cFontName---Font Name, Specifies A CString type value.  
	//		nFontHeight---Font Height, Specifies A integer value.  
	//		nFontStyle---Font Style, Specifies A integer value.
	void SetTitleFont(CString cFontName, int nFontHeight, int nFontStyle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Range, Returns the specified value.
	// Parameters:
	//		double&fMin---double&fMin, Specifies a double&fMin object(Value).  
	//		fMax---fMax, Specifies a double& fMax object(Value).  
	//		fStep---fStep, Specifies a double& fStep object(Value).
	void GetRange(double&fMin, double& fMax, double& fStep);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		fFactor---fFactor, Specifies a double fFactor object(Value).
	void Scale(double fFactor);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	virtual void Serialize(CArchive& archive);
	
protected:
	
 
	// Placement, This member specify EAxisPlacement object.  
	EAxisPlacement m_Placement;
	
 
	// Show Marker, Specify A Boolean value.  
	bool     m_bShowMarker;
 
	// Date Time, Specify A Boolean value.  
	bool     m_bDateTime;
 
	// Show Grid, Specify A Boolean value.  
	bool     m_bShowGrid;
 
	// Automatic Scale, Specify A Boolean value.  
	bool     m_bAutoScale;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString  m_cLabel;
 
	// Display Fmt, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString  m_cDisplayFmt;
 
	// Arc Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int      m_nArcSize;
 
	// Marker Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int      m_nMarkerSize;
 
	// Tick Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int      m_nTickSize;
 
	// Grid Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crGridColor;
 
	// Grid Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT     m_nGridStyle;
	
};

#pragma warning (default : 4244)
#pragma warning (default : 4800)
#pragma warning (default : 4018)
#pragma warning (default : 4010)
#pragma warning (default : 4663)


#endif // !defined(FO_FOTIMECHARTDATA_H__84BAED73_890D_4ABA_8FB0_68CAD82CCBC9__INCLUDED_)
