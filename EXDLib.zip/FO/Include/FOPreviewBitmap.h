//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPreviewBitmap.h: interface for the CFOPreviewBitmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPREVIEWBITMAP_H__28476AB3_29AD_11D6_A52D_525400EA266C__INCLUDED_)
#define AFX_FOPREVIEWBITMAP_H__28476AB3_29AD_11D6_A52D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////////
//
// CFOPreviewBitmap -- the preview bitmap of data model.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPreviewBitmap class derived from CBitmap
//      F O Preview Bitmap
//===========================================================================

class FO_EXT_CLASS CFOPreviewBitmap : public CBitmap
{
protected: //Create from serialization only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPreviewBitmap---F O Preview Bitmap, Specifies a E-XD++ CFOPreviewBitmap object (Value).
    DECLARE_DYNCREATE(CFOPreviewBitmap) 

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Preview Bitmap, Constructs a CFOPreviewBitmap object.
	//		Returns A  value (Object).
	CFOPreviewBitmap();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Preview Bitmap, Destructor of class CFOPreviewBitmap
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPreviewBitmap();

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
    virtual void Dump(CDumpContext& dc) const;    
#endif

public:

	// Create palette
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create D I B Palette, You construct a CFOPreviewBitmap object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hDIB---D I B, Specifies a HANDLE hDIB object(Value).  
	//		pPalette---pPalette, A pointer to the CPalette or NULL if the call failed.
	BOOL CreateDIBPalette(HANDLE hDIB,CPalette* pPalette);

	// Get the handle of dib.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get D I B Handle, Returns the specified value.
	//		Returns A HANDLE value (Object).
	HANDLE GetDIBHandle();

	// Convert to ddb.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To D D B, .
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		HANDLE---A N D L E, Specifies a HANDLE object(Value).
    HBITMAP ConvertToDDB(HANDLE);

	// Find dib bits.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Find D I B Bits, .
	//		Returns A LPTSTR value (Object).  
	// Parameters:
	//		lpDIB---D I B, Specifies a LPTSTR lpDIB object(Value).
	LPTSTR FOFindDIBBits(LPTSTR lpDIB);

	// Draw dib.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw D I B, Draws current object to the specify device.
	// Parameters:
	//		hDIB---D I B, Specifies a HANDLE hDIB object(Value).
	void DrawDIB(HANDLE hDIB);

};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOPreviewDC -- preview dc.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPreviewDC class derived from CDC
//      F O Preview D C
//===========================================================================

class FO_EXT_CLASS CFOPreviewDC : public CDC
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPreviewDC---F O Preview D C, Specifies a E-XD++ CFOPreviewDC object (Value).
   DECLARE_DYNAMIC(CFOPreviewDC);  
// Constructors
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Preview D C, Constructs a CFOPreviewDC object.
	//		Returns A  value (Object).
    CFOPreviewDC(); 
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPreviewDC object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		size---Specifies A CSize type value.  
	//		*pBitmap---*pBitmap, A pointer to the CFOPreviewBitmap  or NULL if the call failed.
	// Create a new dc.
    void Create(CSize size,CFOPreviewBitmap *pBitmap);

// Implementation
public:

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Preview D C, Destructor of class CFOPreviewDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPreviewDC();

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
    virtual void Dump(CDumpContext& dc) const;
#endif

	// Attributes
public:
    
	// Save bitmap.
 
	// Old Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
    CBitmap          *pOldBitmap;

};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOBoxMemDC -- memory box dc.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOBoxMemDC class derived from CDC
//      F O Box Memory D C
//===========================================================================

class FO_EXT_CLASS CFOBoxMemDC : public CDC  
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Box Memory D C, Constructs a CFOBoxMemDC object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pdcInput---pdcInput, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	CFOBoxMemDC( CDC* pdcInput,CRect rcPaint);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Box Memory D C, Destructor of class CFOBoxMemDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBoxMemDC();

protected:

	// Bitmap.
 
	// The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap		m_bitmap;

	// Save dc pointer.
 
	// Save D C, This member maintains a pointer to the object CDC.  
	CDC*		m_pSaveDC;

	// Old bitmap pointer.
 
	// Old Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap *	m_pOldBitmap;

	// Paint rect.
 
	// Area, This member sets a CRect value.  
	CRect		m_rcArea;

	// Save view port origin.
 
	// Save Vp, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveVp;

	// Save window origin.
 
	// Save Window, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptSaveWindow;

	// Save view port size.
 
	// Save Vp, This member sets a CSize value.  
	CSize		m_szSaveVp;

	// Save window size.
 
	// Save Window, This member sets a CSize value.  
	CSize		m_szSaveWindow;

};


#endif // !defined(AFX_FOPREVIEWBITMAP_H__28476AB3_29AD_11D6_A52D_525400EA266C__INCLUDED_)
