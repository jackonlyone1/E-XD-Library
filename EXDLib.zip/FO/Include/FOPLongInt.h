//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLONGINT_H__ECA227F5_9927_4942_931B_19A194B5BBE6__INCLUDED_)
#define AFX_FOPLONGINT_H__ECA227F5_9927_4942_931B_19A194B5BBE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLongInt.h : header file
//

/////////////////////////////////////////////////////////////////////////////////
//
// FOPLongInt -- large big int class.
/////////////////////////////////////////////////////////////////////////////////

#define MAX_DIGITS 8
 
//===========================================================================
// Summary:
//      To use a FOPLongInt object, just call the constructor.
//      O P Long Int
//===========================================================================

class FO_EXT_CLASS FOPLongInt
{
public:

	// Long type value.
 
	// Value, Specify a A 32-bit signed integer.  
	long			m_nVal;
 
	// Num[ M A X_ D I G I T S], This member specify unsigned short object.  
	unsigned short	m_naNum[MAX_DIGITS];

	// Length of the value.
	BYTE			m_nLength	: 5;
	BOOL			m_bIsNeg : 1,
					m_bIsBig : 1,
					m_bIsSet : 1;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).
	FOPLongInt();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies a short nVal object(Value).
	FOPLongInt(short nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit long signed integer.
	FOPLongInt(long nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies A integer value.
	FOPLongInt(int nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies a double nVal object(Value).
	FOPLongInt(double nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies a USHORT nVal object(Value).
	FOPLongInt(USHORT nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit LONG signed integer.
	FOPLongInt(ULONG nVal);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		strString---strString, Specifies A CString type value.
	FOPLongInt(CString& strString);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Long Int, Constructs a FOPLongInt object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aVar---aVar, Specifies a const FOPLongInt& aVar object(Value).
	FOPLongInt(const FOPLongInt& aVar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operator short
	operator		short() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operator long
	operator		long()  const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operator int
	operator		int()   const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operator double
	operator		double() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// S H O R T, .
	//		Returns A operator value (Object).
	// Operator USHORT
	operator		USHORT() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// L O N G, .
	//		Returns A operator value (Object).
	// // Operator ULONG
	operator		ULONG() const;

	// Change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set, Sets a specify value to current class FOPLongInt
	// Parameters:
	//		bSet---bSet, Specifies A Boolean value.
	void Set(BOOL bSet)		{	m_bIsSet = bSet;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Set, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSet() const		{	return m_bIsSet;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Neg, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsNeg() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Zero, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsZero() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is One, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOne() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Long, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLong() const		{	return !m_bIsBig;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Abs, .

	void Abs();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Div Mod, .
	// Parameters:
	//		aDiv---aDiv, Specifies a const FOPLongInt& aDiv object(Value).  
	//		aMod---aMod, Specifies a FOPLongInt& aMod object(Value).
	void DivMod(const FOPLongInt& aDiv, FOPLongInt& aMod);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator  =(const FOPLongInt& value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator +=(const FOPLongInt& value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator -=(const FOPLongInt& value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOPLongInt& operator ,or NULL if the call failed  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator *=(const FOPLongInt& value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator /=(const FOPLongInt& value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		value---Specifies a const FOPLongInt& value object(Value).
	FOPLongInt& operator %=(const FOPLongInt& value);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		nValue---nValue, Specifies a const short    nValue object(Value).
	FOPLongInt& operator  =(const short    nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.
	FOPLongInt& operator  =(const long     nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		nValue---nValue, Specifies A integer value.
	FOPLongInt& operator  =(const int	  nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLongInt& operator value (Object).  
	// Parameters:
	//		nValue---nValue, Specifies a const USHORT   nValue object(Value).
	FOPLongInt& operator  =(const USHORT   nValue);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPLongInt operator value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   FOPLongInt operator +(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPLongInt operator value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   FOPLongInt operator -(const FOPLongInt& value1, const FOPLongInt& value2);
	friend _FOLIB_INLINE   FOPLongInt operator *(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPLongInt operator value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   FOPLongInt operator /(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPLongInt operator value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   FOPLongInt operator %(const FOPLongInt& value1, const FOPLongInt& value2);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend  		BOOL operator==(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator!=(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend  		BOOL operator<(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend  		BOOL operator>(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator<=(const FOPLongInt& value1, const FOPLongInt& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPLongInt& value1 object(Value).  
	//		value2---Specifies a const FOPLongInt& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator>=(const FOPLongInt& value1, const FOPLongInt& value2);
};

_FOLIB_INLINE FOPLongInt operator+(const FOPLongInt& value1, const FOPLongInt& value2)
{
	FOPLongInt aErg(value1);
	aErg += value2;
	return aErg;
}

_FOLIB_INLINE FOPLongInt operator-(const FOPLongInt& value1, const FOPLongInt& value2)
{
	FOPLongInt aErg(value1);
	aErg -= value2;
	return aErg;
}

_FOLIB_INLINE FOPLongInt operator*(const FOPLongInt& value1, const FOPLongInt& value2)
{
	FOPLongInt aErg(value1);
	aErg *= value2;
	return aErg;
}

_FOLIB_INLINE FOPLongInt operator/(const FOPLongInt& value1, const FOPLongInt& value2)
{
	FOPLongInt aErg(value1);
	aErg /= value2;
	return aErg;
}

_FOLIB_INLINE FOPLongInt operator%(const FOPLongInt& value1, const FOPLongInt& value2)
{
	FOPLongInt aErg(value1);
	aErg %= value2;
	return aErg;
}

_FOLIB_INLINE BOOL operator!=(const FOPLongInt& value1, const FOPLongInt& value2)
{
	return !(value1 == value2);
}

_FOLIB_INLINE BOOL operator<=(const FOPLongInt& value1, const FOPLongInt& value2)
{
	return !(value1 > value2);
}

_FOLIB_INLINE BOOL operator>=(const FOPLongInt& value1, const FOPLongInt& value2)
{
	return !(value1 < value2);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLONGINT_H__ECA227F5_9927_4942_931B_19A194B5BBE6__INCLUDED_)
