//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMultiCompsPropAction.h: interface for the CFOMultiCompsPropAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMULTICOMPSPROPACTION_H__F73B5F57_9D2F_11D6_A611_0050BAE30439__INCLUDED_)
#define AFX_FOMULTICOMPSPROPACTION_H__F73B5F57_9D2F_11D6_A611_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOCompsPropAction.h"
#include "FOActionMacro.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOMultiShapePropAction -- action that changed multiple shape's property values one time
 
 
//===========================================================================
// Summary:
//     The CFOMultiShapePropAction class derived from CFOActionMacro
//      F O Multiple Shape Property Action
//===========================================================================

class FO_EXT_CLASS CFOMultiShapePropAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiShapePropAction---F O Multiple Shape Property Action, Specifies a E-XD++ CFOMultiShapePropAction object (Value).
	DECLARE_ACTION(CFOMultiShapePropAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Shape Property Action, Constructs a CFOMultiShapePropAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOMultiShapePropAction(CFODataModel* pModel);
	// Attributes

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Add action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOAction  or NULL if the call failed.
	virtual void AddAction(CFOAction *pAction);

public:

	// Add value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShape(CFODrawShape *pShape,const FO_VALUE &Value,const int &nPropId);



	// Add bool value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Bool, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeBool(CFODrawShape *pShape,const BOOL &bValue,const int &nPropId);

	// Add int value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Int, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeInt(CFODrawShape *pShape,const int &nValue,const int &nPropId);

	// Add uint value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Uint, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeUint(CFODrawShape *pShape,const UINT &nValue,const int &nPropId);

	// Add string value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape String, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeString(CFODrawShape *pShape,const CString &strValue,const int &nPropId);

	// Add float value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Float, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeFloat(CFODrawShape *pShape,const float &fValue,const int &nPropId);

	// Add double value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Double, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeDouble(CFODrawShape *pShape,const double &dValue,const int &nPropId);

	// Add dword value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape D Word, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeDWord(CFODrawShape *pShape,const DWORD &dwValue,const int &nPropId);

	// Add date time value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Date Time, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeDateTime(CFODrawShape *pShape,const COleDateTime &dtValue,const int &nPropId);

	// Add color value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Color, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapeColor(CFODrawShape *pShape,const COLORREF &crValue,const int &nPropId);


	// Add value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapes(CFODrawShapeList &list,const FO_VALUE &Value,const int &nPropId);


	// Add bool value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Bool, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesBool(CFODrawShapeList &list,const BOOL &bValue,const int &nPropId);

	// Add int value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Int, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesInt(CFODrawShapeList &list,const int &nValue,const int &nPropId);

	// Add uint value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Uint, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesUint(CFODrawShapeList &list,const UINT &nValue,const int &nPropId);

	// Add string value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes String, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesString(CFODrawShapeList &list,const CString &strValue,const int &nPropId);

	// Add float value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Float, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesFloat(CFODrawShapeList &list,const float &fValue,const int &nPropId);

	// Add double value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Double, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDouble(CFODrawShapeList &list,const double &dValue,const int &nPropId);

	// Add dword value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes D Word, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDWord(CFODrawShapeList &list,const DWORD &dwValue,const int &nPropId);

	// Add date time value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Date Time, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDateTime(CFODrawShapeList &list,const COleDateTime &dtValue,const int &nPropId);

	// Add color value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Color, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesColor(CFODrawShapeList &list,const COLORREF &crValue,const int &nPropId);

public:
	// Add value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapes(CFODrawShapeSet &list,const FO_VALUE &Value,const int &nPropId);


	// Add bool value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Bool, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesBool(CFODrawShapeSet &list,const BOOL &bValue,const int &nPropId);

	// Add int value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Int, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesInt(CFODrawShapeSet &list,const int &nValue,const int &nPropId);

	// Add uint value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Uint, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesUint(CFODrawShapeSet &list,const UINT &nValue,const int &nPropId);

	// Add string value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes String, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesString(CFODrawShapeSet &list,const CString &strValue,const int &nPropId);

	// Add float value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Float, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesFloat(CFODrawShapeSet &list,const float &fValue,const int &nPropId);

	// Add double value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Double, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDouble(CFODrawShapeSet &list,const double &dValue,const int &nPropId);

	// Add dword value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes D Word, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDWord(CFODrawShapeSet &list,const DWORD &dwValue,const int &nPropId);

	// Add date time value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Date Time, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesDateTime(CFODrawShapeSet &list,const COleDateTime &dtValue,const int &nPropId);

	// Add color value for undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes Color, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual void AddShapesColor(CFODrawShapeSet &list,const COLORREF &crValue,const int &nPropId);


	// Attributes
protected:

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

     // a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFX_FOMULTICOMPSPROPACTION_H__F73B5F57_9D2F_11D6_A611_0050BAE30439__INCLUDED_)
