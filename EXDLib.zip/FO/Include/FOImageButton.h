//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEBUTTON_H__38B479A4_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
#define AFX_FOIMAGEBUTTON_H__38B479A4_D0E7_11D6_A665_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageButton window

 
//===========================================================================
// Summary:
//     The CFOImageButton class derived from CButton
//      F O Image Button
//===========================================================================

class FO_EXT_CLASS CFOImageButton : public CButton
{
// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Button, Constructs a CFOImageButton object.
	//		Returns A  value (Object).
	CFOImageButton();

// Attributes
public:
	enum ImageAlignment
	{
		beLeft,		// Show image left
		beRight,    // Show image right
		beTop,      // Show image top
		beBottom,	// Show image bottom
		beCenter	// Show image center
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOImageButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new control.
	virtual BOOL Create(
		// Button caption.
		LPCTSTR lpszCaption, 
		// Button style.
		DWORD dwStyle,
		// Rectangle of button.
		const CRect& rc,
		// Pointer of parent wnd.
		CWnd* pParent,
		// Control ID.
		UINT nID
		);

	// Pre create control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create , Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCreateControl();

	// Redraw the entire window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcLayout();

	// Sub class the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subclass , .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rWnd---rWnd, Specifies a CWnd& rWnd object(Value).
	virtual BOOL SubclassControl(CWnd& rWnd);
	
	// Sub class the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subclass , .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL SubclassControl(UINT nID, CWnd* pParent);

	// Calc text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOImageButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,CRect rcBox,CStringArray& arLines);
protected:
	virtual void PreSubclassWindow();
public:

	// Get format type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Format Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetDrawFormatType();

	// Is mouse on button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse On Button, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMouseOnButton();

	// Set alignment type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		align---Specifies a ImageAlignment align object(Value).
	void SetAlignment(ImageAlignment align);

	// Get text horz alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Horizontal Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetTextHorzAlignment() const;

	// Set text horz alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetTextHorzAlignment(const UINT &nT);

	// Get text vert alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Vertical Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetTextVertAlignment() const;

	// Set text vert alignment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Vertical Alignment, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetTextVertAlignment(const UINT &nT);

	// Get  back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetBkColor() const;

	// Set back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void SetBkColor(const COLORREF &crBkColor);

	// Define for font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetFaceName() const;

	// Set font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void SetFaceName(LPCTSTR lpszFaceName);

	// Get font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int GetPointSize() const;

	// Set font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int GetHeight() const;

	// Set font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetColor() const;

	// Set font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetColor(const COLORREF &crColor);

	// Is font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int GetWeight() const;

	// Set font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void SetWeight(const int &nWeight);

	// Is font italic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetItalic() const;

	// Set font italic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void SetItalic(const BOOL &bItalic);

	// Is font underline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetUnderline() const;

	// Set font underline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void SetUnderline(const BOOL &bUnderline);

	// Is font strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetStrikeout() const;

	// Set font strikeout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void SetStrikeout(const BOOL &bStrikeout);

	// Is button with cool look.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Cool Look, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCoolLook() const;
	
	// Set button with cool look
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cool Look, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&bF---&bF, Specifies A Boolean value.
	void SetCoolLook(const BOOL &bF);

	// Is It MultiLine
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMultiLine() const;

	// Set MultiLine
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Line, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void SetMultiLine(const BOOL &bMulti);
	
	// Cursor button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button Cursor, Sets a specify value to current class CFOImageButton
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		nId---nId, Specifies A integer value.  
	//		bRepaint---bRepaint, Specifies A Boolean value.
	DWORD SetBtnCursor(int nId = NULL, BOOL bRepaint = TRUE);

	// Set use icon handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon, Sets a specify value to current class CFOImageButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		size---Specifies A CSize type value.  
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual BOOL SetIcon(CSize size,HICON hIcon,BOOL bRedraw=TRUE);

	// Set use icon id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon, Sets a specify value to current class CFOImageButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		size---Specifies A CSize type value.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual BOOL SetIcon(CSize size,UINT nID,BOOL bRedraw=TRUE);

	// Change the current bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap, Sets a specify value to current class CFOImageButton
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL SetBitmap(LPCTSTR lpszFileName);
	
	// Change the current bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap, Sets a specify value to current class CFOImageButton
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A integer value.
	BOOL SetBitmap(int nID);

	// Size to content.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size To Content, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SizeToContent();

	// Set tool tip text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tooltip Text, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		nText---nText, Specifies A integer value.  
	//		bActivate---bActivate, Specifies A Boolean value.
	void SetTooltipText(int nText, BOOL bActivate = TRUE);

	// Set tool tip text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tooltip Text, Sets a specify value to current class CFOImageButton
	// Parameters:
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bActivate---bActivate, Specifies A Boolean value.
	void SetTooltipText(LPCTSTR lpszText, BOOL bActivate = TRUE);

	// Activate tooltip.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Tooltip, Activates the specified object.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void ActivateTooltip(BOOL bEnable = TRUE);

	// Init tool tip control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Tool Tip, Call InitToolTip after creating a new object.

	void InitToolTip();

protected:

	//Define for brush.
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOImageButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relase Brush Object, .

	void RelaseBrushObject();

	//Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOImageButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont* CreateFont(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Extend, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFontExt(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relase Font Object, .

	void RelaseFontObject();

protected:
	
	//	Do click button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Button, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoClickButton() {}

	// Size to content.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Size To Content, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		size---Specifies A CSize type value.
	virtual void MakeSizeToContent(CSize& size);

	// Change font to logical.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Logical, .
	//		Returns a int type value.  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int ChangeToLogical(const int nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Chante font to point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Logical To Point, .
	//		Returns a int type value.  
	// Parameters:
	//		nLog---nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int FromLogToPoint(const int nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Calc focus rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Focus Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcButton---rcButton, Specifies A CRect type value.  
	//		rc---Specifies A CRect type value.
	virtual void CalcFocusPosition(CDC *pDC, CRect rcButton, CRect& rc);

	// Get face rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Panel Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcButton---rcButton, Specifies A CRect type value.  
	//		rc---Specifies A CRect type value.  
	//		bSizeToContent---Size To Content, Specifies A Boolean value.
	virtual void CalcPanelRect(CDC *pDC, CRect rcButton, CRect& rc,BOOL bSizeToContent = FALSE);

	// Calc image rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Rects, .
	// Parameters:
	//		rcFace---rcFace, Specifies A CRect type value.  
	//		&rcImage---&rcImage, Specifies A CRect type value.  
	//		&rcText---&rcText, Specifies A CRect type value.
	void LayoutRects(CRect rcFace,CRect &rcImage,CRect &rcText);

	// Calc text extent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Text Extent, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual CSize CalcTextExtent(CDC *pDC, CRect rcPos, CString strCaption);

	// Override to draw a custom button face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		uState---uState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bDisable---bDisable, Specifies A Boolean value.
	virtual void OnDrawFace(CDC *pDC, const CRect& rc, UINT uState,BOOL bDisable);

	// Override to draw a custom button focus state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.
	virtual void OnDrawFocus(CDC *pDC, const CRect& rc);

	// Override to draw a custom button frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Frame, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		uState---uState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnDrawFrame(CDC *pDC, CRect& rc, UINT uState);

	// Draw disable state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Disable, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual void OnDrawDisable(CDC* pDC, int nImageWidth, int nImageHeight);

public:

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOImageButton)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Default Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Button, Destructor of class CFOImageButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOImageButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Capture Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	afx_msg void OnCaptureChanged(CWnd *pWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont* m_pFont;

	// Horz text alignment.
 
	// Text Horizontal Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT    m_nTextHorzAlignment;

	// Vert text alignment.
 
	// Text Vertical Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT    m_nTextVertAlignment;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBkColor;

	// Cached GDI brush. 
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush* m_pBrush;

	// Border size.
 
	// Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_cxBorderSize;

	// Face position.
 
	// Face, This member sets a CRect value.  
	CRect m_rcFace;

	// Multi lines
 
	// Multiple Line, This member sets TRUE if it is right.  
	BOOL			m_bMultiLine;

	// Handle to cursor
 
	// Cursor, This member specify HCURSOR object.  
	HCURSOR		m_hCursor;

	// Tooltip
 
	// Tool Tip, This member specify CToolTipCtrl object.  
	CToolTipCtrl m_ToolTip;

	// Resource name for bitmap.
 
	// Bitmap File Name, This member sets A 32-bit pointer to a constant character string that is portable for Unicode and DBCS.  
	LPCTSTR m_lpszBmpFileName;

	// The bitmap for the button.
 
	// Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap m_Bitmap;

	// Window rectangle for the bitmap
 
	// Rectangle, This member sets a CRect value.  
	CRect m_bmpRect;
	
	// Window rectangle for the text
 
	// Rectangle, This member sets a CRect value.  
	CRect m_textRect;
	
	// The alignment mode.
 
	// This member specify ImageAlignment object.  
	ImageAlignment m_alignment;

	// Is Flat or not
 
	// Cool, This member sets TRUE if it is right.  
	BOOL m_bCool;

	// Is window version
 
	// Win Ver4, This member sets TRUE if it is right.  
	BOOL m_bWinVer4;

	// Mouse over state.
 
	// Mouse Over, This member sets TRUE if it is right.  
	BOOL m_bMouseOver;

	// Mouse push state.
 
	// Pushed, This member sets TRUE if it is right.  
	BOOL m_bPushed;
	
	// Mouse push tracking state.
 
	// Push Tracking, This member sets TRUE if it is right.  
	BOOL m_bPushTracking;

	// User icon.
 
	// Use Icon, This member sets TRUE if it is right.  
	BOOL m_bUseIcon;

	// Icon handle.
 
	// Icon, This member specify HICON object.  
	HICON m_hIcon;

	// Image size.
 
	// Image, This member sets a CSize value.  
	CSize m_szImage;

};

_FOLIB_INLINE	BOOL CFOImageButton::IsCoolLook() const						
{ 
	return m_bCool; 
}

_FOLIB_INLINE	void CFOImageButton::SetCoolLook(const BOOL &bF)               
{ 
	m_bCool = bF; 
}

_FOLIB_INLINE	BOOL CFOImageButton::IsMultiLine() const
{
	return m_bMultiLine;
}

_FOLIB_INLINE	void CFOImageButton::SetMultiLine(const BOOL &bMulti)
{
	m_bMultiLine = bMulti;
}

/////////////////////////////////////////////////////////////////////////////
_FOLIB_INLINE	UINT CFOImageButton::GetTextHorzAlignment()	const
{ 
	return m_nTextHorzAlignment;
}

_FOLIB_INLINE void CFOImageButton::SetTextHorzAlignment(const UINT &nT)	
{ 
	m_nTextHorzAlignment = nT;
}

_FOLIB_INLINE	UINT CFOImageButton::GetTextVertAlignment()	const
{ 
	return m_nTextVertAlignment;
}

_FOLIB_INLINE void CFOImageButton::SetTextVertAlignment(const UINT &nT)	
{ 
	m_nTextVertAlignment = nT;
}

_FOLIB_INLINE	COLORREF CFOImageButton::GetBkColor() const					
{ 
	return m_crBkColor; 
}

_FOLIB_INLINE	void CFOImageButton::SetBkColor(const COLORREF &crBkColor)	
{	
	RelaseBrushObject();
	m_crBkColor = crBkColor;
}

_FOLIB_INLINE CString CFOImageButton::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOImageButton::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOImageButton::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOImageButton::GetColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOImageButton::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOImageButton::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOImageButton::SetItalic(const BOOL &bItalic)
{
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOImageButton::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOImageButton::SetUnderline(const BOOL &bUnderline)
{
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOImageButton::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOImageButton::SetStrikeout(const BOOL &bStrikeout)
{
	m_bStrikeout = bStrikeout;
}
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEBUTTON_H__38B479A4_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
