//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPCHARTSHAPE_H__2A371554_4E04_4832_BA25_8FAB5AEE6F51__INCLUDED_)
#define FO_FOPCHARTSHAPE_H__2A371554_4E04_4832_BA25_8FAB5AEE6F51__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOPChartData.h"
#include "FOCompositeShape.h"
#include <float.h>
#include "FOPSimplePolygon.h"

#define FOP_AXIS_POS_A -1		//Top or Right
#define FOP_AXIS_POS_B -2		//Bottom or Left

#define FOP_AXIS_MARK_BOTH   3
#define FOP_AXIS_MARK_OUTER  2
#define FOP_AXIS_MARK_INNER  1
#define FOP_AXIS_MARK_NONE   0
#define FOP_AXIS_MARK_ASMAIN 4

#define FOP_AXIS_AXIS_UNKNOWN 0
#define FOP_AXIS_AXIS_X		1
#define FOP_AXIS_AXIS_Y		2
#define FOP_AXIS_AXIS_Z		3
#define FOP_AXIS_AXIS_B		4	// secondary Y axis
#define FOP_AXIS_AXIS_A		5	// secondary X axis

class CFOPChartShape;

#define FOP_STACK_NONE      0
#define FOP_STACK_MINMAX    1
#define FOP_STACK_OVERLAP   2

#define FOP_CHART_AXIS_X    0
#define FOP_CHART_AXIS_Y    1
#define FOP_CHART_AXIS_Z    2

#define FOP_LINE_POINT_COUNT 9
#define FOP_ROW_COLOR_COUNT 12

#define        FOP_CHART_ANY                        0
#define        FOP_CHART_TEXT                       1
#define        FOP_CHART_AREA                       2
#define        FOP_CHART_LINE                       3
#define        FOP_CHART_DIAGRAM_AREA              10
#define        FOP_CHART_TITLE_MAIN                11
#define        FOP_CHART_TITLE_SUB                 12
#define        FOP_CHART_DIAGRAM                   13
#define        FOP_CHART_DIAGRAM_WALL              14
#define        FOP_CHART_DIAGRAM_FLOOR             15
#define        FOP_CHART_DIAGRAM_TITLE_X_AXIS      16
#define        FOP_CHART_DIAGRAM_TITLE_Y_AXIS      17
#define        FOP_CHART_DIAGRAM_TITLE_Z_AXIS      18
#define        FOP_CHART_DIAGRAM_X_AXIS            19
#define        FOP_CHART_DIAGRAM_Y_AXIS            20
#define        FOP_CHART_DIAGRAM_Z_AXIS            21
#define        FOP_CHART_DIAGRAM_X_GRID_MAIN       22
#define        FOP_CHART_DIAGRAM_Y_GRID_MAIN       23
#define        FOP_CHART_DIAGRAM_Z_GRID_MAIN       24
#define        FOP_CHART_DIAGRAM_X_GRID_HELP       25
#define        FOP_CHART_DIAGRAM_Y_GRID_HELP       26
#define        FOP_CHART_DIAGRAM_Z_GRID_HELP       27
#define        FOP_CHART_DIAGRAM_ROWGROUP          28
#define        FOP_CHART_DIAGRAM_ROWS              29
#define        FOP_CHART_DIAGRAM_ROWSLINE          30
#define        FOP_CHART_DIAGRAM_DATA              31
#define        FOP_CHART_DIAGRAM_DESCRGROUP        32
#define        FOP_CHART_DIAGRAM_DESCR_ROW         33
#define        FOP_CHART_LEGEND                    34
#define        FOP_CHART_LEGEND_BACK               35
#define        FOP_CHART_LEGEND_SYMBOL_ROW         36
#define        FOP_CHART_LEGEND_SYMBOL_COL         37
#define        FOP_CHART_DIAGRAM_DESCR_COL         38
#define        FOP_CHART_DIAGRAM_DESCR_SYMBOL      39


#define        FOP_CHART_DIAGRAM_A_AXIS            65
#define        FOP_CHART_DIAGRAM_B_AXIS            66
#define        FOP_CHART_DIAGRAM_C_AXIS            67
#define        FOP_CHART_DIAGRAM_TITLE_A_AXIS      68
#define        FOP_CHART_DIAGRAM_TITLE_B_AXIS      69
#define        FOP_CHART_DIAGRAM_TITLE_C_AXIS      70

#define        FOP_CHART_DIAGRAM_X_AXIS_GROUP      38
#define        FOP_CHART_DIAGRAM_Y_AXIS_GROUP      39
#define        FOP_CHART_DIAGRAM_Z_AXIS_GROUP      40

#define        FOP_CHART_DIAGRAM_NET               41
#define        FOP_CHART_DIAGRAM_AVERAGEVALUE      42
#define        FOP_CHART_DIAGRAM_ERROR             43
#define        FOP_CHART_DIAGRAM_REGRESSION        45
#define        FOP_CHART_DIAGRAM_STACKEDGROUP      46
#define        FOP_CHART_DIAGRAM_STATISTICS_GROUP  48
#define        FOP_CHART_DIAGRAM_X_GRID_MAIN_GROUP 49
#define        FOP_CHART_DIAGRAM_Y_GRID_MAIN_GROUP 50
#define        FOP_CHART_DIAGRAM_Z_GRID_MAIN_GROUP 51
#define        FOP_CHART_DIAGRAM_X_GRID_HELP_GROUP 52
#define        FOP_CHART_DIAGRAM_Y_GRID_HELP_GROUP 53
#define        FOP_CHART_DIAGRAM_Z_GRID_HELP_GROUP 54
#define        FOP_CHART_DIAGRAM_SPECIAL_GROUP     55

#define			FOP_CHART_DIAGRAM_STOCKLINE		   60
#define			FOP_CHART_DIAGRAM_STOCKRECT		   61
#define			FOP_CHART_DIAGRAM_STOCKLINE_GROUP  62
#define			FOP_CHART_DIAGRAM_STOCKLOSS_GROUP  63
#define			FOP_CHART_DIAGRAM_STOCKPLUS_GROUP  64

#define FOP_DATALOG_ANY							   -1

enum FOPChartRegress
{
	FOP_CHREGRESS_NONE,
		FOP_CHREGRESS_LINEAR,
		FOP_CHREGRESS_LOG,
		FOP_CHREGRESS_EXP,
		FOP_CHREGRESS_POWER
};

// Chart text orient.
enum FOPChartTextOrient
{
	FOP_CHTXTORIENT_AUTOMATIC,
		FOP_CHTXTORIENT_STANDARD,
		FOP_CHTXTORIENT_BOTTOMTOP,
		FOP_CHTXTORIENT_STACKED,
		FOP_CHTXTORIENT_TOPBOTTOM
};

// Chart position adjust.
enum FOPChartAdjust
{
	FOP_CHADJUST_TOP_LEFT,
		FOP_CHADJUST_TOP_RIGHT,
		FOP_CHADJUST_TOP_CENTER,
		FOP_CHADJUST_CENTER_LEFT,
		FOP_CHADJUST_CENTER_RIGHT,
		FOP_CHADJUST_CENTER_CENTER,
		FOP_CHADJUST_BOTTOM_LEFT,
		FOP_CHADJUST_BOTTOM_CENTER,
		FOP_CHADJUST_BOTTOM_RIGHT
};

// Chart data.
enum FOPChartDataDescr
{
	FOP_CHDESCR_NONE,
		FOP_CHDESCR_VALUE,
		FOP_CHDESCR_PERCENT,
		FOP_CHDESCR_TEXT,
		FOP_CHDESCR_TEXTANDPERCENT,
		FOP_CHDESCR_NUMFORMAT_PERCENT,
		FOP_CHDESCR_NUMFORMAT_VALUE,
		FOP_CHDESCR_TEXTANDVALUE
};

// Chart text order.
enum FOPChartTextOrder
{
	FOP_CHTXTORDER_SIDEBYSIDE,
		FOP_CHTXTORDER_UPDOWN,
		FOP_CHTXTORDER_DOWNUP,
		FOP_CHTXTORDER_AUTO
};

//////////////////////////////////////////////
// CFOPDataLogBook -- chart data manager.

 
//===========================================================================
// Summary:
//      To use a CFOPDataLogBook object, just call the constructor.
//      F O P Data Logical Book
//===========================================================================

class FO_EXT_CLASS CFOPDataLogBook
{
protected:
	// Row of chart.
 
	// Rows, Specify a A 32-bit signed integer.  
	long		m_nRows;

	// Columns of chart
 
	// Cols, Specify a A 32-bit signed integer.  
	long		m_nCols;

	// Columns that initicaled.
 
	// Cols Initial, Specify a A 32-bit signed integer.  
	long		m_nColsInitial;

	// Rows that initicaled.
 
	// Rows Initial, Specify a A 32-bit signed integer.  
	long		m_nRowsInitial;
	
	// Rows that added.
 
	// Rows Added, Specify a A 32-bit signed integer.  
	long		m_nRowsAdded;

	// Columns that added.
 
	// Cols Added, Specify a A 32-bit signed integer.  
	long		m_nColsAdded;

	// Rows left.
 
	// Rows Left, Specify a A 32-bit signed integer.  
	long		m_nRowsLeft;

	// Columns left
 
	// Cols Left, Specify a A 32-bit signed integer.  
	long		m_nColsLeft;
	
	// Valid or not.
 
	// Valid, This member sets TRUE if it is right.  
	BOOL		m_bValid;

	// Row changed or not.
 
	// Row Changed, This member sets TRUE if it is right.  
	BOOL		m_bRowChanged;

	// Columns changed or not.
 
	// Column Changed, This member sets TRUE if it is right.  
	BOOL		m_bColChanged;

	// Get column or not.
 
	// Get Column, This member sets TRUE if it is right.  
	BOOL		m_bGetCol;
	
	// Row coordinates
 
	// Row Coordinates, This member maintains a pointer to the object long.  
	long*		m_pRowCoordinates;

	// Column coordinates
 
	// Column Coordinates, This member maintains a pointer to the object long.  
	long*		m_pColCoordinates;
	
	// Dummy.
 
	// Specify a A 32-bit signed integer.  
	long		dummy;
	
	// Increase row count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Increase Row Count, .

	void IncreaseRowCount();

	// Increase column count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Increase Column Count, .

	void IncreaseColCount();
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Data Logical Book, Constructs a CFOPDataLogBook object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aChartData---Chart Data, Specifies a const CFOPChartData& aChartData object(Value).
	CFOPDataLogBook(const CFOPChartData& aChartData);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Data Logical Book, Destructor of class CFOPDataLogBook
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDataLogBook();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOPDataLogBook object.

	// Reset
	void Reset();
	
	// Is valid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValid() const;
	
	// Is changed or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Changed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsChanged()    const;

	// Is row changed or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Row Changed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsRowChanged() const;

	// Is columns changed or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Column Changed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsColChanged() const;
	
	// Set valid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Valid, Sets a specify value to current class CFOPDataLogBook
	// Parameters:
	//		bValid---bValid, Specifies A Boolean value.
	void SetValid(BOOL bValid)  { m_bValid = bValid;}
	
	// Obtain the count of columns.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetColCount()          {return m_nCols;}

	// Obtain the count of row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetRowCount()          {return m_nRows;}
	
	// Obtain columns that are added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cols Added, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetColsAdded()         {return m_nColsAdded;}

	// Obtain the rows that are added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rows Added, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetRowsAdded()         {return m_nRowsAdded;}
	
	// Obtain the columsn that initical.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cols Initial, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetColsInitial()       {return m_nColsInitial;}

	// Obtain the rows that initical.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rows Initial, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetRowsInitial()       {return m_nRowsInitial;}
	
	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetCount()             {if(m_bGetCol)return m_nCols;return m_nRows;}

	// Obtain added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Added, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetAdded()             {if(m_bGetCol)return m_nColsAdded;return m_nRowsAdded;}

	// Obtain initicaled.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Initial, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetInitial()           {if(m_bGetCol)return m_nColsInitial;return m_nRowsInitial;}
	
	// Delete row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Row, Deletes the given object.
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void DeleteRow(const long nRow);

	// Delete column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Column, Deletes the given object.
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void DeleteCol(const long nCol);

	// Insert row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Row, Inserts a child object at the given index..
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void InsertRow(const long nRow);

	// Insert column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Column, Inserts a child object at the given index..
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void InsertCol(const long nCol);

	// swap columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Cols, .
	// Parameters:
	//		nCol1---nCol1, Specifies A 32-bit long signed integer.  
	//		nCol2---nCol2, Specifies A 32-bit long signed integer.
	void SwapCols(long nCol1,long nCol2);

	// swap rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Rows, .
	// Parameters:
	//		nRow1---nRow1, Specifies A 32-bit long signed integer.  
	//		nRow2---nRow2, Specifies A 32-bit long signed integer.
	void SwapRows(long nRow1,long nRow2);
	
	// Change column's mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Mode, Sets a specify value to current class CFOPDataLogBook
	// Parameters:
	//		bCol---bCol, Specifies A Boolean value.
	void SetColMode(const BOOL bCol){m_bGetCol =  bCol;};

	// Change row's mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Mode, Sets a specify value to current class CFOPDataLogBook
	// Parameters:
	//		bCol---bCol, Specifies A Boolean value.
	void SetRowMode(const BOOL bCol){m_bGetCol = !bCol;};
	
	// Obtain the id of column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Id, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	long GetColId(const long nCol) const
	{if(nCol<m_nCols)return m_pColCoordinates[nCol];return FOP_DATALOG_ANY;}
	
	// Obtain the row id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Id, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long GetRowId(const long nRow) const
	{if(nRow<m_nRows)return m_pRowCoordinates[nRow];return FOP_DATALOG_ANY;}
	
	// Obtain id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Id, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	long GetId(const long n)
	{
		if(m_bGetCol)return GetColId(n);
		return GetRowId(n);
	}
};

////////////////////////////////////////////////////
// CFOPChartAxis -- chart axis define class.

 
//===========================================================================
// Summary:
//      To use a CFOPChartAxis object, just call the constructor.
//      F O P Chart Axis
//===========================================================================

class FO_EXT_CLASS CFOPChartAxis
{
protected:
	// with inner position or not
 
	// Inner Position, This member sets TRUE if it is right.  
	BOOL				m_bInnerPos;

	// Inner position
 
	// Inner Position, Specify a A 32-bit signed integer.  
	long				m_nInnerPos;

	// with column text or not
 
	// Column Text, This member sets TRUE if it is right.  
	BOOL				m_bColText;

	// With center text or not.
 
	// Center Text, This member sets TRUE if it is right.  
	BOOL				m_bCenterText;
	
	// Maximize text width.
 
	// Maximize Text Width, Specify a A 32-bit signed integer.  
	long				m_nMaxTextWidth;
	
	// Alternate id
 
	// Alternate Id, Specify a A 32-bit signed integer.  
	long				m_nAlternateId;

	// Alternative id used.
 
	// Alternativ Id Used, Specify a A 32-bit signed integer.  
	long				m_bAlternativIdUsed;
	
	// Column percent
 
	// Percent Column, This member sets TRUE if it is right.  
	BOOL				m_bPercentCol;

	// text overlap.
 
	// Text Overlap, This member sets TRUE if it is right.  
	BOOL				m_bTextOverlap;

	// Visible or not.
 
	// Visible, This member sets TRUE if it is right.  
	BOOL				m_bVisible;

	// total value.
 
	// Total, This member maintains a pointer to the object double.  
	double				*m_pTotal;

	// total size.
 
	// Total Size, Specify a A 32-bit signed integer.  
	long 				m_nTotalSize;

	// total actual.
 
	// Total Actual, This member sets TRUE if it is right.  
	BOOL				m_bTotalActual;

	// total alloc
 
	// Total Alloc, This member sets TRUE if it is right.  
	BOOL				m_bTotalAlloc;

	// column stack.
 
	// Column Stack, This member maintains a pointer to the object double.  
	double	 			*m_pColStack;

	// with column stack
 
	// Column Stack O K, This member sets TRUE if it is right.  
	BOOL				m_bColStackOK;
	
	// id
 
	// U Id, Specify a A 32-bit signed integer.  
	long				m_nUId;

	// with description showing or not.
 
	// Show Descr, This member sets TRUE if it is right.  
	BOOL				m_bShowDescr;
	
	// Axis list
 
	// Axis List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList*	m_pAxisList;

	// axis object.
 
	// Axis Object, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape*	m_pAxisObj;
	
	// Main grid list.
 
	// Main Grid List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList*	m_pMainGridList;

	// help grid list
 
	// Help Grid List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList*	m_pHelpGridList;

	// row ids
	CArray<int,int>		arRowIds;
	
	// Main grid id
 
	// Id Main Grid, Specify a A 32-bit signed integer.  
	long				m_nIdMainGrid;

	// Help grid id
 
	// Id Help Grid, Specify a A 32-bit signed integer.  
	long				m_nIdHelpGrid;
	
	// rectangle A.
 
	// Rectangle A, This member specify FOPRect object.  
	FOPRect				m_rcRectA;

	// rectangle B.
 
	// Rectangle B, This member specify FOPRect object.  
	FOPRect				m_rcRectB;
	
	// Total of ticks.
 
	// Ticks, Specify a A 32-bit signed integer.  
	long				m_nTicks;

	// total of help ticks.
 
	// Help Ticks, Specify a A 32-bit signed integer.  
	long				m_nHelpTicks;

	// the length of tick.
 
	// Tick Len, Specify a A 32-bit signed integer.  
	long				m_nTickLen;

	// the length of help tick
 
	// Help Tick Len, Specify a A 32-bit signed integer.  
	long				m_nHelpTickLen;

	// total position
 
	// Position, Specify a A 32-bit signed integer.  
	long				m_nPos;

	// text position.
 
	// Text Position, Specify a A 32-bit signed integer.  
	long				m_nTextPos;

	// with secondary or not.
 
	// Secondary, This member sets TRUE if it is right.  
	BOOL				m_bSecondary;
	
	// with step value or not.
 
	// Step Value, This member sets TRUE if it is right.  
	BOOL				m_bStepValue;

	// value down or not
 
	// Value Down, This member sets TRUE if it is right.  
	BOOL				m_bValueDown;
	
	// Maximize text size.
 
	// Maximize Text Size, This member specify FOPSize object.  
	FOPSize				m_szMaxTextSize;

	// stack mode or not.
 
	// Stack Mode, Specify a A 32-bit signed integer.  
	long				m_eStackMode;
	
	// Id
 
	// Id, Specify a A 32-bit signed integer.  
	long				m_nId;

	// Flip xy
 
	// Flipped X Y, This member sets TRUE if it is right.  
	BOOL				m_bFlippedXY;

	// position
 
	// Position, Specify a A 32-bit signed integer.  
	long				m_nPosition;
	
	// With radial or not
 
	// Radial, This member sets TRUE if it is right.  
	BOOL				m_bRadial;

	// With area or not.
 
	// Area, This member specify FOPRect object.  
	FOPRect				m_aArea;

	// With reference area or not.
 
	// Reference Area, This member specify FOPRect object.  
	FOPRect				m_aRefArea;

	// With percent or not.
 
	// Percent, This member sets TRUE if it is right.  
	BOOL				m_bPercent;
	
	// Pointer of chart.
 
	// Chart, This member maintains a pointer to the object CFOPChartShape.  
	CFOPChartShape*		m_pChart;
	
	// Minimize
 
	// Minimize, This member specify double object.  
	double				m_fMin;

	// Maximize
 
	// Maximize, This member specify double object.  
	double				m_fMax;

	// Step
 
	// Step, This member specify double object.  
	double				m_fStep;

	// Help step
 
	// Step Help, This member specify double object.  
	double				m_fStepHelp;

	// origin
 
	// Origin, This member specify double object.  
	double				m_fOrigin;
	
	// data bottom.
 
	// Data Bottom, This member specify double object.  
	double				m_fDataBottom;

	// top data.
 
	// Data Top, This member specify double object.  
	double				m_fDataTop;
	
	// with automatic minimize.
 
	// Automatic Minimize, This member sets TRUE if it is right.  
	BOOL				m_bAutoMin;

	// with automatic maximize
 
	// Automatic Maximize, This member sets TRUE if it is right.  
	BOOL				m_bAutoMax;

	// With automatic origin.
 
	// Automatic Origin, This member sets TRUE if it is right.  
	BOOL				m_bAutoOrigin;
	
	// With automatic steps.
 
	// Automatic Step, This member sets TRUE if it is right.  
	BOOL				m_bAutoStep;

	// With automatic help step.
 
	// Automatic Step Help, This member sets TRUE if it is right.  
	BOOL				m_bAutoStepHelp;
	
	// With logarithm
 
	// Logarithm, This member sets TRUE if it is right.  
	BOOL				m_bLogarithm;
	
	// Text orient.
 
	// Text Orient, This member specify FOPChartTextOrient object.  
	FOPChartTextOrient	m_eTextOrient;

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Axis, Constructs a CFOPChartAxis object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFOPChartShape or NULL if the call failed.  
	//		nId---nId, Specifies A 32-bit long signed integer.  
	//		nUid---nUid, Specifies A 32-bit long signed integer.
	CFOPChartAxis(CFOPChartShape* pModel,long nId,long nUid);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Chart Axis, Destructor of class CFOPChartAxis
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPChartAxis();
		
protected:

	// resize total.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Total, .
	// Parameters:
	//		nSize---nSize, Specifies A 32-bit long signed integer.
	void				ResizeTotal(long nSize);
	
	// create total
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Total, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.

	void				CreateTotal();
	
	// Re calculate text position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Text Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcTextPos();

	// Calculate minimize and maximize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Minimize Maximize Value, .

	void CalcMinMaxValue();

	// Set defaults.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Defaults, Sets a specify value to current class CFOPChartAxis

	void SetDefaults();

	// Update row min and max.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Row Minimize Maximize, Call this member function to update the object.
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.  
	//		bPercent---bPercent, Specifies A Boolean value.  
	//		inout_fMin---inout_fMin, Specifies a double & inout_fMin object(Value).  
	//		inout_fMax---inout_fMax, Specifies a double & inout_fMax object(Value).
	void UpdateRowMinMax(const long nRow,const long nColCnt,const BOOL bPercent,
		double & inout_fMin, double & inout_fMax);
	
	// Obtain length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetLength() const;
	
	// Get row error.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Error, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double GetRowError(long nRow);

	// Is data on axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Data On Axis, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	_FOLIB_INLINE BOOL IsDataOnAxis(long nRow);

	// Initial column stack
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Column Stacking, Call InitColStacking after creating a new object.
	// Parameters:
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.
	void   InitColStacking(long nColCnt);
	
public:
	
	// Obtain the width of description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Descr Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetDescrWidth();

	// Change column's text mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Text Mode, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		bColText---Column Text, Specifies A Boolean value.  
	//		bCenterText---Center Text, Specifies A Boolean value.
	void SetColTextMode(BOOL bColText,BOOL bCenterText)
	{
		m_bColText    = bColText;
		m_bCenterText = bCenterText;
	}
	
	// Insert help tick.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Help Tick, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A 32-bit long signed integer.
	void InsertHelpTick(long nPos)					{ InsertMark(nPos,m_nHelpTickLen,m_nHelpTicks); }

	// With help tick or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Help Ticks, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasHelpTicks()								{ return m_nHelpTicks!=0; }
	
	// Attach data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach If No Own Data, Attaches this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pAxis---pAxis, A pointer to the const CFOPChartAxis or NULL if the call failed.
	BOOL AttachIfNoOwnData(const CFOPChartAxis* pAxis);
	
	// Change percent mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Percent Mode, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		bPercentCol---Percent Column, Specifies A Boolean value.
	void SetPercentMode(BOOL bPercentCol=TRUE)
	{
		if(m_bPercentCol!=bPercentCol)
			m_bTotalActual=FALSE;
		m_bPercentCol=bPercentCol;
	}
	
	// No data look at.
	
	//-----------------------------------------------------------------------
	// Summary:
	// If No Data Look At, .
	// Parameters:
	//		nAlternateAxisId---Alternate Axis Id, Specifies A 32-bit long signed integer.
	void IfNoDataLookAt(long nAlternateAxisId)		{ m_nAlternateId = nAlternateAxisId; }
	
	// Obtain area position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Area, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	const FOPRect& GetArea()						{ return m_aRefArea; }

	// Stack column data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stack Column Data, .
	//		Returns A double value (Object).  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.
	double StackColData(double fData,long nCol,long nColCnt);
	
	// Obtain data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns A _FOLIB_INLINE double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	_FOLIB_INLINE double	   GetData(long nCol,long nRow);

	// Data to percent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Data2 Percent, .
	//		Returns A double value (Object).  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double			   Data2Percent(double fData,long nCol,long nRow);

	// Obtain total.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	double			   GetTotal(long n);
	
	// Is vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Vertical, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsVertical();

	// Is negative.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Negative, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsNegative()								{ return (m_fMax <= 0.0 && m_fMin < 0.0 ); }
	
	// Is visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Visible, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL IsVisible() const
	{
		return m_bVisible;
	}
	
	// Has description or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Description, .
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL HasDescription() const
	{
		return m_bShowDescr && IsVisible();
	}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stack, .
	//		Returns A FOPPair value (Object).  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		bConstrained---bConstrained, Specifies A Boolean value.
	// Stack
	FOPPair Stack(double fData,BOOL bConstrained=TRUE);

	// Initical stack
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Stacking, Call InitStacking after creating a new object.

	void InitStacking()	{ m_fDataBottom=m_fDataTop=0.0; }
	
	// Top/Right Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Upper, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		bConstrained---bConstrained, Specifies A Boolean value.
	long GetUpper(double fData,BOOL bConstrained=TRUE);
	
	// Bottom/Left Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lower, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		bConstrained---bConstrained, Specifies A Boolean value.
	long GetLower(double fData,BOOL bConstrained=TRUE);
	
	// Obtain position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).
	long GetPos(double fData);

	// Obtain position constrain
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position Constrained, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).
	long GetPosConstrained(double fData);

	// Obtain position origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position Origin, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetPosOrigin()								{ return GetPos(m_fOrigin); }

	// Change area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Area, Sets a specify value to current class CFOPChartAxis
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).
	BOOL SetArea(const FOPRect& rRect);

	// Adjust origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Origin, .

	void AdjustOrigin();

	// Is origin in range or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Origin In Range, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOriginInRange() const;
	
	// Is value in range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Value In Range, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_fValue---m_fValue, Specifies a double m_fValue object(Value).
	BOOL IsValueInRange( double m_fValue ) const;
	
	// Number steps main
	
	//-----------------------------------------------------------------------
	// Summary:
	// Number Steps Main, .
	//		Returns A double value (Object).
	double NumStepsMain();
	
	// Obtain maximize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize, Returns the specified value.
	//		Returns A double value (Object).
	double GetMax()		 const		{ return m_fMax; }

	// Obtain minimize value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize, Returns the specified value.
	//		Returns A double value (Object).
	double GetMin()		 const		{ return m_fMin; }

	// Obtain the step value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Step, Returns the specified value.
	//		Returns A double value (Object).
	double GetStep()	 const		{ return m_fStep; }

	// Obtain the origin value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Origin, Returns the specified value.
	//		Returns A double value (Object).
	double GetOrigin()   const		{ return m_fOrigin; }

	// Obtain the help step value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Help Step, Returns the specified value.
	//		Returns A double value (Object).
	double GetHelpStep() const		{ return m_fStepHelp; }

	// Change maximize value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		f---Specifies a double f object(Value).
	void SetMax(double f)			{ m_fMax = f; }

	// Change minimize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimize, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		f---Specifies a double f object(Value).
	void SetMin(double f)			{ m_fMin = f; }

	// Is logarithm
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Logarithm, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLogarithm() const		{ return m_bLogarithm; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialise, Call Initialise after creating a new object.
	// Parameters:
	//		&rRect---&rRect, Specifies a const FOPRect &rRect object(Value).  
	//		bFlippedXY---Flipped X Y, Specifies A Boolean value.  
	//		eStackmode---eStackmode, Specifies A 32-bit long signed integer.  
	//		bPercent---bPercent, Specifies A Boolean value.  
	//		bRadial---bRadial, Specifies A Boolean value.  
	//		bPercentCol---Percent Column, Specifies A Boolean value.
	// Initialise.
	void Initialise(const FOPRect &rRect, BOOL bFlippedXY=FALSE, 
		long eStackmode = FOP_STACK_NONE,BOOL bPercent=FALSE,BOOL bRadial=FALSE,BOOL bPercentCol=TRUE);
	
	// Verify steps.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Verify Steps, .

	void VerifySteps();

	// Calculate step values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Value Steps, .

	void CalcValueSteps();

	// Obtain minimize and maximize from data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Maximize From Data, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetMinMaxFromData();
	
	// Calculate fact value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fact, .
	//		Returns A double value (Object).  
	// Parameters:
	//		m_fValue---m_fValue, Specifies a const double m_fValue object(Value).
	double CalcFact(const double m_fValue) const;

	// Calculate fact origin value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fact Origin, .
	//		Returns A double value (Object).
	double CalcFactOrigin()		{ return CalcFact(m_fOrigin); }
	
	// Insert mark.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Mark, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A 32-bit long signed integer.  
	//		nLen---nLen, Specifies A 32-bit long signed integer.  
	//		nWhichTicks---Which Ticks, Specifies A 32-bit long signed integer.
	void InsertMark(long nPos,long nLen,long nWhichTicks);

	// Obtain number format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Format, Returns the specified value.
	//		Returns a UINT type value.
	UINT32 GetNumFormat()							{ return GetNumFormat( m_bPercent ); }

	// Obtain number format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Format, Returns the specified value.
	//		Returns a UINT type value.  
	// Parameters:
	//		bPercent---bPercent, Specifies A Boolean value.
	UINT32 GetNumFormat(BOOL bPercent);

	// Grid line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Grid Line, .
	// Parameters:
	//		aLine---aLine, Specifies a FOPSimplePolygon& aLine object(Value).  
	//		nPos---nPos, Specifies A 32-bit long signed integer.
	void GridLine(FOPSimplePolygon& aLine,long nPos);
	
	// Show description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Descr, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void ShowDescr(BOOL b);

	// Show axis or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Axis, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void ShowAxis(BOOL b);
	
	// Draw grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Grids, Draws current object to the specify device.

	void DrawGrids();

	// Change main grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Grid, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		pList---pList, A pointer to the CFODrawShapeList or NULL if the call failed.
	void SetMainGrid(CFODrawShapeList* pList);

	// Change help grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Help Grid, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		pList---pList, A pointer to the CFODrawShapeList or NULL if the call failed.
	void SetHelpGrid(CFODrawShapeList* pList);
	
	// Create axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Axis, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A 32-bit long signed integer.
	long CreateAxis();

	// Create axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Axis, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		nPos---nPos, Specifies A 32-bit long signed integer.  
	//		bBorderAxis---Border Axis, Specifies A Boolean value.  
	//		bInnerAxis---Inner Axis, Specifies A Boolean value.
	void CreateAxis(const long nPos,BOOL bBorderAxis,BOOL bInnerAxis);

	// Create axis.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Axis, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		rList---rList, Specifies a E-XD++ CFODrawShapeList& rList object (Value).  
	//		nChObjId---Ch Object Id, Specifies A 32-bit long signed integer.
	void CreateAxis(CFODrawShapeList& rList,long nChObjId);
	
	// Subtract description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subtract Descr Size, .
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect& rRect object(Value).
	void SubtractDescrSize(FOPRect& rRect);

	// Subtract description size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subtract Descr Size_ X, .
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect& rRect object(Value).  
	//		rOldRect---Old Rectangle, Specifies a const FOPRect& rOldRect object(Value).
	void SubtractDescrSize_X(FOPRect& rRect,const FOPRect& rOldRect);

	// Initial description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Descr_ X, Call InitDescr_X after creating a new object.

	void InitDescr_X();

	// Initial description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Descr, Call InitDescr after creating a new object.
	// Parameters:
	//		&rValueOrient---Value Orient, Specifies a FOPChartTextOrient &rValueOrient object(Value).  
	//		nMaxTextWidth---Maximize Text Width, Specifies A 32-bit long signed integer.
	void InitDescr(FOPChartTextOrient &rValueOrient,long nMaxTextWidth=-1);

	// Initial description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Descr, Call InitDescr after creating a new object.

	void InitDescr();
	
	// Calculate maximize text size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Maximize Text Size, .
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		eOrient---eOrient, Specifies a FOPChartTextOrient eOrient object(Value).
	FOPSize CalcMaxTextSize(FOPChartTextOrient eOrient);

	// Calculate maximize text size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Maximize Text Size, .
	//		Returns A FOPSize value (Object).
	FOPSize CalcMaxTextSize();
	
	// Create mark description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Mark Descr, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		rString---rString, Specifies A CString type value.  
	//		nPosition---nPosition, Specifies A 32-bit long signed integer.  
	//		*---A pointer to the COLORREF  or NULL if the call failed.
	void CreateMarkDescr(const CString& rString, long nPosition, COLORREF *);

	// Create mark description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Mark Descr, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		fData---fData, Specifies a double fData object(Value).  
	//		nPosition---nPosition, Specifies A 32-bit long signed integer.
	void CreateMarkDescr(double fData,long nPosition);

	// Create mark description.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Mark Descr, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		*pTextObj---Text Object, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nPosition---nPosition, Specifies A 32-bit long signed integer.
	void CreateMarkDescr(CFODrawShape *pTextObj,long nPosition);

	// Change axis list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Axis List, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	void SetAxisList( CFODrawShapeList *pList );
	
	// Change position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPChartAxis
	// Parameters:
	//		nPos---nPos, Specifies A 32-bit long signed integer.
	void SetPosition(long nPos);

	// Create marks
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Marks, You construct a CFOPChartAxis object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		nPosition---nPosition, Specifies A 32-bit long signed integer.  
	//		nLen---nLen, Specifies A 32-bit long signed integer.  
	//		nWhichTicks---Which Ticks, Specifies A 32-bit long signed integer.
	CFODrawShape *CreateMarks(long nPosition,long nLen,long nWhichTicks);
	
	// Obtain unique id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Id, Returns the specified value.
	//		Returns A 32-bit long signed integer.
    long GetUniqueId() const    { return m_nUId; }

	// Obtain unique id by object id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Id By Object Id, Returns the specified value.
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nObjectId---Object Id, Specifies A 32-bit long signed integer.
    static long GetUniqueIdByObjectId( long nObjectId );
	
protected:
	// Calculate the size of the bounding box of a text string.  The 
	// size is measured with respect to the coordinate axes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Description Size, .
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		aString---aString, Specifies A CString type value.
	FOPSize	CalcDescriptionSize	(const CString & aString);
	
	// Calculate the expected size of a "typical" description.  The 
	// size is measured along the axis.  The axis orientation is taken
	// into account.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Typical Description Size, .
	//		Returns a int type value.
	long int	CalcTypicalDescriptionSize();
};

////////////////////////////////////////////////////////////////////////////
// CFOPChartShape -- chart data description object.

struct FOPDataDescription
{
public:
	// Point of 2d chart
	FOPPoint          m_ptPos2D;

	// value
	double            m_fValue;

	// Description data.
	FOPChartDataDescr eDescr;

	// Adjust position
	FOPChartAdjust    m_eAdjust;

	// With symbol or not
	BOOL              bSymbol;

	// Show or hide
	BOOL              bShow;

	// Label object
	CFODrawShape	  *m_pLabelObj;
	
	// Constructor.
	FOPDataDescription() :
		m_ptPos2D( 0, 0 ),
		m_fValue( DBL_MIN ),
		eDescr( FOP_CHDESCR_NONE ),
		m_eAdjust( FOP_CHADJUST_CENTER_CENTER ),
		bSymbol( FALSE ),
		bShow( FALSE ),
		m_pLabelObj( NULL )
	{}
};

/////////////////////////////////////////////////////////////
// CFOPDataExtDescription -- data extend description.

 
//===========================================================================
// Summary:
//      To use a CFOPDataExtDescription object, just call the constructor.
//      F O P Data Extend Description
//===========================================================================

class FO_EXT_CLASS CFOPDataExtDescription
{
protected:

	// Rows
 
	// Rows, Specify a A 32-bit signed integer.  
	long					m_nRows;

	// Columns
 
	// Cols, Specify a A 32-bit signed integer.  
	long					m_nCols;

	// Pointer of chart shape
 
	// Chart, This member maintains a pointer to the object CFOPChartShape.  
	CFOPChartShape*			m_pChart;

	// Description list
 
	// Descr Lists, This member maintains a pointer to the object CFODrawShapeList*.  
	CFODrawShapeList**		m_pDescrLists;

	// List of shapes
 
	// List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList*		m_pList;

	// Array description.
 
	// Descr Array, This member maintains a pointer to the object FOPDataDescription.  
	FOPDataDescription*		m_pDescrArray;

	// Enable or not
 
	// Enable, This member sets TRUE if it is right.  
	BOOL					mbEnable;

	// Group description.
 
	// Descr Groups, This member maintains a pointer to the object CFOCompositeShape*.  
	CFOCompositeShape**		m_pDescrGroups;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDataExtDescription object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	// Create or not
	void Create(long nRow);

	// 2d dirty.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dirty2 D, .
	// Parameters:
	//		bRowDescr---Row Descr, Specifies A Boolean value.
	void Dirty2D(BOOL bRowDescr);
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Data Extend Description, Constructs a CFOPDataExtDescription object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCols---nCols, Specifies A 32-bit long signed integer.  
	//		nRows---nRows, Specifies A 32-bit long signed integer.  
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		m_pChart---m_pChart, A pointer to the CFOPChartShape or NULL if the call failed.  
	//		bEnable---bEnable, Specifies A Boolean value.
	CFOPDataExtDescription( long nCols, long nRows, CFODrawShapeList *pList,
		CFOPChartShape* m_pChart, BOOL bEnable=TRUE );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Data Extend Description, Destructor of class CFOPDataExtDescription
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDataExtDescription();

public:
	
	// Enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enabled, Call this member function to enable or disable the specify object for this command.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL Enabled() { return mbEnable; }
	
	// insert data description in list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build, .
	// Parameters:
	//		bRowDescr---Row Descr, Specifies A Boolean value.
	void Build( BOOL bRowDescr=TRUE );  
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	//		Returns a pointer to the object FOPDataDescription,or NULL if the call failed  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		aPos---aPos, Specifies A integer value.  
	//		bPercent---bPercent, Specifies A Boolean value.  
	//		m_eAdjust---m_eAdjust, Specifies a FOPChartAdjust m_eAdjust object(Value).  
	//		pAxis---pAxis, A pointer to the CFOPChartAxis or NULL if the call failed.
	// Insert
	FOPDataDescription* Insert( long nCol, long nRow, FOPPoint aPos,
		BOOL bPercent, FOPChartAdjust m_eAdjust, CFOPChartAxis* pAxis);
	
	
};

///////////////////////////////////////////////////////////////////////////
// CFOPChartBarDescriptor -- chart bar description.

 
//===========================================================================
// Summary:
//      To use a CFOPChartBarDescriptor object, just call the constructor.
//      F O P Chart Bar Descriptor
//===========================================================================

class FO_EXT_CLASS CFOPChartBarDescriptor
{
protected:

	// Pointer of axis.
 
	// Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*		m_pAxis;

	// Pointer of chart shape.
 
	// Chart, This member maintains a pointer to the object CFOPChartShape.  
	CFOPChartShape*		m_pChart;

	// OVerlap percent.
 
	// Overlap Percent, Specify a A 32-bit signed integer.  
	long				m_nOverlapPercent;

	// Gap percent.
 
	// Gap Percent, Specify a A 32-bit signed integer.  
	long				m_nGapPercent;
	
	// Over or not.
 
	// Over, Specify a A 32-bit signed integer.  
	long				nOver;

	// Gap
 
	// Gap, Specify a A 32-bit signed integer.  
	long				nGap;

	// width or part
 
	// Part Width, Specify a A 32-bit signed integer.  
	long				m_nPartWidth;

	// Column width
 
	// Column Width, Specify a A 32-bit signed integer.  
	long				m_nColWidth;

	// Bar width.
 
	// Bar Width, Specify a A 32-bit signed integer.  
	long				m_nBarWidth;

	// count
 
	// Count, Specify a A 32-bit signed integer.  
	long				nCnt;
	
	// Current.
 
	// Current, Specify a A 32-bit signed integer.  
	long				nCurrent;

	// left
 
	// Left, Specify a A 32-bit signed integer.  
	long				nLeft;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Bar Descriptor, Constructs a CFOPChartBarDescriptor object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nOverlap---nOverlap, Specifies A 32-bit long signed integer.  
	//		_nGap---_nGap, Specifies A 32-bit long signed integer.
	CFOPChartBarDescriptor(long nOverlap=0,long _nGap=100):
		  m_pAxis(NULL),
		  m_nOverlapPercent(nOverlap),
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gap Percent, .
	//		Returns A  value (Object).  
	// Parameters:
	//		_nGap---_nGap, Specifies a _nGap object(Value).
		  m_nGapPercent(_nGap) {}
	  
		  //-----------------------------------------------------------------------
		  // Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Bar Descriptor, Constructs a CFOPChartBarDescriptor object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aRect---aRect, Specifies a const FOPRect& aRect object(Value).  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.  
	//		nRowCnt---Row Count, Specifies A 32-bit long signed integer.  
	//		nOverlap---nOverlap, Specifies A 32-bit long signed integer.  
	//		_nGap---_nGap, Specifies A 32-bit long signed integer.
	  CFOPChartBarDescriptor(const FOPRect& aRect,long nColCnt,
		  long nRowCnt,long nOverlap=0,long _nGap=100);
	  
	  //-----------------------------------------------------------------------
	  // Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Bar Descriptor, Constructs a CFOPChartBarDescriptor object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rSrc---rSrc, Specifies a const CFOPChartBarDescriptor& rSrc object(Value).  
	//		pNewModel---New Model, A pointer to the CFOPChartShape or NULL if the call failed.
	  CFOPChartBarDescriptor( const CFOPChartBarDescriptor& rSrc,
		  CFOPChartShape* pNewModel );
	  
	  //-----------------------------------------------------------------------
	  // Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Chart Bar Descriptor, Destructor of class CFOPChartBarDescriptor
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	  virtual ~CFOPChartBarDescriptor(){};
	  
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPChartBarDescriptor object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		aRect---aRect, Specifies a const FOPRect& aRect object(Value).  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.  
	//		nRowCnt---Row Count, Specifies A 32-bit long signed integer.
	  // Create
	  void Create(const FOPRect& aRect,
		  long nColCnt,long nRowCnt);
	  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assign, .
	// Parameters:
	//		pModel---pModel, A pointer to the CFOPChartShape or NULL if the call failed.  
	//		pAxis---pAxis, A pointer to the CFOPChartAxis or NULL if the call failed.
	  // Assign.
	  void Assign(CFOPChartShape* pModel,CFOPChartAxis* pAxis);
	  
	  // Change overlap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Overlap, Sets a specify value to current class CFOPChartBarDescriptor
	// Parameters:
	//		nPercent---nPercent, Specifies A 32-bit long signed integer.
	  void SetOverlap(long nPercent);

	  // Obtain overlap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Overlap, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	  long GetOverlap() const;

	  // Obtain gap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gap, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	  long GetGap() const;

	  // Change gap value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gap, Sets a specify value to current class CFOPChartBarDescriptor
	// Parameters:
	//		nPercent---nPercent, Specifies A 32-bit long signed integer.
	  void SetGap(long nPercent);

	  // Pointer of data mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model, .
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFOPChartShape or NULL if the call failed.
	  void ChangeModel( CFOPChartShape* pNewModel );
	  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Middle, .
	//		Returns A 32-bit long signed integer.
	  // Middle
	  long Middle();

	  // Next column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Next Column, .
	//		Returns A 32-bit long signed integer.
	  long NextCol();
	  
	  // Bar left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar Left, .
	//		Returns A 32-bit long signed integer.
	  long BarLeft();

	  // Bar right
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar Right, .
	//		Returns A 32-bit long signed integer.
	  long BarRight();

	  // Bar width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar Width, .
	//		Returns A 32-bit long signed integer.
	  long BarWidth();

	  // Bar top
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar Top, .
	//		Returns A 32-bit long signed integer.
	  long BarTop();

	  // Bar bottom
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar Bottom, .
	//		Returns A 32-bit long signed integer.
	  long BarBottom();

	  // Next bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Next Bar, .
	//		Returns A 32-bit long signed integer.
	  long NextBar();
	  
};

/////////////////////////////////////////////////////////////////////////////////
// CFOPChartShape -- chart shape with many styles. ID: FOP_CHART_SHAPE 244

 
//===========================================================================
// Summary:
//     The CFOPChartShape class derived from CFOCompositeShape
//      F O P Chart Shape
//===========================================================================

class FO_EXT_CLASS CFOPChartShape : public CFOCompositeShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPChartShape---F O P Chart Shape, Specifies a E-XD++ CFOPChartShape object (Value).
	DECLARE_SERIAL(CFOPChartShape);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Shape, Constructs a CFOPChartShape object.
	//		Returns A  value (Object).
	CFOPChartShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Shape, Constructs a CFOPChartShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPChartShape& src object(Value).
	CFOPChartShape(const CFOPChartShape& src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Chart Shape, Destructor of class CFOPChartShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPChartShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	// rcPos -- position of chart.
	// strCaption -- caption of chart
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	// rcPos -- position of chart.
	// strCaption -- caption of chart
	virtual void CreateSimple(CRect &rcPos,CString strCaption = _T(""));
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rData---rData, Specifies a E-XD++ CFOPChartData& rData object (Value).  
	//		eStyle---eStyle, Specifies a FOP_CHART_STYLE eStyle object(Value).  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bNewTitles---New Titles, Specifies A Boolean value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	// rData -- data of chart.
	// eStyle -- chart style.
	// rcPos -- position of chart.
	// bNewTitles -- with new titles or not.
	// strCaption -- caption of chart.
	virtual void Create(CFOPChartData& rData, const FOP_CHART_STYLE &eStyle, const CRect &rcPos, 
		BOOL bNewTitles, CString strCaption = _T(""));


	// Clear all data.
	virtual void ClearAll();

	// Do set chart style.
	void SetChartStyle(const FOP_CHART_STYLE &eStyle);
	
	
	// Update chart data.
	void UpdateData(CFOPChartData *pData);

	// Obtain chart style.
	FOP_CHART_STYLE GetChartStyle() const { return eChartStyle; };

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
	// Rebuild chart with new chart style.
	// eStyle -- style of chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Chart Style, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eStyle---eStyle, Specifies a FOP_CHART_STYLE eStyle object(Value).
	virtual BOOL RebuildChartStyle(FOP_CHART_STYLE eStyle);
	
	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPChartShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPChartShape& src object(Value).
	CFOPChartShape& operator=(const CFOPChartShape& src);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Other Data, Create a duplicate copy of this object.
	// Parameters:
	//		src---Specifies a const CFOPChartShape& src object(Value).
	void CopyOtherData(const CFOPChartShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	// Is initialized or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Initialized, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsInitialized() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.

	// Initialize.
	void                Initialize();

	// Initialize chart data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Chart Data, Call InitChartData after creating a new object.
	// Parameters:
	//		bNewTitles---New Titles, Specifies A Boolean value.
	void                InitChartData( BOOL bNewTitles = TRUE );
	
	// Build chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Chart, .
	// Parameters:
	//		bCheckRange---Check Range, Specifies A Boolean value.  
	//		whatTitle---whatTitle, Specifies A 32-bit long signed integer.
	void                BuildChart( BOOL bCheckRange,
									long whatTitle = 0 );

	// Get plus spots
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Create chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		rRect---rRect, Specifies a const FOPRect &  rRect object(Value).
	CFOCompositeShape*  CreateChart( const FOPRect &  rRect );
	
	// Change chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Chart, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eStyle---eStyle, Specifies a FOP_CHART_STYLE eStyle object(Value).  
	//		bSetDefaultAttr---Set Default Attributes, Specifies A Boolean value.
	BOOL                ChangeChart( FOP_CHART_STYLE eStyle, bool bSetDefaultAttr = true );

	// Change chart data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Chart Data, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rData---rData, Specifies a E-XD++ CFOPChartData &   rData object (Value).  
	//		bNewTitles---New Titles, Specifies A Boolean value.  
	//		bDontBuild---Dont Build, Specifies A Boolean value.
	BOOL                ChangeChartData( CFOPChartData &   rData,
		BOOL            bNewTitles = TRUE,
		BOOL            bDontBuild = FALSE );
	
	// Change chart data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Chart Data, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		rData---rData, Specifies a E-XD++ CFOPChartData &  rData object (Value).  
	//		bNewTitles---New Titles, Specifies A Boolean value.
	void                SetChartData( CFOPChartData &  rData,
								BOOL    bNewTitles = TRUE );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Data, Returns the specified value.
	//		Returns a pointer to the object CFOPChartData ,or NULL if the call failed
	CFOPChartData *     GetChartData()  const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Memory Chart, Returns the specified value.
	//		Returns a pointer to the object const CFOPChartData ,or NULL if the call failed
	const CFOPChartData * GetMemChart () const;
	
	// Change char data buffered.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Chart Data Buffered, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		rData---rData, Specifies a E-XD++ CFOPChartData &  rData object (Value).  
	//		bNewTitles---New Titles, Specifies A Boolean value.
	void                SetChartDataBuffered( CFOPChartData &  rData,
								BOOL    bNewTitles = TRUE );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Catch Up Buffered Data, .

    void                CatchUpBufferedData();
	
	// Obtain data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bPercent---bPercent, Specifies A Boolean value.  
	//		bRowData---Row Data, Specifies A Boolean value.
	double              GetData(long    nCol,
								long    nRow,
								BOOL    bPercent = FALSE,
								BOOL    bRowData = TRUE )   const;

	// Obtain column count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetColCount() const;

	// Obtain row count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetRowCount() const;
	
	// Create default colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Colors, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.

	void                CreateDefaultColors();

	// Destroy default colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Default Colors, Call this function to destroy an existing object.

	void                DestroyDefaultColors();

	// Copy default colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Default Colors, Create a duplicate copy of this object.
	// Parameters:
	//		pOtherColors---Other Colors, A pointer to the FOPList  or NULL if the call failed.
	void                CopyDefaultColors( FOPList * pOtherColors );
	
	// switch data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Switch Data, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		b---Specifies A Boolean value.
	void                SetSwitchData( BOOL b );
	
	// Is data switched or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Switch Data, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         IsSwitchData() const;

	// Is data switched or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Data Switched, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         IsDataSwitched() const;
	
	// Is column or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Column, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	BOOL                IsCol( long nRow ) const;

	// Is area or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Area, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	BOOL                IsArea( long nRow );
	
    /// return TRUE if the current chart type supports a given axis type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Axis, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nAxisId---Axis Id, Specifies A 32-bit long signed integer.
	BOOL                CanAxis( long nAxisId ) const;
	
	// Create default symbol.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Symbol, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*		CreateDefaultSymbol(long nRow);

	// Create symbol.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Symbol, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		aPoint---aPoint, Specifies A integer value.  
	//		nRow---nRow, Specifies A integer value.  
	//		nColumn---nColumn, Specifies A integer value.  
	//		nSymbolSize---Symbol Size, Specifies A 32-bit long signed integer.  
	//		bInsert---bInsert, Specifies A Boolean value.
	CFODrawShape*       CreateSymbol( FOPPoint      aPoint,
										int         nRow,
										int         nColumn,
										long        nSymbolSize,
										BOOL        bInsert = TRUE );
	
	// Obtain chart shape list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Shape List, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	CFODrawShapeList*   GetChartShapeList();
	
	// Obtain axis by UID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis By U I D, Returns the specified value.
	//		Returns a pointer to the object CFOPChartAxis,or NULL if the call failed  
	// Parameters:
	//		nUId---U Id, Specifies A 32-bit long signed integer.
	CFOPChartAxis*      GetAxisByUID( long nUId ) const;

	// Obtainthe axis of chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis, Returns the specified value.
	//		Returns a pointer to the object CFOPChartAxis,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A 32-bit long signed integer.
	CFOPChartAxis*      GetAxis( long nId );

	// Has second y axis or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Second Y Axis, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                HasSecondYAxis() const;
	
    /// is the x-axis vertical, ie we have bars not columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is X Vertikal, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsXVertikal() const { return IsBar(); }
	
	// Draw stock bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Stock Bars, Draws current object to the specify device.
	// Parameters:
	//		pList---pList, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).
	void                DrawStockBars( CFODrawShapeList* pList, const FOPRect& rRect );

	// Has stock bar or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Stock Bars, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                HasStockBars( FOP_CHART_STYLE* pStyle = NULL );

	// Draw stock lines or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Stock Lines, Draws current object to the specify device.
	// Parameters:
	//		pList---pList, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).
	void                DrawStockLines(CFODrawShapeList* pList,const FOPRect& rRect);

	// Has stock lines or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Stock Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                HasStockLines( FOP_CHART_STYLE* pStyle=NULL );

	// Has stock rectangle or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Stock Rects, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                HasStockRects( FOP_CHART_STYLE* pStyle=NULL );
	
	// Move row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Row, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bUp---bUp, Specifies A Boolean value.
	BOOL                MoveRow( long nRow, BOOL bUp = TRUE );

	// Obtain chart shape type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Shape Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetChartShapeType();

	// Obtain chart shape type by row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Shape Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long                GetChartShapeType( long nRow );
	
	// Create 2d xy titles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D X Y Titles, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect& rRect object(Value).  
	//		bSwitchColRow---Switch Column Row, Specifies A Boolean value.
	void                Create2DXYTitles( FOPRect& rRect, BOOL bSwitchColRow );
	
	// Row ids
	CArray<int,int>		arRowIds;
	
	// Obtain data row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data Row Attributes, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	int GetDataRowAttr( long nRow ) const;
	
	// Change chart status.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Chart Status, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nStatus---nStatus, Specifies A 32-bit long signed integer.
	void                SetChartStatus( const long  nStatus )	{ m_nChartStatus = nStatus; }

	// Change chart status flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Chart Status Flag, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		flag---Specifies A 32-bit long signed integer.
	void                SetChartStatusFlag( const long flag )	{ FOP_SETFLAG( m_nChartStatus, flag ); }

	// Reset chart status flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Chart Status Flag, Called this function to empty a previously initialized CFOPChartShape object.
	// Parameters:
	//		flag---Specifies A 32-bit long signed integer.
	void                ResetChartStatusFlag( const long flag )	{ FOP_RESETFLAG( m_nChartStatus, flag ); }

	// Obtain chart status
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Status, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetChartStatus()						{ return m_nChartStatus; }

	// Obtain chart status flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Status Flag, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		flag---Specifies A 32-bit long signed integer.
	BOOL                GetChartStatusFlag( const long flag )	{ return FOP_ISFLAGSET( m_nChartStatus, flag ); }
	
	// Setup line colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setup Line Colors, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nMode---nMode, Specifies A 32-bit long signed integer.  
	//		nStartIndex---Start Index, Specifies A 32-bit long signed integer.
	void                SetupLineColors( const long nMode, long nStartIndex = 0 );    //#54870#
	
	// Change title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nId---nId, Specifies A 32-bit long signed integer.  
	//		rTitle---rTitle, Specifies A CString type value.
	void                SetTitle( const long nId, const CString& rTitle );

	// Obtain title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nId---nId, Specifies A 32-bit long signed integer.
	CString             GetTitle( const long nId );	// BM

	// Change been moved flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nId---nId, Specifies A 32-bit long signed integer.  
	//		bMoved---bMoved, Specifies A Boolean value.
	void                SetHasBeenMoved( const long nId, BOOL bMoved = TRUE );

	// Obtain object with ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object With Id, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A 32-bit long signed integer.  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*       GetObjectWithId( const long nId, const long nCol = 0, const long nRow = 0 );
	
	// set number of lines in a bar/line combination chart. This value
    //    determines the number of series that should be represented as line
    //    beginning from the last series, eg when set to 2 the last two series
    //   are lines. This is not availably via GUI, but only via API
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Number Lines Column Chart, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nSet---nSet, Specifies A 32-bit long signed integer.  
	//		bForceStyleChange---Force Style Change, Specifies A Boolean value.
    void                SetNumLinesColChart( const long nSet, BOOL bForceStyleChange = FALSE );

	// Obtain column chart number lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Lines Column Chart, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetNumLinesColChart() const    { return m_nNumLinesInColChart; }
	
	// Change bar chart's percent width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bar Percent Width, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	void				SetBarPercentWidth( const long nWidth );

	// Obtain bar chart's percent width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bar Percent Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetBarPercentWidth() const     { return m_nBarPercentWidth; }
	
	// Change default color set.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Color Set, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nSet---nSet, Specifies A 32-bit long signed integer.
	void                SetDefaultColorSet( long nSet ); 

	// Obtain default color set.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Color Set, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetDefaultColorSet() const     { return m_nDefaultColorSet; }
	
	// Create text object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Object, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOStaticShape,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A integer value.  
	//		&rPos---&rPos, Specifies A integer value.  
	//		&rText---&rText, Specifies A CString type value.  
	//		bIsTitle---Is Title, Specifies A Boolean value.  
	//		m_eAdjust---m_eAdjust, Specifies a FOPChartAdjust   m_eAdjust = FOP_CHADJUST_TOP_LEFT object(Value).  
	//		nMaximumWidth---Maximum Width, Specifies A 32-bit long signed integer.
	CFOStaticShape*     CreateTextObj( int      nId,
							const FOPPoint			&rPos,
							const CString			&rText,
							BOOL					bIsTitle,
							FOPChartAdjust			m_eAdjust = FOP_CHADJUST_TOP_LEFT,
							const long				nMaximumWidth = -1);
	
	// Calc max description size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Maximize Descr Size, .
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		bRowDescr---Row Descr, Specifies A Boolean value.  
	//		nNumberFormat---Number Format, Specifies A 32-bit long signed integer.  
	//		nAxisUId---Axis U Id, Specifies A 32-bit long signed integer.  
	//		m_eAdjust---m_eAdjust, Specifies a FOPChartAdjust   m_eAdjust = FOP_CHADJUST_TOP_LEFT object(Value).  
	//		MaximumWidth---Maximum Width, Specifies A 32-bit long signed integer.  
	//		pFirstAndLast---First And Last, A pointer to the FOPPair or NULL if the call failed.
    FOPSize             CalcMaxDescrSize( BOOL		bRowDescr,
							const long				nNumberFormat,
							long					nAxisUId,
							FOPChartAdjust			m_eAdjust = FOP_CHADJUST_TOP_LEFT,
							const long				MaximumWidth  = -1,
							FOPPair*                pFirstAndLast = NULL );
	
	// Obtain regress string id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Regress String Id, Returns the specified value.
	//		Returns A USHORT value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	USHORT              GetRegressStrId( long nRow );
	
	// Obtain data row group
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data Row Group, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*       GetDataRowGroup( const long nRow );
	
	// Change chart base type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Base Type, Sets a specify value to current class CFOPChartShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nBaseType---Base Type, Specifies A 32-bit long signed integer.
	BOOL                SetBaseType( long nBaseType );
	
	// Obtain chart base type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long                GetBaseType()                     const;
	
	// Is percent or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Percent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsPercent()                       const;

	// Is stacked or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Stacked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsStacked()                       const;

	// Is bar or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bar, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsBar()                           const;

	// Is pie chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Pie Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsPieChart()                      const;

	// Is pie or donut chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Pie Or Donut Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                IsPieOrDonutChart()               const;

	// Is 3d chart or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is3 D Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                Is3DChart()                       const;

	// Is statistic chart or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Statistic Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsStatisticChart()                const;

	// Is net chart or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Net Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsNetChart()                      const;

	// Check if it is stacked chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Stacked Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsStackedChart()                  const;

	// Check if it is percent chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Percent Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsPercentChart()                  const;

	// Check if it is axis chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Axis Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsAxisChart()                     const;

	// Check if it is spline chart or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Spline Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsSplineChart()                   const;

	// Check if it is donut chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Donut Chart, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
    _FOLIB_INLINE BOOL         IsDonutChart()                    const;
	
	// Has symbols or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Symbols, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	BOOL                HasSymbols( const long nRow = 0 ) const;

	// Is line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	BOOL                IsLine( const long nRow = 0 )     const;
	
    // chart features for current chart (default) or the given type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Negative Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                IsNegativeChart( FOP_CHART_STYLE* pStyle = NULL ) const;

	// Is signed chart or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Signed Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                IsSignedChart( FOP_CHART_STYLE* pStyle = NULL )   const;

	// Is XY Chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is X Y Chart, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                IsXYChart( FOP_CHART_STYLE* pStyle = NULL )       const;
	
	// Obtain row chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Chart Style, Returns the specified value.
	//		Returns A FOP_CHART_STYLE value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	FOP_CHART_STYLE     GetRowChartStyle( const long nRow );
	
	// Change data log book
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data Logical Book, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		pLog---pLog, A pointer to the CFOPDataLogBook or NULL if the call failed.
	void                SetDataLogBook( CFOPDataLogBook* pLog );
	
	// Obtain chart object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Object, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A integer value.
	CFODrawShape*       GetChartObj( int nId );

	// Obtain row data object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data Row Object, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*       GetDataRowObj( long nRow );

	// Obtain data point object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data Point Object, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*       GetDataPointObj( long nCol, long nRow );

	// Obtain pie data row object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pie Data Row Object, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape*       GetPieDataRowObj( const long nRow );
	
	// Change title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Title, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bShowMain---Show Main, Specifies A Boolean value.  
	//		rMainTitle---Main Title, Specifies A CString type value.  
	//		bShowSub---Show Child, Specifies A Boolean value.  
	//		rSubTitle---Child Title, Specifies A CString type value.  
	//		bShowX---Show X, Specifies A Boolean value.  
	//		rXAxisTitle---X Axis Title, Specifies A CString type value.  
	//		bShowY---Show Y, Specifies A Boolean value.  
	//		rYAxisTitle---Y Axis Title, Specifies A CString type value.  
	//		bShowZ---Show Z, Specifies A Boolean value.  
	//		rZAxisTitle---Z Axis Title, Specifies A CString type value.
	BOOL                ChangeTitle( BOOL             bShowMain,
									const CString &   rMainTitle,
									BOOL              bShowSub,
									const CString &   rSubTitle,
									BOOL              bShowX,
									const CString &   rXAxisTitle,
									BOOL              bShowY,
									const CString &   rYAxisTitle,
									BOOL              bShowZ,
									const CString &   rZAxisTitle );
	
	// Has title or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Title, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                HasTitle() const;

	// Has axis or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Axis, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nObjectId---Object Id, Specifies A 32-bit long signed integer.
	BOOL                HasAxis( long nObjectId = FOP_CHART_ANY ) const;

	// Has grid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Grid, .
	//		Returns A Boolean value.  
	// Parameters:
	//		nObjectId---Object Id, Specifies A integer value.
    bool                HasGrid( int nObjectId ) const;

	// Has grid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Grid, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                HasGrid() const;
	
	// Change axis.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Axis, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bXAxis---X Axis, Specifies A Boolean value.  
	//		bXDescr---X Descr, Specifies A Boolean value.  
	//		bYAxis---Y Axis, Specifies A Boolean value.  
	//		bYDescr---Y Descr, Specifies A Boolean value.  
	//		bZAxis---Z Axis, Specifies A Boolean value.  
	//		bZDescr---Z Descr, Specifies A Boolean value.  
	//		b2YAxis---Y Axis, Specifies A Boolean value.  
	//		b2YDescr---Y Descr, Specifies A Boolean value.  
	//		b2XAxis---X Axis, Specifies A Boolean value.  
	//		b2XDescr---X Descr, Specifies A Boolean value.  
	//		bAllowBuildChart---Allow Build Chart, Specifies A Boolean value.
	BOOL                ChangeAxis( BOOL bXAxis,
		BOOL bXDescr,
		BOOL bYAxis,
		BOOL bYDescr,
		BOOL bZAxis,
		BOOL bZDescr,
		BOOL b2YAxis,
		BOOL b2YDescr,
		BOOL b2XAxis,
		BOOL b2XDescr,
		BOOL bAllowBuildChart = TRUE );

	// Change grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Grid, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bXMain---X Main, Specifies A Boolean value.  
	//		bXHelp---X Help, Specifies A Boolean value.  
	//		bYMain---Y Main, Specifies A Boolean value.  
	//		bYHelp---Y Help, Specifies A Boolean value.  
	//		bZMain---Z Main, Specifies A Boolean value.  
	//		bZHelp---Z Help, Specifies A Boolean value.  
	//		bAllowBuildChart---Allow Build Chart, Specifies A Boolean value.
	BOOL                ChangeGrid( BOOL bXMain,
		BOOL bXHelp,
		BOOL bYMain,
		BOOL bYHelp,
		BOOL bZMain,
		BOOL bZHelp,
		BOOL bAllowBuildChart = TRUE );
	
	// Resize page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Page, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rNewSize---New Size, Specifies a const FOPSize & rNewSize object(Value).
	BOOL                ResizePage( const FOPSize & rNewSize );
	
	// Obtain chart rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Rectangle, Returns the specified value.
	//		Returns A const FOPRect & value (Object).
	const FOPRect &		GetChartRect () const;
	
	// Can rebuild or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Rebuild, .
	// Parameters:
	//		bNewRebuild---New Rebuild, Specifies A Boolean value.
	void                CanRebuild( BOOL bNewRebuild );
	
	// Obtain legend show.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Legend, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetShowLegend() const;

	// Change show legend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Legend, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		bNewShow---New Show, Specifies A Boolean value.
	void                SetShowLegend( BOOL bNewShow );
	
	// Text scalability
	
	//-----------------------------------------------------------------------
	// Summary:
	// Text Scalability, .
	//		Returns _FOLIB_INLINE BOOL &value, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL &       TextScalability();

	// Text scalability.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Text Scalability, .
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         TextScalability() const;
	
	// Show average.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Average, Call this function to show the specify object.
	//		Returns _FOLIB_INLINE BOOL &value, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL &       ShowAverage();

	// Show average.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Average, Call this function to show the specify object.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         ShowAverage() const;
	
	// Is copied or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Copied, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOL &value, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL &       IsCopied ();

	// Is copied or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Copied, Determines if the given value is correct or exist.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         IsCopied() const;
	
	// Percent indicate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Percent, .
	//		Returns A double & value (Object).
	double &            IndicatePercent();

	// Percent indicate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Percent, .
	//		Returns A double value (Object).
	double              IndicatePercent() const;
	
	// Big error indicate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Big Error, .
	//		Returns A double & value (Object).
	double &            IndicateBigError();

	// Big error indicate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Big Error, .
	//		Returns A double value (Object).
	double              IndicateBigError() const;
	
	// Indicate plus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Plus, .
	//		Returns A double & value (Object).
	double &            IndicatePlus();

	// Indicate plus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Plus, .
	//		Returns A double value (Object).
	double              IndicatePlus() const;
	
	// Minus indicate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Minus, .
	//		Returns A double & value (Object).
	double &            IndicateMinus();

	// Minus indicate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Indicate Minus, .
	//		Returns A double value (Object).
	double              IndicateMinus() const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Granularity, .
	//		Returns a int type value.
	// Granularity
	int &               Granularity();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Granularity, .
	//		Returns a int type value.
	// Granularity
	int                 Granularity() const;
	
	// Chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Chart Style, .
	//		Returns A FOP_CHART_STYLE & value (Object).
	FOP_CHART_STYLE &   ChartStyle();

	// Chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Chart Style, .
	//		Returns A FOP_CHART_STYLE value (Object).
    FOP_CHART_STYLE     ChartStyle() const;
	
	// Old chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Old Chart Style, .
	//		Returns A FOP_CHART_STYLE & value (Object).
	FOP_CHART_STYLE &   OldChartStyle();

	// Old chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Old Chart Style, .
	//		Returns A FOP_CHART_STYLE value (Object).
	FOP_CHART_STYLE     OldChartStyle() const;
	
	// Pie segment offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pie Seg Ofs, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
    long                PieSegOfs( long nCol ) const;
	
	// Show main title or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Main Title, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowMainTitle();

	// Show main title or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Main Title, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                ShowMainTitle() const;
	
	// Main title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Main Title, .
	//		Returns a CString type value.
	CString &           MainTitle ();

	// Main title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Main Title, .
	//		Returns a CString type value.
	const CString &     MainTitle () const;
	
	// Show sub title or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Child Title, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowSubTitle();

	// Show sub title or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Child Title, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowSubTitle() const;
	
	// Sub title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Child Title, .
	//		Returns a CString type value.
	CString &           SubTitle();

	// Sub title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Child Title, .
	//		Returns a CString type value.
	const CString &     SubTitle() const;
	
	// Show x axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Axis Title, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowXAxisTitle();

	// Show x axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Axis Title, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowXAxisTitle() const;
	
	// x axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	CString &           XAxisTitle();

	// x axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	const CString &     XAxisTitle() const;
	
	// Show y axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Axis Title, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowYAxisTitle();

	// Show y axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Axis Title, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowYAxisTitle() const;
	
	// Y axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	CString &           YAxisTitle();

	// y axis title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	const CString &     YAxisTitle() const;
	
	// Show z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Axis Title, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowZAxisTitle();

	// Show z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Axis Title, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowZAxisTitle() const;
	
	// z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	CString &           ZAxisTitle();

	// z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Axis Title, .
	//		Returns a CString type value.
	const CString &     ZAxisTitle() const;
	
	// Show x main grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Grid Main, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowXGridMain();

	// show x main grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Grid Main, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                ShowXGridMain() const;
	
	// Show x help grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Grid Help, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowXGridHelp();

	// show x help grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Grid Help, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowXGridHelp() const;
	
	// show y main grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Grid Main, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowYGridMain();

	// show y main grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Grid Main, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowYGridMain() const;
	
	// show y help grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Grid Help, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowYGridHelp();

	// show y help grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Grid Help, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowYGridHelp() const;
	
	// show z main grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Grid Main, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowZGridMain();

	// show z main grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Grid Main, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                ShowZGridMain() const;
	
	// show z help grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Grid Help, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowZGridHelp();

	// show z help grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Grid Help, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowZGridHelp() const;
	
	// data description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Data Descr, .
	//		Returns A FOPChartDataDescr & value (Object).
	FOPChartDataDescr & DataDescr();

	// data description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Data Descr, .
	//		Returns A FOPChartDataDescr value (Object).
	FOPChartDataDescr   DataDescr() const;
	
	// show symbol
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Sym, Call this function to show the specify object.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ShowSym();

	// show symbol
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Sym, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowSym() const;
	
	// Read error
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Error, Call this function to read the specify data from an archive.
	//		Returns BOOL &value, TRUE on success; FALSE otherwise.
	BOOL &              ReadError ();

	// Rad error
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Error, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ReadError() const;
	
	// Spot intensity
	
	//-----------------------------------------------------------------------
	// Summary:
	// Spot Intensity, .
	//		Returns A double & value (Object).
	double &            SpotIntensity();

	// spot intensity
	
	//-----------------------------------------------------------------------
	// Summary:
	// Spot Intensity, .
	//		Returns A double value (Object).
    double              SpotIntensity() const;
	
	// size initial
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Size, Call InitialSize after creating a new object.
	//		Returns A FOPSize & value (Object).
	FOPSize &           InitialSize();

	// size initial
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Size, Call InitialSize after creating a new object.
	//		Returns A const FOPSize & value (Object).
	const FOPSize &     InitialSize() const;
	
	// pie height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pie Height, .
	//		Returns A 32-bit long signed integer.
	long &              PieHeight();

	// pie height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pie Height, .
	//		Returns A 32-bit long signed integer.
	long                PieHeight() const;
	
	// pie segment count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pie Seg Count, .
	//		Returns A short & value (Object).
	short &             PieSegCount();

	// pie segment count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pie Seg Count, .
	//		Returns A short value (Object).
	short               PieSegCount() const;
	
	// spline depth.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Spline Depth, .
	//		Returns a int type value.
    int &               SplineDepth()                   { return m_nSplineDepth; }
	
	// column text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Column Text, .
	//		Returns a CString type value.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	CString				ColText( long nCol );
	
	// row text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Row Text, .
	//		Returns a CString type value.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CString				RowText( long nRow );
	
	// change overlap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Overlap, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nPercent---nPercent, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void                SetOverlap( long nPercent, long nRow );

	// change gap value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gap, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nPercent---nPercent, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void                SetGap( long nPercent, long nRow );

	// obtain overlap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Overlap, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long                GetOverlap( long nRow );

	// Obtain gap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gap, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long                GetGap( long nRow );
	
	// Obtain axis with id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Axis U I D, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long                GetAxisUID( long nRow );
	
	// Change data description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Data Descr, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		b---Specifies A Boolean value.
    void                SetShowDataDescr( const BOOL b ) { m_bShowDataDescr = b; }
	
	// Show x description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Descr, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                ShowXDescr() const;

	// Show x description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Descr, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowXDescr( BOOL b );

	// Show y description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Descr, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowYDescr() const;

	// Show y description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Descr, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowYDescr( BOOL b );

	// Show z axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Axis, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowZAxis() const;

	// Show z axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Axis, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowZAxis( BOOL b );

	// Show x axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Axis, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowXAxis() const;

	// Show x axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show X Axis, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowXAxis( BOOL b );

	// Show yx axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Axis, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowYAxis() const;

	// Show y axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Y Axis, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowYAxis( BOOL b );

	// Show z description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Descr, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                ShowZDescr() const;

	// Show z description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Z Descr, Call this function to show the specify object.
	// Parameters:
	//		b---Specifies A Boolean value.
	void                ShowZDescr( BOOL b );
	
	// Change angles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Angles, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nNewXAngle---New X Angle, Specifies a short nNewXAngle object(Value).  
	//		nNewYAngle---New Y Angle, Specifies a short nNewYAngle object(Value).  
	//		nNewZAngle---New Z Angle, Specifies a short nNewZAngle object(Value).
	void                SetAngles( short nNewXAngle, short nNewYAngle, short nNewZAngle);
	
	// Obtain angles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angles, Returns the specified value.
	// Parameters:
	//		rNewXAngle---New X Angle, Specifies a short &  rNewXAngle object(Value).  
	//		rNewYAngle---New Y Angle, Specifies a short &  rNewYAngle object(Value).  
	//		rNewZAngle---New Z Angle, Specifies a short &  rNewZAngle object(Value).
    void                GetAngles( short &  rNewXAngle, short &  rNewYAngle,short &  rNewZAngle );
	
	// Change pie segment offset
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pie Seg Ofs, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nOfs---nOfs, Specifies A 32-bit long signed integer.
	void                SetPieSegOfs( long  nCol,long  nOfs );
	
	// Alloc pie segment offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Pie Seg Ofs,  Alloc the specify space for this object.
	// Parameters:
	//		m_nPieSegCount---Pie Seg Count, Specifies A 32-bit long signed integer.
	void                AllocPieSegOfs( long m_nPieSegCount );
	
	// Is description centered under data point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Description Centered Under Data Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                IsDescriptionCenteredUnderDataPoint();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Format X Axis Text In Multiple Lines If Necessary, Returns the specified value.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
    _FOLIB_INLINE BOOL         GetFormatXAxisTextInMultipleLinesIfNecessary();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Format X Axis Text In Multiple Lines If Necessary, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	_FOLIB_INLINE void         SetFormatXAxisTextInMultipleLinesIfNecessary( BOOL value );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Format Y Axis Text In Multiple Lines If Necessary, Returns the specified value.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         GetFormatYAxisTextInMultipleLinesIfNecessary();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Format Y Axis Text In Multiple Lines If Necessary, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	_FOLIB_INLINE void         SetFormatYAxisTextInMultipleLinesIfNecessary( BOOL value );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Format Z Axis Text In Multiple Lines If Necessary, Returns the specified value.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         GetFormatZAxisTextInMultipleLinesIfNecessary();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Format Z Axis Text In Multiple Lines If Necessary, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	_FOLIB_INLINE void         SetFormatZAxisTextInMultipleLinesIfNecessary( BOOL value );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Format Legend Text In Multiple Lines If Necessary, Returns the specified value.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         GetFormatLegendTextInMultipleLinesIfNecessary();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Format Legend Text In Multiple Lines If Necessary, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	_FOLIB_INLINE void         SetFormatLegendTextInMultipleLinesIfNecessary( BOOL value );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Use Relative Positions, Returns the specified value.
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.
	_FOLIB_INLINE BOOL         GetUseRelativePositions()                       { return  m_bUseRelativePositionsForChartGroups; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use Relative Positions, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetUseRelativePositions( BOOL value );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For Legend, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForLegend( BOOL value )         { m_bAdjustMarginsForLegend = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For Legend, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForLegend()                     { return m_bAdjustMarginsForLegend; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For Main Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForMainTitle( BOOL value )      { m_bAdjustMarginsForMainTitle = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For Main Title, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForMainTitle()                  { return m_bAdjustMarginsForMainTitle; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For Child Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForSubTitle( BOOL value )       { m_bAdjustMarginsForSubTitle = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For Child Title, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForSubTitle()                   { return m_bAdjustMarginsForSubTitle; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For X Axis Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForXAxisTitle( BOOL value )     { m_bAdjustMarginsForXAxisTitle = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For X Axis Title, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForXAxisTitle()                 { return m_bAdjustMarginsForXAxisTitle; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For Y Axis Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForYAxisTitle( BOOL value )     { m_bAdjustMarginsForYAxisTitle = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For Y Axis Title, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForYAxisTitle()                 { return m_bAdjustMarginsForYAxisTitle; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Adjust Margins For Z Axis Title, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetAdjustMarginsForZAxisTitle( BOOL value )     { m_bAdjustMarginsForZAxisTitle = value; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Adjust Margins For Z Axis Title, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetAdjustMarginsForZAxisTitle()                 { return m_bAdjustMarginsForZAxisTitle; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Diagram Has Been Moved Or Resized, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetDiagramHasBeenMovedOrResized()               { return m_bDiagramHasBeenMovedOrResized; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Diagram Has Been Moved Or Resized, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetDiagramHasBeenMovedOrResized( BOOL value )   { m_bDiagramHasBeenMovedOrResized=value; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Title Has Been Moved, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetMainTitleHasBeenMoved()                      { return m_bMainTitleHasBeenMoved; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Title Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetMainTitleHasBeenMoved( BOOL value )          { m_bMainTitleHasBeenMoved = value; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Title Has Been Moved, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetSubTitleHasBeenMoved()                       { return m_bSubTitleHasBeenMoved; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Child Title Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetSubTitleHasBeenMoved( BOOL value )           { m_bSubTitleHasBeenMoved = value; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Legend Has Been Moved, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetLegendHasBeenMoved()                         { return m_bLegendHasBeenMoved; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Legend Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetLegendHasBeenMoved( BOOL value )             { m_bLegendHasBeenMoved = value; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Axis Title Has Been Moved, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetXAxisTitleHasBeenMoved()                     { return m_bXAxisTitleHasBeenMoved; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set X Axis Title Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetXAxisTitleHasBeenMoved( BOOL value )         { m_bXAxisTitleHasBeenMoved = value; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Axis Title Has Been Moved, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                GetYAxisTitleHasBeenMoved()                     { return m_bYAxisTitleHasBeenMoved; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Y Axis Title Has Been Moved, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		value---Specifies A Boolean value.
	void                SetYAxisTitleHasBeenMoved( BOOL value )         { m_bYAxisTitleHasBeenMoved = value; }
	
	// Change diagram rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Diagram Rectangle, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		&rNewRect---New Rectangle, Specifies a const FOPRect &rNewRect object(Value).  
	//		bStoreLast---Store Last, Specifies A Boolean value.
	_FOLIB_INLINE void         SetDiagramRectangle( const FOPRect &rNewRect, bool bStoreLast = true );

	// Change chart rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Chart Rectangle, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		&rValue---&rValue, Specifies a FOPRect &rValue object(Value).
	void                SetChartRect( FOPRect &rValue )					{ m_rcChartRect = rValue; }

	// Obtain chart rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Rectangle, Returns the specified value.
	//		Returns A FOPRect & value (Object).
	FOPRect &			GetChartRect()                                  { return m_rcChartRect; }

	// Change legend position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Legend Position, Sets a specify value to current class CFOPChartShape
	// Parameters:
	//		rPos---rPos, Specifies A integer value.
    void                SetLegendPos( const FOPPoint& rPos )            { m_ptLegendTopLeft = rPos; }
	
	// Obtain pie radius
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pie Radius, Returns the specified value.
	//		Returns A 32-bit long signed integer.
    long                GetPieRadius() const							{ return m_nPieRadius; }

	// Has default gray area or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Default Gray Area, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                HasDefaultGrayArea( FOP_CHART_STYLE* pStyle = NULL ) const;

	// Has default gray wall or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Default Gray Wall, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pStyle---pStyle, A pointer to the FOP_CHART_STYLE or NULL if the call failed.
	BOOL                HasDefaultGrayWall( FOP_CHART_STYLE* pStyle = NULL ) const;
	
	// Data range changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Data Range Changed, .
	// Parameters:
	//		_nOldRowCnt---Old Row Count, Specifies A 32-bit long signed integer.  
	//		_nOldColCnt---Old Column Count, Specifies A 32-bit long signed integer.
	void                DataRangeChanged( long _nOldRowCnt = 0, long _nOldColCnt = 0 );
	
	// Delete object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Object, Deletes the given object.
	// Parameters:
	//		pObj---pObj, A pointer to the CFOCompositeShape or NULL if the call failed.
	void                DeleteObject( CFOCompositeShape* pObj );
	
	// Calculate text size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Text Size Of One Text, .
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		eOrient---eOrient, Specifies a FOPChartTextOrient eOrient object(Value).  
	//		&strText---&strText, Specifies A CString type value.  
	//		MaximumWidth---Maximum Width, Specifies A 32-bit long signed integer.  
	//		bGetRotated---Get Rotated, Specifies A Boolean value.  
	//		bUseTextAttributes---Use Text Attributes, Specifies A Boolean value.
	FOPSize                CalcTextSizeOfOneText( FOPChartTextOrient eOrient, 
		const CString	   &strText,
		long               MaximumWidth,
		BOOL               bGetRotated = FALSE,
		BOOL               bUseTextAttributes = TRUE );
	
	// Is flat
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Flat3 D Chart, Determines if the given value is correct or exist.
	//		Returns A Boolean value.
	bool IsFlat3DChart() const;
	
	// Create legend
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Legend, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		&aRect---&aRect, Specifies a const FOPRect &aRect object(Value).
	CFOCompositeShape*        CreateLegend( const FOPRect &aRect );
	
	// Is read only or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Read Only, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		IsReadOnly() const;
	
	// Change group
	
	//-----------------------------------------------------------------------
	// Summary:
	// D R A Attributes Group, .
	// Parameters:
	//		pDataRowObj---Data Row Object, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nDataRow---Data Row, Specifies A 32-bit long signed integer.
	void                CDRAAttrGroup( CFODrawShape *         pDataRowObj,
		const long          nDataRow);
	
	// Change data description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Data Descr, .
	// Parameters:
	//		eDescr---eDescr, Specifies a FOPChartDataDescr eDescr object(Value).  
	//		bSym---bSym, Specifies A Boolean value.  
	//		nRowToChange---Row To Change, Specifies A 32-bit long signed integer.  
	//		bBuildChart---Build Chart, Specifies A Boolean value.
	void                ChangeDataDescr( FOPChartDataDescr eDescr,
		BOOL              bSym,
		long              nRowToChange = -1,
		BOOL              bBuildChart = TRUE );
	
	// Create title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Title, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOStaticShape,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies a short           nID object(Value).  
	//		bSwitchColRow---Switch Column Row, Specifies A Boolean value.  
	//		rText---rText, Specifies A CString type value.  
	//		bVert---bVert, Specifies A Boolean value.  
	//		pTextDirection---Text Direction, A pointer to the FOPChartAdjust  or NULL if the call failed.
	CFOStaticShape*     CreateTitle(short           nID,
		BOOL            bSwitchColRow,
		const CString &  rText,
		BOOL            bVert,
		FOPChartAdjust *   pTextDirection = NULL );
	
	// Init data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Data Attrs, Call InitDataAttrs after creating a new object.

	void                InitDataAttrs();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Chart Objects, Deletes the given object.

	void                DeleteChartObjects();
	
	// Check ranges
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Ranges, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bCheckAlways---Check Always, Specifies A Boolean value.
	BOOL                CheckRanges( BOOL bCheckAlways );
	
	// Resize chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Chart, .
	// Parameters:
	//		rPageSize---Page Size, Specifies a const FOPSize& rPageSize object(Value).
	void                ResizeChart( const FOPSize& rPageSize );

	// Calculate upper border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Upper Border, .

	void                CalculateUpperBorder();

	// Create rectangles and titles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Rects And Titles, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		whatTitle---whatTitle, Specifies A 32-bit long signed integer.
	void                CreateRectsAndTitles( long whatTitle );
	
	// Obtain average value y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Average Value Y, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double              GetAverageValueY( long nRow );
	
	// Obtain variant Y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Variant Y, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double              GetVariantY( long nRow );
	

	// Obtain sigma y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sigma Y, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double              GetSigmaY( long nRow );

	// Obtain big error y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Big Error Y, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		fError---fError, Specifies a double fError object(Value).
    double              GetBigErrorY( long nRow, double fError );
	
	// Regression YX
	
	//-----------------------------------------------------------------------
	// Summary:
	// Regression Y X, .
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		fAverageX---Average X, Specifies a double &        fAverageX object(Value).  
	//		fAverageY---Average Y, Specifies a double &        fAverageY object(Value).  
	//		fBetaYX---Beta Y X, Specifies a double &        fBetaYX object(Value).  
	//		eMyRegress---My Regress, Specifies a FOPChartRegress eMyRegress object(Value).
	void                RegressionYX( long            nRow,
		double &        fAverageX,
		double &        fAverageY,
		double &        fBetaYX,
		FOPChartRegress eMyRegress );
	
    /// this method shouldn't be used because it is not axis-oriented (why does it exist then?)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Average Value Y, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bIsVertical---Is Vertical, Specifies A Boolean value.  
	//		rRect---rRect, Specifies a FOPRect & rRect object(Value).  
	//		fAverageValue---Average Value, Specifies a double      fAverageValue object(Value).
	CFODrawShape *      AverageValueY( long        nRow,
		BOOL        bIsVertical,
		FOPRect & rRect,
		double      fAverageValue );
	
    /// this one is axis-oriented (whatever that means)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Average Value Y, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bIsVertical---Is Vertical, Specifies A Boolean value.  
	//		pAxis---pAxis, A pointer to the CFOPChartAxis  or NULL if the call failed.  
	//		fAverageValue---Average Value, Specifies a double       fAverageValue object(Value).
	CFODrawShape *      AverageValueY( long         nRow,
		BOOL         bIsVertical,
		CFOPChartAxis *  pAxis,
		double       fAverageValue );
	
	// Show main title.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Main Title, Do a event. 
	// Parameters:
	//		rIndex---rIndex, Specifies a USHORT & rIndex object(Value).  
	//		nYOfs---Y Ofs, Specifies A 32-bit long signed integer.
	void                DoShowMainTitle( USHORT & rIndex, const long nYOfs);

	// Show sub tile.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Child Title, Do a event. 
	// Parameters:
	//		rIndex---rIndex, Specifies a USHORT & rIndex object(Value).  
	//		nYOfs---Y Ofs, Specifies A 32-bit long signed integer.
	void                DoShowSubTitle(  USHORT & rIndex, const long nYOfs );

	// Show legend
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Legend, Do a event. 
	// Parameters:
	//		rWholeRect---Whole Rectangle, Specifies a const FOPRect & rWholeRect object(Value).  
	//		nXOfs---X Ofs, Specifies A 32-bit long signed integer.  
	//		nYOfs---Y Ofs, Specifies A 32-bit long signed integer.  
	//		rIndex---rIndex, Specifies a USHORT &          rIndex object(Value).
	void                DoShowLegend( const FOPRect & rWholeRect,
		const long        nXOfs,
		const long        nYOfs,
		USHORT &          rIndex );
	
	// Create back plane.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Backplane, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect &  rRect object(Value).  
	//		rObjList---Object List, Specifies a E-XD++ CFODrawShapeList & rObjList object (Value).  
	//		bPartDescr---Part Descr, Specifies A Boolean value.  
	//		eStackMode---Stack Mode, Specifies a USHORT       eStackMode object(Value).
	void                Create2DBackplane( FOPRect &  rRect,
		CFODrawShapeList & rObjList,
		BOOL         bPartDescr,
		USHORT       eStackMode );

	// Create 2d column chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Column Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DColChart     (FOPRect aRect);

	// Create 2d row line chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Row Line Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DRowLineChart (FOPRect aRect);

	// Create 2d pie chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Pie Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DPieChart     (FOPRect aRect);

	// Create 2d donut chart
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Donut Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DDonutChart   (FOPRect aRect);

	// Create 2d net chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D Net Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DNetChart     (FOPRect aRect);

	// Create 2d xy chart.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2 D X Y Chart, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect aRect object(Value).
	CFOCompositeShape*        Create2DXYChart      (FOPRect aRect);
	
	// Position 2D axis titles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position2 D Axis Titles, .
	// Parameters:
	//		rRect---rRect, Specifies a const FOPRect &  rRect object(Value).  
	//		bSwitchColRow---Switch Column Row, Specifies A Boolean value.  
	//		nTitleLeft---Title Left, Specifies A 32-bit long signed integer.  
	//		nTitleBottom---Title Bottom, Specifies A 32-bit long signed integer.
	void Position2DAxisTitles( const FOPRect &  rRect,
		BOOL               bSwitchColRow,
		long               nTitleLeft,
		long               nTitleBottom );
	
	// Check for new axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check For New Axis Number Format, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL                CheckForNewAxisNumFormat();

	// Clear description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Description, Remove the specify data from the list.
	// Parameters:
	//		pDescription---pDescription, A pointer to the FOPDataDescription  or NULL if the call failed.  
	//		nElements---nElements, Specifies A 32-bit long signed integer.
	void                ClearDescription( FOPDataDescription * pDescription, long nElements );
	
	// Create data description
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Data Descr, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		rDescr---rDescr, Specifies a FOPDataDescription & rDescr object(Value).  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		pAxis---pAxis, A pointer to the CFOPChartAxis  or NULL if the call failed.  
	//		bRowDescr---Row Descr, Specifies A Boolean value.  
	//		bIsPercent---Is Percent, Specifies A Boolean value.
	void                CreateDataDescr( FOPDataDescription & rDescr,
		long              nCol,
		long              nRow,
		CFOPChartAxis *   pAxis,
		BOOL              bRowDescr,
		BOOL              bIsPercent = FALSE );
	
	// Dirty 2D
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dirty2 D, .
	// Parameters:
	//		nRowCnt---Row Count, Specifies A 32-bit long signed integer.  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		pDescrLists---Descr Lists, A pointer to the CFODrawShapeList * or NULL if the call failed.  
	//		bRowDescr---Row Descr, Specifies A Boolean value.  
	//		pDescription---pDescription, A pointer to the FOPDataDescription  or NULL if the call failed.
	void                Dirty2D( long               nRowCnt,
		long               nCol,
		CFODrawShapeList **      pDescrLists,
		BOOL               bRowDescr,
		FOPDataDescription *  pDescription );
	
	// Create rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Rectangle, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect &  rRect object(Value).  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CFODrawShape *        CreateRect( FOPRect &  rRect,
		long         nCol,
		long         nRow );
	
	// Create pie segment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pie Segment, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect  &  rRect object(Value).  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A 32-bit long signed integer.  
	//		nEndAngle---End Angle, Specifies A 32-bit long signed integer.  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.
	CFODrawShape* CreatePieSegment(FOPRect  &  rRect,
		long          nCol,
		long          nRow,
		long          nStartAngle,
		long          nEndAngle,
		long          nColCnt );
	
	// Create donut segment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Donut Segment, You construct a CFOPChartShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect  &  aRect object(Value).  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A 32-bit long signed integer.  
	//		nEndAngle---End Angle, Specifies A 32-bit long signed integer.  
	//		nColCnt---Column Count, Specifies A 32-bit long signed integer.
	CFODrawShape* CreateDonutSegment(FOPRect  &  aRect,
		long         nWidth,
		long          nCol,
		long          nRow,
		long          nStartAngle,
		long          nEndAngle,
		long          nColCnt );
	
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	
    // --------------------------------------------------------
    // members params
    // --------------------------------------------------------
	
 
	// Bar Y1, This member specify E-XD++ CFOPChartBarDescriptor object.  
	CFOPChartBarDescriptor  m_aBarY1;
 
	// Bar Y2, This member specify E-XD++ CFOPChartBarDescriptor object.  
	CFOPChartBarDescriptor  m_aBarY2;
	
 
	// Clear Depth, This member sets TRUE if it is right.  
	BOOL					m_bClearDepth;
 
	// New Or Load Completed, This member sets TRUE if it is right.  
    BOOL					m_bNewOrLoadCompleted;
 
	// Attributes Automatic Storage, This member sets TRUE if it is right.  
    BOOL					m_bAttrAutoStorage;
	
	// save data in buffer while editing chart
 
	// Chart Data Buffered, This member maintains a pointer to the object CFOPChartData.  
    CFOPChartData*			m_pChartDataBuffered;
	
 
	// Chart Reference Out Device, This member maintains a pointer to the object CDC.  
	CDC*					m_pChartRefOutDev;
 
	// Chart Status, Specify a A 32-bit signed integer.  
	long					m_nChartStatus;
	
 
	// Chart Shape List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList*		m_pChartShapeList;
 
	// Resize Pie, This member sets TRUE if it is right.  
    BOOL					m_bResizePie;
 
	// Pie Radius, Specify a A 32-bit signed integer.  
	long					m_nPieRadius;
	
 
	// Logical Book, This member maintains a pointer to the object CFOPDataLogBook.  
	CFOPDataLogBook*		m_pLogBook;
	
 
	// Bar Percent Width, Specify a A 32-bit signed integer.  
	long					m_nBarPercentWidth;
 
	// Number Lines In Column Chart, Specify a A 32-bit signed integer.  
	long					m_nNumLinesInColChart;
 
	// Default Color Set, Specify a A 32-bit signed integer.  
	long					m_nDefaultColorSet;
	
 
	// Chart Rectangle, This member specify FOPRect object.  
	FOPRect					m_rcChartRect;
 
	// Initial Size, This member specify FOPSize object.  
	FOPSize					m_szInitialSize;
	
 
	// Chart Data, This member maintains a pointer to the object CFOPChartData.  
	CFOPChartData*			pChartData;
 
	// Minimize Data, This member specify double object.  
	double					m_fMinData;
 
	// Maximize Data, This member specify double object.  
	double					m_fMaxData;
 
	// Ambient Intensity, This member specify double object.  
	double					m_fAmbientIntensity;
 
	// Ambient Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crAmbientColor;
 
	// Spot Intensity, This member specify double object.  
	double					m_dSpotIntensity;
 
	// Spot Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crSpotColor;
 
	// Chart Style, This member specify FOP_CHART_STYLE object.  
	FOP_CHART_STYLE			eChartStyle;
 
	// Old Chart Style, This member specify FOP_CHART_STYLE object.  
	FOP_CHART_STYLE			eOldChartStyle;
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						eChartLinePoints[ FOP_LINE_POINT_COUNT ];
	
 
	// Default Colors, This member maintains a pointer to the object FOPList.  
	FOPList*				pDefaultColors;
	
 
	// Text Scalable, This member sets TRUE if it is right.  
	BOOL					m_bTextScalable;
 
	// Is Copied, This member sets TRUE if it is right.  
	BOOL					m_bIsCopied;
 
	// Legend Visible, This member sets TRUE if it is right.  
	BOOL					m_bLegendVisible;
 
	// Show Average, This member sets TRUE if it is right.  
	BOOL					m_bShowAverage;
 
	// Indicate Percent, This member specify double object.  
	double					m_fIndicatePercent;
 
	// Indicate Big Error, This member specify double object.  
	double					m_fIndicateBigError;
 
	// Indicate Plus, This member specify double object.  
	double					m_fIndicatePlus;
 
	// Indicate Minus, This member specify double object.  
	double					m_fIndicateMinus;
 
	// Spline Depth, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nSplineDepth;
 
	// Granularity, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nGranularity;

 
	// Mark Len, Specify a A 32-bit signed integer.  
	long					m_nMarkLen;
 
	// Pie Height, Specify a A 32-bit signed integer.  
	long					m_nPieHeight;
 
	// Pie Seg Ofs, This member maintains a pointer to the object long.  
	long*					m_pPieSegOfs;
 
	// Pie Seg Count, This member specify short object.  
	short					m_nPieSegCount;
 
	// X Angle, This member specify short object.  
	short					m_nXAngle;
 
	// Y Angle, This member specify short object.  
	short					m_nYAngle;
 
	// Z Angle, This member specify short object.  
	short					m_nZAngle;
	
 
	// Can Rebuild, This member sets TRUE if it is right.  
	BOOL					m_bCanRebuild;
	
 
	// Show Main Title, This member sets TRUE if it is right.  
	BOOL					m_bShowMainTitle;
 
	// Show Child Title, This member sets TRUE if it is right.  
	BOOL					m_bShowSubTitle;
 
	// Show X Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bShowXAxisTitle;
 
	// Show Y Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bShowYAxisTitle;
 
	// Show Z Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bShowZAxisTitle;
	
 
	// Main Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strMainTitle;
 
	// Child Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSubTitle;
 
	// X Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strXAxisTitle;
 
	// Y Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strYAxisTitle;
 
	// Z Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strZAxisTitle;
	
 
	// Show X Grid Main, This member sets TRUE if it is right.  
	BOOL					m_bShowXGridMain;
 
	// Show X Grid Help, This member sets TRUE if it is right.  
	BOOL					m_bShowXGridHelp;
 
	// Show Y Grid Main, This member sets TRUE if it is right.  
	BOOL					m_bShowYGridMain;
 
	// Show Y Grid Help, This member sets TRUE if it is right.  
	BOOL					m_bShowYGridHelp;
 
	// Show Z Grid Main, This member sets TRUE if it is right.  
	BOOL					m_bShowZGridMain;
 
	// Show Z Grid Help, This member sets TRUE if it is right.  
	BOOL					m_bShowZGridHelp;
	
	// show description for all series
 
	// Show Data Descr, This member sets TRUE if it is right.  
	BOOL					m_bShowDataDescr;
	
 
	// Chart X Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*          pChartXAxis;
 
	// Chart Y Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*          pChartYAxis;
 
	// Chart Z Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*          pChartZAxis;
	
	// secondary x axis
 
	// Chart A Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*          pChartAAxis;  
	
	// secondary y axis
 
	// Chart B Axis, This member maintains a pointer to the object CFOPChartAxis.  
	CFOPChartAxis*          pChartBAxis;    
	
	
 
	// Data Descr, This member specify FOPChartDataDescr object.  
	FOPChartDataDescr		eDataDescr;
 
	// Show Sym, This member sets TRUE if it is right.  
	BOOL					m_bShowSym;
 
	// Switch Data, This member sets TRUE if it is right.  
	BOOL					m_bSwitchData;
	
	// BuildChart does nothing if this is true
 
	// No Build Chart, This member sets TRUE if it is right.  
	BOOL					m_bNoBuildChart;       
	
	// This is set when BuildChart was called and m_bNoBuildChart was TRUE
 
	// Should Build Chart, This member sets TRUE if it is right.  
	BOOL					m_bShouldBuildChart;
 
	// Read Error, This member sets TRUE if it is right.  
	BOOL					m_bReadError;
 
	// Is Initialized, This member sets TRUE if it is right.  
	BOOL					m_bIsInitialized;
	
 
	// Format X Axis Text In Multiple Lines If Necessary, This member sets TRUE if it is right.  
	BOOL					m_bFormatXAxisTextInMultipleLinesIfNecessary;
 
	// Format Y Axis Text In Multiple Lines If Necessary, This member sets TRUE if it is right.  
	BOOL					m_bFormatYAxisTextInMultipleLinesIfNecessary;
 
	// Format Z Axis Text In Multiple Lines If Necessary, This member sets TRUE if it is right.  
	BOOL					m_bFormatZAxisTextInMultipleLinesIfNecessary;
 
	// Format Legend Text In Multiple Lines If Necessary, This member sets TRUE if it is right.  
	BOOL					m_bFormatLegendTextInMultipleLinesIfNecessary;
	
    /// maximum number of lines for text break
 
	// X Axis Text Maximum Number Of Lines, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nXAxisTextMaximumNumberOfLines;
 
	// Y Axis Text Maximum Number Of Lines, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nYAxisTextMaximumNumberOfLines;
 
	// Z Axis Text Maximum Number Of Lines, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nZAxisTextMaximumNumberOfLines;
	
 
	// Width Of First X Axis Text, Specify a A 32-bit signed integer.  
	long					m_nWidthOfFirstXAxisText;
 
	// Width Of Last X Axis Text, Specify a A 32-bit signed integer.  
	long					m_nWidthOfLastXAxisText;
	
    // positions of chart objects
 
	// Title Top Center, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptTitleTopCenter;
 
	// Child Title Top Center, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptSubTitleTopCenter;
 
	// Diagram Rectangle, This member specify FOPRect object.  
	FOPRect					m_rcDiagramRectangle;
 
	// Last Diagram Rectangle, This member specify FOPRect object.  
    FOPRect					m_rcLastDiagramRectangle;
 
	// Legend Top Left, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptLegendTopLeft;
	
 
	// Title X Axis Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptTitleXAxisPosition;
 
	// Title Y Axis Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptTitleYAxisPosition;
 
	// Title Z Axis Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint				m_ptTitleZAxisPosition;
	
 
	// Adjust X Axes Title, This member specify FOPChartAdjust object.  
	FOPChartAdjust			m_eAdjustXAxesTitle;
 
	// Adjust Y Axes Title, This member specify FOPChartAdjust object.  
	FOPChartAdjust			m_eAdjustYAxesTitle;
 
	// Adjust Z Axes Title, This member specify FOPChartAdjust object.  
	FOPChartAdjust			m_eAdjustZAxesTitle;
	
    // On resize objects remember their position relatively to the page if
    // this member is TRUE.  For some objects the upper left corner is
    // preserved for others the center position
 
	// Use Relative Positions For Chart Groups, This member sets TRUE if it is right.  
    BOOL					m_bUseRelativePositionsForChartGroups;
	
    /// on manual move of chart objects the calculation of space left has to be changed
 
	// Adjust Margins For Legend, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForLegend;
 
	// Adjust Margins For Main Title, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForMainTitle;
 
	// Adjust Margins For Child Title, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForSubTitle;
 
	// Adjust Margins For X Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForXAxisTitle;
 
	// Adjust Margins For Y Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForYAxisTitle;
 
	// Adjust Margins For Z Axis Title, This member sets TRUE if it is right.  
	BOOL					m_bAdjustMarginsForZAxisTitle;
	
    /// keep track if objects have manually been repositioned
 
	// Diagram Has Been Moved Or Resized, This member sets TRUE if it is right.  
	BOOL					m_bDiagramHasBeenMovedOrResized;
 
	// Main Title Has Been Moved, This member sets TRUE if it is right.  
	BOOL					m_bMainTitleHasBeenMoved;
 
	// Child Title Has Been Moved, This member sets TRUE if it is right.  
	BOOL					m_bSubTitleHasBeenMoved;
 
	// Legend Has Been Moved, This member sets TRUE if it is right.  
	BOOL					m_bLegendHasBeenMoved;
 
	// X Axis Title Has Been Moved, This member sets TRUE if it is right.  
	BOOL					m_bXAxisTitleHasBeenMoved;
 
	// Y Axis Title Has Been Moved, This member sets TRUE if it is right.  
	BOOL					m_bYAxisTitleHasBeenMoved;
	
 
	// Initial Sizefor3d, This member specify FOPSize object.  
	FOPSize					m_szInitialSizefor3d;
	
	// test object for calculating the height of two rows
	// GetHeightOfnRows
 
	// Test Text Object, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*			m_pTestTextObj;
	
 
	// X Last Number Fmt, Specify a A 32-bit signed integer.  
	long					m_nXLastNumFmt;
 
	// Y Last Number Fmt, Specify a A 32-bit signed integer.  
	long					m_nYLastNumFmt;
 
	// B Last Number Fmt, Specify a A 32-bit signed integer.  
	long					m_nBLastNumFmt;
	
 
	// Delete Undo Action Notification From Draw, This member sets TRUE if it is right.  
	BOOL					m_bDeleteUndoActionNotificationFromDraw;
 
	// Change Notifications Enabled, Specify A Boolean value.  
    bool					m_bChangeNotificationsEnabled;
	
};

_FOLIB_INLINE const FOPSize& CFOPChartShape::InitialSize () const
{
	return m_szInitialSize;
}

_FOLIB_INLINE FOPSize& CFOPChartShape::InitialSize ()
{
	return m_szInitialSize;
}

_FOLIB_INLINE BOOL CFOPChartShape::GetFormatXAxisTextInMultipleLinesIfNecessary()
{
    return m_bFormatXAxisTextInMultipleLinesIfNecessary;
}

_FOLIB_INLINE void CFOPChartShape::SetDiagramRectangle( const FOPRect &rNewRect, bool bStoreLast )
{
    if( bStoreLast )
	{
        m_rcLastDiagramRectangle = m_rcDiagramRectangle;
	}
	
    m_rcDiagramRectangle = rNewRect;
}

_FOLIB_INLINE BOOL CFOPChartShape::IsDataSwitched() const
{
    if( IsDonutChart())
        return ! m_bSwitchData;
    else
        return m_bSwitchData;
}

_FOLIB_INLINE BOOL CFOPChartShape::IsDonutChart() const
{
    return ( eChartStyle == FOP_CHSTYLE_2D_DONUT1 ||
		eChartStyle == FOP_CHSTYLE_2D_DONUT2 );
};

#endif // !defined(FO_FOPCHARTSHAPE_H__2A371554_4E04_4832_BA25_8FAB5AEE6F51__INCLUDED_)
