//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPChartData.h: interface for the CFOPChartData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPCHARTDATA_H__92A2074C_8A74_4FB8_9C0F_0045F2BB23DC__INCLUDED_)
#define AFX_FOPCHARTDATA_H__92A2074C_8A74_4FB8_9C0F_0045F2BB23DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFOPChartData window

// Chart data type.
enum FOPChartDataId
{
	CHDATAID_NONE,
	CHDATAID_MEMCHART,
	CHDATAID_DYNCHART,
	CHDATAID_MEMCHART_PLUS
};

#define FOP_TRANS_NONE	0
#define FOP_TRANS_COL	1
#define FOP_TRANS_ROW	2
#define FOP_TRANS_ERROR 3


// Style of chart.
enum FOP_CHART_STYLE
{
	FOP_CHSTYLE_2D_LINE = 0,
		FOP_CHSTYLE_2D_STACKEDLINE,
		FOP_CHSTYLE_2D_PERCENTLINE,
		FOP_CHSTYLE_2D_COLUMN,
		FOP_CHSTYLE_2D_STACKEDCOLUMN,
		FOP_CHSTYLE_2D_PERCENTCOLUMN,
		FOP_CHSTYLE_2D_BAR,
		FOP_CHSTYLE_2D_STACKEDBAR,
		FOP_CHSTYLE_2D_PERCENTBAR,
		FOP_CHSTYLE_2D_AREA,
		FOP_CHSTYLE_2D_STACKEDAREA,
		FOP_CHSTYLE_2D_PERCENTAREA,
		FOP_CHSTYLE_2D_PIE,
		FOP_CHSTYLE_2D_XY,
		FOP_CHSTYLE_2D_LINESYMBOLS,
		FOP_CHSTYLE_2D_STACKEDLINESYM,
		FOP_CHSTYLE_2D_PERCENTLINESYM,
		FOP_CHSTYLE_2D_XYSYMBOLS,
		FOP_CHSTYLE_2D_DONUT1,
		FOP_CHSTYLE_2D_DONUT2,
		FOP_CHSTYLE_2D_PIE_SEGOF1,
		FOP_CHSTYLE_2D_PIE_SEGOFALL,
		FOP_CHSTYLE_2D_NET,
		FOP_CHSTYLE_2D_NET_SYMBOLS,
		FOP_CHSTYLE_2D_NET_STACK,
		FOP_CHSTYLE_2D_NET_SYMBOLS_STACK,
		FOP_CHSTYLE_2D_NET_PERCENT,
		FOP_CHSTYLE_2D_NET_SYMBOLS_PERCENT,
		FOP_CHSTYLE_2D_CUBIC_SPLINE,
		FOP_CHSTYLE_2D_CUBIC_SPLINE_SYMBOL,
		FOP_CHSTYLE_2D_B_SPLINE,
		FOP_CHSTYLE_2D_B_SPLINE_SYMBOL,
		FOP_CHSTYLE_2D_CUBIC_SPLINE_XY,
		FOP_CHSTYLE_2D_CUBIC_SPLINE_SYMBOL_XY,
		FOP_CHSTYLE_2D_B_SPLINE_XY,
		FOP_CHSTYLE_2D_B_SPLINE_SYMBOL_XY,
		FOP_CHSTYLE_2D_XY_LINE,
		FOP_CHSTYLE_2D_LINE_COLUMN,
		FOP_CHSTYLE_2D_LINE_STACKEDCOLUMN,
		FOP_CHSTYLE_2D_STOCK_1,
		FOP_CHSTYLE_2D_STOCK_2,
		FOP_CHSTYLE_2D_STOCK_3,
		FOP_CHSTYLE_2D_STOCK_4,
		FOP_CHSTYLE_CUSTOM
};

// Chart legend position.
enum FOPChartLegendPos
{
	FOP_CHLEGEND_NONE,
	FOP_CHLEGEND_LEFT,
	FOP_CHLEGEND_TOP,
	FOP_CHLEGEND_RIGHT,
	FOP_CHLEGEND_BOTTOM,
	FOP_CHLEGEND_NONE_TOP,
	FOP_CHLEGEND_NONE_LEFT,
	FOP_CHLEGEND_NONE_RIGHT,
	FOP_CHLEGEND_NONE_BOTTOM
};

#define FOP_SPLINE_NONE  0
#define FOP_SPLINE_CUBIC 1
#define FOP_SPLINE_B     2

#define FOP_TEXTHEIGHT_OFS_TWO		2
#define FOP_DEFAULT_COLCNT_THREE	3
#define FOP_DEFAULT_ROWCNT_FOUR		4

// base diagram types
#define FOP_CHTYPE_INVALID			0

#define FOP_CHTYPE_LINE				1
#define FOP_CHTYPE_LINESYMB			2	// this one has to be removed.
#define FOP_CHTYPE_AREA				3
#define FOP_CHTYPE_COLUMN			4	// is also a bar-type
#define FOP_CHTYPE_BAR				5
#define FOP_CHTYPE_CIRCLE			6
#define FOP_CHTYPE_XY				7
#define FOP_CHTYPE_NET				8
#define FOP_CHTYPE_DONUT			9
#define FOP_CHTYPE_STOCK		   10
#define FOP_CHTYPE_ADDIN		   11

#define FOP_SETLINES_BLACK			1
#define FOP_SETLINES_FILLCOLOR		2
#define FOP_SETLINES_COMPAT			3
#define FOP_SETLINES_REVERSE		4

#define FOP_SYMBOLMODE_LEGEND       1   // symbol for legend (default)
#define FOP_SYMBOLMODE_DESCRIPTION  2   // symbol for series data description
#define FOP_SYMBOLMODE_LINE         3   // unused (line as symbol)
#define FOP_SYMBOLMODE_ROW          4   // unused (symbol for series)

#define FOP_SETFLAG( status, flag )   (status)|= (flag)
#define FOP_RESETFLAG( status, flag )   (status) = ((status) | (flag)) - (flag)
#define FOP_ISFLAGSET( status, flag )	(((status) & (flag)) != 0)

#define FOP_CHS_USER_QUERY			0	// ask for sorting data for xy charts
#define FOP_CHS_USER_NOQUERY		1	// do not ask for sorting
#define FOP_CHS_KEEP_ADDIN			2	// if this flag is set a change of chart
										// type keeps the reference to the AddIn
#define FOP_CHS_NO_ADDIN_REFRESH	4	// used to avoid recursion in BuildChart

#define FOP_CHART_NUM_SYMBOLS		8	// number of different polygons as symbols

#define FOP_CHART_AXIS_PRIMARY_X	1	// never change these defines (persistent)
#define FOP_CHART_AXIS_PRIMARY_Y	2
#define FOP_CHART_AXIS_PRIMARY_Z	3
#define FOP_CHART_AXIS_SECONDARY_Y	4
#define FOP_CHART_AXIS_SECONDARY_X	5

#define FOP_SYMBOLTYPE_NONE	      (-3)
#define FOP_SYMBOLTYPE_AUTO	      (-2)
#define FOP_SYMBOLTYPE_BRUSHITEM  (-1)
#define FOP_SYMBOLTYPE_UNKNOWN  (-100)

////////////////////////////////////////////////////////////////////
// This struct contains information about selection in the chart, for chart selection.

struct FOPChartSelectionInfo
{
	// Constructor.
	FOPChartSelectionInfo() : nRow(0), nCol(0), fValue(0.0), nValue(0), nSelection(0) {}

	// Constructor.
	FOPChartSelectionInfo(long sel) : nRow(0), nCol(0), fValue(0.0), nValue(0), nSelection(sel) {}

	// Operator ==
	BOOL operator == (const FOPChartSelectionInfo& s) const
	{
		return nRow				== s.nRow
			&& nCol				== s.nCol
			&& nSelection		== s.nSelection
			&& fValue			== s.fValue
			&& nValue			== s.nValue
			&& aSelectionColor	== s.aSelectionColor;
	}

	// Row
	long	nRow;

	// Column
	long	nCol;

	// value.
	double	fValue;

	// value
	long	nValue;

	// Selection number
	long	nSelection;

	// Selection color.
	COLORREF	aSelectionColor;
};

/////////////////////////////////////////////////////
// CFOPChartType -- chart type.

 
//===========================================================================
// Summary:
//      To use a CFOPChartType object, just call the constructor.
//      F O P Chart Type
//===========================================================================

class FO_EXT_CLASS CFOPChartType
{
protected:
 
	// Has Lines, This member sets TRUE if it is right.  
	BOOL		bHasLines;
 
	// Is Donut, This member sets TRUE if it is right.  
	BOOL		bIsDonut;
 
	// Is Percent, This member sets TRUE if it is right.  
	BOOL		bIsPercent;
 
	// Is3 D, This member sets TRUE if it is right.  
	BOOL		bIs3D;
 
	// Is Deep3 D, This member sets TRUE if it is right.  
	BOOL		bIsDeep3D;
 
	// Is Vertical, This member sets TRUE if it is right.  
	BOOL		bIsVertical;
 
	// Is Stacked, This member sets TRUE if it is right.  
	BOOL		bIsStacked;

 
	// Has Volume, This member sets TRUE if it is right.  
	BOOL		bHasVolume;
 
	// Has Up Down, This member sets TRUE if it is right.  
	BOOL		bHasUpDown;
 
	// Symbol Type, This member specify INT32 object.  
	INT32		nSymbolType;
 
	// Shape Type, This member specify INT32 object.  
	INT32		nShapeType;

 
	// Spline Type, Specify a A 32-bit signed integer.  
	long		nSplineType;
 
	// Special Type, Specify a A 32-bit signed integer.  
	long		nSpecialType;
 
	// Base Type, Specify a A 32-bit signed integer.  
	long		nBaseType;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.

	// Init or not
    void Init();

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Type, Constructs a CFOPChartType object.
	//		Returns A  value (Object).
	CFOPChartType()                                { Init(); }

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Type, Constructs a CFOPChartType object.
	//		Returns A  value (Object).  
	// Parameters:
	//		eStyle---eStyle, Specifies a const FOP_CHART_STYLE eStyle object(Value).
	CFOPChartType( const FOP_CHART_STYLE eStyle )  { Init(); SetType( eStyle ); }

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Chart Type, Destructor of class CFOPChartType
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPChartType(){};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clean Up, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CleanUp();

	// Obtain chart style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chart Style, Returns the specified value.
	//		Returns A FOP_CHART_STYLE value (Object).
	FOP_CHART_STYLE GetChartStyle() const;

	// Change chart type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOPChartType
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	void SetType(const FOP_CHART_STYLE eChartStyle);

	// Change the default base type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Base Type, Sets a specify value to current class CFOPChartType
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nDefault---nDefault, Specifies A 32-bit long signed integer.
	BOOL SetDefaultBaseType(long nDefault=-1);

	// Change base type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Base Type, Sets a specify value to current class CFOPChartType
	// Parameters:
	//		nBase---nBase, Specifies A 32-bit long signed integer.
	void SetBaseType(const long nBase) {nBaseType=nBase;};

	// Obtain base type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetBaseType() const           {return nBaseType;};

	// Obtain base chart type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	long GetBaseType(const FOP_CHART_STYLE eChartStyle) const;

	// Has lines or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasLines() const {return bHasLines;};

	// Has lines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL HasLines(const FOP_CHART_STYLE eChartStyle) const;

	// Is donut or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Donut, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsDonut() const {return bIsDonut;};

	// Is donut or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Donut, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL IsDonut(const FOP_CHART_STYLE eChartStyle) const;

	// Is percent style or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Percent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL IsPercent(const FOP_CHART_STYLE eChartStyle) const;

	// Is percent style or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Percent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsPercent()    const {return bIsPercent;};

	// Is 3d style chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is3 D, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL Is3D(const FOP_CHART_STYLE eChartStyle) const;

	// Is 3d style chart or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is3 D, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL Is3D()         const {return bIs3D;};

	// Has splines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Splines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasSplines() const {return nSplineType!=FOP_SPLINE_NONE;};

	// Has splines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Splines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL HasSplines(const FOP_CHART_STYLE eChartStyle) const;

	// Obtain spline type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spline Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetSplineType() const {return nSplineType;};

	// Obtain spline type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spline Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	long GetSplineType(const FOP_CHART_STYLE eChartStyle) const;

	// Is vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Vertical, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsVertical() const {return bIsVertical;};

	// Is vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Vertical, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL IsVertical(const FOP_CHART_STYLE eChartStyle) const;

	// Is stack or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Stacked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL IsStacked(const FOP_CHART_STYLE eChartStyle) const;

	// Is stack or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Stacked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsStacked()    const {return bIsStacked;};

	// Has symbols or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Symbols, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL HasSymbols(const FOP_CHART_STYLE eChartStyle) const;

	// Has symbols or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Symbols, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasSymbols()   const {return nSymbolType!=FOP_SYMBOLTYPE_NONE;};

	// Is deep 3d or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Deep3 D, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		eChartStyle---Chart Style, Specifies a const FOP_CHART_STYLE eChartStyle object(Value).
	BOOL IsDeep3D(const FOP_CHART_STYLE eChartStyle) const;

	// Is deep 3d or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Deep3 D, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsDeep3D()     const {return bIsDeep3D;};
};

////////////////////////////////////////////
// Chart memory data.

 
//===========================================================================
// Summary:
//     The CFOPChartData class derived from CObject
//      F O P Chart Data
//===========================================================================

class FO_EXT_CLASS CFOPChartData : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPChartData---F O P Chart Data, Specifies a E-XD++ CFOPChartData object (Value).
	DECLARE_SERIAL(CFOPChartData)
// Construction
protected:
 
	// Last Select Information Return, Specify a A 32-bit signed integer.  
	long					m_nLastSelInfoReturn;
 
	// Reference Count, Specify a A 32-bit signed integer.  
	ULONG					nRefCount;

 
	// Translated, Specify a A 32-bit signed integer.  
	long					m_nTranslated;
 
	// Row Count, This member specify short object.  
	short					m_nRowCnt;
 
	// Column Count, This member specify short object.  
	short					m_nColCnt;
 
	// Main Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strMainTitle;
 
	// Child Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSubTitle;
 
	// X Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strXAxisTitle;
 
	// Y Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strYAxisTitle;
 
	// Z Axis Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strZAxisTitle;
 
	// Data Type, This member specify short object.  
	short					eDataType;
 
	// Some Data1, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSomeData1;
 
	// Some Data2, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSomeData2;
 
	// Some Data3, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSomeData3;
 
	// Some Data4, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strSomeData4;
 
	// Data, This member maintains a pointer to the object double.  
	double					*pData;
 
	// Column Text, The member supports arrays of CString objects.  
	CStringArray			m_arColText;
 
	// Row Text, The member supports arrays of CString objects.  
	CStringArray			m_arRowText;
 
	// I D, This member specify FOPChartDataId object.  
	FOPChartDataId			myID;

public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Data, Constructs a CFOPChartData object.
	//		Returns A  value (Object).
	CFOPChartData();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Data, Constructs a CFOPChartData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		myID---I D, Specifies a FOPChartDataId myID object(Value).
	CFOPChartData(FOPChartDataId myID);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Data, Constructs a CFOPChartData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCols---nCols, Specifies a short nCols object(Value).  
	//		nRows---nRows, Specifies a short nRows object(Value).
	CFOPChartData(short nCols, short nRows);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Chart Data, Constructs a CFOPChartData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rMemChart---Memory Chart, Specifies a const CFOPChartData& rMemChart object(Value).
	CFOPChartData(const CFOPChartData& rMemChart);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Chart Data, Destructor of class CFOPChartData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPChartData();

	// Quick sort table
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort Table Cols, .
	// Parameters:
	//		l---Specifies A 32-bit long signed integer.  
	//		r---Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void QuickSortTableCols (long l,
							 long r,
							 long nRow);

	// Quick sort table
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort Table Rows, .
	// Parameters:
	//		l---Specifies A 32-bit long signed integer.  
	//		r---Specifies A 32-bit long signed integer.  
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void QuickSortTableRows (long l,
							 long r,
							 long nCol);

	// Quick sort table
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort Cols, .
	// Parameters:
	//		l---Specifies A 32-bit long signed integer.  
	//		r---Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void QuickSortCols (long l,
						long r,
						long nRow);

	// Quick sort table
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort Rows, .
	// Parameters:
	//		l---Specifies A 32-bit long signed integer.  
	//		r---Specifies A 32-bit long signed integer.  
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void QuickSortRows (long l,
						long r,
						long nCol);

	// Change read only property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Read Only, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		bNewValue---New Value, Specifies A Boolean value.
	void SetReadOnly( BOOL bNewValue );

	// Is read only or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Read Only, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsReadOnly() { return m_bReadOnly; }

public:
 
	// Row Number Fmt Id, This member maintains a pointer to the object long.  
	long		*pRowNumFmtId;
 
	// Column Number Fmt Id, This member maintains a pointer to the object long.  
	long		*pColNumFmtId;

 
	// Row Table, This member maintains a pointer to the object long.  
	long		*pRowTable;
 
	// Column Table, This member maintains a pointer to the object long.  
	long		*pColTable;
 
	// Selection Information, This member specify FOPChartSelectionInfo object.  
	FOPChartSelectionInfo aSelectionInfo;
 
	// Read Only, This member sets TRUE if it is right.  
	BOOL		m_bReadOnly;

// Implementation
public:

	// initialize number format, -1 means unset
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Number Fmt, Call InitNumFmt after creating a new object.

	void InitNumFmt();

	// transfer chart selection.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection Information, Returns the specified value.
	//		Returns A const FOPChartSelectionInfo& value (Object).
	const FOPChartSelectionInfo& GetSelectionInfo() const { return aSelectionInfo; }

	// Section
	
	//-----------------------------------------------------------------------
	// Summary:
	// Submit Selection, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		aInfo---aInfo, Specifies a const FOPChartSelectionInfo& aInfo object(Value).
	long SubmitSelection(const FOPChartSelectionInfo& aInfo);

	// methods for translation of data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transparent Column, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		bUp---bUp, Specifies A Boolean value.
	BOOL TransCol(long nCol,BOOL bUp=TRUE);

	// Translation row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transparent Row, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bUp---bUp, Specifies A Boolean value.
	BOOL TransRow(long nRow,BOOL bUp=TRUE);

	// Reset translation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Translation, Called this function to empty a previously initialized CFOPChartData object.
	// Parameters:
	//		*pTable---*pTable, A pointer to the long  or NULL if the call failed.  
	//		nCnt---nCnt, Specifies A 32-bit long signed integer.
	void ResetTranslation(long *pTable,long nCnt);

	// Verify translation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Verify Translation, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL VerifyTranslation();

	// Obtain translation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Translation, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetTranslation() const { return m_nTranslated; }

	// Update translation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Translation, Call this member function to update the object.
	// Parameters:
	//		*pTable---*pTable, A pointer to the long  or NULL if the call failed.  
	//		nCnt---nCnt, Specifies A 32-bit long signed integer.
	void UpdateTranslation(long *pTable,long nCnt);

	// Obtain translation data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Data, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	double GetTransData(long nCol,long nRow);

	// Obtain translation data by percent format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Data In Percent, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		bRowData---Row Data, Specifies A Boolean value.
	double GetTransDataInPercent(long nCol ,long nRow,BOOL bRowData) const;

	// Obtain translation text by column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Column Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	CString GetTransColText(long nCol) const;

	// Obtain translation text by row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Row Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	CString GetTransRowText(long nRow) const;

	// Obtain the min and max values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Minimize Maximize Value, .
	// Parameters:
	//		&dMin---&dMin, Specifies a double &dMin object(Value).  
	//		&dMax---&dMax, Specifies a double &dMax object(Value).
	void CalcMinMaxValue(double &dMin, double &dMax);

	// Obtain row translation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Translation, Returns the specified value.
	//		Returns a pointer to the object const long ,or NULL if the call failed
	const long *GetRowTranslation() const { return pRowTable; }

	// Obtain column translation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Translation, Returns the specified value.
	//		Returns a pointer to the object const long ,or NULL if the call failed
	const long *GetColTranslation() const { return pColTable; }

	// Obtain row number table
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Number Fmt Table, Returns the specified value.
	//		Returns a pointer to the object const long,or NULL if the call failed
	const long* GetRowNumFmtTable() const { return pRowNumFmtId; }

	// Obtain column number table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Number Fmt Table, Returns the specified value.
	//		Returns a pointer to the object const long,or NULL if the call failed
	const long* GetColNumFmtTable() const { return pColNumFmtId; }
	
	// Use these four methods with care! The arrays MUST have the correct size!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Translation, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		pTransTable---Transparent Table, A pointer to the const long or NULL if the call failed.
	void SetRowTranslation( const long* pTransTable );

	// Change column translation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Translation, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		pTransTable---Transparent Table, A pointer to the const long or NULL if the call failed.
	void SetColTranslation( const long* pTransTable );

	// Change row number table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Number Fmt Table, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		pNumFmtTable---Number Fmt Table, A pointer to the const long or NULL if the call failed.
	void SetRowNumFmtTable( const long* pNumFmtTable );

	// Change column number table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Number Fmt Table, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		pNumFmtTable---Number Fmt Table, A pointer to the const long or NULL if the call failed.
	void SetColNumFmtTable( const long* pNumFmtTable );

	// this is only valid if the corresponding translation table was set correctly!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Translation, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nTrans---nTrans, Specifies A 32-bit long signed integer.
	void SetTranslation( long nTrans ) { m_nTranslated = nTrans; }

	// Obtain table index by column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Table Index Column, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	long GetTableIndexCol(long nCol) const;

	// Obtain table index by row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Table Index Row, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long GetTableIndexRow(long nRow) const;

	// Swap row translation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Row Translation, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		n1---Specifies A 32-bit long signed integer.  
	//		n2---Specifies A 32-bit long signed integer.
	BOOL SwapRowTranslation(long n1, long n2);

	// Swap column tranlation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Column Translation, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		n1---Specifies A 32-bit long signed integer.  
	//		n2---Specifies A 32-bit long signed integer.
	BOOL SwapColTranslation(long n1, long n2);

	// Change row number format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Number Format Id Row, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.  
	//		nFmtId---Fmt Id, Specifies A 32-bit long signed integer.
	void SetNumFormatIdRow( const long nRow, const long nFmtId )	{ if( pRowNumFmtId && nRow < m_nRowCnt ) pRowNumFmtId[ nRow ] = nFmtId; }

	// Change column number format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Number Format Id Column, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.  
	//		nFmtId---Fmt Id, Specifies A 32-bit long signed integer.
	void SetNumFormatIdCol( const long nCol, const long nFmtId )	{ if( pColNumFmtId && nCol < m_nColCnt ) pColNumFmtId[ nCol ] = nFmtId; }

	// Obtain row number format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Format Id Row, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long GetNumFormatIdRow( const long nRow ) const					{ return ( pRowNumFmtId && nRow < m_nRowCnt )? pRowNumFmtId[ nRow ]: -1; }

	// Obtain column number format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Format Id Column, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	long GetNumFormatIdCol( const long nCol ) const					{ return ( pColNumFmtId && nCol < m_nColCnt )? pColNumFmtId[ nCol ]: -1; }

	// Obtain translation number id by row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Number Format Id Row, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	long GetTransNumFormatIdRow( const long nRow ) const;

	// Obtain translation number id by column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Number Format Id Column, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	long GetTransNumFormatIdCol( const long nCol ) const;

	// Change none numeric data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Non Numeric Data, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		&rMemChart---Memory Chart, Specifies a const CFOPChartData &rMemChart object(Value).
	void SetNonNumericData(const CFOPChartData &rMemChart);

	// Change data type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data Type, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		eType---eType, Specifies a short eType object(Value).
	void SetDataType(short eType) { eDataType = eType; }

	// Obtain data type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data Type, Returns the specified value.
	//		Returns A short value (Object).
	short GetDataType() const { return eDataType; }

	// Obtain columns count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Count, Returns the specified value.
	//		Returns A short value (Object).
	short GetColCount() const { return m_nColCnt;	}

	// Obtain rows count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Count, Returns the specified value.
	//		Returns A short value (Object).
	short GetRowCount() const {	return m_nRowCnt;	}

	// Obtain main title text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Title, Returns the specified value.
	//		Returns a CString type value.
	const CString& GetMainTitle() const	{ return m_strMainTitle; }

	// Obtain sub title text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Title, Returns the specified value.
	//		Returns a CString type value.
	const CString& GetSubTitle() const	{ return m_strSubTitle; }

	// Change the main title text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Title, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		rText---rText, Specifies A CString type value.
	void SetMainTitle(const CString& rText) { m_strMainTitle = rText; }

	// Change the sub title text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Child Title, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		rText---rText, Specifies A CString type value.
	void SetSubTitle(const CString& rText) { m_strSubTitle = rText; }

	// Obtain x axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Axis Title, Returns the specified value.
	//		Returns a CString type value.
	const CString& GetXAxisTitle() const	{ return m_strXAxisTitle; }

	// Obtain y axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Axis Title, Returns the specified value.
	//		Returns a CString type value.
	const CString& GetYAxisTitle() const	{ return m_strYAxisTitle; }

	// Obtain z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Z Axis Title, Returns the specified value.
	//		Returns a CString type value.
	const CString& GetZAxisTitle() const	{ return m_strZAxisTitle; }
	
	// Change x axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set X Axis Title, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		rText---rText, Specifies A CString type value.
	void SetXAxisTitle(const CString& rText) { m_strXAxisTitle = rText; }

	// Change y axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Y Axis Title, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		rText---rText, Specifies A CString type value.
	void SetYAxisTitle(const CString& rText) { m_strYAxisTitle = rText; }

	// Change z axis title
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Z Axis Title, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		rText---rText, Specifies A CString type value.
	void SetZAxisTitle(const CString& rText) { m_strZAxisTitle = rText; }

	// Obtain column text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nCol---nCol, Specifies a short nCol object(Value).
	CString GetColText(short nCol) const;

	// Obtain row text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nRow---nRow, Specifies a short nRow object(Value).
	CString GetRowText(short nRow) const;

	// Obtain id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Id, Returns the specified value.
	//		Returns A FOPChartDataId value (Object).
	FOPChartDataId GetId() const { return myID; }

	// Obtain data with column and row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies a short nCol object(Value).  
	//		nRow---nRow, Specifies a short nRow object(Value).
	double GetData(short nCol, short nRow) const { return pData[nCol * m_nRowCnt + nRow]; }

	// Obtain data with percent format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data In Percent, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies a const short nCol object(Value).  
	//		nRow---nRow, Specifies a const short nRow object(Value).  
	//		bRowData---Row Data, Specifies A Boolean value.
	double GetDataInPercent(const short nCol , const short nRow, const BOOL bRowData) const;

	// Insert columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Cols, Inserts a child object at the given index..
	// Parameters:
	//		nAtCol---At Column, Specifies a short nAtCol object(Value).  
	//		nCount---nCount, Specifies a short nCount object(Value).
	void InsertCols(short nAtCol, short nCount);

	// Remove columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Cols, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nAtCol---At Column, Specifies a short nAtCol object(Value).  
	//		nCount---nCount, Specifies a short nCount object(Value).
	void RemoveCols(short nAtCol, short nCount);

	// Insert rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Rows, Inserts a child object at the given index..
	// Parameters:
	//		nAtRow---At Row, Specifies a short nAtRow object(Value).  
	//		nCount---nCount, Specifies a short nCount object(Value).
	void InsertRows(short nAtRow, short nCount);

	// Remove rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rows, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nAtRow---At Row, Specifies a short nAtRow object(Value).  
	//		nCount---nCount, Specifies a short nCount object(Value).
	void RemoveRows(short nAtRow, short nCount);

	// Swap columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Cols, .
	// Parameters:
	//		nAtCol1---At Col1, Specifies A integer value.  
	//		nAtCol2---At Col2, Specifies A integer value.
	void SwapCols(int nAtCol1, int nAtCol2);

	// Swap rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Rows, .
	// Parameters:
	//		nAtRow1---At Row1, Specifies A integer value.  
	//		nAtRow2---At Row2, Specifies A integer value.
	void SwapRows(int nAtRow1, int nAtRow2);

	// Change data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nCol---nCol, Specifies a short nCol object(Value).  
	//		nRow---nRow, Specifies a short nRow object(Value).  
	//		rVal---rVal, Specifies a const double& rVal object(Value).
	void SetData(short nCol, short nRow, const double& rVal)
	{ pData[nCol * m_nRowCnt + nRow] = rVal; }

	// Some data 1 string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data1, .
	//		Returns a CString type value.
	CString& SomeData1() { return m_strSomeData1; }

	// Some data 2 string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data2, .
	//		Returns a CString type value.
	CString& SomeData2() { return m_strSomeData2; }

	// Some data 3 string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data3, .
	//		Returns a CString type value.
	CString& SomeData3() { return m_strSomeData3; }

	// Some data 4 string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data4, .
	//		Returns a CString type value.
	CString& SomeData4() { return m_strSomeData4; }

	// Some data text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data1, .
	//		Returns a CString type value.
	const CString& SomeData1() const { return m_strSomeData1; }

	// Some data text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data2, .
	//		Returns a CString type value.
	const CString& SomeData2() const { return m_strSomeData2; }

	// Some data text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data3, .
	//		Returns a CString type value.
	const CString& SomeData3() const { return m_strSomeData3; }

	// Some data text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Some Data4, .
	//		Returns a CString type value.
	const CString& SomeData4() const { return m_strSomeData4; }

	// Change column text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Text, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nCol---nCol, Specifies a short nCol object(Value).  
	//		rText---rText, Specifies A CString type value.
	void SetColText(short nCol, const CString& rText) { m_arColText[nCol] = rText; }

	// Change row text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Text, Sets a specify value to current class CFOPChartData
	// Parameters:
	//		nRow---nRow, Specifies a short nRow object(Value).  
	//		rText---rText, Specifies A CString type value.
	void SetRowText(short nRow, const CString& rText) { m_arRowText[nRow] = rText; }

	// Sort table columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Table Cols, .
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void SortTableCols (long nRow = 0);

	// Sort table rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Table Rows, .
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void SortTableRows (long nCol = 0);

	// Sort columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Cols, .
	// Parameters:
	//		nRow---nRow, Specifies A 32-bit long signed integer.
	void SortCols (long nRow = 0);

	// Sort rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Rows, .
	// Parameters:
	//		nCol---nCol, Specifies A 32-bit long signed integer.
	void SortRows (long nCol = 0);

	// Increase reference count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Increase Reference Count, .

	void IncreaseRefCount() { nRefCount++; }

	// Decrease reference dount
	
	//-----------------------------------------------------------------------
	// Summary:
	// Decrease Reference Count, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL DecreaseRefCount();

	// get a string for default (column|row) labels
	// the indexes start at 0, but the text starts with "(Column|Row) 1"
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Column Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nCol---nCol, Specifies A integer value.
	CString GetDefaultColumnText( int nCol ) const;

	// Obtain default row text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Row Text, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nRow---nRow, Specifies A integer value.
	CString GetDefaultRowText( int nRow ) const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file
	virtual void Serialize(CArchive& ar);

};

#endif // !defined(AFX_FOPCHARTDATA_H__92A2074C_8A74_4FB8_9C0F_0045F2BB23DC__INCLUDED_)
