//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTABPAGEVIEW_H__1E4323A3_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
#define FO_FOTABPAGEVIEW_H__1E4323A3_F9E3_11D5_A4DE_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Normal class.
///////////////////////////////////////
#include "FOTabPageModel.h"
#include "FODrawView.h"
#include "FOPDrawWnd.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOTabPageView
//
// This is the view of VisioApp sample style application,most the control methods are defined
// within its parent class CFODrawView.
// 
// Call GetCurrentModel() to obtain the pointer of the data model.
//
// Most of the methods that control the canvas are defined within class CFODataModel.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOTabPageView class derived from CFODrawView
//      F O Tab Page View
//===========================================================================

class FO_EXT_CLASS CFOTabPageView : public CFODrawView
{
protected: 
	//-----------------------------------------------------------------------
	// Summary:
	// create from serialization only
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabPageView---F O Tab Page View, Specifies a E-XD++ CFOTabPageView object (Value).
	DECLARE_DYNCREATE(CFOTabPageView)

		//-----------------------------------------------------------------------
		// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Page View, Constructs a CFOTabPageView object.
	//		Returns A  value (Object).
	CFOTabPageView();

// Attributes

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the pointer of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel ,or NULL if the call failed
	virtual CFOTabPageModel *GetTabModel() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set tab page model pointer.
	// You must call this function in OnInitialUpdate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Model, Sets a specify value to current class CFOTabPageView
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	virtual void SetTabModel(
		// Pointer of data model.
		CFOTabPageModel *pModel
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Update current tab view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Tab View, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateTabView();

	//-----------------------------------------------------------------------
	// Summary:
	// Update scroll size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar Size, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateScrollBarSize();

public:

	// Allow multiple printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Multiple Printing, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL AllowMultiPrinting() const { return m_bPrintWithMultiModel; }

	// Allow multiple model printing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Multipage Printing, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void EnableMultipagePrinting(const BOOL &bMulti) { m_bPrintWithMultiModel = bMulti; }

	// Calculate the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Total Print Pages, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int CalcTotalPrintPages();

	// Print direct without showing the print setting dialog.
	virtual void PrintDirect();

	// Do print single model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print One Page, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&bPreview---&bPreview, Specifies A Boolean value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void DoPrintOnePage(CDC *pDC,CFOTabPageModel *pModel,const int &nIndex,
		BOOL &bPreview, CPrintInfo* pInfo);

	// Find model by page index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Page Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nCurPage---Current Page, Specifies A integer value.
	virtual CFOTabPageModel *FindPageModel(const int &nIndex,int &nCurPage);

	// Get model print position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Single Model Print Position, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&nPageNo---Page No, Specifies A integer value.
	CRect GetCurrentSingleModelPrintPosition(CFOTabPageModel *pModel,const int &nPageNo);

	// Draw single model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Single Model Print Objects, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&rcPrintPage---Print Page, Specifies A CRect type value.
	void DoDrawSingleModelPrintObjects(CDC *pDC,CFOTabPageModel *pModel,const CRect &rcPrintPage);

	// Prepare header and footer DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Prepare Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	void SingleModelPreparePrintHeaderFooterDC(CDC *pDC,CFOTabPageModel *pModel);

	// Print header and footer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Do Draw Print Header And Footer, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		nCurPage---Current Page, Specifies A integer value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void SingleModelDoDrawPrintHeaderAndFooter(CDC* pDC,CFOTabPageModel *pModel,
		const int& nCurPage, CPrintInfo* pInfo);

	// Clear header and footer DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Clear Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	void SingleModelClearPrintHeaderFooterDC(CDC *pDC,CFOTabPageModel *pModel);

	// Does it sharing scrollbar with parent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Share Scroll, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShareScroll() const;

	// Get Extend drawing size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extend Draw Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetExtendDrawSize();

	// Operations
public:
	
	// Override the scrollbar ctrl.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar , Returns the specified value.
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.
	CScrollBar*     GetScrollBarCtrl(int nBar) const;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTabPageView)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitialUpdate(); // called first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);

	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

	// Implementation
public:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Page View, Destructor of class CFOTabPageView
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabPageView();

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOTabPageView)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Enable print multiple models one time,all the data models within the data model manager
	// can be printed.
 
	// Print With Multiple Model, This member sets TRUE if it is right.  
	BOOL		m_bPrintWithMultiModel;
};

/////////////////////////////////////////////////////////////////////////////
// CFOTabPageWnd window -- this is the visio style multiple pages application's window canvas.
//			See sample: BasicApp.

 
//===========================================================================
// Summary:
//     The CFOTabPageWnd class derived from CFOPDrawWnd
//      F O Tab Page Window
//===========================================================================

class FO_EXT_CLASS CFOTabPageWnd : public CFOPDrawWnd
{
protected: 
	//-----------------------------------------------------------------------
	// Summary:
	// create from serialization only
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabPageWnd---F O Tab Page Window, Specifies a E-XD++ CFOTabPageWnd object (Value).
	DECLARE_DYNCREATE(CFOTabPageWnd)

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Page Window, Constructs a CFOTabPageWnd object.
	//		Returns A  value (Object).
	CFOTabPageWnd();

// Attributes
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the pointer of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel ,or NULL if the call failed
	virtual CFOTabPageModel *GetTabModel() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set tab page model pointer.
	// You must call this function in OnInitialUpdate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Model, Sets a specify value to current class CFOTabPageWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	virtual void SetTabModel(
		// Pointer of data model.
		CFOTabPageModel *pModel
		);

// Operations
public:
	// Update current tab view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Tab View, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateTabView();

	// Print direct without showing the print setting dialog.
	virtual void PrintDirect();

	// Obtain scroll bar control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar , Returns the specified value.
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.
	CScrollBar* GetScrollBarCtrl(int nBar) const;

	// Obtain the pointer of the scroll bar.
	// nBar -- SB_HORZ or SB_VERT
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar  Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.
	virtual CScrollBar* GetScrollBarCtrlExt(int nBar) const;

	// Obtain the pointer of the horz scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Scroll Bar, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetHScrollBar();
	
	// Obtain the pointer of the vertical scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get V Scroll Bar, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetVScrollBar();

	// Obtain the pointer of the horz scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Scroll Bar1, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetHScrollBar1() const;
	
	// Obtain the pointer of the vertical scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get V Scroll Bar1, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetVScrollBar1() const;
	
	// Does it sharing scrollbar with parent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Share Scroll, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShareScroll() const;

public:

	// Obtain the default virtual origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Origin Offset, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetCanvasOriginOffset() const;

protected:

	// Enable print multiple models one time,all the data models within the data model manager
	// can be printed.
 
	// Print With Multiple Model, This member sets TRUE if it is right.  
	BOOL		m_bPrintWithMultiModel;

public:

	// Allow multiple printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Multiple Printing, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL AllowMultiPrinting() const { return m_bPrintWithMultiModel; }

	// Allow multiple model printing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Multipage Printing, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void EnableMultipagePrinting(const BOOL &bMulti) { m_bPrintWithMultiModel = bMulti; }

	// Calc the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Total Print Pages, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int CalcTotalPrintPages();

	// Do print single model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print One Page, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&bPreview---&bPreview, Specifies A Boolean value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void DoPrintOnePage(CDC *pDC,CFOTabPageModel *pModel,const int &nIndex,
		BOOL &bPreview, CPrintInfo* pInfo);

	// Find model by page index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Page Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nCurPage---Current Page, Specifies A integer value.
	virtual CFOTabPageModel *FindPageModel(const int &nIndex,int &nCurPage);

	// Get model print position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Single Model Print Position, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&nPageNo---Page No, Specifies A integer value.
	CRect GetCurrentSingleModelPrintPosition(CFOTabPageModel *pModel,const int &nPageNo);

	// Draw single model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Single Model Print Objects, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		&rcPrintPage---Print Page, Specifies A CRect type value.
	void DoDrawSingleModelPrintObjects(CDC *pDC,CFOTabPageModel *pModel,const CRect &rcPrintPage);

	// Prepare header and footer DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Prepare Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	void SingleModelPreparePrintHeaderFooterDC(CDC *pDC,CFOTabPageModel *pModel);

	// Print header and footer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Do Draw Print Header And Footer, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		nCurPage---Current Page, Specifies A integer value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void SingleModelDoDrawPrintHeaderAndFooter(CDC* pDC,CFOTabPageModel *pModel,
		const int& nCurPage, CPrintInfo* pInfo);

	// Clear header and footer DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Clear Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.
	void SingleModelClearPrintHeaderFooterDC(CDC *pDC,CFOTabPageModel *pModel);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTabPageWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Page Window, Destructor of class CFOTabPageWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabPageWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOTabPageWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(FO_FOTABPAGEVIEW_H__1E4323A3_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
