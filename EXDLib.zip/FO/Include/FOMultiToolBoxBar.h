//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMultiToolBoxBar.h: interface for the CFOMultiToolBoxBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMULTITOOLBOXBAR_H__20C77111_E496_11D5_A4B6_525400EA266C__INCLUDED_)
#define AFX_FOMULTITOOLBOXBAR_H__20C77111_E496_11D5_A4B6_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOPControlBar.h"
#include "FOMultiToolBoxWnd.h"
#include "FOListItemObj.h"

/////////////////////////////////////////////////////////////////////////////
// CFOMultiToolBoxBar Controlbar

 
//===========================================================================
// Summary:
//     The CFOMultiToolBoxBar class derived from CFOPControlBar
//      F O Multiple Tool Box Bar
//===========================================================================

class FO_EXT_CLASS CFOMultiToolBoxBar : public CFOPControlBar
{
// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Tool Box Bar, Constructs a CFOMultiToolBoxBar object.
	//		Returns A  value (Object).
	CFOMultiToolBoxBar();

// Attributes
public:
	// Attributes
 
	// Pages, This member specify E-XD++ CFOListItemObjList object.  
	CFOListItemObjList m_Pages;

	// Load resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void LoadFromFile();

	// Find item with id.
	// nIndex -- the id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Object By I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOListItemObj ,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFOListItemObj *FindObjByID(int nIndex);

	// Do create toolbox pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Pages, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCreatePages();

public:

	// Toolbox wnd.
 
	// Tool, This member specify E-XD++ CFOMultiToolBoxWnd object.  
	CFOMultiToolBoxWnd m_wndTool;

public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiToolBoxBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Tool Box Bar, Destructor of class CFOMultiToolBoxBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiToolBoxBar();
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOMultiToolBoxBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd( CDC* pDC );
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_FOMULTITOOLBOXBAR_H__20C77111_E496_11D5_A4B6_525400EA266C__INCLUDED_)
