//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOListItemObj.h: interface for the CFOListItemObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOLISTITEMOBJ_H__ABA1BFD3_E3C0_11D5_A4B5_525400EA266C__INCLUDED_)
#define AFX_FOLISTITEMOBJ_H__ABA1BFD3_E3C0_11D5_A4B5_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 
//===========================================================================
// Summary:
//     The CFOListItemObj class derived from CObject
//      F O List Item Object
//===========================================================================

class FO_EXT_CLASS CFOListItemObj : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOListItemObj---F O List Item Object, Specifies a E-XD++ CFOListItemObj object (Value).
	DECLARE_SERIAL(CFOListItemObj);

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Item Object, Constructs a CFOListItemObj object.
	//		Returns A  value (Object).
	CFOListItemObj();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Item Object, Destructor of class CFOListItemObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOListItemObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// The title of catalogue.
 
	// Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strTitle;

	// The file name of catalogue.
 
	// File Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strFileName;

	// The id of catalogue.
 
	// I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nID;

public:
	
	// Save document to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document from a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get the pointer of file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,
	CFileException* pError);

	// Release the file from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

};

typedef CTypedPtrList<CObList, CFOListItemObj*> CFOListItemObjList;

#endif // !defined(AFX_FOLISTITEMOBJ_H__ABA1BFD3_E3C0_11D5_A4B5_525400EA266C__INCLUDED_)
