//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEPNG_H__BB356E27_60D7_439F_A0D9_BC138FDB2900__INCLUDED_)
#define AFX_FOIMAGEPNG_H__BB356E27_60D7_439F_A0D9_BC138FDB2900__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImagePNG.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CFOImagePNG window

#include "FOBitmap.h"

 
//===========================================================================
// Summary:
//     The CFOImagePNG class derived from CFOBitmap
//      F O Image P N G
//===========================================================================

class FO_EXT_CLASS CFOImagePNG : public CFOBitmap
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImagePNG---F O Image P N G, Specifies a E-XD++ CFOImagePNG object (Value).
    DECLARE_SERIAL(CFOImagePNG)
		
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image P N G, Constructs a CFOImagePNG object.
	//		Returns A  value (Object).
	CFOImagePNG();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image P N G, Destructor of class CFOImagePNG
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOImagePNG();

public:
	// Save document.
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    virtual void Serialize(CArchive &ar);
	// Operations

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID,LPCTSTR pcszResourceType);

	// load icon file
	// strFileName -- file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Decode, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&reader---Specifies a E-XD++ CFODataReadBase &reader object (Value).  
	//		*pImage---*pImage, A pointer to the CFOBitmap  or NULL if the call failed.
	// Decode png file format.
	bool Decode( CFODataReadBase &reader,CFOBitmap *pImage);

};

//===========================================================================
// Summary:
//     The CFOPPngImage class derived from CBitmapCFOBitmap
//      F O Image P N G
//===========================================================================

class FO_EXT_CLASS CFOPPngImage : public CBitmap  
{
	// Construction/Destruction
public:
	CFOPPngImage();
	virtual ~CFOPPngImage();
	
	// Attributes:
public:
	static CString	strTypePng;

protected:
	
	// Load from file
	BOOL LoadFromFile(CFile* pFile);
	
	// Save to file
	BOOL SaveToFile(CFile* pFile);
	
	// Operations:
public:
	BOOL Load(UINT nResID, HINSTANCE hinstRes = NULL);
	
	// Load.
	BOOL Load(LPCTSTR strRes, HINSTANCE hinstRes = NULL);
	
	// Load from file.
	BOOL LoadFromFile(LPCTSTR strFile);
	
	// Load from buffer
	BOOL LoadFromBuffer(LPBYTE lpBuffer, UINT uiSize);
	
	// Save to file.
	BOOL SaveToFile(LPCTSTR lpszPath);
	
	// Save to buffer
	UINT SaveToBuffer(LPBYTE* lpBuffer);

	// Alpha
	BOOL	m_bAlpha;
};


/////////////////////////////////////////////////////////////////////////////
// CFODrawImagePNG class

 
//===========================================================================
// Summary:
//     The CFODrawImagePNG class derived from CFODrawImage
//      F O Draw Image P N G
//===========================================================================

class FO_EXT_CLASS CFODrawImagePNG : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImagePNG---F O Draw Image P N G, Specifies a E-XD++ CFODrawImagePNG object (Value).
	DECLARE_SERIAL(CFODrawImagePNG)
public:

	// Image pointer.
 
	// Image P N G, This member specify E-XD++ CFOImagePNG object.  
	CFOImagePNG m_ImagePNG;

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap() { return &m_ImagePNG; }


public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image P N G, Constructs a CFODrawImagePNG object.
	//		Returns A  value (Object).
	CFODrawImagePNG();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image P N G, Destructor of class CFODrawImagePNG
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImagePNG();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImagePNG &target object(Value).
	virtual BOOL operator==(const CFODrawImagePNG &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEPNG_H__BB356E27_60D7_439F_A0D9_BC138FDB2900__INCLUDED_)
