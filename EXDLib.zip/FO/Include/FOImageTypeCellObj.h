//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOImageTypeCellObj.h: interface for the CFOImageTypeCellObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOIMAGETYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FOIMAGETYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Define brush type

 
//===========================================================================
// Summary:
//     The CFOImageTypeCellObj class derived from CObject
//      F O Image Type Cell Object
//===========================================================================

class FO_EXT_CLASS CFOImageTypeCellObj : public CObject
{
protected:

	// DECLARE SERIAL CLASS
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageTypeCellObj---F O Image Type Cell Object, Specifies a E-XD++ CFOImageTypeCellObj object (Value).
	DECLARE_SERIAL(CFOImageTypeCellObj);
public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Type Cell Object, Constructs a CFOImageTypeCellObj object.
	//		Returns A  value (Object).
	CFOImageTypeCellObj();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Type Cell Object, Destructor of class CFOImageTypeCellObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageTypeCellObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file 
	virtual void Serialize(CArchive &ar);
 
	// Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint point);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draw select 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Set Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOImageTypeCellObj
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void	SetItemRect(const CRect &rcPos)			{ m_rcPosition = rcPos; }

	// Get Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const						{ return m_rcPosition; }

	// Set Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Type, Sets a specify value to current class CFOImageTypeCellObj
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void	SetImageType(const int &nType);

	// Get Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Type, Returns the specified value.
	//		Returns a int type value.
	int		GetImageType() const				{ return m_nImageType; }

	// Set Cell Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOImageTypeCellObj
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder)	{ nCellBorderSize = nBorder; }

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set F G Color, Sets a specify value to current class CFOImageTypeCellObj
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetFGColor(const COLORREF &cr);

	// get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get F G Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFGColor() const				{ return m_crFG; }

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set B K Color, Sets a specify value to current class CFOImageTypeCellObj
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetBKColor(const COLORREF &cr);

	// Get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get B K Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetBKColor() const				{ return m_crBack; }

protected:

	// Position of the cell.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Current cell FG color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crFG;

	// Current cell back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// Current line type.
 
	// Image Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int 		m_nImageType;

	// Cell border size.
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCellBorderSize;

};

//Define type CTypedPtrList
typedef CTypedPtrList<CObList, CFOImageTypeCellObj*> CFOImageTypeCellObjList;

#endif // !defined(AFX_FOIMAGETYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_)
