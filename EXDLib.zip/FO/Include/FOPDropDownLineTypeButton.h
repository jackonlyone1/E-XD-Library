//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNLINETYPEBUTTON_H__C3094B2E_40A7_4DFA_8EE3_CBD00955F4ED__INCLUDED_)
#define AFX_FOPDROPDOWNLINETYPEBUTTON_H__C3094B2E_40A7_4DFA_8EE3_CBD00955F4ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownLineTypeButton.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// FOPDropDownLineTypeButton window
#include "FOPLineTypePickerDrawPanel.h"
#include "FOPDropDownButtonBase.h"
#include "FOPPickerBaseWnd.h"

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownLineTypeButton window
void FO_API_DECL AFXAPI DDX_LineTypeDropDown(CDataExchange *pDX, int nIDC, int& nLineType);

 
//===========================================================================
// Summary:
//     The FOPDropDownLineTypeButton class derived from FOPDropDownButtonBase
//      O P Drop Down Line Type Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownLineTypeButton : public FOPDropDownButtonBase, FOPDropLineTypeCallback
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownLineTypeButton---O P Drop Down Line Type Button, Specifies a FOPDropDownLineTypeButton object(Value).
	DECLARE_DYNCREATE(FOPDropDownLineTypeButton);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Line Type Button, Constructs a FOPDropDownLineTypeButton object.
	//		Returns A  value (Object).
	FOPDropDownLineTypeButton();

// Attributes
public:
	// Drop wnd
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Auto ptr draw impl
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPDropLineTypePickerDrawPanel.  
	FOPDropLineTypePickerDrawPanel* pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPDropLineTypePickerDrawPanel.  
	FOPDropLineTypePickerDrawPanel*	pDrawImpl;

	// Line type value
 
	// Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							nLineType;
// Operations
public:

	// Share draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownLineTypeButton& button object(Value).
	void						ShareDrawImpl(FOPDropDownLineTypeButton& button);

	// Get line type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Type, Returns the specified value.
	//		Returns a int type value.
	int		 					GetLineType()	const	{	return(nLineType);	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPDropLineTypePickerDrawPanel& value (Object).
	const FOPDropLineTypePickerDrawPanel&	GetDrawImpl() const	{	return *pDrawImpl;	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPDropLineTypePickerDrawPanel& value (Object).
	FOPDropLineTypePickerDrawPanel&	GetDrawImpl()		{	return *pDrawImpl;	}

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int					GetMinimumHeight() const;

	// Set line type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Type, Sets a specify value to current class FOPDropDownLineTypeButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void						SetLineType(int nWidth);

	// Do drop down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		r---Specifies A CRect type value.  
	//		BOOL---O O L, Specifies A Boolean value.
	// Draw state
	void						Draw(CDC& dc, const CRect& r, BOOL );

	// Do when line type change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Type Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellLineTypeChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom line type button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Line Type, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomLineType();

	// Do when choose none line type action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Type None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellLineTypeNone();

	// Set transparentcy
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPDropDownLineTypeButton
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void						SetTransparency(BOOL  bTransparent);

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 						IsTransparent()	const	{	return m_bTransparent;		}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownLineTypeButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Line Type Button, Destructor of class FOPDropDownLineTypeButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownLineTypeButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownLineTypeButton)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Transparent
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 						m_bTransparent;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNLINETYPEBUTTON_H__C3094B2E_40A7_4DFA_8EE3_CBD00955F4ED__INCLUDED_)
