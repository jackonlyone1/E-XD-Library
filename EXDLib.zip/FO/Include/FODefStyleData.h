//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODEFSTYLEDATA_H__34C7992D_182A_4C9D_8DA1_B1F6D3B9FED6__INCLUDED_)
#define AFX_FODEFSTYLEDATA_H__34C7992D_182A_4C9D_8DA1_B1F6D3B9FED6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODefStyleData.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPShapeDefaultStyle default style.
// CFOPXMLAttr

 
//===========================================================================
// Summary:
//      To use a CFOPXMLAttr object, just call the constructor.
//      F O P X M L Attributes
//===========================================================================

class FO_EXT_CLASS CFOPXMLAttr
{
public:
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
   CString m_sName;
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
   CString m_sValue;
};

///////////////////////////////////////////////////////////////////////////////
// CFOPXMLObj

 
//===========================================================================
// Summary:
//      To use a CFOPXMLObj object, just call the constructor.
//      F O P X M L Object
//===========================================================================

class FO_EXT_CLASS CFOPXMLObj
{
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P X M L Object, Constructs a CFOPXMLObj object.
	//		Returns A  value (Object).
	CFOPXMLObj();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P X M L Object, Destructor of class CFOPXMLObj
	//		Returns A  value (Object).
	~CFOPXMLObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Write, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFile---*pFile, A pointer to the FILE  or NULL if the call failed.
	// Write file
	BOOL Write(FILE *pFile);

	// Load from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFile---*pFile, A pointer to the FILE  or NULL if the call failed.  
	//		ch---Specifies a TCHAR ch = 0 object(Value).
	BOOL Read(FILE *pFile, TCHAR ch = 0);
	
	// Load attribute.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Attributes, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pFile---pFile, A pointer to the FILE or NULL if the call failed.
	BOOL ReadAttr(FILE* pFile);
	
	// Obtain attribute
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attributes, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		sName---sName, Specifies A CString type value.
	CString GetAttr(CString sName);

	// Obtain integer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Integer, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		sTag---sTag, Specifies A CString type value.  
	//		sTagChild---Tag Child, Specifies A CString type value.
	int GetInteger(CString sTag, CString sTagChild);

	// Obtain double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Double, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		sTag---sTag, Specifies A CString type value.  
	//		sTagChild---Tag Child, Specifies A CString type value.
	double GetDouble(CString sTag, CString sTagChild);

	// Obtain string value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		sTag---sTag, Specifies A CString type value.  
	//		sTagChild---Tag Child, Specifies A CString type value.
	CString GetString(CString sTag, CString sTagChild);

	// Obtain XML object pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X M L Object, Returns the specified value.
	//		Returns a pointer to the object CFOPXMLObj,or NULL if the call failed  
	// Parameters:
	//		sTag---sTag, Specifies A CString type value.  
	//		sTagChild---Tag Child, Specifies A CString type value.
	CFOPXMLObj* GetXMLObj(CString sTag, CString sTagChild);
	
	// Get child item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sName---sName, Specifies A CString type value.  
	//		CFOPXMLObj*&---F O P X M L Obj*&, A pointer to the CFOPXMLObj or NULL if the call failed.
	BOOL GetChild(CString sName, CFOPXMLObj*&);
	
	// Add new child item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Child, Adds an object to the specify list.
	// Parameters:
	//		CFOPXMLObj*---F O P X M L Obj*, A pointer to the CFOPXMLObj or NULL if the call failed.
	void AddChild(CFOPXMLObj*);
	
	// Name
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_sName;

	// Value
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_sValue;

	// Next node
 
	// Next, This member maintains a pointer to the object CFOPXMLObj.  
	CFOPXMLObj *m_pNext;

	// Child node.
 
	// Child, This member maintains a pointer to the object CFOPXMLObj.  
	CFOPXMLObj *m_pChild;

	// Attributes array
	CArray <CFOPXMLAttr, CFOPXMLAttr> m_aAttr; 
};

///////////////////////////////////////////////////////////////////////////////
// CFOPXMLFile

 
//===========================================================================
// Summary:
//     The CFOPXMLFile class derived from CFOPXMLObj
//      F O P X M L File
//===========================================================================

class FO_EXT_CLASS CFOPXMLFile : public CFOPXMLObj
{
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sFile---sFile, Specifies A CString type value.
	// Write to file
	BOOL Write(CString sFile);
	
	// Load from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sFile---sFile, Specifies A CString type value.
	BOOL Read(CString sFile);
};

///////////////////////////////////////////////////////////////////////////////
// CFOPShapeDefaultStyle

 
//===========================================================================
// Summary:
//     The CFOPShapeDefaultStyle class derived from CObject
//      F O P Shape Default Style
//===========================================================================

class FO_EXT_CLASS CFOPShapeDefaultStyle : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPShapeDefaultStyle---F O P Shape Default Style, Specifies a E-XD++ CFOPShapeDefaultStyle object (Value).
	DECLARE_SERIAL(CFOPShapeDefaultStyle);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Shape Default Style, Constructs a CFOPShapeDefaultStyle object.
	//		Returns A  value (Object).
	CFOPShapeDefaultStyle();

	// Copy constructor. 
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Shape Default Style, Constructs a CFOPShapeDefaultStyle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPShapeDefaultStyle& source object(Value).
	CFOPShapeDefaultStyle(const CFOPShapeDefaultStyle& source);
	
	// Assignment operator.
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPShapeDefaultStyle& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPShapeDefaultStyle& source object(Value).
	CFOPShapeDefaultStyle& operator=(const CFOPShapeDefaultStyle& source);

	// == operator.
	// aCmp -- target compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPShapeDefaultStyle& aCmp object(Value).
	BOOL operator==(const CFOPShapeDefaultStyle& aCmp) const;

	// != operator.
	// aCmp -- target compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPShapeDefaultStyle& aCmp object(Value).
	BOOL operator!=(const CFOPShapeDefaultStyle& aCmp) const
	{
		return !operator == (aCmp);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPShapeDefaultStyle,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPShapeDefaultStyle* Copy() const;

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Shape Default Style, Destructor of class CFOPShapeDefaultStyle
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPShapeDefaultStyle();
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	// Convert to XML
	
	//-----------------------------------------------------------------------
	// Summary:
	// As X M L, .
	// Parameters:
	//		pXML---X M L, A pointer to the CFOPXMLObj or NULL if the call failed.
	void AsXML(CFOPXMLObj* pXML);

	// Convert from XML
	
	//-----------------------------------------------------------------------
	// Summary:
	// M L As, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pXML---X M L, A pointer to the CFOPXMLObj or NULL if the call failed.
	BOOL XMLAs(CFOPXMLObj* pXML);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Get Object Caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetItemCaption()	const { return m_strCaption; }

	// Get Object Caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Caption, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetItemCaption(
		// Specify the Caption of shape.
		const CString &str
		) { m_strCaption = str; }

	
	/////////////////////////////////////
	// Font

	// Set color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const { return m_crFontColor; }

	// Change color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&crFontColor---Font Color, Specifies A 32-bit COLORREF value used as a color value.
	void SetFontColor(const COLORREF &crFontColor) { m_crFontColor = crFontColor; }

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	// nPointSize -- font point size.
	// pDC -- pointer of the dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.
	void		SetPointSize(const int &nPointSize);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	// bItalic -- italic or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	// crBkColor -- new back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Define for shadow.
	// Get shadow color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetShadowColor() const;

	// Change the shadow color,this is used by shadow brush,the shadow brush type must be 1.
	// crColor -- shadow color or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetShadowColor(const COLORREF &crColor);

	// If shadow is visible,return true,else return false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetShadow() const { return m_bShowShadow; }

	// Change the shadow visible property,true for showing,false for hide
	// bHas -- has shadow or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetShadow(const BOOL &bHas) { m_bShowShadow = bHas; }

	// Get Line Width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int			GetLineWidth() const		{ return m_nLineWidth; }

	// Change the line with.
	// nWidth -- new line width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void		SetLineWidth(const int &nWidth);

	// Get Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetLineColor() const		{ return m_crLine; }

	// Change the Line Color
	// crColor -- new line color or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetLineColor(const COLORREF &crColor);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,shape use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	// cr -- new pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Obtain canvas's color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetCanvasColor() const { return m_crCanvas; }

	// Change canvas's color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Color, Sets a specify value to current class CFOPShapeDefaultStyle
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetCanvasColor(const COLORREF &crColor) { m_crCanvas = crColor; }

public:

	// Caption of the layer.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;

	
	// Font Color of the layer.
 
	// Font Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crFontColor;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;

	// The line width.
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineWidth;

	// The line color.
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLine;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;


	// Show shadow.
 
	// Show Shadow, This member sets TRUE if it is right.  
	BOOL			m_bShowShadow;

	// Define for shadow color.
 
	// Shadow Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crShadowColor;

	// Color of canvas.
 
	// Canvas, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crCanvas;

	// Color of line shape.
 
	// Line Shape, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLineShape;

	// Line width of line shape.
 
	// Line Shape Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineShapeWidth;

	// Start arrow of line shape.
 
	// Start Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nStartArrow;

	// End arrow of line shape.
 
	// End Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nEndArrow;

};

// List of default style objects.

typedef CTypedPtrList<CObList, CFOPShapeDefaultStyle*> CFOPShapeDefaultStyleList;

_FOLIB_INLINE	COLORREF CFOPShapeDefaultStyle::GetBkColor() const					
{ 
	return m_crBkColor; 
}

_FOLIB_INLINE	void CFOPShapeDefaultStyle::SetBkColor(const COLORREF &crBkColor)	
{	
	m_crBkColor = crBkColor;
}

_FOLIB_INLINE int CFOPShapeDefaultStyle::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOPShapeDefaultStyle::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOPShapeDefaultStyle::SetItalic(const BOOL &bItalic)
{
	m_bItalic = bItalic;
}

_FOLIB_INLINE CString CFOPShapeDefaultStyle::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOPShapeDefaultStyle::GetPointSize() const
{
	return m_nPointSize;
}

/////////////////////////////////////////////////////////////////////////
// CFODefStyleData

 
//===========================================================================
// Summary:
//     The CFODefStyleData class derived from CObject
//      F O Default Style Data
//===========================================================================

class FO_EXT_CLASS CFODefStyleData : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODefStyleData---F O Default Style Data, Specifies a E-XD++ CFODefStyleData object (Value).
	DECLARE_SERIAL(CFODefStyleData);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Default Style Data, Constructs a CFODefStyleData object.
	//		Returns A  value (Object).
	CFODefStyleData();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Default Style Data, Destructor of class CFODefStyleData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODefStyleData();
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

public:

	/*************************************************************************
	|*
	|* Define for default styles.
	|*
	\************************************************************************/

	// Obtain current style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Default Style, Returns the specified value.
	//		Returns a pointer to the object CFOPShapeDefaultStyle ,or NULL if the call failed
	CFOPShapeDefaultStyle *GetCurDefStyle() { return &m_CurStyle; }

	// Obtain current style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Temp Default Style, Returns the specified value.
	//		Returns a pointer to the object CFOPShapeDefaultStyle ,or NULL if the call failed
	CFOPShapeDefaultStyle *GetTempDefStyle() { return &m_TempStyle; }

	// Initial current default style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Default, Call InitDef after creating a new object.
	// Parameters:
	//		&strTitle---&strTitle, Specifies A CString type value.
	void InitDef(const CString &strTitle);

	// Initial current default style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Default, Call InitDef after creating a new object.
	// Parameters:
	//		&nCurIndex---Current Index, Specifies A integer value.
	void InitDef(const int &nCurIndex);

	// Init current default style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Default, Call InitDef after creating a new object.
	// Parameters:
	//		&style---Specifies a const CFOPShapeDefaultStyle &style object(Value).
	void InitDef(const CFOPShapeDefaultStyle &style);

	// Init current default style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Current Default, Call this member function to update the object.
	// Parameters:
	//		&style---Specifies a const CFOPShapeDefaultStyle &style object(Value).
	void UpdateCurDef(const CFOPShapeDefaultStyle &style);

	// Clear all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Default Style, Remove the specify data from the list.

	void ClearAllDefStyle();

	// All def list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Style List, Returns the specified value.
	//		Returns a pointer to the object CFOPShapeDefaultStyleList ,or NULL if the call failed
	CFOPShapeDefaultStyleList *GetDefStyleList() { return &m_DefList; }

	// Find with caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Default Style With, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&str---Specifies A CString type value.
	BOOL FindDefStyleWith(const CString &str);

	// Add new style list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Default Style, Adds an object to the specify list.
	//		Returns a pointer to the object CFOPShapeDefaultStyle ,or NULL if the call failed  
	// Parameters:
	//		&strItem---&strItem, Specifies A CString type value.
	CFOPShapeDefaultStyle *AddNewDefStyle(const CString &strItem);

	void RemoveStyle(CFOPShapeDefaultStyle *pRemove);

	// Update current style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Current Default Style, Call this member function to update the object.

	void UpdateCurDefStyle();

	// Update all default style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Default Style, Call this member function to update the object.

	void UpdateAllDefStyle();

	// Convert to XML
	
	//-----------------------------------------------------------------------
	// Summary:
	// As X M L, .
	// Parameters:
	//		pXML---X M L, A pointer to the CFOPXMLObj or NULL if the call failed.
	void AsXML(CFOPXMLObj* pXML);

	// Convert from XML
	
	//-----------------------------------------------------------------------
	// Summary:
	// M L As, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pXML---X M L, A pointer to the CFOPXMLObj or NULL if the call failed.
	BOOL XMLAs(CFOPXMLObj* pXML);

public:

	// Load data from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Data, Call this function to read a specified number of bytes from the archive.

	void LoadData();

	// Save data to file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Data, Call this function to save the specify data to a file.

	void SaveData();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Current style.
 
	// Current Style, This member specify E-XD++ CFOPShapeDefaultStyle object.  
	CFOPShapeDefaultStyle			m_CurStyle;

	// Current style.
 
	// Temp Style, This member specify E-XD++ CFOPShapeDefaultStyle object.  
	CFOPShapeDefaultStyle			m_TempStyle;

	// All shape style.
 
	// Default List, This member specify E-XD++ CFOPShapeDefaultStyleList object.  
	CFOPShapeDefaultStyleList		m_DefList;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODEFSTYLEDATA_H__34C7992D_182A_4C9D_8DA1_B1F6D3B9FED6__INCLUDED_)
