//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOActionMacro.h: interface for the CFOActionMacroMacro class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOACTIONMACRO_H__5D3EDD15_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOACTIONMACRO_H__5D3EDD15_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseActionMacro.h"
#include "FODrawShape.h"
#include "FOGlobals.h"
#include "FOAction.h"

///////////////////////////////////////////////////////////////////////////////////
// CFOActionMacro -- The base of class of all multiple action.

class CFODataModel;

typedef CMap<CFODrawShape*, CFODrawShape*,int,int> FOPShapeOrderMap;
 
//===========================================================================
// Summary:
//     The CFOActionMacro class derived from CFOBaseActionMacro
//      F O Action Macro
//===========================================================================

class FO_EXT_CLASS CFOActionMacro : public CFOBaseActionMacro  
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N_ N O I D, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOActionMacro---F O Action Macro, Specifies a E-XD++ CFOActionMacro object (Value).
	DECLARE_ACTION_NOID(CFOActionMacro)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	// pModel -- pointer of model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Action Macro, Constructs a CFOActionMacro object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOActionMacro(CFODataModel* pModel);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Action Macro, Destructor of class CFOActionMacro
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOActionMacro();

	//-----------------------------------------------------------------------
	// Summary:
	// Set the model of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOActionMacro
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void SetModel(
		// Pointer of data model.
		CFODataModel *pModel
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of the model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	virtual CFODataModel *GetModel();

	//-----------------------------------------------------------------------
	// Summary:
	// Get save update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Update Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetSaveUpdateRect() const { return m_rcSaveUpdate; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set save update position.
	// rc -- position of saving rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Update Rectangle, Sets a specify value to current class CFOActionMacro
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SetSaveUpdateRect(const CRect &rc);

	//-----------------------------------------------------------------------
	// Summary: execute an action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

protected:

	//The pointer To Model
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel* m_pModel;

	// Save update position.
 
	// Save Update, This member sets a CRect value.  
	CRect			m_rcSaveUpdate;
};

// Get the pointer of the model.
_FOLIB_INLINE CFODataModel* CFOActionMacro::GetModel()
{
	return m_pModel;
}

// Set the model of the action.
_FOLIB_INLINE void CFOActionMacro::SetModel(CFODataModel *pModel)
{
	m_pModel = pModel;
}

//////////////////////////////////////////////////////////////////////////////////
// CFODirectActionMacro -- Direct macro action.
/////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFODirectActionMacro class derived from CFOActionMacro
//      F O Direct Action Macro
//===========================================================================

class FO_EXT_CLASS CFODirectActionMacro : public CFOActionMacro  
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODirectActionMacro---F O Direct Action Macro, Specifies a E-XD++ CFODirectActionMacro object (Value).
	DECLARE_ACTION(CFODirectActionMacro)
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Direct Action Macro, Constructs a CFODirectActionMacro object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFODirectActionMacro(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Direct Action Macro, Destructor of class CFODirectActionMacro
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODirectActionMacro();

	// Obtain save update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Update Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetSaveUpdateRect() const;

	// Set save update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Update Rectangle, Sets a specify value to current class CFODirectActionMacro
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SetSaveUpdateRect(const CRect &rc);

	// Add action, add an action to the list of actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOAction  or NULL if the call failed.
	virtual void AddAction(CFOAction *pAction);

	// Add action, add a macro action to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Macro Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOActionMacro  or NULL if the call failed.
	virtual void AddMacroAction(CFOActionMacro *pAction);

	// Add action, add a list of actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Multiple Actions, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CActionList  or NULL if the call failed.
	virtual void AddMultiActions(CActionList *pList);

	// Remove all actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Action, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllAction();

	// Override with the name of this action
	// Generate action label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Return the inverse action of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Obtain the count of the children actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Action Count, Returns the specified value.
	//		Returns a int type value.
	int GetActionCount() const;

	// Need update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Need Update, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL NeedUpdate();

	// Change the description of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Action Description, Sets a specify value to current class CFODirectActionMacro
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetActionDescription(const CString &str);

	// Obtain action type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Action Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetActionType() { return m_nActionType; }

	// Change the action type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Action Type, Sets a specify value to current class CFODirectActionMacro
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetActionType(const UINT &nType) { m_nActionType = nType; }

	// Enable prepare.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Prepare, Call this member function to enable or disable the specify object for this command.

	void EnablePrepare() { m_bNeedPrepare = TRUE; }

	// Do execute an action.
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

public:
	// Need update all.
 
	// Update All, This member sets TRUE if it is right.  
	BOOL			m_bUpdateAll;

	// Need remove all the selection.
 
	// Remove All Selection, This member sets TRUE if it is right.  
	BOOL			m_bRemoveAllSelection;

	// Type of the action.
 
	// Action Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nActionType;

	// Need prepare data model's shape list.
 
	// Need Prepare, This member sets TRUE if it is right.  
	BOOL			m_bNeedPrepare;

	// Link auto route only.
 
	// Route Only, This member sets TRUE if it is right.  
	BOOL			m_bRouteOnly;

	// True need update all.
 
	// True Update All, This member sets TRUE if it is right.  
	BOOL			m_bTrueUpdateAll;

protected:

	// Save update position.
 
	// Save Update, This member sets a CRect value.  
	CRect			m_rcSaveUpdate;

	// Need update.
 
	// Need Update, This member sets TRUE if it is right.  
	BOOL			m_bNeedUpdate;

	// Action description.
 
	// Action, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strAction;

	
};


#endif // !defined(AFX_FOACTIONMACRO_H__5D3EDD15_F259_11DD_A433_525400EA266C__INCLUDED_)
