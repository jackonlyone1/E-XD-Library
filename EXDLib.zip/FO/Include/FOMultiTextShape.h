//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMULTITEXTSHAPE_H__F64469F0_3A49_4776_9F75_DBB46901F4B1__INCLUDED_)
#define FO_FOMULTITEXTSHAPE_H__F64469F0_3A49_4776_9F75_DBB46901F4B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



#include "FODrawPortsShape.h"

// Default list box items.
const CString foDefaultListBoxItemsX = _T("List item0\r\nList item1\r\nBRD_NEW\r\nList item2\r\nList item3");

///////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOMultiTextShape -- shapes that has multiple lines text support.
// Author: Author Name. ID: FOP_MULTITEXT_SHAPE 246
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOMultiTextShape class derived from CFODrawPortsShape
//      F O Multiple Text Shape
//===========================================================================

class FO_EXT_CLASS CFOMultiTextShape : public CFODrawPortsShape  
{

protected:

	// Serialize declare
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiTextShape---F O Multiple Text Shape, Specifies a E-XD++ CFOMultiTextShape object (Value).
	DECLARE_SERIAL(CFOMultiTextShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Text Shape, Constructs a CFOMultiTextShape object.
	//		Returns A  value (Object).
	CFOMultiTextShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Text Shape, Constructs a CFOMultiTextShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMultiTextShape& src object(Value).
	CFOMultiTextShape(const CFOMultiTextShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Text Shape, Destructor of class CFOMultiTextShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiTextShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiTextShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the multiple line text shape from a CRect object.
	// rcPos -- Position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMultiTextShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMultiTextShape& src object(Value).
	CFOMultiTextShape& operator=(const CFOMultiTextShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get next line of the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Next Line Extend, .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A CString type value.  
	//		&sLine---&sLine, Specifies A CString type value.
	int FOGetNextLineExt(CString& s, CString &sLine);

	// Change icon resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Resource, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetIconRes(const UINT &nRes) { m_nIconID = nRes; }

	// Change icon width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Width, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&nW---&nW, Specifies A integer value.
	void SetIconWidth(const int &nW) { m_nIconWidth = nW; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
	
	// Get choice list,this is the choice list string of the shape CFOTabbedComboShape.
	// It return a string like this:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice List, Returns the specified value.
	//		Returns a CString type value.
	CString		GetChoiceList() const;
	
	// Change the choice list string of the shape CFOTabbedComboShape,
	// strChoice -- It must be like the following string:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	void		SetChoiceList(const CString &strChoice);
	
	// Is show left border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetLeftBorder() const;
	
	// Change left border mode,if with left border mode,it will show a red line at the left of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Border, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&bLeft---&bLeft, Specifies A Boolean value.
	void		SetLeftBorder(const BOOL &bLeft);
	
	// Is show top border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTopBorder() const;
	
	// Change top border mode,if with top border mode,it will show a red line at the top border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top Border, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&bTop---&bTop, Specifies A Boolean value.
	void		SetTopBorder(const BOOL &bTop);
	
	// Is show right border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Right Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetRightBorder() const;
	
	// Change right border mode,if with right border mode,it will show a red line at the right border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Right Border, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&bRight---&bRight, Specifies A Boolean value.
	void		SetRightBorder(const BOOL &bRight);
	
	// Is show bottom border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetBottomBorder() const;
	
	// Change bottom border mode,if with bottom border mode,it will show a red line at the bottom border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bottom Border, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&bBottom---&bBottom, Specifies A Boolean value.
	void		SetBottomBorder(const BOOL &bBottom);
	

	// Return AllowPrintBorder value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Allow Print Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetAllowPrintBorder() const;
	
	// Change AllowPrintBorder value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Print Border, Sets a specify value to current class CFOMultiTextShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetAllowPrintBorder( const BOOL &bValue );

public:

	// Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the true shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:
	// Id of the icon.
 
	// Icon I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT m_nIconID;

	// Icon item width and height.
 
	// Icon Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nIconWidth;
};


#endif // !defined(FO_FOMULTITEXTSHAPE_H__F64469F0_3A49_4776_9F75_DBB46901F4B1__INCLUDED_)
