//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDRAWPICKERBASE_H__BACDEB47_4FA3_4E62_8084_3445605F432B__INCLUDED_)
#define AFX_FOPDRAWPICKERBASE_H__BACDEB47_4FA3_4E62_8084_3445605F432B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDrawPickerBase.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDrawPickerBase window

// Draw control with raised border
const unsigned FOP_RAISED_BORDER	= 0x0001L;	

// Draw control with sunken border
const unsigned FOP_SUNKEN_BORDER	= 0x0002L;	

// Compare
#define FORMMIN(X,Y)							(((X) < (Y)) ? (X) : (Y))
#define FORMMAX(X,Y)							(((X) > (Y)) ? (X) : (Y))

class FOPPickerBaseWnd;
 
//===========================================================================
// Summary:
//      To use a FOPDrawPickerBase object, just call the constructor.
//      O P Draw Picker Base
//===========================================================================

class FO_EXT_CLASS FOPDrawPickerBase
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Draw Picker Base, Constructs a FOPDrawPickerBase object.
	//		Returns A  value (Object).
	FOPDrawPickerBase();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Draw Picker Base, Destructor of class FOPDrawPickerBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDrawPickerBase() {};

public:

	// Get default cols.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Cols, Returns the specified value.
	//		Returns a int type value.
	int				GetDefaultCols()				const {	return	m_nDefcCols;			}

	// Set default cols.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Cols, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nCol---nCol, Specifies A integer value.
	void			SetDefaultCols(int nCol)			  {	m_nDefcCols			= nCol;	}

	// Get default headerbars.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Header Bars, Returns the specified value.
	//		Returns a int type value.
	int				GetDefaultHeaderBars()			const {	return	m_nDefcHeaderBars;		}

	// Set default headerbars.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Header Bars, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nBars---nBars, Specifies A integer value.
	void			SetDefaultHeaderBars(int nBars)		  {	m_nDefcHeaderBars		= nBars;}


	// Get default main group wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Wells Main Group, Returns the specified value.
	//		Returns a int type value.
	int				GetDefaultWellsMainGroup()		const {	return	m_nDefcWellsMainGroup;	}

	// Set default main group wells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Wells Main Group, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nWells---nWells, Specifies A integer value.
	void			SetDefaultWellsMainGroup(int nWells)  {	m_nDefcWellsMainGroup	= nWells;}

	// Get default extra group wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Wells Extra Group, Returns the specified value.
	//		Returns a int type value.
	int				GetDefaultWellsExtraGroup()		const {	return	m_nDefcWellsExtraGroup;}

	// Set default extra group wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Wells Extra Group, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nWells---nWells, Specifies A integer value.
	void			SetDefaultWellsExtraGroup(int nWells) {	m_nDefcWellsExtraGroup	= nWells;}

	// Get default buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Buttons, Returns the specified value.
	//		Returns a int type value.
	int				GetDefaultButtons()				const {	return	m_nDefcButtons;		}

	// Set default buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Buttons, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nButtons---nButtons, Specifies A integer value.
	void			SetDefaultButtons(int nButtons)	   	  {	m_nDefcButtons			= nButtons;	}

	// Get dbu cell size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get D B U Cell Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&	GetDBUCellSize()				const {	return	m_szDefaultDBUCell;			}

	// Change dbu cell size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set D B U Cell Size, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		szCell---szCell, Specifies A CSize type value.
	void			SetDBUCellSize(const CSize& szCell)	  {	m_szDefaultDBUCell	= szCell;	}

	// Get default headerbar sep.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Header Bar separator, Returns the specified value.
	//		Returns a int type value.
	int				GetDefHeaderBarSep()			const {	return	m_nDefHeaderBarSep;	}

	// Set default headerbar sep
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Header Bar separator, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nSep---nSep, Specifies A integer value.
	void			SetDefHeaderBarSep(int nSep)		  {	m_nDefHeaderBarSep		= nSep;	}

	// Get default wells sep
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Wells separator, Returns the specified value.
	//		Returns a int type value.
	int				GetDefWellsSep()				const {	return	m_nDefWellsSep;		}

	// Set default wells sep.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Wells separator, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nSep---nSep, Specifies A integer value.
	void			SetDefWellsSep(int nSep)			  {	m_nDefWellsSep			= nSep;	}

	// Get default button sep
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Button separator, Returns the specified value.
	//		Returns a int type value.
	int				GetDefButtonSep()				const {	return	m_nDefButtonSep;		}

	// Set default button sep.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Button separator, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nSep---nSep, Specifies A integer value.
	void			SetDefButtonSep(int nSep)			  {	m_nDefButtonSep		= nSep;	}

	// Get default extra group rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Reserve Extra Group Rows, Returns the specified value.
	//		Returns a int type value.
	int				GetDefReserveExtraGroupRows()	const {	return	m_nDefReserveExtraGroupRows;}

	// Set default extra group rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Reserve Extra Group Rows, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nRows---nRows, Specifies A integer value.
	void			SetDefReserveExtraGroupRows(int nRows){	m_nDefReserveExtraGroupRows= nRows;}

	// Get default selected wells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Selected Well, Returns the specified value.
	//		Returns a int type value.
	int				GetDefSelectedWell()			const {	return  m_nDefSelectedWell;	}

	// Set default selected wells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Selected Well, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		nSelect---nSelect, Specifies A integer value.
	void			SetDefSelectedWell(int nSelect)		  {	m_nDefSelectedWell		= nSelect;	}

	// Get default separator size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Separator Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&	GetDefSeparatorSize()			const {	return	m_szDefSeparator;		}

	// Set default separator size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Separator Size, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		szSize---szSize, Specifies A CSize type value.
	void			SetDefSeparatorSize(const CSize& szSize)  {	m_szDefSeparator		= szSize;	}

	// Get default indent size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Indent Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&	GetDefIndentSize()				const {	return	m_szDefIndent;		}

	// Set default indent size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Indent Size, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		szSize---szSize, Specifies A CSize type value.
	void			SetDefIndentSize(const CSize& szSize)  {	m_szDefIndent			= szSize;	}

	// Get default indent border size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Indent Border Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&	GetDefIndentBorderSize()		const {	return	m_szDefIndentBorder;	}

	// Set default indent border size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Indent Border Size, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		szSize---szSize, Specifies A CSize type value.
	void			SetDefIndentBorderSize(const CSize& szSize){	m_szDefIndentBorder	= szSize;	}

	// Get default use tool tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Use Tool Tips, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefUseToolTips()	  			const {	return	m_bDefUseToolTips;		}

	// Set default use tool tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Use Tool Tips, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bDefault---bDefault, Specifies A Boolean value.
	void			SetDefUseToolTips(BOOL  bDefault)	  {	m_bDefUseToolTips 		= bDefault;	}

	// Get default headerbar grey outline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Header Bar Grey Outline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefHeaderBarGreyOutline()	const {	return	m_bDefHeaderBarGreyOutline;}

	// Set default headerbar grey outline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Header Bar Grey Outline, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bGrey---bGrey, Specifies A Boolean value.
	void			SetDefHeaderBarGreyOutline(BOOL  bGrey)	  {	m_bDefHeaderBarGreyOutline = bGrey;}

	// Get default grey out line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Wells Grey Outline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefWellsGreyOutline()		const {	return	m_bDefWellsGreyOutline;}

	// Set default well out line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Wells Grey Outline, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bGrey---bGrey, Specifies A Boolean value.
	void			SetDefWellsGreyOutline(BOOL  bGrey)	  {	m_bDefWellsGreyOutline	= bGrey;	}

	// Get draw sunken mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Draw Sunken, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefDrawSunken()				const {	return	m_bDefDrawSunken;		}

	// Set draw sunken mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Draw Sunken, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bSunken---bSunken, Specifies A Boolean value.
	void			SetDefDrawSunken(BOOL  bSunken)		  {	m_bDefDrawSunken 		= bSunken;	}

	// Get default mouse down tool tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Mouse Down Tool Tips, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefMouseDownToolTips()		const {	return	m_bDefMouseDownToolTips;}

	// Set default mouse down tool tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Mouse Down Tool Tips, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bToolTip---Tool Tip, Specifies A Boolean value.
	void			SetDefMouseDownToolTips(BOOL  bToolTip)	  {	m_bDefMouseDownToolTips= bToolTip;	}

	// Get default mouse tracking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Mouse Tracking, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefMouseTracking()			const {	return	m_bDefMouseTracking;	}

	// Set default mouse tracking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Mouse Tracking, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bTracking---bTracking, Specifies A Boolean value.
	void			SetDefMouseTracking(BOOL  bTracking)  {	m_bDefMouseTracking	= bTracking;	}

	// Get default show focus rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Show Focus Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefShowFocusRect()			const {	return	m_bDefShowFocusRect;	}

	// Set default show focus rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Show Focus Rectangle, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void			SetDefShowFocusRect(BOOL  bShow)	  {	m_bDefShowFocusRect	= bShow;	}

	// Get default extra group fixed rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Extra Group Fixed Rows, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefExtraGroupFixedRows()		const {	return	m_bDefExtraGroupFixedRows;	}

	// Set default extra group fixed rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Extra Group Fixed Rows, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bRows---bRows, Specifies A Boolean value.
	void			SetDefExtraGroupFixedRows(BOOL  bRows)	  {	m_bDefExtraGroupFixedRows	= bRows;}

	// Get default disabled empty cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Disabled Empty Cells, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefDisabledEmptyCells()		const {	return	m_bDefDisabledEmptyCells;	}

	// Set default disabled empty cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Disabled Empty Cells, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bEmpty---bEmpty, Specifies A Boolean value.
	void			SetDefDisabledEmptyCells(BOOL  bEmpty)	  {	m_bDefDisabledEmptyCells = bEmpty;	}

	// Get default buttons that using dialog font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Buttons Use Dialog Font, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDefButtonsUseDialogFont()	const {	return	m_bDefButtonsUseDialogFont;}

	// Set default buttons to use dialog font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Buttons Use Dialog Font, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		bDlgFont---Dialog Font, Specifies A Boolean value.
	void			SetDefButtonsUseDialogFont(BOOL  bDlgFont)	  {	m_bDefButtonsUseDialogFont = bDlgFont;	}

	// Set drop parent wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Parent Window, Returns the specified value.
	//		Returns a pointer to the object FOPPickerBaseWnd,or NULL if the call failed
	FOPPickerBaseWnd*	GetDropParentWnd()			const {	return	m_pDropWnd;			}

	// Get drop parent wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drop Parent Window, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		pWnd---pWnd, A pointer to the FOPPickerBaseWnd or NULL if the call failed.
	void				SetDropParentWnd(FOPPickerBaseWnd* pWnd) {	m_pDropWnd			= pWnd;	}

	// Get notify wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Notify Window, Returns the specified value.
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	CWnd*				GetNotifyWnd() const			  {	return	NotifyWnd;			}

	// Set notify wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify Window, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		pNotify---pNotify, A pointer to the CWnd or NULL if the call failed.
	void				SetNotifyWnd(CWnd* pNotify)			  {	NotifyWnd			= pNotify;	}

	// Get cell size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Size, Returns the specified value.
	//		Returns a CSize type value.
	const CSize&		GetCellSize()	const			  {	return	m_szCellDefault;				}

	// Set cell size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Size, Sets a specify value to current class FOPDrawPickerBase
	// Parameters:
	//		szSize---szSize, Specifies A CSize type value.
	void				SetCellSize(const CSize& szSize)	  {	m_szCellDefault				= szSize;	}

	// Get button height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetButtonHeight();

	// Get button font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Font, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A CFont& value (Object).
	virtual CFont&		GetButtonFont();

	// Get headerbar height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetHeaderBarHeight();

	// Get headerbar font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar Font, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A CFont& value (Object).
	virtual CFont&		GetHeaderBarFont();

	// Get max headerbar button width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Header Bar Button Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetMaxHeaderBarButtonWidth();

	// Create drop down list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Down Window, You construct a FOPDrawPickerBase object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual CWnd*		CreateDropDownWnd(CWnd *pParent,const CRect &rcPos);

	// Set selected well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected Well, Sets a specify value to current class FOPDrawPickerBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void		SetSelectedWell(int nIndex);

	// Override virtual functions in derived classes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPDrawPickerBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bSunken---bSunken, Specifies A Boolean value.
	virtual void		SetSunkenMode(BOOL  bSunken);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Palette, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CPalette ,or NULL if the call failed  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		realize---Specifies A Boolean value.
	// if realize	RealizePalette() neccessary, SelectPalette(dc, realize);
	virtual CPalette *	SelectPalette(CDC& dc, BOOL  realize);

	// Create palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Palette, You construct a FOPDrawPickerBase object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		CreatePalette();


	// Callbacks to draw elements
	// Draw button face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button Face, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled)---Specifies A Boolean value.
	virtual void	DrawButtonFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled) = 0;

	// Draw headerbar face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Header Bar Face, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled)---Specifies A Boolean value.
	virtual void	DrawHeaderBarFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled) = 0;

	// Draw main group face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled)---Specifies A Boolean value.
	virtual void	DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled) = 0;

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled)---Specifies A Boolean value.
	virtual void	DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled) = 0;

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup)---Is Popup), Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup) = 0;

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup)---Is Popup), Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int nIndex, BOOL  IsPopup) = 0;

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup)---Is Popup), Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int nIndex, BOOL  IsPopup) = 0;

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup)---Is Popup), Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int nIndex, BOOL  IsPopup) = 0;

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup)---Is Popup), Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int nIndex, BOOL  IsPopup) = 0;

	// Notify system color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify System Color Change, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	NotifySysColorChange();


	// Callbacks to get tooltip text

	// Get headerbar name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Bar Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex)---nIndex), Specifies A integer value.
	virtual const CString GetHeaderBarName(int nIndex) = 0;

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex)---nIndex), Specifies A integer value.
	virtual const CString GetMainGroupName(int nIndex) = 0;

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex)---nIndex), Specifies A integer value.
	virtual const CString GetExtraGroupName(int nIndex) = 0;

	// Get button name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex)---nIndex), Specifies A integer value.
	virtual const CString GetButtonName(int nIndex) = 0;

	// Enabled or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL 		IsMainGroupEnabled(int nIndex);

	// Is extra group enabled.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Extra Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual	BOOL 		IsExtraGroupEnabled(int nIndex);

	// Draw enabled text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Enabled Text, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		text---Specifies A CString type value.  
	//		enable---Specifies A Boolean value.
	static void			DrawEnabledText(CDC& dc, CRect& rc, const CString text, BOOL  enable);

protected:

	// Pointer of drop wnd.
 
	// Drop Window, This member maintains a pointer to the object FOPPickerBaseWnd.  
	FOPPickerBaseWnd*	m_pDropWnd;

	// 	Data
	// Cell size.
 
	// Cell Default, This member sets a CSize value.  
	CSize				m_szCellDefault;

	// Default headerbar grey outline
 
	// Default Header Bar Grey Outline, This member sets TRUE if it is right.  
	BOOL 				m_bDefHeaderBarGreyOutline;

	// Default wells grey outline
 
	// Default Wells Grey Outline, This member sets TRUE if it is right.  
	BOOL 				m_bDefWellsGreyOutline;

	// Default use tooltips
 
	// Default Use Tool Tips, This member sets TRUE if it is right.  
	BOOL 				m_bDefUseToolTips;

	// Default draw sunken.
 
	// Default Draw Sunken, This member sets TRUE if it is right.  
	BOOL 				m_bDefDrawSunken;

	// Default mouse down tooltips
 
	// Default Mouse Down Tool Tips, This member sets TRUE if it is right.  
	BOOL 				m_bDefMouseDownToolTips;

	// Default mouse tracking.
 
	// Default Mouse Tracking, This member sets TRUE if it is right.  
	BOOL 				m_bDefMouseTracking;

	// Default show focus rectangle.
 
	// Default Show Focus Rectangle, This member sets TRUE if it is right.  
	BOOL 				m_bDefShowFocusRect;

	// Extra group rows.
 
	// Default Reserve Extra Group Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefReserveExtraGroupRows;

	// Default cols.
 
	// Defc Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefcCols;

	// Default headerbars.
 
	// Defc Header Bars, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefcHeaderBars;

	// Default main group wells.
 
	// Defc Wells Main Group, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefcWellsMainGroup;

	// Default extra group wells.
 
	// Defc Wells Extra Group, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefcWellsExtraGroup;

	// Default buttons.
 
	// Defc Buttons, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefcButtons;

	// Default DBU cell size.
 
	// Default D B U Cell, This member sets a CSize value.  
	CSize				m_szDefaultDBUCell;

	// Default headerbar sep.
 
	// Default Header Bar separator, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefHeaderBarSep;

	// Default wells sep.
 
	// Default Wells separator, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefWellsSep;

	// Default button sep.
 
	// Default Button separator, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefButtonSep;

	// Default separator size.
 
	// Default Separator, This member sets a CSize value.  
	CSize				m_szDefSeparator;

	// Default indent size,
 
	// Default Indent, This member sets a CSize value.  
	CSize				m_szDefIndent;

	// Default indent border size.
 
	// Default Indent Border, This member sets a CSize value.  
	CSize				m_szDefIndentBorder;

	// Window to notify changes
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*				NotifyWnd;			
	
	// Default selected well.
 
	// Default Selected Well, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nDefSelectedWell;

	// Default disabled empty cells.
 
	// Default Disabled Empty Cells, This member sets TRUE if it is right.  
	BOOL 				m_bDefDisabledEmptyCells;

	// Use dialog font.
 
	// Default Buttons Use Dialog Font, This member sets TRUE if it is right.  
	BOOL 				m_bDefButtonsUseDialogFont;

	// Default extra group fixed rows.
 
	// Default Extra Group Fixed Rows, This member sets TRUE if it is right.  
	BOOL 				m_bDefExtraGroupFixedRows;

	// HeaderBar font.
 
	// Header Bar Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont				m_HeaderBarFont;

	// Button font.
 
	// Button Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont				m_ButtonFont;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDRAWPICKERBASE_H__BACDEB47_4FA3_4E62_8084_3445605F432B__INCLUDED_)
