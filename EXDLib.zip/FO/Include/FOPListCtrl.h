//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLISTCTRL_H__6EAF5B00_E575_435C_B1D5_BC638EF1D06A__INCLUDED_)
#define AFX_FOPLISTCTRL_H__6EAF5B00_E575_435C_B1D5_BC638EF1D06A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPListCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPListCtrl window

#include <tchar.h>

#define FO_FLATHEADER_TEXT_MAX			80
#define FO_HEADERCTRL_NO_IMAGE			0
#define FO_HEADERCTRL_UNCHECKED_IMAGE	1
#define FO_HEADERCTRL_CHECKED_IMAGE		2

///////////////////////////////////////////////////////////////////////////////
// CFOPHeaderCtrl window

#define FOP_PROPERTY_SPACING		1
#define FOP_PROPERTY_ARROW			2
#define FOP_PROPERTY_STATICBORDER	3
#define FOP_PROPERTY_DONTDROPCURSOR	4
#define FOP_PROPERTY_DROPTARGET		5

 
//===========================================================================
// Summary:
//     The CFOPHeaderCtrl class derived from CHeaderCtrl
//      F O P Header 
//===========================================================================

class FO_EXT_CLASS CFOPHeaderCtrl : public CHeaderCtrl
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHeaderCtrl---F O P Header , Specifies a E-XD++ CFOPHeaderCtrl object (Value).
    DECLARE_DYNCREATE(CFOPHeaderCtrl)

// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Header , Constructs a CFOPHeaderCtrl object.
	//		Returns A  value (Object).
	CFOPHeaderCtrl();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Header , Destructor of class CFOPHeaderCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHeaderCtrl();

// Attributes
public:

	// Modify property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Modify Property, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	BOOL ModifyProperty(WPARAM wParam, LPARAM lParam);

	// Obtain the spacing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spacing, Returns the specified value.
	//		Returns a int type value.
	int GetSpacing() const					{ return m_nSpacing; }

	// Change the spacing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spacing, Sets a specify value to current class CFOPHeaderCtrl
	// Parameters:
	//		&nSpacing---&nSpacing, Specifies A integer value.
	void SetSpacing(const int &nSpacing)	{ m_nSpacing = nSpacing; }

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPHeaderCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		LPDRAWITEMSTRUCT---P D R A W I T E M S T R U C T, Specifies a LPDRAWITEMSTRUCT object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		lphdi---Specifies a LPHDITEM lphdi object(Value).
	virtual void DrawItem(CDC* pDC, CRect rect, LPHDITEM lphdi);
	//}}AFX_VIRTUAL

protected:

	// Draw ctrls
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void DoDraw(CDC* pDC);

	// Draw images.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		hdi---Specifies a LPHDITEM hdi object(Value).  
	//		bRight---bRight, Specifies A Boolean value.
	int DoDrawImage(CDC* pDC, CRect rect, LPHDITEM hdi, BOOL bRight);

	// Drawing bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bitmap, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		hdi---Specifies a LPHDITEM hdi object(Value).  
	//		pBitmap---pBitmap, A pointer to the CBitmap or NULL if the call failed.  
	//		pBitmapInfo---Bitmap Information, A pointer to the BITMAP or NULL if the call failed.  
	//		bRight---bRight, Specifies A Boolean value.
	int DoDrawBitmap(CDC* pDC, CRect rect, LPHDITEM hdi, CBitmap* pBitmap, 
		BITMAP* pBitmapInfo, BOOL bRight);

	// Drawing text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		lphdi---Specifies a LPHDITEM lphdi object(Value).
	int DoDrawText(CDC* pDC, CRect rect, LPHDITEM lphdi);

	// Create memory dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Temp D C, You construct a CFOPHeaderCtrl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&pMemoryDC---Memory D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	virtual BOOL CreateTempDC( CDC* pDC, CDC* &pMemoryDC, const CRect& rcPaint) const;

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPHeaderCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wparam---Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lparam---Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteItem(WPARAM wparam, LPARAM lparam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Insert Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wparam---Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lparam---Specifies A LPARAM value.
	afx_msg LRESULT OnInsertItem(WPARAM wparam, LPARAM lparam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Layout, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wparam---Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lparam---Specifies A LPARAM value.
	afx_msg LRESULT OnLayout(WPARAM wparam, LPARAM lparam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Image List, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wparam---Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lparam---Specifies A LPARAM value.
	afx_msg LRESULT OnSetImageList(WPARAM wparam, LPARAM lparam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()


// Implementation
protected:

	// Spacing 
 
	// Spacing, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSpacing;

	// Size of image
 
	// Image, This member specify SIZE object.  
	SIZE		m_sizeImage;

	// Size of arrow.
 
	// Arrow, This member specify SIZE object.  
	SIZE		m_sizeArrow;

	// Static border
 
	// Static Border, This member sets TRUE if it is right.  
	BOOL		m_bStaticBorder;

	// Drop cursor.
 
	// Dont Drop Cursor, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nDontDropCursor;

	// Resizing flag.
 
	// Resizing, This member sets TRUE if it is right.  
	BOOL		m_bResizing;

	// Click flags
 
	// Click Flags, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nClickFlags;

	// Click point
 
	// Click Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptClickPoint;

	// High light color.
 
	// D High Light, This member sets A 32-bit value used as a color value.  
	COLORREF	m_cr3DHighLight;

};

extern UINT NEAR WM_FOPLISTCTRL_CHECKBOX_CLICKED;

///////////////////////////////////////////////////////////////////////////////
// CFOPListCtrl data

struct FOP_LISTCTRL_ITEM
{
	FOP_LISTCTRL_ITEM()
	{
		m_bEnabled             = TRUE;
		m_crText               = ::GetSysColor(COLOR_WINDOWTEXT);
		m_crBackground         = ::GetSysColor(COLOR_WINDOW);
		m_nCheckedState        = -1;
		m_bBold                = FALSE;
		m_nImage               = -1;
		m_dwItemData           = 0;
	}

	// TRUE = enabled, FALSE = disabled (gray text)
	BOOL			m_bEnabled;
				
	// TRUE = display bold text
	BOOL			m_bBold;	
	
	// index in image list, else -1
	int				m_nImage;					

	// text color
	COLORREF		m_crText;

	// background color
	COLORREF		m_crBackground;

	// for checkbox
	// -1 = don't show, 0 = unchecked, 1 = checked
	int				m_nCheckedState;				

	// pointer to app's data
	DWORD			m_dwItemData;					
};


///////////////////////////////////////////////////////////////////////////////
// CFOPListCtrl class

 
//===========================================================================
// Summary:
//     The CFOPListCtrl class derived from CListCtrl
//      F O P List 
//===========================================================================

class FO_EXT_CLASS CFOPListCtrl : public CListCtrl
{
// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P List , Constructs a CFOPListCtrl object.
	//		Returns A  value (Object).
	CFOPListCtrl();

	// Destructor.	
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P List , Destructor of class CFOPListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPListCtrl();

// Attributes
public:

// Operations
public:

	// Count checked items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Count Checked Items, .
	//		Returns a int type value.  
	// Parameters:
	//		nSubItem---Child Item, Specifies A integer value.
	int		CountCheckedItems(int nSubItem);

	// Delete all items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Items, Deletes the given object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	DeleteAllItems();

	// Delete item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL	DeleteItem(int nItem);

	// Obtain bold font flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bold, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	BOOL	GetBold(int nItem, int nSubItem);

	// Obtain check box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Checkbox, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	int		GetCheckbox(int nItem, int nSubItem);

	// Obtain columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Columns, Returns the specified value.
	//		Returns a int type value.
	int		GetColumns();

	// Obtain current selected item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Select, Returns the specified value.
	//		Returns a int type value.
	int		GetCurSel();

	// Obtain enable flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Enabled, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL	GetEnabled(int nItem);

	// Obtain header check state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Checked State, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nSubItem---Child Item, Specifies A integer value.
	int		GetHeaderCheckedState(int nSubItem);

	// Obtain item's data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Data, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	DWORD	GetItemData(int nItem);

	// Obtain item rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Item Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		nArea---nArea, Specifies A integer value.  
	//		rect---Specifies A CRect type value.
	BOOL	GetSubItemRect(int nItem, int nSubItem, int nArea, CRect& rect);

	// Insert new item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Item, Inserts a child object at the given index..
	//		Returns a int type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		lpszItem---lpszItem, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	int		InsertItem(int nItem, LPCTSTR lpszItem);

	// Insert new item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Item2, Inserts a child object at the given index..
	//		Returns a int type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		lpszItem---lpszItem, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&nImage---&nImage, Specifies A integer value.
	int		InsertItem2(int nItem, LPCTSTR lpszItem, const int &nImage);

	// Insert new item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Item, Inserts a child object at the given index..
	//		Returns a int type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		lpszItem---lpszItem, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBackground---crBackground, Specifies A 32-bit COLORREF value used as a color value.
	int		InsertItem(int nItem, 
					   LPCTSTR lpszItem, 
					   COLORREF crText, 
					   COLORREF crBackground);

	// Insert new item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Item, Inserts a child object at the given index..
	//		Returns a int type value.  
	// Parameters:
	//		pItem---pItem, A pointer to the const LVITEM or NULL if the call failed.
	int		InsertItem(const LVITEM* pItem);

	// Change font bold flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bold, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		bBold---bBold, Specifies A Boolean value.
	BOOL	SetBold(int nItem, int nSubItem, BOOL bBold);

	// Change check box state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Checkbox, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		nCheckedState---Checked State, Specifies A integer value.
	BOOL	SetCheckbox(int nItem, int nSubItem, int nCheckedState);

	// Change current selection item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Select, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL	SetCurSel(int nItem);

	// Change enable state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Enabled, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		bEnable---bEnable, Specifies A Boolean value.
	BOOL	SetEnabled(int nItem, BOOL bEnable);

	// Change listctrl extend style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Extended Style X, Sets a specify value to current class CFOPListCtrl
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwNewStyle---New Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD	SetExtendedStyleX(DWORD dwNewStyle) 
	{
		DWORD dwOldStyle = m_dwExtendedStyleX;
		m_dwExtendedStyleX = dwNewStyle;
		return dwOldStyle;
	}
	
	// Change header check state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Checked State, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nSubItem---Child Item, Specifies A integer value.  
	//		nCheckedState---Checked State, Specifies A integer value.
	BOOL	SetHeaderCheckedState(int nSubItem, int nCheckedState);

	// Change item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item, Sets a specify value to current class CFOPListCtrl
	//		Returns a int type value.  
	// Parameters:
	//		pItem---pItem, A pointer to the const LVITEM or NULL if the call failed.
	int		SetItem(const LVITEM* pItem);

	// Change item's data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Data, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		dwData---dwData, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	BOOL	SetItemData(int nItem, DWORD dwData);

	// Change item's image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Image, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		nImage---nImage, Specifies A integer value.
	BOOL	SetItemImage(int nItem, int nSubItem, int nImage);

	// Change item's text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Text, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL	SetItemText(int nItem, int nSubItem, LPCTSTR lpszText); 

	// Change item text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Text, Sets a specify value to current class CFOPListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBackground---crBackground, Specifies A 32-bit COLORREF value used as a color value.
	BOOL	SetItemText(int nItem, 
						int nSubItem, 
						LPCTSTR lpszText,
						COLORREF crText, 
						COLORREF crBackground);

	// Update sub items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Child Item, Call this member function to update the object.
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	void	UpdateSubItem(int nItem, int nSubItem);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPListCtrl)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:

	// Header control
 
	// Header , This member specify E-XD++ CFOPHeaderCtrl object.  
	CFOPHeaderCtrl	m_HeaderCtrl;

	// Image list for the header control
 
	// Image List, This member is a collection of same-sized images.  
	CImageList		m_cImageList;	

protected:

	// Draw check box item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Checkbox, Do a event. 
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBkgnd---crBkgnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		rect---Specifies A CRect type value.  
	//		*pCLD---C L D, A pointer to the FOP_LISTCTRL_ITEM  or NULL if the call failed.
	void DoDrawCheckbox(int nItem, 
					  int nSubItem, 
					  CDC *pDC, 
					  COLORREF crText,
					  COLORREF crBkgnd,
					  CRect& rect, 
					  FOP_LISTCTRL_ITEM *pCLD);

	// Draw image item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBkgnd---crBkgnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		rect---Specifies A CRect type value.  
	//		*pXLCD---X L C D, A pointer to the FOP_LISTCTRL_ITEM  or NULL if the call failed.
	int DoDrawImage(int nItem, 
				  int nSubItem, 
				  CDC* pDC, 
				  COLORREF crText,
				  COLORREF crBkgnd,
				  CRect rect,
				  FOP_LISTCTRL_ITEM *pXLCD);

	// Draw text item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text, Do a event. 
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBkgnd---crBkgnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		rect---Specifies A CRect type value.  
	//		*pCLD---C L D, A pointer to the FOP_LISTCTRL_ITEM  or NULL if the call failed.
	void DoDrawText(int nItem, 
				  int nSubItem, 
				  CDC *pDC, 
				  COLORREF crText,
				  COLORREF crBkgnd,
				  CRect& rect, 
				  FOP_LISTCTRL_ITEM *pCLD);

	
	// Calc drawing colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Colors, Returns the specified value.
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		colorText---colorText, Specifies A 32-bit COLORREF value used as a color value.  
	//		colorBkgnd---colorBkgnd, Specifies A 32-bit COLORREF value used as a color value.
	void GetDrawColors(int nItem,
					   int nSubItem,
					   COLORREF& colorText,
					   COLORREF& colorBkgnd);

	
	// Subclass header control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subclass Header , .

	void SubclassHeaderControl();

	// Is header control subclassed or not.
 
	// Header Is Subclassed, This member sets TRUE if it is right.  
	BOOL			m_bHeaderIsSubclassed;

	// Extend listctrl style.
 
	// Extended Style X, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD			m_dwExtendedStyleX;

	// High light color
 
	// D High Light, This member sets A 32-bit value used as a color value.  
	COLORREF		m_cr3DHighLight;

	// Window color.
 
	// Window, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crWindow;

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPListCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Column Click, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Font, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnSetFont(WPARAM wParam, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	afx_msg void MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct );
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLISTCTRL_H__6EAF5B00_E575_435C_B1D5_BC638EF1D06A__INCLUDED_)
