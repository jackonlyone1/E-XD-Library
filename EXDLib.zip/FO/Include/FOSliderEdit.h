//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOSLIDEREDIT_H__C9D7B786_2F0C_11D6_A536_525400EA266C__INCLUDED_)
#define AFX_FOSLIDEREDIT_H__C9D7B786_2F0C_11D6_A536_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOSliderEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOSliderEdit window

#define WM_FO_SLIDER_CHANGE         WM_USER + 313
#define WM_FO_SLIDER_CLOSE          WM_USER + 314

#include "FODefines.h"

class CFOSliderEdit;
void FO_API_DECL AFXAPI DDX_SliderEditCtrl (CDataExchange *pDX, int nIDC, CFOSliderEdit &Ctrl);

 
//===========================================================================
// Summary:
//     The CFOSliderEdit class derived from CEdit
//      F O Slider Edit
//===========================================================================

class FO_EXT_CLASS CFOSliderEdit : public CEdit
{
// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Slider Edit, Constructs a CFOSliderEdit object.
	//		Returns A  value (Object).
	CFOSliderEdit();

// Attributes
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOSliderEdit object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new control
	virtual BOOL Create(
		// Extend style.
		DWORD dwExStyle,
		// Window name.
		LPCTSTR lpszWindowName, 
		// Style.
		DWORD dwStyle, 
		// Rectangle.
		const RECT& rect, 
		// Pointer of parent wnd.
		CWnd* pParentWnd, 
		// Control ID.
		UINT nID
		);

	// Attach the control to a given ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Edit, Attaches this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCtlID---Ctl I D, Specifies A integer value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	BOOL AttachEdit(
		// Control ID.
		int nCtlID, 
		// Pointer of parent wnd.
		CWnd* pParentWnd
		);

// Operations
public:
	
	// Set current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOSliderEdit
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void	SetPos(const int nPos);

	// Get current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns a int type value.
	int		GetPos() const					{ return m_nCurrentPos; }

	// Set slider value range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range, Sets a specify value to current class CFOSliderEdit
	// Parameters:
	//		nMin---nMin, Specifies A integer value.  
	//		nMax---nMax, Specifies A integer value.
	void	SetRange(int nMin,int nMax )	{ m_nMinValue = nMin; m_nMaxValue = nMax; }

	// Set the min value of range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range Minimize, Sets a specify value to current class CFOSliderEdit
	// Parameters:
	//		nMin---nMin, Specifies A integer value.
	void    SetRangeMin(int nMin)			{ m_nMinValue = nMin; }

	// Set the max value of range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range Maximize, Sets a specify value to current class CFOSliderEdit
	// Parameters:
	//		nMax---nMax, Specifies A integer value.
	void    SetRangeMax(int nMax)			{ m_nMaxValue = nMax; }

protected:

	// Update button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Button, Call this member function to update the object.

	void UpdateButton();

	// When click on the button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Clicked, This member function is called by the framework to allow your application to handle a Windows message.

	void    OnClicked();

	// Draw button normal state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nState---nState, Specifies A integer value.
	void	DrawButton(CDC *pDC,int nState = 0);

	// Draw button disable satate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Disable State, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		ptStart---ptStart, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	void	DrawDisableState(CDC& dc, CPoint ptStart, int nWidth, int nHeight);

	// Hit test on the button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Button, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	BOOL	HitTestButton(CPoint pt);

	// Override the function to handle error input message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Input Error, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ShowInputError();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOSliderEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Slider Edit, Destructor of class CFOSliderEdit
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOSliderEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOSliderEdit)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Calculate Size, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bCalcValidRects---Calculate Valid Rects, Specifies A Boolean value.  
	//		lpncsp---A pointer to the NCCALCSIZE_PARAMS FAR or NULL if the call failed.
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc L Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Paint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnNcPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.

	afx_msg void OnUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void OnEnable(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Move, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	afx_msg void OnMove(int x, int y);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Number Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		lParam---lParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit LONG signed integer.
    afx_msg LRESULT OnNumberChange(WPARAM lParam, LPARAM wParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		lParam---lParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit LONG signed integer.
    afx_msg LRESULT OnSelectCancel(WPARAM lParam, LPARAM wParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg FOPNcHitTestType value (Object).  
	// Parameters:
	//		point---Specifies A CPoint type value.
	afx_msg FOPNcHitTestType OnNcHitTest(CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Mouse down
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL			m_bMouseDown;

	// Current value.
 
	// Current Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentPos;

	// Min value.
 
	// Minimize Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMinValue;

	// Max value.
 
	// Maximize Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMaxValue;

	// Mouse state
 
	// State, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nState;

	// Button position.
 
	// Button, This member sets a CRect value.  
	CRect			m_rcButton;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOSLIDEREDIT_H__C9D7B786_2F0C_11D6_A536_525400EA266C__INCLUDED_)
