//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOScaleUint.h: interface for the CFOScaleUint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSCALEUINT_H__48AC69B5_D1AE_11D6_A666_0050BAE30439__INCLUDED_)
#define AFX_FOSCALEUINT_H__48AC69B5_D1AE_11D6_A666_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////////
// Field unit
enum FieldUnit 
{ 
	FUNIT_NONE = -1,
	FUNIT_INCHES,		//0
	FUNIT_FEET,			//1
	FUNIT_MM,			//2
	FUNIT_CM,			//3
	FUNIT_METERS,		//4
	FUNIT_KM,			//5
	FUNIT_YARDS,		//6
	FUNIT_MILES,		//7
	FUNIT_POINTS,		//8
	FUNIT_TWIPS,		//9
	FUNIT_LOGPOINT		//10
};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOScaleUint
//
// This class is defined for Unit Convert,you can convert unit from one type to other.
// For example:
// Convert from inches to CM
//		double dInch = 5.0;
//		CFOScaleUint eUnit;
//		double dCM = eUnit.ConvertInchsTo(FUNIT_CM,dInch);
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a CFOScaleUint object, just call the constructor.
//      F O Scale Uint
//===========================================================================

class FO_EXT_CLASS CFOScaleUint  
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Scale Uint, Constructs a CFOScaleUint object.
	//		Returns A  value (Object).
	CFOScaleUint();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Scale Uint, Destructor of class CFOScaleUint
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOScaleUint();

	// Paper formats.
	enum FOP_PaperFormat 
	{
		Custom, 
		Letter, 
		Legal, 
		Executive,
        A0, 
		A1,
		A2, 
		A3, 
		A4, 
		A5, 
		A6, 
		A7, 
		A8, 
		A9, 
        B0, 
		B1, 
		B2, 
		B3, 
		B4, 
		B5, 
		B6, 
		B7, 
		B8, 
		B9, 
		B10,
        C5E, 
		Comm10E,
        DLE, 
		Folio, 
		Tabloid, 
		NPageSize 
	};
public:
	// Obtain the paper size from the paper format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Format To Size, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		nType---nType, Specifies a FOP_PaperFormat nType object(Value).  
	//		&dWidth---&dWidth, Specifies a double &dWidth object(Value).  
	//		&dHeight---&dHeight, Specifies a double &dHeight object(Value).
	static void GetPaperFormatToSize(FOP_PaperFormat nType, double &dWidth, double &dHeight);

	// Gets the paper format which matches the given size. If no
	// format matches, RS2::Custom is returned.
	static CFOScaleUint::FOP_PaperFormat GetPaperSizeToFormat(double &dWidth, double &dHeight);

	// Converts a paper format to a string (e.g. for a A0).
	static CString ConvertPaperFormatToString(CFOScaleUint::FOP_PaperFormat nType);

	// Converts a string to a paper format.
	static CFOScaleUint::FOP_PaperFormat ConvertStringToPaperFormat(const CString& str);

public:
	
	// Get unit string
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// rStr -- return string value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Unit String, .
	// This member function is a static function.
	// Parameters:
	//		&eUnit---&eUnit, Specifies a const FieldUnit &eUnit object(Value).  
	//		rStr---rStr, Specifies A CString type value.
	static void TakeUnitStr(const FieldUnit &eUnit, CString& rStr);

	// Convert inches to.
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Inchs To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertInchsTo(const FieldUnit &nUint,double dValue);

	// Convert feet to.
	// eUnit -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Feet To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertFeetTo(const FieldUnit &nUint,double dValue);

	// Convert yards to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Yards To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertYardsTo(const FieldUnit &nUint,double dValue);

	// Convert Miles to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Miles To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertMilesTo(const FieldUnit &nUint,double dValue);

	// Convert Millimeters to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert M M To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertMMTo(const FieldUnit &nUint,double dValue);

	// Convert Centimeters to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert C M To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertCMTo(const FieldUnit &nUint,double dValue);

	// Convert Meters to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Meters To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertMetersTo(const FieldUnit &nUint,double dValue);

	// Convert Kilometers to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert K M To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertKMTo(const FieldUnit &nUint,double dValue);

	// Convert point to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Points To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertPointsTo(const FieldUnit &nUint,double dValue);

	// Convert point to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Logical Point To X, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertLogPointToX(const FieldUnit &nUint,double dValue);


	// Convert point to.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nFromUint---From Uint, Specifies A integer value.  
	//		&nToUint---To Uint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double ConvertFromTo(const FieldUnit &nFromUint,const FieldUnit &nToUint,double dValue);


	// Convert log point to,use logical instead of.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Logical Point To, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		nValue---nValue, Specifies A integer value.  
	//		bHeight---bHeight, Specifies A Boolean value.
	static double ConvertLogPointTo(const FieldUnit &nUint,int nValue,BOOL bHeight = FALSE);

	// Convert to log point,use logical point instead.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Logical Point, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		bHeight---bHeight, Specifies A Boolean value.
	static int ConvertToLogPoint(const FieldUnit &nUint,double dValue,BOOL bHeight = FALSE);

	// Convert to log point,use logical point instead.
	// nUint -- Unit type to be converted,it must be one of the following value:
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	// dValue -- convert value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Logical Point Extend, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&nUint---&nUint, Specifies A integer value.  
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		bHeight---bHeight, Specifies A Boolean value.
	static double ConvertToLogPointExt(const FieldUnit &nUint,double dValue,BOOL bHeight = FALSE);

	// Convert the size of one logical unit on the screen.
	// nMapMode -- map mode of the screen.
	// szWndExt -- wnd extend size
	// szVpExt -- view port extend size
	// nXUint -- x unit
	// dXValue -- x value
	// nYUint -- y unit
	// dYValue -- y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To M A P Logical, .
	// This member function is a static function.
	// Parameters:
	//		nMapMode---Map Mode, Specifies A integer value.  
	//		szWndExt---Window Extend, Specifies A CSize type value.  
	//		szVpExt---Vp Extend, Specifies A CSize type value.  
	//		&nXUint---X Uint, Specifies A integer value.  
	//		&dXValue---X Value, Specifies a double &dXValue object(Value).  
	//		&nYUint---Y Uint, Specifies A integer value.  
	//		&dYValue---Y Value, Specifies a double &dYValue object(Value).
	static void ConvertToMAPLog(const int nMapMode,
	                               const CSize& szWndExt,
	                               const CSize& szVpExt,
	                               FieldUnit &nXUint,double &dXValue,
	                               FieldUnit &nYUint,double &dYValue);

};

// Determines if the given unit of measure is metric or not.
FO_API_DECL BOOL AFX_API FOIsMetric(const FieldUnit &nUint);

#endif // !defined(AFX_FOSCALEUINT_H__48AC69B5_D1AE_11D6_A666_0050BAE30439__INCLUDED_)
