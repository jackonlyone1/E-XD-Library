//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOFormProperties.h: interface for the CFOFormProperties class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOFORMPROPERTIES_H__5D3EDD1E_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOFORMPROPERTIES_H__5D3EDD1E_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseProperties.h"
#include "FOGlobals.h"

// Only define for form design mode.
// Form Margin size.
#define FO_FORM_MARGIN_X					14	  // Default form margin width.
#define FO_FORM_MARGIN_Y					14	  // Default form margin height.

const COLORREF fo_DefaultFormBackColor		= RGB(255,255,255);
const int	   fo_DefaultFormFontPointSize	= 10;
const double   fo_DefaultFormGridX			= 0.10;
const double   fo_DefaultFormGridY			= 0.10;
const COLORREF fo_DefaultFormGridColor		= RGB(192,192,192);

//////////////////////////////////
// Standard model properties.
//////////////////////////////////
#define M_ID_3DBORDER		2001
#define M_ID_CLOSEBUTTON	2002
#define M_ID_MINBUTTON		2003
#define M_ID_MAXBUTTON		2004
#define M_ID_HELPBUTTON		2005
#define M_ID_ICON			2006
#define M_ID_TITLEBAR		2007
#define M_ID_MARGIN			2008
#define M_ID_GRIDX			2009
#define M_ID_GRIDY			2010
#define M_ID_GRIDCOLOR		2011
#define M_ID_SHOWGRID		2012
#define M_ID_SNAPGRID		2013
#define M_ID_GRIDLINETYPE	2014
#define M_ID_MARGIN_X_START 2015
#define M_ID_MARGIN_Y_START 2016
#define M_ID_MARGIN_X_END	2017
#define M_ID_MARGIN_Y_END	2018
#define M_ID_NAME			2019
#define M_ID_CAPTION		2020
#define M_ID_TYPE			2021
#define M_ID_DESIGNMODE		2022
#define M_ID_LOCK			2023
#define M_ID_ALLOWHOLE		2024

#define M_ID_FONT_FACENAME	2033
#define M_ID_FONT_POINTSIZE 2034
#define M_ID_FONT_HEIGHT	2035
#define M_ID_FONT_COLOR		2036
#define M_ID_FONT_WEIGHT	2037
#define M_ID_FONT_ITALIC	2038
#define M_ID_FONT_UNDERLINE 2039
#define M_ID_FONT_STRIKEOUT 2040

#define M_ID_BK_COLOR		2050
#define M_ID_PAGE_BK_COLOR	2051
#define M_ID_BURSHTYPE		2052
#define M_ID_PATTERNCOLOR	2053

// Printing x scale.
#define M_ID_PRINTXSCALE    2054

// Printing y scale.
#define M_ID_PRINTYSCALE    2055

//************************************************************
//   CFOFormProperties
//
// This class defines all the default properties values for CFODataModel,
// you can call FindProperty which is defined within class CFODataModel to search
// this properties object.
//
//************************************************************

 
//===========================================================================
// Summary:
//     The CFOFormProperties class derived from CFOBaseProperties
//      F O Form Properties
//===========================================================================

class FO_EXT_CLASS CFOFormProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFormProperties---F O Form Properties, Specifies a E-XD++ CFOFormProperties object (Value).
	DECLARE_SERIAL(CFOFormProperties)

// Construction/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Form Properties, Constructs a CFOFormProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOFormProperties(int nCurID = FO_DEFAULT_FORM_PROP_ID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Form Properties, Constructs a CFOFormProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOFormProperties& propShape object(Value).
	CFOFormProperties(const CFOFormProperties& propShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Form Properties, Destructor of class CFOFormProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFormProperties();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current property.
	virtual CFOBaseProperties* Copy();

public:
	/*************************************************************************
	|*
	|* Basic properties,these properties only validate with Form edit Mode.
	|* You can call SetFormMode(..),that defined within class CFODataModel.
	|*
	\************************************************************************/

	// Define for form mode only.
	// deciding if being 3d border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has3 D Border, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	Has3DBorder() const;

	// Change to 3d border mode
	// bHas -- with 3d border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set3 D Border, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	Set3DBorder(const BOOL &bHas);


	// deciding if there being close button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Close Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasCloseButton() const;
 
	// Change to close button mode
	// bHas -- with close button or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Close Button, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	SetCloseButton(const BOOL &bHas);


    // deciding if there being min button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Minimize Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasMinButton() const;
 
	// Change to min button mode
	// bHas -- with minimize button or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimize Button, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	SetMinButton(const BOOL &bHas);


	// deciding if there being max button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Maximize Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasMaxButton() const;
 
	// Change to max button mode
	// bHas -- with maximize button or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Button, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	SetMaxButton(const BOOL &bHas);


	// deciding if there being help button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Help Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasHelpButton() const;

	// Change to show help button mode.
	// bHas -- with help button show or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Help Button, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	SetHelpButton(const BOOL &bHas);


	// deciding if there being icon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Icon, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasIcon() const;

	// show dialog top left icon.
	// bHas -- with icon show or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Icon, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	ShowIcon(const BOOL &bHas);


	// deciding if there being title bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Title Bar, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasTitleBar() const;

	// show title bar
	// bHas -- with title bar showing or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Title Bar, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	ShowTitleBar(const BOOL &bHas);


    // deciding if there being margin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Margin, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	HasMargin() const;

	// show margin
	// bHas -- with margin show or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Margin, Call this function to show the specify object.
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void	ShowMargin(const BOOL &bHas);

public:
	/*************************************************************************
	|*
	|* Grid setting properties.
	|*
	\************************************************************************/

	// Grid property.
	// get grid of x
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid X, Returns the specified value.
	//		Returns A double value (Object).
	double		GetGridX() const;

	// change grid of x
	// x -- x grid value or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid X, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&x---Specifies a const double &x object(Value).
	void	SetGridX(const double &x);

	// get grid of y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Y, Returns the specified value.
	//		Returns A double value (Object).
	double		GetGridY() const;

	// change grid of y
	// y -- y grid value or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Y, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&y---Specifies a const double &y object(Value).
	void	SetGridY(const double &y);

	// get grid color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetGridColor() const;

	// change grid color.
	// cr -- grid color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Color, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	 SetGridColor(const COLORREF &cr);

	// deciding if being grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Grid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsGrid() const;

	// show grid or not
	// bS -- show grid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Grid, Call this function to show the specify object.
	// Parameters:
	//		&bS---&bS, Specifies A Boolean value.
	void	ShowGrid(BOOL const &bS);

	// get snap to grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Snap To Grid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL    IsSnapToGrid() const { return m_bSnapToGrid; }

	// set snap to grid mode.
	// bSnap -- with snap to grid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap To Grid, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bSnap---&bSnap, Specifies A Boolean value.
	void    SetSnapToGrid(const BOOL &bSnap) { m_bSnapToGrid = bSnap; }

	// get grid line type,it will return one of the following value:
	// enum FO_GRIDLINE_TYPE
	// {
	// 	GRID_CROSSLINE = 0,			// Cross grid line
	// 	GRID_DOT,					// Dot grid.
	// 	GRID_RECTANGLE				// Rectangle grid line.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Line Type, Returns the specified value.
	//		Returns A FO_GRIDLINE_TYPE value (Object).
	FO_GRIDLINE_TYPE GetGridLineType() const { return m_nGridLineType; }

	// set grid line type.
	// nType -- It must be one of the following value:
	// enum FO_GRIDLINE_TYPE
	// {
	// 	GRID_CROSSLINE = 0,			// Cross grid line
	// 	GRID_DOT,					// Dot grid.
	// 	GRID_RECTANGLE				// Rectangle grid line.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Type, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nType---&nType, Specifies a const FO_GRIDLINE_TYPE &nType object(Value).
	void SetGridLineType(const FO_GRIDLINE_TYPE &nType) { m_nGridLineType = nType; }

public:
	/*************************************************************************
	|*
	|* Change margin of the form, it only works with Form edit Mode.
	|*
	\************************************************************************/

	// Define for margin of form
	// get margin x-start
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin X Start, Returns the specified value.
	//		Returns a int type value.
	int		GetMarginXStart() const;

	// Change margin start X value.
	// x -- start margin x value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin X Start, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&x---Specifies A integer value.
	void	SetMarginXStart(const int &x);

	// get margin y-start
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin Y Start, Returns the specified value.
	//		Returns a int type value.
	int		GetMarginYStart() const;

	// Change form start Y value.
	// y -- start margin y value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin Y Start, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&y---Specifies A integer value.
	void	SetMarginYStart(const int &y);

	// get margin x-end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin X End, Returns the specified value.
	//		Returns a int type value.
	int		GetMarginXEnd() const;

	// Change margin end x value.
	// x -- end margin x value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin X End, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&x---Specifies A integer value.
	void	SetMarginXEnd(const int &x);

	// get margin y-end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margin Y End, Returns the specified value.
	//		Returns a int type value.
	int		GetMarginYEnd() const;

	// Change margin end y value.
	// y -- end margin y value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margin Y End, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&Y---&Y, Specifies A integer value.
	void	SetMarginYEnd(const int &Y);

public:

	// Get Object Name, returns the name of the data model, the object name is not used for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectName()	const;

	// Get Object Name, change the name of the data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Name, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectName(
		// Specify the name of data model.
		const CString &str
		);

	// Define for text.
	// Get Object Caption, this is also the label of some data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const;

	// Set Object Caption,you can also call this method to change the label of datamodel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(
		// Specify the new caption.
		const CString &str
		);

	// Get Type,this is not used by the system.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetType()	const;

	// Change the type of the data model, this is not used by the system.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetType(const UINT &nT);


	// deciding if being design mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Design Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsDesignMode()	const;

	// Change to design mode,with design mode you can modify the shapes on the canvas,such as Moving,Resizing... etc.
	// bD -- design mode or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Design Mode, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bD---&bD, Specifies A Boolean value.
	void	SetDesignMode(const BOOL &bD);

	// deciding if being locked,not used by the system,this is a temp property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsLock() const;

	// Change to lock mode,not used by the system,this is a temp property value.
	// bL -- lock or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Component, .
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void	LockComp(const BOOL &bL);

	// Is allow hole link,if it is true,when you move the mouse on the port of the shape,you can start draw link now.
	// This is defined by quick drawing link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Hole Link, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsAllowHoleLink() const;

	// Change to allow hole link mode,if it is true,when you move the mouse on the port of the shape,
	// you can start draw link now.
	// This is defined by quick drawing link.
	// bAllow -- allow hole link or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Hole Link, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bAllow---&bAllow, Specifies A Boolean value.
	void	SetAllowHoleLink(const BOOL &bAllow);

public:

	// Form back color.
	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41, it is used for fill hatch back color.
	// crBkColor -- new back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// get the outside of the page back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetPageBkColor() const;

	// Change the outside of the canvas back color.
	// crBkColor -- new page back color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Background Color, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void	SetPageBkColor(const COLORREF &crBkColor);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,canvas use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Get bitmap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	// Change the Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold, 500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

public:
	
	/*************************************************************************
	|*
	|* printing properties
	|*
	\************************************************************************/

	// Return Print X Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print X Scale, Returns the specified value.
	//		Returns a float value.
	float GetPrintXScale() const { return m_fPrintXScale;}
	
	// Change Print X Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print X Scale, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetPrintXScale( const float &fValue ) {m_fPrintXScale = fValue; }
	
	// Return Print Y Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Y Scale, Returns the specified value.
	//		Returns a float value.
	float GetPrintYScale() const { return m_fPrintYScale;}
	
	// Change Print Y Scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Y Scale, Sets a specify value to current class CFOFormProperties
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetPrintYScale( const float &fValue ) {m_fPrintYScale = fValue; }

public:

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOFormProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

	//Define for brush.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Grid Pen, You construct a CFOFormProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CPen* CreateGridPen(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetGridPen(CDC* pDC = NULL);

	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Grid Pen Object, .

	void ReleaseGridPenObject();

	// Is Current Grid pen null
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Grid Pen Null, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsGridPenNull();


	//Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOFormProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont* CreateFont(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void ReleaseFontObject();

public:

	// change to logical axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// from logical size to point size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

public:
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOFormProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFormProperties& propEdit object(Value).
	virtual CFOFormProperties& operator=(const CFOFormProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFormProperties propEdit object(Value).
	virtual BOOL operator==(const CFOFormProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
// Attributes
protected:
	
	// Name of Shape.
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strName;

	// Caption of Shape.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;

	// Type of Shape.
 
	// Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nType;

	// Is Design mode or not.
 
	// Design Mode, This member sets TRUE if it is right.  
	BOOL			m_bDesignMode;
	
	// Is Object Lock or not
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// Cached GDI brush. 
 
	// Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData	m_pBrush;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, This member specify E-XD++ CFOFontObjectData object.  
	CFOFontObjectData	m_pFont;

	// Define for win 9x only.
 
	// New Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			*m_pNewFont;

	//Define for form.
	//	Grid step x.
 
	// Step, This member specify double object.  
	double				m_xStep;
	
	//	Grid step y.
 
	// Step, This member specify double object.  
	double				m_yStep;

	// Grid color.
 
	// Grid, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crGrid;

	//Margin width
 
	// Margin Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cxMarginStart;

	//Margin height
 
	// Margin Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cyMarginStart;

	//Margin width
 
	// Margin End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cxMarginEnd;

	//Margin height
 
	// Margin End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cyMarginEnd;

	// Show or hide grid.
 
	// Grid, This member sets TRUE if it is right.  
	BOOL			m_bGrid;

	// Show or hide snap to grid.
 
	// Snap To Grid, This member sets TRUE if it is right.  
	BOOL			m_bSnapToGrid;

	// Show or hide close button.
 
	// Close Button, This member sets TRUE if it is right.  
	BOOL			m_bCloseButton;

	// Show or hide min button.
 
	// Minimize Button, This member sets TRUE if it is right.  
	BOOL			m_bMinButton;

	// Show or hide max button.
 
	// Maximize Button, This member sets TRUE if it is right.  
	BOOL			m_bMaxButton;

	// Show or hide help button.
 
	// Help Button, This member sets TRUE if it is right.  
	BOOL			m_bHelpButton;

	// Show or hide icon.
 
	// Has Icon, This member sets TRUE if it is right.  
	BOOL			m_bHasIcon;

	// Show or hide Title bar.
 
	// Title Bar, This member sets TRUE if it is right.  
	BOOL			m_bTitleBar;

	// Show or hide 3D Border.
 
	// D Border, This member sets TRUE if it is right.  
	BOOL			m_b3DBorder;

	// Show or hide margin.
 
	// Margin, This member sets TRUE if it is right.  
	BOOL			m_bMargin;

	// Page background color.
 
	// Page Back, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crPageBack;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;


	// Allow or not allow link directly.
 
	// Allow Hole Link, This member sets TRUE if it is right.  
	BOOL			m_bAllowHoleLink;

	// Pen.
 
	// Grid Pen, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen*			m_pGridPen;

	// Grid line type.
 
	// Grid Line Type, This member specify FO_GRIDLINE_TYPE object.  
	FO_GRIDLINE_TYPE m_nGridLineType;

	// Print X Scale value.
 
	// Print X Scale, This member specify The float keyword designates a 32-bit floating-point number.  
	float            m_fPrintXScale;
	
	// Print Y Scale value.
 
	// Print Y Scale, This member specify The float keyword designates a 32-bit floating-point number.  
	float            m_fPrintYScale;

};

#include "FOFormProperties.inl"

#endif // !defined(AFX_FOFORMPROPERTIES_H__5D3EDD1E_F259_11DD_A433_525400EA266C__INCLUDED_)
