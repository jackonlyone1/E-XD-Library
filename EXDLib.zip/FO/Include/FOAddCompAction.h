//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOAddCompAction.h: interface for the CFOAddCompAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOADDCOMPACTION_H__2EEABBFC_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOADDCOMPACTION_H__2EEABBFC_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

class CFOCompositeShape;
//////////////////////////////////////////////////////////////////////////////////
// CFOAddCompAction -- add component to canvas action.

 
//===========================================================================
// Summary:
//     The CFOAddCompAction class derived from CFOAction
//      F O Add Component Action
//===========================================================================

class FO_EXT_CLASS CFOAddCompAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddCompAction---F O Add Component Action, Specifies a E-XD++ CFOAddCompAction object (Value).
	DECLARE_ACTION(CFOAddCompAction)

public:
	// member
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Component Action, Constructs a CFOAddCompAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOAddCompAction(CFODataModel* pModel, CFODrawShape* pShape);

	// member
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Component Action, Destructor of class CFOAddCompAction
	//		Returns A  value (Object).
	~CFOAddCompAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	//Executes the action
	virtual BOOL		Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action, override this method to generate text of action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

    // Set shape member variable m_pShape to the pointer of pShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOAddCompAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	//  Returns a pointer to the Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOAddCompAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Set index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFOAddCompAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetIndex(const int &nIndex) { m_nIndex = nIndex; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

// Attributes
protected:

	// a pointer to the Shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
	// Current index within.
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nIndex;

	// Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

//  Returns a pointer to the Shape	
_FOLIB_INLINE CFODrawShape *CFOAddCompAction::GetShape()
{
	return m_pShape;
}

#include "FODrawPortsShape.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOAddPortAction -- action that add port to canvas or shapes.

 
//===========================================================================
// Summary:
//     The CFOAddPortAction class derived from CFOAction
//      F O Add Port Action
//===========================================================================

class FO_EXT_CLASS CFOAddPortAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddPortAction---F O Add Port Action, Specifies a E-XD++ CFOAddPortAction object (Value).
	DECLARE_ACTION(CFOAddPortAction)

public:
	//cmember
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Port Action, Constructs a CFOAddPortAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFOPortShape or NULL if the call failed.
	CFOAddPortAction(CFODataModel* pModel, CFOPortShape* pShape);

	//cmember
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Port Action, Destructor of class CFOAddPortAction
	//		Returns A  value (Object).
	~CFOAddPortAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	//Executes the action
	virtual BOOL		Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

    // Set shape member variable m_pShape to the pointer of pShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOAddPortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetShape(CFOPortShape *pShape);
	
	//  Returns a pointer to the Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetShape();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed
	CFODrawPortsShape *GetCompShape() { return m_pPortsShape; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOAddPortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	virtual void SetCompShape(CFODrawPortsShape *pComp) { m_pPortsShape = pComp; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

// Attributes
protected:

	// a pointer to the Shape
 
	// Shape, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pShape;

	// member variable,a pointer to the composite shape.
 
	// Ports Shape, This member maintains a pointer to the object CFODrawPortsShape.  
	CFODrawPortsShape *m_pPortsShape;
    
	// Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

//  Returns a pointer to the Shape	
_FOLIB_INLINE CFOPortShape *CFOAddPortAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOADDCOMPACTION_H__2EEABBFC_F19E_11DD_A432_525400EA266C__INCLUDED_)
