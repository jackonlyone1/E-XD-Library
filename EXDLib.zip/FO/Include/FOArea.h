//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOArea.h: interface for the CFOArea class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOAREA_H__A431E051_67A3_11DF_A46B_525400EA266C__INCLUDED_)
#define AFX_FOAREA_H__A431E051_67A3_11DF_A46B_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////////
//
// CFOSmallArea
// 
// An area includes many small area,this class is defined for CFOAra.
//
/////////////////////////////////////////////////////////////////////////////////

#include "FOPSimplePolygon.h"

/////////////////////////////////////////////////////////////////
// CFOSmallArea -- small area of a shape, one shape's aread will be split to many small
// area, it is used for hit testing.

 
//===========================================================================
// Summary:
//     The CFOSmallArea class derived from CObject
//      F O Small Area
//===========================================================================

class FO_EXT_CLASS CFOSmallArea : public CObject
{
protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSmallArea---F O Small Area, Specifies a E-XD++ CFOSmallArea object (Value).
	DECLARE_SERIAL(CFOSmallArea);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).
	CFOSmallArea();

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		area---Specifies a const CFOSmallArea& area object(Value).
	CFOSmallArea(const CFOSmallArea& area);

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	CFOSmallArea(
		// Points array.
		LPPOINT pptPoints, 
		// Total of point.
		int nCount
		);

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	CFOSmallArea(
		const FOPPoint &ptStart, 
		const FOPPoint &ptEnd
		);

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		<CPoint---C Point, Specifies A CArray array.  
	//		&aPoints---&aPoints, Specifies A CPoint type value.
	CFOSmallArea(
		const CArray <CPoint, CPoint> &aPoints
		);

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		poly---Specifies a const FOPPolygon& poly object(Value).
	CFOSmallArea(const FOPPolygon& poly);


	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Small Area, Constructs a CFOSmallArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		apoly---Specifies a const FOPSimplePolygon& apoly object(Value).
	CFOSmallArea(const FOPSimplePolygon& apoly);

	//-----------------------------------------------------------------------
	// Summary:
	// Convert to polygon.
	// Need call delete by hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPolygon value (Object).
	virtual FOPPolygon ConvertToPolygon();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Small Area, Destructor of class CFOSmallArea
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOSmallArea();

	//-----------------------------------------------------------------------
	// Summary:
	// Normal points.
	// Allow memory for the points of the shape.
	// nCount -- total points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Memory,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCount---nCount, Specifies A integer value.
	virtual void		AllocMemory(int nCount);

public:
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize the data to file.
	virtual void Serialize(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Save the specify document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(
		// Specifies file name.
		LPCTSTR lpszPathName
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Open the specify document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(
		// Specifies file name.
		LPCTSTR lpszPathName
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of file.
	// lpszFileName -- file name.
	// nOpenFlags -- open file flags.
	// pError -- pointer of the file exception.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//-----------------------------------------------------------------------
	// Summary:
	// Release file.
	// pFile -- pointer of the file.
	// bAbort -- abort or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOSmallArea& value (Object).  
	// Parameters:
	//		area---Specifies a const CFOSmallArea& area object(Value).
	CFOSmallArea& operator=(const CFOSmallArea& area);
	
	//-----------------------------------------------------------------------
	// Summary:
	// operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		area---Specifies a E-XD++ CFOSmallArea area object (Value).
	BOOL operator==(const CFOSmallArea &area) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// operator !=.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		area---Specifies a E-XD++ CFOSmallArea area object (Value).
	BOOL operator!=(const CFOSmallArea &area) const;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bounding Rectangle, Returns the specified value.
	//		Returns a FOPRect type value.
	FOPRect	GetBoundingRect() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get points pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	//		Returns A LPPOINT value (Object).
	LPPOINT GetPoints() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get the specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CPoint	GetPoint(
		// Index of point.
		int nIndex
		) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get the total point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count, Returns the specified value.
	//		Returns a int type value.
	int		GetPointCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Update current rgn.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Area, Call this member function to update the object.

	void	UpdateArea();

	//-----------------------------------------------------------------------
	// Summary:
	// Is in current rgn.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Area, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A integer value.  
	//		nIndex---nIndex, Specifies A integer value.
	BOOL	PickInArea(
		// Mouse hit point.
		POINT point, 
		// Index of point.
		int nIndex
		) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Insert a new point.
	// nIndex -- index of the insert position.
	// point -- new insert point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Point, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		point---Specifies A CPoint type value.
	virtual BOOL		InsertPoint(int nIndex, const CPoint& point);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert multiple points.
	// nIndex -- insert position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Points, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		lpInsertPoints---Insert Points, Specifies A LPPOINT Points array.  
	//		nInsertCount---Insert Count, Specifies A integer value.
	// lpInsertPoints -- insert points.
	// nIndestCount -- total points inserted.
	virtual BOOL		InsertPoints(int nIndex,LPPOINT lpInsertPoints, const int nInsertCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert multiple points.
	// nIndex -- insert position.
	// arPoints -- points array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Points, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		arPoint---arPoint, Specifies A CPoint type value.
	virtual BOOL		InsertPoints(int nIndex,const CArray<CPoint,CPoint>& arPoint);

	//-----------------------------------------------------------------------
	// Summary:
	// Set spot at a specify position.
	// nIndex -- index of the point.
	// point -- new point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point At, Sets a specify value to current class CFOSmallArea
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		point---Specifies A CPoint type value.
	virtual void		SetPointAt(int nIndex, const CPoint& point);

	//-----------------------------------------------------------------------
	// Summary:
	// Add a new spot at the end.
	// point -- new point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Point, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL		AddPoint(const CPoint& point);

	//-----------------------------------------------------------------------
	// Summary:
	// Add multiple points.
	// lpInsertPoints -- array of the points that be inserted.
	// nInsertCount -- count of the points to be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpInsertPoints---Insert Points, Specifies A LPPOINT Points array.  
	//		nInsertCount---Insert Count, Specifies A integer value.
	virtual BOOL		AddPoints(LPPOINT lpInsertPoints, const int nInsertCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Add multiple points.
	// arPoint -- array of the points that be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		arPoint---arPoint, Specifies A CPoint type value.
	virtual BOOL		AddPoints(const CArray<CPoint,CPoint>& arPoint);

	//-----------------------------------------------------------------------
	// Summary:
	// Delete a specify point.
	// nIndex -- index of the point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Point, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL		DeletePoint(int nIndex);

	//-----------------------------------------------------------------------
	// Summary:
	// Is polygon area or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Polygon Area, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL				IsPolyArea() const { return m_bPolygonArea; }

	//-----------------------------------------------------------------------
	// Summary:
	// Set polygon area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Polygon Area, Sets a specify value to current class CFOSmallArea

	void				SetPolyArea() { m_bPolygonArea = TRUE; }
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Is point in current rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		rect---Specifies A FOPRect type value.
	BOOL	PtInRect(
		// Mouse hit point.
		CPoint point,
		// Specifies rectangle for hit.
		FOPRect rect
		) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute the angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Angle, .
	//		Returns a int type value.  
	// Parameters:
	//		point1---Specifies A CPoint type value.  
	//		point2---Specifies A CPoint type value.
	int		ComputeAngle(
		// Start angle point.
		const CPoint point1, 
		// End angle point.
		const CPoint point2
		) const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Bounding rectangle of area.
 
	// Position, This member sets a FOPRect value.  
	FOPRect		m_rcPosition;

	// 
	// Multi points buffer.
	FOPPolygonBindData *mpPointAry;

	// Is polygon area or not.
 
	// Polygon Area, This member sets TRUE if it is right.  
	BOOL		m_bPolygonArea;
};

// List of small area.
typedef CTypedPtrList<CObList, CFOSmallArea*> CFOSmallAreaList;

/////////////////////////////////////////////////////////////////////////////////
//
// CFOArea
//
// Each kind of shape must has its area,this is CFOArea. With area we can hit testing
// and update the area of the shape.
// 
// Override the GeometryUpdated(..) method which is defined within class CFODrawShape
// to generate the area for the shape.
//
// Method BuildArea is used to generate line, polygon, bezier kind of areas.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOArea class derived from CObject
//      F O Area
//===========================================================================

class FO_EXT_CLASS CFOArea : public CObject
{
protected:
	// Declare serial class
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOArea---F O Area, Specifies a E-XD++ CFOArea object (Value).
	DECLARE_SERIAL(CFOArea);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Area, Constructs a CFOArea object.
	//		Returns A  value (Object).
	CFOArea();

	//-----------------------------------------------------------------------
	// Summary:
	// copy constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Area, Constructs a CFOArea object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rgn---Specifies a const CFOArea& rgn object(Value).
	CFOArea(const CFOArea& rgn);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Area, Destructor of class CFOArea
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOArea();

public:
	enum AreaFlag
	{
		AreaNone = -1,			// None
		AreaLine,				// Line area.
		AreaPolygon,			// Polygon area.
		AreaBezierLine,			// Bezier Line area.
		AreaCloseBezier,		// Close Bezier area.
		AreaRect				// Rect.
	};

public:
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize the data to file.
	virtual void Serialize(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Save the specify document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(
		// Specifies file name.
		LPCTSTR lpszPathName
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Open the specify document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(
		// Specifies file name.
		LPCTSTR lpszPathName
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get the pointer of file.
	// lpszFileName -- file name.
	// nOpenFlags -- open file flags.
	// pError -- pointer of the file exception.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//-----------------------------------------------------------------------
	// Summary:
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Is valid area.
	BOOL IsValid();

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Get position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bounding Rectangle, Returns the specified value.
	//		Returns a FOPRect type value.
	FOPRect GetBoundingRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	void Clear();

	//-----------------------------------------------------------------------
	// Summary:
	// Re compute the position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Validate Area, .

	void ValidateArea();

	//-----------------------------------------------------------------------
	// Summary:
	// Get the count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Point Count, Returns the specified value.
	//		Returns a int type value.
	int GetMultiPointCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get the specify area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Area At, Returns the specified value.
	//		Returns A const CFOSmallArea& value (Object).  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CFOSmallArea& GetMultiAreaAt(
		// Index of small area.
		int nIndex
		) const;

public:
	//-----------------------------------------------------------------------
	// Summary:
	// ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rgn---Specifies a const CFOArea& rgn object(Value).
	BOOL operator==(const CFOArea& rgn) const;

	//-----------------------------------------------------------------------
	// Summary:
	// !=.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rgn---Specifies a const CFOArea& rgn object(Value).
	BOOL operator!=(const CFOArea& rgn) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set Mult_Area At region
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Area At, Sets a specify value to current class CFOArea
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		area---Specifies a const CFOSmallArea& area object(Value).
	void SetMultiAreaAt(
		// Index to insert new area.
		int nIndex,
		// Small area.
		const CFOSmallArea& area
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Mult_Area rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Area Rectangle, Returns the specified value.
	//		Returns a FOPRect type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	FOPRect GetMultiAreaRect(
		// Index of small area.
		int nIndex
		) const;

	// Build rectangle area.
	void BuildRect(FOPRect &rc);

	//-----------------------------------------------------------------------
	// Summary:
	// Build line area.
	// nType -- It must be one of the following value:
	// enum AreaFlag
	// {
	// 	AreaNone = -1,			// None
	// 	AreaLine,				// Line area.
	// 	AreaPolygon,			// Polygon area.
	// 	AreaBezierLine,			// Bezier Line area.
	// 	AreaCloseBezier			// Close Bezier area.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		nType---nType, Specifies a AreaFlag nType object(Value).
	virtual void BuildArea(
		// Array of points.
		LPPOINT pptPoints,
		// Total point.
		int nCount,
		// Area flag states.
		AreaFlag nType);


	//-----------------------------------------------------------------------
	// Summary:
	// Build polygon area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Polygon Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void BuildPolygonArea(
		// Array of points.
		LPPOINT pptPoints, 
		// Total of point.
		int nCount
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Build polygon area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Polygon Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void XBuildPolygonArea(
		// Array of points.
		FOPFloat* pptPoints, 
		// Total of point.
		int nCount
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Build complex area with types.
	// lppPoints -- points for drawing.
	// lyTypes -- polygon type
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Complex Area, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lppPoints---lppPoints, Specifies A LPPOINT Points array.  
	//		lpTypes---lpTypes, Specifies An 8-bit BYTE integer that is not signed.  
	//		cCount---cCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void BuildComplexArea(CONST LPPOINT lppPoints, CONST LPBYTE lpTypes, int cCount, const BOOL &bClose = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add spline area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Spline Line2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		spline---Specifies A spline line type value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void AddSpline(const FOPSplineGeometry& spline, const BOOL &bClose = FALSE);


	//-----------------------------------------------------------------------
	// Summary:
	// Add complex area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add complex area, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		geometry---Specifies A complex line type value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void AddComplexGeometry(const FOPComplexGeometry& geometry, const BOOL &bClose = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier Line2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		pt2---Specifies A CPoint type value.  
	//		pt3---Specifies A CPoint type value.  
	//		pt4---Specifies A CPoint type value.
	virtual void AddBezierLine2(const CPoint& pt1,const CPoint& pt2,const CPoint& pt3,const CPoint& pt4);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Line area.
	// ptStart -- start point of the line
	// ptEnd -- end point of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.
	virtual void AddLine(const FOPPoint &ptStart,const FOPPoint &ptEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Add lines to area
	// points -- points of the line
	// count -- count of the points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Lines, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddLines(const FOPPoint* points,int count);

	//-----------------------------------------------------------------------
	// Summary:
	// Add polygon to area.
	// points -- points of the polygon
	// count -- count of the polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddPolygon(const FOPPoint* points,int count);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc area.
	// ptCenter -- center point of the rectangle that bounding the arc shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddArc(const FOPPoint& ptCenter, long nRx, long nRy, int nStartAngle = 0, int nEndAngle = 3600);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A FOPRect type value.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddArc(const FOPRect &rcPos, int nStartAngle = 0, int nEndAngle = 3600);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A FOPRect type value.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddPie(const FOPRect &rcPos, int nStartAngle = 0, int nEndAngle = 3600);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.  
	//		pt4---Specifies A integer value.  
	//		bClose---bClose, Specifies A Boolean value.
	virtual void AddBezier(const FOPPoint& pt1,const FOPPoint& pt2,const FOPPoint& pt3,const FOPPoint& pt4, 
		BOOL bClose = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier Line2, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.  
	//		pt4---Specifies A integer value.
	virtual void AddBezierLine2(const FOPPoint& pt1,const FOPPoint& pt2,const FOPPoint& pt3,const FOPPoint& pt4);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Beizers
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Beziers, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.  
	//		bClose---bClose, Specifies A Boolean value.
	virtual void AddBeziers(const FOPPoint* points,int count, 
		BOOL bClose = TRUE);
    
	//-----------------------------------------------------------------------
	// Summary:
	// Add rectangle to area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A FOPRect type value.
	virtual void AddRect(const FOPRect& rect);

	//-----------------------------------------------------------------------
	// Summary:
	// Add rectangles to area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rects, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rects---A pointer to the const FOPRect or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddRects(const FOPRect* rects, int count);

	//-----------------------------------------------------------------------
	// Summary:
	// Add ellipse to area
	// rect -- rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ellipse, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void AddEllipse(const FOPRect& rect);

	//-----------------------------------------------------------------------
	// Summary:
	// Build polygon area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Extend Polygon, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&aPolygon---&aPolygon, Specifies a const FOPSimplePolygon &aPolygon object(Value).  
	//		bClose---bClose, Specifies A Boolean value.
	virtual void AddExtPolygon(const FOPSimplePolygon &aPolygon,BOOL bClose);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build polygon area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Extend Polygon Polygon, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&aPolyPolygon---Polygon Polygon, Specifies a const FOPSimpleCompositePolygon &aPolyPolygon object(Value).  
	//		bClose---bClose, Specifies A Boolean value.
	virtual void AddExtPolyPolygon(const FOPSimpleCompositePolygon &aPolyPolygon,BOOL bClose);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Operator =.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOArea& value (Object).  
	// Parameters:
	//		area---Specifies a const CFOArea& area object(Value).
	CFOArea& operator=(const CFOArea& area);


	//-----------------------------------------------------------------------
	// Summary:
	// Hit test,
	// ptLog -- It must be Logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Area, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptLog---ptLog, Specifies a POINT ptLog object(Value).  
	//		nLine---nLine, Specifies A integer value.
	BOOL PickInArea(
		// Log point of mouse hit.
		POINT ptLog, 
		// Line width,only for line shape
		int nLine = 0
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Hit test,
	// ptLog -- It must be Logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Area, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptLog---ptLog, Specifies a POINT ptLog object(Value).  
	//		nLine---nLine, Specifies A integer value.
	BOOL XPickInArea(
		// Log point of mouse hit.
		FOPFloat ptLog, 
		// Line width,only for line shape
		int nLine = 0
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Combine the areas.
	// area -- the combine area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Combine Area, .
	// Parameters:
	//		area---Specifies a const CFOArea& area object(Value).
	void CombineArea(const CFOArea& area);

	//-----------------------------------------------------------------------
	// Summary:
	// Get a more near point to the area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		ptIn---ptIn, Specifies A LPPOINT Points array.  
	//		ptOut---ptOut, Specifies A LPPOINT Points array.  
	//		&nSpace---&nSpace, Specifies A integer value.
	CPoint GetNearestPoint(
		// Input points.
		LPPOINT ptIn, 
		// Out points.
		LPPOINT ptOut,
		// nSpace -- nearest space.
		const int &nSpace = 4) const;

	CPoint GetRoundPoint(FOPPoint ptFirst, FOPPoint ptSecond, BOOL bNeedx, BOOL bInvertX, CPoint &pt) const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Bounding rectangle.
 
	// Position, This member sets a FOPRect value.  
	FOPRect					m_rcPosition;

	// Points array.
	CArray<CPoint,CPoint>*  m_arPoints;

	// Area array.
	CArray<CFOSmallArea, const CFOSmallArea&> mpAryPolyPolygon;

	// FOPPolyPolygon object.
 
	// A Polygon, This member maintains a pointer to the object FOPPolyPolygon.  
	FOPPolyPolygon		*m_pAPolygon;

	// Points array.
	CArray<CPoint,CPoint>  m_arTempPoints;

};

// define type CTypedPtrList,list of area.
typedef CTypedPtrList<CObList, CFOArea*> CFOAreaList;

#endif // !defined(AFX_FOAREA_H__A431E051_67A3_11DF_A46B_525400EA266C__INCLUDED_)
