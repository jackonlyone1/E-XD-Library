//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTABCONTROLWND_H__CB8CC9E8_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
#define AFX_FOTABCONTROLWND_H__CB8CC9E8_FAA6_11D5_A4DF_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTabControlWnd.h : header file
//

#include "FOTabSheetObject.h"
#include "FOLabelEdit.h"

 
//===========================================================================
// Summary:
//     The CFOTabControlWnd class derived from CWnd
//      F O Tab  Window
//===========================================================================

class FO_EXT_CLASS CFOTabControlWnd : public CWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabControlWnd---F O Tab  Window, Specifies a E-XD++ CFOTabControlWnd object (Value).
	DECLARE_DYNCREATE(CFOTabControlWnd)
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab  Window, Constructs a CFOTabControlWnd object.
	//		Returns A  value (Object).
	CFOTabControlWnd();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab  Window, Destructor of class CFOTabControlWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabControlWnd();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTabControlWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create tab.
	BOOL Create(DWORD dwStyle, const CRect& rect, CWnd* pParent, UINT nID);
	
protected:

	// Set notify window pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify Window, Sets a specify value to current class CFOTabControlWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void	SetNotifyWnd(CWnd* pWnd);

	// Create all fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Font, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	AdjustFont();

	// Release the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ReleaseFont();

	// Create all brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Brush, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	AdjustBrush();
	
	// Get active tab positon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int     GetActiveTabPos();

public:

	// Change current tab position to a new position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Tab Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void	ChangeTabPosition(int nTab);

	// Get sep of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab separator, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual int     GetTabSep(int nTab);

	// Get next tab offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Next Offset, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	virtual int     GetTabNextOffset(int nPos);

protected:
	// Draw tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Tabs, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nTab---nTab, Specifies A integer value.
	virtual void    OnDrawTabs(CDC* pDC, int nTab);

	// Draw arrows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Arrow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nNumber---nNumber, Specifies A integer value.  
	//		bPressed---bPressed, Specifies A Boolean value.
	virtual void    OnDrawArrow(CDC* pDC, int nNumber, BOOL bPressed);

	// Move arrows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Move Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void    StartMoveButton(UINT nType);

	// Hit test tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void    HitTest(CPoint point);

	// Hit test tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Right Button, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void    HitTestRightButton(CPoint point);

	// Hit test arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Arrow, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A integer value.
	virtual int     HitTestArrow(CPoint point, int nButton = -1);

	// Do help method.
	void DoHelpMethod1();

	// Gen new sheet.
	virtual CFOTabSheetObject *DoGenSheetObj();

public:

	// Tabs array.
 
	// Tab Pages, This member specify CObArray object.  
	CObArray		m_arTabPages;

	// Current select tab index.
 
	// Select, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSelect;

	// Count of tabs.
 
	// Total Tabs, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalTabs;

// Operations
public:

	// TabInfo
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab, Returns the specified value.
	//		Returns A E-XD++ CFOTabSheetObject& value (Object).  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabSheetObject& GetTab(int nTab);

	// Inserts a tab into the list of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tab, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.  
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		hMenu---hMenu, Specifies a HMENU hMenu = 0 object(Value).  
	//		&bAutoRemove---Automatic Remove, Specifies A Boolean value.
	virtual void   InsertTab(CString strLabel,CFOTabPageModel*pModel,CWnd* pWnd = NULL,HMENU hMenu = 0,const BOOL &bAutoRemove = FALSE);

	// Remove a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void   RemoveTab(int nTab);

	// Adjust tab space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Tab Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void   AdjustTabSize(int nTab);

	// Find a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Index, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the const CWnd  or NULL if the call failed.
	virtual int    GetTabIndex(const CWnd *pWnd);

	// Find tab by a specify model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Index, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabSheetObject,or NULL if the call failed  
	// Parameters:
	//		*pModel---*pModel, A pointer to the const CFOTabPageModel  or NULL if the call failed.
	virtual CFOTabSheetObject*	GetTabIndex(const CFOTabPageModel *pModel);

	// Current Selection, TabCount
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab, Returns the specified value.
	//		Returns a int type value.
	int     GetActiveTab() const;

	// Returns the number of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	//		Returns a int type value.
	int     GetTabCount() const;

	// Goto specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Goto Direction, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nDir---nDir, Specifies A integer value.
	virtual void    GotoDirection(int nDir);

	// Find tab by label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual BOOL FindTab(CString strLabel);

	// Find tab with window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the const CWnd  or NULL if the call failed.
	virtual BOOL FindTab(const CWnd *pWnd);

	// Find tab by label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual int FindTabIndex(CString strLabel);

	// Is double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Edit Label, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableEditLabel() const { return m_bEnableEditLabel; }

	// Set double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Edit Label, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void		EnableEditLabel(const BOOL bEnable) { m_bEnableEditLabel = bEnable; }

protected:
	// Generated message map functions
	//{{AFX_MSG(CFOTabControlWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

public:

	// Sep space.
 
	// Space separator, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nSpaceSep;

	// Cursor.
 
	// Drag Currsor, This member specify HCURSOR object.  
	HCURSOR     m_hDragCurrsor;

	// Mouse click down type.
 
	// Down Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nDownType;

	// Mouse click down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL        m_bMouseDown;

	// Has button.
 
	// Has Button, This member sets TRUE if it is right.  
	BOOL        m_bHasButton;

	// Border space.
 
	// Border Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nBorderSpace;

	
	// Item width.
 
	// Item Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nItemWidth;

	// Begin drag.
 
	// Begin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nBegin;

	// Visible.
 
	// Visible, This member sets TRUE if it is right.  
	BOOL        m_bVisible;

	// Capture the mouse.
 
	// Capture, This member sets TRUE if it is right.  
	BOOL        m_bCapture;

	// T
 
	// Track, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nTrack;          

	// Page item height.
 
	// Tab Item Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nTabItemHeight;
	
	// Number of buttons.
 
	// Number Button, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nNumberButton;


	// Notify wnd pointer.
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*       m_pNotifyWnd;

	///////////////////////////////////////////////////////
	// Define font.
	// Active page font.
 
	// Active Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*      m_pActiveFont;

	// UnActive page font.
 
	// Un Active Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*      m_pUnActiveFont;

	//////////////////////////////////////////////////////////
	// Define color.
	// Sheet back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF    m_crBack;

	// Select page text color.
 
	// Select, This member sets A 32-bit value used as a color value.  
	COLORREF    m_crSelect; 

	// Sheet color.
 
	// Sheet, This member sets A 32-bit value used as a color value.  
	COLORREF    m_crSheet;

	// Active page text color.
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF    maTextColor;

	// Un active page text color.
 
	// Text Disable Color, This member sets A 32-bit value used as a color value.  
	COLORREF    maTextDisableColor;

	// Enable of disable the double click to edit the label.
 
	// Enable Edit Label, This member sets TRUE if it is right.  
	BOOL		m_bEnableEditLabel;

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTABCONTROLWND_H__CB8CC9E8_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
