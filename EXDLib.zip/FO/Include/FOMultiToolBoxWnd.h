//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOMULTITOOLBOXWND_H__BC45D798_E140_11D5_A4B1_525400EA266C__INCLUDED_)
#define AFX_FOMULTITOOLBOXWND_H__BC45D798_E140_11D5_A4B1_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOMultiToolBoxWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOMultiToolBoxWnd window

#include "FOToolBoxPageWnd.h"
#include "FODrawShape.h"
#include "FODropSource.h"

#define FO_FS_ANIMATESCROLL				(0x0002)
#define FO_FS_BUTTONFOCUS				(0x0004)

// Forward Declarations
class CFOToolBoxPage;

// Types
typedef CArray<CFOToolBoxPage*,CFOToolBoxPage*> CFOToolBoxPageArray;

 
//===========================================================================
// Summary:
//     The CFOMultiToolBoxWnd class derived from CWnd
//      F O Multiple Tool Box Window
//===========================================================================

class FO_EXT_CLASS CFOMultiToolBoxWnd : public CWnd
{
public:

	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Tool Box Window, Constructs a CFOMultiToolBoxWnd object.
	//		Returns A  value (Object).
	CFOMultiToolBoxWnd();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Tool Box Window, Destructor of class CFOMultiToolBoxWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiToolBoxWnd();
	
	// Is hmi child window mode.
	BOOL			m_bHMIChildWnd;

	// Parent shape.
	CFODrawShape *	m_pShape;
	CFOOleDropTargetEx	m_DropTarget;
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();
	

	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
public:

	// set back color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// set text horizon alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextHorzAlignment(const UINT &nT);

	// set text vertical alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Vertical Alignment, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextVertAlignment(const UINT &nT);

	// set multi-line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Line, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void		SetMultiLine(const BOOL &bMulti);

public:

	// set face name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);
   
	// set size of point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// set height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// set color of font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// set weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// set italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// set underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// set strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

	// Is mouse on button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse On Button, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMouseOnButton();

	// Obtain the pointer of selected toolbox item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Item, Returns the specified value.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	CFOToolBoxItem *GetSelectItem();

public:

	// Get tool box wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tool Box Window, Returns the specified value.
	//		Returns a pointer to the object CFOToolBoxPageWnd ,or NULL if the call failed
	CFOToolBoxPageWnd *GetToolBoxWnd();

	// activate page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Page, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void ActivatePage(int nIndex);
	
	// select page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Page, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void SelectPage( int nIndex ){ ActivatePage(nIndex); }

	// Re calc the window layout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RecalcLayout();

	// disable page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Disable Page, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void DisablePage( int nIndex );

	// enable page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Page, Call this member function to enable or disable the specify object for this command.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void EnablePage( int nIndex );

	// When drag and drop object call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Drag And Drop, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual void WhenDragAndDrop(CFOToolBoxItem *pItem);

	// When double click on item call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Double click Clickp, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual void WhenDblClickp(CFOToolBoxItem *pItem);

	// When click on item call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Double click Clickp, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual BOOL WhenClickItem(CFOToolBoxItem *pItem);

	// Customize Context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Customize Context Menu, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&menu---Specifies a CMenu &menu object(Value).
	virtual void CustomizeContextMenu(CMenu &menu);

	// add a new papge.
	// lpszText -- title of new page.
	// bRedaraw -- need or not redraw.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Page, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed  
	// Parameters:
	//		strText---strText, Specifies A CString type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
    virtual CFOToolBoxPage* AddPage(CString strText,BOOL bRedraw=FALSE);

	// insert a page at index
	// lpszText -- title of new page.
	// bRedaraw -- need or not redraw.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Page, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		strText---strText, Specifies A CString type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual CFOToolBoxPage* InsertPage(int nIndex, CString strText, BOOL bRedraw=FALSE);

	// remove a page at index
	// iIndex -- index to remove.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Page, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void RemovePage(int nIndex);

	// reanmae a page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename Page, Call this function to Changes the name of the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		strText---strText, Specifies A CString type value.
	virtual void RenamePage(int nIndex, CString strText );
    
// Attributes
public:

	// Get view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Style, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetViewStyle() const;

	// Set view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Style, Sets a specify value to current class CFOMultiToolBoxWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nStyle---&nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void SetViewStyle(const UINT &nStyle);

	// Obtain the animate flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Animate Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAnimateMode();

	// Change the animate mode flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Animate Mode, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		&bMode---&bMode, Specifies A Boolean value.
	void SetAnimateMode(const BOOL &bMode);

	// Change the animation speed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Animation Speed, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		nSpeed---nSpeed, Specifies A integer value.
	void SetAnimationSpeed( const int& nSpeed );

	// Obtain the animation speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Animation Speed, Returns the specified value.
	//		Returns a int type value.
	int GetAnimationSpeed() const;

	// Change the steps for animation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Animation Step, Sets a specify value to current class CFOMultiToolBoxWnd
	// Parameters:
	//		nStep---nStep, Specifies A integer value.
	void SetAnimationStep( const int& nStep );

	// Obtain the steps for animation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Animation Step, Returns the specified value.
	//		Returns a int type value.
	int GetAnimationStep() const;

	// Do helper method.
	void DoHelpMethod1(const int &nIndex);
	
	// Re cal set page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Cal Set Page, .
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void ReCalSetPage(int nIndex = -1 );

	// Re cal set page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Cal Page Font, .
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void ReCalPageFont(int nIndex = -1 );

	// create context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();

	// Remove all pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Pages, Call this function to remove a specify value from the specify object.

	void RemoveAllPages();

	// Set cursor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void FOSetCursor(UINT nID);
	
	// Set system cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set System Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszCursor---lpszCursor, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void FOSetSystemCursor(LPCTSTR lpszCursor);

	// Enable or not the context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Context Menu, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableContextMenu(const BOOL &bEnable);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create(
		// Toolbox style.
		DWORD dwStyle, 
		// Position of the control
		const RECT& rect,
		// Pointer of parent wnd.
		CWnd* pParentWnd, 
		// Control ID.
		UINT nID,
		// Pointer of context.
		CCreateContext* pContext = NULL 
		);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyleEx---Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( 
		// Specify the style of toolbox.
		DWORD dwStyle,
		// Specify the extend style.
		DWORD dwStyleEx, 
		// Position of control.
		const RECT& rect,
		// Pointer of parent wnd.
		CWnd* pParentWnd, 
		// Control ID.
		UINT nID, 
		// Pointer of context.
		CCreateContext* pContext = NULL 
		);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
		DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	// Create extend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		hWndParent---Window Parent, Specifies a HWND hWndParent object(Value).  
	//		nIDorHMenu---I Dor H Menu, Specifies a HMENU nIDorHMenu object(Value).  
	//		lpParam---lpParam, Specifies a LPVOID lpParam = NULL object(Value).
	virtual BOOL CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
		                   int x, int y, int cx, int cy, HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

	// Creation new window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Tool Box , Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL AttachToolBoxCtrl( 
		// Resource control ID.
		UINT uID, 
		// Pointer of parent wnd.
		CWnd* pParentWnd 
		);

	// Get the count of pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Count, Returns the specified value.
	//		Returns a int type value.
    int GetPageCount() const;
	
	// get or decide active page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Page, Returns the specified value.
	//		Returns A E-XD++ CFOToolBoxPage& value (Object).
	CFOToolBoxPage& GetActivePage() const;

	// Has active page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Active Page, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL    HasActivePage() const;
	
	// get index or active page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Index, Returns the specified value.
	//		Returns a int type value.
	int		GetActiveIndex() const;

	// Get the specify index of page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page, Returns the specified value.
	//		Returns A E-XD++ CFOToolBoxPage& value (Object).  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOToolBoxPage&	GetPage(int nIndex ) const;

	// Get the pointer of page.
	// nIndex -- the index of page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Pointer, Returns the specified value.
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOToolBoxPage* GetPagePtr(int nIndex ) const;
	
	// Hit test page.
	// pt -- point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Page, Determines if the mouse has been clicked on a component.
	//		Returns a int type value.  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	int HitPage( const CPoint& pt );

	// Hit test page icon.
	// pt -- point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Page Icon, Determines if the mouse has been clicked on a component.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A CPoint type value.  
	//		&rc---Specifies A CRect type value.
	BOOL HitPageIcon( const CPoint& pt,CRect &rc);

	// Do mouse over drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Do Before Over Page, Returns the specified value.
	//		Returns a int type value.
	int GetPreOverPage();

protected:
	
	// Prepare draw dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PrepareDC();

	// clear draw dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearDC();

	// Draw pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).
	virtual void DoPaint( CDC& dc );

	// Invalidate a specify page.
	// nPage -- the index of page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Page, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nPage---nPage, Specifies A integer value.
	virtual void InvalidatePage( int nPage );

	// Invalidate a specify page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Page, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		Page---Page, Specifies a E-XD++ CFOToolBoxPage& Page object (Value).
	virtual void InvalidatePage( CFOToolBoxPage& Page );

	// Invalidate a specify page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Page, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOToolBoxPage or NULL if the call failed.
	virtual void InvalidatePage( CFOToolBoxPage* pPage );

protected:
	// compute size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nNew---nNew, Specifies A integer value.  
	//		nOld---nOld, Specifies A integer value.
	virtual void ComputeSize( int nNew, int nOld );

	// set rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setup Rects, Sets a specify value to current class CFOMultiToolBoxWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVert---bVert, Specifies A Boolean value.  
	//		rc---Specifies A CRect type value.
	virtual void SetupRects( BOOL bVert, CRect& rc );

	// set position of page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Positions, Sets a specify value to current class CFOMultiToolBoxWnd
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetPagePositions();

	// create a new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Page, You construct a CFOMultiToolBoxWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed
	virtual CFOToolBoxPage* CreateNewPage() const;

	// set page at index no animate scroll
	
	//-----------------------------------------------------------------------
	// Summary:
	// No Animate Scroll, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void NoAnimateScroll( int nIndex );

	// Animate scroll.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Animate Scroll, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nOld---nOld, Specifies A integer value.  
	//		nNew---nNew, Specifies A integer value.
	virtual void AnimateScroll( int nOld, int nNew );

	// find prev active page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Previous Active Page, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void FindPrevActivePage( int& nIndex );

	// find next active page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Next Active Page, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void FindNextActivePage( int& nIndex );

protected:
	// remove a page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL OnRemovePage(int nIndex );

	// disable a page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Disable Page, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL OnDisablePage(int nIndex );

	// enable a page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable Page, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL OnEnablePage(int nIndex );

	// change page styles
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Style Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dwRemovedStyles---Removed Styles, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwAddedStyles---Added Styles, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void OnStyleChange( DWORD dwRemovedStyles, DWORD dwAddedStyles );

	// change a page at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Page, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL OnChangePage(int nIndex );

	// create a new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create Page, Called as a part of window creation.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOToolBoxPage or NULL if the call failed.
	virtual BOOL OnCreatePage( CFOToolBoxPage* pPage );

	// When add page call this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Add Page, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed  
	// Parameters:
	//		strText---strText, Specifies A CString type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual CFOToolBoxPage* WhenAddPage(CString strText, BOOL bRedraw );

	// When insert page call this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Insert Page, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		strText---strText, Specifies A CString type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual CFOToolBoxPage* WhenInsertPage( int nIndex,CString strText, BOOL bRedraw );

	// Is file exist or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// File Exists, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFilePath---File Path, Specifies A CString type value.
	BOOL XFileExists(CString strFilePath);

public:

	// Find item with type.
	CFOToolBoxItem *FindItemWithType(const int &nType);
	
	// Find item with name.
	CFOToolBoxItem *FindItemWithName(const CString &strName);

	// Saving data file.
	virtual void SaveDataFile();
	
	// Change font height with specify view type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change View Page Font, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nViewType---View Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void ChangeViewPageFont(UINT nViewType);

	// function deciding existing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Exists, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPage---nPage, Specifies A integer value.
    BOOL IsExists(int nPage) const;

	// Override this to hook in a CFOToolBoxPageWnd derived object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Tool Box Page Window, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCreateToolBoxPageWnd();

	// Do creating new toolbox item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Tool Box Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	virtual CFOToolBoxItem *DoCreateToolBoxItem();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiToolBoxWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL	

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOMultiToolBoxWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Closefile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxClosefile();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Closefile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxClosefile(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Loadfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxLoadfile();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Loadfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxLoadfile(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Newfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxNewfile();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Newfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxNewfile(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Saveasfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxSaveasfile();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Saveasfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxSaveasfile(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Savefile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxSavefile();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Savefile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxSavefile(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Menu Popup, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pPopupMenu---Popup Menu, A pointer to the CMenu or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysMenu---System Menu, Specifies A Boolean value.
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	// Key down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Icon Detail, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxIconDetail();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Icon Detail, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxIconDetail(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Icons Names, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxIconsNames();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Icons Names, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxIconsNames(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Name, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxName();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Name, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxName(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Pageprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxPageprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Pageprop, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxPageprop(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Capture Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	afx_msg void OnCaptureChanged(CWnd *pWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Leave, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnMouseLeave(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// object of class
 
	// Tool Box Window, This member maintains a pointer to the object CFOToolBoxPageWnd.  
	CFOToolBoxPageWnd *m_pToolBoxWnd;	
	
	// Enable context menu.
	BOOL				m_bEnableMenu;

	// object of class
 
	// Pages, This member specify E-XD++ CFOToolBoxPageArray object.  
	CFOToolBoxPageArray		m_arPages;	
	
	// View style.
 
	// View Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nViewStyle;
	
	// flag of active index
 
	// Active Index, This member sets TRUE if it is right.  
	BOOL			m_bActiveIndex;		
	
	// flag of button down
 
	// Button Down, This member sets TRUE if it is right.  
	BOOL			m_bBtnDown;			
	
	
	// size of las window
 
	// Window Size, This member sets a CSize value.  
	CSize			m_lastWndSize;		
	
	// back ground brush
 
	// Brush Back, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*			m_pBrushBack;		
	
	
	// pointer to class
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*			m_pContextMenu;		
	
	// index of hit
 
	// Hit Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHitIndex;		
	
	// active index
 
	// Active Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nActiveIndex;		
	
	// last total page size
 
	// Last Total Page Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLastTotalPageSize;	
	
	// step of animation
 
	// Animation Step, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nAnimationStep;	
	
	// last total button size
 
	// Last Total Button Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLastTotalBtnSize;
	
	// speed of animation
 
	// Animation Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nAnimationSpeed;	
	
	
	// Animate mode.
 
	// Animate Mode, This member sets TRUE if it is right.  
	BOOL			m_bAnimateMode;     
	
	
	// Mouse over state.
 
	// Mouse Over, This member sets TRUE if it is right.  
	BOOL			m_bMouseOver;
	
	// Mouse push state.
 
	// Pushed, This member sets TRUE if it is right.  
	BOOL			m_bPushed;
	
	// Mouse push tracking state.
 
	// Push Tracking, This member sets TRUE if it is right.  
	BOOL			m_bPushTracking;
	
	// Is track or not.
 
	// Tracked, This member sets TRUE if it is right.  
	BOOL			m_bTracked;
	
	// Current cursor handle.
 
	// Cursor, This member specify HCURSOR object.  
	HCURSOR			m_hCursor;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOMULTITOOLBOXWND_H__BC45D798_E140_11D5_A4B1_525400EA266C__INCLUDED_)
