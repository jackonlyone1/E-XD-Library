//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-201? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/

#ifndef __FOSOLUTION_H
#define __FOSOLUTION_H

/********************************************************************/
// Solutions that include within this package
/********************************************************************/

#define _FO_VERSION_			0x32010
#define _FO_VERSION_MAJOR		32
#define _FO_VERSION_MINOR		0
#define _FO_VERSION_BUILD		2022010160
/********************************************************************/

// Chart solution
#ifndef _FOP_CHART_SOLUTION
#define _FOP_CHART_SOLUTION
#endif

// Table solution
#ifndef _FOP_TABLE_SOLUTION
#define _FOP_TABLE_SOLUTION
#endif

// Gauge solution
#ifndef _FOP_GAUGE_SOLUTION
#define _FOP_GAUGE_SOLUTION
#endif

// Layout solution
#ifndef _FOP_LAYOUT_SOLUTION
#define _FOP_LAYOUT_SOLUTION
#endif

// Script solution
#ifndef _FOP_SCRIPT_SOLUTION
#define _FOP_SCRIPT_SOLUTION
#endif

// Electronic form solution
#ifndef _FOP_E_SOLUTION
#define _FOP_E_SOLUTION
#endif

#endif __FOSOLUTION_H
