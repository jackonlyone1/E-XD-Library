//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPFULLSCREENIMPL_H__732BFA0F_2B6A_4F13_9925_4BFFE720014D__INCLUDED_)
#define AFX_FOPFULLSCREENIMPL_H__732BFA0F_2B6A_4F13_9925_4BFFE720014D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPFullScreenImpl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPFullScreenImpl window

#include "FOPToolBar.h"

 
//===========================================================================
// Summary:
//      To use a CFOPFullScreenImpl object, just call the constructor.
//      F O P Full Screen Impl
//===========================================================================

class FO_EXT_CLASS CFOPFullScreenImpl
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Full Screen Impl, Constructs a CFOPFullScreenImpl object.
	//		Returns A  value (Object).
	CFOPFullScreenImpl();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Full Screen Impl, Destructor of class CFOPFullScreenImpl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPFullScreenImpl();

public:
	
	// Show full screen window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Full Screen, Call this function to show the specify object.
	// Parameters:
	//		bWithMenu---With Menu, Specifies A Boolean value.
	void ShowFullScreen(BOOL bWithMenu);

	// Show full screen.
	// pFrame -- pointer of frame window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Full Screen, Call this function to show the specify object.
	// Parameters:
	//		pFrame---pFrame, A pointer to the CFrameWnd or NULL if the call failed.  
	//		bWithMenu---With Menu, Specifies A Boolean value.
	void ShowFullScreen(CFrameWnd* pFrame, BOOL bWithMenu);

	// Close full screen mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Full Mode, .
	// Parameters:
	//		pFrame---pFrame, A pointer to the CFrameWnd or NULL if the call failed.
	void CloseFullMode(CFrameWnd* pFrame);

	// Is full screen mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Full Screen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFullScreen() const		{ return m_bFullMode; }

	// On get minimize maximize info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Minimize Maximize Information, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		lpMMI---M M I, A pointer to the MINMAXINFO FAR or NULL if the call failed.
	void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);

	// Set frame window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Frame Window, Sets a specify value to current class CFOPFullScreenImpl
	// Parameters:
	//		*pFrame---*pFrame, A pointer to the CFrameWnd  or NULL if the call failed.
	void SetFrameWnd(CFrameWnd *pFrame);

protected:

	// Show all controls bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show All  Bars, Call this function to show the specify object.
	// Parameters:
	//		pFrame---pFrame, A pointer to the CFrameWnd or NULL if the call failed.  
	//		&bVal---&bVal, Specifies A Boolean value.
	void ShowAllCtrlBars(CFrameWnd* pFrame,const BOOL &bVal);

protected:

	// Position of full screen.
 
	// Full Window, This member sets a CRect value.  
	CRect					m_rcFullWindow;

	// Full screen mode
 
	// Full Mode, This member sets TRUE if it is right.  
	BOOL					m_bFullMode;

	// Save frame window position.
 
	// Save Frame, This member sets a CRect value.  
	CRect					m_rcSaveFrame;

	// Pointer of frame wnd.
 
	// Parent Frame, This member maintains a pointer to the object CFrameWnd.  
	CFrameWnd*				m_pParentFrame;

	// Bar state.
	CMap<CControlBar*, CControlBar*, BOOL, BOOL> m_mapSaveBar;

	// Hidden bar state.
	CMap<CControlBar*, CControlBar*, BOOL, BOOL> m_mapHideBar;

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPFULLSCREENIMPL_H__732BFA0F_2B6A_4F13_9925_4BFFE720014D__INCLUDED_)
