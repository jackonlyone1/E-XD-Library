//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOTabShape.h: interface for the CFOTabShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOTABSHAPE_H__70D7EFDA_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOTABSHAPE_H__70D7EFDA_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOTabSubObj.h"
#include "FODrawPortsShape.h"

/////////////////////////////////////////////////////////////////////////////////
// CFOTabShape -- tab control shape with multiple pages support.

 
//===========================================================================
// Summary:
//     The CFOTabShape class derived from CFODrawPortsShape
//      F O Tab Shape
//===========================================================================

class FO_EXT_CLASS CFOTabShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabShape---F O Tab Shape, Specifies a E-XD++ CFOTabShape object (Value).
	DECLARE_SERIAL(CFOTabShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Shape, Constructs a CFOTabShape object.
	//		Returns A  value (Object).
	CFOTabShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Shape, Constructs a CFOTabShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOTabShape& src object(Value).
	CFOTabShape(const CFOTabShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Shape, Destructor of class CFOTabShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTabShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the tab shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTabShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOTabShape& src object(Value).
	CFOTabShape& operator=(const CFOTabShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOTabShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	void SVG_Draw3d(CString &strIn);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Implementation
	// Get the list of tab pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Objects, Returns the specified value.
	//		Returns a pointer to the object CFOTabSubObjList,or NULL if the call failed
	CFOTabSubObjList* GetObjects() { return &m_objectsTab; }

	// Obtain the count of tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	//		Returns a int type value.
	int GetTabCount() { return m_objectsTab.GetCount(); }

	// Find tab with name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFindName---Find Name, Specifies A CString type value.
	BOOL FindTab(const CString &strFindName);

	// Add sub tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tab, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.
	virtual void AddTab(CFOTabSubObj* pObj);

	// Add a new empty sub tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Empty Tab Page, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	virtual void AddEmptyTabPage(const CString &strName);

	// Remove sub tab page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.
	virtual void RemoveTab(CFOTabSubObj* pObj);

	// Remove one page with name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab With Name, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	virtual void RemoveTabWithName(const CString &strName);

	// Adjust tab font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Font, .

	void AdjustFont();

	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Tab, Hit test on this object.
	//		Returns a int type value.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	int HitTestTab(const CPoint &ptHit);

protected:

	// The list of tab pages.
 
	// Tab, This member specify E-XD++ CFOTabSubObjList object.  
	CFOTabSubObjList m_objectsTab;
public:

	// Set active tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Page, Sets a specify value to current class CFOTabShape
	// Parameters:
	//		&nNewCur---New Current, Specifies A integer value.
	void SetActiveTabPage(const int &nNewCur);

	// Remove all tab pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();

	// Fill rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill R G B Rectangle, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.
	void FillRGBRect(CDC* pDC,int x,int y,int cx,int cy, COLORREF rgb);

	// Get the width of label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		bLong---bLong, Specifies A Boolean value.
	int GetLabelWidth(CDC *pDC,CFOTabSubObj* pObj, BOOL bLong);

	// draw tab bottom ,top ,left ,right ,text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tab Bottom, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		rcTab---rcTab, Specifies A CRect type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawTabBottom(CDC* pDC, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF cr);

	void SVG_TabBottom(CString &strIn, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF cr);

	// Draw tabs on top.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tab Top, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		rcTab---rcTab, Specifies A CRect type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawTabTop(CDC* pDC, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF crColor);

	void SVG_TabTop(CString &strIn, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF crColor);

	// Draw tabs on left.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tab Left, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		rcTab---rcTab, Specifies A CRect type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawTabLeft(CDC* pDC, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF cr);

	void SVG_TabLeft(CString &strIn, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF crColor);

	// Draw tab on right.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tab Right, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		rcTab---rcTab, Specifies A CRect type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawTabRight(CDC* pDC, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF cr);

	void SVG_TabRight(CString &strIn, CFOTabSubObj* pObj,CRect rcTab, DWORD dwStyle,COLORREF crColor);

	// Draw tab text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tab Text, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcTab---rcTab, Specifies A CRect type value.  
	//		pObj---pObj, A pointer to the CFOTabSubObj or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void DrawTabText(CDC* pDC, CRect rcTab,CFOTabSubObj* pObj, DWORD dwStyle);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// draws bounding rect in XOR mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Obtain tab position.
	int GetTabPos() const { return nTabPos; }

	// Set tab position.
	void SetTabPos(const int &nPos) { nTabPos = nPos; }
protected:

	// flag of main tab	
 
	// Type Tab Main, This member sets TRUE if it is right.  
	BOOL		bTypeTabMain;	
	
	// pos of tab
 
	// Tab Position, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		nTabPos;	
	
	// color when tab inactive
 
	// Tab In Active, This member sets A 32-bit value used as a color value.  
	COLORREF	crTabInActive;	
	
	// font of draw
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		drawFont;
	
	// color when tab active
 
	// Tab Active, This member sets A 32-bit value used as a color value.  
	COLORREF	crTabActive;	
	
	// pen
 
	// The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_pens[2];		
	
	// brush
 
	// The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
    CBrush		m_brushes[2];
	
	// icon when locked
 
	// Icon Lock, This member specify HICON object.  
	HICON		m_hIconLock;	
	
	// color
 
	// Text[2], This member sets A 32-bit value used as a color value.  
	COLORREF	m_rgbText[2];	
	
	// pen (shadow)
 
	// Shadow, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penShadow;	
	
	// white pen
 
	// White, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
    CPen		m_penWhite;	
	
	// new font
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		newFont;

	// Current active tab page.
 
	// Current Active, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurActive;

	// Mouse pressed.
 
	// Pressed, This member sets TRUE if it is right.  
	BOOL		m_bPressed;

	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL		m_bMouseDown;

	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL		m_bCanPress;
};

#endif // !defined(AFX_FOTABSHAPE_H__70D7EFDA_F31E_11DD_A436_525400EA266C__INCLUDED_)
