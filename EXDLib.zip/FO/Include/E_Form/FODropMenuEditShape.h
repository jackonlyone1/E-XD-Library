//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FODROPMENUEDITSHAPE_H__25892846_A93B_49CD_B1AE_BED842FA2757__INCLUDED_)
#define AFC_FODROPMENUEDITSHAPE_H__25892846_A93B_49CD_B1AE_BED842FA2757__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOEditBoxShape.h"

// Default list box items.
const CString foDefaultListBoxItems1 = _T("Menu item0\r\nMenu item1\r\nMenu item2\r\nMenu item3");

//////////////////////////////////////////////////////////////////////////////////
// CFODropMenuEditShape -- drop menu edit shape.
//------------------------------------------------------
// Description
// Author: Author.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFODropMenuEditShape class derived from CFOEditBoxShape
//      F O Drop Menu Edit Shape
//===========================================================================

class FO_EXT_CLASS CFODropMenuEditShape : public CFOEditBoxShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODropMenuEditShape---F O Drop Menu Edit Shape, Specifies a E-XD++ CFODropMenuEditShape object (Value).
	DECLARE_SERIAL(CFODropMenuEditShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Menu Edit Shape, Constructs a CFODropMenuEditShape object.
	//		Returns A  value (Object).
	CFODropMenuEditShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Menu Edit Shape, Constructs a CFODropMenuEditShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFODropMenuEditShape& src object(Value).
	CFODropMenuEditShape(const CFODropMenuEditShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Menu Edit Shape, Destructor of class CFODropMenuEditShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropMenuEditShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFODropMenuEditShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the edit with button shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODropMenuEditShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFODropMenuEditShape& src object(Value).
	CFODropMenuEditShape& operator=(const CFODropMenuEditShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// area of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Show popup menus.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void ShowPopup( CPoint point, CFOPCanvasCore* parent );

	// Execute menu item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		from---A pointer to the CWnd or NULL if the call failed.
	virtual BOOL DoMessage( UINT msg,CWnd* from = NULL );

	// Get next line of the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Next Line Extend, .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A CString type value.  
	//		&sLine---&sLine, Specifies A CString type value.
	int FOGetNextLineExt(CString& s, CString &sLine);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bFlat---bFlat, Specifies A Boolean value.
	virtual void OnDrawText(CDC *pDC,BOOL bFlat);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Implement edit box control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Implement Edit Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual BOOL ImplementEditBox(CFOPCanvasCore* pView,DWORD dwStyle);

	// Do sub button id click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Button Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSubButtonClick();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:

	// Button item position.
 
	// Button Item, This member sets a CRect value.  
	CRect m_rcButtonItem;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};


/////////////////////////////////////////////////////////////////////////////////
// CFOPCalcEditShape -- calculator edit shape.

 
//===========================================================================
// Summary:
//     The CFOPCalcEditShape class derived from CFOEditBoxShape
//      F O P Calculate Edit Shape
//===========================================================================

class FO_EXT_CLASS CFOPCalcEditShape : public CFOEditBoxShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPCalcEditShape---F O P Calculate Edit Shape, Specifies a E-XD++ CFOPCalcEditShape object (Value).
	DECLARE_SERIAL(CFOPCalcEditShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Calculate Edit Shape, Constructs a CFOPCalcEditShape object.
	//		Returns A  value (Object).
	CFOPCalcEditShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Calculate Edit Shape, Constructs a CFOPCalcEditShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPCalcEditShape& src object(Value).
	CFOPCalcEditShape(const CFOPCalcEditShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Calculate Edit Shape, Destructor of class CFOPCalcEditShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPCalcEditShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPCalcEditShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the edit with button shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPCalcEditShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPCalcEditShape& src object(Value).
	CFOPCalcEditShape& operator=(const CFOPCalcEditShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// area of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Show popup menus.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void ShowPopup( CPoint point, CFOPCanvasCore* parent );

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bFlat---bFlat, Specifies A Boolean value.
	virtual void OnDrawText(CDC *pDC,BOOL bFlat);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Implement edit box control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Implement Edit Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual BOOL ImplementEditBox(CFOPCanvasCore* pView,DWORD dwStyle);

	// Do sub button id click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Button Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSubButtonClick();

	// Obtain the currency symbol	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Currency Symbol, Returns the specified value.
	//		Returns A TCHAR value (Object).
	TCHAR	GetCurrencySymbol();

	// Change the currency symbol
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Currency Symbol, Sets a specify value to current class CFOPCalcEditShape
	// Parameters:
	//		chSymbol---chSymbol, Specifies a TCHAR chSymbol object(Value).
	void	SetCurrencySymbol(TCHAR chSymbol);

	// Convert text to number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Text To Number, .
	//		Returns A double value (Object).  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	double	ConvertTextToNumber(CString strText);

	// Convert number to text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Number To Text, .
	//		Returns a CString type value.  
	// Parameters:
	//		dNumber---dNumber, Specifies a double dNumber object(Value).
	CString ConvertNumberToText(double dNumber);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartEdit(CFOPCanvasCore * pView, CPoint ptCursorSP);
    
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:

	// Button item position.
 
	// Button Item, This member sets a CRect value.  
	CRect			m_rcButtonItem;

	// Char of the symbol
 
	// Currency Symbol, This member specify TCHAR object.  
	TCHAR			m_chCurrencySymbol;
	
	// Number of the precision
 
	// Precision, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPrecision;

	// Be Neg support or not.
 
	// Neg Values, This member sets TRUE if it is right.  
	BOOL			m_bNegValues;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

/////////////////////////////////////////////////////////////////////////////
// FOPProperty object
//

 
//===========================================================================
// Summary:
//      To use a FOPProperty object, just call the constructor.
//      O P Property
//===========================================================================

class FO_EXT_CLASS FOPProperty
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Property, Constructs a FOPProperty object.
	//		Returns A  value (Object).
	FOPProperty();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Property, Constructs a FOPProperty object.
	//		Returns A  value (Object).  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		textColor---textColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		hFont---hFont, Specifies a HFONT hFont = NULL object(Value).  
	//		lphBitmap---lphBitmap, A pointer to the HBITMAP or NULL if the call failed.
	FOPProperty(DWORD dwStyle, COLORREF textColor = 0L, 
		HFONT hFont = NULL, 
		HBITMAP* lphBitmap = NULL);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Property, Constructs a FOPProperty object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aProp---aProp, Specifies a const FOPProperty& aProp object(Value).
	FOPProperty(const FOPProperty& aProp);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Property, Destructor of class FOPProperty
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPProperty();

public:
	// operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPProperty& value (Object).  
	// Parameters:
	//		aProp---aProp, Specifies a const FOPProperty& aProp object(Value).
	const FOPProperty& operator=(const FOPProperty& aProp);
	
	// Obtain the handle of the font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns A HFONT value (Object).
	HFONT GetFont() const;

	// Obtain the color of the text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetTextColor() const;

	// Obtain the handle of the bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	//		Returns A HBITMAP value (Object).
	HBITMAP GetBitmap() const;
	
protected:
	// Handle of the font
 
	// Font, This member specify HFONT object.  
	HFONT    m_hFont;

	// Handle of bitmap
 
	// H Bitmap, This member maintains a pointer to the object HBITMAP.  
	HBITMAP* m_ptHBitmap;

	// Color of the text
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF m_crText;

	// Style
 
	// Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD    m_dwStyle;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPCalcCellObject object
//

 
//===========================================================================
// Summary:
//     The CFOPCalcCellObject class derived from CObject
//      F O P Calculate Cell Object
//===========================================================================

class FO_EXT_CLASS CFOPCalcCellObject : public CObject
{
	// Construction
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Calculate Cell Object, Constructs a CFOPCalcCellObject object.
	//		Returns A  value (Object).
	CFOPCalcCellObject();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Calculate Cell Object, Destructor of class CFOPCalcCellObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPCalcCellObject();

// Attributes
public:
	// Obtain the width of the cell item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetWidth() const;

	// Obtain the command
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Command, Returns the specified value.
	//		Returns A FOPCalcCommand value (Object).
	FOPCalcCommand GetCommand() const;

	// Obtain the state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get State, Returns the specified value.
	//		Returns a int type value.
	int  GetState() const;

	// Change the state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set State, Sets a specify value to current class CFOPCalcCellObject
	// Parameters:
	//		nState---nState, Specifies A integer value.
	void SetState(int nState);

	// Is key
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Key, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszChar---lpszChar, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL IsKey(LPCTSTR lpszChar) const;

	// Check key down
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Key Down, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL IsKeyDown(UINT nChar) const;

	// Set down key
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Key Down, Sets a specify value to current class CFOPCalcCellObject
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetKeyDown(UINT nChar);

	// Obtain the position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns a CRect type value.
	const CRect& GetPosition() const;

	// Change position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPCalcCellObject
	// Parameters:
	//		rcPos---rcPos, Specifies a const RECT& rcPos object(Value).
	void SetPosition(const RECT& rcPos);
	
// Operations
public:

	// Init data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aProp---aProp, Specifies a const FOPProperty& aProp object(Value).  
	//		cmd---Specifies a FOPCalcCommand cmd object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bStartsRow---Starts Row, Specifies A Boolean value.
	BOOL DoInit(const FOPProperty& aProp, FOPCalcCommand cmd, 
					LPCTSTR lpszCaption, int nWidth = 1, 
					BOOL bStartsRow = FALSE);

	// Init data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aProp---aProp, Specifies a const FOPProperty& aProp object(Value).  
	//		cmd---Specifies a FOPCalcCommand cmd object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		cKey---cKey, Specifies a TCHAR cKey object(Value).  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bStartsRow---Starts Row, Specifies A Boolean value.
	BOOL DoInit(const FOPProperty& aProp, FOPCalcCommand cmd, 
					LPCTSTR lpszCaption, TCHAR cKey, int nWidth = 1, 
					BOOL bStartsRow = FALSE);

	// Init data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aProp---aProp, Specifies a const FOPProperty& aProp object(Value).  
	//		cmd---Specifies a FOPCalcCommand cmd object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszKeys---lpszKeys, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		bStartsRow---Starts Row, Specifies A Boolean value.
	BOOL DoInit(const FOPProperty& aProp, FOPCalcCommand cmd, 
					LPCTSTR lpszCaption, LPCTSTR lpszKeys, int nWidth = 1, 
					BOOL bStartsRow = FALSE);

// Overrides
public:
	// Draws the button!
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		&imgEnter---&imgEnter, Specifies a CImageList &imgEnter object(Value).
	virtual void OnDraw(CDC& dc,CImageList &imgEnter);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif

// Implementation, data members.
public:
	
	enum FOPButtonKey
	{
		stateDown      = 0x0001,
		stateStartsRow = 0x0002,
		stateHot       = 0x0004
	};

protected:

	// Property object
 
	// Property, This member specify FOPProperty object.  
	FOPProperty	             m_Property;

	// Caption
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                  m_strCaption;

	// Name of key
 
	// Key, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                  m_strKey;

	// Key down
 
	// Key Down Key, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		             m_nKeyDownKey;

	// Width of the item
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nWidth;

	// Position of the item
 
	// Position, This member sets a CRect value.  
	CRect		             m_rcPosition;

	// Item state
 
	// State, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nState;

	// Handle event
 
	// Handle Event, This member specify FOPCalcCommand object.  
	FOPCalcCommand			 m_HandleEvent;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPCalcCellObjectArray object
//

 
//===========================================================================
// Summary:
//     The CFOPCalcCellObjectArray class derived from CObArray
//      F O P Calculate Cell Object Array
//===========================================================================

class FO_EXT_CLASS CFOPCalcCellObjectArray : public CObArray
{
public:
	// Obtain the cell object of the pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object CFOPCalcCellObject,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPCalcCellObject* GetAt(int nIndex) const
	{ return (CFOPCalcCellObject*)CObArray::GetAt(nIndex); }

	// Get element at a specify index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Element At, .
	//		Returns a pointer to the object CFOPCalcCellObject,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPCalcCellObject*& ElementAt(int nIndex)
	{ return (CFOPCalcCellObject*&)CObArray::ElementAt(nIndex); }

	// Change the object at a speicfy index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At, Sets a specify value to current class CFOPCalcCellObjectArray
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptr---A pointer to the CFOPCalcCellObject or NULL if the call failed.
	void SetAt(int nIndex, CFOPCalcCellObject* ptr)
	{ CObArray::SetAt(nIndex, (CObject*) ptr); }
	
	// Set at grow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At Grow, Sets a specify value to current class CFOPCalcCellObjectArray
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		newElement---newElement, A pointer to the CFOPCalcCellObject or NULL if the call failed.
	void SetAtGrow(int nIndex, CFOPCalcCellObject* newElement)
	{ CObArray::SetAtGrow(nIndex, (CObject*) newElement); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		newElement---newElement, A pointer to the CFOPCalcCellObject or NULL if the call failed.
	// Add a new shape to the index.
	int Add(CFOPCalcCellObject* newElement)
	{ return (int)CObArray::Add((CObject*) newElement); }
	
	// Insert a new object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		newElement---newElement, A pointer to the CFOPCalcCellObject or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.
	void InsertAt(int nIndex, CFOPCalcCellObject* newElement, int nCount = 1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		nStartIndex---Start Index, Specifies A integer value.  
	//		pNewArray---New Array, A pointer to the CFOPCalcCellObjectArray or NULL if the call failed.
	{ CObArray::InsertAt(nIndex, (CObject*) newElement, nCount); }

	// Insert a new object
	void InsertAt(int nStartIndex, CFOPCalcCellObjectArray* pNewArray)
	{ CObArray::InsertAt(nStartIndex, pNewArray); }
	
	// Obtain object at.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFOPCalcCellObject,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPCalcCellObject* operator[](int nIndex) const
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFOPCalcCellObject,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	{ return (CFOPCalcCellObject*)CObArray::operator[](nIndex); }

	// Obtain object at.
	CFOPCalcCellObject*& operator[](int nIndex)
	{ return (CFOPCalcCellObject*&)CObArray::operator[](nIndex); }
};

#endif // !defined(AFC_FODROPMENUEDITSHAPE_H__25892846_A93B_49CD_B1AE_BED842FA2757__INCLUDED_)
