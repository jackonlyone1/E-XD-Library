//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPNEWGRIDSHAPE_H__3FB4E9C3_F6F1_44EA_A792_B7A87482C3DD__INCLUDED_)
#define AFC_FOPNEWGRIDSHAPE_H__3FB4E9C3_F6F1_44EA_A792_B7A87482C3DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author.
//------------------------------------------------------

#include "FODrawPortsShape.h"
#include "FOPMsgShell.h"

// Below are the default setting values.

const int			fopDefaultGridColumnHeight			= 28;
const int			fopDefaultGridMinColumnWidth		= 20;
const int			fopDefaultGridCellHeight			= 22;
const int			fopDefaultGridTitleBarHeight		= 24;
const int			fopDefaultGridLeftColumnWidth		= 30;
const COLORREF		fopDefaultGridLineColor				= RGB(192,192,192);
const CString		fopDefaultGridDateFormat			= _T("%m/%d/%Y");
const CString		fopDefaultGridUninitializedCellText = _T("<null>");
const int			fopDefaultGridDBLAccuracyDigits		= 2;
const int			fopDefaultGridVSBDraggableMinHeight = 5;
const int			fopDefaultGridVSBDraggableMinWidth	= 5;

#define FOP_GRID_COLUMN_LAST_ITEM               -1

//------------------------------------------------------
// FOPGridModes
// 
//------------------------------------------------------

typedef enum FOPGridModes
{
    // Node view functions as grid view
    FOPModeGrid = 0,
        
    // Node view functions as secondary view type
    FOPNewModeGrid

} FOPGridMode;

//------------------------------------------------------
// FOPGridCellTypes
// 
//------------------------------------------------------

typedef enum FOPGridCellTypes
{
    // Uninitialized column object type.
    cell_NONE,
       
    // Cells will be a long value.
    cell_LONG,
        
    // Cells will be a string value.
    cell_STRING,
        
    // Cells will be a double value.
    cell_DOUBLE,
        
    // Cells will be a currency value.
    cell_CURRENCY,
        
    // Cells will be a date value.
    cell_DATE,
        
    // Cells will be owner drawn and a virtual method
    // will be called to handle their drawing.
    cell_OWNERDRAW,
	cell_CHECKBOX
        
} FOPGridCellType;

//------------------------------------------------------
// FOPGridColumnSortStates
// 
//------------------------------------------------------

typedef enum FOPGridColumnSortStates
{
    // Columns' grid data column unsorted.
    fopGridColSort_NONE,
        
    // Columns' grid data column sorted (asc)
    fopGridColSort_ASC,
        
    // Columns' grid data column sorted (dec)
    fopGridColSort_DEC
        
} FOPGridColumnSortState;

//------------------------------------------------------
// FOPGridButtonStates
// 
//------------------------------------------------------

// Button state.
typedef enum FOPGridButtonStates
{
    // Button pressed.
    fopGridBtnState_PRESSED,
        
    // Button unpressed.
    fopGridBtnState_UNPRESSED

} FOPGridButtonState;

//------------------------------------------------------
// FOPGridCellAlignments
// 
//------------------------------------------------------

// Cell text alignment
typedef enum FOPGridCellAlignments
{
    fopGridCellAlign_NONE,
    fopGridCellAlign_CENTER,
    fopGridCellAlign_RIGHT,
    fopGridCellAlign_LEFT,
    fopGridCellAlign_POS_LEFT_NEG_RIGHT,
    fopGridCellAlign_NEG_LEFT_POS_RIGHT

} FOPGridCellAlignment;

//------------------------------------------------------
// FOPGridLineStyles
// 
//------------------------------------------------------

// Grid line type
typedef enum FOPGridLineStyles
{
    fopGridLineStyle_SOLID,
    fopGridLineStyle_DOTTED,
    fopGridLineStyle_DOTTED_QUALITY
} FOPGridLineStyle;

//------------------------------------------------------
// FOPGridViewNavigationPoints
// 
//------------------------------------------------------

// Navigation style
typedef enum FOPGridViewNavigationPoints
{
    FOP_GRID_NAV_TOP,
    FOP_GRID_NAV_BOTTOM,
    FOP_GRID_NAV_LEFT,
    FOP_GRID_NAV_RIGHT,
    FOP_GRID_NAV_TOPLEFT,
    FOP_GRID_NAV_BOTTOMRIGHT
} FOPGridViewNavigationPoint;

//------------------------------------------------------
// FOPGridSBBtnStates
// 
//------------------------------------------------------

// Button states
struct FOPGridSBBtnStates
{
	// Constructor
    FOPGridSBBtnStates();

	// Change button.
    void SetScrollBarButton(FOPGridViewElement sbBtn,FOPGridButtonState state);

    FOPGridButtonState	m_aHorzSBBtnLeftPress;
    FOPGridButtonState	m_aHorzSBBtnRightPress;
    FOPGridButtonState	m_aHScrollableSpaceRight;
    FOPGridButtonState	m_aHScrollableSpaceLeft;
    FOPGridButtonState	m_aVertSBBtnTopPress;
    FOPGridButtonState	m_aVertSBBtnBottomPress;
    FOPGridButtonState	m_aVScrollableSpaceTop;
    FOPGridButtonState	m_aVScrollableSpaceBottom;
    FOPGridButtonState  m_aTitleBarMinimize;
};  

//////////////////////////////////////////////////////////////////////////
// FOPGridColumn

 
//===========================================================================
// Summary:
//      To use a FOPGridColumn object, just call the constructor.
//      O P Grid Column
//===========================================================================

class FO_EXT_CLASS FOPGridColumn
{
    
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Grid Column, Constructs a FOPGridColumn object.
	//		Returns A  value (Object).
    FOPGridColumn();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Column, Destructor of class FOPGridColumn
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPGridColumn() {};

public:
	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		&rGridColumnObjeect---Grid Column Objeect, Specifies a const FOPGridColumn &rGridColumnObjeect object(Value).
    void operator= (const FOPGridColumn &rGridColumnObjeect);
    
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

public:
    // Return CellType value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Type, Returns the specified value.
	//		Returns A FOPGridCellType value (Object).
    FOPGridCellType GetCellType() const { return m_nCellType;}
    
    // Change CellType value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Type, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridCellType &nValue object(Value).
    void SetCellType( const FOPGridCellType &nValue ) {m_nCellType = nValue; }
    
    // Return ColumnText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Text, Returns the specified value.
	//		Returns a CString type value.
    CString GetColumnText() const { return m_strColumnLabel;}
    
    // Change ColumnText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Text, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
    void SetColumnText( const CString &strValue ) {m_strColumnLabel = strValue; }
    
    // Return TextColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetTextColor() const { return m_crText;}
    
    // Change TextColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Color, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetTextColor( const COLORREF &crValue ) {m_crText = crValue; }
    
    // Return ColumnBackgroundColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetColumnBackgroundColor() const { return m_crColumnBackground;}
    
    // Change ColumnBackgroundColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Background Color, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetColumnBackgroundColor( const COLORREF &crValue ) {m_crColumnBackground = crValue; }
    
    // Return TextColorNegative value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color Negative, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetTextColorNegative() const { return m_crTextNegative;}
    
    // Change TextColorNegative value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Color Negative, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetTextColorNegative( const COLORREF &crValue ) {m_crTextNegative = crValue; }
    
    // Return TextColorPositive value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color Positive, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetTextColorPositive() const { return m_crTextPositive;}
    
    // Change TextColorPositive value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Color Positive, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetTextColorPositive( const COLORREF &crValue ) {m_crTextPositive = crValue; }
    
    // Return Width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns a int type value.
    int GetWidth() const { return m_nWidth;}
    
    // Change Width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Width, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetWidth( const int &nValue ) {m_nWidth = nValue; }
    
    // Return MinWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Width, Returns the specified value.
	//		Returns a int type value.
    int GetMinWidth() const { return m_nMinWidth;}
    
    // Change MinWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimize Width, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetMinWidth( const int &nValue ) {m_nMinWidth = nValue; }
    
    // Return Alignment value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Alignment, Returns the specified value.
	//		Returns A FOPGridCellAlignment value (Object).
    FOPGridCellAlignment GetAlignment() const { return m_aAlignment;}
    
    // Change Alignment value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nType---&nType, Specifies a const FOPGridCellAlignment &nType object(Value).
    void SetAlignment( const FOPGridCellAlignment &nType ) {m_aAlignment = nType; }
    
    // Return DateFormat value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Format, Returns the specified value.
	//		Returns a CString type value.
    CString GetDateFormat() const { return m_strDateFormat;}
    
    // Change DateFormat value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Date Format, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
    void SetDateFormat( const CString &strValue ) {m_strDateFormat = strValue; }
    
    
    // Return DoubleAccuracyDigits value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Double Accuracy Digits, Returns the specified value.
	//		Returns A short value (Object).
    short GetDoubleAccuracyDigits() const { return m_nDoubleAccuracyDigits;}
    
    // Change DoubleAccuracyDigits value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Double Accuracy Digits, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies a const short &nValue object(Value).
    void SetDoubleAccuracyDigits( const short &nValue ) {m_nDoubleAccuracyDigits = nValue; }
    
    // Return ThousandSeparator value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Thousand Separator, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetThousandSeparator() const { return m_bThousandSeparator;}
    
    // Change ThousandSeparator value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Thousand Separator, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetThousandSeparator( const BOOL &bValue ) {m_bThousandSeparator = bValue; }
    
    // Return CurrencySymbol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Currency Symbol, Returns the specified value.
	//		Returns a CString type value.
    CString GetCurrencySymbol() const { return m_strCurrencySymbol;}
    
    // Change CurrencySymbol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Currency Symbol, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
    void SetCurrencySymbol( const CString &strValue ) {m_strCurrencySymbol = strValue; }
    
    // Return UninitializedCellText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Uninitialized Cell Text, Returns the specified value.
	//		Returns a CString type value.
    CString GetUninitializedCellText() const { return m_strUninitializedCellText;}
    
    // Change UninitializedCellText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Uninitialized Cell Text, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
    void SetUninitializedCellText( const CString &strValue ) {m_strUninitializedCellText = strValue; }
    
    // Return ShowUninitializedFieldText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Uninitialized Field Text, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetShowUninitializedFieldText() const { return m_bShowUninitializedFieldText;}
    
    // Change ShowUninitializedFieldText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Uninitialized Field Text, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetShowUninitializedFieldText( const BOOL &bValue ) {m_bShowUninitializedFieldText = bValue; }
    
    // Return BtnState value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button State, Returns the specified value.
	//		Returns A FOPGridButtonStates value (Object).
    FOPGridButtonStates GetBtnState() const { return m_aBtnState;}
    
    // Change BtnState value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button State, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridButtonStates &nValue object(Value).
    void SetBtnState( const FOPGridButtonStates &nValue ) {m_aBtnState = nValue; }
    
    // Return SortState value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sort State, Returns the specified value.
	//		Returns A FOPGridColumnSortState value (Object).
    FOPGridColumnSortState GetSortState() const { return m_aSortState;}
    
    // Change SortState value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sort State, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridColumnSortState &nValue object(Value).
    void SetSortState( const FOPGridColumnSortState &nValue ) {m_aSortState = nValue; }
    
	// Is selected or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const { return m_bSelected; }

	// Set selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class FOPGridColumn
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void SetSelected(const BOOL &bSelect) { m_bSelected = bSelect; }

	
protected:
    
 
	// Cell Type, This member specify FOPGridCellType object.  
    FOPGridCellType         m_nCellType;
 
	// Column Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
    CString                 m_strColumnLabel;
 
	// Text, This member sets A 32-bit value used as a color value.  
    COLORREF                m_crText;
 
	// Column Background, This member sets A 32-bit value used as a color value.  
    COLORREF                m_crColumnBackground;
 
	// Text Negative, This member sets A 32-bit value used as a color value.  
    COLORREF                m_crTextNegative;
 
	// Text Positive, This member sets A 32-bit value used as a color value.  
    COLORREF                m_crTextPositive;
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                     m_nWidth;
 
	// Minimize Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                     m_nMinWidth;
 
	// Double Accuracy Digits, This member specify short object.  
    short                   m_nDoubleAccuracyDigits;
 
	// Alignment, This member specify FOPGridCellAlignment object.  
    FOPGridCellAlignment    m_aAlignment;
 
	// Button State, This member specify FOPGridButtonStates object.  
    FOPGridButtonStates     m_aBtnState;
 
	// Sort State, This member specify FOPGridColumnSortState object.  
    FOPGridColumnSortState  m_aSortState;
 
	// Date Format, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
    CString                 m_strDateFormat;
 
	// Thousand Separator, This member sets TRUE if it is right.  
    BOOL                    m_bThousandSeparator;
 
	// Currency Symbol, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
    CString                 m_strCurrencySymbol;
 
	// Uninitialized Cell Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
    CString                 m_strUninitializedCellText;
 
	// Show Uninitialized Field Text, This member sets TRUE if it is right.  
    BOOL                    m_bShowUninitializedFieldText;
 
	// Selected, This member sets TRUE if it is right.  
	BOOL					m_bSelected;
};

// Array of the columns
typedef CArray<FOPGridColumn *, FOPGridColumn *> FOPColumnsArray;

 
//===========================================================================
// Summary:
//      To use a FOPGridCell object, just call the constructor.
//      O P Grid Cell
//===========================================================================

class FO_EXT_CLASS FOPGridCell
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Grid Cell, Constructs a FOPGridCell object.
	//		Returns A  value (Object).
    FOPGridCell();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Cell, Destructor of class FOPGridCell
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~FOPGridCell();

public:

	// Operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		&rGridCell---Grid Cell, Specifies a const FOPGridCell &rGridCell object(Value).
	void operator= (const FOPGridCell &rGridCell);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

public:
    
	// Is selected or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const { return m_bSelected; }

	// Set selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void SetSelected(const BOOL &bSelect) { m_bSelected = bSelect; }

	// Is selected or not.
	BOOL IsChecked() const { return m_bCheck; }
	
	// Set selected
	void SetChecked(const BOOL &bCheck) { m_bCheck = bCheck ;}

	// Cell rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCellRect() const { return m_rcCell; }

	// Set cell rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Rectangle, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		&rcCell---&rcCell, Specifies A CRect type value.
	void SetCellRect(const CRect &rcCell) { m_rcCell = rcCell; }

	// Object of the column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Object, Returns the specified value.
	//		Returns a pointer to the object FOPGridColumn ,or NULL if the call failed
	FOPGridColumn * GetColumnObject() const { return m_pColumnObject; }

	// Change the object of the column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Column Object, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		*pObj---*pObj, A pointer to the FOPGridColumn  or NULL if the call failed.
	void SetSimpleColumnObject(FOPGridColumn *pObj) { m_pColumnObject  = pObj; }
	
    // Return Alignment value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Alignment, Returns the specified value.
	//		Returns A FOPGridCellAlignment value (Object).
    FOPGridCellAlignment GetAlignment() const { return m_aAlignment;}
    
    // Change Alignment value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		&aValue---&aValue, Specifies a const FOPGridCellAlignment &aValue object(Value).
    void SetAlignment( const FOPGridCellAlignment &aValue ) {m_aAlignment = aValue; }
    
    // Return Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetColor() const { return m_crColor;}
    
    // Change Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetColor( const COLORREF &crValue ) {m_crColor = crValue; }
    
    // Return CellData value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Cell Data, Returns the specified value.
	//		Returns a pointer to the object void ,or NULL if the call failed
    void * GetNewCellData() const { return m_aCellData;}
    
    // Change CellData value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Cell Data, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		dwValue---dwValue, A pointer to the void  or NULL if the call failed.
    void SetNewCellData( void * dwValue ) {m_aCellData = dwValue; }
    
    // Return Initialized value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Initialized, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetInitialized() const { return m_bInitialized;}
    
    // Change Initialized value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initialized, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetInitialized( const BOOL &bValue ) {m_bInitialized = bValue; }
    
public:
    // Obtain the double value of the cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Double Value, Returns the specified value.
	//		Returns A double value (Object).
    double GetDoubleValue() const;

	// Obtain the string value of the cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String Value, Returns the specified value.
	//		Returns a CString type value.
    CString GetStringValue() const;

	// Obtain the long value of the cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Long Value, Returns the specified value.
	//		Returns a int type value.
    int GetLongValue() const;

	// Obtain the date value of the cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Value, Returns the specified value.
	//		Returns A COleDateTime value (Object).
    COleDateTime GetDateValue() const;

	// Obtain the date string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date String, Returns the specified value.
	//		Returns a CString type value.
	CString GetDateString() const { return m_strDate; }
    
	// Change the double value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Double Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		value---Specifies a double value object(Value).
	void SetDoubleValue(double value);

	// Change the double value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Double Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		value---Specifies A integer value.
    void SetDoubleValue(int value); 

	// Change the string value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set String Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		value---Specifies A CString type value.
    void SetStringValue(CString value);

	// Change the long vlaue
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Long Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		value---Specifies A integer value.
    void SetLongValue(int value);
    
	// Change column object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Object, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		pColumnObject---Column Object, A pointer to the FOPGridColumn  or NULL if the call failed.
    void SetColumnObject(FOPGridColumn * pColumnObject);

	// Set cell item data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Data, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		value---A pointer to the void  or NULL if the call failed.
    void SetCellData(void * value);

	// Change date value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Date Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		year---Specifies A integer value.  
	//		month---Specifies A integer value.  
	//		day---Specifies A integer value.  
	//		hour---Specifies A integer value.  
	//		minute---Specifies A integer value.  
	//		sec---Specifies A integer value.
    void SetDateValue(int year,int month,int day,int hour = 0,int minute = 0,int sec = 0);
    
	// Obtain the date value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Date Value, Returns the specified value.
	// Parameters:
	//		year---Specifies A integer value.  
	//		month---Specifies A integer value.  
	//		day---Specifies A integer value.  
	//		hour---Specifies A integer value.  
	//		minute---Specifies A integer value.  
	//		sec---Specifies A integer value.
    void GetDateValue(int & year,int & month,int & day,int & hour,int & minute,int & sec);
    
    // Change date value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Date Value, Sets a specify value to current class FOPGridCell
	// Parameters:
	//		gridDate---gridDate, Specifies a const COleDateTime & gridDate object(Value).
    void SetDateValue(const COleDateTime & gridDate);

	// Obtain the cell label
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Label, Returns the specified value.
	//		Returns a CString type value.
    CString GetCellLabel();

	// Format number string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format Number String, .
	//		Returns a CString type value.  
	// Parameters:
	//		source---Specifies A CString type value.
    CString FormatNumberStr(CString source);
    
protected:

 
	// Alignment, This member specify FOPGridCellAlignment object.  
    FOPGridCellAlignment	m_aAlignment;
 
	// Color, This member sets A 32-bit value used as a color value.  
    COLORREF				m_crColor;
 
	// Cell Data, This member maintains a pointer to the object void.  
    void *					m_aCellData;
 
	// Value, This member specify double object.  
    double					m_dValue;
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strValue;
 
	// Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_lValue;
 
	// Value, This member specify COleDateTime object.  
	COleDateTime			m_dtValue;
 
	// Initialized, This member sets TRUE if it is right.  
    BOOL					m_bInitialized;
 
	// Column Object, This member maintains a pointer to the object FOPGridColumn.  
	FOPGridColumn *			m_pColumnObject;
 
	// Cell, This member sets a CRect value.  
	CRect					m_rcCell;
 
	// Selected, This member sets TRUE if it is right.  
	BOOL					m_bSelected;
 
	// Date, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strDate;

	BOOL                    m_bCheck;
};


//------------------------------------------------------
// FOPGridRow
// 
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The FOPGridRow class derived from CArray<FOPGridCell*
//      O P Grid Row
//===========================================================================

class FOPGridRow : public CArray<FOPGridCell*, FOPGridCell*>
{
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Grid Row, Constructs a FOPGridRow object.
	//		Returns A  value (Object).
	FOPGridRow();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Row, Destructor of class FOPGridRow
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPGridRow();

public:
	// Is selected or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const { return m_bSelected; }

	// Set selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class FOPGridRow
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void SetSelected(const BOOL &bSelect) { m_bSelected = bSelect; }

protected:

	// Be selected or not.
 
	// Selected, This member sets TRUE if it is right.  
	BOOL		m_bSelected;

};

// Array of the grid rows
typedef CArray<FOPGridRow *,FOPGridRow *> FOPGridData;


// Date time
struct FOPGridColData
{
	// cell type,it should be one of the following value:
	// cell_NONE,cell_LONG,cell_STRING,cell_DOUBLE,cell_CURRENCY,
	// cell_DATE,cell_OWNERDRAW
    FOPGridCellType	cellType;

	// Label of the column.
    CString			columnText;

	// Width of the column
	int				width;

	// Alignment of the label,it should be one of the following value:
	// fopGridCellAlign_NONE, fopGridCellAlign_CENTER,  fopGridCellAlign_RIGHT, fopGridCellAlign_LEFT,
	// fopGridCellAlign_POS_LEFT_NEG_RIGHT,  fopGridCellAlign_NEG_LEFT_POS_RIGHT	
	FOPGridCellAlignment    alignment;
};

typedef CArray<FOPGridColData,FOPGridColData> FOPInitColsData;

class CFOPCanvasCore;
////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// CFOPNewGridShape -- new style grid shape.
// 
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPNewGridShape class derived from CFODrawPortsShape
//      F O P New Grid Shape
//===========================================================================

class FO_EXT_CLASS CFOPNewGridShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewGridShape---F O P New Grid Shape, Specifies a E-XD++ CFOPNewGridShape object (Value).
	DECLARE_SERIAL(CFOPNewGridShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Grid Shape, Constructs a CFOPNewGridShape object.
	//		Returns A  value (Object).
	CFOPNewGridShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Grid Shape, Constructs a CFOPNewGridShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewGridShape& src object(Value).
	CFOPNewGridShape(const CFOPNewGridShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Grid Shape, Destructor of class CFOPNewGridShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewGridShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewGridShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button Shape from a CRect object.
	// rcPos -- position of the shape.
	// strCaption -- caption of the shape
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewGridShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&aryColumns---&aryColumns, Specifies a const FOPInitColsData &aryColumns object(Value).  
	//		nRows---nRows, Specifies A integer value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button Shape from a CRect object.
	// rcPos -- position of the shape
	// aryColumns -- data of the columns
	// nRows -- total of the rows.
	// strCaption -- caption of the shape.
	virtual void Create(CRect &rcPos,const FOPInitColsData &aryColumns,int nRows,CString strCaption = _T(""));

	// Do init data of the grid shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Grid Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoInitGridData();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewGridShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewGridShape& src object(Value).
	CFOPNewGridShape& operator=(const CFOPNewGridShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;

	// Update shape's area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

public:
    
    // Return SBAtRightmost value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get S B At Rightmost, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetSBAtRightmost() const { return m_bSBAtRightMost;}
    
    // Change SBAtRightmost value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set S B At Rightmost, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetSBAtRightmost( const BOOL &bValue ) {m_bSBAtRightMost = bValue; }
    
    // Return SBAtBottommost value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get S B At Bottommost, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetSBAtBottommost() const { return m_bSBAtBottomMost;}
    
    // Change SBAtBottommost value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set S B At Bottommost, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetSBAtBottommost( const BOOL &bValue ) {m_bSBAtBottomMost = bValue; }
    
    // Return SaveGridData value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Grid Data, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetSaveGridData() const { return m_bSaveGridData;}
    
    // Change SaveGridData value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Grid Data, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetSaveGridData( const BOOL &bValue ) {m_bSaveGridData = bValue; }
    
    // Return AllowSwitchPrimaryMode value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Allow Switch Primary Mode, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetAllowSwitchPrimaryMode() const { return m_bAllowSwitchPrimaryMode;}
    
    // Change AllowSwitchPrimaryMode value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Switch Primary Mode, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetAllowSwitchPrimaryMode( const BOOL &bValue ) {m_bAllowSwitchPrimaryMode = bValue; }
    
public:
    
    // Return Mode value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mode, Returns the specified value.
	//		Returns A FOPGridMode value (Object).
    FOPGridMode GetMode() const { return m_aMode;}
    
    // Change Mode value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridMode &nValue object(Value).
    void SetMode( const FOPGridMode &nValue ) {m_aMode = nValue; }
    
    // Return ColumnHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Height, Returns the specified value.
	//		Returns a int type value.
    int GetColumnHeight() const { return m_nColHeight;}
    
    // Change ColumnHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Height, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetColumnHeight( const int &nValue ) {m_nColHeight = nValue; }
    
    // Return CellHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Height, Returns the specified value.
	//		Returns a int type value.
    int GetCellHeight() const { return m_nCellHeight;}
    
    // Change CellHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Height, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetCellHeight( const int &nValue ) {m_nCellHeight = nValue; }
    
public:
    
    // Return TitleBarColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Bar Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetTitleBarColor() const { return m_crTitleBar;}
    
    // Change TitleBarColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Bar Color, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetTitleBarColor( const COLORREF &crValue ) {m_crTitleBar = crValue; }
    
    // Return TitleBarColorInactive value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Bar Color Inactive, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetTitleBarColorInactive() const { return m_crTitleBarInactive;}
    
    // Change TitleBarColorInactive value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Bar Color Inactive, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetTitleBarColorInactive( const COLORREF &crValue ) {m_crTitleBarInactive = crValue; }
    
    // Return ShowTitleBar value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Title Bar, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetShowTitleBar() const { return m_bShowTitleBar;}
    
    // Change ShowTitleBar value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Title Bar, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetShowTitleBar( const BOOL &bValue ) {m_bShowTitleBar = bValue; }
    
    // Return LeftColumnShow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Column Show, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetLeftColumnShow() const { return m_bLeftColumnShow;}
    
    // Change LeftColumnShow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Column Show, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetLeftColumnShow( const BOOL &bValue ) {m_bLeftColumnShow = bValue; }
    
public:
    
    // Return LeftColumnWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Column Width, Returns the specified value.
	//		Returns a int type value.
    int GetLeftColumnWidth() const { return m_nLeftColumnWidth;}
    
    // Change LeftColumnWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Column Width, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetLeftColumnWidth( const int &nValue ) {m_nLeftColumnWidth = nValue; }
    
    // Return TitleBarHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Bar Height, Returns the specified value.
	//		Returns a int type value.
    int GetTitleBarHeight() const { return m_nTitleBarHeight;}
    
    // Change TitleBarHeight value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Bar Height, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetTitleBarHeight( const int &nValue ) {m_nTitleBarHeight = nValue; }
    
    // Return GridLineStyle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Line Style, Returns the specified value.
	//		Returns A FOPGridLineStyle value (Object).
    FOPGridLineStyle GetGridLineStyle() const { return m_aGridLineStyle;}
    
    // Change GridLineStyle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Style, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridLineStyle &nValue object(Value).
    void SetGridLineStyle( const FOPGridLineStyle &nValue ) {m_aGridLineStyle = nValue; }
    
    // Return GridLineColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
    COLORREF GetGridLineColor() const { return m_crGridLine;}
    
    // Change GridLineColor value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Color, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
    void SetGridLineColor( const COLORREF &crValue ) {m_crGridLine = crValue; }
    
    // Return StretchColorOverride value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Stretch Color Override, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetStretchColorOverride() const { return m_bStretchColorOverride;}
    
    // Change StretchColorOverride value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Stretch Color Override, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetStretchColorOverride( const BOOL &bValue ) {m_bStretchColorOverride = bValue; }
    
    // Return SortColumn value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sort Column, Returns the specified value.
	//		Returns a int type value.
    int GetSortColumn() const { return m_nSortColumn;}
    
    // Change SortColumn value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sort Column, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetSortColumn( const int &nValue ) {m_nSortColumn = nValue; }
    
    // Return ColumnWidthIncludeHeaderText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Width Include Header Text, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetColumnWidthIncludeHeaderText() const { return m_bColumnWidthIncludeHeaderText;}
    
    // Change ColumnWidthIncludeHeaderText value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Width Include Header Text, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetColumnWidthIncludeHeaderText( const BOOL &bValue ) {m_bColumnWidthIncludeHeaderText = bValue; }
    
    // Return Modified value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modified, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL GetModified() const { return m_bModified;}
    
    // Change Modified value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
    void SetModified( const BOOL &bValue ) {m_bModified = bValue; }
    
public:

	// When mode changes call this method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mode Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		mode---Specifies a FOPGridMode mode object(Value).  
	//		updateNode---updateNode, Specifies A Boolean value.
    virtual void DoModeChange(FOPGridMode mode,BOOL updateNode = TRUE);
    
	// Init fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Fonts, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DoInitFonts();
    
	// Clear all the grid data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Grid Data, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void ClearGridData();

	// Delete all the columns of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Columns, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DeleteAllColumns();

	// Obtain the columns array
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Columns, Returns the specified value.
	//		Returns A FOPColumnsArray & value (Object).
    FOPColumnsArray & GetColumns();

	// Obtain columns text.
	CString GetColsText();

	// Obtain the data of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Data, Returns the specified value.
	//		Returns A FOPGridData & value (Object).
    FOPGridData & GetGridData();

	// Obtain the data of the grid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns A FOPGridData & value (Object).
    FOPGridData & GetData();

	// Obtain the row of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row, Returns the specified value.
	//		Returns a pointer to the object FOPGridRow ,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
    FOPGridRow * GetRow(int index);

	// Obtain the count of rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Rows, Returns the specified value.
	//		Returns a int type value.
	int GetTotalRows();

	// Obtain the cell object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell, Returns the specified value.
	//		Returns a pointer to the object FOPGridCell ,or NULL if the call failed  
	// Parameters:
	//		pGridRow---Grid Row, A pointer to the FOPGridRow  or NULL if the call failed.  
	//		columnIndex---columnIndex, Specifies A integer value.
    FOPGridCell * GetCell(FOPGridRow * pGridRow,int columnIndex);

	// Obtain the cell object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell, Returns the specified value.
	//		Returns a pointer to the object FOPGridCell ,or NULL if the call failed  
	// Parameters:
	//		rowIndex---rowIndex, Specifies A integer value.  
	//		columnIndex---columnIndex, Specifies A integer value.
    FOPGridCell * GetCell(int rowIndex,int columnIndex);
    
	// Do minimize
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Minimize, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DoMinimize();

	// Do maximize
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Maximize, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DoMaximize();
    
	// Obtain the total columns of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Columns, Returns the specified value.
	//		Returns a int type value.
    int GetTotalColumns();
    
	// Obtain the column of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column, Returns the specified value.
	//		Returns a pointer to the object FOPGridColumn ,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
    FOPGridColumn * GetColumn(int index);
    
	// Add a new column to the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Column, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pNewColumn---New Column, A pointer to the FOPGridColumn  or NULL if the call failed.  
	//		insertAfter---insertAfter, Specifies A integer value.
    virtual void AddColumn(FOPGridColumn *pNewColumn,int insertAfter = FOP_GRID_COLUMN_LAST_ITEM);

	// Add a new column to the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Column, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridColumn ,or NULL if the call failed  
	// Parameters:
	//		cellType---cellType, Specifies a FOPGridCellType cellType object(Value).  
	//		columnText---columnText, Specifies A CString type value.  
	//		width---Specifies A integer value.  
	//		insertAfter---insertAfter, Specifies A integer value.
    virtual FOPGridColumn * AddColumn(FOPGridCellType cellType,
        CString columnText,
        int width,
        int insertAfter = FOP_GRID_COLUMN_LAST_ITEM);

	// Add a new column to the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Column, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridColumn ,or NULL if the call failed  
	// Parameters:
	//		cellType---cellType, Specifies a FOPGridCellType cellType object(Value).  
	//		columnText---columnText, Specifies A CString type value.  
	//		width---Specifies A integer value.  
	//		textColor---textColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		insertAfter---insertAfter, Specifies A integer value.
    virtual FOPGridColumn * AddColumn(FOPGridCellType cellType,
        CString columnText,
        int width,
        COLORREF textColor,
        int insertAfter = FOP_GRID_COLUMN_LAST_ITEM);

	// Add a new column to the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Column, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridColumn ,or NULL if the call failed  
	// Parameters:
	//		cellType---cellType, Specifies a FOPGridCellType cellType object(Value).  
	//		columnText---columnText, Specifies A CString type value.  
	//		width---Specifies A integer value.  
	//		textColor---textColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		columnBackgroundColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		insertAfter---insertAfter, Specifies A integer value.
    virtual FOPGridColumn * AddColumn(FOPGridCellType cellType,
        CString columnText,
        int width,
        COLORREF textColor,
        COLORREF columnBackgroundColor,
        int insertAfter = FOP_GRID_COLUMN_LAST_ITEM);
    
	// Add a new row to the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Row, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridRow ,or NULL if the call failed
    virtual FOPGridRow * AddRow();

	// Add a new row.
	void AddNewRow(const CString& strText);

	// Add a new column.
	void AddNewColumn(const CString& strText);

	// Add columns.
	void AddColumns(const CString &strCols);

	// Clear rows.
	void ClearRows();

	// Do new column
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Column, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		columnIdx---columnIdx, Specifies A integer value.
    virtual void OnNewColumn(int columnIdx);

	// Obtain the columns logical size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Columns Logical Size, Returns the specified value.
	//		Returns a CSize type value.
    CSize GetColumnsLogicalSize();

	// Obtain the rectangles of the grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rects, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPGridRectStruct & value (Object).
    virtual FOPGridRectStruct & GetRects();

	// Obtain the client logical size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Client Logical Size, Returns the specified value.
	//		Returns a CSize type value.
    CSize GetClientLogicalSize();

	// Adjust clip rectangle of the print preview
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Clipboard Rectangle For Print Preview, .
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rClipRect---Clipboard Rectangle, Specifies A CRect type value.
    void AdjustClipRectForPrintPreview(CDC & rDC,CRect & rClipRect);

	// Adjust clip rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Clipboard Rectangle, .
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rClipRect---Clipboard Rectangle, Specifies A CRect type value.
    void AdjustClipRect(CDC & rDC,CRect & rClipRect);
    
	// Do convert log rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Logical Rectangle, Do a event. 
	//		Returns a CRect type value.  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rect---Specifies A CRect type value.
	CRect DoConvertLogRect(CDC & rDC,CRect & rect);

	// Do convert log point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Logical Point, Do a event. 
	//		Returns a CPoint type value.  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		point---Specifies A CPoint type value.
    CPoint DoConvertLogPoint(CDC & rDC,CPoint & point);
    
	// Obtain the device unit size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Device Unit Size, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    double GetDeviceUnitSize(CDC & rDC) const;
    
	// Change the title bar text color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Bar Text Color, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
    void SetTitleBarTextColor(COLORREF color);

	// Obtain the title bar text color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Bar Text Color, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.
    virtual COLORREF GetTitleBarTextColor();
    
	// Init position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Position, Call InitPosition after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
    virtual void InitPosition(const CRect &rcPos);
    
public:
	// Do draw border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Border, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DoDrawBorder(CDC & rDC);

	// Do draw title bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Title Bar, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DrawTitleBar(CDC & rDC);
    
    // Do draw column cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Column Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		index---Specifies A integer value.  
	//		rcDeviceBounds---Device Bounds, Specifies A CRect type value.  
	//		btnState---btnState, Specifies a FOPGridButtonStates btnState object(Value).  
	//		element---Specifies a FOPGridViewElement element = FOP_GRID_ELEMENT_NONE object(Value).
    virtual void DoDrawColumnCell(CDC & rDC,
        int index,
        CRect rcDeviceBounds,
        FOPGridButtonStates btnState,
        FOPGridViewElement element = FOP_GRID_ELEMENT_NONE);

    //-----------------------------------------------------------------------
	// Summary:
	// Do Draw Column Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		index---Specifies A integer value.  
	//		rcDeviceBounds---Device Bounds, Specifies A CRect type value.  
	//		btnState---btnState, Specifies a FOPGridButtonStates btnState object(Value).  
	//		element---Specifies a FOPGridViewElement element = FOP_GRID_ELEMENT_NONE object(Value).
    virtual void SVGDrawColumnCell(CString & strIn,
        int index,
        CRect rcDeviceBounds,
        FOPGridButtonStates btnState,
        FOPGridViewElement element = FOP_GRID_ELEMENT_NONE);
    
	// Do draw grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DoDraw(CDC & rDC);

	// Do draw client
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Client, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DoDrawClient(CDC & rDC);
    
	// Do draw cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Cells, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DoDrawCells(CDC & rDC);
    
	// Do draw client
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Client, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void SVGDrawClient(CString &strIn);
    
	// Do draw title bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Title Bar, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void SVGTitleBar(CString &strIn);

	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);
	// Do draw text cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		textHeight---textHeight, Specifies A integer value.  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.
    virtual void SVGDrawTextCell(CString & strIn,
        CRect & rRect,
        double deviceUnitSize,
        int textHeight,
        FOPGridCell * pCell);

	// Do draw columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Columns, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void SVGDrawColumns(CString & strIn);

	// Do draw text cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		textHeight---textHeight, Specifies A integer value.  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.
    virtual void DoDrawTextCell(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        int textHeight,
        FOPGridCell * pCell);

	// Do draw int cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Int Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		textHeight---textHeight, Specifies A integer value.  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.
    virtual void DoDrawIntCell(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        int textHeight,
        FOPGridCell * pCell);

	// Do draw double cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Double Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		textHeight---textHeight, Specifies A integer value.  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.
    virtual void DoDrawDoubleCell(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        int textHeight,
        FOPGridCell * pCell);

	// Do draw date cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Date Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		textHeight---textHeight, Specifies A integer value.  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.
    virtual void DoDrawDateCell(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        int textHeight,
        FOPGridCell * pCell);

	// For checking the editing label.
	virtual BOOL DoHitEditLabel(const CPoint &ptHit);
	
	// Update shape caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shape Caption, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual BOOL UpdateShapeCaption(const CString &strNew);
	
	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Do draw left column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Left Column, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		pRow---pRow, A pointer to the FOPGridRow  or NULL if the call failed.  
	//		rowIndex---rowIndex, Specifies A integer value.
    virtual void DoDrawLeftColumn(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        FOPGridRow * pRow,
        int rowIndex);

	// Do draw custom cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Custom Draw Cell, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		rRect---rRect, Specifies A CRect type value.  
	//		deviceUnitSize---Unit Size, Specifies a double deviceUnitSize object(Value).  
	//		pCell---pCell, A pointer to the FOPGridCell  or NULL if the call failed.  
	//		rowIndex---rowIndex, Specifies A integer value.  
	//		cellIndex---cellIndex, Specifies A integer value.
    virtual void DoCustomDrawCell(CDC & rDC,
        CRect & rRect,
        double deviceUnitSize,
        FOPGridCell * pCell,
        int rowIndex,
        int cellIndex);
    
	virtual void DoCustomDrawCheckbox(CDC & rDC,
		CRect & rRect,
		double deviceUnitSize,
		FOPGridCell * pCell,
		int rowIndex,
		int cellIndex);
	// Do draw columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Columns, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    virtual void DoDrawColumns(CDC & rDC);

	// Do draw vert line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Vertical Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		xPoint---xPoint, Specifies A integer value.  
	//		rLogicalBounds---Logical Bounds, Specifies A CRect type value.  
	//		rInvalidLogRect---Invalid Logical Rectangle, Specifies A CRect type value.
	virtual void DoDrawVertLine(CDC & rDC,
        int xPoint,
        CRect & rLogicalBounds,
        CRect & rInvalidLogRect);
    
	// Do draw scroll bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Scroll Bar, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		scrollBar---scrollBar, Specifies a FOPGridScrollBar scrollBar object(Value).
    virtual void DoDrawScrollBar(CDC & rDC,FOPGridScrollBar scrollBar);
    
public:
	// Is output to screen ot printer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Screen Or Print, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).
    BOOL IsScreenOrPrint(CDC & rDC);

	// Obtain the scroll bar button states
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar Button States, Returns the specified value.
	//		Returns A FOPGridSBBtnStates & value (Object).
    FOPGridSBBtnStates & GetScrollBarBtnStates();
    
	// origin position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Origin Position, .
	//		Returns a CPoint type value.
    CPoint & OriginPos();

	// Obtain the column rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		index---Specifies A integer value.
    CRect GetColumnRect(int index);
    
	
	//-----------------------------------------------------------------------
	// Summary:
	// Navigate, .
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		navPoint---navPoint, Specifies A integer value.  
	//		updateImmediately---updateImmediately, Specifies A Boolean value.
    // Navigate
    void Navigate(CFOPCanvasCore *pWnd,FOPGridViewNavigationPoint navPoint,BOOL updateImmediately);
    
	// Do calc rectangles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Calculate Rects, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
    virtual void DoCalcRects();
    
	// Obtain the cell rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		row---Specifies A integer value.  
	//		cell---Specifies A integer value.  
	//		firstItem---firstItem, Specifies A integer value.  
	//		yDrawOrigin---Draw Origin, Specifies A integer value.  
	//		projectionColumnXGap---Column X Gap, Specifies A integer value.  
	//		projectionColumnYGap---Column Y Gap, Specifies A integer value.
    CRect GetCellRect(int row,
        int cell,
        int firstItem,           
        int yDrawOrigin,
        int projectionColumnXGap,
        int projectionColumnYGap);
    
	// Delete row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Row, Deletes the given object.
	// Parameters:
	//		index---Specifies A integer value.
    void DeleteRow(int index);

	// Delete all rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Rows, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DeleteAllRows();

	// Quick sort
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort Smaler Than, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		column---Specifies A integer value.  
	//		elementIdx1---elementIdx1, Specifies A integer value.  
	//		elementIdx2---elementIdx2, Specifies A integer value.
    BOOL QuickSortSmalerThan(int column,
        int elementIdx1,
        int elementIdx2);
    
	// Quick sort
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quick Sort, .
	// Parameters:
	//		low---Specifies A integer value.  
	//		hi---Specifies A integer value.  
	//		column---Specifies A integer value.  
	//		sortState---sortState, Specifies a FOPGridColumnSortState sortState object(Value).
    void QuickSort(int low, 
        int hi,
        int column,
        FOPGridColumnSortState sortState);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// This member function is also a virtual function, you can Override it if you need,
	// Sort columns
    virtual void Sort();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		column---Specifies A integer value.  
	//		sortState---sortState, Specifies a FOPGridColumnSortState sortState object(Value).
	// Sort columns
    virtual void Sort(int column,FOPGridColumnSortState sortState);
    
	// Check bound x
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Bounds X, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
    virtual void CheckBoundsX(CFOPCanvasCore *pWnd);

	// Check bound y
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Bounds Y, .
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
    void CheckBoundsY(CFOPCanvasCore *pWnd);
    
	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridCell ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.  
	//		nElement---nElement, Specifies a FOPGridViewElement & nElement object(Value).  
	//		nSubElement---Child Element, Specifies a FOPGridViewElement & nSubElement object(Value).  
	//		nIndex---nIndex, Specifies A integer value.  
	//		nExIndex---Ex Index, Specifies A integer value.  
	//		&bDblClk---Double click Clk, Specifies A Boolean value.
    virtual FOPGridCell *HitTestGrid(CPoint pt,
        FOPGridViewElement & nElement,
        FOPGridViewElement & nSubElement,
        int & nIndex,
        int & nExIndex,const BOOL &bDblClk = FALSE);
    
	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartShowEdit(CFOPCanvasCore* pView, CPoint ptCursorSP);
    
	// Reset all row selection mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Row Select, Called this function to empty a previously initialized CFOPNewGridShape object.

	void ResetAllRowSelect();

	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Cell, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPGridCell ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
    virtual FOPGridCell *HitTestCell(const CPoint &ptHit);
    
	// Calculate column width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Column Width, .
	//		Returns a int type value.  
	// Parameters:
	//		columnIndex---columnIndex, Specifies A integer value.  
	//		includeColumnText---Column Text, Specifies A Boolean value.
    int CalcColumnWidth(int columnIndex,BOOL includeColumnText = TRUE);

	// Calculate columns widths
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Column Widths, .
	// Parameters:
	//		includeHeaderText---Header Text, Specifies A Boolean value.
    void CalcColumnWidths(BOOL includeHeaderText = TRUE);
    
	// Check button state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Button State, .
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		subElement---subElement, Specifies a FOPGridViewElement subElement object(Value).  
	//		index---Specifies A integer value.
    void ChangeButtonState(CFOPCanvasCore *pWnd,FOPGridViewElement subElement,int index = -1);
    
	// Do change cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Set Cursor, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
    virtual BOOL DoSetCursor(const CPoint &ptHit);
    
	// Change sort column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sort Column, Sets a specify value to current class CFOPNewGridShape
	// Parameters:
	//		column---Specifies A integer value.  
	//		sortState---sortState, Specifies a FOPGridColumnSortState sortState object(Value).
    void SetSortColumn(int column,FOPGridColumnSortState sortState);
    
	// Change cell text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Cell Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strCell---&strCell, Specifies A CString type value.
	virtual void ChangeCellText(const CString &strCell);

    // Operations
public:
    // Create all fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Font, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void    AdjustFont();
    
    // Release the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void    ReleaseFont();
    
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Implementation
	FOPGridRow * GetSelectRow();

	// Get select row.
	int GetCurSelectRow();

	// Reset selected row select state.
	void ResetSelectedRow();

	// Select a specify row.
	void SelectRow(const int &nRow);

	// Reset all cell select state.
	void ResetAllCellSelect();

	// Change item text with row and column.
	void SetItemText(int nRow, int nColumn, const CString& strText);

	// Obtain item text with row and column.
	CString GetItemText(int nRow, int nColumn);

	// Obtain row text.
	CString GetRowText(int nRow);

	// Add rows, text with @ for seperator.
	void AddRows(const CString& strText);
	
	// Obtain next line.
	int FOGetNextLineExt(CString& s, CString &sLine);
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
    // Implementation
public:
 
	// Mode, This member specify FOPGridMode object.  
    FOPGridMode         m_aMode;
 
	// Column Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                 m_nColHeight;
 
	// Cell Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                 m_nCellHeight;
 
	// Allow Switch Primary Mode, This member sets TRUE if it is right.  
    BOOL                m_bAllowSwitchPrimaryMode;
 
	// Show Title Bar, This member sets TRUE if it is right.  
    BOOL                m_bShowTitleBar;
 
	// Stretch Color Override, This member sets TRUE if it is right.  
    BOOL                m_bStretchColorOverride;
 
	// Title Bar Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                 m_nTitleBarHeight;
 
	// Left Column Show, This member sets TRUE if it is right.  
    BOOL                m_bLeftColumnShow;
 
	// Left Column Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                 m_nLeftColumnWidth;
 
	// Title Bar, This member sets A 32-bit value used as a color value.  
    COLORREF            m_crTitleBar;
 
	// Title Bar Inactive, This member sets A 32-bit value used as a color value.  
    COLORREF            m_crTitleBarInactive;
 
	// Grid Line Style, This member specify FOPGridLineStyle object.  
    FOPGridLineStyle    m_aGridLineStyle;
 
	// Grid Line, This member sets A 32-bit value used as a color value.  
    COLORREF            m_crGridLine;
 
	// Array Columns, This member specify FOPColumnsArray object.  
    FOPColumnsArray     m_aArrayColumns;
 
	// Bold Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
    CFont*              m_pBoldFont;
 
	// Origin Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint              m_ptOriginPos;
 
	// Grid, This member specify FOPGridData object.  
    FOPGridData         m_dataGrid;
 
	// Rects, This member specify FOPGridRectStruct object.  
    FOPGridRectStruct   m_aRects;
 
	// Scroll Bar Button States, This member specify FOPGridSBBtnStates object.  
    FOPGridSBBtnStates  m_aScrollBarBtnStates;
 
	// S B At Right Most, This member sets TRUE if it is right.  
    BOOL                m_bSBAtRightMost;
 
	// S B At Bottom Most, This member sets TRUE if it is right.  
    BOOL                m_bSBAtBottomMost;
 
	// Modified, This member sets TRUE if it is right.  
    BOOL                m_bModified;
 
	// Save Grid Data, This member sets TRUE if it is right.  
    BOOL                m_bSaveGridData;
 
	// Sort Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int                 m_nSortColumn;
 
	// Tmp Grid Row, This member maintains a pointer to the object FOPGridRow.  
    FOPGridRow *        m_pTmpGridRow;
 
	// Last Minimized Node, This member sets a CSize value.  
    CSize               m_szLastMinimizedNode;
 
	// Column Width Include Header Text, This member sets TRUE if it is right.  
    BOOL                m_bColumnWidthIncludeHeaderText;
 
	// Selected, This member sets TRUE if it is right.  
    BOOL                m_bSelected;
 
	// Current Edit Cell, This member maintains a pointer to the object FOPGridCell.  
	FOPGridCell *		m_pCurEditCell;
 
	// Icon Lock, This member specify HICON object.  
	HICON				m_hIconLock;

};

const int fopGridInitButtonTimer			= 250;
const int fopGridBtnStateTimer		        = 10;

#define FOP_GRID_EVENT_TOOL			2001

////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// FOPGridHandleTool -- grid handle tool
// 
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The FOPGridHandleTool class derived from FOPMsgHandleTool
//      O P Grid Handle Tool
//===========================================================================

class FO_EXT_CLASS FOPGridHandleTool  : public FOPMsgHandleTool
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Grid Handle Tool, Constructs a FOPGridHandleTool object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.
	FOPGridHandleTool(CFOPCanvasCore *pWnd = NULL,int nID = FOP_GRID_EVENT_TOOL);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Grid Handle Tool, Constructs a FOPGridHandleTool object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		pGridShape---Grid Shape, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		subElement---subElement, Specifies a FOPGridViewElement subElement object(Value).  
	//		startPoint---startPoint, Specifies A CPoint type value.  
	//		subElementIndex---Element Index, Specifies A integer value.  
	//		nID---I D, Specifies A integer value.
    FOPGridHandleTool(CFOPCanvasCore *pWnd,CFOPNewGridShape * pGridShape,
        FOPGridViewElement subElement,
        CPoint startPoint,
        int subElementIndex = -1,int nID = FOP_GRID_EVENT_TOOL);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Handle Tool, Destructor of class FOPGridHandleTool
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPGridHandleTool();
    
public:

	// Init data
	// pGridShape -- pointer of the grid shape.
	// nType -- handle type.
	// startPoint-- start point.
	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pGridShape---Grid Shape, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		nType---nType, Specifies a FOPGridViewElement nType object(Value).  
	//		startPoint---startPoint, Specifies A CPoint type value.  
	//		subElementIndex---Element Index, Specifies A integer value.
    void DoInit(CFOPNewGridShape * pGridShape,FOPGridViewElement nType,
		CPoint startPoint,int subElementIndex = -1);

	// Obtain the sub element rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Element Rectangle, Returns the specified value.
	// Parameters:
	//		nButtonType---Button Type, Specifies a FOPGridViewElement nButtonType object(Value).  
	//		rect---Specifies A CRect type value.
    void GetSubElementRect(FOPGridViewElement nButtonType,CRect & rect);

	// Change button state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Button State, .
	// Parameters:
	//		nButtonType---Button Type, Specifies a FOPGridViewElement nButtonType object(Value).
    void ChangeButtonState(FOPGridViewElement nButtonType);
    
public:

	// Do on init mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// On When Initial, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void OnWhenInit();

	// On timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL OnTimer(UINT_PTR nIDEvent);

	// Do when mouse move
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    virtual BOOL OnMouseMove(UINT nFlags, CPoint point);

	// Do when mouse left button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    virtual BOOL OnLButtonUp(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnRButtonUp(UINT nFlags, CPoint point);

	// Do cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    virtual BOOL OnCancelMode();

public:
    
    // Return Grid shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Shape, Returns the specified value.
	//		Returns a pointer to the object CFOPNewGridShape ,or NULL if the call failed
    CFOPNewGridShape *GetGridShape() const { return m_pGridShape;}
    
    // Change Grid shape value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Shape, Sets a specify value to current class FOPGridHandleTool
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPNewGridShape  or NULL if the call failed.
    void SetGridShape( CFOPNewGridShape *pShape ) {m_pGridShape = pShape; }
    
    // Return SubElement value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Element, Returns the specified value.
	//		Returns A FOPGridViewElements value (Object).
    FOPGridViewElements GetSubElement() const { return m_aSubElement;}
    
    // Change SubElement value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Child Element, Sets a specify value to current class FOPGridHandleTool
	// Parameters:
	//		&nValue---&nValue, Specifies a const FOPGridViewElements &nValue object(Value).
    void SetSubElement( const FOPGridViewElements &nValue ) {m_aSubElement = nValue; }
    
    // Return SubElement Index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Element Index, Returns the specified value.
	//		Returns a int type value.
    int GetSubElementIndex() const { return m_aSubElementIndex;}
    
    // Change SubElement Index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Child Element Index, Sets a specify value to current class FOPGridHandleTool
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
    void SetSubElementIndex( const int &nValue ) {m_aSubElementIndex = nValue; }
    
	// Update grid with specify rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Grid, Call this member function to update the object.
	// Parameters:
	//		pRect---pRect, A pointer to the CRect  or NULL if the call failed.
    void UpdateGrid(CRect * pRect);

protected:
 
	// Grid Shape, This member maintains a pointer to the object CFOPNewGridShape.  
    CFOPNewGridShape *		m_pGridShape;
 
	// Child Element, This member specify FOPGridViewElements object.  
    FOPGridViewElements		m_aSubElement;
 
	// Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint					m_ptStart;
 
	// Mouse Over Button, This member sets TRUE if it is right.  
    BOOL					m_bMouseOverBtn;
 
	// Delayed Action, This member sets TRUE if it is right.  
    BOOL					m_bDelayedAction;
 
	// Child Element Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int						m_aSubElementIndex;
};

#endif // !defined(AFC_FOPNEWGRIDSHAPE_H__3FB4E9C3_F6F1_44EA_A792_B7A87482C3DD__INCLUDED_)
