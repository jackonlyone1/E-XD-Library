//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOYueObj.h: interface for the CFOYueObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOYUEOBJ_H__70D7EFD2_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOYUEOBJ_H__70D7EFD2_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Include head file of day object
#include "FODayObj.h"

#define     START_YEAR            1583	// define the start year
#define     SIMPLE_STYLE          0		// define simple style
#define     TRADITIONAL_STYLE     1		// defien traditional style

//////////////////////////////////////////////////////////////////////////////////
// CFOYueObj -- yue object.

 
//===========================================================================
// Summary:
//     The CFOYueObj class derived from CObject
//      F O Yue Object
//===========================================================================

class FO_EXT_CLASS CFOYueObj : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOYueObj---F O Yue Object, Specifies a E-XD++ CFOYueObj object (Value).
	DECLARE_SERIAL(CFOYueObj);

public:
	// get an object from a list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Objects, Returns the specified value.
	//		Returns a pointer to the object CFODayObjList,or NULL if the call failed
	CFODayObjList* GetObjects()		{ return &m_objects; }

	// initialize
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Yue Object, Constructs a CFOYueObj object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nYear---nYear, Specifies A integer value.  
	//		nMonth---nMonth, Specifies A integer value.  
	//		nDate---nDate, Specifies A integer value.
	CFOYueObj(int nYear = -1, int nMonth = -1, int nDate = -1);

	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Yue Object, Constructs a CFOYueObj object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOYueObj& source object(Value).
	CFOYueObj(const CFOYueObj& source);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOYueObj& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOYueObj& source object(Value).
	CFOYueObj& operator=(const CFOYueObj& source);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOYueObj,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOYueObj* Copy() const;

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Yue Object, Destructor of class CFOYueObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOYueObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// serialize
	virtual void Serialize(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		pObj---pObj, A pointer to the CFODayObj or NULL if the call failed.
	// add an object
	void		Add(CFODayObj* pObj);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		pObj---pObj, A pointer to the CFODayObj or NULL if the call failed.
	// remove an object
	void		Remove(CFODayObj* pObj);

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		mm---Specifies A integer value.  
	//		id---Specifies A integer value.  
	//		iyyy---Specifies A integer value.
	long		julday (int mm, int id, int iyyy);

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// D O M, .
	//		Returns a int type value.
	int			FDOM ();

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Leap Year, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		LeapYear ();

	// get days in month
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Daysin Month, Returns the specified value.
	//		Returns a int type value.
	int			GetDaysinMonth();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Initial, .

	// reinitialize 
	void		ReInit();

	// find a day 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Day, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODayObj ,or NULL if the call failed  
	// Parameters:
	//		nY---nY, Specifies A integer value.  
	//		nM---nM, Specifies A integer value.  
	//		nD---nD, Specifies A integer value.
	CFODayObj *	FindDay(int nY,int nM,int nD);
	
	virtual void SVG_GenFill(CString &strIn);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void		Draw(CDC *pDC);

	// initialize month
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Month, Call InitMonth after creating a new object.

	void		InitMonth();

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFODayObj,or NULL if the call failed  
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	CFODayObj*	HitTest(CPoint &pt);

public:
 
	// Year, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nYear;		// year
 
	// Month, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int			m_nMonth;		// month
 
	// Date, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDate;		// date
 
	// This member specify E-XD++ CFODayObjList object.  
	CFODayObjList m_objects;	// list of objects
 
	// Cell Height, This member specify short object.  
	short		nCellHeight;	// height of a cell
 
	// Cell Width, This member specify short object.  
    short		nCellWidth;		// width of a cell	
	int			nRows, nColumns, nMargins, nStyle; // row ,column ,margin ,style
 
	// Position, This member sets a CRect value.  
	CRect		rcPosition;		// position
 
	// Minus, This member sets a CRect value.  
    CRect		m_rMinus;		// minus
 
	// Plus, This member sets a CRect value.  
    CRect		m_rPlus;		// plus			
 
	// Year, This member sets a CRect value.  
    CRect		m_rYear;		// year display rect
 
	// Current Day, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCurDay;		// current day
 
	// Current Month, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCurMonth;		// current month		
 
	// Current Year, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCurYear;		// current year
public:
	// set backk color of days
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Days Back Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetDaysBackColor(COLORREF cr) {crBackColor = cr;};

	// set text color of days
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Days Text Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetDaysTextColor(COLORREF cr) { crTextColor = cr;};

	// set border color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetBorderColor(COLORREF cr)   { crBorder = cr;};

	// set bkcolor of year
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Year Back Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetYearBackColor(COLORREF cr) { crTitle = cr;};

	// set color of year bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Year Bar Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetYearBarColor(COLORREF cr)  {crTitleTextColor = cr;};

	// set color of week bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Week Bar Color, Sets a specify value to current class CFOYueObj
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetWeekBarColor(COLORREF cr)  {crCaptionColor = cr;};

protected:
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF crBackColor;		// background color
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF crTextColor;		// text color
 
	// Border, This member sets A 32-bit value used as a color value.  
	COLORREF crBorder;			// border color
 
	// Title, This member sets A 32-bit value used as a color value.  
	COLORREF crTitle;			// title color
 
	// Title Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF crTitleTextColor;	// title text color
 
	// Caption Color, This member sets A 32-bit value used as a color value.  
	COLORREF crCaptionColor;	// caption color
public:

	// virtual function :save a document ;Para :path name given
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// virtual function :open a document ;Para :path name given
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// get a file ;Para: filename , open flags , file exception
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *	GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// virtual function : release a file ;Para: file pointer , flag of continue
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// change year ; Para :year
	
	//-----------------------------------------------------------------------
	// Summary:
	// Chnage Year, .
	// Parameters:
	//		nChangeYear---Change Year, Specifies A integer value.
	void ChnageYear(int nChangeYear);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOYueObj object.

	// reset : reset all paras to default
	void Reset();
	
};
typedef CTypedPtrList<CObList, CFOYueObj*> CFOYueObjList;

#endif // !defined(AFX_FOYUEOBJ_H__70D7EFD2_F31E_11DD_A436_525400EA266C__INCLUDED_)
