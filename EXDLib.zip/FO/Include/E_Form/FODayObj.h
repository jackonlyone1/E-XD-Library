//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODayObj.h: interface for the CFODayObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODAYOBJ_H__70D7EFD1_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FODAYOBJ_H__70D7EFD1_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Define for class CFODayObj.
#define FO_DAY_TYPE_0					99
#define FO_DAY_TYPE_1					100
#define FO_DAY_TYPE_2					101
#define FO_DAY_TYPE_3					102
#define FO_DAY_TYPE_4					103
#define FO_DAY_TYPE_5					104
#define FO_DAY_TYPE_6					105
#define FO_DAY_TYPE_7					106

////////////////////////////////////////////////////////////////////////////////
// CFODayObj -- day object.

 
//===========================================================================
// Summary:
//     The CFODayObj class derived from CObject
//      F O Day Object
//===========================================================================

class FO_EXT_CLASS CFODayObj : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODayObj---F O Day Object, Specifies a E-XD++ CFODayObj object (Value).
	DECLARE_SERIAL(CFODayObj);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Day Object, Constructs a CFODayObj object.
	//		Returns A  value (Object).
	CFODayObj();

	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Day Object, Constructs a CFODayObj object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFODayObj& source object(Value).
	CFODayObj(const CFODayObj& source);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODayObj& value (Object).  
	// Parameters:
	//		source---Specifies a const CFODayObj& source object(Value).
	CFODayObj& operator=(const CFODayObj& source);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODayObj,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFODayObj* Copy() const;

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Day Object, Destructor of class CFODayObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODayObj();
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
	// Draw the object with normal state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DrawNormal(CDC *pDC);
	
	virtual void SVG_GenFill(CString &strIn);

	// Draw the object with select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Select, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DrawSelect(CDC *pDC);
	
	// Draw the object with type state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Type, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DrawType(CDC *pDC);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	// Draw the object.
	virtual void Draw(CDC *pDC);
public:

	// Is Select
 
	// Select, This member sets TRUE if it is right.  
	BOOL			bSelect;

	// Position Rectangle
 
	// Position, This member sets a CRect value.  
	CRect			rcPosition;

	// Type
 
	// Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			nType;

	// Caption string
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strCaption;

	// Day
 
	// Day, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nDay;

	// Current Month
 
	// Current Month, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nCurMonth;

	// Current Day
 
	// Current Day, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nCurDay;

	// Current Year
 
	// Current Year, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nCurYear;

	// 
 
	// Jia Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strJiaName;

	// Current Week
 
	// Current Week, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nCurWeek;
	
	// Is Week or Not
 
	// Week, This member sets TRUE if it is right.  
	BOOL			bWeek;
	
	// Text Color
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF		crTextColor;
	
	// Back Color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF		crBackColor;
};

// day object list.
typedef CTypedPtrList<CObList, CFODayObj*> CFODayObjList;

#endif // !defined(AFX_FODAYOBJ_H__70D7EFD1_F31E_11DD_A436_525400EA266C__INCLUDED_)
