// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOAUTOFONTTEXTSHAPE_H__8EA336F4_120D_4EAC_B2B9_E5899E96A16C__INCLUDED_)
#define AFC_FOAUTOFONTTEXTSHAPE_H__8EA336F4_120D_4EAC_B2B9_E5899E96A16C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOEditBoxShape.h"

////////////////////////////////////////////////////////////////////////////
// CFOAutoFontFillShape --  this is a text shape, it's font size will
//						be automatic created with it's bounding rectangle.
// 
///////////////////////////////////////////////////////////////////
 

 
//===========================================================================
// Summary:
//     The CFOAutoFontFillShape class derived from CFOEditBoxShape
//      F O Automatic Font Fill Shape
//===========================================================================

class FO_EXT_CLASS CFOAutoFontFillShape : public CFOEditBoxShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAutoFontFillShape---F O Automatic Font Fill Shape, Specifies a E-XD++ CFOAutoFontFillShape object (Value).
	DECLARE_SERIAL(CFOAutoFontFillShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Automatic Font Fill Shape, Constructs a CFOAutoFontFillShape object.
	//		Returns A  value (Object).
	CFOAutoFontFillShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Automatic Font Fill Shape, Constructs a CFOAutoFontFillShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOAutoFontFillShape& src object(Value).
	CFOAutoFontFillShape(const CFOAutoFontFillShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Automatic Font Fill Shape, Destructor of class CFOAutoFontFillShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAutoFontFillShape();

	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Is or no auto font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is auto font Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsAutoFont() const;
	
	// Set auto font mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set auto font Mode, Sets a specify value to current class CFOAutoFontTextShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAuto---auto font Mode, Specifies A Boolean value.
	virtual void SetAutoFont(BOOL bAuto);

	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOAutoFontFillShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Create auto size of font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Automatic Size Font, You construct a CFOAutoFontFillShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HFONT value (Object).  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		*rect---A pointer to the RECT  or NULL if the call failed.  
	//		string---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	HFONT CreateAutoSizeFont(HDC hdc, RECT *rect,LPCTSTR string);

	// Rectangle size from font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Size From Font, .
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		*pLf---*pLf, A pointer to the LOGFONT  or NULL if the call failed.
	CSize RectSizeFromFont( CDC *pDC, CString strLabel, LOGFONT *pLf );

	// Font size from rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Font Size From Rectangle, .
	//		Returns A LOGFONT value (Object).  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		*pLf---*pLf, A pointer to the LOGFONT  or NULL if the call failed.  
	//		*pR---*pR, A pointer to the CRect  or NULL if the call failed.
	LOGFONT FontSizeFromRect(CDC *pDC, CString strLabel, LOGFONT *pLf, CRect *pR );

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOAutoFontFillShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOAutoFontFillShape& src object(Value).
	CFOAutoFontFillShape& operator=(const CFOAutoFontFillShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bFlat---bFlat, Specifies A Boolean value.
	virtual void OnDrawText(CDC *pDC,BOOL bFlat);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Save size of shape.
 
	// Save, This member sets a CSize value.  
	CSize m_szSave;

	// Save old title
 
	// Old Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOldTitle;

	// Date font.
 
	// Date Font, This member specify LOGFONT object.  
	LOGFONT m_lfDateFont;

	// Current font size.
 
	// Current Font Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nCurFontSize;
};


#endif // !defined(AFC_FOAUTOFONTTEXTSHAPE_H__8EA336F4_120D_4EAC_B2B9_E5899E96A16C__INCLUDED_)
