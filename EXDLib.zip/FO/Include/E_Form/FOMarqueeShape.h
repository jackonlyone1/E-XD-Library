//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMarqueeShape.h: interface for the CFOMarqueeShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMARQUEESHAPE_H__70D7EFD0_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOMARQUEESHAPE_H__70D7EFD0_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FODrawPortsShape.h"

///////////////////////////////////////////////////////////
// CFOMarqueeShape
// Marquee Shape.
//------------------------------------------------------


 
//===========================================================================
// Summary:
//     The CFOMarqueeShape class derived from CFODrawPortsShape
//      F O Marquee Shape
//===========================================================================

class FO_EXT_CLASS CFOMarqueeShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMarqueeShape---F O Marquee Shape, Specifies a E-XD++ CFOMarqueeShape object (Value).
	DECLARE_SERIAL(CFOMarqueeShape);

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Marquee Shape, Constructs a CFOMarqueeShape object.
	//		Returns A  value (Object).
	CFOMarqueeShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Marquee Shape, Constructs a CFOMarqueeShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMarqueeShape& src object(Value).
	CFOMarqueeShape(const CFOMarqueeShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Marquee Shape, Destructor of class CFOMarqueeShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMarqueeShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMarqueeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the marquee shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMarqueeShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMarqueeShape& src object(Value).
	CFOMarqueeShape& operator=(const CFOMarqueeShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Get the position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOMarqueeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Get next line of the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Next Line Extend, .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A CString type value.  
	//		&sLine---&sLine, Specifies A CString type value.
	int FOGetNextLineExt(CString& s, CString &sLine);

	int GetTextLength(CString s);

	
	// Get choice list,this is the choice list string of the shape CFOTabbedComboShape.
	// It return a string like this:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice List, Returns the specified value.
	//		Returns a CString type value.
	CString		GetChoiceList() const;
	
	// Change the choice list string of the shape CFOTabbedComboShape,
	// strChoice -- It must be like the following string:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CFOMarqueeShape
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	void		SetChoiceList(const CString &strChoice);
	
public:

	//Draw flat status.

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();

	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();

	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOMarqueeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);

	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOMarqueeShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOMarqueeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

public:
	// Current timer ID
	FOPString strCurDraw;
	FOPString strRemain;
	int nCharWidth;

	int nAllDraw;

	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;

	// Current text length.
 
	// Current Text Len, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCurTextLen;

	// Current timer speed, default is 400
 
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;

	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;
};

#endif // !defined(AFX_FOMARQUEESHAPE_H__70D7EFD0_F31E_11DD_A436_525400EA266C__INCLUDED_)
