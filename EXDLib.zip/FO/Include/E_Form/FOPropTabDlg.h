//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPropTabDlg.h: interface for the CFOPropTabDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPROPTABDLG_H__25CFE446_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
#define AFX_FOPROPTABDLG_H__25CFE446_E30F_11D5_A4B4_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOTabSubObj.h"
#include "FOImageButton.h"

/////////////////////////////////////////////////////////////////////////////////
// CFOPropTabDlg -- tab property dialog.

 
//===========================================================================
// Summary:
//     The CFOPropTabDlg class derived from CDialog
//      F O Property Tab Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropTabDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Tab Dialog, Constructs a CFOPropTabDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropTabDlg(CWnd* pParent = NULL);   // standard constructor


	// Dialog Data
	//{{AFX_DATA(CFOPropTabDlg)
	enum { IDD = IDD_FO_COMP_PROP_TAB };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	//Update Control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.

	void				UpdateControl();

	//List of Tab SubObject
 
	// List, This member maintains a pointer to the object CFOTabSubObjList.  
	CFOTabSubObjList*	pList;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	//Clear All
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void				ClearAll();

	// Find tab with name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFindName---Find Name, Specifies A CString type value.
	BOOL FindTab(const CString &strFindName);

	// Get Unique Name,this will check all the shapes on the canvas,and generate the unique name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Name, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString			GetUniqueName();

	//Tab position
 
	// Tab Position, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				nTabPos;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPropTabDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropTabDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Double click Fo Component Listbox, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnDblclkFoCompListbox();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Add, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Delete, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabDelete();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Edit, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabEdit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Radio Left, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabRadioLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Radio Top, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabRadioTop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Radio Right, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabRadioRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Tab Radio Bottom, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompTabRadioBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


#endif // !defined(AFX_FOPROPTABDLG_H__25CFE446_E30F_11D5_A4B4_525400EA266C__INCLUDED_)
