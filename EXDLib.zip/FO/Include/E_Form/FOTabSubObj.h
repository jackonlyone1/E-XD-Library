//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOTabSubObj.h: interface for the CFOTabSubObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOTABSUBOBJ_H__70D7EFD9_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOTABSUBOBJ_H__70D7EFD9_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////////////////
// CFOTabSubObj -- tab children object.

 
//===========================================================================
// Summary:
//     The CFOTabSubObj class derived from CObject
//      F O Tab Child Object
//===========================================================================

class FO_EXT_CLASS CFOTabSubObj : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabSubObj---F O Tab Child Object, Specifies a E-XD++ CFOTabSubObj object (Value).
	DECLARE_SERIAL(CFOTabSubObj);

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Child Object, Constructs a CFOTabSubObj object.
	//		Returns A  value (Object).
	CFOTabSubObj();

	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Child Object, Constructs a CFOTabSubObj object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOTabSubObj& source object(Value).
	CFOTabSubObj(const CFOTabSubObj& source);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOTabSubObj& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOTabSubObj& source object(Value).
	CFOTabSubObj& operator=(const CFOTabSubObj& source);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabSubObj,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOTabSubObj* Copy() const;

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Child Object, Destructor of class CFOTabSubObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabSubObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// serialize
	virtual void Serialize(CArchive &ar);

public:

	// Number of the page.
 
	// Tab Number, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nTabNumber;

	// Title.
 
	// Title, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strTitle;

	// Tab class name.
	// No used now.
 
	// Class, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strClass;

	// Tab icon resource id.
	// No used now.
 
	// Icon, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strIcon;

	// Position of tab page.
 
	// Title, This member sets a CRect value.  
	CRect m_rcTitle;

};
typedef CTypedPtrList<CObList, CFOTabSubObj*> CFOTabSubObjList;

#endif // !defined(AFX_FOTABSUBOBJ_H__70D7EFD9_F31E_11DD_A436_525400EA266C__INCLUDED_)
