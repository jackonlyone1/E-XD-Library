//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOButtonShape.h: interface for the CFOButtonShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBUTTONSHAPE_H__70D7EFC7_F31E_11DD_A436_525400EA266C__INCLUDED_)
#define AFX_FOBUTTONSHAPE_H__70D7EFC7_F31E_11DD_A436_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOInsideBaseShape.h"

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// CFOButtonShape -- Button shape.
//------------------------------------------------------
#define HDIB HANDLE
#define xBFT_ICON   0x4349   // 'IC'
#define xBFT_BITMAP 0x4d42   // 'BM'
#define xBFT_CURSOR 0x5450   // 'PT'

class FO_EXT_CLASS CFOPButtonDib
{
public:
	CFOPButtonDib();
	~CFOPButtonDib();
	HDIB Create(DWORD dwWidth, DWORD dwHeight, WORD wBitCount);
	void Clear(BYTE bval=0);
	void Clone(CFOPButtonDib *src);
	BOOL IsValid();
	long GetSize();
	BYTE* GetBits();
	DWORD GetHeight() {return m_bi.biHeight;};
	DWORD GetWidth() {return m_bi.biWidth;};
	DWORD GetLineWidth() {return m_LineWidth;};
	WORD GetNumColors() {return m_nColors;};
	WORD GetBitCount() {return m_bi.biBitCount;};
	WORD GetPaletteSize();
	BYTE GetPixelIndex(long x,long y);
	RGBQUAD GetPaletteIndex(BYTE idx);
	RGBQUAD GetPixelColor(long x,long y);
	BYTE GetNearestIndex(RGBQUAD c);
	long Draw(HDC pDC, long xoffset, long yoffset);
	long Stretch(HDC pDC, long xoffset, long yoffset, long xsize, long ysize);
	void BlendPalette(COLORREF cr,long perc);
	void SetPaletteIndex(BYTE idx, BYTE r, BYTE g, BYTE b);
	void SetPaletteIndex(BYTE idx, RGBQUAD c);
	void SetPaletteIndex(BYTE idx, COLORREF cr);
	void SetPixelColor(long x,long y,RGBQUAD c);
	void SetPixelIndex(long x,long y,BYTE i);
	void SetPixelColor(long x,long y,COLORREF cr);
	void SetGrayPalette();
	long WriteBMP(LPSTR bmpFileName);
	RGBQUAD HSLtoRGB(COLORREF cHSLColor);
	RGBQUAD RGB2RGBQUAD(COLORREF cr);
	COLORREF RGBQUAD2RGB (RGBQUAD c);
	RGBQUAD RGBtoHSL(RGBQUAD lRGBColor);
	RGBQUAD HSLtoRGB(RGBQUAD lHSLColor);
protected:
	HDIB hDib;
    BITMAPINFOHEADER    m_bi;
	DWORD m_LineWidth;
	WORD  m_nColors;
	bool IsWin30Dib();
	WORD HueToRGB(WORD n1,WORD n2,WORD hue);
};


#define SHS_NOISE 0
#define SHS_DIAGSHADE 1
#define SHS_HSHADE 2
#define SHS_VSHADE 3
#define SHS_HBUMP 4
#define SHS_VBUMP 5
#define SHS_SOFTBUMP 6
#define SHS_HARDBUMP 7
#define SHS_METAL 8
 
//===========================================================================
// Summary:
//     The CFOButtonShape class derived from CFOPEFormBaseShape
//      F O Button Shape
//===========================================================================

class FO_EXT_CLASS CFOButtonShape : public CFOPEFormBaseShape  
{

protected:

	// Adding serial support.
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOButtonShape---F O Button Shape, Specifies a E-XD++ CFOButtonShape object (Value).
	DECLARE_SERIAL(CFOButtonShape);

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Button Shape, Constructs a CFOButtonShape object.
	//		Returns A  value (Object).
	CFOButtonShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Button Shape, Constructs a CFOButtonShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOButtonShape& src object(Value).
	CFOButtonShape(const CFOButtonShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Button Shape, Destructor of class CFOButtonShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOButtonShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	// rcPos -- Position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Change shade style
	void SetShade(UINT shadeID=0,BYTE granularity=8,BYTE highlight=10,BYTE coloring=0,COLORREF color=0);

	// Focus margin.
	short	m_FocusRectMargin;	//dotted margin offset

	// Drawing data.
	CFOPButtonDib	m_dNormal,m_dDown,m_dDisabled,m_dOver,m_dh,m_dv;
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOButtonShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOButtonShape& src object(Value).
	CFOButtonShape& operator=(const CFOButtonShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the Select status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcTotal---rcTotal, Specifies A CRect type value.
	virtual void OnDrawFace(CDC *pDC,CRect rcTotal);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draw edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Edit, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcEdit---rcEdit, Specifies A CRect type value.
	virtual void DrawEdit(CDC* pDC,CRect rcEdit);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartEdit(CFOPCanvasCore * pView, CPoint ptCursorSP);
    
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

};


//------------------------------------------------------
// CFOMenuButtonShape shape with Drop menu.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOMenuButtonShape class derived from CFOButtonShape
//      F O Menu Button Shape
//===========================================================================

class FO_EXT_CLASS CFOMenuButtonShape : public CFOButtonShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMenuButtonShape---F O Menu Button Shape, Specifies a E-XD++ CFOMenuButtonShape object (Value).
	DECLARE_SERIAL(CFOMenuButtonShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Menu Button Shape, Constructs a CFOMenuButtonShape object.
	//		Returns A  value (Object).
	CFOMenuButtonShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Menu Button Shape, Constructs a CFOMenuButtonShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMenuButtonShape& src object(Value).
	CFOMenuButtonShape(const CFOMenuButtonShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Menu Button Shape, Destructor of class CFOMenuButtonShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMenuButtonShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMenuButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	void GetMenuListEx(CArray<FOPSTATE,FOPSTATE> *arStates);
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMenuButtonShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMenuButtonShape& src object(Value).
	CFOMenuButtonShape& operator=(const CFOMenuButtonShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Do sub button id click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Button Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSubButtonClick();

	// Show popup menus.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void ShowPopup( CPoint point, CFOPCanvasCore* parent );
	
	// Execute menu item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		from---A pointer to the CWnd or NULL if the call failed.
	virtual BOOL DoMessage( UINT msg,CWnd* from = NULL );
	
	// Get next line of the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Next Line Extend, .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A CString type value.  
	//		&sLine---&sLine, Specifies A CString type value.
	int FOGetNextLineExt(CString& s, CString &sLine);

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Draws the Select status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcTotal---rcTotal, Specifies A CRect type value.
	virtual void OnDrawFace(CDC *pDC,CRect rcTotal);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOBitmapButtonShape -- bitmap button shape.
// Author: Author.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOBitmapButtonShape class derived from CFOMenuButtonShape
//      F O Bitmap Button Shape
//===========================================================================

class FO_EXT_CLASS CFOBitmapButtonShape : public CFOMenuButtonShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBitmapButtonShape---F O Bitmap Button Shape, Specifies a E-XD++ CFOBitmapButtonShape object (Value).
	DECLARE_SERIAL(CFOBitmapButtonShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Button Shape, Constructs a CFOBitmapButtonShape object.
	//		Returns A  value (Object).
	CFOBitmapButtonShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Button Shape, Constructs a CFOBitmapButtonShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBitmapButtonShape& src object(Value).
	CFOBitmapButtonShape(const CFOBitmapButtonShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bitmap Button Shape, Destructor of class CFOBitmapButtonShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBitmapButtonShape();
	
	enum Alignment
	{
		Al_Left,		    // Bitmap on left, text on right
			Al_Right,		// Bitmap on right, text on left
			Al_Top,			// Bitmap on top, text on bottom
			Al_Bottom,		// Bitmap on bottom, text on top
			Al_Center		// Bitmap centered in button. No caption.
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBitmapButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	// rcPos -- Position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBitmapButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		alignment---Specifies a Alignment alignment object(Value).  
	//		lpszBmpName---Bitmap Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos, Alignment alignment, LPCTSTR lpszBmpName,CString strCaption = _T(""));
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBitmapButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		alignment---Specifies a Alignment alignment object(Value).  
	//		nIDBmp---I D Bitmap, Specifies A integer value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,Alignment alignment, int nIDBmp, CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBitmapButtonShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBitmapButtonShape& src object(Value).
	CFOBitmapButtonShape& operator=(const CFOBitmapButtonShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Sets the bitmap margin offsets.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Indents, Sets a specify value to current class CFOBitmapButtonShape
	// Parameters:
	//		sz---Specifies A CSize type value.
	void SetIndents(CSize sz);
	
	// Returns the bitmap margin offsets.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Indents, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetIndents() const;

	// Calculates the position of the bitmap and text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Layout, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CalcLayout();

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bImageTransparent; }
	
	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOBitmapButtonShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Change to new image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap Resource, Sets a specify value to current class CFOBitmapButtonShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBitmapRes(const UINT &nRes);
	
	// Change to new image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap Resource, Sets a specify value to current class CFOBitmapButtonShape
	// Parameters:
	//		&strRes---&strRes, Specifies A CString type value.
	void SetBitmapRes(const CString &strRes);

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Draws the Select status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcTotal---rcTotal, Specifies A CRect type value.
	virtual void OnDrawFace(CDC *pDC,CRect rcTotal);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Id of the Bitmap.
 
	// Bitmap I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT m_nBitmapID;
	
	// Resource name.
 
	// Resource Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strResName;
	
	// Bitmap cache.
 
	// Bitmap Cache, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap * m_pBitmapCache;
	
	// Is transparent or not.
 
	// Image Transparent, This member sets TRUE if it is right.  
	BOOL	m_bImageTransparent;
	
	// Indentations of bitmap from edge of button face.
 
	// This member sets a CSize value.  
	CSize		m_indents;
	
	// Window rectangle for the bitmap
 
	// Rectangle, This member sets a CRect value.  
	CRect		m_bmpRect;
	
	// Window rectangle for the text
 
	// Rectangle, This member sets a CRect value.  
	CRect		m_textRect;
	
	// The alignment mode.
 
	// This member specify Alignment object.  
	Alignment	m_alignment;

};

#endif // !defined(AFX_FOBUTTONSHAPE_H__70D7EFC7_F31E_11DD_A436_525400EA266C__INCLUDED_)
