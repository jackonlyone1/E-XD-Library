//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPageProperties.h: interface for the CFOPageProperties class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPAGEPROPERTIES_H__18CF5273_F709_11DD_A43D_525400EA266C__INCLUDED_)
#define AFX_FOPAGEPROPERTIES_H__18CF5273_F709_11DD_A43D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Properties.
//------------------------------------------------------

#include "FOBaseProperties.h"
const COLORREF fo_DefaultPageColor = RGB(255,255,255);

//////////////////////////////////
// Standard page properties.
//////////////////////////////////

#define G_ID_NUMBER		3001
#define G_ID_SELECT		3002
#define G_ID_POS		3003
#define G_ID_CAPTION	3004
#define G_ID_BK_COLOR	3005

//************************************************************
//   CFOPageProperties
//
// This Properties object is only defined for Multi Pages style data model,
// See sample CustomMSample,it is called within class CFOMultiPageModel,
// A GetDefaultPageProperty method defined within class CFOMultiPageModel is
// used to visit this properties values.
//
//************************************************************

 
//===========================================================================
// Summary:
//     The CFOPageProperties class derived from CFOBaseProperties
//      F O Page Properties
//===========================================================================

class FO_EXT_CLASS CFOPageProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPageProperties---F O Page Properties, Specifies a E-XD++ CFOPageProperties object (Value).
	DECLARE_SERIAL(CFOPageProperties)

	// Construction/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Properties, Constructs a CFOPageProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOPageProperties(int nCurID = FO_DEFAULT_PAGE_PROP_ID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Properties, Constructs a CFOPageProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOPageProperties& propShape object(Value).
	CFOPageProperties(const CFOPageProperties& propShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Page Properties, Destructor of class CFOPageProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPageProperties();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current property.
	virtual CFOBaseProperties* Copy();

public:
	/*************************************************************************
	|*
	|* The following properties value only used for Multiple Model (CFOMultiPageModel)
	|* It is used for each page's data model.
	|*
	\************************************************************************/

	// get page item number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Number, Returns the specified value.
	//		Returns a int type value.
	int		GetPageItemNumber() const			{ return m_nPageNumber; }

	// Change page item number
	// num -- number of the page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Number, Sets a specify value to current class CFOPageProperties
	// Parameters:
	//		&num---Specifies A integer value.
	void	SetPageItemNumber(const int &num)	{ m_nPageNumber = num; }

	// get flag of page being selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Page Item Selectd, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsPageItemSelectd() const			{ return m_bFormSelected; }

	// Change page item to be selected.
	// bSelect -- selected or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Selected, Sets a specify value to current class CFOPageProperties
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void	SetPageItemSelected(const BOOL &bSelect) { m_bFormSelected = bSelect; }

	// get page position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Position, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetPageItemPosition() const			{ return m_rcItemRect; }

	// Change page position.
	// rc -- page item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Position, Sets a specify value to current class CFOPageProperties
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void	SetPageItemPosition(const CRect &rc) { m_rcItemRect = rc; }

	// get page caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Caption, Returns the specified value.
	//		Returns a CString type value.
	CString GetPageItemCaption() const			{ return m_strPageCaption; }

	// Change page caption.
	// strCap -- page item caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Caption, Sets a specify value to current class CFOPageProperties
	// Parameters:
	//		&strCap---&strCap, Specifies A CString type value.
	void	SetPageItemCaption(const CString &strCap) { m_strPageCaption = strCap; }

	// get back color of page 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Item Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetPageItemBackColor() const		{ return m_crDefaultPageColor; }

	// Change page item back color.
	// crBack -- page item back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Item Back Color, Sets a specify value to current class CFOPageProperties
	// Parameters:
	//		&crBack---&crBack, Specifies A 32-bit COLORREF value used as a color value.
	void	SetPageItemBackColor(const COLORREF &crBack) { m_crDefaultPageColor = crBack; }

public:

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOPageProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOPageProperties& propEdit object(Value).
	virtual CFOPageProperties& operator=(const CFOPageProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOPageProperties propEdit object(Value).
	virtual BOOL operator==(const CFOPageProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Attributes
protected:

	// page item number
 
	// Page Number, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nPageNumber;	
	
	// is current page selected
 
	// Form Selected, This member sets TRUE if it is right.  
	BOOL		m_bFormSelected;	
	
	// rect of item
 
	// Item Rectangle, This member sets a CRect value.  
	CRect		m_rcItemRect;			

	// caption of item
 
	// Page Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strPageCaption;		

	// default color of item
 
	// Default Page Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crDefaultPageColor;	
};

_FOLIB_INLINE CFOBaseProperties* CFOPageProperties::Copy()
{
	return new CFOPageProperties(*this);
}


#endif // !defined(AFX_FOPAGEPROPERTIES_H__18CF5273_F709_11DD_A43D_525400EA266C__INCLUDED_)
