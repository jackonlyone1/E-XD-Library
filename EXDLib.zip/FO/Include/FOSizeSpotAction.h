//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOSIZESPOTACTION_H__084B4B32_BBEF_11D5_A47A_525400EA266C__INCLUDED_)
#define AFC_FOSIZESPOTACTION_H__084B4B32_BBEF_11D5_A47A_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action
///////////////////////////////////////

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOSizeSpotAction -- action that size the spot of shape.

 
//===========================================================================
// Summary:
//     The CFOSizeSpotAction class derived from CFOAction
//      F O Size Spot Action
//===========================================================================

class FO_EXT_CLASS CFOSizeSpotAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSizeSpotAction---F O Size Spot Action, Specifies a E-XD++ CFOSizeSpotAction object (Value).
	DECLARE_ACTION(CFOSizeSpotAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Size Spot Action, Constructs a CFOSizeSpotAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOSizeSpotAction(CFODataModel* pModel,CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Size Spot Action, Destructor of class CFOSizeSpotAction
	//		Returns A  value (Object).
	~CFOSizeSpotAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOSizeSpotAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Index, Returns the specified value.
	//		Returns a int type value.
	int GetOldIndex()				{ return nOldIndex; }

	// Set old index.
	// nIndex -- index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Index, Sets a specify value to current class CFOSizeSpotAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetOldIndex(int nIndex)	{ nOldIndex = nIndex; }

	// Get new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Index, Returns the specified value.
	//		Returns a int type value.
	int GetNewIndex()				{ return nNewIndex; }

	// Set new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Index, Sets a specify value to current class CFOSizeSpotAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetNewIndex(int nIndex)	{ nNewIndex = nIndex; }

	// Get new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOSizeSpotAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// old index
 
	// Old Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nOldIndex;			

	// new index
 
	// New Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nNewIndex;			

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;			
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOSizeSpotAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOSizeSpotAction::GetShape()
{
	return m_pShape;
}

////////////////////////////////////////////////////////////
// CFOSizeCenterSpotAction -- action that sizing the center spot of line shape.

 
//===========================================================================
// Summary:
//     The CFOSizeCenterSpotAction class derived from CFOAction
//      F O Size Center Spot Action
//===========================================================================

class FO_EXT_CLASS CFOSizeCenterSpotAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSizeCenterSpotAction---F O Size Center Spot Action, Specifies a E-XD++ CFOSizeCenterSpotAction object (Value).
	DECLARE_ACTION(CFOSizeCenterSpotAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Size Center Spot Action, Constructs a CFOSizeCenterSpotAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOSizeCenterSpotAction(CFODataModel* pModel,CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Size Center Spot Action, Destructor of class CFOSizeCenterSpotAction
	//		Returns A  value (Object).
	~CFOSizeCenterSpotAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOSizeCenterSpotAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	//TODO:Add your code here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Index, Returns the specified value.
	//		Returns a int type value.
	int GetOldIndex()				{ return nOldIndex; }

	// Set old index.
	// nIndex -- index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Index, Sets a specify value to current class CFOSizeCenterSpotAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetOldIndex(int nIndex)	{ nOldIndex = nIndex; }

	// Get new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Index, Returns the specified value.
	//		Returns a int type value.
	int GetNewIndex()				{ return nNewIndex; }

	// Set new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Index, Sets a specify value to current class CFOSizeCenterSpotAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetNewIndex(int nIndex)	{ nNewIndex = nIndex; }

	// Get new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOSizeCenterSpotAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// old index
 
	// Old Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nOldIndex;			

	// new index
 
	// New Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nNewIndex;			

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;			
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOSizeCenterSpotAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOSizeCenterSpotAction::GetShape()
{
	return m_pShape;
}


#endif // !defined(AFC_FOSIZESPOTACTION_H__084B4B32_BBEF_11D5_A47A_525400EA266C__INCLUDED_)
