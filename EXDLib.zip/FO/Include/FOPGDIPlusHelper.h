//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPGDIPLUSHELPER_H__4A491B47_B259_4438_AD44_4664EDF58F14__INCLUDED_)
#define AFC_FOPGDIPLUSHELPER_H__4A491B47_B259_4438_AD44_4664EDF58F14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include <atlbase.h>        // for the ATL string transfer
#include <wchar.h>			// for WCHAR

using namespace Gdiplus;

//////////////////////////////////////////////////////////////////
// HokGdiPlusG

 
//===========================================================================
// Summary:
//      To use a HokGdiPlusG object, just call the constructor.
//      Hok Gdi Plus G
//===========================================================================

class HokGdiPlusG
{
public:
 
	// Mode, This member specify SmoothingMode object.  
	 static SmoothingMode m_smoothingMode;
};


//////////////////////////////////////////////////////////////////
// FOPHokPenStyle -- pen style of the gdiplus

 
//===========================================================================
// Summary:
//      To use a FOPHokPenStyle object, just call the constructor.
//      O P Hok Pen Style
//===========================================================================

class FOPHokPenStyle
{
public:
	// Constructor.
	// penColor -- color of the pen.
	// penWidth -- width of the pen.
	// penDashStyle -- pen dash style
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Hok Pen Style, Constructs a FOPHokPenStyle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		penColor---penColor, Specifies a Color penColor = Color(0 object(Value).  
	//		0---Specifies a 0 object(Value).  
	//		0)---Specifies a 0) object(Value).  
	//		penWidth---penWidth, Specifies a REAL penWidth = 1.0f object(Value).  
	//		penDashStyle---Dash Style, Specifies a DashStyle penDashStyle = DashStyleSolid object(Value).
	FOPHokPenStyle(Color penColor = Color(0, 0, 0), REAL penWidth = 1.0f,
		DashStyle penDashStyle = DashStyleSolid)
	{
//		m_penColor		= penColor;
		m_penColor		= Color(penColor.GetA(), penColor.GetR(), penColor.GetG(), penColor.GetB());
		m_penWidth		= penWidth;
		m_penDashStyle	= penDashStyle;
	}

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		penStyle---penStyle, Specifies a const FOPHokPenStyle penStyle object(Value).
	BOOL operator==(const FOPHokPenStyle &penStyle) const
	{
		if (penStyle.m_penColor.GetAlpha()	!= m_penColor.GetAlpha()	||
			penStyle.m_penColor.GetRed()	!= m_penColor.GetRed()		||
			penStyle.m_penColor.GetGreen()	!= m_penColor.GetGreen()	||
			penStyle.m_penColor.GetBlue()	!= m_penColor.GetBlue()		||
			penStyle.m_penWidth				!= m_penWidth				||
			penStyle.m_penDashStyle			!= m_penDashStyle)
		{
			return FALSE;
		}
		return TRUE;
	}
	
	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPHokPenStyle& value (Object).  
	// Parameters:
	//		penStyle---penStyle, Specifies a const FOPHokPenStyle& penStyle object(Value).
	FOPHokPenStyle& operator=(const FOPHokPenStyle& penStyle)
	{
//		m_penColor		= penStyle.m_penColor;
		m_penColor		= Color(penStyle.m_penColor.GetA(), penStyle.m_penColor.GetR(), penStyle.m_penColor.GetG(), penStyle.m_penColor.GetB());
		m_penWidth		= penStyle.m_penWidth;
		m_penDashStyle	= penStyle.m_penDashStyle;
		return (*this);
	}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Color, Sets a specify value to current class FOPHokPenStyle
	// Parameters:
	//		&penColor---&penColor, Specifies a const Color &penColor object(Value).
	void SetPenColor(const Color &penColor) 
	{
//		m_penColor = penColor;
		m_penColor = Color(penColor.GetA(), penColor.GetR(), penColor.GetG(), penColor.GetB());
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Color, Returns the specified value.
	//		Returns A Color value (Object).
	Color GetPenColor() {return m_penColor;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPHokPenStyle
	// Parameters:
	//		&penWidth---&penWidth, Specifies a const REAL &penWidth object(Value).
	void SetPenWidth(const REAL &penWidth) {m_penWidth = penWidth;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns A REAL value (Object).
	REAL GetPenWidth() {return m_penWidth;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Style, Sets a specify value to current class FOPHokPenStyle
	// Parameters:
	//		&penDashStyle---Dash Style, Specifies a const DashStyle &penDashStyle object(Value).
	void SetDashStyle(const DashStyle &penDashStyle) {m_penDashStyle = penDashStyle;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Style, Returns the specified value.
	//		Returns A DashStyle value (Object).
	DashStyle GetDashStyle() {return m_penDashStyle;}

private:
	//	Color of the pen.
 
	// Color, This member specify Color object.  
	Color m_penColor;
	
	//	width of the pen
 
	// Width, This member specify REAL object.  
	REAL m_penWidth;
	
	//	Pen dash style
 
	// Dash Style, This member specify DashStyle object.  
	DashStyle m_penDashStyle;
};


//////////////////////////////////////////////////////////////////
// FOPHokPen -- pen object of GDI plus.

 
//===========================================================================
// Summary:
//      To use a FOPHokPen object, just call the constructor.
//      O P Hok Pen
//===========================================================================

class FOPHokPen
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Hok Pen, Constructs a FOPHokPen object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pPen---pPen, A pointer to the Pen or NULL if the call failed.
	FOPHokPen(Pen* pPen = NULL)
	{
		m_pPen = pPen;
	}

public:
	// Style of pen
 
	// Style, This member specify FOPHokPenStyle object.  
	FOPHokPenStyle m_penStyle;

	// Pointer of pen object/
 
	// Pen, This member maintains a pointer to the object Pen.  
	Pen* m_pPen;
};

typedef CList<FOPHokPen*, FOPHokPen*> CFOPHokBasePenList;


//////////////////////////////////////////////////////////////////
// CFOPHokPenCache -- pen objects list.

 
//===========================================================================
// Summary:
//     The CFOPHokPenCache class derived from CFOPHokBasePenList
//      F O P Hok Pen Cache
//===========================================================================

class CFOPHokPenCache : public CFOPHokBasePenList
{
protected:
	//	Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hok Pen Cache, Constructs a CFOPHokPenCache object.
	//		Returns A  value (Object).
	CFOPHokPenCache();

	//	Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hok Pen Cache, Destructor of class CFOPHokPenCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHokPenCache();

public:
	//	Return a pointer to the instance of a pen cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPHokPenCache,or NULL if the call failed
	static CFOPHokPenCache* GetInstance();

	//	Destory instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destory Instance, .
	// This member function is a static function.
	static void DestoryInstance();

	//	Find a Pen by data
	// HokPenStyle -- pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Pen, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object Pen,or NULL if the call failed  
	// Parameters:
	//		HokPenStyle---Hok Pen Style, Specifies a FOPHokPenStyle& HokPenStyle object(Value).
	Pen* FindPen(FOPHokPenStyle& HokPenStyle);

	//	Create a new Pen
	// HokPenStyle -- pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pen, You construct a CFOPHokPenCache object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object Pen,or NULL if the call failed  
	// Parameters:
	//		HokPenStyle---Hok Pen Style, Specifies a FOPHokPenStyle& HokPenStyle object(Value).
	Pen* CreatePen(FOPHokPenStyle& HokPenStyle);

	//  Create a pen by a GDI pen
	// pPen -- pointer of the object for searching.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen, Returns the specified value.
	//		Returns a pointer to the object Pen,or NULL if the call failed  
	// Parameters:
	//		pPen---pPen, A pointer to the CPen  or NULL if the call failed.  
	//		&nA---&nA, Specifies An 8-bit BYTE integer that is not signed.
	Pen* GetPen(CPen * pPen, const BYTE &nA = 255);

protected:
	//	A pointer to the one instance of the pen cache
 
	// Pen Cache, This member maintains a pointer to the object CFOPHokPenCache.  
	static CFOPHokPenCache* m_psPenCache;

	// Dash style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Style By Arr, Returns the specified value.
	// This member function is a static function.
	//		Returns A DashStyle value (Object).  
	// Parameters:
	//		*pArr---*pArr, A pointer to the REAL  or NULL if the call failed.  
	//		nSize---nSize, Specifies A integer value.
	static DashStyle GetDashStyleByArr(REAL *pArr, int nSize);
};


//////////////////////////////////////////////////////////////////
// FOPHokBrushStyle -- brush style of gdi plus brush object

 
//===========================================================================
// Summary:
//      To use a FOPHokBrushStyle object, just call the constructor.
//      O P Hok Brush Style
//===========================================================================

class FOPHokBrushStyle 
{
public:
	// Constructor.
	// nBrushType -- brush type.
	// FirColor -- first color.
	// SecColor -- second color,mostly it is the pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Hok Brush Style, Constructs a FOPHokBrushStyle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nBrushType---Brush Type, Specifies A integer value.  
	//		firColor---firColor, Specifies a Color firColor = Color(0 object(Value).  
	//		0---Specifies a 0 object(Value).  
	//		0)---Specifies a 0) object(Value).  
	//		secColor---secColor, Specifies a Color secColor = Color(255 object(Value).  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	FOPHokBrushStyle(int nBrushType = -1, Color firColor = Color(0, 0, 0), Color secColor = Color(255, 255, 255))
	{
		m_nBrushType = nBrushType;
//		m_FirColor	= SecColor;
//		m_SecColor	= FirColor;
		m_FirColor = Color(firColor.GetA(), firColor.GetR(), firColor.GetG(), firColor.GetB());
		m_SecColor = Color(secColor.GetA(), secColor.GetR(), secColor.GetG(), secColor.GetB());
	}

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		brushStyle---brushStyle, Specifies a const FOPHokBrushStyle brushStyle object(Value).
	BOOL operator==(const FOPHokBrushStyle &brushStyle) const
	{
		if (brushStyle.m_nBrushType		   != m_nBrushType			||
			brushStyle.m_FirColor.GetAlpha()!= m_FirColor.GetAlpha()||
			brushStyle.m_FirColor.GetRed()  != m_FirColor.GetRed()	||
			brushStyle.m_FirColor.GetGreen()!= m_FirColor.GetGreen()||
			brushStyle.m_FirColor.GetBlue() != m_FirColor.GetBlue() ||

			brushStyle.m_SecColor.GetAlpha()!= m_SecColor.GetAlpha()||
			brushStyle.m_SecColor.GetRed()  != m_SecColor.GetRed()	||
			brushStyle.m_SecColor.GetGreen()!= m_SecColor.GetGreen()||
			brushStyle.m_SecColor.GetBlue() != m_SecColor.GetBlue()	)
			{
				return FALSE;
			}
		return TRUE;
	}
	
	// Operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPHokBrushStyle& value (Object).  
	// Parameters:
	//		brushStyle---brushStyle, Specifies a const FOPHokBrushStyle& brushStyle object(Value).
	FOPHokBrushStyle& operator=(const FOPHokBrushStyle& brushStyle)
	{
		m_nBrushType = brushStyle.m_nBrushType;
//		m_FirColor	= brushStyle.m_FirColor;
//		m_SecColor	= brushStyle.m_SecColor;
		m_FirColor = Color(brushStyle.m_FirColor.GetA(), brushStyle.m_FirColor.GetR(), brushStyle.m_FirColor.GetG(), brushStyle.m_FirColor.GetB());
		m_SecColor = Color(brushStyle.m_SecColor.GetA(), brushStyle.m_SecColor.GetR(), brushStyle.m_SecColor.GetG(), brushStyle.m_SecColor.GetB());
		return (*this);
	}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fir Color, Sets a specify value to current class FOPHokBrushStyle
	// Parameters:
	//		&firColor---&firColor, Specifies a const Color &firColor object(Value).
	void SetFirColor(const Color &firColor)
	{
//		m_FirColor = firColor;
		m_FirColor = Color(firColor.GetA(), firColor.GetR(), firColor.GetG(), firColor.GetB());
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fir Color, Returns the specified value.
	//		Returns A Color value (Object).
	Color GetFirColor() {return m_FirColor;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sec Color, Sets a specify value to current class FOPHokBrushStyle
	// Parameters:
	//		&secColor---&secColor, Specifies a const Color &secColor object(Value).
	void SetSecColor(const Color &secColor) 
	{
//		m_SecColor = secColor;
		m_SecColor = Color(secColor.GetA(), secColor.GetR(), secColor.GetG(), secColor.GetB());
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sec Color, Returns the specified value.
	//		Returns A Color value (Object).
	Color GetSecColor() {return m_SecColor;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class FOPHokBrushStyle
	// Parameters:
	//		&nBrushType---Brush Type, Specifies A integer value.
	void SetBrushType(const int &nBrushType) {m_nBrushType = nBrushType;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int GetBrushType() {return m_nBrushType;}

private:
	// Type of brush.
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;
	
	//	First color for gradient.
 
	// Fir Color, This member specify Color object.  
	Color m_FirColor;
	
	//	Second color for gradient
 
	// Sec Color, This member specify Color object.  
	Color m_SecColor;
};


//////////////////////////////////////////////////////////////////
// FOPHokBrush -- gdi plus brush object

 
//===========================================================================
// Summary:
//      To use a FOPHokBrush object, just call the constructor.
//      O P Hok Brush
//===========================================================================

class FOPHokBrush
{
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Hok Brush, Constructs a FOPHokBrush object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBrush---pBrush, A pointer to the Brush or NULL if the call failed.
	FOPHokBrush(Brush* pBrush = NULL)
	{
		m_pBrush = pBrush;
	}

public:

	// Style of the brush
 
	// Style, This member specify FOPHokBrushStyle object.  
	FOPHokBrushStyle m_brushStyle;

	// Pointer of the brush object.
 
	// Brush, This member maintains a pointer to the object Brush.  
	Brush* m_pBrush;
};

typedef CList<FOPHokBrush*, FOPHokBrush*> CHokBaseBrushList;


//////////////////////////////////////////////////////////////////
// CHokBaseBrushList -- brush objects list.

 
//===========================================================================
// Summary:
//     The CFOPHokBrushCache class derived from CHokBaseBrushList
//      F O P Hok Brush Cache
//===========================================================================

class CFOPHokBrushCache : public CHokBaseBrushList
{
protected:
	//	Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hok Brush Cache, Constructs a CFOPHokBrushCache object.
	//		Returns A  value (Object).
	CFOPHokBrushCache();

	//	Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hok Brush Cache, Destructor of class CFOPHokBrushCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHokBrushCache();

public:
	//	Find a Brush by data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Brush, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object Brush,or NULL if the call failed  
	// Parameters:
	//		&brushStyle---&brushStyle, Specifies a FOPHokBrushStyle &brushStyle object(Value).
	Brush* FindBrush(FOPHokBrushStyle &brushStyle);

	//	Create a new Brush
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOPHokBrushCache object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object Brush,or NULL if the call failed  
	// Parameters:
	//		&brushStyle---&brushStyle, Specifies a FOPHokBrushStyle &brushStyle object(Value).
	Brush* CreateBrush(FOPHokBrushStyle &brushStyle);

	//	Get Prop by Brush
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style, Returns the specified value.
	//		Returns A FOPHokBrushStyle value (Object).  
	// Parameters:
	//		*pBrush---*pBrush, A pointer to the Brush  or NULL if the call failed.
	FOPHokBrushStyle GetStyle(Brush *pBrush);

	//	Return a pointer to the instance of a Brush cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPHokBrushCache,or NULL if the call failed
	static CFOPHokBrushCache* GetInstance();

	//	Destory instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destory Instance, .
	// This member function is a static function.
	static void DestoryInstance();

	//  Create a brush
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object Brush,or NULL if the call failed  
	// Parameters:
	//		nFillType---Fill Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		0---Specifies a 0 object(Value).  
	//		0)---Specifies a 0) object(Value).  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		0---Specifies a 0 object(Value).  
	//		0)---Specifies a 0) object(Value).  
	//		&nAStart---A Start, Specifies An 8-bit BYTE integer that is not signed.  
	//		&nAEnd---A End, Specifies An 8-bit BYTE integer that is not signed.
	Brush* GetBrush(UINT nFillType, COLORREF crStart = RGB(0,0,0), COLORREF crEnd = RGB(0,0,0), const BYTE &nAStart = 255, const BYTE &nAEnd = 255);

protected:
	//	A pointer to the one instance of the Brush cache
 
	// Brush Cache, This member maintains a pointer to the object CFOPHokBrushCache.  
	static CFOPHokBrushCache* m_psBrushCache;

public:

	// Create gradient brush with type.
	// nBrTypeIn -- gradient type.
	// crStartIn -- first color of the gradient.
	// crEndIn -- second color of the gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Gradient Brush, You construct a CFOPHokBrushCache object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object Brush,or NULL if the call failed  
	// Parameters:
	//		nBrTypeIn---Br Type In, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		crStartIn---Start In, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEndIn---End In, Specifies A 32-bit COLORREF value used as a color value.  
	//		rcIn---rcIn, Specifies A CRect type value.  
	//		&nAStart---A Start, Specifies An 8-bit BYTE integer that is not signed.  
	//		&nAEnd---A End, Specifies An 8-bit BYTE integer that is not signed.
	static Brush* CreateGradientBrush(UINT nBrTypeIn, COLORREF crStartIn, COLORREF crEndIn, CRect rcIn, const BYTE &nAStart = 255, const BYTE &nAEnd = 255);
};


//////////////////////////////////////////////////////////////////
// FOPHokFontStyle -- style of the font

 
//===========================================================================
// Summary:
//      To use a FOPHokFontStyle object, just call the constructor.
//      O P Hok Font Style
//===========================================================================

class FOPHokFontStyle
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Hok Font Style, Constructs a FOPHokFontStyle object.
	//		Returns A  value (Object).
	FOPHokFontStyle()
	{
		m_fHeight = 0;
		m_strFaceName = _T("");
		m_FontStyle = FontStyleRegular;
	}

	// Operator == 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		fontStyle---fontStyle, Specifies a const FOPHokFontStyle fontStyle object(Value).
	BOOL operator==(const FOPHokFontStyle &fontStyle) const
	{
		if (fontStyle.m_fHeight		!= m_fHeight   ||
			fontStyle.m_FontStyle	!= m_FontStyle ||
			fontStyle.m_strFaceName	!= m_strFaceName)
		{
			return FALSE;
		}

		return TRUE;
	}

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPHokFontStyle& value (Object).  
	// Parameters:
	//		fontStyle---fontStyle, Specifies a const FOPHokFontStyle& fontStyle object(Value).
	FOPHokFontStyle& operator=(const FOPHokFontStyle& fontStyle)
	{
		m_fHeight		= fontStyle.m_fHeight;
		m_strFaceName   = fontStyle.m_strFaceName;
		m_FontStyle		= fontStyle.m_FontStyle;
		return (*this);
	}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class FOPHokFontStyle
	// Parameters:
	//		&fHeight---&fHeight, Specifies a const REAL &fHeight object(Value).
	void SetHeight(const REAL &fHeight) {m_fHeight = fHeight;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns A REAL value (Object).
	REAL GetHeight() {return m_fHeight;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class FOPHokFontStyle
	// Parameters:
	//		&strFaceName---Face Name, Specifies A CString type value.
	void SetFaceName(const CString &strFaceName) {m_strFaceName = strFaceName;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetFaceName() {return m_strFaceName;}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Style, Sets a specify value to current class FOPHokFontStyle
	// Parameters:
	//		&fontStyle---&fontStyle, Specifies a const FontStyle &fontStyle object(Value).
	void SetFontStyle(const FontStyle &fontStyle) {m_FontStyle = fontStyle;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Style, Returns the specified value.
	//		Returns A FontStyle value (Object).
	FontStyle GetFontStyle() {return m_FontStyle;}

private:
	// Height of the font
 
	// Height, This member specify REAL object.  
	REAL	m_fHeight;
	
	// Face name of the font
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strFaceName;
	
	// Style of the font
 
	// Font Style, This member specify FontStyle object.  
	FontStyle m_FontStyle;
};


//////////////////////////////////////////////////////////////////
// FOPHokFont -- font object of GDI plus.

 
//===========================================================================
// Summary:
//      To use a FOPHokFont object, just call the constructor.
//      O P Hok Font
//===========================================================================

class FOPHokFont
{
public:

	// Constructor.
	FOPHokFont(Gdiplus::Font* pFont = NULL)
	{
		m_pFont = pFont;
	}

public:

	// Font style
 
	// Style, This member specify FOPHokFontStyle object.  
	FOPHokFontStyle m_fontStyle;

	// Pointer of the font object
	Gdiplus::Font* m_pFont;
};

typedef CList<FOPHokFont*, FOPHokFont*> CHokBaseFontList;


//////////////////////////////////////////////////////////////////
// CFOPHokFontCache -- list of font objects.

 
//===========================================================================
// Summary:
//     The CFOPHokFontCache class derived from CHokBaseFontList
//      F O P Hok Font Cache
//===========================================================================

class CFOPHokFontCache : public CHokBaseFontList
{
protected:
	//	Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hok Font Cache, Constructs a CFOPHokFontCache object.
	//		Returns A  value (Object).
	CFOPHokFontCache();
	
	//	Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hok Font Cache, Destructor of class CFOPHokFontCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHokFontCache();

public:
	//	Find a Font by data
	Gdiplus::Font* FindFont(FOPHokFontStyle &fontStyle, CDC *pDC);
	
	//	Create a new Font
	Gdiplus::Font* CreateFont(FOPHokFontStyle &fontStyle, CDC *pDC);
	
	//	Create a new Font
	FOPHokFontStyle GetStyle(Gdiplus::Font* pFont);
	
	//	Return a pointer to the instance of a Font cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Instance, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CFOPHokFontCache,or NULL if the call failed
	static CFOPHokFontCache* GetInstance();
	
	//	Destory instance
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destory Instance, .
	// This member function is a static function.
	static void DestoryInstance();
	
	//  Create a Font
	Gdiplus::Font* GetFont(CFont *pFont, CDC *pDC);

protected:

	//	A pointer to the one instance of the Font cache
 
	// Font Cache, This member maintains a pointer to the object CFOPHokFontCache.  
	static CFOPHokFontCache* m_psFontCache;
};

class FOPGDIPlusHelper
{
public:
	FOPGDIPlusHelper();
	~FOPGDIPlusHelper();

public:
	static void NormRect(Gdiplus::RectF& rect);
	static Gdiplus::Color XGColor(BYTE r, BYTE g, BYTE b, BYTE a);
	static Gdiplus::Color FXColor(COLORREF clr, BYTE a);
};

#endif // !defined(AFC_FOPGDIPLUSHELPER_H__4A491B47_B259_4438_AD44_4664EDF58F14__INCLUDED_)
