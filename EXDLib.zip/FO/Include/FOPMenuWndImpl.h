//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPMENUWNDIMPL_H__A5052B13_6B85_477D_8158_D5AAF1050DE7__INCLUDED_)
#define AFX_FOPMENUWNDIMPL_H__A5052B13_6B85_477D_8158_D5AAF1050DE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPMenuWndImpl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWnd window
#include <afxtempl.h>

//////////////////////////////////////////////////////////////////////
// CFOPMenuBaseWnd is a CWnd derived class.  It is used to hook a CWnd object
// in order to intercept and act upon window messages that are received.
//

class CFOPWindowMap;
class FO_EXT_CLASS CFOPMenuBaseWnd : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMenuBaseWnd---F O P Window Hook, Specifies a E-XD++ CFOPMenuBaseWnd object (Value).
    DECLARE_DYNAMIC(CFOPMenuBaseWnd)

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Window Hook, Constructs a CFOPMenuBaseWnd object.
	//		Returns A  value (Object).
    // Constructs a CFOPMenuBaseWnd object.
    //
    CFOPMenuBaseWnd();

	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Window Hook, Destructor of class CFOPMenuBaseWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPMenuBaseWnd();
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Install Window, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
    virtual BOOL InstallWnd(CWnd* pWnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Install Window, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hWnd---hWnd, Specifies a HWND hWnd object(Value).
    virtual BOOL InstallWnd(HWND hWnd);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
    // This member function provides a Windows procedure (WindowProc) for
	// a CFOPMenuBaseWnd object.  It dispatches messages through the window's message
	// map. Returns an LRESULT value. The return value depends on the message.
    //
    virtual LRESULT WindowProc(UINT message,WPARAM wParam,LPARAM lParam);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Default, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.
    // This member function calls the default window procedure.  The default
	// window procedure provides default processing for any window message
	// that an application does not process.  This member function ensures
	// that every message is processed. Returns an LRESULT value. The return
	// value depends on the message.
    //
    LRESULT Default();

public:
	
	BOOL m_bUnicode;
	// This member specify class object.  
	class Private;
	
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
	
	// F O P Window Map, This member specify friend class object.  
    friend class CFOPWindowMap;

};

class CFOPMenuTheme;
//////////////////////////////////////////////////////////////////////

class FO_EXT_CLASS CFOPPopupMenu : public CFOPMenuBaseWnd
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// F O P Popup Menu, Constructs a CFOPPopupMenu object.
	//		Returns A  value (Object).
	CFOPPopupMenu();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Popup Menu, Destructor of class CFOPPopupMenu
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPopupMenu();

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Window, Returns the specified value.
	//		Returns A HWND value (Object).
	HWND GetHWnd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Menu, Returns the specified value.
	//		Returns A HMENU value (Object).
	HMENU GetHMenu();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void MethodTempx4(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	void MethodTempx3();

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		*pParent---*pParent, A pointer to the CFOPMenuTheme  or NULL if the call failed.
	void MethodTempx2(CFOPMenuTheme *pParent);
	
	//-----------------------------------------------------------------------
	// Summary:
	void MethodTempx1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		hMenu---hMenu, Specifies a HMENU hMenu object(Value).
	void MethodTempx5(HMENU hMenu);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
 
public:
	// This member sets TRUE if it is right.  
	static BOOL      m_bWithProp1;
	
	// This member sets TRUE if it is right.  
	static BOOL      m_bWithProp2;
	
	// This member sets TRUE if it is right.  
	static BOOL      m_bWithProp3;
	
	// Reference Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int       m_iRefCount;

public:
	
	// This member specify class object.  
	class MyPrivate;
	
	// This member maintains a pointer to the object Private.  
    MyPrivate * const m_md;

};
 
typedef CList<CFOPPopupMenu*, CFOPPopupMenu*&> CFOPPopupMenuList;
//////////////////////////////////////////////////////////////////////
// CFOPMenuTheme is a CFOPMenuBaseWnd derived class.  CFOPMenuTheme manages the
//===========================================================================

class FO_EXT_CLASS CFOPMenuTheme : public CFOPMenuBaseWnd
{
 
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMenuTheme---F O P Menu Theme, Specifies a E-XD++ CFOPMenuTheme object (Value).
    DECLARE_DYNAMIC(CFOPMenuTheme)

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Menu Theme, Constructs a CFOPMenuTheme object.
	//		Returns A  value (Object).  
	// Parameters:
	//		bWith---Specifies A Boolean value.
    // Constructs a CFOPMenuTheme object.
    //
    CFOPMenuTheme(BOOL bWith = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Menu Theme, Destructor of class CFOPMenuTheme
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPMenuTheme();

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Create Menu Font, You construct a CFOPMenuTheme object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Menu Font, You construct a CFOPMenuTheme object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  CreateMenuFont();

	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Menu Font, You construct a CFOPMenuTheme object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Menu Font, You construct a CFOPMenuTheme object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  CreateDefaultMenuFont();

	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Font, Returns the specified value.
	//		Returns A HFONT value (Object).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed
	CFont* GetMenuFont();

	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Menu Font, Returns the specified value.
	//		Returns A HFONT value (Object).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Menu Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed
	CFont* GetDefaultMenuFont();
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// This member function is a static function.
    static void UnAttachNow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is a static function.
    static void AttachNow();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is a static function.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		nCode---nCode, Specifies A integer value.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
    static LRESULT CALLBACK Plugin(int nCode, WPARAM wParam, LPARAM lParam);
	


	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		nID---Command I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual int MethodTempx18(CMenu* pObj, UINT nID);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tool Bar Resource, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---Toolbar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bEnable---bEnable, Specifies A Boolean value.
    virtual BOOL InsertToolBarRes(UINT nID, BOOL bEnable = TRUE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		nPos---nPos, Specifies A integer value.
	BOOL MethodTempx6(CMenu* pObj, int nPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		nPos---nPos, Specifies A integer value.
    virtual BOOL MethodTempx7(CMenu* pObj, int nPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		nPos---nPos, Specifies A integer value.
    virtual BOOL MethodTempx8(CMenu* pObj, int nPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		hdx---hdx, Specifies a HMENU hMenu object(Value).  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL MethodTempx9(HMENU hdx, UINT nPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Is System Menu, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.
    virtual BOOL MethodTempx10(CMenu* pObj);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.
    virtual BOOL MethodTempx11(CMenu* pObj);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.
    virtual void MethodTempx12(CMenu* pObj);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.
    virtual BOOL MethodTempx17(CMenu* pObj);
 
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Draw Menu Text, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---Specifies A CRect type value.  
	//		str---str, Specifies A CString type value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
    virtual void DoDrawMenuText(CDC* pDC, CRect rcPos, CString str, COLORREF crColor);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw Check box, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bHas---bHas, Specifies A Boolean value.  
	//		bColor---bColor, Specifies A Boolean value.  
	//		bitx---bitx, Specifies a HBITMAP hbmCheck object(Value).
    virtual void DoDrawCheck(CDC* pDC, const CRect& rc, BOOL bHas, BOOL bColor, HBITMAP bitx);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw state, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcItem---rcItem, Specifies A CRect type value.  
	//		bHas---bHas, Specifies A Boolean value.
    virtual void DoDrawSelect(CDC* pDC, CRect rcItem, BOOL bHas);

	//-----------------------------------------------------------------------
	// Summary:
	// Add Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIdx---nIdx, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL AddMenuItem(UINT nIdx);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nIdx---nIdx, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL MethodTempx16(UINT nIdx);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		bHas---Has, Specifies A Boolean value.
    virtual void MethodTempx15(CMenu* pObj, BOOL bHas);
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID--- I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL MethodTempx14( UINT nID);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		hMenu---hMenu, Specifies a HMENU hMenu object(Value).  
	//		nIdx---nIdx, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nId---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    virtual BOOL MethodTempx13(HMENU hDl, UINT nIdx, UINT nId);
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is a static function.
	// Parameters:
	//		hWnd---hWnd, Specifies a HWND hWnd object(Value).
    static void DetachWnd(HWND hWnd);

	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pObj---pObj, A pointer to the CMenu or NULL if the call failed.  
	//		bTemp---bTemp, Specifies A Boolean value.
    virtual BOOL UpdateSelect(CMenu* pObj, BOOL bTemp);

	
    //{{AFX_VIRTUAL(CFOPMenuTheme)
	virtual LRESULT OnMenuChar(UINT nChar, UINT nFlags, CMenu* pObj);
    virtual void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
    virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void OnMenuTimer(int nIDEvent);
    virtual void OnInitMenuPopup(CMenu* pObj, UINT nIndex, BOOL bSysMenu);
	virtual BOOL OnMeasureItem(LPMEASUREITEMSTRUCT lpms);
	virtual BOOL OnDrawItem(LPDRAWITEMSTRUCT lpds);
    virtual void Destroy();
    virtual void OnSetChanged();
	
    //}}AFX_VIRTUAL

public:
	static CSize			m_szSize1; 
	static CSize			m_szSize2; 
	static BOOL				m_bWithProp1;
	CRect					m_aTempValue5;
	CPoint					m_ptValue1;
	CPoint					m_aTempValue4;
	int						m_aTempValue3;
	CSize					m_aTempValue2;
	CSize					m_aTempValue1;
	static CFOPPopupMenuList m_lstMenu1;
	static HMENU			m_Handle1;
    static HHOOK			m_hPlugin;
public:
	CSize					m_szValue1;
	CPoint					m_szValue2;
	CSize					m_szValue3;
	CSize					m_szValue4;
	static BOOL				m_bWithProp5;
	static BOOL				m_bWithProp6;
	static CFOPPopupMenu*	m_pDataNew1;
	static CRect			m_rcRect;
	static long				m_number1;
	DWORD					m_dwValue1;
	static BOOL				m_bValue1;
	static BOOL				m_bWithProp2;
	static BOOL				m_bWithProp3;
	static BOOL				m_bWithProp4;  
	double					m_dValue1;
	double					m_dValue2;
	DWORD					m_dwValue2;
	static long				m_number2;
	static long				m_number3;
    static long				m_number4;
	
protected:
	// This member specify class object.  
	class MyPrivate;
	
	// This member maintains a pointer to the object Private.  
    MyPrivate * const m_md;
	
	// F O P Popup Menu, This member specify friend class object.  
    friend class CFOPPopupMenu;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPItemImageManager

#define FOP_SAFE_DELETE(p)  if(p) { delete p; p = NULL; }
const COLORREF crFOBack = RGB(102,102,102);

// CFOPImage is an internal stand alone class. 
//
class FO_EXT_CLASS CFOPImage
{
	//:Ignore
	friend class CFOPMenuDrawMgr;
	friend class CFOToolBarDrawMgr;
	friend class CFOPImageMap;
	
private:
	CFOPImage();
	~CFOPImage();
	
public:
	CImageList *m_pImageList;
	CImageList *m_pImageDisable;
	int m_nIndex;
public:
	HICON GetIcon() { return m_hIcon; }
	HICON GetDisabledIcon() { return m_hDisabled;	}
	
	
public:
	HICON m_hIcon;
	HICON m_hDisabled;
	int m_nDisable;
	
private:
	void InitBimaps(CImageList* imageList, int nIndex);
	
	void CreateFadedIcon();	
	//	void CreateShadowIcon();
	
	void Clear(BOOL bIcon = FALSE);
	COLORREF LightenColor(COLORREF clr, double factor);
};

 
//===========================================================================
// Summary:
//     The CFOPItemImageManager class derived from CObject
//      F O P Item Image Manager
//===========================================================================

class FO_EXT_CLASS CFOPItemImageManager : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPItemImageManager---F O P Item Image Manager, Specifies a E-XD++ CFOPItemImageManager object (Value).
	DECLARE_DYNAMIC(CFOPItemImageManager)
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Item Image Manager, Constructs a CFOPItemImageManager object.
	//		Returns A  value (Object).
	CFOPItemImageManager();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Item Image Manager, Destructor of class CFOPItemImageManager
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPItemImageManager();

public:

	// Bitmap item.
	struct FOImageItemData
	{
		// Image data ID
		UINT m_nIndImageData;

		// Bitmap offset ID.
		UINT m_nBmpOffset;
	};

public:

	// Add reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Reference, Adds an object to the specify list.

	void AddRef();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Release, .

	// Release.
	void Release();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Add Image Data, Adds an object to the specify list.
	// Parameters:
	//		pData---pData, A pointer to the CFOPImageData  or NULL if the call failed.  
	//		arIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void AddImageData(const UINT* arIDArray, UINT nIDCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tool Bar Resource, Inserts a child object at the given index..
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszSmall---lpszSmall, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszLarge---lpszLarge, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bSysColor---System Color, Specifies A Boolean value.
	BOOL InsertToolBarRes(LPCTSTR lpszSmall, UINT nIDSmall, 
		BOOL bSysColor = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tool Bar Resource, Inserts a child object at the given index..
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDSmall---I D Small, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDLarge---I D Large, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysColor---System Color, Specifies A Boolean value.
	BOOL InsertToolBarRes(UINT nIDSmall, BOOL bSysColor = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Insert Bitmap Resource, Inserts a child object at the given index..
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszSmall---lpszSmall, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszLarge---lpszLarge, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		arIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysColor---System Color, Specifies A Boolean value.
	BOOL InsertBmpRes(LPCTSTR lpszSmall, LPCTSTR lpszLarge, const UINT* arIDArray,
		UINT nIDCount, BOOL bSysColor = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Item, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		hBitmap---hBitmap, Specifies a HBITMAP& hBitmap object(Value).  
	//		nIndex---nIndex, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bAlwaysSmall---Always Small, Specifies A Boolean value.
	CFOPImage* GetItem(UINT nID, UINT& nIndex, 
		BOOL bAlwaysSmall = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Small Width, Returns the specified value.
	//		Returns a int type value.
	int  GetSmallWidth() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Small Height, Returns the specified value.
	//		Returns a int type value.
	int  GetSmallHeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Item Width, Returns the specified value.
	//		Returns a int type value.
	int  GetImageItemWidth() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Item Height, Returns the specified value.
	//		Returns a int type value.
	int  GetImageItemHeight() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Load Toolbar Data, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResourceName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		pBmpItems---Bitmap Items, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nBmpItems---Bitmap Items, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		bSeparators---bSeparators, Specifies A Boolean value.
	BOOL InsertToolBarResData(LPCTSTR lpszResourceName, UINT* & pBmpItems, 
		UINT& nBmpItems,int& nWidth, int& nHeight, BOOL bSeparators = FALSE);

public:
	
	// Menu item maps
	CMap<UINT, UINT, FOImageItemData *, FOImageItemData *> m_mapItem;

	// Small icon width.
 
	// Small Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSmallWidth;

	// Small icon height.
 
	// Small Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSmallHeight;

	// ID of reference.
 
	// Reference, Specify a A 32-bit signed integer.  
	ULONG		m_nRef;
};

/////////////////////////////////////////////////////////////////////////////
class FO_EXT_CLASS CFOPMenuDialog : public CDialog
{
	DECLARE_DYNCREATE(CFOPMenuDialog)
		
public:
	CFOPMenuDialog();
	CFOPMenuDialog(const UINT nID, CWnd* pParent = 0, const UINT nFlags = 0);
	CFOPMenuDialog(LPCTSTR lpszTemplateName, CWnd* pParent = 0, const UINT nFlags = 0);
		
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nID);
	
protected:
	
	DECLARE_MESSAGE_MAP()
		
	//{{AFX_MSG(CFOPMenuDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	
protected:
	UINT m_nDialogID;
	
};

class FO_EXT_CLASS CFOPExtTreeCtrl : public CTreeCtrl
{
	DECLARE_DYNAMIC(CFOPExtTreeCtrl)
		
		// Construction
public:
	CFOPExtTreeCtrl();
	
	// Attributes
public:
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	

	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nID);
	
	// Operations
public:
	
	// Overrides
public:
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtTreeCtrl)
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	virtual ~CFOPExtTreeCtrl();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtTreeCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	
	DECLARE_MESSAGE_MAP()
		
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPMENUWNDIMPL_H__A5052B13_6B85_477D_8158_D5AAF1050DE7__INCLUDED_)
