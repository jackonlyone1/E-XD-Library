//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMultiPageModelManager.h: interface for the CFOMultiPageModelManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMULTIPAGEMODELMANAGER_H__18CF5275_F709_11DD_A43D_525400EA266C__INCLUDED_)
#define AFX_FOMULTIPAGEMODELMANAGER_H__18CF5275_F709_11DD_A43D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOMultiPageModel.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOMultiPageModelManager
//
// This class is defined for Multiple Pages style application,see sample CustomMSample.
// it is the manager of the Multiple Pages.
//
// Call AddNewModel for adding new model.
// 
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOMultiPageModelManager class derived from CObject
//      F O Multiple Page Model Manager
//===========================================================================

class FO_EXT_CLASS CFOMultiPageModelManager : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiPageModelManager---F O Multiple Page Model Manager, Specifies a E-XD++ CFOMultiPageModelManager object (Value).
	DECLARE_SERIAL(CFOMultiPageModelManager);
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page Model Manager, Constructs a CFOMultiPageModelManager object.
	//		Returns A  value (Object).
	CFOMultiPageModelManager();

	//-----------------------------------------------------------------------
	// Summary:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Page Model Manager, Destructor of class CFOMultiPageModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiPageModelManager();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Attach observer wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Observer, Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*---A pointer to the CFOObserver  or NULL if the call failed.
	virtual void AttachObserver( CFOObserver * );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach observer wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*---A pointer to the CFOObserver  or NULL if the call failed.
	virtual void DetachObserver( CFOObserver * );

	//-----------------------------------------------------------------------
	// Summary:
	// Notify observer wnd.
	// lHint -- notify hint.
	// pHint -- notify data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual void NotifyObserver(LPARAM lHint, CObject*pHint = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove all observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Observer, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllObserver();

	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild all the property index of all tab pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild All Property Index, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		RebuildAllPropIndex();

// Attributes
protected:
	
	// Current model pointer.
 
	// Current Model, This member maintains a pointer to the object CFOMultiPageModel.  
	CFOMultiPageModel *m_pCurModel;

public:
	
	// flag of needing rebuild
 
	// Need Rebuild, This member sets TRUE if it is right.  
	BOOL bNeedRebuild;

	// get current model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed
	CFOMultiPageModel*	GetCurrentModel() const;

	// set current model
	// pModel -- pointer of the data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Model, Sets a specify value to current class CFOMultiPageModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.
    virtual void		SetCurrentModel(CFOMultiPageModel *pModel);

	// get mode list 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model List, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelSet ,or NULL if the call failed
	CFOMultiPageModelSet *GetModelList() { return &m_ModelList ;}

	// Clear all data from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		ClearAll();

	// Get count of models.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Count, Returns the specified value.
	//		Returns a int type value.
	int GetModelCount() { return (int)m_ModelList.GetCount(); }

	// Get count of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetShapesCount();

	// add new model
	// strCaption -- label of the data model item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Model, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		strCaption---strCaption, Specifies A CString type value.
	virtual CFOMultiPageModel* AddNewModel(CString strCaption = _T(""));

	// Insert a new model after a specify model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert After, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		*pModelAfter---Model After, A pointer to the CFOMultiPageModel  or NULL if the call failed.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual CFOMultiPageModel* InsertAfter(CFOMultiPageModel *pModelAfter,CString strCaption = _T(""));

	// find mode(ID) a page at
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model With I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPageNumber---Page Number, Specifies A integer value.
	virtual BOOL		FindModelWithID(int nPageNumber);

	// get selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed
	virtual CFOMultiPageModel* GetSelected();

	// Only serialize tabs.
	void SerializeTabs(CArchive &ar);

	// Get the max height of sub items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetMaxHeight();

	// Obtain an unique page number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Page Number, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetUniquePageNumber();

	// find the caption of a model
	// strCap -- caption of the data model that to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual BOOL		FindModelCaption(CString strCap);

	// find the caption of a model,
	// strCap -- caption of the data model that to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model With Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual CFOMultiPageModel*	FindModelWithCaption(CString strCap);

	// Alloc model,new create a data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Model,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed
	virtual CFOMultiPageModel *AllocModel() const;

	// Create an unique caption for the page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Page Caption, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString		GetUniquePageCaption();

	// select model of page with a specify page number.
	// nPageNumber -- number of the data model that will be selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Model, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		nPageNumber---Page Number, Specifies A integer value.
	virtual CFOMultiPageModel* SelectModel(int nPageNumber);

	// Select model with a specify caption of item.
	// strCap -- name of the data model that to be selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Model, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual CFOMultiPageModel* SelectModel(CString strCap);

	// change page model with a specify page number.
	// nPageNumber -- page number of the data model that switch to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPageNumber---Page Number, Specifies A integer value.
	virtual BOOL		ChangeModel(int nPageNumber);

	// Change page model with a specify page caption.
	// strCap -- name of the data model that switch to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual BOOL		ChangeModel(CString strCap);

	// Remove model from the list.
	// pModel -- model to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Model, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	virtual CFOMultiPageModel*	RemoveModel(CFOMultiPageModel *pModel);

	// Move page before other page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Page, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		fromPageName---Page Name, Specifies A CString type value.  
	//		toPageName---Page Name, Specifies A CString type value.  
	//		before---Specifies A Boolean value.
	virtual void MovePage( const CString& fromPageName, const CString& toPageName, BOOL before);

	// Go to the previous model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Goto Do Before Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		GotoPreModel();

	// Go to the next model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Goto Next Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		GotoNextModel();

	// Go to the first model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Goto First Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		GotoFirstModel();

	// Go to the last model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Goto Last Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		GotoLastModel();

	// Goto a specify model.
	// pModel -- pointer of the specify model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Go To Model, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pModel---pModel, A pointer to the CFOMultiPageModel or NULL if the call failed.
	virtual void		GoToModel(CFOMultiPageModel* pModel);

	// update view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update View, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		UpdateView();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified Flag, Sets a specify value to current class CFOMultiPageModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	// SetModifiedflag.
	virtual void		SetModifiedFlag(BOOL bModified = TRUE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// IsModified.
	virtual BOOL		IsModified();

	// decide if first model
	// pModel -- data model to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is First Model, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	virtual BOOL		IsFirstModel(CFOMultiPageModel *pModel);

	// Get model canvas size.
	// iIndex -- specify index of the data model within the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Size, Returns the specified value.
	//		Returns a CSize type value.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	CSize				GetCanvasSize(int iIndex) const;

public:

	// Create a new document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Document, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnNewDocument();

	// Open a document file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Open Document, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOpenDocument();

	// Save document to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Save Document, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnSaveDocument();

	// Clear document data from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Content, Reset the content and clear all the data of this data model.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetContent();

	// Obtain the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Print Pages, Returns the specified value.
	//		Returns a int type value.
	int GetTotalPrintPages() const { return m_nTotalPrintPages; }

	// Change total print pages,this is only defined for creating the output string on the Header or the Footer
	// of the print page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Print Pages, Sets a specify value to current class CFOMultiPageModelManager
	// Parameters:
	//		&nTotal---&nTotal, Specifies A integer value.
	void	SetTotalPrintPages( const int &nTotal)	{ m_nTotalPrintPages = nTotal; }

protected:
	
	// Sub data model list.
 
	// Model List, This member specify E-XD++ CFOMultiPageModelSet object.  
	CFOMultiPageModelSet m_ModelList;

	// The list pointer of parent wnd.
 
	// Observer List, This member specify CPtrList object.  
	CPtrList			m_ObserverList;			

public:

	// Save current document data to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get file pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release file from memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Modified flag.
 
	// Modified, This member sets TRUE if it is right.  
	BOOL		m_bModified;			
	
	// Total print pages.
 
	// Total Print Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTotalPrintPages;

};


#endif // !defined(AFX_FOMULTIPAGEMODELMANAGER_H__18CF5275_F709_11DD_A43D_525400EA266C__INCLUDED_)
