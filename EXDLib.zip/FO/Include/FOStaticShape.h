//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOStaticShape.h: interface for the CFOStaticShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSTATICSHAPE_H__70D7EFC3_F31E_11DD_A436_525400EA266C__1483_INCLUDED_)
#define AFX_FOSTATICSHAPE_H__70D7EFC3_F31E_11DD_A436_525400EA266C__1483_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FODrawPortsShape.h"

////////////////////////////////////////////////////////////////////////////
// CFOStaticShape -- static text shape, text Bullets tools.
//                 ID: FO_COMP_STATIC 2
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOStaticShape class derived from CFODrawPortsShape
//      F O Static Shape
//===========================================================================

class FO_EXT_CLASS CFOStaticShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOStaticShape---F O Static Shape, Specifies a E-XD++ CFOStaticShape object (Value).
	DECLARE_SERIAL(CFOStaticShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Static Shape, Constructs a CFOStaticShape object.
	//		Returns A  value (Object).
	CFOStaticShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Static Shape, Constructs a CFOStaticShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOStaticShape& src object(Value).
	CFOStaticShape(const CFOStaticShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Static Shape, Destructor of class CFOStaticShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOStaticShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOStaticShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the static shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOStaticShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOStaticShape& src object(Value).
	CFOStaticShape& operator=(const CFOStaticShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// shape area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Draw mark.
	// pDC -- pointer of the DC.
	// rcPos -- drawing within.
	// nType -- bullet type,it must be one of the following value:
	// enum FO_BULLETS_TYPE
	// {
	// 	FO_BULLET_NULL = 0,
	// 	FO_BULLET_MAX_ELLIPSE,
	// 	FO_BULLET_FILL_RECTANGLE,
	// 	FO_BULLET_RHOMBUS,
	// 	FO_BULLET_EMPTY_RECTANGLE,
	// 	FO_BULLET_ARROW,
	// 	FO_BULLET_MIN_CIRCLE,
	// 	FO_BULLET_PLUM	
	// };
	// strCustom -- custom symbol.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Bullet, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		strCustom---strCustom, Specifies A CString type value.
	virtual void OnDrawBullet(CDC *pDC,CRect &rcPos,UINT nType,CString strCustom = _T(""));

	// Release pen and brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen And Brush, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleasePenAndBrush();


	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Position shape.
	// rcNewPos -- new position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Offset all points.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

public:

	// Get font metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Metrics, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dxWidth---dxWidth, Specifies A integer value.  
	//		dyHeight---dyHeight, Specifies A integer value.
	virtual void GetFontMetrics(CDC* pDC, int& dxWidth, int& dyHeight);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

public:

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Re calculate extend bound rectangle.
	// rcBound -- bounding rectangle that is generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// CPen
	CPen *GetBulletPen();

	// Get bullet brush.
	CBrush *GetBulletBrush();

protected:

	// Pen of bullet.
 
	// Bullet, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CFOPenObjData		m_penBullet;

	// Brush of bullet.
 
	// Bullet, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CFOBrushObjectData			m_brBullet;

	// Old text color.
 
	// Old Text, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crOldText;

	// Save bulleted type.
 
	// Save Bulleted, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSaveBulleted;

	// Need rebuild pen and brush.
 
	// Need Create, This member sets TRUE if it is right.  
	BOOL			m_bNeedCreate;

};

/////////////////////////////////////////////////////////////////////////////
// Class for digital

class FO_EXT_CLASS FOPNumberDigit
{
protected:
	struct FOPXSegment
	{
		// Constructor.
		FOPXSegment()	{}

		// Constructor.
		FOPXSegment(const FOPXSegment& segment)
		{
			m_arPoints.Copy(segment.m_arPoints);
			m_arPaintPts.Copy(segment.m_arPaintPts);
		}
		
		// Operator =
		FOPXSegment& operator = (const FOPXSegment& segment)
		{
			m_arPoints.Copy(segment.m_arPoints);
			m_arPaintPts.Copy(segment.m_arPaintPts);
			return *this;
		}
		
		// Points.
		FOPointsArray m_arPoints;

		// Draw points
		FOPointsArray m_arPaintPts;
		
		// Create points
		void GenPoints(double scale);

		// Draw
		void Draw(CDC& dc, const COLORREF& br, const FOPRect& rect);

		// Bounds
		FOPRect GetBounds() const;
	};


	// Digital.
	struct FOPXDigit
	{
		// Constructor.
		FOPXDigit()
			: m_dVScale(0.0)
		{
		}

		// Constructor.
		FOPXDigit(const FOPXDigit& digit)
		{
			m_arSegs.Copy(digit.m_arSegs);
			m_rcDot    = digit.m_rcDot;
			m_rcBound = digit.m_rcBound;
			m_dVScale  = digit.m_dVScale;
		}
		
		// segments
		CArray<FOPXSegment, FOPXSegment>	m_arSegs;

		// Dot rectangle.
		FOPRect					m_rcDot;

		// Bounds
		FOPRect					m_rcBound;

		// Scale
		double						m_dVScale;
		

		// Generateo points
		void GenPoints(double scale);


		// Draw segments
		void DrawSegments(CDC& dc, const COLORREF& br, const CString& strSegments, const FOPRect& rect, BOOL bInvert = FALSE);

		// Draw dot
		void DrawDot(CDC& dc, const COLORREF& br, const FOPRect& rect);

		// Initialize
		void Initialize(double skewAngle);

		// Obtain bounds
		FOPRect GetBounds(BOOL bDot) const;
	};
    
    public:
        
        // Constructor.
        FOPNumberDigit();
        
        // Destructor.
        virtual ~FOPNumberDigit();
        
        
        // Create
        virtual void Create (double skewAngle = 0.0) = 0;
        
        
        // Create
        FOPRect CreateDigit(CDC& gm, const FOPRect& rect, BOOL bDot);
        
        // Draw
        void DrawDigit(CDC& gm, const COLORREF& br, TCHAR ch, const FOPRect& rect, double opacityInv = 0.0);
        
        // Draw dot
        void DrawDot(CDC& gm, const COLORREF& br, const FOPRect& rect);
        
        
        // Obtain default size.
        FOPSize GetDefaultSize(CDC& gm, BOOL bDot) const;
        
protected:
        
        // Initialize
        void Initialize(double skewAngle);
        
protected:
        
        // Numbers.
        CArray<FOPXDigit, FOPXDigit>    m_arNumbers;
        
        // Fix numbers
        CArray<FOPXDigit, FOPXDigit>    m_arNumbersFix;
        
        // Number
        int                     m_nNumberX;
};

///////////////////////////////////////////////////////////////
// CFOPSimpleLabelShape -- simple label shape. ID: FO_SIMPLE_LABLE 257

 
//===========================================================================
// Summary:
//     The CFOPSimpleLabelShape class derived from CFODrawPortsShape
//      F O P Simple Label Shape
//===========================================================================

class FO_EXT_CLASS CFOPSimpleLabelShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSimpleLabelShape---F O P Simple Label Shape, Specifies a E-XD++ CFOPSimpleLabelShape object (Value).
	DECLARE_SERIAL(CFOPSimpleLabelShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Label Shape, Constructs a CFOPSimpleLabelShape object.
	//		Returns A  value (Object).
	CFOPSimpleLabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Label Shape, Constructs a CFOPSimpleLabelShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSimpleLabelShape& src object(Value).
	CFOPSimpleLabelShape(const CFOPSimpleLabelShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Simple Label Shape, Destructor of class CFOPSimpleLabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSimpleLabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSimpleLabelShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the static shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	
	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPSimpleLabelShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSimpleLabelShape& src object(Value).
	CFOPSimpleLabelShape& operator=(const CFOPSimpleLabelShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// shape area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Release pen and brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen And Brush, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleasePenAndBrush();

	// Draws the Text status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text And Edit, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcText---&rcText, Specifies A CRect type value.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual void OnDrawTextAndEdit(CDC *pDC,const CRect &rcText,const BOOL &bFullSize = TRUE);


	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Position shape.
	// rcNewPos -- new position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Offset all points.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

public:

	// Get font metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Metrics, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dxWidth---dxWidth, Specifies A integer value.  
	//		dyHeight---dyHeight, Specifies A integer value.
	virtual void GetFontMetrics(CDC* pDC, int& dxWidth, int& dyHeight);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Get label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetLabelText() const { return m_strLabel; }

	// Change label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Text, Sets a specify value to current class CFOPSimpleLabelShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetLabelText(const CString &str) { m_strLabel = str; }

	// Change current text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void SetCurrentTextValue(const CString &strValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Re calculate extend bound rectangle.
	// rcBound -- bounding rectangle that is generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

public:

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPSimpleLabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);
	enum FOPPNumerCType
	{
		FOPP_NUMERIC_INDICATOR_CELL_TYPE_FIRST = 0,
			FOPP_NUMERIC_INDICATOR_CELL_DIGIT      = FOPP_NUMERIC_INDICATOR_CELL_TYPE_FIRST,
			FOPP_NUMERIC_INDICATOR_CELL_DECIMAL    = 1,
			FOPP_NUMERIC_INDICATOR_CELL_DOT        = 2,
			FOPP_NUMERIC_INDICATOR_CELL_SIGN       = 3,
			FOPP_NUMERIC_INDICATOR_CELL_ERROR      = 4,
			FOPP_NUMERIC_INDICATOR_CELL_TYPE_LAST  = FOPP_NUMERIC_INDICATOR_CELL_ERROR
	};
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Update text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Text, Call this member function to update the object.
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	void UpdateText(CString &strLabel);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);


	// Draw sep
	virtual void OnDrawSeparator(CDC* pDC, FOPRect rc);

	// Draw char
	virtual void OnDrawChar(CDC* pDC, FOPRect rcChar, TCHAR ch, int nIndex, FOPPNumerCType type);

	// Draw digital.
	void DrawLabel(CDC *pDC);

public:
	int							m_nCells;
	int							m_nDecimals;
	int							m_nSeparatorWidth;
	BOOL						m_bDrawSign;
	BOOL						m_bDrawDecimalPoint;
	BOOL						m_bDrawLeadingZeros;
	FOPNumberDigit*				m_nNumberX;
	FOPSize						m_sizeMargin;

protected:

	// Old text color.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strLabel;

	// Int 
 
	// Number Dig, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nNumDig;

	// Start text.
 
	// Start, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strStart;

	// End text.
 
	// End, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strEnd;
};

///////////////////////////////////////////////////////////////
// CFOPHMILabelShape -- simple label shape. ID: FO_SIMPLE_LABLE 299

 
//===========================================================================
// Summary:
//     The CFOPHMILabelShape class derived from CFODrawPortsShape
//      F O P H M I Label Shape
//===========================================================================

class FO_EXT_CLASS CFOPHMILabelShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHMILabelShape---F O P H M I Label Shape, Specifies a E-XD++ CFOPHMILabelShape object (Value).
	DECLARE_SERIAL(CFOPHMILabelShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P H M I Label Shape, Constructs a CFOPHMILabelShape object.
	//		Returns A  value (Object).
	CFOPHMILabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P H M I Label Shape, Constructs a CFOPHMILabelShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHMILabelShape& src object(Value).
	CFOPHMILabelShape(const CFOPHMILabelShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P H M I Label Shape, Destructor of class CFOPHMILabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHMILabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPHMILabelShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the static shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPHMILabelShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHMILabelShape& src object(Value).
	CFOPHMILabelShape& operator=(const CFOPHMILabelShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// shape area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Release pen and brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen And Brush, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleasePenAndBrush();


	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Position shape.
	// rcNewPos -- new position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Offset all points.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

public:

	// Get font metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Metrics, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dxWidth---dxWidth, Specifies A integer value.  
	//		dyHeight---dyHeight, Specifies A integer value.
	virtual void GetFontMetrics(CDC* pDC, int& dxWidth, int& dyHeight);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Get label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetLabelText() const { return m_strLabel; }

	// Change label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Text, Sets a specify value to current class CFOPHMILabelShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetLabelText(const CString &str) { m_strLabel = str; }

	// Change current text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void SetCurrentTextValue(const CString &strValue);

	// Drawing x label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw X, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dwChar---dwChar, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nCol---nCol, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies a const FOPRect &rcPos object(Value).
	void DrawX( CDC* pDC, DWORD dwChar, int nCol, const FOPRect &rcPos);
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPHMILabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Update text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Text, Call this member function to update the object.
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	void UpdateText(CString &strLabel);
protected:

	// Old text color.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strLabel;

	// Int 
 
	// Number Dig, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nNumDig;

	// Start text.
 
	// Start, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strStart;

	// End text.
 
	// End, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strEnd;

	// Faded notches.
 
	// Draw Faded Notches, Specify A Boolean value.  
	bool m_bDrawFadedNotches;

	// Got metrics or not.
 
	// Got Metrics, Specify A Boolean value.  
	bool m_bGotMetrics;

	// fade color.
 
	// Specified Fade Colour, Specify A Boolean value.  
	bool m_bSpecifiedFadeColour;
	
	// Width.
 
	// Notch Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nNotchWidth;

	// Length.
 
	// Notch Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nNotchLength;

	// Margin
 
	// Margin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nMargin;
	
 
	// Foreground, This member sets A 32-bit value used as a color value.  
	COLORREF m_crForeground;
 
	// Dimension Foreground, This member sets A 32-bit value used as a color value.  
	COLORREF m_crDimForeground;
	
 
	// Blank Padding, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nBlankPadding;
};


///////////////////////////////////////////////////////////////
// FO_HMI_NEW_LABEL_SHAPE				340	//CFOPHMINewLabelShape	

 
//===========================================================================
// Summary:
//     The CFOPHMINewLabelShape class derived from CFODrawPortsShape
//      F O P H M I New Label Shape
//===========================================================================

class FO_EXT_CLASS CFOPHMINewLabelShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHMINewLabelShape---F O P H M I New Label Shape, Specifies a E-XD++ CFOPHMINewLabelShape object (Value).
	DECLARE_SERIAL(CFOPHMINewLabelShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P H M I New Label Shape, Constructs a CFOPHMINewLabelShape object.
	//		Returns A  value (Object).
	CFOPHMINewLabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P H M I New Label Shape, Constructs a CFOPHMINewLabelShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHMINewLabelShape& src object(Value).
	CFOPHMINewLabelShape(const CFOPHMINewLabelShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P H M I New Label Shape, Destructor of class CFOPHMINewLabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHMINewLabelShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPHMINewLabelShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the static shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPHMINewLabelShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPHMINewLabelShape& src object(Value).
	CFOPHMINewLabelShape& operator=(const CFOPHMINewLabelShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// shape area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Release pen and brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen And Brush, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleasePenAndBrush();


	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Position shape.
	// rcNewPos -- new position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Offset all points.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

public:

	// Get font metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Metrics, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dxWidth---dxWidth, Specifies A integer value.  
	//		dyHeight---dyHeight, Specifies A integer value.
	virtual void GetFontMetrics(CDC* pDC, int& dxWidth, int& dyHeight);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Get label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetLabelText() const { return m_strLabel; }

	// Change label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Text, Sets a specify value to current class CFOPHMINewLabelShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetLabelText(const CString &str) { m_strLabel = str; }

	// Change current text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void SetCurrentTextValue(const CString &strValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPHMINewLabelShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
	
	// Update text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Text, Call this member function to update the object.
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	void UpdateText(CString &strLabel);
protected:

	// Old text color.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strLabel;
};

#endif // !defined(AFX_FOSTATICSHAPE_H__70D7EFC3_F31E_11DD_A436_525400EA266C__1483_INCLUDED_)
