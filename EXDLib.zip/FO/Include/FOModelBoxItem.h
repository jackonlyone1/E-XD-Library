//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOMODELBOXITEM_H__38B479A8_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
#define AFX_FOMODELBOXITEM_H__38B479A8_D0E7_11D6_A665_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOModelBoxItem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOModelBoxItem window

#include "FOBitmap.h"
#include "FOCompositeShape.h"

 
//===========================================================================
// Summary:
//     The CFOModelBoxItem class derived from CObject
//      F O Model Box Item
//===========================================================================

class FO_EXT_CLASS CFOModelBoxItem : public CObject
{ 
protected: 
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelBoxItem---F O Model Box Item, Specifies a E-XD++ CFOModelBoxItem object (Value).
	DECLARE_SERIAL(CFOModelBoxItem);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Box Item, Constructs a CFOModelBoxItem object.
	//		Returns A  value (Object).
	CFOModelBoxItem();

	// Constructor.
	// strIFile -- the specify file name.
	// crTrans -- transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Box Item, Constructs a CFOModelBoxItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		strIFile---I File, Specifies A CString type value.  
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	CFOModelBoxItem(CString strIFile,COLORREF crTrans= RGB(255,255,255));

	// Constructor.
	// nIconID -- the specify icon id.
	// crTrans -- transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Box Item, Constructs a CFOModelBoxItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nIconID---Icon I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	CFOModelBoxItem(UINT nIconID,COLORREF crTrans= RGB(255,255,255));

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Box Item, Destructor of class CFOModelBoxItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOModelBoxItem();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Serialize ole data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Ole Data, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeOleData(CArchive &ar);

public:

	// Obtain the selected flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&bSelect---&bSelect, Specifies A Boolean value.
	void	SetSelected(const BOOL &bSelect)		{ m_bSelected = bSelect; }

	// Change the selection flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsSelected() const					{ return m_bSelected; }

	// Get view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Style, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetViewStyle() const { return m_nViewStyle; }

	// Set view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Style, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&nStyle---&nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetViewStyle(const UINT &nStyle) { m_nViewStyle = nStyle; }

	// Obtain the caption of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Caption, Returns the specified value.
	//		Returns a CString type value.
	CString GetCaption() const;

	// Change the caption of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Caption, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetCaption(const CString &str);

	// Obtain the prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Prompt, Returns the specified value.
	//		Returns a CString type value.
	CString GetPrompt() const { return m_strPrompt; }

	// Change the item's prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Prompt, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void	SetPrompt(const CString &strText) { m_strPrompt = strText; }

	// Obtain the transparent color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetTransparentColor() const;

	// Change the transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent Color, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetTransparentColor(const COLORREF &cr);

	// Obtain the item's rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const;

	// Change the item's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&cr---Specifies A CRect type value.
	void	SetItemRect(const CRect &cr);

	// Obtain the item's type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a int type value.
	int		GetType() const;

	// Obtain the item's type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&num---Specifies A integer value.
	void	SetType(const int &num);

	// load icon from a special file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL	LoadIconFile(CString strFile,COLORREF cr= RGB(255,255,255));

	// Load icon from a special resource id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon I D, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL	LoadIconID(UINT nID,COLORREF cr= RGB(255,255,255));

	// Is mouse over title bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse Over, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMouseOver() const { return m_bMouseOver; }

	// Set mouse over.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mouse Over, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&bOver---&bOver, Specifies A Boolean value.
	void SetMouseOver(const BOOL &bOver) { m_bMouseOver = bOver; }

	// Obtain the link file name,it will be used to generate the bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link File Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetLinkFileName() const { return m_strLinkFileName; }

	// Change the link file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link File Name, Sets a specify value to current class CFOModelBoxItem
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetLinkFileName(const CString &str) { m_strLinkFileName = str; }

public:

	// Update all data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All, Call this member function to update the object.

	void	UpdateAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	// Init
	virtual void Init(CWnd* pWnd);

	// Get font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	CSize GetFontSize(CDC *pDC);


	// Convert current file to bitmap.
	// bmp -- output bitmap handle.
	// cx -- width of the output bitmap.
	// cy -- height of the output bitmap.
	// crBack -- back color of the output bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bmp---Specifies a E-XD++ CFOBitmap &bmp object (Value).  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual BOOL GetBitmap(CFOBitmap &bmp, int cx, int cy,COLORREF crBack = RGB(255,255,255));

public:
	// With this method to draw the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFull---&bFull, Specifies A Boolean value.
	virtual void OnDraw(CDC *pDC,const BOOL &bFull = FALSE);

	// With this method to draw the item with selection state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFocus---&bFocus, Specifies A Boolean value.
	virtual void OnDrawSelect(CDC *pDC, const BOOL &bFocus);

	// draw transparent bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Transparent Bitmap, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.  
	//		pbmpMask---pbmpMask, A pointer to the CBitmap or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	static void DrawTransparentBitmap(CDC* pDC, CBitmap* pbmp, CBitmap* pbmpMask,
	                              int x, int y, int cx, int cy);

	// Init transparent bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Transparent Bitmap, Call InitTransBitmap after creating a new object.
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		pbmp---A pointer to the CBitmap or NULL if the call failed.
	static COLORREF InitTransBitmap(CBitmap* pbmp);

	// Edit tool bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Edit Tool Bitmap, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void EditToolBitmap();

	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);

public:

	// object of class
 
	// Image, This member specify E-XD++ CFOImageIcon object.  
	CFOImageIcon	m_Image;            

protected:

	// caption	
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;		

	// type of item
 
	// Item Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nItemType;	
	
	// file of icon
 
	// Icon File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strIconFile;	
	
	// color :transparent
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crTransparent;	

	// position:
 
	// Position, This member sets a CRect value.  
	CRect			m_rectPosition;		

	// flag of being selected
 
	// Selected, This member sets TRUE if it is right.  
	BOOL			m_bSelected;		
	
	// Prompt text.
 
	// Prompt, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strPrompt;

	// true type
 
	// True Type, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*		m_bmpTrueType;		

	// parent window
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			pParentWnd;		
	
	// size of image
 
	// Image, This member sets a CSize value.  
	CSize			szImage;			

	// View style.
 
	// View Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nViewStyle;

	// Mouse over state.
 
	// Mouse Over, This member sets TRUE if it is right.  
	BOOL			m_bMouseOver;

	// Link model file name.
 
	// Link File Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strLinkFileName;

	// transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF		crTransparent;

	// Drawing bitmap.
 
	// Draw Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap *		m_pDrawBitmap;

};


/////////////////////////////////////////////////////////////////////////////////
//
// CFOPTemplateBitmapCache
//

 
//===========================================================================
// Summary:
//      To use a CFOPTemplateBitmapCache object, just call the constructor.
//      F O P Template Bitmap Cache
//===========================================================================

class FO_EXT_CLASS CFOPTemplateBitmapCache
{
	// The maximize size of the cache.
 
	// Maximize Size, Specify a A 32-bit signed integer.  
	LONG		            m_nMaxSize;

	// Current memory size of the cache
 
	// Current Size, Specify a A 32-bit signed integer.  
	LONG		            m_nCurSize;

	// List of entries.
 
	// Entries, This member specify FOPList object.  
	FOPList		            m_aEntries;
                            
public:                     
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Template Bitmap Cache, Constructs a CFOPTemplateBitmapCache object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nMaxSizeKB---Maximize Size K B, Specifies A 32-bit LONG signed integer.
				            CFOPTemplateBitmapCache(LONG nMaxSizeKB)
				              : m_nMaxSize(nMaxSizeKB), m_nCurSize(0) {}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Template Bitmap Cache, Destructor of class CFOPTemplateBitmapCache
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual 	            ~CFOPTemplateBitmapCache();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		pItem---pItem, A pointer to the const CFOModelBoxItem or NULL if the call failed.  
	//		rBmp---rBmp, Specifies a E-XD++ CFOBitmap& rBmp object (Value).
	// Add new entries
	void		            Add(const CFOModelBoxItem* pItem, CFOBitmap& rBmp);

	// Obtain entries.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed  
	// Parameters:
	//		pItem---pItem, A pointer to the const CFOModelBoxItem or NULL if the call failed.
	CFOBitmap*				Get(const CFOModelBoxItem* pItem);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		pItem---pItem, A pointer to the const CFOModelBoxItem or NULL if the call failed.
	// Remove entries.
	void                    Remove(const CFOModelBoxItem* pItem);
};

// Model box item list.
typedef CTypedPtrList<CObList, CFOModelBoxItem*> CFOModelBoxItemList;

// Iterator of model box item.
typedef FOBasicListIterator<CFOModelBoxItem*> CFOModelBoxItemIterator;

///////////////////////////////////////////////////////
_FOLIB_INLINE CString CFOModelBoxItem::GetCaption() const
{
	return m_strCaption;
}

_FOLIB_INLINE COLORREF CFOModelBoxItem::GetTransparentColor() const
{
	return m_crTransparent;
}

_FOLIB_INLINE int CFOModelBoxItem::GetType() const
{
	return m_nItemType;
}
	
_FOLIB_INLINE void CFOModelBoxItem::SetCaption(const CString &str)
{
	m_strCaption = str;
}

_FOLIB_INLINE void CFOModelBoxItem::SetTransparentColor(const COLORREF &cr)
{
	m_crTransparent = cr;
}

_FOLIB_INLINE void CFOModelBoxItem::SetType(const int &nType) 
{
	m_nItemType = nType;
}

_FOLIB_INLINE CRect CFOModelBoxItem::GetItemRect() const
{
	return m_rectPosition;
}

_FOLIB_INLINE void CFOModelBoxItem::SetItemRect(const CRect &cr)
{
	m_rectPosition = cr;
}
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOMODELBOXITEM_H__38B479A8_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
