//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPrintHeaderFooterDlg.h: interface for the CFOPrintHeaderFooterDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPRINTHEADERFOOTERDLG_H__0C171E83_E21B_11D5_A4B3_525400EA266C__INCLUDED_)
#define AFX_FOPRINTHEADERFOOTERDLG_H__0C171E83_E21B_11D5_A4B3_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOGlobals.h"

#include "FODropMenuButton.h"
#include "FOPDropDownColorPickerButton.h"
#include "FODataModel.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOPrintHeaderFooterDlg class derived from CDialog
//      F O Print Header Footer Dialog
//===========================================================================

class FO_EXT_CLASS CFOPrintHeaderFooterDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Print Header Footer Dialog, Constructs a CFOPrintHeaderFooterDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPrintHeaderFooterDlg(CWnd* pParent = NULL);   // standard constructor


	// Dialog Data
	//{{AFX_DATA(CFOPrintHeaderFooterDlg)
	enum { IDD = IDD_FO_PRINT_HEADFOOT };
 
	// Font Information, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strFontInfo;
 
	// Foot Center, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strFootCenter;
 
	// Foot Left, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strFootLeft;
 
	// Foot Right, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strFootRight;
 
	// Head Center, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strHeadCenter;
 
	// Head Left, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strHeadLeft;
 
	// Head Right, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strHeadRight;
 
	// Print Information, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strPrintInfo;
	//}}AFX_DATA

 
	// Left1, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnLeft1;
 
	// Center1, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnCenter1;
 
	// Right1, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnRight1;

 
	// Left2, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnLeft2;
 
	// Center2, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnCenter2;
 
	// Right2, This member specify E-XD++ CFODropMenuButton object.  
	CFODropMenuButton m_btnRight2;

 
	// Text Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnTextColor;

	// Log font.
 
	// This member specify LOGFONT object.  
	LOGFONT				m_lf;

 
	// Attach Edit, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd				*m_pAttachEdit;

 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crText;

	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	// Get font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Information, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFontSet---Font Set, A pointer to the FO_FONT or NULL if the call failed.
	virtual void GetFontInfo(FO_FONT* pFontSet);

	// Set font info.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Information, Sets a specify value to current class CFOPrintHeaderFooterDlg
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pFontSet---Font Set, A pointer to the FO_FONT  or NULL if the call failed.
	virtual void SetFontInfo(FO_FONT *pFontSet);

	// Page setup has change.
 
	// Modified, This member sets TRUE if it is right.  
	BOOL				m_bModified;

	// Get current print page size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Print Size, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetPrintSize();
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
protected:

	// The Pointer to Current Data Model
 
	// Current Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pCurDataModel;
public:

	// Get Current Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	CFODataModel *GetCurrentModel() const		{ ASSERT(m_pCurDataModel != NULL);return m_pCurDataModel; }
	
	// Set Current Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Model, Sets a specify value to current class CFOPrintHeaderFooterDlg
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	void SetCurrentModel(CFODataModel *pModel)  { m_pCurDataModel = pModel; }


	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPrintHeaderFooterDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


	// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOPrintHeaderFooterDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Choosefont, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnBtnChoosefont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Printinfo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnBtnPrintinfo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Pagenum, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfPagenum();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Pagename, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfPagename();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Totalpages, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfTotalpages();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Currenttime, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfCurrenttime();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Currentdate Short, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfCurrentdateShort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Currentdatelong, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfCurrentdatelong();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf Filename, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfFilename();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf File Extension, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfFileExtension();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Hf File Name And Extend, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoHfFileNameAndExt();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnBtnHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_FOPRINTHEADERFOOTERDLG_H__0C171E83_E21B_11D5_A4B3_525400EA266C__INCLUDED_)
