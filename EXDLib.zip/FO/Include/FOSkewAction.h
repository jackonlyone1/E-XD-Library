//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOSKEWACTION_H__2378FCF7_C9E0_4683_A201_FABAFEDF3A4C__INCLUDED_)
#define AFX_FOSKEWACTION_H__2378FCF7_C9E0_4683_A201_FABAFEDF3A4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOSkewAction.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOSkewAction -- action that skew selection shape.

#include "FOAction.h"

 
//===========================================================================
// Summary:
//     The CFOPSkewXAction class derived from CFOAction
//      F O P Skew X Action
//===========================================================================

class FO_EXT_CLASS CFOPSkewXAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSkewXAction---F O P Skew X Action, Specifies a E-XD++ CFOPSkewXAction object (Value).
	DECLARE_ACTION(CFOPSkewXAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Skew X Action, Constructs a CFOPSkewXAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&dOrgX---Org X, Specifies a const double &dOrgX object(Value).  
	//		&dOrgY---Org Y, Specifies a const double &dOrgY object(Value).  
	//		&nAngle---&nAngle, Specifies A integer value.
	CFOPSkewXAction(CFODataModel* pModel,const CFODrawShapeList& list,
		const CFODrawShapeList& listCenter,
	const double &dOrgX,const double &dOrgY,const int &nAngle);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Skew X Action, Destructor of class CFOPSkewXAction
	//		Returns A  value (Object).
	~CFOPSkewXAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get total bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTotalSnapRect() const;

protected:

	// a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

	// a list of shape
 
	// Center Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listCenterShapes;

	// X start point.
 
	// X Rotate, This member specify double object.  
	double				dXRotate;

	// Y start point.
 
	// Y Rotate, This member specify double object.  
	double				dYRotate;

	// Current rotate angle.
 
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAngle;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};


/////////////////////////////////////////////////////////////////////////////
// CFOSkewAction -- action that skew shape.

 
//===========================================================================
// Summary:
//     The CFOPSkewYAction class derived from CFOAction
//      F O P Skew Y Action
//===========================================================================

class FO_EXT_CLASS CFOPSkewYAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSkewYAction---F O P Skew Y Action, Specifies a E-XD++ CFOPSkewYAction object (Value).
	DECLARE_ACTION(CFOPSkewYAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Skew Y Action, Constructs a CFOPSkewYAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&dOrgX---Org X, Specifies a const double &dOrgX object(Value).  
	//		&dOrgY---Org Y, Specifies a const double &dOrgY object(Value).  
	//		&nAngle---&nAngle, Specifies A integer value.
	CFOPSkewYAction(CFODataModel* pModel,const CFODrawShapeList& list,
		const CFODrawShapeList& listCenter,
	const double &dOrgX,const double &dOrgY,const int &nAngle);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Skew Y Action, Destructor of class CFOPSkewYAction
	//		Returns A  value (Object).
	~CFOPSkewYAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get total bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTotalSnapRect() const;

protected:

	// a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

	// a list of shape
 
	// Center Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listCenterShapes;

	// X start point.
 
	// X Rotate, This member specify double object.  
	double				dXRotate;

	// Y start point.
 
	// Y Rotate, This member specify double object.  
	double				dYRotate;

	// Current rotate angle.
 
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAngle;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOSKEWACTION_H__2378FCF7_C9E0_4683_A201_FABAFEDF3A4C__INCLUDED_)
