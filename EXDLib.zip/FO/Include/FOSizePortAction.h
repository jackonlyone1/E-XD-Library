//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOSIZEPORTACTION_H__DF116C80_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
#define AFC_FOSIZEPORTACTION_H__DF116C80_DD9D_11D5_A4AC_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action
///////////////////////////////////////

#include "FOAction.h"
#include "FOPortShape.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOSizePortAction -- action that change the port of link shape.

 
//===========================================================================
// Summary:
//     The CFOSizePortAction class derived from CFOAction
//      F O Size Port Action
//===========================================================================

class FO_EXT_CLASS CFOSizePortAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSizePortAction---F O Size Port Action, Specifies a E-XD++ CFOSizePortAction object (Value).
	DECLARE_ACTION(CFOSizePortAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Size Port Action, Constructs a CFOSizePortAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOSizePortAction(CFODataModel* pModel,CFODrawShape *pShape,int nIndex,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Size Port Action, Destructor of class CFOSizePortAction
	//		Returns A  value (Object).
	~CFOSizePortAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOSizePortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	//TODO:Add your code here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Index, Returns the specified value.
	//		Returns a int type value.
	int GetOldIndex()				{ return nOldIndex; }

	// Set old index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Index, Sets a specify value to current class CFOSizePortAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetOldIndex(int nIndex)	{ nOldIndex = nIndex; }

	// Get new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Index, Returns the specified value.
	//		Returns a int type value.
	int GetNewIndex()				{ return nNewIndex; }

	// Set new index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Index, Sets a specify value to current class CFOSizePortAction
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void SetNewIndex(int nIndex)	{ nNewIndex = nIndex; }

	// Get new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOSizePortAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }


	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Port, Sets a specify value to current class CFOSizePortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetOldPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetOldPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Port, Sets a specify value to current class CFOSizePortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetNewPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetNewPort();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
 
	// This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_links;

 
	// Old Third, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pOldThird;
 
	// New Third, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pNewThird;

 
	// Old Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *m_pOldLink;
 
	// New Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *m_pNewLink;
protected:

	// define pointers of classes
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	// Old port pointer.
 
	// Old Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pOldPort;

	// New port pointer.
 
	// New Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pNewPort;

	// old index
 
	// Old Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nOldIndex;		

	// new index
 
	// New Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nNewIndex;		

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;		
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;// friend class
};

_FOLIB_INLINE void CFOSizePortAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOSizePortAction::GetShape()
{
	return m_pShape;
}

_FOLIB_INLINE void CFOSizePortAction::SetOldPort(CFOPortShape *pShape)
{
	m_pOldPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFOSizePortAction::GetOldPort()
{
	return m_pOldPort;
}

_FOLIB_INLINE void CFOSizePortAction::SetNewPort(CFOPortShape *pShape)
{
	m_pNewPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFOSizePortAction::GetNewPort()
{
	return m_pNewPort;
}

//////////////////////////////////////////////////////////////////////////////////
// CFOBreakLinkAction -- action that break link line.

 
//===========================================================================
// Summary:
//     The CFOBreakLinkAction class derived from CFOAction
//      F O Break Link Action
//===========================================================================

class FO_EXT_CLASS CFOBreakLinkAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBreakLinkAction---F O Break Link Action, Specifies a E-XD++ CFOBreakLinkAction object (Value).
	DECLARE_ACTION(CFOBreakLinkAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Break Link Action, Constructs a CFOBreakLinkAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		bHeader---bHeader, Specifies A Boolean value.
	CFOBreakLinkAction(CFODataModel* pModel,CFODrawShape *pShape,BOOL bHeader);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Break Link Action, Destructor of class CFOBreakLinkAction
	//		Returns A  value (Object).
	~CFOBreakLinkAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOBreakLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Port, Sets a specify value to current class CFOBreakLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetOldPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetOldPort();

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Port, Sets a specify value to current class CFOBreakLinkAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetNewPort(CFOPortShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetNewPort();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

 
	// This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_links;

 
	// Old Third, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pOldThird;
 
	// New Third, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pNewThird;

 
	// Old Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *m_pOldLink;
 
	// New Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *m_pNewLink;
protected:

	

	// define pointers of classes
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	// Old port pointer.
 
	// Old Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pOldPort;

	// New port pointer.
 
	// New Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *m_pNewPort;

	// From port or to port.
 
	// Header, This member sets TRUE if it is right.  
	BOOL		  m_bHeader;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;// friend class
};

_FOLIB_INLINE void CFOBreakLinkAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOBreakLinkAction::GetShape()
{
	return m_pShape;
}

_FOLIB_INLINE void CFOBreakLinkAction::SetOldPort(CFOPortShape *pShape)
{
	m_pOldPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFOBreakLinkAction::GetOldPort()
{
	return m_pOldPort;
}

_FOLIB_INLINE void CFOBreakLinkAction::SetNewPort(CFOPortShape *pShape)
{
	m_pNewPort = pShape;
}

_FOLIB_INLINE CFOPortShape *CFOBreakLinkAction::GetNewPort()
{
	return m_pNewPort;
}


#endif // !defined(AFC_FOSIZEPORTACTION_H__DF116C80_DD9D_11D5_A4AC_525400EA266C__INCLUDED_)
