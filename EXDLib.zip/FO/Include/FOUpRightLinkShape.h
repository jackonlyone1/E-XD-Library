//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOUPRIGHTLINKSHAPE_H__19D05235_B3FF_11D6_A633_0050BAE30439__INCLUDED_)
#define AFC_FOUPRIGHTLINKSHAPE_H__19D05235_B3FF_11D6_A633_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOLinkShape.h"

////////////////////////////////////////////////////////////////////////////
// CFOUpRightLinkShape -- up - right link shape, ID: FO_COMP_UPRIGHTLINK 92

 
//===========================================================================
// Summary:
//     The CFOUpRightLinkShape class derived from CFOLinkShape
//      F O Up Right Link Shape
//===========================================================================

class FO_EXT_CLASS CFOUpRightLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOUpRightLinkShape---F O Up Right Link Shape, Specifies a E-XD++ CFOUpRightLinkShape object (Value).
	DECLARE_SERIAL(CFOUpRightLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Up Right Link Shape, Constructs a CFOUpRightLinkShape object.
	//		Returns A  value (Object).
	CFOUpRightLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Up Right Link Shape, Constructs a CFOUpRightLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOUpRightLinkShape& src object(Value).
	CFOUpRightLinkShape(const CFOUpRightLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Up Right Link Shape, Destructor of class CFOUpRightLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOUpRightLinkShape();

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the up right link shape from points.
	// ptArray -- points of shape.
	// pFrom -- start link port.
	// pTo-- end link port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the up right link shape from points.
	// pptPoints -- points of shape.
	// nCount -- total points of shape.
	// pFrom -- start link port.
	// pTo-- end link port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Relayout state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Save Interest Point
	CArray<CPoint,CPoint> m_arInterestPoint;

	// To calculate the intersect points
	// pLinkShape -- pointer of link shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intesect Point, Returns the specified value.
	// Parameters:
	//		*pLinkShape---Link Shape, A pointer to the CFOUpRightLinkShape  or NULL if the call failed.
	void GetIntesectPoint(CFOUpRightLinkShape *pLinkShape);

	// To check if point is on line.
	// ptStart -- start point of line.
	// ptEnd -- end point of line
	// pt -- point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptStart---ptStart, Specifies A CPoint type value.  
	//		ptEnd---ptEnd, Specifies A CPoint type value.  
	//		&pt---Specifies A CPoint type value.
	BOOL PointInLine(CPoint ptStart, CPoint ptEnd, CPoint &pt);

	// Update all points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Calculate All Points, .
	
	virtual void ReCalcAllPoints(const BOOL &only = FALSE);

	// Do draw line.
	// pDC -- pointer of DC
	// ptStart -- start point of line segment.
	// ptEnd -- end point of line segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line Temp, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	void DoDrawLineTemp(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	// Obtain the first center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Begin Center, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetBeginCenter() const;

	// Insert begin point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Begin Center Point, Inserts a child object at the given index..

	void InsertBeginCenterPoint();

	// Obtain the end center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Center, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetEndCenter() const;

	// Insert end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert End Center Point, Inserts a child object at the given index..

	void InsertEndCenterPoint();

	// Get intersections.
	// A -- first point.
	// B -- second point.
	// v -- points
	// numints -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intersections2, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&A---&A, Specifies A CPoint type value.  
	//		&B---&B, Specifies A CPoint type value.  
	//		CArray<float---Array<float, Specifies A CArray array.  
	//		&v---Specifies A float value.  
	//		numints---Specifies A integer value.
	int GetIntersections2(const CPoint &A, const CPoint &B, 
		CArray<float,float> &v, int numints);

	// Get intersections.
	// A -- first point.
	// B -- second point.
	// v -- points that recieved.
	// numints -- point count.
	// nCurNum -- current number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intersections New2, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&A---&A, Specifies A CPoint type value.  
	//		&B---&B, Specifies A CPoint type value.  
	//		CArray<float---Array<float, Specifies A CArray array.  
	//		&v---Specifies A float value.  
	//		numints---Specifies A integer value.  
	//		&nCurNum---Current Number, Specifies A integer value.
	int GetIntersectionsNew2(const CPoint &A, const CPoint &B, 
		CArray<float,float> &v, int numints, const int &nCurNum);

	// Furthest point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Furthest Point, .
	//		Returns a int type value.  
	// Parameters:
	//		&a---Specifies A CPoint type value.  
	//		i---Specifies A integer value.  
	//		oneway---Specifies A Boolean value.
	int FurthestPoint(const CPoint &a, int i, BOOL oneway);

	// Draw new line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw New Line, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&from---Specifies A CPoint type value.  
	//		&to---Specifies A CPoint type value.  
	//		&nCurNum---Current Number, Specifies A integer value.  
	//		&mLinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &mLinkList object (Value).  
	//		&nCurIndex---Current Index, Specifies A integer value.
	void DoDrawNewLine(CDC *pDC, const CPoint &from, const CPoint &to, const int &nCurNum, 
		CFODrawShapeSet &mLinkList, int &nCurIndex);

	// Draw new line corner
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw New Line And Corner, Do a event. 
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&a---Specifies A CPoint type value.  
	//		&b---Specifies A CPoint type value.  
	//		&c---Specifies A CPoint type value.  
	//		&nCurNum---Current Number, Specifies A integer value.  
	//		&mLinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &mLinkList object (Value).  
	//		&nCurIndex---Current Index, Specifies A integer value.
	CPoint DoDrawNewLineAndCorner(CDC *pDC, const CPoint &a, const CPoint &b, const CPoint &c,
		const int &nCurNum, CFODrawShapeSet &mLinkList, int &nCurIndex);

	// Hit test any segment of line.
	// pnt -- point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment Near Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&pnt---Specifies A CPoint type value.
	int GetSegmentNearPoint(const CPoint &pnt);

	// Get orientation offset at a specify segment index.
	// szOffset -- offset size.
	// segIndex -- index of segment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Orientation Offset, Returns the specified value.
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		&szOffset---&szOffset, Specifies a FOPSize &szOffset object(Value).  
	//		segIndex---segIndex, Specifies A integer value.
	FOPSize GetOrientationOffset(FOPSize &szOffset, int segIndex );

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();


	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOUpRightLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOUpRightLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle Track X, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngleTrackX() const;

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Extend Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenExtAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);

	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLabelPoint();
	
	// Get the line total distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Distance, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetTotalDistance();

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetExtAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetExtAnchorPoint(CPoint ptOffset);
	
	// Compute scaling ratio.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Extend Ratio, Call this member function to update the object.

	void UpdateExtRatio();
	
	// Compute scaling ratio.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Track Extend Ratio, Call this member function to update the object.

	void UpdateTrackExtRatio();
	
	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;
	
	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);
	
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOUpRightLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOUpRightLinkShape& src object(Value).
	CFOUpRightLinkShape& operator=(const CFOUpRightLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:
	
	// Return AllowShowRoundCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Allow Show Round Corner, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetAllowShowRoundCorner() const { return m_bAllowShowRoundCorner;}

	// Change AllowShowRoundCorner value.
	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Show Round Corner, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void SetAllowShowRoundCorner( const BOOL &bShow ) {m_bAllowShowRoundCorner = bShow; }

	// Return RoundCornerType value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Round Corner Type, Returns the specified value.
	//		Returns a int type value.
	int GetRoundCornerType() const { return m_nRoundCornerType;}

	// Change RoundCornerType value,below are:
	// nValue = 0,drawing nothing
	// nValue = 1,drawing rectangle.
	// nValue = 2,drawing triangle
	// nValue > 3,drawing customize type by yourself,override DoDrawBridge for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Round Corner Type, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetRoundCornerType( const int &nValue ) {m_nRoundCornerType = nValue; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Do drawing the link cross round corner.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bridge, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&pt3---Specifies A CPoint type value.  
	//		&pt4---Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void DoDrawBridge(CDC *pDC,const CPoint &pt1,const CPoint &pt2,const CPoint &pt3, const CPoint &pt4 = CPoint(0,0));

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point New1, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPointNew1(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point New1, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPointNew1(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Is points on line
	// ptStart -- start point of line.
	// ptEnd -- end point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Point On Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.
	BOOL CheckPointOnLine( const FOPPoint &ptStart, const FOPPoint &ptEnd );

	// Get orient of first segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Segment Orient, Returns the specified value.
	//		Returns A FO_Orth_Orign value (Object).
	FO_Orth_Orign GetFirstSegmentOrient();

	// Merge same line points.
	// mpSpot -- spot points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Merge Same Line Points, .
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		mpSpot---mpSpot, A pointer to the CPoint> or NULL if the call failed.
	void MergeSameLinePoints(FOPointsArray& mpSpot);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();
	
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOUpRightLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
	// Do animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

protected:

	// Ext anchor ratio.
 
	// Extend Anchor Ratio, This member specify double object.  
	double m_dExtAnchorRatio;
	
	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize m_szSavLabel;

protected:
	// FODO:Add your properties items below.
	// AllowShowRoundCorner value.
 
	// Allow Show Round Corner, This member sets TRUE if it is right.  
	BOOL                              m_bAllowShowRoundCorner;

	// RoundCornerType value, it is one of the following value.
	// 	
	// enum FOPBridgeStyle
	// {
	// 	FOPCap = 0,
	// 	FOPArc,
	// 	FOPSquare,
	// 	FOPSides2,
	// 	FOPSides3,
	// 	FOPSides4,
	// 	FOPSides5,
	// 	FOPSides6,
	// 	FOPSides7
	// };
 
	// Round Corner Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                 m_nRoundCornerType;

	// Shift value.
 
	// Shift, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nShift;

	// animate
 
	// Animate, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAnimate;
	
	// wide
 
	// Wide, This member sets TRUE if it is right.  
	BOOL				m_bWide;

	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
public:
	// Current timer speed, default is 400
 
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;

	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

};


#endif // !defined(AFC_FOUPRIGHTLINKSHAPE_H__19D05235_B3FF_11D6_A633_0050BAE30439__INCLUDED_)
