//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLINETYPEPICKERDRAWPANEL_H__B97A50BC_FA8D_453B_A499_D0D74A007B2A__INCLUDED_)
#define AFX_FOPLINETYPEPICKERDRAWPANEL_H__B97A50BC_FA8D_453B_A499_D0D74A007B2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLineTypePickerDrawPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPLineTypePickerDrawPanel window
#include "FOPDrawControlPanel.h"

const unsigned FOP_MSG__LINETYPE_CHANGE		= 1;
const unsigned FOP_MSG__LINETYPE_CYCLE		= 2;
const unsigned FOP_MSG__LINETYPE_NONE		= 3;
const unsigned FOP_MSG__LINETYPE_CUSTOM		= 4;
const unsigned FOP_MSG__LINETYPE_CANCEL		= 5;
const unsigned FOP_MSG__LINETYPE_BUTTON2	= 6;

// Line type table entry
struct FOPLineTypeTableEntry 
{
	// Line type value.
    int			nLineType;

	// Line type name.
    LPCTSTR		szName;
};

 
//===========================================================================
// Summary:
//     The FOPLineTypeDrawPanel class derived from FOPDrawControlPanel
//      O P Line Type Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPLineTypeDrawPanel : public FOPDrawControlPanel
{
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Type Draw Panel, Constructs a FOPLineTypeDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
					FOPLineTypeDrawPanel(HasHeaderBar ind = HeaderBarOne, 
						HasButton but = ButtonOne);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Type Draw Panel, Destructor of class FOPLineTypeDrawPanel
	//		Returns A  value (Object).
					~FOPLineTypeDrawPanel();

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetMainGroupName(int nIndex);

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetExtraGroupName(int nIndex);

	// Draw main group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		enabled---Specifies A Boolean value.
	// Do draw mode
	virtual void	Draw(CDC& DC, const CRect& rect, int nIndex, BOOL  transparent = FALSE, 
		BOOL  focus = FALSE, BOOL  enabled = TRUE);

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup);

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int nIndex, BOOL  IsPopup);

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int nIndex, BOOL  IsPopup);

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int nIndex, BOOL  IsPopup);

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int nIndex, BOOL  IsPopup);

	// Is main group enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL 	IsMainGroupEnabled(int nIndex);

	// Get transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetTransparency()			{	return m_bTransparent;	}

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPLineTypeDrawPanel
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void			SetTransparency(BOOL  bTransparent)		{	m_bTransparent = bTransparent;	}

	// Get pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
	int				GetPenWidth() const 		{		return m_nPenWidth;	}	

	// Set pen width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPLineTypeDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetPenWidth(int nWidth)			{		m_nPenWidth = nWidth;		}


	// assessor functions
	//Get line types.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Types, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const int&		GetLineTypes(int nIndex) const	{	return arLineTypes[nIndex].nLineType;	}

	// Get line type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Type, Returns the specified value.
	//		Returns a int type value.
	int				GetLineType();

	// Get fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetFillColor() const;

	// Set line type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Type, Sets a specify value to current class FOPLineTypeDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetLineType(const int& nWidth);

	// Set headerbar state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPLineTypeDrawPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	void			SetHeaderBarState(HasHeaderBar ind);

	// Set sunken draw mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPLineTypeDrawPanel
	// Parameters:
	//		b---Specifies A Boolean value.
	void			SetSunkenMode(BOOL  b);

	// response functions
	// Do when line type change action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Type Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void	DoWellLineTypeChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choose custom line type button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Line Type, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomLineType();

	// Do when choose none line type button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Type None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellLineTypeNone();

	// None line type value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Type None, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.
	static const int	GetLineTypeNone()		{	return (int) PS_NULL; }

	// Total number of line type.
	enum { DefaultLineTypePickers = 5};

protected:

	// Total number of line type.
 
	// Total Line Type Pickers, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nTotalLineTypePickers;

	// Line types.
 
	// Line Types, This member maintains a pointer to the object FOPLineTypeTableEntry.  
	FOPLineTypeTableEntry*			arLineTypes;

	// Default line types.
 
	// Default Line Types[ Default Line Type Pickers], This member specify FOPLineTypeTableEntry object.  
	static FOPLineTypeTableEntry	DefaultLineTypes[DefaultLineTypePickers];

	// Transparent.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 							m_bTransparent;

	// Pen width.
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nPenWidth;
};

// DDX
void DDX_LineTypeWell(CDataExchange* pDX, FOPLineTypeDrawPanel& w, int& nWidth);

struct FOPDropLineTypeCallback
{
	// Do when line type change
	virtual void	OnWellLineTypeChange(const int& nWidth) = 0;

	// Do when cancel action.
	virtual void	OnWellCancel() = 0;

	// Do when choose custom line type button action.
	virtual void	OnWellCustomLineType() = 0;

	// Do when choose none line type action.
	virtual void	OnWellLineTypeNone() = 0;
};

 
//===========================================================================
// Summary:
//     The FOPDropLineTypePickerDrawPanel class derived from FOPLineTypeDrawPanel
//      O P Drop Line Type Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPDropLineTypePickerDrawPanel : public FOPLineTypeDrawPanel
{
protected:
	// Call back
 
	// This member maintains a pointer to the object FOPDropLineTypeCallback.  
	FOPDropLineTypeCallback* Button;
public:
	// response functions
	// Do when line type change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Type Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void DoWellLineTypeChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCancel();

	// Do when choose custom line type button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Line Type, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCustomLineType();

	// Do when choose none line type action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Line Type None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellLineTypeNone();

	// Set call back
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPDropLineTypePickerDrawPanel
	// Parameters:
	//		button---A pointer to the FOPDropLineTypeCallback or NULL if the call failed.
	void SetButton(FOPDropLineTypeCallback* button)	{	Button = button;	}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Line Type Picker Draw Panel, Constructs a FOPDropLineTypePickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = NoHeaderBar object(Value).  
	//		but---Specifies a HasButton but = NoButton object(Value).  
	//		btn---A pointer to the FOPDropLineTypeCallback or NULL if the call failed.
	FOPDropLineTypePickerDrawPanel(HasHeaderBar ind = NoHeaderBar,
		HasButton but = NoButton, FOPDropLineTypeCallback* btn = 0);

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLINETYPEPICKERDRAWPANEL_H__B97A50BC_FA8D_453B_A499_D0D74A007B2A__INCLUDED_)
