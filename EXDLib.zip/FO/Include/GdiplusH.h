#ifndef _GDIPLUSH_H_INCLUDED_
#define _GDIPLUSH_H_INCLUDED_

// 
// GDI+ helper file v1.0
// 
// Written by Zoltan Csizmadia
// 

// GDIPLUS_NO_AUTO_INIT:
// GDI+ won't be initialized at program startup, 
// you have to create GdiPlus::GdiPlusInitialize object to 
// initialize GDI+ ( GDI+ will be uninitialized, when destructor
// is called.
//#define GDIPLUS_NO_AUTO_INIT

// GDIPLUS_USE_GDIPLUS_MEM:
// GdipAlloc and GdipFree is used for memory operations
// In this case _Crt functions cannot be used to detect 
// memory leaks
//#define GDIPLUS_USE_GDIPLUS_MEM

// GDIPLUS_NO_AUTO_NAMESPACE:
// Gdiplus namespace wont' be defined as a used namespace
// In this case you have to use Gdiplus:: prefix
//#define GDIPLUS_NO_AUTO_NAMESPACE

#ifdef _GDIPLUS_H
#error Gdiplus.h is already included. You have to include this file instead.
#endif

// Fix for STL iterator problem
#define iterator _iterator
#define list _list
#define map _map

#define _GDIPLUSBASE_H

namespace Gdiplus
{
    namespace DllExports
    {
        #include "GdiplusMem.h"
    };

 
//===========================================================================
// Summary:
//      To use a GdiplusBase object, just call the constructor.
//      Gdiplus Base
//===========================================================================

    class GdiplusBase
    {
    public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdiplus Alloc, .
	// This member function is a static function.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nSize---nSize, Specifies a size_t nSize object(Value).  
	//		szFileName---File Name, Specifies a LPCSTR szFileName object(Value).  
	//		nLine---nLine, Specifies A integer value.
        static void* __cdecl GdiplusAlloc( size_t nSize, LPCSTR szFileName, int nLine )
        {
#ifdef GDIPLUS_USE_GDIPLUS_MEM
            UNREFERENCED_PARAMETER(szFileName);
            UNREFERENCED_PARAMETER(nLine);
            return DllExports::GdipAlloc(nSize); 
#else
            return ::operator new( nSize, szFileName, nLine );
#endif
        }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdiplus Free, .
	// This member function is a static function.
	// Parameters:
	//		pVoid---pVoid, A pointer to the void or NULL if the call failed.  
	//		szFileName---File Name, Specifies a LPCSTR szFileName object(Value).  
	//		nLine---nLine, Specifies A integer value.
        static void GdiplusFree( void* pVoid, LPCSTR szFileName, int nLine )
        {
#ifdef GDIPLUS_USE_GDIPLUS_MEM
            UNREFERENCED_PARAMETER(szFileName);
            UNREFERENCED_PARAMETER(nLine);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies a operator new)(size_t nSize object(Value).
            DllExports::GdipFree(pVoid); 
#else
            ::operator delete( pVoid, szFileName, nLine );
#endif
        }
        
        void* (operator new)(size_t nSize) 
        { 
            return GdiplusAlloc( nSize, __FILE__, __LINE__ );
        }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies a operator new[])(size_t nSize object(Value).
        void* (operator new[])(size_t nSize) 
        { 
            return GdiplusAlloc( nSize, __FILE__, __LINE__ );
        }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		pVoid---pVoid, A pointer to the operator delete)(void or NULL if the call failed.
        void * (operator new)(size_t nSize, LPCSTR lpszFileName, int nLine) 
        { 
            return GdiplusAlloc( nSize, lpszFileName, nLine );
        }
        void (operator delete)(void* pVoid) 
        { 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		pVoid---pVoid, A pointer to the operator delete[])(void or NULL if the call failed.
            GdiplusFree( pVoid, __FILE__, __LINE__ );
        }
        void (operator delete[])(void* pVoid) 
        { 
            GdiplusFree( pVoid, __FILE__, __LINE__ );
        }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		pVoid---pVoid, A pointer to the void or NULL if the call failed.  
	//		lpszFileName---File Name, Specifies a LPCSTR lpszFileName object(Value).  
	//		nLine---nLine, Specifies A integer value.
        void operator delete(void* pVoid, LPCSTR lpszFileName, int nLine) 
        { 
            GdiplusFree( pVoid, lpszFileName, nLine);
        }
#else // _DEBUG

	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdiplus Alloc, .
	// This member function is a static function.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nSize---nSize, Specifies a size_t nSize object(Value).
        static void* __cdecl GdiplusAlloc( size_t nSize )
        {
#ifdef GDIPLUS_USE_GDIPLUS_MEM
            return DllExports::GdipAlloc(nSize); 
#else
            return ::operator new(nSize);
#endif
        }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdiplus Free, .
	// This member function is a static function.
	// Parameters:
	//		pVoid---pVoid, A pointer to the void or NULL if the call failed.
        static void GdiplusFree( void* pVoid )
        {
#ifdef GDIPLUS_USE_GDIPLUS_MEM
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies a operator new)(size_t nSize object(Value).
            DllExports::GdipFree(pVoid); 
#else
            ::operator delete( pVoid );
#endif
        }

        void* (operator new)(size_t nSize) 
        { 
            return GdiplusAlloc( nSize );
        }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies a operator new[])(size_t nSize object(Value).
        void* (operator new[])(size_t nSize) 
        { 
            return GdiplusAlloc( nSize );
        }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		pVoid---pVoid, A pointer to the operator delete)(void or NULL if the call failed.
        void (operator delete)(void* pVoid) 
        { 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A  value (Object).  
	// Parameters:
	//		pVoid---pVoid, A pointer to the operator delete[])(void or NULL if the call failed.
            GdiplusFree( pVoid );
        }
        void (operator delete[])(void* pVoid) 
        { 
            GdiplusFree( pVoid );
        }
#endif
    };
};

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
// zhj
#ifndef ULONG_PTR
#define ULONG_PTR DWORD
#endif
// zhj
#include <Gdiplus.h> 
// zhj
#ifndef _SafeDeletePtr
#define _SafeDeletePtr(ptr)		if(ptr!=NULL) {delete ptr; ptr = NULL;}
#endif
#ifndef _SafeDeletePtrArr
#define _SafeDeletePtrArr(ptr)	if ((ptr) != NULL) { delete [](ptr); (ptr) = NULL; }
#endif
#ifndef _SafeDeletePtrArrBySize
#define _SafeDeletePtrArrBySize(size,ptr) if(size != 0) {delete []ptr; ptr = NULL; size = 0;}
#endif
#include "FOPGDIPlusHelper.h"
// zhj

#ifdef _DEBUG
#undef new
#endif

#pragma comment (lib, "Gdiplus.lib")

namespace Gdiplus
{
 
//===========================================================================
// Summary:
//      To use a GdiPlusInitialize object, just call the constructor.
//      Gdi Plus Initialize
//===========================================================================

    class GdiPlusInitialize
    {
    public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdi Plus Initialize, Constructs a GdiPlusInitialize object.
	//		Returns A  value (Object).
        GdiPlusInitialize()
        {
            GdiplusStartupInput Startup;
            GdiplusStartup( &m_Token, &Startup, NULL );
        }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Gdi Plus Initialize, Destructor of class GdiPlusInitialize
	//		Returns A  value (Object).
        ~GdiPlusInitialize()
        {
			CFOPHokPenCache::DestoryInstance();
			CFOPHokFontCache::DestoryInstance();
			CFOPHokBrushCache::DestoryInstance();
            GdiplusShutdown( m_Token );
        }

    protected:
 
	// Token, Specify a A 32-bit signed integer.  
        ULONG_PTR m_Token;
#ifndef GDIPLUS_NO_AUTO_INIT
 
	// Initialize, This member specify GdiPlusInitialize object.  
        static GdiPlusInitialize m_Initialize;
#endif
    };
#ifndef GDIPLUS_NO_AUTO_INIT
    GdiPlusInitialize GdiPlusInitialize::m_Initialize;
#endif
}

#ifndef GDIPLUS_NO_AUTO_NAMESPACE
using namespace Gdiplus;
#endif

// STL problem
#undef iterator
#undef list
#undef map

#endif
