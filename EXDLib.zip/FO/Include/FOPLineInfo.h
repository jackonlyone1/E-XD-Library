//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLINEINFO_H__6FF5CEE4_1F60_4D49_B4CF_BC8C678050DC__INCLUDED_)
#define AFX_FOPLINEINFO_H__6FF5CEE4_1F60_4D49_B4CF_BC8C678050DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLineInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////////
//
// FOPLineInfo -- line information object.
/////////////////////////////////////////////////////////////////////////////////

#include "FOPUtil.h"
#include "FOPCollect.h"

// Line description
struct FOP_LineDesc
{
	double x,y;
	double slope;
	double c;
};

// Line object
struct FOP_XLine
{
	FOPFloat ptStart;
	FOPFloat ptEnd;
};

// Line object
struct FOP_LineObject
{
	FOPPoint ptStart;
	FOPPoint ptEnd;
};

// Point of control handle.
enum FO_RECT_POINT
{
	RP_LT, RP_MT, RP_RT, RP_LM, RP_MM, RP_RM, RP_LB, RP_MB, RP_RB
};

// Line style
enum FOPLineStyle
{
	FOP_LINE_STYLE_NONE,
	FOP_LINE_STYLE_SOLID,
	FOP_LINE_STYLE_DASH
};

// Line dash style
enum FOPDashStyle
{
	FOP_LINE_DASH_RECT,
	FOP_LINE_DASH_RECTRELATIVE
};

///////////////////////////////////////////////////////////////
// FOPLineInfo -- Line dash information object.

 
//===========================================================================
// Summary:
//     The FOPLineInfo class derived from CObject
//      O P Line Information
//===========================================================================

class FO_EXT_CLASS FOPLineInfo : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPLineInfo---O P Line Information, Specifies a FOPLineInfo object(Value).
	DECLARE_SERIAL(FOPLineInfo);

protected:

	// Pen Width value.
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPenWidth;

	// Pen Style value.
 
	// Pen Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nPenStyle;

	// Line dash style.
 
	// Dash, This member specify FOPDashStyle object.  
	FOPDashStyle	m_eDash;

	// Number of dots.
 
	// Dots, This member specify USHORT object.  
	USHORT			m_nDots;

	// Length of the dot.
 
	// Dot Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDotLength;

	// Number of the dashes.
 
	// Dashes, This member specify USHORT object.  
	USHORT			m_nDashes;

	// Length of the dash.
 
	// Dash Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDashLength;

	// Distance of the dash.
 
	// Distance, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nDistance;

	// Line Width value.
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nLineWidth;

	// Line Color value.
 
	// Line Color, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crLineColor;

	// Fill Color value.
 
	// Fill Color, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crFillColor;

	// Pattern	Color value.
 
	// Pattern Color, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crPatternColor;

	// Fill	Type value.
 
	// Fill Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nFillType;

	// Drawing type.
 
	// Draw Type, This member sets TRUE if it is right.  
	BOOL			m_nDrawType;

public:

	// Constructor.
	// aDash -- dash style,it must be one of the following value:
	// enum FOPDashStyle
	// {
	// 	FOP_LINE_DASH_RECT,
	// 	FOP_LINE_DASH_RECTRELATIVE
	// };
	// nDots -- number of dots.
	// nDotLength -- length of the dot.
	// nDashes -- number of the dashes
	// nDashLength -- length of the dash
	// nDistance -- distance
	/***********************************************************/
	//   Dot  Dashes
	//	  |    |   DL  DSL
	//    |  DSL  | | |  |
	//    -   --   -   --   -   --   -   --
	//   |		  |
	//   |        |
	//   |Distance|
	/***********************************************************/
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Information, Constructs a FOPLineInfo object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aDash---aDash, Specifies a FOPDashStyle aDash = FOP_LINE_DASH_RECT object(Value).  
	//		nDots---nDots, Specifies a USHORT   nDots = 1 object(Value).  
	//		nDotLength---Dot Length, Specifies A integer value.  
	//		nDashes---nDashes, Specifies a USHORT   nDashes = 1 object(Value).  
	//		nDashLength---Dash Length, Specifies A integer value.  
	//		nDistance---nDistance, Specifies A integer value.
	FOPLineInfo(FOPDashStyle	aDash = FOP_LINE_DASH_RECT,
				USHORT			nDots = 1, 
				int				nDotLength = 20, 
				USHORT			nDashes = 1, 
				int				nDashLength = 20, 
				int				nDistance = 20);
	
	// Copy constructor. 
	// source -- target line infomation object
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Information, Constructs a FOPLineInfo object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const FOPLineInfo& source object(Value).
	FOPLineInfo(const FOPLineInfo& source);
	
	// Operator == 
	// aDash -- compare dash object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		aDash---aDash, Specifies a const FOPLineInfo& aDash object(Value).
	int operator==(const FOPLineInfo& aDash) const;

	// Assignment operator.
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLineInfo& value (Object).  
	// Parameters:
	//		source---Specifies a const FOPLineInfo& source object(Value).
	FOPLineInfo& operator=(const FOPLineInfo& source);

	// != operator.
	// rCmp -- compare dash object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rCmp---rCmp, Specifies a const FOPLineInfo& rCmp object(Value).
	BOOL operator!=(const FOPLineInfo& rCmp) const
	{
		return !operator == (rCmp);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPLineInfo,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual FOPLineInfo* Copy() const;

	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

public:
	
	CPoint m_ptStart1;
	CPoint m_ptStart2;
	CPoint m_ptEnd1;
	CPoint m_ptEnd2;

	BOOL	m_bFirst;
	// Return Line Width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetLineWidth() const					{ return m_nLineWidth;}

	// Change Line Width value.
	// nValue -- line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetLineWidth( const int &nValue )		{m_nLineWidth = nValue; }

	// Return Line Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetLineColor() const				{ return m_crLineColor;}

	// Change Line Color value.
	// crColor -- line color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void SetLineColor( const COLORREF &crValue ) {m_crLineColor = crValue; }

	// Return Fill Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFillColor() const				{ return m_crFillColor;}

	// Change Fill Color value.
	// crValue -- fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Color, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void SetFillColor( const COLORREF &crValue ) {m_crFillColor = crValue; }

	// Return Pattern	Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetPatternColor() const			{ return m_crPatternColor;}

	// Change Pattern	Color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void SetPatternColor( const COLORREF &crValue ) {m_crPatternColor = crValue; }

	// Return Fill	Type value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Type, Returns the specified value.
	//		Returns a int type value.
	int GetFillType() const						{ return m_nFillType;}

	// Change Fill	Type value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fill Type, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetFillType( const int &nValue )		{m_nFillType = nValue; }


	// Return draw	Type value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Type, Returns the specified value.
	//		Returns a int type value.
	int GetDrawType() const						{ return m_nDrawType;}

	// Change draw	Type value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Type, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDrawType( const int &nValue )		{m_nDrawType = nValue; }


	// Obtain the dash style,it will returns one of the following value:
	// enum FOPDashStyle
	// {
	// 	FOP_LINE_DASH_RECT,
	// 	FOP_LINE_DASH_RECTRELATIVE
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Style, Returns the specified value.
	//		Returns A FOPDashStyle value (Object).
	FOPDashStyle GetDashStyle() const			{	return m_eDash;	}

	// Change dash style.
	// nNewStyle -- new dash style,it must be one of the following value:
	// enum FOPDashStyle
	// {
	// 	FOP_LINE_DASH_RECT,
	// 	FOP_LINE_DASH_RECTRELATIVE
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Style, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewStyle---New Style, Specifies a FOPDashStyle nNewStyle object(Value).
	void SetDashStyle(FOPDashStyle nNewStyle)	{	m_eDash = nNewStyle;	}


	// Obtain the dash dot
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dots, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetDots() const						{	return m_nDots;	}

	// Change the line dash dot.
	// nNewDots -- total of dots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dots, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewDots---New Dots, Specifies a USHORT nNewDots object(Value).
	void SetDots(USHORT nNewDots)				{	m_nDots = nNewDots;	}


	// Obtain the dot length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dot Length, Returns the specified value.
	//		Returns a int type value.
	int GetDotLength() const					{	return m_nDotLength;	}

	// Change the dot length.
	// nNewDotLength -- new dot length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dot Length, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewDotLength---New Dot Length, Specifies A integer value.
	void SetDotLength(int nNewDotLength)		{	m_nDotLength = nNewDotLength;	}


	// Obtain the dashes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dashes, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetDashes() const					{	return m_nDashes;	  }

	// Change the line dashes
	// nNewDashes -- new dashes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dashes, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewDashes---New Dashes, Specifies a USHORT nNewDashes object(Value).
	void SetDashes(USHORT nNewDashes)			{	m_nDashes = nNewDashes;	}


	// Obtain the dash length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Length, Returns the specified value.
	//		Returns a int type value.
	int GetDashLength() const					{	return m_nDashLength;  }

	// Change the dash length.
	// nNewDashLength -- new dash length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Length, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewDashLength---New Dash Length, Specifies A integer value.
	void SetDashLength(int nNewDashLength)	{	m_nDashLength = nNewDashLength;	}


	// Obtain the line distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns a int type value.
	int GetDistance() const					{	return m_nDistance; }

	// Change the line distance.
	// nNewDistance -- new distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Distance, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		nNewDistance---New Distance, Specifies A integer value.
	void SetDistance(int nNewDistance)		{	m_nDistance = nNewDistance;	}

	// Return Pen Width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
	int GetPenWidth() const						{ return m_nPenWidth;}

	// Change Pen Width value.
	// nValue -- pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPenWidth( const int &nValue )		{ m_nPenWidth = nValue; }

	// Return Pen Style value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Style, Returns the specified value.
	//		Returns a int type value.
	int GetPenStyle() const						{ return m_nPenStyle;}

	// Change Pen Style value.
	// nValue -- pen style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Style, Sets a specify value to current class FOPLineInfo
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPenStyle( const int &nValue )		{ m_nPenStyle = nValue; }

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

///////////////////////////////////////////////////////////////
// FOPLineDashEntry -- Line dash entry.

 
//===========================================================================
// Summary:
//      To use a FOPLineDashEntry object, just call the constructor.
//      O P Line Dash Entry
//===========================================================================

class FO_EXT_CLASS FOPLineDashEntry
{
public:
					// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Dash Entry, Constructs a FOPLineDashEntry object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rDash---rDash, Specifies a const FOPLineInfo& rDash object(Value).  
	//		strName---strName, Specifies A CString type value.
					FOPLineDashEntry(const FOPLineInfo& rDash, const CString& strName) : m_strName(strName), aDash(rDash) {}
					// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Dash Entry, Constructs a FOPLineDashEntry object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rOther---rOther, Specifies a const FOPLineDashEntry& rOther object(Value).
					FOPLineDashEntry(const FOPLineDashEntry& rOther): m_strName(rOther.m_strName), aDash(rOther.aDash) {}
public:

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line Dash Entry, Destructor of class FOPLineDashEntry
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual			~FOPLineDashEntry() {}

	// Change Name of the entry
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Name, Sets a specify value to current class FOPLineDashEntry
	// Parameters:
	//		strName---strName, Specifies A CString type value.
	void			SetName(const CString& strName)		{ m_strName = strName; }

	// Obtain the name of the entry
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Name, Returns the specified value.
	//		Returns a CString type value.
	CString&		GetName()							{ return m_strName; }

	// Change line dash
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash, Sets a specify value to current class FOPLineDashEntry
	// Parameters:
	//		rDash---rDash, Specifies a const FOPLineInfo& rDash object(Value).
	void			SetDash(const FOPLineInfo& rDash)   { aDash = rDash; }

	// Obtain the line dash
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash, Returns the specified value.
	//		Returns A FOPLineInfo& value (Object).
	FOPLineInfo&	GetDash()							{ return aDash; }

protected:
	// Name of the entry
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strName;

	// Dash
 
	// Dash, This member specify FOPLineInfo object.  
	FOPLineInfo		aDash;

};

///////////////////////////////////////////////////////////////
// Line dash entry list

 
//===========================================================================
// Summary:
//      To use a FOPDashEntryList object, just call the constructor.
//      O P Dash Entry List
//===========================================================================

class FO_EXT_CLASS FOPDashEntryList
{
protected:
	// Name of the dash list
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strName;

	// Path string
 
	// Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strPath;

	// List of the entry
 
	// List, This member specify FOPList object.  
	FOPList					m_aList;

	// Modified or not
 
	// Modified, This member sets TRUE if it is right.  
	BOOL					m_bModified;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Dash Entry List, Constructs a FOPDashEntryList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rPath---rPath, Specifies A CString type value.  
	//		nInitSize---Initial Size, Specifies a USHORT nInitSize = 16 object(Value).  
	//		nReSize---Re Size, Specifies a USHORT nReSize = 16 object(Value).
							FOPDashEntryList(  const CString& rPath,
										USHORT nInitSize = 16,
										USHORT nReSize = 16 );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data
	void					Clear();

public:

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Dash Entry List, Destructor of class FOPDashEntryList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual					~FOPDashEntryList();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Count, .
	//		Returns A 32-bit long signed integer.
	// Count
	long					Count() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		pEntry---pEntry, A pointer to the FOPLineDashEntry or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Insert new entry
	void					Insert( FOPLineDashEntry* pEntry, long nIndex = 0xFFFF );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns a pointer to the object FOPLineDashEntry,or NULL if the call failed  
	// Parameters:
	//		pEntry---pEntry, A pointer to the FOPLineDashEntry or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Replace an entry
	FOPLineDashEntry*		Replace( FOPLineDashEntry* pEntry, long nIndex );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object FOPLineDashEntry,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.  
	//		nDummy---nDummy, Specifies a USHORT nDummy object(Value).
	// Remove an entry
	FOPLineDashEntry*		Remove( long nIndex, USHORT nDummy );

	// Obtain an entry
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get, Returns the specified value.
	//		Returns a pointer to the object FOPLineDashEntry,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.  
	//		nDummy---nDummy, Specifies a USHORT nDummy object(Value).
	FOPLineDashEntry*		Get( long nIndex, USHORT nDummy ) const;

	// Obtin with name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		rName---rName, Specifies A CString type value.
	long					Get(const CString& rName);

	// Obtain its name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Name, Returns the specified value.
	//		Returns a CString type value.
	const CString&			GetName() const { return m_strName; }

	// Change name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Name, Sets a specify value to current class FOPDashEntryList
	// Parameters:
	//		rString---rString, Specifies A CString type value.
	void					SetName( const CString& rString );

	// Obtain the path name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path, Returns the specified value.
	//		Returns a CString type value.
	const CString&			GetPath() const { return m_strPath; }

	// Change path name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Path, Sets a specify value to current class FOPDashEntryList
	// Parameters:
	//		rString---rString, Specifies A CString type value.
	void					SetPath( const CString& rString ) { m_strPath = rString; }

	// Is modified or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Dirty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL					IsDirty() const { return m_bModified; }

	// Set modified flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dirty, Sets a specify value to current class FOPDashEntryList
	// Parameters:
	//		bDirty---bDirty, Specifies A Boolean value.
	void					SetDirty( BOOL bDirty = TRUE )
							{ m_bModified = bDirty; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a FOPDashEntryList object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Create
	virtual BOOL			Create();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
	// Load data from file
	virtual BOOL			Load() = 0;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Save, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
	// Save data to file
	virtual BOOL			Save() = 0;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLINEINFO_H__6FF5CEE4_1F60_4D49_B4CF_BC8C678050DC__INCLUDED_)
