//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFC_FOCOLORCELLOBJ_H__F621A685_6C7E_11DF_A470_525400EA266C__INCLUDED_)
#define AFC_FOCOLORCELLOBJ_H__F621A685_6C7E_11DF_A470_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 
//===========================================================================
// Summary:
//     The CFOColorCellObj class derived from CObject
//      F O Color Cell Object
//===========================================================================

class FO_EXT_CLASS CFOColorCellObj : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOColorCellObj---F O Color Cell Object, Specifies a E-XD++ CFOColorCellObj object (Value).
	DECLARE_SERIAL(CFOColorCellObj);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Color Cell Object, Constructs a CFOColorCellObj object.
	//		Returns A  value (Object).
	CFOColorCellObj();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Color Cell Object, Destructor of class CFOColorCellObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOColorCellObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data
	virtual void Serialize(CArchive &ar);

	// Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint point);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draw Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Set Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOColorCellObj
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void	SetItemRect(const CRect &rcPos)			{ m_rcPosition = rcPos; }

	// Get Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const;

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Color, Sets a specify value to current class CFOColorCellObj
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetCellColor(const COLORREF &cr);

	// Set border color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Color, Sets a specify value to current class CFOColorCellObj
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetBorderColor(const COLORREF &cr) { m_crBorder = cr; }

	// Get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetCellColor() const				{ return m_crCell; }

	// Set Cell Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOColorCellObj
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder)	{ nCellBorderSize = nBorder; }

	// Adjust cell position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Cell Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.
	virtual void AdjustCellPosition(int x, int y, int nWidth);

	// Set first type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set First Type, Sets a specify value to current class CFOColorCellObj
	// Parameters:
	//		&bFirst---&bFirst, Specifies A Boolean value.
	void SetFirstType(const BOOL &bFirst) {m_bAtFirstType = bFirst; }

	// Get more near point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// More Near, .
	//		Returns a int type value.  
	// Parameters:
	//		fNear---fNear, Specifies A float value.
	int MoreNear(float fNear);

protected:

	// Position of the cell.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Current cell color.
 
	// Cell, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crCell;

	// Cell border size.
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCellBorderSize;

	// Cell points.
 
	// Points[6], This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_Points[6];

	// Is first type.
 
	// At First Type, This member sets TRUE if it is right.  
	BOOL		m_bAtFirstType;

	// Border color.
 
	// Border, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBorder;

};

//Define type CTypedPtrList
typedef CTypedPtrList<CObList, CFOColorCellObj*> CFOColorCellObjList;

#endif // !defined(AFC_FOCOLORCELLOBJ_H__F621A685_6C7E_11DF_A470_525400EA266C__INCLUDED_)
