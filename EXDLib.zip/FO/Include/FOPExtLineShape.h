#if !defined(FO_FOPEXTLINESHAPE_H__556D9C40_7C6C_435A_839E_93E09821E2ED__INCLUDED_)
#define AFC_FOPEXTLINESHAPE_H__556D9C40_7C6C_435A_839E_93E09821E2ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author.
//------------------------------------------------------

#include "FOBaseEndObject.h"
#include "FODrawShape.h"

///////////////////////////////////////////////////////////
// CFOPExtLineShape -- extend line shape, ID: FOP_EXTEND_LINE 204

 
//===========================================================================
// Summary:
//     The CFOPExtLineShape class derived from CFODrawShape
//      F O P Extend Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPExtLineShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPExtLineShape---F O P Extend Line Shape, Specifies a E-XD++ CFOPExtLineShape object (Value).
	DECLARE_SERIAL(CFOPExtLineShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Extend Line Shape, Constructs a CFOPExtLineShape object.
	//		Returns A  value (Object).
	CFOPExtLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Extend Line Shape, Constructs a CFOPExtLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPExtLineShape& src object(Value).
	CFOPExtLineShape(const CFOPExtLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Extend Line Shape, Destructor of class CFOPExtLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPExtLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Creates the extend line shape from points.
	// ptArray -- points of line.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// Create the extend line shape from the points.
	// pptPoints -- points of line.
	// nCount -- total points of shape.
	BOOL Create(LPPOINT pptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	
	// Is current shape to be closed or not.
	BOOL IsClosed() const { return m_bClose; }
	
	// Set current shape to be closed mode.
	void SetClosed(const BOOL &bClose) { m_bClose = bClose; }

	// Get the point of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Convert to polygon.
	// Need call delete by hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPolygon value (Object).
	virtual FOPPolygon ConvertToPolygon();

	// Return Dots value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dots, Returns the specified value.
	//		Returns a int type value.
	int GetDots();
	
	// Change Dots value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dots, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDots( const int &nValue );
	
	// Return DotLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dot Length, Returns the specified value.
	//		Returns a int type value.
	int GetDotLength();
	
	// Change DotLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dot Length, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDotLength( const int &nValue );
	
	// Return Dashes value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dashes, Returns the specified value.
	//		Returns a int type value.
	int GetDashes();
	
	// Change Dashes value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dashes, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashes( const int &nValue );
	
	// Return DashLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Length, Returns the specified value.
	//		Returns a int type value.
	int GetDashLength();
	
	// Change DashLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Length, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashLength( const int &nValue );
	
	// Return Distance value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Distance, Returns the specified value.
	//		Returns a int type value.
	int GetDashDistance();
	
	// Change Distance value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Distance, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashDistance( const int &nValue );
	
	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetNewLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Line Width, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetNewLineWidth( const int &nValue );

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPExtLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPExtLineShape& src object(Value).
	CFOPExtLineShape& operator=(const CFOPExtLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

public:

	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOPExtLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }


	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOPExtLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Is or no m_UpRightMode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Up Right Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsUpRightMode() const;
	
	// Set m_UpRightMode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Up Right Mode, Sets a specify value to current class CFOPExtLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bUpRightMode---Up Right Mode, Specifies A Boolean value.
	virtual void SetUpRightMode(BOOL bUpRightMode);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Is zhi line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Zhi Line, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsZhiLine();

	// Obtain the total length of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Length, Returns the specified value.
	//		Returns a int type value.
	int GetTotalLength();

	// Obtain the line info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Information, Returns the specified value.
	//		Returns A FOPLineInfo value (Object).
	FOPLineInfo GetLineInfo() const { return m_aLineInfo; }

	// Change the line info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Information, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&LineInfo---Line Information, Specifies a const FOPLineInfo &LineInfo object(Value).
	void SetLineInfo(const FOPLineInfo &LineInfo);

	// Return Show Center Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Center Line, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetShowCenterLine() const { return m_bShowCenterLine;}

	// Change Show Center Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Center Line, Sets a specify value to current class CFOPExtLineShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetShowCenterLine( const BOOL &bValue ) {m_bShowCenterLine = bValue; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Create zhi line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Up Right Mode Line, You construct a CFOPExtLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CreateUpRightModeLine();

	// Get current point with a specify handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		nControlPoint---Point, Specifies A integer value.
	virtual CPoint GetCurrentPoint(const CRect& rcPos, FO_CONTROL_HANDLE nControlPoint);


public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

protected:

	// Close or not
	BOOL				m_bClose;

	// Extend line information.
 
	// Line Information, This member specify FOPLineInfo object.  
	FOPLineInfo			m_aLineInfo;

	// Show Center Line value.
 
	// Show Center Line, This member sets TRUE if it is right.  
	BOOL                m_bShowCenterLine;

	// Converting polygon.
 
	// Convert Polygon, This member specify FOPPolygon object.  
	FOPPolygon			m_aConvertPoly;
};

//------------------------------------------------------
// Description: Liquid line shape, ID: FO_COMP_LIQUID_LINESHAPE 269
// Author: Author. class CFOPLiquidLineShape
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPLiquidLineShape class derived from CFOPExtLineShape
//      F O P Liquid Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPLiquidLineShape : public CFOPExtLineShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLiquidLineShape---F O P Liquid Line Shape, Specifies a E-XD++ CFOPLiquidLineShape object (Value).
	DECLARE_SERIAL(CFOPLiquidLineShape);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Liquid Line Shape, Constructs a CFOPLiquidLineShape object.
	//		Returns A  value (Object).
	CFOPLiquidLineShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Liquid Line Shape, Constructs a CFOPLiquidLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPLiquidLineShape& src object(Value).
	CFOPLiquidLineShape(const CFOPLiquidLineShape& src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Liquid Line Shape, Destructor of class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLiquidLineShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPLiquidLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Create the bezier line shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPLiquidLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount);
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPLiquidLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPLiquidLineShape& src object(Value).
	CFOPLiquidLineShape& operator=(const CFOPLiquidLineShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Convert to polygon.
	// Need call delete by hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPolygon value (Object).
	virtual FOPPolygon ConvertToPolygon();

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Set with move state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set With Move State, Sets a specify value to current class CFOPLiquidLineShape
	// Parameters:
	//		&nState---&nState, Specifies A integer value.
	void SetWithMoveState(const int &nState) { m_nWithMoveState = nState; }

	// Get with move state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is With Move State, Determines if the given value is correct or exist.
	//		Returns a int type value.
	int IsWithMoveState() const { return m_nWithMoveState; }

	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();
	
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOPLiquidLineShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);

public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
 
	// With Move State, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nWithMoveState;

	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current timer speed, default is 400
 
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;

	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

};

//------------------------------------------------------
// Description
// Author: Author.
//------------------------------------------------------

class FO_EXT_CLASS CFOPNewPolyLineShape : public CFOPExtLineShape  
{
protected:
	DECLARE_SERIAL(CFOPNewPolyLineShape);
public:
	
	// constructor
	CFOPNewPolyLineShape();
	
	// Copy constructor.
	CFOPNewPolyLineShape(const CFOPNewPolyLineShape& src);
	
	// Destructor.
	virtual ~CFOPNewPolyLineShape();
	
	// Create the bezier line shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount);
	
public:
	
	// Assignment operator.
	CFOPNewPolyLineShape& operator=(const CFOPNewPolyLineShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Convert to polygon.
	// Need call delete by hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPolygon value (Object).
	virtual FOPPolygon ConvertToPolygon();

	// Convert to polygon.
	// Need call delete by hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Polygon, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPPolygon value (Object).
	virtual FOPPolygon ConvertToTrackPolygon();

	// Obtain the start point arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Arrow Cut Length, Returns the specified value.
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void GetTrackStartArrowCutLength(FOPPoint &ptStart, const int &nArrowLen = 0);
	
	// Obtain the end point arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Arrow Cut Length, Returns the specified value.
	// Parameters:
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void GetTrackEndArrowCutLength(FOPPoint &ptEnd, const int &nArrowLen = 0);
	
	// Implementation
	
	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// mpSpot -- result of the spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object.
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get the sport point of control by edit point,override this method to calculate your own new control handle.
	// mpSpot -- control handles list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetUserHandles(CFOPHandleList& lstHandle);
	
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset User Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetUserAnchorPoint(const int &nPtIndex, const CPoint &ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset User Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetUserAnchorPoint(const int &nPtIndex, const CPoint &ptOffset);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Build current line end object.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	virtual void BuildLineStartObject(int &nType);
	
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	double GetOutLen(const int &nAngle, int nLength);

	void SetArrowAngle1(const int &nAngle, BOOL bUpdate = TRUE);
	void SetArrowAngle2(const int &nAngle, BOOL bUpdate = TRUE);

	void SetArrowType1(const int &nType);
	void SetArrowType2(const int &nType);
public:
	
	int m_nArrowAngle1;
	int m_nArrowAngle2;
	int m_nXiangDuiAngle1;
	int m_nXiangDuiAngle2;
	CFOArea maArea;

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BOOL m_bTrackNow;
	int m_nTempLineWidth;
	
};

#endif // !defined(AFC_FOPEXTLINESHAPE_H__556D9C40_7C6C_435A_839E_93E09821E2ED__INCLUDED_)
