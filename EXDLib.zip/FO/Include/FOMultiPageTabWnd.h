//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOMULTIPAGETABWND_H__CB8CC9E9_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
#define AFX_FOMULTIPAGETABWND_H__CB8CC9E9_FAA6_11D5_A4DF_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOMultiPageTabWnd.h : header file
//

#include "FOTabPageModel.h"
#include "FOTabControlWnd.h"
#include "FOTabModelManager.h"
#include "FOPMenuWndImpl.h"

class CFOTabPageWnd;
 
//===========================================================================
// Summary:
//     The CFOMultiPageTabWnd class derived from CWnd
//      F O Multiple Page Tab Window
//===========================================================================

class FO_EXT_CLASS CFOMultiPageTabWnd : public CWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiPageTabWnd---F O Multiple Page Tab Window, Specifies a E-XD++ CFOMultiPageTabWnd object (Value).
	DECLARE_DYNCREATE(CFOMultiPageTabWnd)

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page Tab Window, Constructs a CFOMultiPageTabWnd object.
	//		Returns A  value (Object).
	CFOMultiPageTabWnd();
	
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Page Tab Window, Destructor of class CFOMultiPageTabWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiPageTabWnd();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		*pManager---*pManager, A pointer to the CFOTabModelManager  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a tab.
	BOOL Create(
		// Pointer of parent wnd.
		CWnd* pParentWnd,
		// Pointer of tab model manager.
		CFOTabModelManager *pManager,
		// Pointer of Context.
		CCreateContext* pContext = NULL,
		// Style.
		DWORD dwStyle = WS_CHILD | WS_VISIBLE |WS_HSCROLL | WS_VSCROLL,
		// Specify a ID.
		UINT nID = AFX_IDW_PANE_FIRST
		);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		*pManager---*pManager, A pointer to the CFOTabModelManager  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a tab.
	BOOL Create(
		// Pointer of parent wnd.
		CWnd* pParentWnd,
		// Pointer of tab model manager.
		CFOTabModelManager *pManager,
		// Pointer of Context.
		const CRect &rcPos,
		// Style.
		DWORD dwStyle = WS_CHILD | WS_VISIBLE |WS_HSCROLL | WS_VSCROLL,
		// Specify a ID.
		UINT nID = AFX_IDW_PANE_FIRST
		);

	// Attach wnd
	// pWnd -- pointer of the wnd.
	// pModel -- pointer of the model
	// lpszLabel -- label text
	// bAutoRemove -- destroy the window pointer or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Window, Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOTabPageModel  or NULL if the call failed.  
	//		lpszLabel---lpszLabel, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&bAutoRemove---Automatic Remove, Specifies A Boolean value.
	virtual CWnd* AttachWnd(CWnd* pWnd,CFOTabPageModel *pModel, 
		LPCTSTR lpszLabel,const BOOL &bAutoRemove = FALSE);

protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiToolBoxWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL	

public:
	
	// Create new page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Page, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		strCaption---strCaption, Specifies A CString type value.  
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* CreateNewPage(
		// Caption of new page.
		CString strCaption, 
		// Tab page model.
		CFOTabPageModel*pModel,
		// Pointer of context.
		CCreateContext* pContext = NULL,
		// Specify a ID.
		UINT nID = 0
		);

	// Create new page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Page2, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		strCaption---strCaption, Specifies A CString type value.  
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* CreateNewPage2(
		// Caption of new page.
		CString strCaption, 
		// Tab page model.
		CFOTabPageModel*pModel,
		// Specify a ID.
		UINT nID = 0
		);

	// Override this to hook in a CFOToolBoxPageWnd derived object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create New Page Window, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageWnd,or NULL if the call failed
	virtual CFOTabPageWnd* DoCreateNewPageWnd();

	// Add a new page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Page, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* InsertPage(
		// Specify the pointer of TAB page model.
		CFOTabPageModel*pModel,
		// Pointer of context.
		CCreateContext* pContext,
		// Control ID.
		UINT nID = 0
		);

	// Add a new page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Page2, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* InsertPage2(
		// Specify the pointer of TAB page model.
		CFOTabPageModel*pModel,
		// Control ID.
		UINT nID = 0
		);
	
	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paint Border, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		clr---Specifies A 32-bit COLORREF value used as a color value.
	void PaintBorder(CDC* pDC, int x, int y, int cx, int cy, COLORREF clr);

	// Get current page model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed
	virtual CFOTabPageModel* GetCurrentModel();

	// Get current page model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual CFOTabPageModel* GetModel(int nTab);

	// Get model manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Manager, Returns the specified value.
	//		Returns a pointer to the object CFOTabModelManager ,or NULL if the call failed
	CFOTabModelManager *GetModelManager() const;

	// Set model manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model Manager, Sets a specify value to current class CFOMultiPageTabWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pManager---*pManager, A pointer to the CFOTabModelManager  or NULL if the call failed.
	virtual void SetModelManager(CFOTabModelManager *pManager );

	// Temp method.
	void DoHelpMethod1();

	// Temp method.
	void DoHelpMethod2();

	// Temp method.
	void DoHelpMethod3(DWORD dwStyle);

	// create context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();

	// Enable or not the context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Context Menu, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableContextMenu(const BOOL &bEnable);

	// Get current page number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetActiveTab();

	// Returns the number of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	//		Returns a int type value.
	int     GetTabCount() const;
	
	// Get activate tab label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Label, Returns the specified value.
	//		Returns a CString type value.
	CString GetActiveTabLabel();

	// Change activate tab label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Label, Sets a specify value to current class CFOMultiPageTabWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	virtual BOOL SetActiveTabLabel(CString strText);

	// Do change activate tab label.
	// Only using for Edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Active Tab Label, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	virtual BOOL DoChangeActiveTabLabel(CString strText);

	// Find tab by label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual BOOL FindTab(CString strLabel);

	// Find tab by label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual int FindTabIndex(CString strLabel);

	// Returns the label of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Label, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CString GetTabLabel(int nTab);

	// Returns the label of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Label, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the const CWnd or NULL if the call failed.
	CString GetTabLabel(const CWnd* pWnd);
	
	// Sets the label of the specified tab.
	// nTab -- index of tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Label, Sets a specify value to current class CFOMultiPageTabWnd
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strLabel---strLabel, Specifies A CString type value.
	void SetTabLabel(int nTab, CString strLabel);

	// Sets the label of the specified tab.
	// pWnd -- the pointer of tab window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Label, Sets a specify value to current class CFOMultiPageTabWnd
	// Parameters:
	//		pWnd---pWnd, A pointer to the const CWnd or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.
	void SetTabLabel(const CWnd* pWnd, CString strLabel);

	// Get tab control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab , Returns the specified value.
	//		Returns a pointer to the object CFOTabControlWnd,or NULL if the call failed
	CFOTabControlWnd* GetTabControl();

	// Get active tab wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Window, Returns the specified value.
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	CWnd* GetActiveWnd();

	// Set current active tab.
	// nTab -- the index of tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab, Sets a specify value to current class CFOMultiPageTabWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void SetActiveTab(int nTab);

	// Set current active tab.
	// pWnd -- the pointer of tab wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab, Sets a specify value to current class CFOMultiPageTabWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void SetActiveTab(CWnd* pWnd);
	
	// Remove tab.
	// nTab -- tab index to remove.
	// bNeedTips -- if need show tips messagebox it is true,else it is false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		bNeedTips---Need Tips, Specifies A Boolean value.
	virtual BOOL RemoveTab(int nTab, BOOL bNeedTips = TRUE);

	// Remove tab.
	// pWnd -- the pointer of wnd.
	// bNeedTips -- if need show tips messagebox it is true,else it is false.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		bNeedTips---Need Tips, Specifies A Boolean value.
	virtual BOOL RemoveTab(CWnd* pWnd, BOOL bNeedTips = TRUE);

protected:

	// Save tab state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Tab State, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void SaveTabState(CWnd* pWnd);

	// Load tab state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tab State, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	virtual void LoadTabState(CWnd* pWnd);

	// Create a sheet page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Sheet, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL CreateSheet(CWnd* pParent, DWORD dwStyle, UINT nID);

	// Create scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Scroll Bars, You construct a CFOMultiPageTabWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL CreateScrollBars(DWORD dwStyle, UINT nID);

	// Adjust size of tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	virtual void RecalcLayout(BOOL bRedraw = FALSE);

	// Get tab holder rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Inside Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void CalcInsideRect(CRect& rect) const;
	
	// Draw tab boundy.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Buddy, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual void OnDrawBuddy(CDC* pDC, const CRect& rcPos);

	// Do start double click label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Double Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.
	virtual void DoStartDoubleClick(WPARAM wParam);

protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	// Generated message map functions
	//{{AFX_MSG(CFOMultiPageTabWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Paint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnNcPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Active Tab, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnActiveTab(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Deactivate Tab, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeactivateTab(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnStartEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCancelEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnFinishEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll, Called when the user clicks the horizontal scroll bar of CWnd.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Add Newpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAddNewpage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Add Newpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAddNewpage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Remove Page, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRemovePage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRemovePage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Page Caption, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPageCaption();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Page Caption, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPageCaption(CCmdUI* pCmdUI);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// Tab control pointer.
 
	// Tab , This member maintains a pointer to the object CFOTabControlWnd.  
	CFOTabControlWnd* m_pTabControl;
	
	// Current select tab page wnd.
 
	// Current Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			m_pCurrentWnd;
	
	// context menu pointer
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*			m_pContextMenu;		
	
	// Handle of tab model manager.
 
	// Model Manager, This member maintains a pointer to the object CFOTabModelManager.  
	CFOTabModelManager *m_pModelManager;
	
private:
	
 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOMULTIPAGETABWND_H__CB8CC9E9_FAA6_11D5_A4DF_525400EA266C__INCLUDED_)
