//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOGROUPACTION_H__FC765E83_C623_11D5_A487_525400EA266C__INCLUDED_)
#define AFC_FOGROUPACTION_H__FC765E83_C623_11D5_A487_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action for multi shapes
///////////////////////////////////////
#include "FOAction.h"
#include "FOGroupShape.h"
#include "FOActionMacro.h"

class CFOCompositeShape;
//////////////////////////////////////////////////////////////////////////////////
// CFOGroupAction -- action that defined for group the selection shapes on the canvas

 
//===========================================================================
// Summary:
//     The CFOGroupAction class derived from CFOAction
//      F O Group Action
//===========================================================================

class FO_EXT_CLASS CFOGroupAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOGroupAction---F O Group Action, Specifies a E-XD++ CFOGroupAction object (Value).
	DECLARE_ACTION(CFOGroupAction)

public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Group Action, Constructs a CFOGroupAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOGroupAction(CFODataModel* pModel);

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Group Action, Destructor of class CFOGroupAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOGroupAction();
// Overrides
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get the list shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*list---A pointer to the CFODrawShapeList  or NULL if the call failed.
	virtual void AddShapes(CFODrawShapeList *list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*list---A pointer to the CFODrawShapeSet  or NULL if the call failed.
	virtual void AddShapes(CFODrawShapeSet *list);

	// Remove all shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get a pointer to the group created by the action. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Group Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed
	CFOCompositeShape* GetGroupShape();

	// Set the group shape used by the action. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shape, Sets a specify value to current class CFOGroupAction
	// Parameters:
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	void SetGroupShape(CFOCompositeShape* pGroup);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Group, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	// Add a list of shapes to a group shape.
	// list -- a list of shapes.
	// pGroup -- the pointer of group shape.
	virtual BOOL			Group(const CFODrawShapeList& list, CFOCompositeShape* pGroup);
	
	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOGroupAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
	// Remove all order number.
	void RmeoveAllOrders();

	// Get order.
	BOOL GetOrder(CFODrawShape* pComp, int& nIndex) const;

	// Set order.
	void SetOrder(CFODrawShape* pComp, int nIndex);
	
	// Update indexes.
	void UpdateIndices(CFODrawShapeList* pCompSet);

	// Attributes

	// map orders.
	FOPShapeOrderMap m_mapIndices;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes
protected:

	// Shape list.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList		m_listShapes;

	// Back list of shape.
 
	// Back List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList		m_BackList;

	// Pointer of group shape
 
	// Group, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape*			m_pGroup;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
	// FODO:Add your code here.
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

//////////////////////////////////////////////////////////////////////////////////
// CFOMultiGroupAction -- action that defined for multiple group actions.

 
//===========================================================================
// Summary:
//     The CFOMultiGroupAction class derived from CFOActionMacro
//      F O Multiple Group Action
//===========================================================================

class FO_EXT_CLASS CFOMultiGroupAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiGroupAction---F O Multiple Group Action, Specifies a E-XD++ CFOMultiGroupAction object (Value).
	DECLARE_ACTION(CFOMultiGroupAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Group Action, Constructs a CFOMultiGroupAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOMultiGroupAction(CFODataModel* pModel);
	// Attributes

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	// Add shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOGroupAction  or NULL if the call failed.
	virtual void AddAction(CFOGroupAction *pAction);

	// Get full list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	virtual void GetShapesList(CFODrawShapeList *pList);

	// Attributes
protected:

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFC_FOGROUPACTION_H__FC765E83_C623_11D5_A487_525400EA266C__INCLUDED_)
