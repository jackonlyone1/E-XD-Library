//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOOrderAction.h: interface for the CFOOrderAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOORDERACTION_H__5D3EDD1A_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOORDERACTION_H__5D3EDD1A_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOActionMacro.h"
#include "FOOrderSingleAction.h"

///////////////////////////////////////////////////////////////////
// Orderment type: CFOOrderAction -- action that change the layer of multiple shapes.
// Define for class CFOOrderAction
///////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOOrderAction class derived from CFOActionMacro
//      F O Order Action
//===========================================================================

class FO_EXT_CLASS CFOOrderAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOOrderAction---F O Order Action, Specifies a E-XD++ CFOOrderAction object (Value).
	DECLARE_ACTION(CFOOrderAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Order Action, Constructs a CFOOrderAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOOrderAction(CFODataModel* pModel);

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	// Add shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObj---*pObj, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nOrderment---nOrderment, Specifies a OrderFlag& nOrderment object(Value).
	virtual void AddShape(CFODrawShape *pObj,OrderFlag& nOrderment);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		nOrderment---nOrderment, Specifies a OrderFlag& nOrderment object(Value).
	virtual void AddShapes(CFODrawShapeList &list,OrderFlag& nOrderment);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).  
	//		nOrderment---nOrderment, Specifies a OrderFlag& nOrderment object(Value).
	virtual void AddShapes(CFODrawShapeSet &list,OrderFlag& nOrderment);

	// Attributes
protected:

	// List of shapes
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};


#endif // !defined(AFX_FOORDERACTION_H__5D3EDD1A_F259_11DD_A433_525400EA266C__INCLUDED_)
