//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDOCKBAR_H__A149FDAD_E1A1_421F_AA06_25C33B639744__INCLUDED_)
#define AFX_FOPDOCKBAR_H__A149FDAD_E1A1_421F_AA06_25C33B639744__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDockBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPDockBar window
#include <afxpriv.h>

// Style of the controlbar.
static const DWORD  CBRS_FOP_SIZE		=	0x0001L;
static const DWORD  CBRS_FOP_RECTIONAL	=	0x0002L;
static const DWORD  CBRS_FOP_BORDER		=	0x0004L;
static const DWORD  CBRS_FOP_BDSP		=	0x0008L;
static const DWORD  CBRS_FOP_FIT		=	0x0010L;
static const DWORD  CBRS_FOP_FULL		=	0x0020L;
static const DWORD  CBRS_FOP_COOLBORDER	=	0x0040L;
static const DWORD  CBRS_FOP_BTN		=	0x0080L;
static const DWORD  CBRS_FOP_BTN_CLOSE	=	0x0100L;
static const DWORD  CBRS_FOP_BTN_EXPAND	=	0x0200L;
static const DWORD  CBRS_FOP_TRANS		=	0x0400L;
static const DWORD	CBRS_FOP_WITHBTNS	=	0x0100L | 0x0200L;
static const DWORD  CBRS_FOP_DEFAULT	=	0x0040L | 0x0080L | 0x0100L | 0x0200L;
 
//===========================================================================
// Summary:
//      To use a CFOPDockData object, just call the constructor.
//      F O P Dock Data
//===========================================================================

class FO_EXT_CLASS CFOPDockData
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	// col -- value of the column
	// row -- value of the rows
	// flag -- Dock flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Dock Data, Constructs a CFOPDockData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		col---Specifies A integer value.  
	//		row---Specifies A integer value.  
	//		flag---Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	CFOPDockData(int nCol = 0, int nRow = 0, DWORD nFlag = 0);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Dock Data, Destructor of class CFOPDockData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDockData() {}

public:
	// Number of rows.
 
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRows;

	// Number of coloumns.
 
	// Columns, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nColumns;

	// Flags.
 
	// Flags, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_aValue1;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDockContext frame

class CFOPControlBar;
 
//===========================================================================
// Summary:
//     The CFOPDockContext class derived from CDockContext
//      F O P Dock Context
//===========================================================================

class FO_EXT_CLASS CFOPDockContext : public CDockContext
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Dock Context, Constructs a CFOPDockContext object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.
	CFOPDockContext(CControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Dock Context, Destructor of class CFOPDockContext
	//		Returns A  value (Object).
	~CFOPDockContext();

public:

	// Toggle docking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Toggle Docking, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ToggleDocking();

	// Do temp method1.
	void DoTTTempMethod1();

	// Do temp method
	void DoTTTempMethod2();

	// Do temp method
	BOOL DoTTTempMethod3();

	// Do temp method
	DWORD DoTTTempMethod4(DWORD &dwDock, DWORD dwCurr);

	// Do temp method
	void DoTTTempMethod5();


	// Do temp method
	void DoTTTempMethod6(int nLength, DWORD dwMode);

	// Do temp method
	void DoTTTempMethod7(CSize size);

	// Do temp method
	void DoTTTempMethod8();

	// Do temp method
	void DoTTTempMethod9();

	// Do temp method
	void DoTTTempMethod10();

	// Start draging.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Drag, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual void StartDrag(CPoint pt);

	//-----------------------------------------------------------------------
	// Summary:
	void DoMethod1(const CPoint &pt);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		pt---Specifies A CPoint type value.
	// Move docking.
	void Move(CPoint pt);

	// End draging.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Drag, .

	void EndDrag();

	// Do end drag event.
	
	//-----------------------------------------------------------------------
	// Summary:
	void DoMethod2();
	
	// Start resizing.
	// nHitTest -- hit test flag.
	// pt -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Resize, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nHitTest---Hit Test, Specifies A integer value.  
	//		ptA---Specifies A CPoint type value.
	virtual void StartResize(int nHitTest, CPoint ptA);

	// Do resizing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resizing, Do a event. 
	// Parameters:
	//		&rect---Specifies A CRect type value.  
	//		&ptA---Specifies A CPoint type value.
	void DoResizing(const CRect &rect, const CPoint &ptA);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Stretch, .
	// Parameters:
	//		ptA---Specifies A CPoint type value.
	// Stretch.
	void Stretch(CPoint ptApt);

	// Do stretch base bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	void DoMethod3(CPoint &ptA);

	// Do stretch normal bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	void DoMethod4(CPoint &ptA);

	// End resizing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Resize, .

	void EndResize();

	// Cancel loop.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cancel Loop, .
	void CancelLoop();
	
public:

	// Tracing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL Track();

	// Draw focus rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Focus Rectangle, Draws current object to the specify device.
	// Parameters:
	//		bDraw---Remove Rectangle, Specifies A Boolean value.
	void DrawFocusRect(BOOL bDraw = FALSE);

	// Can dock or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Dock, .
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD CanDock();

protected:
	// Value
	CRect		m_aTempValue5;

	// Value
	CPoint		m_ptValue1;

	// Value
	CPoint		m_aTempValue4;

	// Value
	int			m_aTempValue3;

	// Value
	CSize		m_aTempValue2;

	// Value
	CSize		m_aTempValue1;

	friend class CFOPControlBar;
};
 
//===========================================================================
// Summary:
//     The CFOPGripButton class derived from CObject
//      F O P Grip Button
//===========================================================================

class FO_EXT_CLASS CFOPGripButton : public CObject
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grip Button, Constructs a CFOPGripButton object.
	//		Returns A  value (Object).
	CFOPGripButton();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Grip Button, Destructor of class CFOPGripButton
	//		Returns A  value (Object).
	virtual ~CFOPGripButton();
	
	// Get width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetWidth();

	// Get height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetHeight();
	
public:

	// Value
	int			m_aTempValue11;

	// Value
	int			m_aTempValue10;

	// Value
	int			m_aTempValue9;

	// Value
	int			m_aTempValue8;

	// Value
	int			m_aTempValue7;

	// Value
	int			m_aTempValue6;

	// Value
	int			m_aTempValue5;

	// Value
	int			m_aTempValue4;

	// Value
	int			m_aTempValue3;

	// Value
	int			m_aTempValue2;

	// Value
	int			m_aTempValue1;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPClientBorder

 
//===========================================================================
// Summary:
//     The CFOPClientBorder class derived from CObject
//      F O P Client Border
//===========================================================================

class FO_EXT_CLASS CFOPClientBorder : public CObject
{
	
public:

	// Layout flags.
	enum foBarLayout { foHorz, foVert };

	// Row states
	enum foRowState { foRowClientBorder, foBarClientBorder };
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// F O P Client Border, Constructs a CFOPClientBorder object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aState---Specifies a RowState state object(Value).  
	//		aLay---Specifies a BarLayout layout object(Value).  
	//		rcRect---Specifies a const RECT & rc object(Value).
	CFOPClientBorder(foRowState aState, foBarLayout aLay, const RECT & rcRect);

	// Destructor.
	virtual ~CFOPClientBorder();
	
public:

	// Border width.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static const int		cx;

	// Border height.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static const int		cy;

protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		pWnd---Window Clipboard To, A pointer to the CWnd  or NULL if the call failed.  
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		pWnd2---pWnd, A pointer to the CWnd  or NULL if the call failed.
	void DoMethod3(LPCRECT lpRect,CWnd * pWnd, CDC * pDC, CWnd * pWnd2);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	// Drawing.
	virtual void Draw(CDC * pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoMethod2(CDC *pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoMethod1(CDC *pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Track, .
	//		Returns a int type value.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		ptDrag---Specifies A CPoint type value.  
	//		pWndTo---Window Clipboard To, A pointer to the CWnd  or NULL if the call failed.
	// Tracking.
	int Track(CWnd * pWnd, CPoint ptDrag, CWnd * pWndTo);

public:
	
	class Private;
	Private *m_d;	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPClientEdge

 
//===========================================================================
// Summary:
//     The CFOPClientEdge class derived from CObject
//      F O P Client Edge
//===========================================================================

class FO_EXT_CLASS CFOPClientEdge : public CObject
{
	
public:
	enum foBarLayout { foHorizontal, foVertical };
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Client Edge, Constructs a CFOPClientEdge object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aLay---Specifies a BarLayout layout object(Value).  
	//		aRect---Specifies a const RECT & rect object(Value).
	CFOPClientEdge(foBarLayout aLay, const RECT & aRect);

	// Destructor.
	virtual ~CFOPClientEdge();

public:

	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static const int cx;

	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static const int cy;
	
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	// Drawing.
	virtual void Draw(CDC * pDC);

public:

	class Private;
	Private *m_d;
};


/////////////////////////////////////////////////////////////////////////////
// CFOPDockBar window

#define FOP_CTRL_FIRST			(0xE001)
#define FOP_CTRL_LAST			(0xE0FF)

#include "FOPMenuWndImpl.h"

//===========================================================================
// Summary:
//     The CFOPDockBar class derived from CDockBar
//      F O P Dock Bar
//===========================================================================

class FO_EXT_CLASS CFOPDockBar : public CDockBar
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPDockBar---F O P Dock Bar, Specifies a E-XD++ CFOPDockBar object (Value).
	DECLARE_DYNCREATE(CFOPDockBar)
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	/// Constructor.	
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Dock Bar, Constructs a CFOPDockBar object.
	//		Returns A  value (Object).  
	// Parameters:
	//		bFloat---bFloating, Specifies A Boolean value.
	CFOPDockBar(BOOL bFloat = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	/// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Dock Bar, Destructor of class CFOPDockBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDockBar();
	
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		msg---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT msg, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nID);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();

public:

	//-----------------------------------------------------------------------
	// Summary:
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBar---pBar, A pointer to the CFOPControlBar  or NULL if the call failed.
	virtual BOOL DoMethod25(CFOPControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CFOPControlBar  or NULL if the call failed.
	virtual BOOL DoMethod24(CFOPControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.  
	//		nRow---nRow, Specifies A integer value.  
	//		nCol---nCol, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	BOOL DoMethod23(CControlBar* pBar, int& nRow, int& nCol, int& nHeight);	

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDockBar object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create new dock bar.
	// pParentWnd -- pointer of the parent wnd.
	// dwStyle -- style of the docking bar.
	// nID -- id value of the docking bar.
	BOOL Create(CWnd * pParentWnd, DWORD dwStyle, UINT nID);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDockBar object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create new dock bar.
	// pParentWnd -- pointer of the parent wnd.
	// dwStyle -- style of the docking bar.
	// dwExStyle -- extend style of the docking bar.
	// nID -- id value of the docking bar
	BOOL Create(CWnd * pParentWnd, DWORD dwStyle, DWORD dwExStyle, UINT nID);
	

	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(CControlBar * pBar, LPCRECT lpRect = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		lstList---lstList, Specifies a CPtrList & lstList object(Value).  
	//		pBar---pBar, A pointer to the CFOPControlBar  or NULL if the call failed.
	virtual BOOL DoMethod22(CPtrList & lstList, CFOPControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CFOPControlBar  or NULL if the call failed.  
	//		nType---nType, Specifies a USHORT nType object(Value).
	virtual void DoMethod21(CFOPControlBar * pBar, USHORT nType);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoPaint(CDC * pDC);


	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rc---Specifies A CRect type value.
	void DoMethod20(CDC* pDC, CRect& rc);


	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.
	void DoMethod19(CControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void DoMethod19(int nPos);

	//-----------------------------------------------------------------------
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoMethod18(CDC *pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPosRow---Position Row, Specifies A integer value.
	void DoMethod17(int nPosRow);

	//-----------------------------------------------------------------------
	// Summary:
	// Do Hide Bar, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.
	virtual void DoMethod16(CControlBar * pBar);

	//-----------------------------------------------------------------------
	// Summary:
	virtual void DoMethod15();

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOPClientBorder ,or NULL if the call failed  
	// Parameters:
	//		ptHit---Specifies A CPoint type value.
	CFOPClientBorder * HitTest(CPoint ptHit);


	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pClient---pClient, A pointer to the CFOPClientBorder  or NULL if the call failed.  
	//		ptHit---Specifies A CPoint type value.
	virtual void DoMethod14(CFOPClientBorder * pClient, CPoint ptHit);

	//-----------------------------------------------------------------------
	// Summary:
	virtual void DoMethod13(CFOPClientBorder::foRowState aState, CFOPClientBorder::foBarLayout aLay,
		int x1, int y1, int x2, int y2, int nPos);

	//-----------------------------------------------------------------------
	// Summary:
	virtual void DoMethod12(CFOPClientEdge::foBarLayout aLay,
		int x1, int y1, int x2, int y2);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	CControlBar * DoMethod11(int nPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	CControlBar * DoMethod10(int nPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	CControlBar * DoMethod9(int nPos);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	int GetRowHeight(int nPos) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nRow---nRow, Specifies A integer value.
	int DoMethod8(int nRow) const;
	
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		*pBar---Bar Docked, A pointer to the CControlBar  or NULL if the call failed.  
	//		&nBars1---Bars Bid, Specifies A integer value.  
	//		&nBars2---Bars Uni, Specifies A integer value.
	virtual void DoMethod7(int nPos, CControlBar *pBar, int &nBars1, int &nBars2);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.  
	//		aRect---Specifies A CRect type value.  
	//		ptMid---ptMid, Specifies A CPoint type value.
	int DoMethod6(CControlBar* pBar, CRect aRect, CPoint ptMid);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.  
	//		nCol---nCol, Specifies A integer value.  
	//		nRow---nRow, Specifies A integer value.
	// Insert bar.
	virtual int Insert(CControlBar* pBar, int nCol, int nRow);

	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.  
	//		aPos---aPos, Specifies a const CFOPDockData& aPos object(Value).
	// Insert bar.
	virtual int Insert(CControlBar* pBar, const CFOPDockData& aPos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.  
	//		aRect---Specifies A CRect type value.  
	//		ptMid---ptMid, Specifies A CPoint type value.
	// Insert bar.
	virtual int Insert(CControlBar* pBar, CRect aRect, CPoint ptMid);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.
	virtual int DoMethod5(CControlBar* pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		pBar---pBar, A pointer to the CControlBar or NULL if the call failed.
	virtual int DoMethod4(int nPos, CControlBar* pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBar---pBar, A pointer to the CFOPControlBar  or NULL if the call failed.  
	//		nDelta---nDelta, Specifies A integer value.  
	//		sizeMax---sizeMax, Specifies A CSize type value.
	int DoMethod3(CFOPControlBar * pBar, int nDelta, const CSize& sizeMax);
	
public:

	//-----------------------------------------------------------------------
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.
	void DoMethod2(int nPos, int nWidth);

#if _MFC_VER >= 0x0420
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove  Bar, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBar---A pointer to the CControlBar  or NULL if the call failed.  
	//		nPosExclude---Position Exclude, Specifies A integer value.  
	//		bAddPlaceHolder---Add Place Holder, Specifies A Boolean value.
	virtual BOOL RemoveControlBar(CControlBar *pBar, int nPosExclude = - 1, BOOL bAddPlaceHolder = FALSE);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove  Bar, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBar---A pointer to the CControlBar  or NULL if the call failed.  
	//		nPos---Position Exclude, Specifies A integer value.
	virtual BOOL RemoveControlBar(CControlBar *pBar, int nPos = - 1);
#endif

	//-----------------------------------------------------------------------
	// Summary:
	//		pBorder---pBorder, A pointer to the CFOPClientBorder  or NULL if the call failed.  
	//		nDelta---nDelta, Specifies A integer value.
	virtual void DoMethod1(CFOPClientBorder * pBorder, int nDelta);
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get Docked Visible Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetDockedVisibleCount() const;

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext & dc object(Value).
	virtual void Dump(CDumpContext & dc) const;
#endif

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPDockBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nCol---nCol, Specifies A integer value.  
	//		nRow---nRow, Specifies A integer value.
	virtual void DockControlBar(CControlBar * pBar, int nCol, int nRow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		rPos---rPos, Specifies a const CFOPDockData & rPos object(Value).
	virtual void DockControlBar(CControlBar * pBar, const CFOPDockData & rPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Dock  Bar, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	virtual void ReDockControlBar(CControlBar * pBar, LPCRECT lpRect = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fixed Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		bStretch---bStretch, Specifies A Boolean value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Docking Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		pBarToDock---Bar To Dock, A pointer to the CControlBar  or NULL if the call failed.  
	//		rectBar---rectBar, Specifies A CRect type value.  
	//		pt---Specifies A CPoint type value.  
	//		nPosDockingRow---Position Docking Row, Specifies A integer value.  
	//		prevFocusRect---Focus Rectangle, Specifies A CRect type value.  
	//		prevPt---prevPt, Specifies A CPoint type value.
	virtual CRect CalcDockingLayout(CControlBar * pBarToDock, CRect & rectBar,CPoint pt, int & nPosDockingRow, CRect & prevFocusRect, CPoint & prevPt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Tracking Limits, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pClientBorder---Client Border, A pointer to the CFOPClientBorder  or NULL if the call failed.
	virtual void CalcTrackingLimits(CFOPClientBorder * pClientBorder);
	//}}AFX_VIRTUAL

#if _MSC_VER < 1200 // MFC 5.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Gripper, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void DrawGripper(CDC* pDC, const CRect& rect);
#endif //_MSC_VER < 1200

protected:
	//{{AFX_MSG(CFOPDockBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd * pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size Parent, Called after the size of CWnd has changed.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSizeParent(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		pos---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On  Right Menu Action, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnCtrlRightMenuAction(UINT nID);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

public:

	// Value
	static BOOL		m_bxTempValue3; 

	// Value
	CPtrArray		m_aDockTemp5;

	// Value
	CObArray		m_aDockTemp4;

	// Value
	CObArray		m_aDockTemp3;

	// Value
	DWORD			m_aDockTemp2;

	// Value
	CControlBar *	m_aDockTemp1;

	// Value
	BOOL			m_bxTempValue2;

	// Value
	BOOL			m_bxTempValue1;

	// Value
	double			m_dValueTemp1;

	// Value
	CMap<UINT, UINT, CFOPControlBar*, CFOPControlBar*> m_aDataTemp;
	friend class CFOPMiniDockFrameWnd;
	friend class CFOPDockContext;
};


/////////////////////////////////////////////////////////////////////////////
// CFOPMiniDockFrameWnd frame

class CFOPTitleButton;

//===========================================================================
// Summary:
//     The CFOPMiniDockFrameWnd class derived from CMiniDockFrameWnd
//      F O P Mini Dock Frame Window
//===========================================================================

class FO_EXT_CLASS CFOPMiniDockFrameWnd : public CMiniDockFrameWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMiniDockFrameWnd---F O P Mini Dock Frame Window, Specifies a E-XD++ CFOPMiniDockFrameWnd object (Value).
	DECLARE_DYNCREATE(CFOPMiniDockFrameWnd)
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mini Dock Frame Window, Constructs a CFOPMiniDockFrameWnd object.
	//		Returns A  value (Object).
	CFOPMiniDockFrameWnd();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Mini Dock Frame Window, Destructor of class CFOPMiniDockFrameWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMiniDockFrameWnd();

// Operations
public:

	// Is control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is  Bar, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBar---pBar, A pointer to the CFOPControlBar or NULL if the call failed.
	virtual BOOL DoMethod25(CFOPControlBar* pBar);

	// Get pointer of control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current  Bar, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPControlBar,or NULL if the call failed
    virtual CFOPControlBar* GetCurControlBar() const;

	// Show tips.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Tips, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		bFirst---bFirst, Specifies A Boolean value.
	virtual void ShowTips(CPoint point, BOOL bFirst = FALSE);

	// Draw button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pButton---pButton, A pointer to the CFOPTitleButton or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void MethodTemp14(CDC* pDC,CFOPTitleButton* pButton,CRect& rect);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPMiniDockFrameWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPMiniDockFrameWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		dwBarStyle---Bar Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual BOOL Create(CWnd * pParent, DWORD dwBarStyle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		bNotify---bNotify, Specifies A Boolean value.
	virtual void RecalcLayout(CPoint point, BOOL bNotify = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bNotify---bNotify, Specifies A Boolean value.
	virtual void RecalcLayout(BOOL bNotify = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Window Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpClientRect---Client Rectangle, Specifies a LPRECT lpClientRect object(Value).  
	//		nAdjustType---Adjust Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void CalcWindowRect(LPRECT lpClientRect,UINT nAdjustType = adjustBorder);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPMiniDockFrameWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc L Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc L Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc L Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Mouse Move, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Parent Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg void OnParentNotify(UINT message, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Paint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnNcPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Show Window, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.  
	//		nStatus---nStatus, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Text, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnSetText(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Idle Update Cmd U I, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnIdleUpdateCmdUI();
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Data, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnInitData(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Close Button, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnClickCloseButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Object 
	CToolTipCtrl    m_aObject1;

	// Object  
	CImageList      m_aObject2;

	// Object 
	CFOPDockBar		m_aObject3;
	
	// Object
	BOOL			m_bValue1;

	// Object
	CPtrList		m_aObject4;

	// Object
	CFOPTitleButton* m_aObject5;
	
	// Object
	CFOPTitleButton* m_aObject6;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDOCKBAR_H__A149FDAD_E1A1_421F_AA06_25C33B639744__INCLUDED_)
