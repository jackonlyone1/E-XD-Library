//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOINSIDEBASESHAPE_H__0797599E_CF50_4356_B870_D3D90B8995B7__INCLUDED_)
#define AFC_FOINSIDEBASESHAPE_H__0797599E_CF50_4356_B870_D3D90B8995B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: ucancode.net Software.
//------------------------------------------------------

#include "FODrawPortsShape.h"

class CFOControlBase;
class CFOPCanvasCore;

/////////////////////////////////////////////////////////////////////////
// CFOPEFormBaseShape -- the base core class for E-Form solution shape. 
//						all the input fields shapes are children classes from this class.
//						All these shapes can be worked at running - mode.
//					
//						Call GetCurrentText() method to obtain input text at running - mode.
//						Call SetCurrentText(..) method to change the input data.
//

 
//===========================================================================
// Summary:
//     The CFOPEFormBaseShape class derived from CFODrawPortsShape
//      F O P E Form Base Shape
//===========================================================================

class FO_EXT_CLASS CFOPEFormBaseShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPEFormBaseShape---F O P E Form Base Shape, Specifies a E-XD++ CFOPEFormBaseShape object (Value).
	DECLARE_SERIAL(CFOPEFormBaseShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P E Form Base Shape, Constructs a CFOPEFormBaseShape object.
	//		Returns A  value (Object).
	CFOPEFormBaseShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P E Form Base Shape, Constructs a CFOPEFormBaseShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPEFormBaseShape& src object(Value).
	CFOPEFormBaseShape(const CFOPEFormBaseShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P E Form Base Shape, Destructor of class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPEFormBaseShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPEFormBaseShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the e-form solution wrapper Shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPEFormBaseShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPEFormBaseShape& src object(Value).
	CFOPEFormBaseShape& operator=(const CFOPEFormBaseShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;

public:

	// Get parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Parent Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetParentShape() const { return m_pParentShape; }
	
	// Set parent shape.
	// pParent -- pointer of parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Shape, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		*pParent---*pParent, A pointer to the CFODrawShape  or NULL if the call failed.
	void SetParentShape(CFODrawShape *pParent) { m_pParentShape = pParent; }

	// Update shape's area.
	// pArea -- pointer of area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Implement edit box control
	// pWnd -- pointer of the window.
	// dwStyle -- style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Implement Edit Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual BOOL ImplementEditBox(CFOPCanvasCore* pWnd,DWORD dwStyle);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Initial Property Value, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL DoGetInitPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	// call this method to put the text object into edit in place mode
	// pWnd -- pointer of the window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartEdit(CFOPCanvasCore * pWnd, CPoint ptCursorSP);
    
	// call this method to end edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CFOPCanvasCore or NULL if the call failed.
    virtual void DoEndEdit(CFOPCanvasCore* pWnd = NULL);

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Create text border space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Text Space, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CRect GetDrawTextSpace(CDC* pDC);

	// Get shape back brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Brush, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual HBRUSH GetBackBrush(CDC* pDC);
	
	// Set edit box text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Edit Text, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void SetEditText(const LPCTSTR lpszText);

	// Draw edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Edit, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcEdit---rcEdit, Specifies A CRect type value.
	virtual void DrawEdit(CDC* pDC,CRect rcEdit);

	// Update shape caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component Caption, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateCompCaption();

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Update edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Edit, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void UpdateEdit(CFOPCanvasCore* pWnd);

	// Get edit wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current , Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOControlBase,or NULL if the call failed
	virtual CFOControlBase* GetCurControl() const { return m_pControlBox; }

	// Get font metrics.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Metrics, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dxWidth---dxWidth, Specifies A integer value.  
	//		dyHeight---dyHeight, Specifies A integer value.
	virtual void GetFontMetrics(CDC* pDC, int& dxWidth, int& dyHeight);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	
	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

	// Get current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetCurrentText() { return m_strCurValue; }
	
	// Set current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Change only text.
	void SetSimpleCurrentText(const CString &str);
	
	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Edit Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentEditText(CString& strResult);
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Edit Text, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentEditText(const CString& str);

	// Change current text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void SetCurrentTextValue(const CString &strValue);


	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSimpleValue(const double &nValue);

public:
	
	// Get choice list,this is the choice list string of the shape CFOTabbedComboShape.
	// It return a string like this:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice List, Returns the specified value.
	//		Returns a CString type value.
	CString		GetChoiceList() const;
	
	// Change the choice list string of the shape CFOTabbedComboShape,
	// strChoice -- It must be like the following string:
	// _T("Index\tTitle\nFirst\tMicrosoft\r\nSecond\tBorland\r\nThree\tAdobe\r\nFour\tUCanCode\r\nFive\tSAP\r\n");
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	void		SetChoiceList(const CString &strChoice);
	
	// Is show left border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetLeftBorder() const;
	
	// Change left border mode,if with left border mode,it will show a red line at the left of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Border, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&bLeft---&bLeft, Specifies A Boolean value.
	void		SetLeftBorder(const BOOL &bLeft);
	
	// Is show top border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTopBorder() const;
	
	// Change top border mode,if with top border mode,it will show a red line at the top border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top Border, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&bTop---&bTop, Specifies A Boolean value.
	void		SetTopBorder(const BOOL &bTop);
	
	// Is show right border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Right Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetRightBorder() const;
	
	// Change right border mode,if with right border mode,it will show a red line at the right border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Right Border, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&bRight---&bRight, Specifies A Boolean value.
	void		SetRightBorder(const BOOL &bRight);
	
	// Is show bottom border,this is only used for text input control,such as CFOEditBoxShape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetBottomBorder() const;
	
	// Change bottom border mode,if with bottom border mode,it will show a red line at the bottom border of the shape.
	// This property value only used for text input control such as CFOEditBoxShape,and only showing with running mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bottom Border, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&bBottom---&bBottom, Specifies A Boolean value.
	void		SetBottomBorder(const BOOL &bBottom);
	
		
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetCurValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPEFormBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	virtual void		SetCurValue(const int &nValue);
	
	// Return AllowPrintBorder value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Allow Print Border, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetAllowPrintBorder() const;
	
	// Change AllowPrintBorder value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Print Border, Sets a specify value to current class CFOPEFormBaseShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetAllowPrintBorder( const BOOL &bValue );

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:

	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// Do Middle Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual void OnMButtonDown(UINT nFlags, CPoint pt);

	// Do middle button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual void OnMButtonUp(UINT nFlags, CPoint pt);

	// Do middle button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_KEYUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_SETCURSOT message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);

	// WM_COMMAND message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Action, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnAction(WPARAM wParam, LPARAM lParam);

	// WM_KILLFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	virtual void OnKillFocus(CWnd* pNewWnd);

	//	WM_SETFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	virtual  void OnSetFocus(CWnd* pOldWnd);

	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

	//Draw flat status.
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Parent shape.
 
	// Parent Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pParentShape;

	// Edit control.
 
	// Box, This member maintains a pointer to the object CFOControlBase.  
	CFOControlBase*	m_pControlBox;

	// Parent view.
 
	// Parent View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *	m_pParentView;

	// Need rebuild pen and brush.
 
	// Need Create, This member sets TRUE if it is right.  
	BOOL			m_bNeedCreate;

	// Font handle.
 
	// Text Box Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont *			m_pTextBoxFont;

	// Current text that inputted.
 
	// Current Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCurValue;
};

#endif // !defined(AFC_FOINSIDEBASESHAPE_H__0797599E_CF50_4356_B870_D3D90B8995B7__INCLUDED_)
