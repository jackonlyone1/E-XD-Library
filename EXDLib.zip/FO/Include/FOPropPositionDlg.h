//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPROPPOSITIONDLG_H__92CBC8B9_5422_4BDE_853E_5EA92E375AA5__INCLUDED_)
#define AFX_FOPROPPOSITIONDLG_H__92CBC8B9_5422_4BDE_853E_5EA92E375AA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPropPositionDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPropPositionDlg dialog

#include "FOAngleWnd.h"
#include "FOAngleEditBox.h"
#include "FOPDropDownBitmapPickerButton.h"
#include "FOImageButton.h"

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOPropPositionDlg class derived from CDialog
//      F O Property Position Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropPositionDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Position Dialog, Constructs a CFOPropPositionDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropPositionDlg(CFODataModel *pModel,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPropPositionDlg)
	enum { IDD = IDD_FO_SIZEANDPOS };
 
	// Position X, This member specify double object.  
	double		m_dPosX;
 
	// Position Y, This member specify double object.  
	double		m_dPosY;
 
	// Height, This member specify double object.  
	double		m_dHeight;
 
	// Width, This member specify double object.  
	double		m_dWidth;
 
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nAngle;
 
	// Ratio, This member sets TRUE if it is right.  
	BOOL		m_bRatio;
	//}}AFX_DATA
 
	// Angle Edit, This member specify E-XD++ CFOAngleEditBox object.  
	CFOAngleEditBox m_AngleEdit;
 
	// Angle , This member specify E-XD++ CFOAngleWnd object.  
	CFOAngleWnd		m_AngleCtrl;
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pModel;

	// width-to-height ratio to support the KeepRatio button
 
	// Width Height Ratio, This member specify double object.  
	double  m_fWidthHeightRatio;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Limit Value, This member specify double object.  
	double dLimitValue;

 
	// Do Single Update, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nDoSingleUpdate;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPropPositionDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropPositionDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Position Editx, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoPosEditx();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Fo Position Edity, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeFoPosEdity();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Check Ratio, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCheckRatio();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();

//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPortDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPortDlg class derived from CDialog
//      F O Port Dialog
//===========================================================================

class FO_EXT_CLASS CFOPortDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Port Dialog, Constructs a CFOPortDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPortDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPortDlg)
	enum { IDD = IDD_FO_DIALOG_PORT };
 
	// Combo Box, This member specify CComboBox object.  
	CComboBox	m_aComboBox;
 
	// Spin Width, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_CtrlSpinWidth;
 
	// Spin Height, This member specify CSpinButtonCtrl object.  
	CSpinButtonCtrl	m_CtrlSpinHeight;
 
	// Default, This member sets TRUE if it is right.  
	BOOL	m_bDefault;
 
	// Type, This member specify CComboBox object.  
	CComboBox	m_comboType;
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nHeight;
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nWidth;
 
	// Side, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nSide;
	//}}AFX_DATA
	
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

 
	// Connect Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nConnectType;

 
	// Drop Port Type, This member specify FOPDropDownBitmapPickerButton object.  
	FOPDropDownBitmapPickerButton	DropPortType;
 
	// Port Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int savedPortIndex;

 
	// Old Connect Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nOldConnectType;
 
	// Old Port Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int nOldPortType;

	// Old height.
 
	// Old Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldHeight;

	// Old width.
 
	// Old Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldWidth;

	// Old port type.
 
	// Old Side, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldSide;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL m_bModify;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPortDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPortDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Check Default, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCheckDefault();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio3, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio3();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio4, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio4();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio5, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio5();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fop Default Size, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFopDefaultSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPROPPOSITIONDLG_H__92CBC8B9_5422_4BDE_853E_5EA92E375AA5__INCLUDED_)
