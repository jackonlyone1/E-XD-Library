//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOGEOACTION_H__DFD0B432_4638_4176_BA8B_227484CBE469__INCLUDED_)
#define AFC_FOGEOACTION_H__DFD0B432_4638_4176_BA8B_227484CBE469__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
#include "FODiamondShape.h"
/////////////////////////////////////////////////////////////////////////////
// Description: CFOGeoAction -- action that change the Geometry of path shape.
// Author: Author
///////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOGeoAction class derived from CFOAction
//      F O Geogmetry Action
//===========================================================================

class FO_EXT_CLASS CFOGeoAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOGeoAction---F O Geogmetry Action, Specifies a E-XD++ CFOGeoAction object (Value).
	DECLARE_ACTION(CFOGeoAction)
public:
	
	// Constructor.
	// pModel -- pointer of the data model.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Geogmetry Action, Constructs a CFOGeoAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOGeoAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Geogmetry Action, Destructor of class CFOGeoAction
	//		Returns A  value (Object).
	~CFOGeoAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	// strLabel -- label for the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOGeoAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Obtain index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Vector Handle, Returns the specified value.
	//		Returns a int type value.
	int GetVectorHandle() const { return m_nVectorIndex; }

	// Change vector handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Vector Handle, Sets a specify value to current class CFOGeoAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetVectorHandle(const int &nIndex) { m_nVectorIndex = nIndex; }

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// pointer of the shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *		m_pShape;

	// pointer of the new geometry data
 
	// New Geogmetry, This member maintains a pointer to the object FOPObjGeoData.  
	FOPObjGeoData*		pNewGeo;

	// pointer of the old geometry data.
 
	// Old Geogmetry, This member maintains a pointer to the object FOPObjGeoData.  
	FOPObjGeoData*		pOldGeo;

	// Moving handle.
 
	// Vector Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nVectorIndex;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOGeoAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFOGeoAction::GetShape()
{
	return m_pShape;
}

////////////////////////////////////////////////////////////////////
// CFOPLinkAutoLayoutStateAction -- action that change the layout state of link shape.

 
//===========================================================================
// Summary:
//     The CFOPLinkAutoLayoutStateAction class derived from CFOAction
//      F O P Link Automatic Layout State Action
//===========================================================================

class FO_EXT_CLASS CFOPLinkAutoLayoutStateAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLinkAutoLayoutStateAction---F O P Link Automatic Layout State Action, Specifies a E-XD++ CFOPLinkAutoLayoutStateAction object (Value).
	DECLARE_ACTION(CFOPLinkAutoLayoutStateAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Link Automatic Layout State Action, Constructs a CFOPLinkAutoLayoutStateAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOPLinkAutoLayoutStateAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Link Automatic Layout State Action, Destructor of class CFOPLinkAutoLayoutStateAction
	//		Returns A  value (Object).
	~CFOPLinkAutoLayoutStateAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPLinkAutoLayoutStateAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New State, Sets a specify value to current class CFOPLinkAutoLayoutStateAction
	// Parameters:
	//		&bState---&bState, Specifies A Boolean value.
	void SetNewState(const BOOL &bState) { m_bNewState = bState; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

// Attributes
protected:

	// New state
 
	// New State, This member sets TRUE if it is right.  
	BOOL m_bNewState;

	// Old state.
 
	// Old State, This member sets TRUE if it is right.  
	BOOL m_nOldState;

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.

 
	// User Define View, This member specify friend class object.  
	friend class CUserDefineView;
};

_FOLIB_INLINE void CFOPLinkAutoLayoutStateAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFOPLinkAutoLayoutStateAction::GetShape()
{
	return m_pShape;
}

////////////////////////////////////////////////////
// CFONewGeoAction

class FO_EXT_CLASS CFONewGeoAction : public CFOAction
{
	DECLARE_ACTION(CFONewGeoAction)
public:
	
	// Constructor.
	// pModel -- pointer of the data model.
	// pShape -- pointer of the shape.
	CFONewGeoAction(CFODataModel* pModel,CFOPNewPathShape *pShape, const int &nIndex);
	
	// Destructor.
	~CFONewGeoAction();
	
public:
	
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	// strLabel -- label for the action
	virtual void Sprint(CString &strLabel) const;
	
	// Add new shape to the action.
	// pShape -- pointer of the shape.
	virtual void SetShape(CFOPNewPathShape *pShape);
	
	// Return the pointer of the shape.
	virtual CFOPNewPathShape *GetShape();
	
	// Obtain the index of sub path.
	int GetIndex() const { return m_nIndex; }
	
	// Change the index of sub path.
	void SetIndex(const int &nIndex) { m_nIndex = nIndex; }
	
public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	
	// pointer of the shape
	CFOPNewPathShape *		m_pShape;
	
	// pointer of the new geometry data
	CFOSubPath*		    pNewGeo;
	
	// pointer of the old geometry data.
	CFOSubPath*		    pOldGeo;
	
	// index of sub path.
	int					m_nIndex;
	
	friend class CFODrawView;
};

_FOLIB_INLINE void CFONewGeoAction::SetShape(CFOPNewPathShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}

_FOLIB_INLINE CFOPNewPathShape *CFONewGeoAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFC_FOGEOACTION_H__DFD0B432_4638_4176_BA8B_227484CBE469__INCLUDED_)
