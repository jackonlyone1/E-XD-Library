//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOSHAPEACTORDLG_H__7BB50715_F4AC_11DD_A439_525400EA266C__INCLUDED_)
#define AFX_FOSHAPEACTORDLG_H__7BB50715_F4AC_11DD_A439_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOShapeActorDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOShapeActorDlg dialog
#include "FOBaseGridListCtrl.h"
#include "FODataModel.h"
#include "FOCompositeShape.h"
#include "FOImageButton.h"


//===========================================================================
// Summary:
//     The CFOPPreviewSample class derived from CWnd
//      Preview Sample
//===========================================================================

class FO_EXT_CLASS CFOPPreviewSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Preview Sample, Constructs a CFOPPreviewSample object.
	//		Returns A  value.
	CFOPPreviewSample();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Preview Sample, Destructor of class CFOPPreviewSample
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CFOPPreviewSample();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPPreviewSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shape, Call this member function to update the object.
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	void UpdateShape(CFODrawShape *pShape);
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPreviewSample)
	//}}AFX_VIRTUAL
	
#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Addr, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPPreviewSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.
	
	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()
protected:
	// Line shape
	
	// m_pShape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape		*m_pShape;
	
};
 
//===========================================================================
// Summary:
//     The CFOShapeActorDlg class derived from CDialog
//      F O Shape Actor Dialog
//===========================================================================

class FO_EXT_CLASS CFOShapeActorDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Actor Dialog, Constructs a CFOShapeActorDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOShapeActorDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOShapeActorDlg)
	enum { IDD = IDD_FO_COMP_SELECT };
 
	// Repeater List, This member specify E-XD++ CFOBaseGridListCtrl object.  
	CFOBaseGridListCtrl	m_lcRepeaterList;
	//}}AFX_DATA
protected:
	
	// The Pointer to Current Data Model
 
	// Current Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pCurDataModel;

	// Draw view pointer.
 
	// Draw View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pDrawView;

public:

	// Get Current Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	CFODataModel *GetCurrentModel() const		{ ASSERT(m_pCurDataModel != NULL);return m_pCurDataModel; }
	
	// Set Current Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Model, Sets a specify value to current class CFOShapeActorDlg
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	void SetCurrentModel(CFODataModel *pModel)  { m_pCurDataModel = pModel; }

	// Set draw view pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw View, Sets a specify value to current class CFOShapeActorDlg
	// Parameters:
	//		*pView---*pView, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	void SetDrawView(CFOPCanvasCore *pView) { pDrawView = pView; }

	// Update Control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.

	void UpdateControl();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOShapeActorDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOShapeActorDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Prot Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoProtProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Double click Fo Objects List, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnDblclkFoObjectsList(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT /*nType*/, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Sizing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSide---nSide, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Delete, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompDelete();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Lineprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompLineprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Fillprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompFillprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Shadowprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompShadowprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Customprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompCustomprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Eventprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompEventprop();
	
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	//Has it intialize
 
	// Has Initial, This member sets TRUE if it is right.  
	BOOL m_bHasInit;
};

 
//===========================================================================
// Summary:
//     The CFOGroupShapePropDlg class derived from CDialog
//      F O Group Shape Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOGroupShapePropDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Group Shape Property Dialog, Constructs a CFOGroupShapePropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOGroupShapePropDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOGroupShapePropDlg)
	enum { IDD = IDD_FO_GROUP_COMPS_PROP };
 
	CTreeCtrl	m_treeCtrl;
	//}}AFX_DATA
protected:

	// The Pointer to Current complist
 
	// Group List, This member maintains a pointer to the object CFODrawShapeList.  
	CFODrawShapeList *pGroupList;

	// Draw view pointer.
 
	// Draw View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *pDrawView;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	CImageList  m_image;

	// hRoot, This member specify HTREEITEM object.  
	HTREEITEM hRoot;

	// Sample window.
	
	// m_wndSample, This member specify CHMIPreviewSample object.  
	CFOPPreviewSample m_wndSample;
	
public:

	// Caption.
	CString m_strCaption;


	// Get Current Model
	//-----------------------------------------------------------------------
	// Summary:
	// Insert With Component, Inserts a child object at the given index..
	// Parameters:
	//		hParent---hParent, Specifies a HTREEITEM hParent object.  
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	void InsertWithComp(HTREEITEM hParent, CFOCompositeShape *pComp);
 
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Group, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList ,or NULL if the call failed
	CFODrawShapeList *GetCurrentGroup() const		{ ASSERT(pGroupList != NULL);return pGroupList; }
	
	// Set Current Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Group, Sets a specify value to current class CFOGroupShapePropDlg
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	void SetCurrentGroup(CFODrawShapeList *pList)  { pGroupList = pList; }

	// Set draw view pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw View, Sets a specify value to current class CFOGroupShapePropDlg
	// Parameters:
	//		*pView---*pView, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	void SetDrawView(CFOPCanvasCore *pView) { pDrawView = pView; }

	// Update Control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.

	void UpdateControl();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOGroupShapePropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOGroupShapePropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Prot Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoProtProp();

	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT /*nType*/, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Sizing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSide---nSide, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Bullet, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompBullet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Lineprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompLineprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Fillprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompFillprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Shadowprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompShadowprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Customprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompCustomprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Component Eventprop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompEventprop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	afx_msg void OnClickFoTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedFoTree(NMHDR* pNMHDR, LRESULT* pResult);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	//Has it intialize
 
	// Has Initial, This member sets TRUE if it is right.  
	BOOL m_bHasInit;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOSHAPEACTORDLG_H__7BB50715_F4AC_11DD_A439_525400EA266C__INCLUDED_)
