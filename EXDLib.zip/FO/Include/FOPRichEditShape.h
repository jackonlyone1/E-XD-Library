//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPRICHEDITSHAPE_H__C051E577_7817_4717_9055_CA459BA086A2__INCLUDED_)
#define AFC_FOPRICHEDITSHAPE_H__C051E577_7817_4717_9055_CA459BA086A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include "FOInsideBaseShape.h"
#include "FOTextEdit.h"

#if _MSC_VER >= 1300
	#define WPD_CHARFORMAT CHARFORMAT2
	#define WPD_PARAFORMAT PARAFORMAT2
#else
	#define WPD_CHARFORMAT CHARFORMAT
	#define WPD_PARAFORMAT PARAFORMAT
#endif

/////////////////////////////////////////////////////////////////////////////
// CFOPTextFile implementation

 
//===========================================================================
// Summary:
//      To use a CFOPTextFile object, just call the constructor.
//      F O P Text File
//===========================================================================

class FO_EXT_CLASS CFOPTextFile
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Text File, Constructs a CFOPTextFile object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ext---Specifies A CString type value.  
	//		eol---Specifies A CString type value.
	CFOPTextFile( const CString& ext = _T( "" ), const CString& eol = _T( "\r\n" ) );

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Text File, Destructor of class CFOPTextFile
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPTextFile();

public:
	// Load text from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Text File, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	ReadTextFile( CString& filename, CStringArray& contents );

	// Load text from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Text File, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	ReadTextFile( CString& filename, CString& contents );

	// Write text to file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Text File, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	WriteTextFile( CString& filename, const CStringArray& contents );

	// Write text to file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Text File, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	WriteTextFile( CString& filename, const CString& contents );

	// Append file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append File, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	AppendFile( CString& filename, const CString& contents );

	// Append file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append File, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	AppendFile( CString& filename, const CStringArray& contents );

	// Error handling
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Error Message, Returns the specified value.
	//		Returns a CString type value.
	CString GetErrorMessage();

protected:
	
	// Obtain the file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filename, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		save---Specifies A Boolean value.  
	//		filename---Specifies A CString type value.
	virtual BOOL GetFilename( BOOL save, CString& filename );

	// Obtain the file extension
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extension, Returns the specified value.
	//		Returns a CString type value.
	CString GetExtension();

	// Clear error
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Error, Remove the specify data from the list.

	void	ClearError();

	// Valid param
	
	//-----------------------------------------------------------------------
	// Summary:
	// Valid Parameter, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wnd---A pointer to the CWnd or NULL if the call failed.
	BOOL	ValidParam( CWnd* wnd );

protected:

	// Error string.
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_error;

	// File extension
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_extension;

	// Eol
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_eol;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPRichEditShape implementation -- rich text shape, it supports rich text drawing,
//					editing, and printing.
//					Call GetCurrentText to obtain the rich text.
//					Call SetCurrentText to change the rich text.
//
//					ID: FOP_COMP_RICHEDIT 211
//

 
//===========================================================================
// Summary:
//     The CFOPRichEditShape class derived from CFOPEFormBaseShape
//      F O P Rich Edit Shape
//===========================================================================

class FO_EXT_CLASS CFOPRichEditShape : public CFOPEFormBaseShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRichEditShape---F O P Rich Edit Shape, Specifies a E-XD++ CFOPRichEditShape object (Value).
	DECLARE_SERIAL(CFOPRichEditShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Rich Edit Shape, Constructs a CFOPRichEditShape object.
	//		Returns A  value (Object).
	CFOPRichEditShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Rich Edit Shape, Constructs a CFOPRichEditShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRichEditShape& src object(Value).
	CFOPRichEditShape(const CFOPRichEditShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Rich Edit Shape, Destructor of class CFOPRichEditShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPRichEditShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRichEditShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		*pParent---*pParent, A pointer to the CFOPCanvasCore  or NULL if the call failed.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Create the rich edit shape from a CRect object.
	// pParent -- pointer of canvas.
	// rcPos -- position of shape.
	// strCaption -- caption of shape, it is the rich text.
	virtual void Create(CRect &rcPos,CFOPCanvasCore *pParent,CString strCaption = _T(""));

public:
	
	// Change plain text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Simple Text To R T F, .
	//		Returns a CString type value.  
	// Parameters:
	//		pEdit---pEdit, A pointer to the CRichEditCtrl or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.
	CString ConvertSimpleTextToRTF(CRichEditCtrl* pEdit, CString strText);

	// Change rtf to simple text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert R T F To Simpple Text, .
	//		Returns a CString type value.  
	// Parameters:
	//		pEdit---pEdit, A pointer to the CRichEditCtrl or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.
	CString ConvertRTFToSimppleText(CRichEditCtrl* pEdit, CString strText);

	// Set plain text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Plain Text, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	void SetPlainText(const CString& strText);

	// Obtain plain text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plain Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetPlainText();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPRichEditShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRichEditShape& src object(Value).
	CFOPRichEditShape& operator=(const CFOPRichEditShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

    // Generate Shape Area
	// pArea -- pointer of the area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get edit wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rich Edit, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORichEditControl,or NULL if the call failed
	virtual CFORichEditControl* GetRichEdit() const;


public:

	// Do check Event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Check Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bCheckState---Check State, Specifies A Boolean value.
	virtual void DoCheckEvent(BOOL bCheckState);

	// Load RTF File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load R T F File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.
	BOOL	LoadRTFFile( CString& filename );

	// Save to RTF File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save R T F File, Call this function to save the specify data to a file.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&filename---Specifies A CString type value.
	BOOL    SaveRTFFile( CString &filename);

	// Determines if an editing operation can be undone.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Undo, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanUndo() const;

	// Retrieves the number of lines in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Count, Returns the specified value.
	//		Returns a int type value.
	int GetLineCount() const;

	// Determines the location of a given character within the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Char Position, Returns the specified value.
	//		Returns A POINT value (Object).  
	// Parameters:
	//		lChar---lChar, Specifies A 32-bit long signed integer.
	POINT GetCharPos(long lChar) const;

	// Sets the options for this rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Options, Sets a specify value to current class CFOPRichEditShape
	//		Returns a UINT type value.  
	// Parameters:
	//		wOp---wOp, Specifies a WORD wOp object(Value).  
	//		dwFlags---dwFlags, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	UINT SetOptions(WORD wOp, DWORD dwFlags);

	// Retrieves a line of text from the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		lpszBuffer---lpszBuffer, Specifies a LPTSTR lpszBuffer object(Value).
	int GetLine(int nIndex, LPTSTR lpszBuffer) const;

	// Retrieves a line of text from the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		lpszBuffer---lpszBuffer, Specifies a LPTSTR lpszBuffer object(Value).  
	//		nMaxLength---Maximize Length, Specifies A integer value.
	int GetLine(int nIndex, LPTSTR lpszBuffer, int nMaxLength) const;

	// Determines if the contents of the Clipboard can be pasted into the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Paste, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL CanPaste(UINT nFormat = 0) const;

	// Gets the current text selected in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	// Parameters:
	//		nStartChar---Start Char, Specifies A 32-bit long signed integer.  
	//		nEndChar---End Char, Specifies A 32-bit long signed integer.
	void GetSel(long& nStartChar, long& nEndChar) const;

	// Gets the starting and ending positions of the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	// Parameters:
	//		&cr---Specifies a CHARRANGE &cr object(Value).
	void GetSel(CHARRANGE &cr) const;

	// Limits the amount of text a user can enter into the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Text, .
	// Parameters:
	//		nChars---nChars, Specifies A 32-bit long signed integer.
	void LimitText(long nChars = 0);

	// Determines which line contains the given character.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line From Char, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	long LineFromChar(long nIndex) const;

	// Sets the selection in the rich edit control. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Select, Sets a specify value to current class CFOPRichEditShape
	//		Returns a int type value.  
	// Parameters:
	//		nStartChar---Start Char, Specifies A 32-bit long signed integer.  
	//		nEndChar---End Char, Specifies A 32-bit long signed integer.
	int SetSel(long nStartChar, long nEndChar);

	// Sets the selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Select, Sets a specify value to current class CFOPRichEditShape
	//		Returns a int type value.  
	// Parameters:
	//		&cr---Specifies a CHARRANGE &cr object(Value).
	int SetSel(CHARRANGE &cr);

	// Retrieves the current default character formatting attributes in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Char Format, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		&cf---Specifies a WPD_CHARFORMAT &cf object(Value).
	DWORD GetDefaultCharFormat(WPD_CHARFORMAT &cf) const;

	// Retrieves the character formatting attributes in the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection Char Format, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		&cf---Specifies a WPD_CHARFORMAT &cf object(Value).
	DWORD GetSelectionCharFormat(WPD_CHARFORMAT &cf) const;

	// Retrieves the event mask for the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Event Mask, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetEventMask() const;

	// Gets the current amount of text the rich edit control will accept.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Limit Text, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetLimitText() const;

	// Retrieves the paragraph formatting attributes in the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Para Format, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		&pf---Specifies a PARAFORMAT &pf object(Value).
	DWORD GetParaFormat(PARAFORMAT &pf) const;

	// Gets the text of the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Text, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		lpBuf---lpBuf, Specifies A 32-bit LPSTR pointer to a character string.
	long GetSelText(LPSTR lpBuf) const;

	// Retrieves the type of contents in the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection Type, Returns the specified value.
	//		Returns A 16-bit unsigned integer.
	WORD GetSelectionType() const;

	// Sets the background color of the rich edit control. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOPRichEditShape
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		bSysColor---System Color, Specifies A Boolean value.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	COLORREF SetBackgroundColor(BOOL bSysColor, COLORREF cr);

	// Sets the default character format in the rich edit control.
	// For example:
	// 	CharFormat	cf;
	// 	cf.dwMask = CFM_SIZE | CFM_FACE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE;
	// 	cf.yHeight = 200;
	// 	cf.dwEffects = 0;
	// 	lstrcpy( cf.szFaceName, _T( "Times New Roman" ) );
	// 	MyShape.SendMessage(EM_SETCHARFORMAT, 0, (LPARAM)&cf);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Char Format, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&cf---Specifies a WPD_CHARFORMAT &cf object(Value).
	BOOL SetDefaultCharFormat(WPD_CHARFORMAT &cf);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Space, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bLineSpacingRule---Line Spacing Rule, Specifies A integer value.  
	//		&dyLineSpacing---Line Spacing, Specifies A float value.
	BOOL GetLineSpace(int &bLineSpacingRule, float &dyLineSpacing);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Space, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bLineSpacingRule---Line Spacing Rule, Specifies A integer value.  
	//		&dyLineSpacing---Line Spacing, Specifies A float value.
	BOOL SetLineSpace(const int &bLineSpacingRule, const float &dyLineSpacing);

	// Sets the character formatting attributes in the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selection Char Format, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&cf---Specifies a WPD_CHARFORMAT &cf object(Value).
	BOOL SetSelectionCharFormat(WPD_CHARFORMAT &cf);

	// Sets the character formatting attributes in the current word in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Word Char Format, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&cf---Specifies a WPD_CHARFORMAT &cf object(Value).
	BOOL SetWordCharFormat(WPD_CHARFORMAT &cf);

	// Sets the event mask for the rich edit control.
	// For example:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Event Mask, Sets a specify value to current class CFOPRichEditShape
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwEventMask---Event Mask, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	// MyShape.SetEventMask( MyShape.GetEventMask() | ENM_SELCHANGE | ENM_SCROLL | ENM_CHANGE );
	DWORD SetEventMask(DWORD dwEventMask);

	// Sets the paragraph format for the rich edit control.
	// For example 1:
	//  ParaFormat para( PFM_TABSTOPS );
	// 	para.cTabCount = MAX_TAB_STOPS;
	// 	for( int t = 0; t < MAX_TAB_STOPS ; t++ )
	// 		para.rgxTabs[ t ] = 640 * ( t + 1 );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Para Format, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&pf---Specifies a PARAFORMAT &pf object(Value).
	// 	MyShape.SetParaFormat( para );

	// For example 2:
	// ParaFormat	para( PFM_NUMBERING );
	// if( m_toolbar.IsButtonChecked( BUTTON_BULLET ) )
	// 	para.wNumbering = PFN_BULLET;
	// else
	// 	para.wNumbering = 0;
	// MyShape.SetParaFormat( para );

	// For example 3:
	// Get the current indent, if any
	// ParaFormat	para( PFM_STARTINDENT | PFM_TABSTOPS );
	// MyShape.GetParaFormat( para );
	// int newindent = 0;

	// Find closest smaller tab
	// for( int t = 0 ; t < MAX_TAB_STOPS ; t++ )
	// 	if( para.rgxTabs[ t ] < para.dxStartIndent )
	// 		newindent = para.rgxTabs[ t ];

	// Set indent to this value or 0 if none
	// para.dwMask = PFM_STARTINDENT | PFM_OFFSET;
	// para.dxStartIndent = newindent;
	// para.dxOffset = newindent;
	// MyShape.SetParaFormat( para );

	// For example 4:
	// Get current indent
	// ParaFormat	para( PFM_STARTINDENT | PFM_TABSTOPS );
	// MyShape.GetParaFormat( para );
	// int newindent = para.dxStartIndent;

	// Find next larger tab
	// for( int t = MAX_TAB_STOPS - 1 ; t >= 0 ; t-- )
	// {
	// 
	// 	if( para.rgxTabs[ t ] > para.dxStartIndent )
	// 		newindent = para.rgxTabs[ t ];
	// 
	// }

	// if( newindent != para.dxStartIndent )
	// {

	// Set indent to this value
	// 	para.dwMask = PFM_STARTINDENT | PFM_OFFSET;
	// 	para.dxStartIndent = newindent;
	// 	para.dxOffset = newindent;

	// 	MyShape.SetParaFormat( para );

	// }

	// For example 5:
	// ParaFormat	para( PFM_ALIGNMENT );
	// para.wAlignment = ( WORD ) alignment;

	// MyShape.SetParaFormat( para );

	BOOL SetParaFormat(PARAFORMAT &pf);

	// Sets the target output device for the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Target Device, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		lLineWidth---Line Width, Specifies A 32-bit long signed integer.
	BOOL SetTargetDevice(HDC hDC, long lLineWidth);

	// Gets the length of the text in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Length, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetTextLength() const;

	// Sets the read-only option for the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Read Only, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bReadOnly---Read Only, Specifies A Boolean value.
	BOOL SetReadOnly(BOOL bReadOnly = TRUE);

	// Gets the index of the topmost visible line in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Visible Line, Returns the specified value.
	//		Returns a int type value.
	int GetFirstVisibleLine() const;

	// Empties the undo buffer in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty Undo Buffer, .

	void EmptyUndoBuffer();

	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Get the character index of a line within the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Index, .
	//		Returns a int type value.  
	// Parameters:
	//		nLine---nLine, Specifies A integer value.
	int LineIndex(int nLine = -1) const;

	// Get the line length of the specified line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Length, .
	//		Returns a int type value.  
	// Parameters:
	//		nLine---nLine, Specifies A integer value.
	int LineLength(int nLine = -1) const;

	// Scroll the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Scroll, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nLines---nLines, Specifies A integer value.  
	//		nChars---nChars, Specifies A integer value.
	BOOL LineScroll(int nLines, int nChars = 0);

	// Replace the current selection.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// Parameters:
	//		lpszNewText---New Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bCanUndo---Can Undo, Specifies A Boolean value.
	void ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo = FALSE);

	// Displays a portion of the contents of the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Display Band, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDisplayRect---Display Rectangle, Specifies a LPRECT pDisplayRect object(Value).
	BOOL DisplayBand(LPRECT pDisplayRect);

	// Locate text within the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Text, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		dwFlags---dwFlags, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pFindText---Find Text, A pointer to the FINDTEXTEX or NULL if the call failed.
	long FindText(DWORD dwFlags, FINDTEXTEX* pFindText) const;

	// Format a specified range in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format Range, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pfr---A pointer to the FORMATRANGE or NULL if the call failed.  
	//		bDisplay---bDisplay, Specifies A Boolean value.
	long FormatRange(FORMATRANGE* pfr, BOOL bDisplay = TRUE);

	// Hide the current selection in the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Selection, Hides the objects by removing it from the display screen. 
	// Parameters:
	//		bHide---bHide, Specifies A Boolean value.  
	//		bPerm---bPerm, Specifies A Boolean value.
	void HideSelection(BOOL bHide, BOOL bPerm);

	// Inserts the contents of the Clipboard into the rich edit control in the specified data format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste Special, .
	// Parameters:
	//		nClipFormat---Clipboard Format, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dvAspect---dvAspect, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		hMF---M F, Specifies a HMETAFILE hMF = 0 object(Value).
	void PasteSpecial(UINT nClipFormat, DWORD dvAspect = 0, HMETAFILE hMF = 0);

	// Forces the rich edit control to send request resize messages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Request Resize, .

	void RequestResize();

	// Inserts text from an input stream.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stream In, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nFormat---nFormat, Specifies A integer value.  
	//		es---Specifies a EDITSTREAM& es object(Value).
	long StreamIn(int nFormat, EDITSTREAM& es);

	// Stores text from the rich edit control into an output stream.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stream Out, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nFormat---nFormat, Specifies A integer value.  
	//		es---Specifies a EDITSTREAM& es object(Value).
	long StreamOut(int nFormat, EDITSTREAM& es);

	// Scroll caret into view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Caret, .

	void ScrollCaret();

	// Insert text into the rich edit control at after the specified character.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Text, Inserts a child object at the given index..
	//		Returns a int type value.  
	// Parameters:
	//		nInsertAfterChar---Insert After Char, Specifies A 32-bit long signed integer.  
	//		lpstrText---lpstrText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bCanUndo---Can Undo, Specifies A Boolean value.
	int InsertText(long nInsertAfterChar, LPCTSTR lpstrText, BOOL bCanUndo = FALSE);

	// Append text to the rich edit control.
	// lpstrText -- text to append
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append Text, .
	//		Returns a int type value.  
	// Parameters:
	//		lpstrText---lpstrText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bCanUndo---Can Undo, Specifies A Boolean value.
	int AppendText(LPCTSTR lpstrText, BOOL bCanUndo = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Undo, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Undo the last operation on the rich edit control.
	BOOL Undo();

	// Empty the contents of the rich edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	void Clear();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.

	// Copy the contents of the rich edit control to the Clipboard.
	void Copy();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .

	// Cut the current selection in the rich edit control and copy it to the clipboard.
	void Cut();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .

	// Paste the contents of the Clipboard into the rich edit control.
	void Paste();

	// Sets the formatting rectangle for the rich edit control.
	// Set up edit rect margins
	// int scmargin = 4;
	// CRect rc;
	// MyShape.GetClientRect( rc );

	// rc.top = scmargin;
	// rc.left = scmargin * 2;
	// rc.right -= scmargin * 2;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	// MyShape.SetRect( rc );
	void SetRect(LPCRECT lpRect);

	// Set text associated with window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window Text, Sets a specify value to current class CFOPRichEditShape
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszString---lpszString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL SetWindowText(LPCTSTR lpszString);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Text, Called this function to empty a previously initialized CFOPRichEditShape object.

	void ResetAllText();

	// Get text associated with window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Text, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		lpszStringBuf---String Buffer, Specifies a LPTSTR lpszStringBuf object(Value).  
	//		nMaxCount---Maximize Count, Specifies A integer value.
	int GetWindowText(LPTSTR lpszStringBuf, int nMaxCount) const;

	// Get length of text associated with window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Text Length, Returns the specified value.
	//		Returns a int type value.
	int GetWindowTextLength() const;

	// Force a window update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Window, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateWindow();

	// Set redraw.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Redraw, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetRedraw(BOOL bRedraw = TRUE);

	// Get current update rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Update Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		bErase---bErase, Specifies A Boolean value.
	BOOL GetUpdateRect(LPRECT lpRect, BOOL bErase = FALSE);

	// Force the window to redraw.
	BOOL RedrawWindow(LPCRECT lpRectUpdate = NULL, HRGN hRgnUpdate = NULL, UINT flags = RDW_INVALIDATE |
		RDW_UPDATENOW | RDW_ERASE);

	// This method determines whether the contents of an edit control have been modified.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetModify() const;

	// This method sets or clears the modified flag for an edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	void SetModify(BOOL bModified = TRUE);

	// Is select text bold.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get State, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bBold---&bBold, Specifies A Boolean value.  
	//		&bItalic---&bItalic, Specifies A Boolean value.  
	//		&bUnderLine---Under Line, Specifies A Boolean value.  
	//		&nAlign---&nAlign, Specifies A integer value.  
	//		&bBulleted---&bBulleted, Specifies A Boolean value.  
	//		&strFaceName---Face Name, Specifies A CString type value.  
	//		&nFontSize---Font Size, Specifies A integer value.  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	BOOL GetState(BOOL &bBold,BOOL &bItalic,BOOL &bUnderLine,int &nAlign/*0-left,1-middle,2-right*/,
		BOOL &bBulleted,CString &strFaceName,int &nFontSize,COLORREF &crColor);

	// Set effect.
	// mask -- must be one these values: CFM_BOLD,CFM_ITALIC,CFM_UNDERLINE
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Effect, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		&mask---Specifies A integer value.  
	//		bEffect---bEffect, Specifies A Boolean value.
	void SetEffect(const int &mask, BOOL bEffect);

	// Get effect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Effect, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&mask---Specifies A integer value.
	BOOL GetEffect(const int &mask);

	// Set alignment
	// alignment -- must be one these values: PFA_LEFT,PFA_CENTER,PFA_RIGHT
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alignment, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		alignment---Specifies A integer value.
	void SetAlignment(int alignment);

	// Get alignment
	// the return values must be one these: PFA_LEFT,PFA_CENTER,PFA_RIGHT
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Alignment, Returns the specified value.
	//		Returns a int type value.
	int GetAlignment();

	// Change the selected RTF text font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Name, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		font---Specifies A CString type value.
	void SetCurrentFontName( const CString& font );
	
	// Get the selected RTF text font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetCurrentFontName();
	
	// Change the selected RTF text font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Size, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		points---Specifies A integer value.
	void SetCurrentFontSize( int points );
	
	// Get the selected RTF text font size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Size, Returns the specified value.
	//		Returns a int type value.
	int GetCurrentFontSize();
	
	// Change the selected RTF text bullet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Bullet, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		nBullet---nBullet, Specifies A integer value.
	void SetCurrentFontBullet( int nBullet );
	
	// Get the selected RTF text Bullet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Bullet, Returns the specified value.
	//		Returns a int type value.
	int GetCurrentFontBullet();
	
	// Change the selected RTF text font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Color, Sets a specify value to current class CFOPRichEditShape
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void SetCurrentFontColor( COLORREF color );
	
	// Get the selected RTF text font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetCurrentFontColor();
	
	// Adjust text box size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Text Box Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void AdjustTextBoxSize (CDC *pDC);

	// override this method to return the text which
	// is displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetCurrentText();
	
	// override this method to set the text as it should
	// be displayed in the current shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOPRichEditShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Change only text.
	void SetSimpleCurrentText(const CString &str);
	
	// Obtain all express strings.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Express, Returns the specified value.
	// Parameters:
	//		&strArray---&strArray, Specifies A CString type value.
	void GetAllExpress(CStringArray &strArray);

	// Change express value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Express Value, .

	void ChangeExpressValue();
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draw edit.
	// pDC -- pointer of the DC.
	// rcEdit -- edit position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Edit, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcEdit---rcEdit, Specifies A CRect type value.
	virtual void DrawEdit(CDC* pDC,CRect rcEdit);

	// call this method to put the text object into edit in place mode
	// pView -- pointer of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartEdit(CFOPCanvasCore * pView, CPoint ptCursorSP);
    
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

 
	// Backup, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strBackup;
protected:

	// CRichEditCtrl for drawing.
 
	// Draw R T F, This member specify CRichEditCtrl object.  
	CRichEditCtrl   m_wndDrawRTF;

	// Save rtf text
 
	// Save Draw R T F, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strSaveDrawRTF;

};


#endif // !defined(AFC_FOPRICHEDITSHAPE_H__C051E577_7817_4717_9055_CA459BA086A2__INCLUDED_)
