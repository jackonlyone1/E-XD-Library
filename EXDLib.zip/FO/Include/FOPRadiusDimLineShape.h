//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPRADIUSDIMLINESHAPE_H__95EC40F8_761B_4E59_832F_322376CBF623__INCLUDED_)
#define AFC_FOPRADIUSDIMLINESHAPE_H__95EC40F8_761B_4E59_832F_322376CBF623__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseEndObject.h"
#include "FODrawPortsShape.h"

/////////////////////////////////////////////////////////////////////////////////
// CFOPRadiusDimLineShape -- ID: FOP_RADIUS_DIMLINE 203
//------------------------------------------------------
// Description: 
// Author: ucancode.net Software.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPRadiusDimLineShape class derived from CFODrawShape
//      F O P Radius Dimension Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPRadiusDimLineShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRadiusDimLineShape---F O P Radius Dimension Line Shape, Specifies a E-XD++ CFOPRadiusDimLineShape object (Value).
	DECLARE_SERIAL(CFOPRadiusDimLineShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Radius Dimension Line Shape, Constructs a CFOPRadiusDimLineShape object.
	//		Returns A  value (Object).
	CFOPRadiusDimLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Radius Dimension Line Shape, Constructs a CFOPRadiusDimLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRadiusDimLineShape& src object(Value).
	CFOPRadiusDimLineShape(const CFOPRadiusDimLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Radius Dimension Line Shape, Destructor of class CFOPRadiusDimLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPRadiusDimLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRadiusDimLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	// Creates the radius dimension line shape from points.
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- distance to the line.
	BOOL Create(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRadiusDimLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the radius dimension shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	
public:
	
	// Get the points of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPRadiusDimLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRadiusDimLineShape& src object(Value).
	CFOPRadiusDimLineShape& operator=(const CFOPRadiusDimLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.
	virtual void GeneratePoints(LPPOINT cCtlPt) const;

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.
	virtual void GenerateTrackPoints(LPPOINT cCtlPt) const;

	// Generate dimension text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Dimension Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	virtual CString GenerateDimText(int nLength);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Check current mirror side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Mirror Side, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.
	BOOL CheckMirrorSide(const CPoint& ptPnt,const CPoint &ptRef1) const;

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();
public:


	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOPRadiusDimLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate tack shape.
	// Define for track line.
	// nAngle -- rotate angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror with point ref1 and ref2.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Current side of mirror.
 
	// Side, This member sets TRUE if it is right.  
	BOOL			m_bSide;

	// Use custom label text.
 
	// Use Custom Text, This member sets TRUE if it is right.  
	BOOL			m_bUseCustomText;

};

///////////////////////////////////////////////////////////////////////////
// CFOPNewAnchorLineShape -- new anchor line shape, ID: FOP_ADVANCE_SHAPE 253
//

 
//===========================================================================
// Summary:
//     The CFOPNewAnchorLineShape class derived from CFODrawPortsShape
//      F O P New Anchor Line Shape
//===========================================================================

class FO_EXT_CLASS CFOPNewAnchorLineShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewAnchorLineShape---F O P New Anchor Line Shape, Specifies a E-XD++ CFOPNewAnchorLineShape object (Value).
	DECLARE_SERIAL(CFOPNewAnchorLineShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Anchor Line Shape, Constructs a CFOPNewAnchorLineShape object.
	//		Returns A  value (Object).
	CFOPNewAnchorLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Anchor Line Shape, Constructs a CFOPNewAnchorLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewAnchorLineShape& src object(Value).
	CFOPNewAnchorLineShape(const CFOPNewAnchorLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Anchor Line Shape, Destructor of class CFOPNewAnchorLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewAnchorLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewAnchorLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	// Creates the radius dimension line shape from points.
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- distance to the line.
	BOOL Create(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewAnchorLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the radius dimension shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	
	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle X, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngleX() const;

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle Track X, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngleTrackX() const;

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLabelPoint();

public:
	// Get the points of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:
	// The following can be overrided.

	// Get anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
	// Get ext anchor's path points.
	// points -- points of path.
	// bTrack -- is tracking mode or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Extend Anchor Path Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		&bWithOutLine---With Out Line, Specifies A Boolean value.  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual void GenExtAnchorPathPoints(CArray<CPoint,CPoint> &points, BOOL &bWithOutLine, const BOOL &bTrack = FALSE);
	
	// Layout all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Ports, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void LayoutPorts();

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewAnchorLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewAnchorLineShape& src object(Value).
	CFOPNewAnchorLineShape& operator=(const CFOPNewAnchorLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

public:


	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOPNewAnchorLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);
	
	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }

	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOPNewAnchorLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);
	
	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

	// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();
	
	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();
	
	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Do draw mark shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Mark, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawMark(CDC *pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();
	
};

#endif // !defined(AFC_FOPRADIUSDIMLINESHAPE_H__95EC40F8_761B_4E59_832F_322376CBF623__INCLUDED_)
