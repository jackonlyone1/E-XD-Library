//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_CFOPArcShape_H__019B72BD_0963_4F31_BD9B_E28F649460B3__INCLUDED_)
#define AFC_CFOPArcShape_H__019B72BD_0963_4F31_BD9B_E28F649460B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: ucancode.net Software.
//------------------------------------------------------
#include "FOBaseEndObject.h"
#include "FODrawShape.h"

// Default dim text space of line.

///////////////////////////////////////////////////////////
// Arc data.

 
//===========================================================================
// Summary:
//      To use a FOP_ArcData object, just call the constructor.
//      O P_ Arc Data
//===========================================================================

class FO_EXT_CLASS FOP_ArcData 
{
public:

	// Constrctor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Arc Data, Constructs a FOP_ArcData object.
	//		Returns A  value (Object).
    FOP_ArcData() {}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Arc Data, Constructs a FOP_ArcData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		centerx---Specifies A integer value.  
	//		radiusx---Specifies a double radiusx object(Value).  
	//		anglex1---Specifies a double anglex1 object(Value).  
	//		anglex2---Specifies a double anglex2 object(Value).  
	//		reversedx---Specifies A Boolean value.
    FOP_ArcData(const FOPPoint& centerx,
		double radiusx,
		double anglex1, double anglex2,
		bool reversedx) 
	{
		
        this->center = centerx;
        this->radius = radiusx;
        this->angle1 = anglex1;
        this->angle2 = anglex2;
        this->reversed = reversedx;
    }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized FOP_ArcData object.

    void Reset() 
	{
        center = FOPPoint(0,0);
        radius = 0.0;
        angle1 = 0.0;
        angle2 = 0.0;
        reversed = false;
    }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid, Determines if the given value is correct or exist.
	//		Returns A Boolean value.
    bool IsValid() 
	{
        return (radius>1.0e-10 &&
			fabs(angle1-angle2)>1.0e-8);
    }
	
public:
	// Center point of arc.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
    FOPPoint		center;

	// radius.
 
	// This member specify double object.  
    double			radius;

	// Start angle.
 
	// This member specify double object.  
    double			angle1;

	// End angle.
 
	// This member specify double object.  
    double			angle2;

	// Reversed or not.
 
	// Specify A Boolean value.  
    bool			reversed;
};


///////////////////////////////////////////////////////////
// CFOPArcShape -- arc shape with an anchor point at center, ID: FO_COMP_ARCLINE 47

 
//===========================================================================
// Summary:
//     The CFOPArcShape class derived from CFODrawShape
//      F O P Arc Shape
//===========================================================================

class FO_EXT_CLASS CFOPArcShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPArcShape---F O P Arc Shape, Specifies a E-XD++ CFOPArcShape object (Value).
	DECLARE_SERIAL(CFOPArcShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Arc Shape, Constructs a CFOPArcShape object.
	//		Returns A  value (Object).
	CFOPArcShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Arc Shape, Constructs a CFOPArcShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPArcShape& src object(Value).
	CFOPArcShape(const CFOPArcShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Arc Shape, Destructor of class CFOPArcShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPArcShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPArcShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	// Creates the arc line shape from points.
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- distance to the line.
	BOOL Create(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPArcShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the arc line shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	
	// Get the points of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	
	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLabelPoint();
	
	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Get distance from anchor to line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetDistance() const;

	// Get distance from tracker anchor to tracker line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Distance, Returns the specified value.
	//		Returns A double value (Object).
	double	GetTrackDistance();

	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// mpSpot -- result of the spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetRotateCenterSpotLocation(CFOPHandleList& lstHandle);

	// Obtain arc data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arc Data, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&data---Specifies a FOP_ArcData &data object(Value).
	virtual void GetArcData(FOP_ArcData &data);

	//return Angle length in radius.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle Length, Returns the specified value.
	//		Returns A double value (Object).
	double GetAngleLength();

	// return Length of the arc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Full Length, Returns the specified value.
	//		Returns A double value (Object).
	double GetFullLength();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPArcShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPArcShape& src object(Value).
	CFOPArcShape& operator=(const CFOPArcShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.
	virtual CPoint GeneratePoints(LPPOINT cCtlPt) const;

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Text Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.  
	//		&nTextHeight---Text Height, Specifies A integer value.
	virtual CPoint GenerateTextPoints(LPPOINT cCtlPt,const int &nTextHeight) const;

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.
	virtual void GenerateTrackPoints(LPPOINT cCtlPt);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect		GetMaxRect();

	// Generate dimension text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Dimension Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	virtual CString GenerateDimText(int nLength);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Check current mirror side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Mirror Side, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.
	BOOL CheckMirrorSide(const CPoint& ptPnt,const CPoint &ptRef1) const;

public:
	
	// Return Use Custom Text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Use Custom Text, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetUseCustomText() const { return m_bUseCustomText;}

	// Change Use Custom Text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use Custom Text, Sets a specify value to current class CFOPArcShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetUseCustomText( const BOOL &bValue ) {m_bUseCustomText = bValue; }

	// Return Show Label Inside value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Label Inside, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetShowLabelInside() const { return m_bShowLabelInside;}

	// Change Show Label Inside value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Label Inside, Sets a specify value to current class CFOPArcShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetShowLabelInside( const BOOL &bValue ) {m_bShowLabelInside = bValue; }

public:

	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOPArcShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }


	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOPArcShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Get max position of track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Points X, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		nWidth---nWidth, Specifies a double nWidth object(Value).
	virtual CPoint GeneratePointsX(double nWidth);

	// Generate points of track.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Track Points X, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		nWidth---nWidth, Specifies a double nWidth object(Value).
	virtual CPoint GenerateTrackPointsX(double nWidth);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dCenterX---Center X, Specifies a double &dCenterX object(Value).  
	//		&dCenterY---Center Y, Specifies a double &dCenterY object(Value).
	virtual void GetRotateCenter(double &dCenterX,double &dCenterY) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror with point ref1 and ref2.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	// Define for track line.
	// fX -- x track scale of shape.
	// fY -- y track scale of shape.
	// fOX -- x track origin of shape.
	// fOY -- y track origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dY, double dOX, double dOY);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

protected:

	// Save width.
 
	// Save Width, This member specify double object.  
	double			m_dSaveWidth;

	// Track width.
 
	// Track Width, This member specify double object.  
	double			m_dTrackWidth;

	// Current side of mirror.
 
	// Side, This member sets TRUE if it is right.  
	BOOL			m_bSide;

	// Use custom label text.
 
	// Use Custom Text, This member sets TRUE if it is right.  
	BOOL			m_bUseCustomText;

	// Show label inside or not.
 
	// Show Label Inside, This member sets TRUE if it is right.  
	BOOL			m_bShowLabelInside;

	// Simple polygon object.
 
	// X Polygon, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	aXPoly;

	// Center point.
 
	// Center, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptCenter;

protected:
	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize				m_szSavLabel;
};


#endif // !defined(AFC_CFOPArcShape_H__019B72BD_0963_4F31_BD9B_E28F649460B3__INCLUDED_)
