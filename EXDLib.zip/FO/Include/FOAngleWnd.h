//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOANGLEWND_H__3C60BD1D_A6F8_4FB7_88CF_101089034875__INCLUDED_)
#define AFX_FOANGLEWND_H__3C60BD1D_A6F8_4FB7_88CF_101089034875__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOAngleWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOAngleWnd window

#define EX_WM_EDITCHANGE WM_USER+5

 
//===========================================================================
// Summary:
//     The CFOAngleWnd class derived from CWnd
//      F O Angle Window
//===========================================================================

class FO_EXT_CLASS CFOAngleWnd : public CWnd
{
public:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Angle Window, Constructs a CFOAngleWnd object.
	//		Returns A  value (Object).
	CFOAngleWnd();

// Attributes
public:

	// Get current angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	//		Returns A double value (Object).
	double GetAngle();

	// Change current angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Angle, Sets a specify value to current class CFOAngleWnd
	// Parameters:
	//		&dAngle---&dAngle, Specifies a const double &dAngle object(Value).  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetAngle(const double &dAngle, BOOL bRedraw = TRUE);
	
	// Do update state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update, Do a event. 
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void DoUpdate(BOOL bRedraw = TRUE);

	// Attach current box to a specify wnd (Edit box window).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach To Edit Box, Attaches this object.
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void AttachToEditBox(CWnd *pWnd);

	// Convert angle to text, it is used to obtain the angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle Window Text, Returns the specified value.
	//		Returns a pointer to the object TCHAR ,or NULL if the call failed  
	// Parameters:
	//		*szBuf---*szBuf, A pointer to the TCHAR  or NULL if the call failed.
	TCHAR *GetAngleWindowText(TCHAR *szBuf);

	// Get background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetBackColor() const { return m_crBack; }

	// Change background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Back Color, Sets a specify value to current class CFOAngleWnd
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void SetBackColor(const COLORREF &cr) { m_crBack= cr; }

	// Fix angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fix Angle, .
	//		Returns A double value (Object).  
	// Parameters:
	//		&angle---Specifies a const double &angle object(Value).
	double FixAngle(const double &angle);

	// Compute angle between two points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Angle.
	//		Returns A double value (Object).  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	double ComputeAngle(const CPoint &ptStart, const CPoint &ptEnd);

	// Make it can be selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Turn On Now, .
	// Parameters:
	//		bOn---bOn, Specifies A Boolean value.
	void TurnOnNow(BOOL bOn);

	// Change angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Angle Value, Sets a specify value to current class CFOAngleWnd
	// Parameters:
	//		&dAngle---&dAngle, Specifies a const double &dAngle object(Value).  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetAngleValue(const double &dAngle, BOOL bRedraw = TRUE);

	// Update angle box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Angle Box, Call this member function to update the object.
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void UpdateAngleBox(BOOL bRedraw = TRUE);

protected:

	// Update attach edit box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Attach Box, Call this member function to update the object.

	void UpdateAttachBox();

	// Draw angle circle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Angle Circle, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoDrawAngleCircle(CDC *pDC);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOAngleWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Angle Window, Destructor of class CFOAngleWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAngleWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOAngleWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Point of center.
 
	// Center, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint		m_ptCenter;

	// Back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// Track mode.
 
	// Track, This member sets TRUE if it is right.  
	BOOL		m_bTrack;

	// Drawing dc.
 
	// Draw D C, This member specify CDC object.  
	CDC			m_DrawDC;
	
	// Angle value
 
	// Angle, This member specify double object.  
	double		m_dAngle;

	// Attach wnd handle.
 
	// Attach Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *		m_pAttachWnd;

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOANGLEWND_H__3C60BD1D_A6F8_4FB7_88CF_101089034875__INCLUDED_)
