//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMETHODHOST_H__DE819656_0298_4462_8ACF_D5CF0E69FBFB__INCLUDED_)
#define FO_FOMETHODHOST_H__DE819656_0298_4462_8ACF_D5CF0E69FBFB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFOMethodHost command target

#include "FOScriptView.h"

 
//===========================================================================
// Summary:
//     The CFOMethodHost class derived from CCmdTarget
//      F O Method Host
//===========================================================================

class FO_EXT_CLASS CFOMethodHost : public CCmdTarget
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMethodHost---F O Method Host, Specifies a E-XD++ CFOMethodHost object (Value).
	DECLARE_DYNCREATE(CFOMethodHost)

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Method Host, Constructs a CFOMethodHost object.
	//		Returns A  value (Object).
	CFOMethodHost();           // protected constructor used by dynamic creation

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Method Host, Destructor of class CFOMethodHost
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMethodHost();

// Attributes
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	CFODataModel *GetCurModel() { return pModel; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Window, Returns the specified value.
	//		Returns a pointer to the object CFOScriptView ,or NULL if the call failed
	CFOScriptView *GetCanvasWnd() { return pView; }

	// Load a specify shape from trs file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From T R S File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strTRSFile---T R S File, Specifies A CString type value.
	BOOL LoadFromTRSFile(const CString &strTRSFile);
	
	// Obtain shape from cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape From Cache, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey1---&strKey1, Specifies A CString type value.
	CFODrawShape *GetShapeFromCache(const CString &strKey1);
	
public:
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *pModel;
 
	// View, This member maintains a pointer to the object CFOScriptView.  
	CFOScriptView *pView;
	CArray<CPoint,CPoint> m_MultiPoints;
	CMap<IDispatch*,IDispatch*&, BOOL, BOOL&> m_mpStates;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change  Visible, .
	// Parameters:
	//		bVisible---bVisible, Specifies A Boolean value.  
	//		frm---Specifies a LPDISPATCH frm object(Value).
	void ChangeCtrlVisible(BOOL bVisible, LPDISPATCH frm);
// Operations
public:
 
	// Current Open Page, This member maintains a pointer to the object CFOToolBoxPage.  
	CFOToolBoxPage* m_pCurOpenPage;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMethodHost)
	public:
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOMethodHost)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CFOMethodHost)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Test, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCmd---strCmd, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long Test(LPCTSTR strCmd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Method, .
	// Parameters:
	//		strMsg---strMsg, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void NewMethod(LPCTSTR strMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCanvasWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Height, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCanvasHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Without Undo, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long AddShapeWithoutUndo(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKey1(LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key2, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKey2(LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key3, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKey3(LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key In Comp1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		compshape---Specifies A 32-bit long signed integer.  
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKeyInComp1(long compshape, LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key In Comp2, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		compshape---Specifies A 32-bit long signed integer.  
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKeyInComp2(long compshape, LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key In Comp3, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		compshape---Specifies A 32-bit long signed integer.  
	//		strKey---strKey, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithKeyInComp3(long compshape, LPCTSTR strKey);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate From Center, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		angle---Specifies a short angle object(Value).
	afx_msg void RotateFromCenter(long shape, short angle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Center To, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		xNew---xNew, Specifies A 32-bit long signed integer.  
	//		yNew---yNew, Specifies A 32-bit long signed integer.
	afx_msg void MoveCenterTo(long shape, long xNew, long yNew);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale From Center, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	afx_msg void ScaleFromCenter(long shape, double dX, double dY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Xdg File From File, Call this function to read a specified number of bytes from the archive.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL LoadXdgFromFile(LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save To Xdg File File, Call this function to save the specify data to a file.
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void SaveToXdgFile(LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void UpdateControl(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Run Time Input Text, Returns the specified value.
	//		Returns A 32-bit BSTR character pointer.
	afx_msg BSTR GetRunTimeInputText();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Focus On Shape, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void SetFocusOnShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Limit With Page, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bWithIn---With In, Specifies A Boolean value.
	afx_msg void SetPointLimitWithPage(BOOL bWithIn);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeType(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	//		Returns A 32-bit BSTR character pointer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BSTR GetCurrentText(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		sText---sText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void SetCurrentText(long shape, LPCTSTR sText);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is E Form Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsEFormShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get E Form Focus Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetEFormFocusShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Prot Dialog, Do a event. 

	afx_msg void DoShowProtDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape Dimension, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		width---Specifies A 32-bit long signed integer.  
	//		height---Specifies A 32-bit long signed integer.
	afx_msg void SetShapeDimension(long shape, long width, long height);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Show Label At First, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL GetShapeShowLabelAtFirst(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape Show Label At First, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		bShow---bShow, Specifies A Boolean value.
	afx_msg void SetShapeShowLabelAtFirst(long shape, BOOL bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape With Label Show, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL GetShapeWithLabelShow(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape With Label Show, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		bShow---bShow, Specifies A Boolean value.
	afx_msg void SetShapeWithLabelShow(long shape, BOOL bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape With Label Editing, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL GetShapeWithLabelEditing(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape With Label Editing, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void SetShapeWithLabelEditing(long shape, BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Point Array, .

	afx_msg void MPreparePtAry();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Point To Array, .
	// Parameters:
	//		xPoint---xPoint, Specifies A 32-bit long signed integer.  
	//		yPoint---yPoint, Specifies A 32-bit long signed integer.
	afx_msg void MAddPtToAry(long xPoint, long yPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polyline Shape, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCaption---strCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long MAddPolylineShape(LPCTSTR strCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Shape, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCaption---strCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long MAddPolygonShape(LPCTSTR strCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier Line Shape, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCaption---strCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long MAddBezierLineShape(LPCTSTR strCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Close Bezier Line Shape, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCaption---strCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long MAddCloseBezierLineShape(LPCTSTR strCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Extend Bezier Line Shape, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strCaption---strCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long MAddExtBezierLineShape(LPCTSTR strCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape, .
	// Parameters:
	//		nLinkType---Link Type, Specifies a short nLinkType object(Value).  
	//		fromport---Specifies A 32-bit long signed integer.  
	//		toport---Specifies A 32-bit long signed integer.  
	//		arrowtype---Specifies a short arrowtype object(Value).
	afx_msg void MAddLinkShape(short nLinkType, long fromport, long toport, short arrowtype);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Center Port, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeCenterPort(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Application Name, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		pszAppName---Application Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void SetApplicationName(LPCTSTR pszAppName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape Within Data Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL FindShapeWithinDataModel(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bool User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		bValue---bValue, Specifies A Boolean value.
	afx_msg BOOL AddBoolUserProperty(long shape, long nPropID, BOOL bValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add String User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL AddStringUserProperty(long shape, long nPropID, LPCTSTR strValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Int User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		nValue---nValue, Specifies A 32-bit long signed integer.
	afx_msg BOOL AddIntUserProperty(long shape, long nPropID, long nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Float User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		fValue---fValue, Specifies A float value.
	afx_msg BOOL AddFloatUserProperty(long shape, long nPropID, float fValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Double User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	afx_msg BOOL AddDoubleUserProperty(long shape, long nPropID, double dValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Date User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dtTime---dtTime, Specifies a DATE dtTime object(Value).
	afx_msg BOOL AddDateUserProperty(long shape, long nPropID, DATE dtTime);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Color User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg BOOL AddColorUserProperty(long shape, long nPropID, long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add D Word User Property, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dwData---dwData, Specifies A 32-bit long signed integer.
	afx_msg BOOL AddDWordUserProperty(long shape, long nPropID, long dwData);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Bool Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		bValue---bValue, Specifies A Boolean value.
	afx_msg void ChangeShapeBoolWithoutUndo(long shape, long nPropID, BOOL bValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape String Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void ChangeShapeStringWithoutUndo(long shape, long nPropID, LPCTSTR strValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Int Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		nValue---nValue, Specifies A 32-bit long signed integer.
	afx_msg void ChangeShapeIntWithoutUndo(long shape, long nPropID, long nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Float Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		fValue---fValue, Specifies A float value.
	afx_msg void ChangeShapeFloatWithoutUndo(long shape, long nPropID, float fValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Double Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	afx_msg void ChangeShapeDoubleWithoutUndo(long shape, long nPropID, double dValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape D Word Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dwValue---dwValue, Specifies A 32-bit long signed integer.
	afx_msg void ChangeShapeDWordWithoutUndo(long shape, long nPropID, long dwValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Color Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void ChangeShapeColorWithoutUndo(long shape, long nPropID, long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shape Date Without Undo, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.  
	//		dtValue---dtValue, Specifies a DATE dtValue object(Value).
	afx_msg void ChangeShapeDateWithoutUndo(long shape, long nPropID, DATE dtValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetLinkCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	afx_msg long GetLinkAt(long nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Link Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetSelectedLinkCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Link At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetSelectedLinkAt(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape Without Undo, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void RemoveShapeWithoutUndo(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Links Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeLinksCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Links At Index, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeLinksAtIndex(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape From Links Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeFromLinksCount(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape From Links At Index, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeFromLinksAtIndex(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape To Links Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeToLinksCount(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape To Links At Index, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeToLinksAtIndex(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked From Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedFromShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked From Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedFromShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked To Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedToShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direct Linked To Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetDirectLinkedToShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked From Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedFromShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked From Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedFromShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked To Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedToShapeCount(long node);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Linked To Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		node---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetAllLinkedToShapeAt(long node, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Focus Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetFocusShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape No Undo, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fromNode---fromNode, Specifies A 32-bit long signed integer.  
	//		toNode---toNode, Specifies A 32-bit long signed integer.  
	//		LinkType---Link Type, Specifies a short LinkType object(Value).  
	//		ArrowType---Arrow Type, Specifies a short ArrowType object(Value).
	afx_msg long AddLinkShapeNoUndo(long fromNode, long toNode, short LinkType, short ArrowType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		xTop---xTop, Specifies a short xTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		xBottom---xBottom, Specifies a short xBottom object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddRectShape(short xLeft, short xTop, short xRight, short xBottom, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Text Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		xTop---xTop, Specifies a short xTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		xBottom---xBottom, Specifies a short xBottom object(Value).  
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddTextShape(short xLeft, short xTop, short xRight, short xBottom, LPCTSTR lpszText);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ellipse Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		xTop---xTop, Specifies a short xTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		xBottom---xBottom, Specifies a short xBottom object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddEllipseShape(short xLeft, short xTop, short xRight, short xBottom, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Round Rectangle Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		xTop---xTop, Specifies a short xTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		xBottom---xBottom, Specifies a short xBottom object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddRoundRectShape(short xLeft, short xTop, short xRight, short xBottom, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Hy Link Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddHyLinkShape(short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bitmap File Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddBmpFileShape(short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszFileName, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Emf File Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddEmfFileShape(short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszFileName, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Wmf File Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddWmfFileShape(short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszFileName, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Type, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nType---nType, Specifies a short nType object(Value).  
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddShapeByType(short nType, short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape By File, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		xTop---xTop, Specifies a short xTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		xBottom---xBottom, Specifies a short xBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddCompositeShapeByFile(short xLeft, short xTop, short xRight, short xBottom, LPCTSTR lpszFileName, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Composite Shape By I D, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		nResId---Resource Id, Specifies a short nResId object(Value).  
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddCompositeShapeByID(short xLeft, short yTop, short xRight, short yBottom, short nResId, LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddLineShape(long xStart, long yStart, long xEnd, long yEnd, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Dimension Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddDimLineShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL Read(LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL Write(LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export, .

	afx_msg void Export();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Undo, .

	afx_msg void Undo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Redo, .

	afx_msg void Redo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .

	afx_msg void Cut();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.

	afx_msg void Copy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .

	afx_msg void Paste();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	afx_msg void Clear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	afx_msg void ClearAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select All, Call this function to select the given item.

	afx_msg void SelectAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Grid, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetShowGrid();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Grid, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bGrid---bGrid, Specifies A Boolean value.
	afx_msg void SetShowGrid(BOOL bGrid);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Grid Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnGridProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Design Mode, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetDesignMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Design Mode, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bMode---bMode, Specifies A Boolean value.
	afx_msg void SetDesignMode(BOOL bMode);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap To Grid, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetSnapToGrid();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap To Grid, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bSnap---bSnap, Specifies A Boolean value.
	afx_msg void SetSnapToGrid(BOOL bSnap);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Glue To Handle, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetGlueToHandle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Glue To Handle, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bGlue---bGlue, Specifies A Boolean value.
	afx_msg void SetGlueToHandle(BOOL bGlue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Page Break Line, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetShowPageBreakLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Page Break Line, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	afx_msg void SetShowPageBreakLine(BOOL bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Port, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetShowPort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Port, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	afx_msg void SetShowPort(BOOL bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Percent, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetZoomPercent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Zoom Percent, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nZoom---nZoom, Specifies A 32-bit long signed integer.
	afx_msg void SetZoomPercent(long nZoom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom In, .

	afx_msg void ZoomIn();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom Out, .

	afx_msg void ZoomOut();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page, .

	afx_msg void ZoomToFitPage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page Height, .

	afx_msg void ZoomToFitPageHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page Width, .

	afx_msg void ZoomToFitPageWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Select, .

	afx_msg void ZoomToFitSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Rectangle, .
	// Parameters:
	//		xLeft---xLeft, Specifies A 32-bit long signed integer.  
	//		yTop---yTop, Specifies A 32-bit long signed integer.  
	//		xRight---xRight, Specifies A 32-bit long signed integer.  
	//		yBottom---yBottom, Specifies A 32-bit long signed integer.
	afx_msg void ZoomToRect(long xLeft, long yTop, long xRight, long yBottom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Selection, .

	afx_msg void ZoomToSelection();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Zoom Within Rectangle, Do a event. 

	afx_msg void DoZoomWithinRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Page Property Dialog, Do a event. 

	afx_msg void DoShowPagePropDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Header And Footer Dialog, Do a event. 

	afx_msg void DoShowHeaderAndFooterDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Text Dialog, Do a event. 

	afx_msg void DoShowTextDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Bullets Dialog, Do a event. 

	afx_msg void DoShowBulletsDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Line Dialog, Do a event. 

	afx_msg void DoShowLineDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Fill Dialog, Do a event. 

	afx_msg void DoShowFillDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Shadow Dialog, Do a event. 

	afx_msg void DoShowShadowDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Event Dialog, Do a event. 

	afx_msg void DoShowEventDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Custom Dialog, Do a event. 

	afx_msg void DoShowCustomDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Select, Do a event. 

	afx_msg void DoDrawSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 

	afx_msg void DoDrawLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Line, Do a event. 

	afx_msg void DoDrawArrowLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Cross Line, Do a event. 

	afx_msg void DoDrawCrossLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Bezier Line, Do a event. 

	afx_msg void DoDrawArrowBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Dimension Line, Do a event. 

	afx_msg void DoDrawDimLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Free Line, Do a event. 

	afx_msg void DoDrawFreeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Free Close Line, Do a event. 

	afx_msg void DoDrawFreeCloseLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 

	afx_msg void DoDrawPolyLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon, Do a event. 

	afx_msg void DoDrawPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse, Do a event. 

	afx_msg void DoDrawEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Rectangle, Do a event. 

	afx_msg void DoDrawRectangle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Rectangle, Do a event. 

	afx_msg void DoDrawRoundRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Close Bezier, Do a event. 

	afx_msg void DoDrawCloseBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Line, Do a event. 

	afx_msg void DoDrawBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Static, Do a event. 

	afx_msg void DoDrawStatic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Button, Do a event. 

	afx_msg void DoDrawButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Do Draw Image, Do a event. 

	afx_msg void DoDoDrawImage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Port, Do a event. 

	afx_msg void DoDrawPort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Custom Rectangle, Draws current object to the specify device.
	// Parameters:
	//		nType---nType, Specifies A 32-bit long signed integer.
	afx_msg void DrawCustomRect(long nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Link Normal, Do a event. 

	afx_msg void DoDrawLinkNormal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Link Up Right, Do a event. 

	afx_msg void DoDrawLinkUpRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Corner Link, Do a event. 

	afx_msg void DoDrawCornerLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Link, Do a event. 

	afx_msg void DoDrawBezierLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate, Do a event. 

	afx_msg void DoRotate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Left, Do a event. 

	afx_msg void DoRotateLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Right, Do a event. 

	afx_msg void DoRotateRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flip Horizontal, Do a event. 

	afx_msg void DoFlipHorz();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flip Vertical, Do a event. 

	afx_msg void DoFlipVert();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Angle, .
	// Parameters:
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.
	afx_msg void RotateAngle(long nAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetRotateShapeCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Group, .

	afx_msg void Group();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Un Group, .

	afx_msg void UnGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Un Group, Call this member function to enable or disable the specify object for this command.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL EnableUnGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Left, Do a event. 

	afx_msg void DoAlignLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Right, Do a event. 

	afx_msg void DoAlignRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Top, Do a event. 

	afx_msg void DoAlignTop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Bottom, Do a event. 

	afx_msg void DoAlignBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Center, Do a event. 

	afx_msg void DoAlignCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Vcenter, Do a event. 

	afx_msg void DoAlignVcenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Inview Hor, Do a event. 

	afx_msg void DoAlignInviewHor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Inview Ver, Do a event. 

	afx_msg void DoAlignInviewVer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Across, Do a event. 

	afx_msg void DoSpaceAcross();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Down, Do a event. 

	afx_msg void DoSpaceDown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Width, Do a event. 

	afx_msg void DoSizeWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Height, Do a event. 

	afx_msg void DoSizeHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size All, Do a event. 

	afx_msg void DoSizeAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Lockcomp, Do a event. 

	afx_msg void DoLockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Unlockcomp, Do a event. 

	afx_msg void DoUnlockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Forward, Do a event. 

	afx_msg void DoMoveForward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Back, Do a event. 

	afx_msg void DoMoveBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Backward, Do a event. 

	afx_msg void DoMoveBackward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgeleft, Do a event. 

	afx_msg void DoCmdNudgeleft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgeright, Do a event. 

	afx_msg void DoCmdNudgeright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgetop, Do a event. 

	afx_msg void DoCmdNudgetop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgebottom, Do a event. 

	afx_msg void DoCmdNudgebottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Automatic Pan, Do a event. 

	afx_msg void DoCmdAutoPan();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetTotalSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Edit Spot, Do a event. 

	afx_msg void DoEditSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Selection Handles, Remove the specify data from the list.

	afx_msg void ClearSelectionHandles();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Selection Handles, .

	afx_msg void RestoreSelectionHandles();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Selection, Call this member function to update the object.

	afx_msg void UpdateSelection();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Size, Call this member function to update the object.

	afx_msg void UpdateScrollSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Tab Order, Do a event. 

	afx_msg void DoTabOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified Flag, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bFlag---bFlag, Specifies A Boolean value.
	afx_msg void SetModifiedFlag(BOOL bFlag);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modified Flag, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL GetModifiedFlag();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xPoint---xPoint, Specifies A 32-bit long signed integer.  
	//		yPoint---yPoint, Specifies A 32-bit long signed integer.
	afx_msg long HitTest(long xPoint, long yPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, Hit test on this object.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xPoint---xPoint, Specifies A 32-bit long signed integer.  
	//		yPoint---yPoint, Specifies A 32-bit long signed integer.
	afx_msg long HitTestPort(long xPoint, long yPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Components Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCompsCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Position, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		xLeft---xLeft, Specifies A 32-bit long signed integer.  
	//		yTop---yTop, Specifies A 32-bit long signed integer.  
	//		xRight---xRight, Specifies A 32-bit long signed integer.  
	//		yBottom---yBottom, Specifies A 32-bit long signed integer.
	afx_msg void SetPagePosition(long xLeft, long yTop, long xRight, long yBottom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Position With Pages, .
	// Parameters:
	//		nHorzPages---Horizontal Pages, Specifies A 32-bit long signed integer.  
	//		nVertPages---Vertical Pages, Specifies A 32-bit long signed integer.
	afx_msg void ChangePositionWithPages(long nHorzPages, long nVertPages);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lock With Pages, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bLock---bLock, Specifies A Boolean value.
	afx_msg void SetLockWithPages(BOOL bLock);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Color, Returns the specified value.
	//		Returns A afx_msg OLE_COLOR value (Object).
	afx_msg OLE_COLOR GetGridColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetGridColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid X, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetGridX();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid X, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.
	afx_msg void SetGridX(long nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Y, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetGridY();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Y, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.
	afx_msg void SetGridY(long nValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetBkColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetBkColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Background Color, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetPageBkColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Background Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetPageBkColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetBrushType();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nType---nType, Specifies a short nType object(Value).
	afx_msg void SetBrushType(short nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetPatternColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetPatternColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Form Mode, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsFormMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Form Mode, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bForm---bForm, Specifies A Boolean value.
	afx_msg void SetFormMode(BOOL bForm);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Command State, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCommandState();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Undo, .
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL CanUndo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Redo, .
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL CanRedo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Paste, .
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL CanPaste();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Style, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetGridStyle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Type, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nType---nType, Specifies a short nType object(Value).
	afx_msg void SetGridLineType(short nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Bool Property, .
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelBoolProp(BOOL bValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model String Property, .
	// Parameters:
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelStringProp(LPCTSTR strValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Int Property, .
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelIntProp(long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model U I N T Property, .
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelUINTProp(long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Float Property, .
	// Parameters:
	//		fValue---fValue, Specifies A float value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelFloatProp(float fValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Double Property, .
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelDoubleProp(double dValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Date Time Property, .
	// Parameters:
	//		dtValue---dtValue, Specifies a DATE dtValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelDateTimeProp(DATE dtValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model Color Property, .
	// Parameters:
	//		crValue---crValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeModelColorProp(long crValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Model D Word Property, .
	// Parameters:
	//		dwValue---dwValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies a short nPropID object(Value).
	afx_msg void ChangeModelDWordProp(long dwValue, short nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Bool Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		bValue---bValue, Specifies A Boolean value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeBoolProp(long shape, BOOL bValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape String Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeStringProp(long shape, LPCTSTR strValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Int Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeIntProp(long shape, long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape U I N T Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeUINTProp(long shape, long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Float Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		fValue---fValue, Specifies A float value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeFloatProp(long shape, float fValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Double Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeDoubleProp(long shape, double dValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Date Time Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dtValue---dtValue, Specifies a DATE dtValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeDateTimeProp(long shape, DATE dtValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Color Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		crValue---crValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeColorProp(long shape, long crValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape D Word Property, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dwValue---dwValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSingleShapeDWordProp(long shape, long dwValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Bool Property, .
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionBoolProp(BOOL bValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection String Property, .
	// Parameters:
	//		strValue---strValue, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionStringProp(LPCTSTR strValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Int Property, .
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionIntProp(long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection U I N T Property, .
	// Parameters:
	//		nValue---nValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionUINTProp(long nValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Float Property, .
	// Parameters:
	//		fValue---fValue, Specifies A float value.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionFloatProp(float fValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Double Property, .
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionDoubleProp(double dValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Date Time Property, .
	// Parameters:
	//		dtValue---dtValue, Specifies a DATE dtValue object(Value).  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionDateTimeProp(DATE dtValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Color Property, .
	// Parameters:
	//		crValue---crValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionColorProp(long crValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection D Word Property, .
	// Parameters:
	//		dwValue---dwValue, Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg void ChangeSelectionDWordProp(long dwValue, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add User Data, Adds an object to the specify list.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dwData---dwData, Specifies A 32-bit long signed integer.
	afx_msg void AddUserData(long shape, long dwData);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get User Data, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetUserData(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shape, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nxOffset---nxOffset, Specifies A 32-bit long signed integer.  
	//		nyOffset---nyOffset, Specifies A 32-bit long signed integer.
	afx_msg void MoveShape(long shape, long nxOffset, long nyOffset);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Shape, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dScaleX---Scale X, Specifies a double dScaleX object(Value).  
	//		dScaleY---Scale Y, Specifies a double dScaleY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	afx_msg void ResizeShape(long shape, double dScaleX, double dScaleY, double dOX, double dOY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	afx_msg void RotateShape(long shape, long nAngle, double dOX, double dOY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		xLeft---xLeft, Specifies A 32-bit long signed integer.  
	//		yTop---yTop, Specifies A 32-bit long signed integer.  
	//		xRight---xRight, Specifies A 32-bit long signed integer.  
	//		yBottom---yBottom, Specifies A 32-bit long signed integer.
	afx_msg void PositionShape(long shape, long xLeft, long yTop, long xRight, long yBottom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Select Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCurrentSelectShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		lpszCaption---lpszCaption, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeByCaption(LPCTSTR lpszCaption);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		lpszName---lpszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeByName(LPCTSTR lpszName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Page Setup, Do a event. 

	afx_msg void DoPageSetup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Edit Spots, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEditSpots();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Components Select Dialog, Do a event. 

	afx_msg void DoShowCompsSelectDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Group Shapes, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetTotalGroupShapes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Front, Do a event. 

	afx_msg void DoMoveFront();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Tab Order, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsTabOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Type, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetDrawType();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Shape I D, Do a event. 
	// Parameters:
	//		nResID---Resource I D, Specifies A 32-bit long signed integer.
	afx_msg void DoDrawCustomShapeID(long nResID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Custom Shape File, Do a event. 
	// Parameters:
	//		lpszResFile---Resource File, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void DoDrawCustomShapeFile(LPCTSTR lpszResFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Shapes, Call this member function to update the object.

	afx_msg void UpdateAllShapes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Canvas, Call this member function to update the object.

	afx_msg void UpdateCanvas();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Table, Do a event. 

	afx_msg void DoDrawTable();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line, Do a event. 

	afx_msg void DoDrawArcLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Pie, Do a event. 

	afx_msg void DoDrawPie();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Pan Window Show, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsPanWndShow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Disappear Handle, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableDisappearHandle(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Pick Nearest, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnablePickNearest();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Pick Nearest, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnablePickNearest(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Angle Snap Enabled, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAngleSnapEnabled();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Angle Snap, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableAngleSnap(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap Angle, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nWink---nWink, Specifies A 32-bit long signed integer.
	afx_msg void SetSnapAngle(long nWink);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Angle, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetSnapAngle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Primary Selection Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetPrimarySelectionColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Secondary Selection Color, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit long signed integer.
	afx_msg void SetSecondarySelectionColor(long crColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Port, Adds an object to the specify list.
	// Parameters:
	//		dScaleX---Scale X, Specifies a double dScaleX object(Value).  
	//		dScaleY---Scale Y, Specifies a double dScaleY object(Value).
	afx_msg void AddShapePort(double dScaleX, double dScaleY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Multiple Select, Do a event. 

	afx_msg void DoDrawMultiSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddArcLineShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tab Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nLeft---nLeft, Specifies A 32-bit long signed integer.  
	//		nTop---nTop, Specifies A 32-bit long signed integer.  
	//		nRight---nRight, Specifies A 32-bit long signed integer.  
	//		nBottom---nBottom, Specifies A 32-bit long signed integer.  
	//		nRows---nRows, Specifies A 32-bit long signed integer.  
	//		nCols---nCols, Specifies A 32-bit long signed integer.  
	//		bFixRows---Fix Rows, Specifies A Boolean value.  
	//		bFixCols---Fix Cols, Specifies A Boolean value.  
	//		bShowGridLine---Show Grid Line, Specifies A Boolean value.
	afx_msg long AddTabShape(long nLeft, long nTop, long nRight, long nBottom, long nRows, long nCols, BOOL bFixRows, BOOL bFixCols, BOOL bShowGridLine);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Select Mode, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsMultiSelectMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		ptXStart---X Start, Specifies A 32-bit long signed integer.  
	//		ptYStart---Y Start, Specifies A 32-bit long signed integer.  
	//		ptXEnd---X End, Specifies A 32-bit long signed integer.  
	//		ptYEnd---Y End, Specifies A 32-bit long signed integer.
	afx_msg long AddPieShape(long xStart, long yStart, long xEnd, long yEnd, long ptXStart, long ptYStart, long ptXEnd, long ptYEnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ellipse Chord Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		ptXStart---X Start, Specifies A 32-bit long signed integer.  
	//		ptYStart---Y Start, Specifies A 32-bit long signed integer.  
	//		ptXEnd---X End, Specifies A 32-bit long signed integer.  
	//		ptYEnd---Y End, Specifies A 32-bit long signed integer.
	afx_msg long AddEllipseChordShape(long xStart, long yStart, long xEnd, long yEnd, long ptXStart, long ptYStart, long ptXEnd, long ptYEnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc Line2 Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		ptXStart---X Start, Specifies A 32-bit long signed integer.  
	//		ptYStart---Y Start, Specifies A 32-bit long signed integer.  
	//		ptXEnd---X End, Specifies A 32-bit long signed integer.  
	//		ptYEnd---Y End, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddArcLine2Shape(long xStart, long yStart, long xEnd, long yEnd, long ptXStart, long ptYStart, long ptXEnd, long ptYEnd, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Help Line Visible, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bVisible---bVisible, Specifies A Boolean value.
	afx_msg void SetHlpLineVisible(BOOL bVisible);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line2, Do a event. 

	afx_msg void DoDrawArcLine2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse Chord, Do a event. 

	afx_msg void DoDrawEllipseChord();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mirror Free, Do a event. 

	afx_msg void DoMirrorFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove Help Line, Do a event. 

	afx_msg void DoRemoveHlpLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Position And Size Dialog, Do a event. 

	afx_msg void DoShowPosAndSizeDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As Bitmap File, .
	// Parameters:
	//		strFile---strFile, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void ExportAsBitmapFile(LPCTSTR strFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As E M F File, .
	// Parameters:
	//		strFile---strFile, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void ExportAsEMFFile(LPCTSTR strFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Extend Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddExtLineShape(long xStart, long yStart, long xEnd, long yEnd, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Horizontal Dimension Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddHorzDimLineShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Vertical Dimension Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddVertDimLineShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Radius Dimension Line Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddRadiusDimLineShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Caption Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.  
	//		bArrow---bArrow, Specifies A Boolean value.
	afx_msg long AddCaptionShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, long nHeight, BOOL bArrow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle Callout Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.
	afx_msg long AddRectCalloutShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, long nHeight);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Round Callout Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.
	afx_msg long AddRoundCalloutShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, long nHeight);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Cloud Callout Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.
	afx_msg long AddCloudCalloutShape(long xStart, long yStart, long xEnd, long yEnd, long nWidth, long nHeight);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Help Line Visible, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsHlpLineVisible();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Help Line, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapToHelpLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Help Line, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapToHelpLine(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To  Handle, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapToControlHandle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To  Handle, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapToControlHandle(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Spot, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapToSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Spot, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapToSpot(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap To Intersect Point, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapToIntersectPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap To Intersect Point, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapToIntersectPoint(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Center Draw Allowed, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsCenterDrawAllowed();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Center Draw, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableCenterDraw(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Captionline, Do a event. 

	afx_msg void DoDrawCaptionline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Rectangle Callout, Do a event. 

	afx_msg void DoDrawRectCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Callout, Do a event. 

	afx_msg void DoDrawRoundCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Cloud Callout, Do a event. 

	afx_msg void DoDrawCloudCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Horizontal Dimline, Do a event. 

	afx_msg void DoDrawHorzDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Vertical Dimline, Do a event. 

	afx_msg void DoDrawVertDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Radius Dimline, Do a event. 

	afx_msg void DoDrawRadiusDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Extend Line, Do a event. 

	afx_msg void DoDrawExtLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Reverse Order, Do a event. 

	afx_msg void DoReverseOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Infront Shape, Do a event. 

	afx_msg void DoInfrontShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Behind Shape, Do a event. 

	afx_msg void DoBehindShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ruler Visible, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsRulerVisible();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Rulers, Call this function to show the specify object.
	// Parameters:
	//		bVisible---bVisible, Specifies A Boolean value.
	afx_msg void ShowRulers(BOOL bVisible);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Unit, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		nType---nType, Specifies a short nType object(Value).
	afx_msg void SetRulerUnit(short nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Put Shape To Back, Do a event. 

	afx_msg void DoPutShapeToBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fo Polygon Insertpoint, Do a event. 

	afx_msg void DoFoPolyInsertpoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Insert Point, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowInsertPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fo Polygon Deletepoint, Do a event. 

	afx_msg void DoFoPolyDeletepoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Delete Point, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowDeletePoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment Toline, Do a event. 

	afx_msg void DoConvertSegmentToline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert Segment To Line, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowConvertSegmentToLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment To Curve, Do a event. 

	afx_msg void DoConvertSegmentToCurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert Segment To Curve, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowConvertSegmentToCurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rip Up Point, Do a event. 

	afx_msg void DoRipUpPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Rip Up Point, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowRipUpPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Turn Corner Link Line, Do a event. 

	afx_msg void DoDrawTurnCornerLinkLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Break Center Link Line, Do a event. 

	afx_msg void DoDrawBreakCenterLinkLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Ellipse Select, Do a event. 

	afx_msg void DoEllipseSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path, Do a event. 

	afx_msg void DoConvertToPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert To Path, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowConvertToPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Polygon, Do a event. 

	afx_msg void DoConvertToPoly();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert To Polygon, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowConvertToPoly();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Combine, Do a event. 

	afx_msg void DoShapesCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Combine, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShapeCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Dismantle, Do a event. 

	afx_msg void DoShapesDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Dismantle, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShapeDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Merge, Do a event. 

	afx_msg void DoShapesMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Merge, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShapeMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Substract, Do a event. 

	afx_msg void DoShapesMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Substract, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShapeMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Intersect, Do a event. 

	afx_msg void DoShapesMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Intersect, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShapeMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Connect Lines, Do a event. 

	afx_msg void DoConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Connect Lines, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Break Shape To Lines, Do a event. 

	afx_msg void DoBreakShapeToLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Break Shape To Lines, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowBreakShapeToLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Close Shape, Do a event. 

	afx_msg void DoCloseShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Close Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowCloseShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shear Free, Do a event. 

	afx_msg void DoShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shear Free, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ellipse Select Mode, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEllipseSelectMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Select Shapes, .

	afx_msg void ConnectSelectShapes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Create Link, Do a event. 

	afx_msg void DoGenCreateLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Selection, Adds an object to the specify list.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void AddToSelection(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void RemoveShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Bool Property, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg BOOL GetShapeBoolProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape String Property, Returns the specified value.
	//		Returns A 32-bit BSTR character pointer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg BSTR GetShapeStringProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Int Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg long GetShapeIntProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape U I N T Property, Returns the specified value.
	//		Returns A afx_msg short value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg short GetShapeUINTProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Float Property, Returns the specified value.
	//		Returns a float value.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg float GetShapeFloatProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Double Property, Returns the specified value.
	//		Returns A afx_msg double value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg double GetShapeDoubleProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Date Time Property, Returns the specified value.
	//		Returns A afx_msg DATE value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg DATE GetShapeDateTimeProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Color Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg long GetShapeColorProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Dword Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg long GetShapeDwordProp(long shape, long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Two Shapes, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shapefirst---Specifies A 32-bit long signed integer.  
	//		shapesecond---Specifies A 32-bit long signed integer.
	afx_msg long ConnectTwoShapes(long shapefirst, long shapesecond);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Static Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsStaticShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Linked, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsShapeLinked(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound X Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetBoundXPos(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Y Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetBoundYPos(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetBoundWidth(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Height, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetBoundHeight(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap X Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetSnapXPos(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Y Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetSnapYPos(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetSnapWidth(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Height, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetSnapHeight(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Polygon Object, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsPolyObject(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Rotate Angle, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		angle---Specifies A 32-bit long signed integer.
	afx_msg void SetInitRotateAngle(long shape, long angle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void UpdateComp(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsShapeClosed(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set With Label Show, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		allow---Specifies A Boolean value.
	afx_msg void SetWithLabelShow(long shape, BOOL allow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set With Label Editing, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		allow---Specifies A Boolean value.
	afx_msg void SetWithLabelEditing(long shape, BOOL allow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Link Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsLinkShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Composite Shape, .
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL isCompositeShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Group Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsGroupShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Kind Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		type---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsKindShape(long shape, long type);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetSelectionCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetSelection(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeAt(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Composite Shape Child Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shapecomposite---Specifies A 32-bit long signed integer.
	afx_msg long GetCompositeShapeChildCount(long shapecomposite);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Composite Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		compositeshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetCompositeShapeAt(long compositeshape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Shape Port Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portsshape---Specifies A 32-bit long signed integer.
	afx_msg long GetPortsShapePortCount(long portsshape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Shape Port Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portsshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetPortsShapePortShapeAt(long portsshape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Link Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portshape---Specifies A 32-bit long signed integer.
	afx_msg long GetPortLinkCount(long portshape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Link Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetPortLinkShapeAt(long portshape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link From Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		link---Specifies A 32-bit long signed integer.
	afx_msg long GetLinkFromShape(long link);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link To Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		link---Specifies A 32-bit long signed integer.
	afx_msg long GetLinkToShape(long link);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link From Port, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		link---Specifies A 32-bit long signed integer.
	afx_msg long GetLinkFromPort(long link);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link To Port, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		link---Specifies A 32-bit long signed integer.
	afx_msg long GetLinkToPort(long link);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Current Shape To Selection, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void RemoveCurShapeToSelection(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Selected, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsShapeSelected(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Port Shape, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg BOOL IsPortShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Default Port, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portsshape---Specifies A 32-bit long signed integer.  
	//		xscale---Specifies a double xscale object(Value).  
	//		yscale---Specifies a double yscale object(Value).
	afx_msg long AddDefaultPort(long portsshape, double xscale, double yscale);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect With Two Ports, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portFirst---portFirst, Specifies A 32-bit long signed integer.  
	//		portSecond---portSecond, Specifies A 32-bit long signed integer.
	afx_msg long ConnectWithTwoPorts(long portFirst, long portSecond);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flash Shape, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		times---Specifies a short times object(Value).
	afx_msg void FlashShape(long shape, short times);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Undo Action Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetMaxUndoActionCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Redo Action Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetMaxRedoActionCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Undo Action Count, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		count---Specifies a short count object(Value).
	afx_msg void SetMaxUndoActionCount(short count);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Redo Action Count, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		count---Specifies a short count object(Value).
	afx_msg void SetMaxRedoActionCount(short count);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Ruler Unit, .
	// Parameters:
	//		unit---Specifies a short unit object(Value).
	afx_msg void ChangeRulerUnit(short unit);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Shape, Call this function to select the given item.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void SelectShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetBackgroundShapeCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetBackShapeAt(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape To Back, Adds an object to the specify list.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void AddShapeToBack(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape From Back, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void RemoveShapeFromBack(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes From Back, Call this function to remove a specify value from the specify object.

	afx_msg void RemoveAllShapesFromBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Name From Back, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		name---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long FindShapeWithNameFromBack(LPCTSTR name);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone Shape, Clone this object.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long CloneShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Ports, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		portsshape---Specifies A 32-bit long signed integer.
	afx_msg void RemoveAllPorts(long portsshape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Point Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapePointCount(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Point X At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapePointXAt(long shape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Point Y At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg long GetShapePointYAt(long shape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Point, Adds an object to the specify list.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.
	afx_msg void AddShapePoint(long shape, long x, long y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape Point, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.
	afx_msg void RemoveShapePoint(long shape, long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Shape Point, Inserts a child object at the given index..
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.  
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.
	afx_msg void InsertShapePoint(long shape, long index, long x, long y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape Point At, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		index---Specifies A 32-bit long signed integer.  
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.
	afx_msg void SetShapePointAt(long shape, long index, long x, long y);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P X, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xInput---xInput, Specifies A 32-bit long signed integer.
	afx_msg long FODPtoLPX(long xInput);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P Y, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		yInput---yInput, Specifies A 32-bit long signed integer.
	afx_msg long FODPtoLPY(long yInput);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P X, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xInput---xInput, Specifies a short xInput object(Value).
	afx_msg long FOLPtoDPX(short xInput);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P Y, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		yInput---yInput, Specifies A 32-bit long signed integer.
	afx_msg long FOLPtoDPY(long yInput);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Unique Caption, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableUniqueCaption(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Unique Name, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableUniqueName(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Parent Shape, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		portShape---portShape, Specifies A 32-bit long signed integer.
	afx_msg long GetPortParentShape(long portShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Shape, You construct a CFOMethodHost object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nType---nType, Specifies a short nType object(Value).  
	//		xLeft---xLeft, Specifies a short xLeft object(Value).  
	//		yTop---yTop, Specifies a short yTop object(Value).  
	//		xRight---xRight, Specifies a short xRight object(Value).  
	//		yBottom---yBottom, Specifies a short yBottom object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long CreateShape(short nType, short xLeft, short yTop, short xRight, short yBottom, LPCTSTR lpszFileName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add List Field, Adds an object to the specify list.
	// Parameters:
	//		listshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies a short index object(Value).  
	//		bshowleftport---Specifies A Boolean value.  
	//		bshowrightport---Specifies A Boolean value.  
	//		strfield---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg void AddListField(long listshape, short index, BOOL bshowleftport, BOOL bshowrightport, LPCTSTR strfield);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shape Geogmetry, Call this member function to update the object.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void UpdateShapeGeo(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port From Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		listshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies a short index object(Value).  
	//		bLeftPort---Left Port, Specifies A Boolean value.
	afx_msg long FindPortFromIndex(long listshape, short index, BOOL bLeftPort);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Link Two Field, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		fromport---Specifies A 32-bit long signed integer.  
	//		toport---Specifies A 32-bit long signed integer.
	afx_msg long LinkTwoField(long fromport, long toport);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Field Count Of List , Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		listshape---Specifies A 32-bit long signed integer.
	afx_msg long GetFieldCountOfListCtrl(long listshape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Field Caption, Returns the specified value.
	//		Returns A 32-bit BSTR character pointer.  
	// Parameters:
	//		listshape---Specifies A 32-bit long signed integer.  
	//		index---Specifies a short index object(Value).
	afx_msg BSTR GetFieldCaption(long listshape, short index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image Node, Do a event. 
	// Parameters:
	//		iPictureDisp---Picture Disp, Specifies a LPDISPATCH iPictureDisp object(Value).
	afx_msg void DoDrawImageNode(LPDISPATCH iPictureDisp);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Continue Draw, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableContinueDraw(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Make Subgraph, Do a event. 

	afx_msg void DoMakeSubgraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Un Group Subgraph, .

	afx_msg void UnGroupSubgraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do V C Print Preview, Do a event. 

	afx_msg void DoVCPrintPreview();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Bool Property, Returns the specified value.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg BOOL GetModelBoolProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model String Property, Returns the specified value.
	//		Returns A 32-bit BSTR character pointer.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg BSTR GetModelStringProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Int Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg long GetModelIntProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Float Property, Returns the specified value.
	//		Returns a float value.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg float GetModelFloatProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Double Property, Returns the specified value.
	//		Returns A afx_msg double value (Object).  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg double GetModelDoubleProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Date Time Property, Returns the specified value.
	//		Returns A afx_msg DATE value (Object).  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg DATE GetModelDateTimeProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model Color Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nPropID---Property I D, Specifies A float value.
	afx_msg long GetModelColorProp(float nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model D Word Property, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nPropID---Property I D, Specifies A 32-bit long signed integer.
	afx_msg long GetModelDWordProp(long nPropID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse2, Do a event. 

	afx_msg void DoDrawEllipse2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw New Bizer Line, Do a event. 

	afx_msg void DoDrawNewBizerLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enter Editing Back, .

	afx_msg void EnterEditingBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Editing Back, .

	afx_msg void EndEditingBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsModified();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Automatic Reroute, Do a event. 

	afx_msg void DoAutoReroute();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Simple Path Shape, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		xStart---xStart, Specifies A 32-bit long signed integer.  
	//		yStart---yStart, Specifies A 32-bit long signed integer.  
	//		xEnd---xEnd, Specifies A 32-bit long signed integer.  
	//		yEnd---yEnd, Specifies A 32-bit long signed integer.  
	//		nType---nType, Specifies a short nType object(Value).
	afx_msg long AddSimplePathShape(long xStart, long yStart, long xEnd, long yEnd, short nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Free Form Drawing, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableFreeFormDrawing(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Free Form Drawing, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsFreeFormDrawing();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap Dyn Grid, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapDynGrid();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap Dyn Grid, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapDynGrid(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Snap Aid Line, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void EnableSnapAidLine(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Snap Aid Line, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsEnableSnapAidLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Color Theme Dialog, Call this function to show the specify object.

	afx_msg void ShowColorThemeDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Curve Link, Do a event. 

	afx_msg void DoDrawCurveLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Corner Link Line, Do a event. 

	afx_msg void DoDrawRoundCornerLinkLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shape To, .
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		xPos---xPos, Specifies A 32-bit long signed integer.  
	//		yPos---yPos, Specifies A 32-bit long signed integer.
	afx_msg void MoveShapeTo(long shape, long xPos, long yPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Cache, Adds an object to the specify list.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strKey1---strKey1, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL AddToCache(LPCTSTR strKey1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape Count, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	afx_msg long GetCacheShapeCount();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape At2, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		strKey1---strKey1, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long GetCacheShapeAt2(LPCTSTR strKey1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nIndex---nIndex, Specifies a short nIndex object(Value).
	afx_msg long GetCacheShapeAt(short nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache Shapes, Remove the specify data from the list.

	afx_msg void ClearCacheShapes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Link Type And Arrow, Call InitLinkTypeAndArrow after creating a new object.
	// Parameters:
	//		nLinkType---Link Type, Specifies a short nLinkType object(Value).  
	//		nArrowType---Arrow Type, Specifies a short nArrowType object(Value).
	afx_msg void InitLinkTypeAndArrow(short nLinkType, short nArrowType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load New Trs File, Call this function to read a specified number of bytes from the archive.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strTrsFile---Trs File, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg BOOL LoadNewTrsFile(LPCTSTR strTrsFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape By Trs, Adds an object to the specify list.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.  
	//		strKey1---strKey1, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	afx_msg long AddShapeByTrs(long x, long y, long nWidth, long nHeight, LPCTSTR strKey1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Port Pin Name, Call this function to show the specify object.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	afx_msg void ShowPortPinName(BOOL bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All From Selection, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	afx_msg void RemoveAllFromSelection(BOOL bRedraw);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Color Prop2, Returns the specified value.
	//		Returns A afx_msg OLE_COLOR value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		nPropId---Property Id, Specifies A 32-bit long signed integer.
	afx_msg OLE_COLOR GetShapeColorProp2(long shape, long nPropId);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Free, Do a event. 

	afx_msg void DoBendFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Bend Free, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsAllowBendFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Path Count, Returns the specified value.
	//		Returns A afx_msg short value (Object).  
	// Parameters:
	//		pathshape---Specifies A 32-bit long signed integer.
	afx_msg short GetSubPathCount(long pathshape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count Child Path, Returns the specified value.
	//		Returns A afx_msg short value (Object).  
	// Parameters:
	//		pathshape---Specifies A 32-bit long signed integer.  
	//		segment---Specifies a short segment object(Value).
	afx_msg short GetPointCountSubPath(long pathshape, short segment);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment Type, Returns the specified value.
	//		Returns A afx_msg short value (Object).  
	// Parameters:
	//		pathshape---Specifies A 32-bit long signed integer.  
	//		segment---Specifies a short segment object(Value).  
	//		ptIndex---ptIndex, Specifies a short ptIndex object(Value).
	afx_msg short GetSegmentType(long pathshape, short segment, short ptIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select New Shape, Call this function to select the given item.
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg void SelectNewShape(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Hole Link, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void SetAllowHoleLink(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Key Dialog, Do a event. 

	afx_msg void DoShowKeyDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Map Logical, .
	//		Returns A afx_msg double value (Object).  
	// Parameters:
	//		dConvertValue---Convert Value, Specifies a double dConvertValue object(Value).  
	//		nUnit---nUnit, Specifies a short nUnit object(Value).  
	//		bVert---bVert, Specifies A Boolean value.
	afx_msg double ConvertToMapLog(double dConvertValue, short nUnit, BOOL bVert);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gauge Current Value, Returns the specified value.
	//		Returns A afx_msg double value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg double GetGaugeCurrentValue(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gauge Current Value, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	afx_msg void SetGaugeCurrentValue(long shape, double dValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	//		Returns A afx_msg double value (Object).  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg double GetCurrentValue(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		dValue---dValue, Specifies a double dValue object(Value).
	afx_msg void SetCurrentValue(long shape, double dValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Scroll Bar, Call this function to show the specify object.
	// Parameters:
	//		bHorzVisible---Horizontal Visible, Specifies A Boolean value.  
	//		bVertVisible---Vertical Visible, Specifies A Boolean value.
	afx_msg void ShowScrollBar(BOOL bHorzVisible, BOOL bVertVisible);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape I D, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.
	afx_msg long GetShapeID(long shape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape I D, Sets a specify value to current class CFOMethodHost
	// Parameters:
	//		shape---Specifies A 32-bit long signed integer.  
	//		ID---D, Specifies A 32-bit long signed integer.
	afx_msg void SetShapeID(long shape, long ID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape By I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nID---I D, Specifies A 32-bit long signed integer.
	afx_msg long FindShapeByID(long nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Update, .
	// Parameters:
	//		bLock---bLock, Specifies A Boolean value.
	afx_msg void LockUpdate(BOOL bLock);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock Update, Determines if the given value is correct or exist.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL IsLockUpdate();
	//}}AFX_DISPATCH
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D I S P A T C H_ M A P, .
	//		Returns A  value (Object).
	DECLARE_DISPATCH_MAP()
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ I N T E R F A C E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_INTERFACE_MAP()
};

// Note: we add support for IID_IFOMethodHost to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {BBD4DAF6-616A-4BF6-A920-F90A5C7E2B39}
static const IID IID_IFOMethodHost =
{ 0xbbd4daf6, 0x616a, 0x4bf6, { 0xa9, 0x20, 0xf9, 0xa, 0x5c, 0x7e, 0x2b, 0x39 } };


#endif // !defined(FO_FOMETHODHOST_H__DE819656_0298_4462_8ACF_D5CF0E69FBFB__INCLUDED_)
