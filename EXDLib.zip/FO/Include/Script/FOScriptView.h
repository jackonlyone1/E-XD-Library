//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOSCRIPTVIEW_H__EA646830_62C3_4EE7_B367_D76A89EA6145__INCLUDED_)
#define FO_FOSCRIPTVIEW_H__EA646830_62C3_4EE7_B367_D76A89EA6145__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////////////////////////////////////////////////
// Description
// Author: Author
////////////////////////////////////////////////////////////////////////////////////

#include "FODrawView.h"
#include "FOEMFShape.h"
#include "FOListCtrlShape.h"

 
//===========================================================================
// Summary:
//     The CFOScriptView class derived from CFODrawView
//      F O Script View
//===========================================================================

class FO_EXT_CLASS CFOScriptView : public CFODrawView
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Script View, Constructs a CFOScriptView object.
	//		Returns A  value (Object).
	CFOScriptView();           // protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOScriptView---F O Script View, Specifies a E-XD++ CFOScriptView object (Value).
	DECLARE_DYNCREATE(CFOScriptView)

// Attributes
	// Attributes

// Operations
public:

	// Do model change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Model, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void	DoChangeModel(
		// Pointer of model.
		CFODataModel *pModel);

public:
	
 
	// Current Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *pCurShape;
	// Operations

	// Do generate the init additional items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Initial Items, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoGenInitItems(CFODrawShape *pShape);
	
	// Do something when click on the items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do When Click Additional, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWhenClickAddi();

	// object of class
 
	// Group List, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet	m_GroupList;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Cache, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strKey1---&strKey1, Specifies A CString type value.
	BOOL AddToCache(const CString &strKey1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape Count, Returns the specified value.
	//		Returns a int type value.
	int GetCacheShapeCount() { return m_GroupList.GetCount(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape At2, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey1---&strKey1, Specifies A CString type value.
	CFODrawShape *GetCacheShapeAt2(const CString &strKey1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cache Shape At, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	CFODrawShape *GetCacheShapeAt(const int &nIndex);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache Shapes, Remove the specify data from the list.

	void ClearCacheShapes();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Free, Do a event. 

	void DoBendFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Bend Free, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowBendFree();
	
	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select New Shape, Call this function to select the given item.
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	void SelectNewShape(CFODrawShape *pShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Key Dialog, Do a event. 

	void DoShowKeyDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gauge Current Value, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	double GetGaugeCurrentValue(CFODrawShape *pShape);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gauge Current Value, Sets a specify value to current class CFOScriptView
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetGaugeCurrentValue(CFODrawShape *pShape, const double &dValue);

public:
	
	// End print preview mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Print Preview, Called when a print job ends; override to deallocate GDI resources.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.  
	//		pt---Specifies a POINT pt object(Value).  
	//		pView---pView, A pointer to the CPreviewView or NULL if the call failed.
	void OnEndPrintPreview(CDC* pDC, CPrintInfo* pInfo,POINT pt, CPreviewView* pView);
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CElectricDemoView)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitialUpdate(); // called first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//E-XD++ Library add lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Undo, .

	void Undo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Redo, .

	void Redo();

	// Current link type.
 
	// Link Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nLinkType;
	
	// Current arrow type.
 
	// Arrow Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nArrowType;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .

	void Cut();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.

	void Copy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .

	void Paste();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	void Clear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Select All, Do a event. 

	void DoSelectAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Grid Property, This member function is called by the framework to allow your application to handle a Windows message.

	void OnGridProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Design Mode, Sets a specify value to current class CFOScriptView
	// Parameters:
	//		bMode---bMode, Specifies A Boolean value.
	void SetDesignMode(const BOOL& bMode);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Page Break Line, Call this function to show the specify object.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void ShowPageBreakLine(const BOOL& bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Port, Call this function to show the specify object.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void ShowPort(const BOOL& bShow);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Run Time Input Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetRunTimeInputText();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Zoom Within Rectangle, Do a event. 

	void DoZoomWithinRect();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Page Dialog, Do a event. 

	void DoShowPageDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Header And Footer Dialog, Do a event. 

	void DoShowHeaderAndFooterDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Text Dialog, Do a event. 

	void DoShowTextDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Protect Dialog, Do a event. 

	void DoShowProtectDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Bullets Dialog, Do a event. 

	void DoShowBulletsDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Line Dialog, Do a event. 

	void DoShowLineDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Fill Dialog, Do a event. 

	void DoShowFillDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Shadow Dialog, Do a event. 

	void DoShowShadowDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Event Dialog, Do a event. 

	void DoShowEventDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Custom Dialog, Do a event. 

	void DoShowCustomDlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Position And Size Dialog, Do a event. 

	void DoShowPosAndSizeDlg();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Select, Do a event. 

	void DoDrawSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Multiple Select, Do a event. 

	void DoDrawMultiSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 

	void DoDrawLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc, Do a event. 

	void DoDrawArc();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Pie, Do a event. 

	void DoDrawPie();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Line, Do a event. 

	void DoDrawArrowLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Cross Line, Do a event. 

	void DoDrawCrossLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arrow Bezier Line, Do a event. 

	void DoDrawArrowBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Dimension Line, Do a event. 

	void DoDrawDimLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Free Line, Do a event. 

	void DoDrawFreeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Free Close Line, Do a event. 

	void DoDrawFreeCloseLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon Line, Do a event. 

	void DoDrawPolyLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Polygon, Do a event. 

	void DoDrawPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse, Do a event. 

	void DoDrawEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse2, Do a event. 

	void DoDrawEllipse2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Rectangle, Do a event. 

	void DoDrawRectangle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Rectangle, Do a event. 

	void DoDrawRoundRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Close Bezier, Do a event. 

	void DoDrawCloseBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Line, Do a event. 

	void DoDrawBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Static, Do a event. 

	void DoDrawStatic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Button, Do a event. 

	void DoDrawButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Do Draw Image, Do a event. 

	void DoDoDrawImage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Port, Do a event. 

	void DoDrawPort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Table, Do a event. 

	void DoDrawTable();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Arc Line2, Do a event. 

	void DoDrawArcLine2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ellipse Chord, Do a event. 

	void DoDrawEllipseChord();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Captionline, Do a event. 

	void DoDrawCaptionline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Rectangle Callout, Do a event. 

	void DoDrawRectCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Round Callout, Do a event. 

	void DoDrawRoundCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Cloud Callout, Do a event. 

	void DoDrawCloudCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Horizontal Dimline, Do a event. 

	void DoDrawHorzDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Vertical Dimline, Do a event. 

	void DoDrawVertDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Radius Dimline, Do a event. 

	void DoDrawRadiusDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Extend Line, Do a event. 

	void DoDrawExtLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw New Bezier Line, Do a event. 

	void DoDrawNewBezierLine();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Select Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMultiSelectMode();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Custom Rectangle, Draws current object to the specify device.
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void DrawCustomRect(int nType);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Link Normal, Do a event. 

	void DoDrawLinkNormal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Link Up Right, Do a event. 

	void DoDrawLinkUpRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Corner Link, Do a event. 

	void DoDrawCornerLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bezier Link, Do a event. 

	void DoDrawBezierLink();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate, Do a event. 

	void DoRotate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Left, Do a event. 

	void DoRotateLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Right, Do a event. 

	void DoRotateRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flip Horizontal, Do a event. 

	void DoFlipHorz();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flip Vertical, Do a event. 

	void DoFlipVert();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Angle, .
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.
	void RotateAngle(int nAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Shape Count, Returns the specified value.
	//		Returns a int type value.
	int GetRotateShapeCount();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mirror Free, Do a event. 

	void DoMirrorFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove Help Line, Do a event. 

	void DoRemoveHlpLine();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Metafile, .
	//		Returns A HENHMETAFILE value (Object).  
	// Parameters:
	//		lpszDescription---lpszDescription, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	HENHMETAFILE GenMetafile(LPCTSTR lpszDescription);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Metafile, Call this function to read a specified number of bytes from the archive.
	//		Returns a pointer to the object CFOEMFShape,or NULL if the call failed  
	// Parameters:
	//		hEmf---hEmf, Specifies a HENHMETAFILE hEmf object(Value).  
	//		&xStart---&xStart, Specifies A integer value.  
	//		&yStart---&yStart, Specifies A integer value.
	CFOEMFShape* LoadMetafile(HENHMETAFILE hEmf, const int &xStart, const int &yStart);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Group, .

	void Group();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Un Group, .

	void UnGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Un Group, Call this member function to enable or disable the specify object for this command.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL EnableUnGroup();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Left, Do a event. 

	void DoAlignLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Right, Do a event. 

	void DoAlignRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Top, Do a event. 

	void DoAlignTop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Bottom, Do a event. 

	void DoAlignBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Center, Do a event. 

	void DoAlignCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Vcenter, Do a event. 

	void DoAlignVcenter();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Inview Hor, Do a event. 

	void DoAlignInviewHor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Inview Ver, Do a event. 

	void DoAlignInviewVer();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Across, Do a event. 

	void DoSpaceAcross();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Down, Do a event. 

	void DoSpaceDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Width, Do a event. 

	void DoSizeWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Height, Do a event. 

	void DoSizeHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size All, Do a event. 

	void DoSizeAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Lockcomp, Do a event. 

	void DoLockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Unlockcomp, Do a event. 

	void DoUnlockcomp();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Front, Do a event. 

	void DoMoveFront();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Forward, Do a event. 

	void DoMoveForward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Back, Do a event. 

	void DoMoveBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Backward, Do a event. 

	void DoMoveBackward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Reverse Order, Do a event. 

	void DoReverseOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Infront Shape, Do a event. 

	void DoInfrontShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Behind Shape, Do a event. 

	void DoBehindShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgeleft, Do a event. 

	void DoCmdNudgeleft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgeright, Do a event. 

	void DoCmdNudgeright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgetop, Do a event. 

	void DoCmdNudgetop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Nudgebottom, Do a event. 

	void DoCmdNudgebottom();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cmd Automatic Pan, Do a event. 

	void DoCmdAutoPan();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select, Returns the specified value.
	//		Returns a int type value.
	int	GetTotalSelect();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Edit Spot, Do a event. 

	void DoEditSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Selection, Call this member function to update the object.

	void UpdateSelection();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Shapes, Call this member function to update the object.

	void UpdateAllShapes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Canvas, Call this member function to update the object.

	void UpdateCanvas();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Tab Order, Do a event. 

	void DoTabOrder();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print Preview, Do a event. 

	void DoPrintPreview();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Command State, Returns the specified value.
	//		Returns a int type value.
	int GetCommandState();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	long GetBackShapeAt(long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Rich Text Shape Edit, .
	// Parameters:
	//		*pRich---*pRich, A pointer to the CFOPRichEditShape  or NULL if the call failed.
	void StartRichTextShapeEdit(CFOPRichEditShape *pRich);

	// Override this method to handle the selection change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Selection Changed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSelectionChanged();

	// End text edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Finish, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnTextEditFinish(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// End edit box edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Box, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnFinishEditBox(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// End combo box edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Combo Box, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnFinishComboBox(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// Init link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Link Shape, Call InitLinkShape after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitLinkShape();

	// Create group shape,override this method to do something before drop toolbox shape to the canvas.
	// pShape -- pointer of the composite shape.
	// nType -- type of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Composite Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		nType---nType, Specifies A integer value.
	virtual void DoInitCompositeShape(CFOCompositeShape *pShape,int nType);

	// Do something before any shape is dragged to the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Before Drag, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL OnBeforeDrag(CFODrawShape *pShape);

	// Do something after text enter finished.
	// pShape -- pointer of shape.
	// strText -- text for entering.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Text Enter, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strText---&strText, Specifies A CString type value.
	virtual void DoAfterTextEnter(CFODrawShape *pShape, CString &strText);

	// Do something before any shape is dropped on the canvas.
	// Do shape drop,override this method to handle shape drop action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Drop, Do something before any shape is dropped on the canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.
	virtual void	DoShapeDrop(
		// List of shapes.
		const CFODrawShapeList& listShapes,
		// Toolbox Item drop value.
		COleDataObject* pDataObject
		);

	// Do click event from button, check button, check box, etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Button Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nSel---&nSel, Specifies A integer value.
	virtual void DoButtonClickEvent(CFODrawShape *pShape,const int &nSel);

	// Do somthing before link is created, call GetParentComp of CFOPortShape class to obtain the parent shape of port.
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Link Created, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL DoBeforeLinkCreated(CFOPortShape *pFrom,CFOPortShape *pTo);

	// Do somthing before edit text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Editing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL DoBeforeEditing(CFODrawShape *pShape);

	// Move and size action.
	// Move a list of shapes.
	// pShapeList -- the list of shapes.
	// nOffsetX -- x offset size.
	// nOffsetY -- y offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveCompsAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.
	virtual CFOMoveCompsAction*	DoMoveAction(CFODrawShapeList* pShapeList, int nOffsetX, int nOffsetY);

	// Do Group a list of shape ation.
	// pShapeList -- the list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Group Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOGroupAction*		DoGroupAction(CFODrawShapeList* pShapeList);

	// Do Ungroup multi shapes action.
	// pShapeList -- the pointer of group shape list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Multiple Un Group Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiUnGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOMultiUnGroupAction*	DoMultiUnGroupAction(CFODrawShapeList* pShapeList);

	// Do Size Spot Action
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizeSpotAction,or NULL if the call failed  
	// Parameters:
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOSizeSpotAction*		DoSizeSpotAction(int nSpotIndex,CPoint ptNew);

	// Do Size port Action
	// pPortHit -- pointer of the port that hitted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Port Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizePortAction,or NULL if the call failed  
	// Parameters:
	//		*pPortHit---Port Hit, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFOSizePortAction*		DoSizePortAction(CFOPortShape *pPortHit);

	// Do Size Spot Action
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Center Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizeCenterSpotAction,or NULL if the call failed  
	// Parameters:
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOSizeCenterSpotAction*		DoSizeCenterSpotAction(int nSpotIndex,CPoint ptNew);

	// Do Size anchor point Action
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveAnchorAction*	DoSizeAnchorAction(CPoint ptNew);

	// Do Size extend anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Extend Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveExtAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveExtAnchorAction*	DoSizeExtAnchorAction(CPoint ptNew);

	// Do Size third anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Third Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveThirdAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveThirdAnchorAction*	DoSizeThirdAnchorAction(CPoint ptNew);

	// Do Size third anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Four Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveFourAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveFourAnchorAction*	DoSizeFourAnchorAction(CPoint ptNew);

	// Do Size third anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Five Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveFiveAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveFiveAnchorAction*	DoSizeFiveAnchorAction(CPoint ptNew);

	// Do Add new Spot to a specify shape Action
	// pShape -- A specify shape that can be added spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOAddSpotAction,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOAddSpotAction*		DoAddSpotAction(CFODrawShape *pShape,int nSpotIndex,CPoint ptNew);

	// Do Remove a Spot from a specify shape Action
	// pShape -- A specify shape that can be removed spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORemoveSpotAction,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nSpotIndex---Spot Index, Specifies A integer value.
	virtual CFORemoveSpotAction*	DoRemoveSpotAction(CFODrawShape *pShape,int nSpotIndex);

	// Do Remove a list of Shapes.
	// pShapeList -- the list of shapes for removing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Delete Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORemoveCompsAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFORemoveCompsAction*	DoDeleteAction(CFODrawShapeList* pShapeList);

	// Do Resize a specify shape Action,resize shapes with the total selection rectangle's CONTROL_HANDLE.
	// the list of shapes.
	// dX -- x scale.
	// dY -- y scale.
	// nPoint -- the control handle,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resize Shapes Action Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFONewScaleAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nPoint---nPoint, Specifies A integer value.
	virtual CFONewScaleAction*	DoResizeShapesActionEx(CFODrawShapeList* pShapeList,double dX,double dY,FO_CONTROL_HANDLE nPoint);

	// Do Rotate a specify shapes Action,rotate the shapes by arounding each shape's center.
	// pShapeList -- the list of shapes.
	// nAngle -- the angle to rotate(from 0 to 360)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORotateAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFORotateAction*	DoRotateShapesAction(CFODrawShapeList* pShapeList,int nAngle);

	// Do Resize a specify shapes Action,rotate the shapes by arounding the total selection rectangle's center.
	// pShapeList -- the list of shapes.
	// nAngle -- rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Shapes Action Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFONewRotateAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFONewRotateAction*	DoRotateShapesActionEx(CFODrawShapeList* pShapeList,int nAngle);

	// Add link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape, Adds an object to the specify list.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOListPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOListPortShape  or NULL if the call failed.
	CFOLinkShape *AddLinkShape(CFOListPortShape *pFrom,CFOListPortShape *pTo);

	// Add link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape No Undo, Adds an object to the specify list.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed  
	// Parameters:
	//		*pFirst---*pFirst, A pointer to the CFODrawPortsShape  or NULL if the call failed.  
	//		*pSecond---*pSecond, A pointer to the CFODrawPortsShape  or NULL if the call failed.  
	//		&nLinkType---Link Type, Specifies A integer value.  
	//		&nArrowType---Arrow Type, Specifies A integer value.
	CFOLinkShape *AddLinkShapeNoUndo(CFODrawPortsShape *pFirst,CFODrawPortsShape *pSecond, const int &nLinkType, const int &nArrowType);

	// Do start image node.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image Node, Do a event. 
	// Parameters:
	//		m_pIPictureDisp---I Picture Disp, A pointer to the IPictureDisp or NULL if the call failed.
	void DoDrawImageNode(IPictureDisp* m_pIPictureDisp);

public:
//	BOOL IsRulerVisible();
//	void ShowRulers(BOOL bVisible);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Unit, Sets a specify value to current class CFOScriptView
	// Parameters:
	//		nUnit---nUnit, Specifies a short nUnit object(Value).
	void SetRulerUnit(short nUnit);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Put Shape To Back, Do a event. 

	void DoPutShapeToBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fo Polygon Insertpoint, Do a event. 

	void DoFoPolyInsertpoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Insert Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowInsertPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fo Polygon Deletepoint, Do a event. 

	void DoFoPolyDeletepoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Delete Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowDeletePoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment Toline, Do a event. 

	void DoConvertSegmentToline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert Segment To Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowConvertSegmentToLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Segment To Curve, Do a event. 

	void DoConvertSegmentToCurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert Segment To Curve, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowConvertSegmentToCurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rip Up Point, Do a event. 

	void DoRipUpPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Rip Up Point, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowRipUpPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Turn Corner Link Line, Do a event. 

	void DoDrawTurnCornerLinkLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Break Center Link Line, Do a event. 

	void DoDrawBreakCenterLinkLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Ellipse Select, Do a event. 

	void DoEllipseSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path, Do a event. 

	void DoConvertToPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert To Path, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowConvertToPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Polygon, Do a event. 

	void DoConvertToPoly();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Convert To Polygon, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowConvertToPoly();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Combine, Do a event. 

	void DoShapesCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Combine, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShapeCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Dismantle, Do a event. 

	void DoShapesDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Dismantle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShapeDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Merge, Do a event. 

	void DoShapesMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Merge, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShapeMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Substract, Do a event. 

	void DoShapesMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Substract, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShapeMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shapes Merge Intersect, Do a event. 

	void DoShapesMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shape Merge Intersect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShapeMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Connect Lines, Do a event. 

	void DoConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Connect Lines, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Break Shape To Lines, Do a event. 

	void DoBreakShapeToLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Break Shape To Lines, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowBreakShapeToLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Close Shape, Do a event. 

	void DoCloseShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Close Shape, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowCloseShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shear Free, Do a event. 

	void DoShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Shear Free, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ellipse Select Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEllipseSelectMode();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		*pMainShape---Main Shape, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	CFOPortShape *GetCenterPort(CFODrawPortsShape *pMainShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Select Shapes, .

	void ConnectSelectShapes();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Create Link, Do a event. 

	void DoGenCreateLink();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Current Shape To Selection, Adds an object to the specify list.
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	void AddCurShapeToSelection(CFODrawShape *pShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Current Shape To Selection, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	void RemoveCurShapeToSelection(CFODrawShape *pShape);

	// Connect the select shapes with center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Two Shapes, .
	//		Returns a pointer to the object CFOLinkShape,or NULL if the call failed  
	// Parameters:
	//		*pFirst---*pFirst, A pointer to the CFODrawPortsShape  or NULL if the call failed.  
	//		*pSecond---*pSecond, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	CFOLinkShape* ConnectTwoShapes(CFODrawPortsShape *pFirst,CFODrawPortsShape *pSecond);

	// Connect the select shapes with center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect With Two Ports, .
	//		Returns a pointer to the object CFOLinkShape,or NULL if the call failed  
	// Parameters:
	//		*pFirst---*pFirst, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pSecond---*pSecond, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		nLinkType---Link Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nArrowType---Arrow Type, Specifies A integer value.
	CFOLinkShape* ConnectWithTwoPorts(CFOPortShape *pFirst,CFOPortShape *pSecond, UINT nLinkType, int nArrowType);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selection, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A 32-bit long signed integer.
	long GetSelection(long index);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Composite Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		index---Specifies A 32-bit long signed integer.
	long GetCompositeShapeAt(CFOCompositeShape *pComp,long index);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Shape Port Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFODrawPortsShape  or NULL if the call failed.  
	//		index---Specifies A 32-bit long signed integer.
	long GetPortsShapePortShapeAt(CFODrawPortsShape *pComp,long index);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Link Shape At, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		index---Specifies A 32-bit long signed integer.
	long GetPortLinkShapeAt(CFOPortShape *pPort,long index);

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As Bitmap, .
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.
	void ExportAsBitmap(const CString &strFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As E M F, .
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.
	void ExportAsEMF(const CString &strFile);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Panwnd, Do a event. 

	void DoShowPanwnd();

	// Set primary selection color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Set Primary Selection Color, Do a event. 
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DoSetPrimarySelectionColor(
		// Primary selection color.
		COLORREF color
		);

	// Sets the color for unprimary selection
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Set Secondary Selection Color, Do a event. 
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DoSetSecondarySelectionColor(
		// Secondary selection color.
		COLORREF color
		);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Undo, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanUndo();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Redo, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanRedo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Paste, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanPaste();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	void PrepareDC(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Printing, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	BOOL PreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	void DoPrint(CDC* pDC, CPrintInfo* pInfo);

	// Change bool value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Bool Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeBoolProp(CFODrawShape *pShape,
		const BOOL &bValue,const int &nPropId);

	// Change CString value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape String Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeStringProp(CFODrawShape *pShape,
		const CString &strValue,const int &nPropId);

	// Change int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Int Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeIntProp(CFODrawShape *pShape,
		const int &nValue,const int &nPropId);

	// Change UINT value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape U I N T Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeUINTProp(CFODrawShape *pShape,
		const UINT &nValue,const int &nPropId);

	// Change float value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Float Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeFloatProp(CFODrawShape *pShape,
		const float &fValue,const int &nPropId);

	// Change Double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Double Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeDoubleProp(CFODrawShape *pShape,
		const double &dValue,const int &nPropId);

	// Change Date Time value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Date Time Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeDateTimeProp(CFODrawShape *pShape,
		const COleDateTime &dtValue,const int &nPropId);

	// Change COLOR value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape Color Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeColorProp(CFODrawShape *pShape,
		const COLORREF &crValue,const int &nPropId);

	// Change DWORD value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Single Shape D Word Property, .
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSingleShapeDWordProp(CFODrawShape *pShape,
		const DWORD &dwValue,const int &nPropId);

	// Change bool value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Bool Property, .
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionBoolProp(const BOOL &bValue,const int &nPropId);

	// Change CString value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection String Property, .
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionStringProp(const CString &strValue,const int &nPropId);

	// Change int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Int Property, .
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionIntProp(const int &nValue,const int &nPropId);

	// Change UINT value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection U I N T Property, .
	// Parameters:
	//		&nValue---&nValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionUINTProp(const UINT &nValue,const int &nPropId);

	// Change float value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Float Property, .
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionFloatProp(const float &fValue,const int &nPropId);

	// Change Double value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Double Property, .
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionDoubleProp(const double &dValue,const int &nPropId);

	// Change Date Time value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Date Time Property, .
	// Parameters:
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionDateTimeProp(const COleDateTime &dtValue,const int &nPropId);

	// Change COLOR value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection Color Property, .
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionColorProp(const COLORREF &crValue,const int &nPropId);

	// Change DWORD value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Selection D Word Property, .
	// Parameters:
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		&nPropId---Property Id, Specifies A integer value.
	void ChangeSelectionDWordProp(const DWORD &dwValue,const int &nPropId);


	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Page Setup, Do a event. 

	void DoPageSetup();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Edit Spots, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEditSpots();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Components Select Dialog, Do a event. 

	void DoShowCompsSelectDlg();

	// Handle event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Tip Relay Event, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	BOOL		TipRelayEvent(MSG* pMsg);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Group Shapes, Returns the specified value.
	//		Returns a int type value.
	int GetTotalGroupShapes();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Tab Order, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTabOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Type, Returns the specified value.
	//		Returns a int type value.
	int GetDrawType();

	// When you double click on the composite shape,it will addd a label on the composite shape.
	// With this method,you can do something before showing this label.
	// pLabel -- pointer of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Show Label, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLabel---*pLabel, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoInitShowLabel(CFODrawShape *pLabel);

	// Start link shape, override this method to do something before creating link
	// pPort -- starting link port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Link Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL DoStartLinkEvent(CFOPortShape *pPort);

	// Draw link line.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Link Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoLinkShape(UINT nFlags, CPoint point);

// Implementation
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Script View, Destructor of class CFOScriptView
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOScriptView();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOScriptView)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On File Print Preview, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFilePrintPreview();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

#endif // !defined(FO_FOSCRIPTVIEW_H__EA646830_62C3_4EE7_B367_D76A89EA6145__INCLUDED_)
