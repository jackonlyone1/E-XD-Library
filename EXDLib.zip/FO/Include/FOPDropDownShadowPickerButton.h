//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNSHADOWPICKERBUTTON_H__487991EF_D01F_4E69_B544_D27E41F000A0__INCLUDED_)
#define AFX_FOPDROPDOWNSHADOWPICKERBUTTON_H__487991EF_D01F_4E69_B544_D27E41F000A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownShadowPickerButton.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// FOPDropDownShadowPickerButton window
#include "FOPShadowPickerDrawPanel.h"
#include "FOPDropDownButtonBase.h"
#include "FOPPickerBaseWnd.h"

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownShadowPickerButton window
void FO_API_DECL AFXAPI DDX_ShadowPickerDropDown(CDataExchange *pDX, int nIDC, int& nShadowPicker);

 
//===========================================================================
// Summary:
//     The FOPDropDownShadowPickerButton class derived from FOPDropDownButtonBase
//      O P Drop Down Shadow Picker Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownShadowPickerButton : public FOPDropDownButtonBase, FOPDropShadowPickerCallback
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownShadowPickerButton---O P Drop Down Shadow Picker Button, Specifies a FOPDropDownShadowPickerButton object(Value).
	DECLARE_DYNCREATE(FOPDropDownShadowPickerButton);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Shadow Picker Button, Constructs a FOPDropDownShadowPickerButton object.
	//		Returns A  value (Object).
	FOPDropDownShadowPickerButton();

// Attributes
public:
	// Drop wnd
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Auto ptr draw impl
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPDropShadowPickerDrawPanel.  
	FOPDropShadowPickerDrawPanel* pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPDropShadowPickerDrawPanel.  
	FOPDropShadowPickerDrawPanel*	pDrawImpl;

	// Shadow Picker value
 
	// Shadow Picker Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							nShadowPickerType;
// Operations
public:

	// Share draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownShadowPickerButton& button object(Value).
	void						ShareDrawImpl(FOPDropDownShadowPickerButton& button);

	// Get Shadow Picker
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Picker, Returns the specified value.
	//		Returns a int type value.
	int		 					GetShadowPicker()	const	{	return(nShadowPickerType);	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPDropShadowPickerDrawPanel& value (Object).
	const FOPDropShadowPickerDrawPanel&	GetDrawImpl() const	{	return *pDrawImpl;	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPDropShadowPickerDrawPanel& value (Object).
	FOPDropShadowPickerDrawPanel&	GetDrawImpl()			{	return *pDrawImpl;	}

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int					GetMinimumHeight() const;

	// Set Shadow Picker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Picker, Sets a specify value to current class FOPDropDownShadowPickerButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void						SetShadowPicker(int nWidth);

	// Do drop down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		bDraw---bDraw, Specifies A Boolean value.
	// Draw state
	void						Draw(CDC& dc, const CRect& rc, BOOL bDraw);

	// Do when Shadow Picker change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Shadow Picker Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellShadowPickerChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom Shadow Picker button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Shadow Picker, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomShadowPicker();

	// Do when choose none Shadow Picker action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Shadow Picker None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellShadowPickerNone();

	// Set transparentcy
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPDropDownShadowPickerButton
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void						SetTransparency(BOOL  bTransparent);

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 						IsTransparent()	const	{	return m_bTransparent;		}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownShadowPickerButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Shadow Picker Button, Destructor of class FOPDropDownShadowPickerButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownShadowPickerButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownShadowPickerButton)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Transparent
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 						m_bTransparent;
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNSHADOWPICKERBUTTON_H__487991EF_D01F_4E69_B544_D27E41F000A0__INCLUDED_)
