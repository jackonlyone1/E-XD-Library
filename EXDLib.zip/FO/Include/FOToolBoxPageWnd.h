//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTOOLBOXPAGEWND_H__7A03F39B_E0B2_11D5_A4B1_525400EA266C__INCLUDED_)
#define AFX_FOTOOLBOXPAGEWND_H__7A03F39B_E0B2_11D5_A4B1_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOToolBoxPageWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOToolBoxPageWnd window
#include "FOPMenuWndImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CFOToolBoxPageWnd window
#include "FOToolBoxItem.h"
#include "FOToolTipsWnd.h"
#include "FODropTarget.h"

#define FO_TIMER_EVENT 1214
#define TOOLPAGEWND_CLASSNAME	_T("ToolBoxPageWnd")
typedef HANDLE HSHBGROUP;

#include "FODropSource.h"
#include "FOToolBoxPage.h"
#include "FOPreviewBitmap.h"
#include "FOLabelEdit.h"

////////////////////////////////////////////////////////////
// CFOToolBoxPageWnd -- toolbox window

 
//===========================================================================
// Summary:
//     The CFOToolBoxPageWnd class derived from CWnd
//      F O Tool Box Page Window
//===========================================================================

class FO_EXT_CLASS CFOToolBoxPageWnd : public CWnd
{
// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOToolBoxPageWnd---F O Tool Box Page Window, Specifies a E-XD++ CFOToolBoxPageWnd object (Value).
	DECLARE_DYNAMIC(CFOToolBoxPageWnd)
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Page Window, Constructs a CFOToolBoxPageWnd object.
	//		Returns A  value (Object).
	CFOToolBoxPageWnd();

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Box Page Window, Destructor of class CFOToolBoxPageWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolBoxPageWnd();

// Attributes
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, const RECT& rect,
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyleEx---Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, DWORD dwStyleEx, const RECT& rect, 
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
		DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	// Create extend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		hWndParent---Window Parent, Specifies a HWND hWndParent object(Value).  
	//		nIDorHMenu---I Dor H Menu, Specifies a HMENU nIDorHMenu object(Value).  
	//		lpParam---lpParam, Specifies a LPVOID lpParam = NULL object(Value).
	virtual BOOL CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
		                   int x, int y, int cx, int cy, HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

	// Creation new window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Page , Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL AttachPageCtrl( UINT uID, CWnd* pParentWnd );

	// Pre translate message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Get scroll bar control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar , Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.
	virtual CScrollBar* GetScrollBarCtrl(int nBar) const;

	// Is mouse on button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse On Button, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMouseOnButton();

	// Hit test on arrow
	BOOL HitTestOnArrow(CFOToolBoxItem *pItem, const CPoint& ptHit);

protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);

	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
public:
// Attributes

	// Set current page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Page, Sets a specify value to current class CFOToolBoxPageWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPage---*pPage, A pointer to the CFOToolBoxPage  or NULL if the call failed.
	virtual void SetCurrentPage(CFOToolBoxPage *pPage);

	// Get current page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Page, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage ,or NULL if the call failed
	virtual CFOToolBoxPage *GetCurrentPage();

	// Get view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Style, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetViewStyle() const { return m_nViewStyle; }

	// Set view style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Style, Sets a specify value to current class CFOToolBoxPageWnd
	// Parameters:
	//		&nStyle---&nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetViewStyle(const UINT &nStyle);

public:

	// first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Data, Call InitData after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResFile---Resource File, Specifies A CString type value.
	virtual void InitData(CString strResFile = _T(""));

	// add a new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	virtual CFOToolBoxItem * AddNewItem();

	// add a new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	virtual CFOToolBoxItem * AddNewItem2(long posInsert);

	// Add a new item.
	// nIconID -- Resource Icon ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		nIconID---Icon I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CFOToolBoxItem * AddNewItem(UINT nIconID);

	// add a new item.
	// strIconFile -- a specify icon file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		strIconFile---Icon File, Specifies A CString type value.
	virtual CFOToolBoxItem * AddNewItem(CString strIconFile);

	// add a new items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual CFOToolBoxItem *AddNewItem(CFOToolBoxItem *pItem);

	// Remove an item.
	// pItem -- a pointer to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOToolBoxItem  or NULL if the call failed.
	virtual void RemoveItem(CFOToolBoxItem *pItem);

	// Remove an item.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	virtual void RemoveItem(int nType);

	// Find an item with type.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	CFOToolBoxItem *FindItem(int nType);

	// get item count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Count, Returns the specified value.
	//		Returns a int type value.
	int GetItemCount();

	// clear all items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearAll();

	// set item size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOToolBoxPageWnd
	// Parameters:
	//		nx---Specifies A integer value.  
	//		ny---Specifies A integer value.
	void SetItemSize(int nx,int ny);
	
	// update control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void UpdateControl(BOOL bMoveScroll = FALSE);
	
	// load res file or save
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Resource File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL LoadResFile(CString strFile);

	// Save resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL SaveFile();

	// Save resource file to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Resource File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL SaveResFile(CString strFile);

	// Show save file dialog and save resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Resource File, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoSaveResFile();

	// Re update all item's image.
	void UpdateAllImages();

public:

	// Obtain the item's size 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize		GetItemSize() const						{ return CSize(nItemCX,nItemCY); }

	// Change the item's size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOToolBoxPageWnd
	// Parameters:
	//		szItem---szItem, Specifies A CSize type value.
	void		SetItemSize(CSize szItem)				{ nItemCX = szItem.cx,nItemCY = szItem.cy; }

	// Obtain the item's space
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Space, Returns the specified value.
	//		Returns a int type value.
	int			GetItemSpace() const					{ return nItemSpace; }

	// Change the item's space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Space, Sets a specify value to current class CFOToolBoxPageWnd
	// Parameters:
	//		&nSpace---&nSpace, Specifies A integer value.
	void		SetItemSpace(const int &nSpace)			{ nItemSpace = nSpace; }

	// Is double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Edit Property, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableEditProp() const				{ return m_bEnableEditProp; }

	// Set double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Edit Property, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnableEditProp(const BOOL &bEnable)		{ m_bEnableEditProp = bEnable; }

	// Is paste enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Paste Enable, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPasteEnable() const					{ return m_bPasteItemByUser; }

	// Enable paste item by user.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Paste By User, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void		EnablePasteByUser(const BOOL &bEnable)	{ m_bPasteItemByUser = bEnable; }

	// --- In  : hGroup     -- handle to the group that is being dragged
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drag Group, Sets a specify value to current class CFOToolBoxPageWnd
	//		Returns A HSHBGROUP value (Object).  
	// Parameters:
	//		hGroup---hGroup, Specifies a HSHBGROUP hGroup object(Value).
	HSHBGROUP SetDragGroup(HSHBGROUP hGroup);
	
	
	// --- In  : 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drag Group, Returns the specified value.
	//		Returns A inline HSHBGROUP value (Object).
	inline HSHBGROUP GetDragGroup() const { return m_hDragGroup; }

	// Do drawing track linge
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Track, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void DoDrawTrack(CDC *pDC, const CRect &rcPos);

public:

	// Obtain active canvas.
	virtual CWnd *GetActiveWnd();

	// get start position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Position, Returns the specified value.
	// Parameters:
	//		&nStart---&nStart, Specifies A integer value.
	void			GetStartPos(int &nStart);

	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOToolBoxItem *HitTest(CPoint pt);

	// Hit test label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Label, Hit test on this object.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	CFOToolBoxItem *HitTestLabel(const CPoint &ptHit);

	// Gen the tool tip.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Tool Tip, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&info---Specifies a FOP_TIP_INFO &info object(Value).
	virtual BOOL GenToolTip(const CPoint &ptHit,FOP_TIP_INFO &info);

	// Select and item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Item, Call this function to select the given item.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOToolBoxItem *SelectedItem(CPoint pt);


	// Select and item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Item, Call this function to select the given item.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	void DoFocusItem(CFOToolBoxItem *pSel);

	// Get selected item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	//		Returns a pointer to the object CFOToolBoxItem ,or NULL if the call failed
	CFOToolBoxItem *GetSelected();

	CFOToolBoxItem *GetTracked();
	
	// update scroll bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void	UpdateScrollBar(BOOL bMoveScroll = FALSE);

	// get size of font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetFontSize();

	// draw items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Items, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void	DrawItems(CDC *pDC,const CRect &rcView);

	// calculate item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Item Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcItemPosition();

	// Is focused.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Focused, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsFocused() const { return m_bFocused; }

	// Change specify parent wnd pointer.
	void SetSpeParentWnd(CWnd *pWnd) { m_pSpeParentWnd = pWnd; }

protected:

	// Convert from doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		rect---Specifies A CRect type value.
	void DocToClient(CRect& rect);

	// Convert from doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		point---Specifies A CPoint type value.
	void DocToClient(CPoint& point);

	// Convert from client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void ClientToDoc(CPoint& point);

	// Convert from client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void ClientToDoc(CRect& rect);

public:
	// Invalidate rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rc---Specifies A CRect type value.
	void InvalRect(CRect rc);

	// Do split composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Split Composite Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void DoSplitCompositeShape(CFODrawShapeList *pList,CFODrawShapeList *pPortsList,CFOCompositeShape *pShape);

public:

	// Create sub toolbox context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Child Context Menu, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu ,or NULL if the call failed
	virtual CMenu * CreateSubContextMenu();

	// Get the drag and drop clipboard format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drag Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	static CLIPFORMAT GetDragClipFormat();
	
	// custom clipboard format
 
	// Drag Draw, This member specify CLIPFORMAT object.  
	static CLIPFORMAT m_cfDragDraw;

	// Save data to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Data To Clipboard, Call this function to save the specify data to a file.
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.
	void SaveDataToClipboard(CFOToolBoxItem* pItem);

	// Create memory dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Temp D C, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&pMemoryDC---Memory D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	virtual BOOL CreateTempDC( CDC* pDC, CDC* &pMemoryDC, const CRect& rcPaint) const;

	// Do paint.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoPaint(CDC* pDC);

	// check flag of Ole support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ole Support, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOleSupport();

	// Do ole drag and drop.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Ole Drag And Drop, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.
	virtual void DoOleDragAndDrop(CFOToolBoxItem* pItem, CPoint pt);

	// Create drag image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drag Image, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CImageList,or NULL if the call failed  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.
	virtual CImageList* CreateDragImage(CFOToolBoxItem* pItem);

	// Create from ole data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Ole Data, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.
	static BOOL CreateFromOleData(CFOToolBoxItem* pItem,COleDataObject* pDataObject);

	// Get drop source.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Source, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODropSource,or NULL if the call failed
	virtual CFODropSource* CreateDropSource();

	// Do build tool tips.
	// Override this function to build your own tooltips text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Build Tool Tips Text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strTips---&strTips, Specifies A CString type value.
	virtual void DoBuildToolTipsText(CString &strTips);

	// Scroll to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.  
	//		bUp---bUp, Specifies A Boolean value.
	virtual void ScrollItem(CFOToolBoxItem* pItem,BOOL bUp);

	// Get inside rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Full Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	virtual void GetFullRect(LPRECT lpRect) const;

	// Scroll to new position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Position, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void ScrollPos(int nPos);

	// Close label edit box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Label Edit Box, .

	void CloseLabelEditBox();

	// Set cursor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void FOSetCursor(UINT nID);

	// Set system cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set System Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszCursor---lpszCursor, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void FOSetSystemCursor(LPCTSTR lpszCursor);

	// Clone shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone The Selection, Clone this object.
	// Parameters:
	//		*listCopy---*listCopy, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeSet &listShapes object (Value).
	void CloneTheSelection(CFODrawShapeList *listCopy, CFODrawShapeSet &listShapes);

	// Check all links.
	// list -- list of shapes.
	// bNeedProp -- need property or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Link Names, Called this function to empty a previously initialized CFOToolBoxPageWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeSet& list object(Value).  
	//		&bNeedProp---Need Property, Specifies A Boolean value.
	virtual void			ResetLinkNames(const CFODrawShapeSet& list, const BOOL &bNeedProp = TRUE);

	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Full Link, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aShapes---aShapes, Specifies a FOPContainer aShapes object(Value).  
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void			RebuildFullLink(const FOPContainer &aShapes,
		// List of shapes.
		const CFODrawShapeSet& list
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardFormat() const;

protected:
	
	// Drop moving select shape.
	// point -- point for sizing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Drop Moving, Do something before any shape is dropped on the canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void DoShapeDropMoving(CPoint point);
	
public:

	// Tooltip.
 
	// Tips, This member specify E-XD++ CFOToolTipsWnd object.  
	CFOToolTipsWnd	m_wndTips;

	// Current mouse point.
 
	// Mouse Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_MousePoint;

	// Timer start.
 
	// Mouse Timer, This member sets TRUE if it is right.  
	BOOL			m_bMouseTimer;

	// Timer id.
 
	// Timer I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_TimerID;
	// Operations
	// Is track or not.
	
	// Tracked, This member sets TRUE if it is right.  
	BOOL					m_bTracked;

protected:

	// Get scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Pos32, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		bGetTrackPos---Get Track Position, Specifies A Boolean value.
	int GetScrollPos32(int nBar, BOOL bGetTrackPos = FALSE );
	
	// Set scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Pos32, Sets a specify value to current class CFOToolBoxPageWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		nPos---nPos, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetScrollPos32( int nBar, int nPos, BOOL bRedraw = TRUE );

	// Make sure item visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ensure Visible, .
	// Parameters:
	//		pItem---pItem, A pointer to the CFOToolBoxItem or NULL if the call failed.
	void		EnsureVisible (CFOToolBoxItem* pItem);

public:

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);   
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOToolBoxPageWnd)
	public:

		// prepare device context
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:

		// update view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);

	// activate view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActivateView---Activate View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

public:
	//--------------------
	// Drag & Drop support
	//--------------------
	BOOL m_bWithItemDrop;

	//-----------------------------------------------------------------------
	// Summary:
	// On Drop, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Enter, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragEnter(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Leave, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnDragLeave();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Over, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragOver(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
public:
	
	//Define for track line pen.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Track Pen2, You construct a CFOToolBoxPageWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreateTrackPen2(CDC* pDC = NULL);
	
	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Pen2, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetTrackPen2(CDC* pDC = NULL);
	
	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Track Pen Object2, .

	void ReleaseTrackPenObject2();
	
	// Draw track line.
	// Prepare the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Track D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareTrackDC(CDC* pDC);
	
	// Clear the track dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Track D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearTrackDC(CDC* pDC);
	
// Implementation
protected:

#ifdef _DEBUG

	// performs a valid check
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// dumps the contents of your object
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions

	//{{AFX_MSG(CFOToolBoxPageWnd)
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();

	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	// when left button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	// when left button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	//when double click on left button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);

	// when WM_SIZE 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);

	// when erasing background
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	// when right button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

	// when right button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);

	// when painting
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();

	// when adding new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Add Newpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnAddNewpage();

	// when update adding new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Add Newpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateAddNewpage(CCmdUI* pCmdUI);

	// remove page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnRemovePage();

	// update removing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRemovePage(CCmdUI* pCmdUI);

	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Page Caption, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPageCaption();

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Page Caption, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdatePageCaption(CCmdUI* pCmdUI);

	// changing icon
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Changeicon, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemChangeicon();

	// update changing icon 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Changeicon, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemChangeicon(CCmdUI* pCmdUI);

	// copy item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Copy, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemCopy();

	// update copying
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Copy, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemCopy(CCmdUI* pCmdUI);

	// create empty item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Createempty, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemCreateempty();

	// update creating empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Createempty, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemCreateempty(CCmdUI* pCmdUI);

	// edot toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Edit, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemEdit();

	// update editing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Edit, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemEdit(CCmdUI* pCmdUI);

	// load file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Loadfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemLoadfile();

	// update loading
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Loadfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemLoadfile(CCmdUI* pCmdUI);

	// load file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Load Data, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemLoadData();

	// update loading
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Load Data, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemLoadData(CCmdUI* pCmdUI);

	// paste item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Paste, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemPaste();
	// update pasting
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Paste, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemPaste(CCmdUI* pCmdUI);
	//  remove item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Remove, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemRemove();
	// update removing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Remove, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemRemove(CCmdUI* pCmdUI);
	// change type
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Changetype, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemChangetype();
	// update changing type
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Changetype, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemChangetype(CCmdUI* pCmdUI);
	// create a new file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Newfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxNewfile();
	// update new file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Newfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxNewfile(CCmdUI* pCmdUI);
	// loading file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Loadfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxLoadfile();
	// update loading file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Loadfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxLoadfile(CCmdUI* pCmdUI);
	// save file 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Savefile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxSavefile();
	// update saving file
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Savefile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxSavefile(CCmdUI* pCmdUI);
	// Key down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Menu Popup, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pMenu---pMenu, A pointer to the CMenu or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysMenu---System Menu, Specifies A Boolean value.
	afx_msg void OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Capture Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	afx_msg void OnCaptureChanged(CWnd *pWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Property, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemProp(CCmdUI* pCmdUI);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnStartEditLabel(WPARAM wParam, LPARAM lParam);

	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Leave, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnMouseLeave(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCancelEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnFinishEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
	
protected:

	// Previous rectangle.
 
	// Previous, This member sets a CRect value.  
	CRect			m_rcPrevious;

	// size of section
 
	// Section, This member sets a CSize value.  
	CSize			m_sizSection;		

	// section number per row
 
	// Sections Per Row, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_uSectionsPerRow;	

	// context menu pointer
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*			m_pContextMenu;		

	// scroll width 
 
	// Scroll Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_ScrollWidth;		

	// item -cx
 
	// Item C X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nItemCX;			

	// item -cy
 
	// Item C Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nItemCY;			

	// item space
 
	// Item Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nItemSpace;			

	// current file
 
	// Current File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			strCurrentFile;		

	// Paste new item by user.
 
	// Paste Item By User, This member sets TRUE if it is right.  
	BOOL			m_bPasteItemByUser;	
	
	// notify window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			pNotifyWnd;

	// Current page.
 
	// Current Page, This member maintains a pointer to the object CFOToolBoxPage.  
	CFOToolBoxPage	*m_pCurPage;

	// View style.
 
	// View Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nViewStyle;

	// Enable or disable the double click to edit the label.
 
	// Enable Edit Property, This member sets TRUE if it is right.  
	BOOL			m_bEnableEditProp;

	// Images area
 
	// List, This member sets a CRect value.  
	CRect			m_rectList;	

	// The pointer of text edit control.
 
	// Text Edit, This member maintains a pointer to the object CFOLabelEdit.  
	CFOLabelEdit*	m_pTextEdit;

	// Save old item.
 
	// Old Item, This member maintains a pointer to the object CFOToolBoxItem.  
	CFOToolBoxItem	*m_pOldItem;

	// Drag and drop support.
 
	// Drop Target, This member specify E-XD++ CFOToolBoxDropTarget object.  
//	COleDropTarget	m_DropTarget;

	// Current cursor handle.
 
	// Cursor, This member specify HCURSOR object.  
	HCURSOR			m_hCursor;

	// Control has focus
 
	// Focused, This member sets TRUE if it is right.  
	BOOL			m_bFocused;				

	// notifies drawing routines that we are creating drag image of chosen item
 
	// Draw Drag Image, This member sets TRUE if it is right.  
	BOOL			bDrawDragImage;

	// drag item image
 
	// Drag Image, This member is a collection of same-sized images.  
	CImageList*		m_pDragImage;

	// point in drag image where the mouse cursor point to
 
	// Drag Image, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptDragImage;

	// currently being dragged group
 
	// Drag Group, This member specify HSHBGROUP object.  
	HSHBGROUP		m_hDragGroup;

	// Current action.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_action_state;

	// Draw track pen 2.
 
	// Track Pen, This member specify E-XD++ CFOPenObjData object.  
	CPen*		m_pTrackPen;

	// Current device point
 
	// Current Device, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptCurrentDevice;

	// Current log point.
 
	// Current Logical, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptCurrentLog;

	// Last moving point.
 
	// Last Move, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLastMove;

	// Tracking rectangle.
 
	// Last Tracking Rectangle, This member specify FOPRect object.  
	FOPRect			m_rcLastTrackingRect;

	CWnd *			m_pSpeParentWnd;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTOOLBOXPAGEWND_H__7A03F39B_E0B2_11D5_A4B1_525400EA266C__INCLUDED_)
