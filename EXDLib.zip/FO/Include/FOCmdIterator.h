//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOCmdIterator.h: interface for the FOCmdIterator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCMDITERATOR_H__0D05FF57_D1B7_11D6_A666_0050BAE30439__INCLUDED_)
#define AFX_FOCMDITERATOR_H__0D05FF57_D1B7_11D6_A666_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXTEMPL_H__
#include <afxtempl.h>
#endif

// Actions list iterator.
template<class TYPE, class ARG_TYPE>
 
//===========================================================================
// Summary:
//      To use a FOCmdIterator object, just call the constructor.
//      O Cmd Iterator
//===========================================================================

class FO_EXT_CLASS FOCmdIterator  
{
private:
 
	// Position, This member sets A value used to denote the position of an element in a collection; used by MFC collection classes.  
    POSITION                m_pPos;
    CList<TYPE, ARG_TYPE> *m_pList;
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// R G_ T Y P E>, .
	//		Returns A FOCmdIterator<TYPE, value (Object).
	FOCmdIterator<TYPE, ARG_TYPE>() 
	{
		m_pPos = NULL;
		m_pList = NULL;
	};

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// R G_ T Y P E>, .
	//		Returns A FOCmdIterator<TYPE, value (Object).  
	// Parameters:
	//		CList<TYPE---List< T Y P E, Specifies a CList<TYPE object(Value).  
	//		*pList---*pList, A pointer to the ARG_TYPE>  or NULL if the call failed.
	FOCmdIterator<TYPE, ARG_TYPE>(CList<TYPE, ARG_TYPE> *pList) 
	{
		m_pPos = NULL;
		Init(pList);
	};

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Cmd Iterator, Destructor of class FOCmdIterator
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOCmdIterator() 
	{
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CList<TYPE---List< T Y P E, Specifies a CList<TYPE object(Value).  
	//		*pList---*pList, A pointer to the ARG_TYPE>  or NULL if the call failed.
	virtual void Init(CList<TYPE, ARG_TYPE> *pList)
	{
		ASSERT(pList != NULL);
		if(pList == NULL)
		{
			TRACE0("pList -- Is empty!");
			return;
		}
		if (m_pList != pList) 
		{
			m_pList = pList;
			m_pPos = m_pList->GetHeadPosition();
		}
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Last, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Last()
	{
		m_pPos = m_pList->GetTailPosition();
		return (m_pPos != NULL);
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// First, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		void---void
	virtual BOOL First(void)
	{
		m_pPos = m_pList->GetHeadPosition();
		
		return (m_pPos != NULL);
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class FOCmdIterator
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	void SetPosition(POSITION &pos)
	{
		m_pPos = pos;
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOCmdIterator& value (Object).
	FOCmdIterator& operator++() 
	{
		GetNext();
		return (*this); 
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOCmdIterator& value (Object).
	FOCmdIterator& operator--()
	{
		GetPrev();
		return (*this); 
	};


	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		void---void
	POSITION GetPosition(void)
	{
		return m_pPos;
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetFirst()
	{
		First();
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
			m_pList->GetNext(m_pPos);
		}
		return pReturn;
	};

	_FOLIB_INLINE TYPE GetNext()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetNext(m_pPos);
		}
		return NULL;
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetPrev()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetPrev(m_pPos);
		}
		return NULL;
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetLast()
	{
		Last();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A TYPE value (Object).
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
			m_pList->GetPrev(m_pPos);
		}
		return pReturn;
	};
	
	virtual TYPE GetAt()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Remove()
	{
		if(m_pPos != NULL)
		{
			m_pList->RemoveAt(m_pPos);
		}
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A TYPE& value (Object).
	TYPE& operator*()
	{
		return GetAt();
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y P E, .
	//		Returns A operator value (Object).
	operator TYPE ()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};
};

#endif // !defined(AFX_FOCMDITERATOR_H__0D05FF57_D1B7_11D6_A666_0050BAE30439__INCLUDED_)
