//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOSpacingAction.h: interface for the CFOSpacingAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSPACINGACTION_H__5D3EDD18_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOSPACINGACTION_H__5D3EDD18_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "FOActionMacro.h"
///////////////////////////////////////////////////////////////////
// Spacement type.
// Define for CFOSpacingAction
///////////////////////////////////////////////////////////////////
enum SpacingFlag
{
	SpacingNone,		// Spacing none.
	SpacingCross,		// Spacing cross.
	SpacingDown			// Spacing down.
};

//////////////////////////////////////////////////////////////////////////////////
// CFOSpacingAction -- action that make space between a list of shapes.

 
//===========================================================================
// Summary:
//     The CFOSpacingAction class derived from CFOActionMacro
//      F O Spacing Action
//===========================================================================

class FO_EXT_CLASS CFOSpacingAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSpacingAction---F O Spacing Action, Specifies a E-XD++ CFOSpacingAction object (Value).
	DECLARE_ACTION(CFOSpacingAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Spacing Action, Constructs a CFOSpacingAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOSpacingAction(CFODataModel* pModel);
	// Attributes

	// The spacement type used to reposition shapes. 
 
	// Spacingment, This member specify SpacingFlag object.  
	SpacingFlag m_nSpacingment;

	// Get the main componet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMainShape();

	// Find the correct action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Move Action, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOBaseAction *FindMoveAction(CFODrawShape *pShape);

	// Order hor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Order Hor Shapes, .
	// Parameters:
	//		<CFODrawShape*---C F O Draw Shape*, Specifies A CArray array.  
	//		&selection---A pointer to the CFODrawShape or NULL if the call failed.
	void OrderHorShapes(CArray <CFODrawShape*, CFODrawShape*> &selection);

	// Order ver.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Order Ver Shapes, .
	// Parameters:
	//		<CFODrawShape*---C F O Draw Shape*, Specifies A CArray array.  
	//		&selection---A pointer to the CFODrawShape or NULL if the call failed.
	void OrderVerShapes(CArray <CFODrawShape*, CFODrawShape*> &selection);

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	// Add shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObj---*pObj, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShape(CFODrawShape *pObj);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Get spacing type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spacing Type, Returns the specified value.
	// Parameters:
	//		nSpacingment---nSpacingment, Specifies a SpacingFlag& nSpacingment object(Value).
	void GetSpacingType(SpacingFlag& nSpacingment) const;

	// Set spacing type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spacing Type, Sets a specify value to current class CFOSpacingAction
	// Parameters:
	//		nSpacingment---nSpacingment, Specifies a SpacingFlag nSpacingment object(Value).
	void SetSpacingType(SpacingFlag nSpacingment);

	// Attributes
protected:

	// list of object of class
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;	

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;		// friend class
};

_FOLIB_INLINE void CFOSpacingAction::GetSpacingType(SpacingFlag& nSpacingment) const
{
	nSpacingment = m_nSpacingment;
}

_FOLIB_INLINE void CFOSpacingAction::SetSpacingType(SpacingFlag nSpacingment)
{
	m_nSpacingment = nSpacingment;
}

#endif // !defined(AFX_FOSPACINGACTION_H__5D3EDD18_F259_11DD_A433_525400EA266C__INCLUDED_)
