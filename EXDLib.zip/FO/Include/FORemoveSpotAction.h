//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOREMOVESPOTACTION_H__5ABCA955_57E1_11D6_A57B_525400EA266C__INCLUDED_)
#define AFC_FOREMOVESPOTACTION_H__5ABCA955_57E1_11D6_A57B_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Description
// Author: Author Name
///////////////////////////////////////

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFORemoveSpotAction -- action that remove spot from line shape.

 
//===========================================================================
// Summary:
//     The CFORemoveSpotAction class derived from CFOAction
//      F O Remove Spot Action
//===========================================================================

class FO_EXT_CLASS CFORemoveSpotAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveSpotAction---F O Remove Spot Action, Specifies a E-XD++ CFORemoveSpotAction object (Value).
	DECLARE_ACTION(CFORemoveSpotAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Spot Action, Constructs a CFORemoveSpotAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFORemoveSpotAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Spot Action, Destructor of class CFORemoveSpotAction
	//		Returns A  value (Object).
	~CFORemoveSpotAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORemoveSpotAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Index, Returns the specified value.
	//		Returns a int type value.
	int GetSpotIndex() const { return m_nSpotIndex; }

	// Set spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Index, Sets a specify value to current class CFORemoveSpotAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetSpotIndex(const int &nIndex) { m_nSpotIndex = nIndex; }

	// Get spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetSpotPoint() const { return m_ptPoint; }

	// Set spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Point, Sets a specify value to current class CFORemoveSpotAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetSpotPoint(const CPoint &pt) { m_ptPoint = pt; }

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	// Add spot index.
 
	// Spot Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nSpotIndex;

	// Add new point.
 
	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint  m_ptPoint;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORemoveSpotAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFORemoveSpotAction::GetShape()
{
	return m_pShape;
}



//////////////////////////////////////////////////////////////////////////////////
// CFORemoveUserPointAction -- action that remove spot from line shape.

 
//===========================================================================
// Summary:
//     The CFORemoveUserPointAction class derived from CFOAction
//      F O Remove Spot Action
//===========================================================================

class FO_EXT_CLASS CFORemoveUserPointAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveUserPointAction---F O Remove Spot Action, Specifies a E-XD++ CFORemoveUserPointAction object (Value).
	DECLARE_ACTION(CFORemoveUserPointAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Spot Action, Constructs a CFORemoveUserPointAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFORemoveUserPointAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Spot Action, Destructor of class CFORemoveUserPointAction
	//		Returns A  value (Object).
	~CFORemoveUserPointAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORemoveUserPointAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Index, Returns the specified value.
	//		Returns a int type value.
	int GetSpotIndex() const { return m_nSpotIndex; }

	// Set spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Index, Sets a specify value to current class CFORemoveUserPointAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetSpotIndex(const int &nIndex) { m_nSpotIndex = nIndex; }

	// Get spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetSpotPoint() const { return m_ptPoint; }

	// Set spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Point, Sets a specify value to current class CFORemoveUserPointAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetSpotPoint(const CPoint &pt) { m_ptPoint = pt; }

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	// Add spot index.
 
	// Spot Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nSpotIndex;

	// Add new point.
 
	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint  m_ptPoint;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORemoveUserPointAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFORemoveUserPointAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFC_FOREMOVESPOTACTION_H__5ABCA955_57E1_11D6_A57B_525400EA266C__INCLUDED_)
