//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCOMPLEXPICKERDRAWBASE_H__610A1FA4_BDEA_4C2F_8154_5151476B0F1D__INCLUDED_)
#define AFX_FOPCOMPLEXPICKERDRAWBASE_H__610A1FA4_BDEA_4C2F_8154_5151476B0F1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPComplexPickerDrawBase.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPComplexPickerDrawBase window

#include "FOPDrawControlPanel.h"

const unsigned FOP_INDEXW_CANCEL		= 1;
const unsigned FOP_INDEXW_CHANGE		= 2;
const unsigned FOP_INDEXW_BUTTONONE		= 3;
const unsigned FOP_INDEXW_BUTTONTWO		= 4;
const unsigned FOP_INDEXW_HEADERBARONE	= 5;
const unsigned FOP_INDEXW_HEADERBARTWO	= 6;

// Call back object for linking to drop down buttons
struct FOPComplexPickerCallback
{
	// return true to indicate handled
	// Do when index changed.
	virtual void	OnWellIndexChange(int nIndex)	= 0;

	// Do when cancel action
	virtual void	OnWellCancel()				= 0;

	// Do when choose headerbar one button action.
	virtual BOOL 	OnWellHeaderBarOne();

	// Do when choose headerbar two button action.
	virtual BOOL 	OnWellHeaderBarTwo();

	// Do when choose button one action.
	virtual BOOL 	OnWellButtonOne();

	// Do when choose button two action.
	virtual BOOL 	OnWellButtonTwo();
};

 
//===========================================================================
// Summary:
//     The FOPComplexPickerDrawBase class derived from FOPDrawControlPanel
//      O P Complex Picker Draw Base
//===========================================================================

class FO_EXT_CLASS FOPComplexPickerDrawBase : public FOPDrawControlPanel
{
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complex Picker Draw Base, Constructs a FOPComplexPickerDrawBase object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).  
	//		but---Specifies a HasButton but object(Value).  
	//		trans---Specifies A Boolean value.
						FOPComplexPickerDrawBase(HasHeaderBar ind, HasButton but,
							BOOL  trans);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Complex Picker Draw Base, Destructor of class FOPComplexPickerDrawBase
	//		Returns A  value (Object).
						~FOPComplexPickerDrawBase();
	// HeaderBar.
	enum 
	{
		HeaderBarOneIndex = -2, 
		HeaderBarTwoIndex = -1
	};
	
	// virtual functions called from FOPPickerBaseWnd

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString		GetMainGroupName(int nIndex);

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString		GetExtraGroupName(int nIndex);

	// Draw main group face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void				DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void				DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// return false if Well is to be destroyed
	// Notify when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	BOOL 				NotifyCancel(BOOL  IsPopup);

	// Notify when button pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	BOOL 				NotifyButtonPressed(int nIndex, BOOL  IsPopup);

	// Notify when headerbar pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		b---Specifies A Boolean value.
	BOOL 				NotifyHeaderBarPressed(int nIndex, BOOL b);

	// Notify when main group selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		b---Specifies A Boolean value.
	BOOL 				NotifyWellMainGroupSelected(int nIndex, BOOL b);

	// Notify when extra group selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		b---Specifies A Boolean value.
	BOOL 				NotifyWellExtraGroupSelected(int nIndex, BOOL b);

	// Notify system color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify System Color Change, .

	void				NotifySysColorChange() {}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		TRUE)---R U E), Specifies A Boolean value.
	// Draw state.
	virtual void		Draw(CDC& DC, const CRect& rect, int nIndex, BOOL  transparent = FALSE, BOOL  focus = FALSE, BOOL  enabled = TRUE)=0;

	// Get count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int					GetCount() const						{	return m_nCount;		};
	
	// assessor functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetIndex() const;
	
	// Get transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 				GetTransparency()						{	return m_bTransparent;	}
	
	// Get call back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button, Returns the specified value.
	//		Returns a pointer to the object FOPComplexPickerCallback,or NULL if the call failed
	FOPComplexPickerCallback*	GetButton() const				{	return m_pPicker;		}
	
	// Get fill color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual COLORREF	GetFillColor() const = 0;

	// mutator functions

	// Set index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class FOPComplexPickerDrawBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void		SetIndex(int nIndex);
	
	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPComplexPickerDrawBase
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void				SetTransparency(BOOL  bTransparent)		{	m_bTransparent = bTransparent;	}
	
	// Set callback
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPComplexPickerDrawBase
	// Parameters:
	//		button---A pointer to the FOPComplexPickerCallback or NULL if the call failed.
	void				SetButton(FOPComplexPickerCallback* button)	{	m_pPicker = button;	}

protected:
	// Set count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Count, Sets a specify value to current class FOPComplexPickerDrawBase
	// Parameters:
	//		nCount---nCount, Specifies A integer value.
	void				SetCount(int nCount)							{	m_nCount = nCount;			}
	
	// Array strings.
 
	// Texts, The member supports arrays of CString objects.  
	CStringArray 		m_arTexts;

	// data
	// Call back
 
	// Picker, This member maintains a pointer to the object FOPComplexPickerCallback.  
	FOPComplexPickerCallback*	m_pPicker;

	// Transparent.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 				m_bTransparent;

	// Count
 
	// Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCount;
};

// DDX
void DDX_Index(CDataExchange* pDX, FOPComplexPickerDrawBase& w, int& index);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCOMPLEXPICKERDRAWBASE_H__610A1FA4_BDEA_4C2F_8154_5151476B0F1D__INCLUDED_)
