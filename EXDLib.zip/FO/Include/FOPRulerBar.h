//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPRULERBAR_H__9A3049D8_7EBA_4492_ADE4_692493BD7EB1__INCLUDED_)
#define AFC_FOPRULERBAR_H__9A3049D8_7EBA_4492_ADE4_692493BD7EB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include "FODrawShape.h"
#include "FOScaleUint.h"

// Ruler bar type
enum FOPRulerType
{
	FOP_HORZ_RULER, // Horz ruler
	FOP_VERT_RULER  // Vert ruler
};

// Ruler arrow
struct FOPRulerArrow
{
    long    nPos;	// Arrow pos
    long    nWidth; // Arrow width
    USHORT  nStyle; // Arrow style
};

// Ticks of the the rulers
 
//===========================================================================
// Summary:
//      To use a FOPRulerTick object, just call the constructor.
//      O P Ruler Tick
//===========================================================================

class FO_EXT_CLASS FOPRulerTick
{
public:

	// unit of the ruler
 
	// Unit, This member specify FieldUnit object.  
	FieldUnit	m_Unit;

	// Value of the tick
 
	// Value, This member specify double object.  
	double		m_dValue;

	// Current of the value.
 
	// Current Value, This member specify double object.  
	double		m_dCurValue;

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ruler Tick, Constructs a FOPRulerTick object.
	//		Returns A  value (Object).
	FOPRulerTick() { m_Unit = FUNIT_MM;  m_dValue = 0.0; }

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ruler Tick, Constructs a FOPRulerTick object.
	//		Returns A  value (Object).  
	// Parameters:
	//		Unit---Unit, Specifies a FieldUnit Unit object(Value).  
	//		Value---Value, Specifies a double Value object(Value).
	FOPRulerTick(FieldUnit Unit,double Value) { m_Unit = Unit; m_dValue = Value; }

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ruler Tick, Destructor of class FOPRulerTick
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPRulerTick() {};
};

//////////////////////////////////////////////////////////////////
// CFOPRulerBar -- ruler bar shape, E-XD++'s ruler bar is also a standard shape, 
//				ID: None

 
//===========================================================================
// Summary:
//     The CFOPRulerBar class derived from CFODrawShape
//      F O P Ruler Bar
//===========================================================================

class FO_EXT_CLASS CFOPRulerBar : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRulerBar---F O P Ruler Bar, Specifies a E-XD++ CFOPRulerBar object (Value).
	DECLARE_SERIAL(CFOPRulerBar);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ruler Bar, Constructs a CFOPRulerBar object.
	//		Returns A  value (Object).
	CFOPRulerBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ruler Bar, Constructs a CFOPRulerBar object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRulerBar& src object(Value).
	CFOPRulerBar(const CFOPRulerBar& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Ruler Bar, Destructor of class CFOPRulerBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPRulerBar();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPRulerBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies a const FOPRulerType & nType object(Value).  
	//		rcBounds---rcBounds, Specifies A CRect type value.
	// Creates the shape and initializes the data members.
	// nType -- type of the ruler,it should be one of the following value:
	//	enum FOPRulerType
	// {
	//	FOP_HORZ_RULER, // Horz ruler
	//	FOP_VERT_RULER  // Vert ruler
	// };
	// rcBounds -- bounding rectangle of the ruler
	virtual void Create(const FOPRulerType & nType, const CRect& rcBounds);

public:
	
	// Origin point of the ruler
 
	// Ruler Org, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptRulerOrg;

	// Vert font.
 
	// Vertical Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*			m_pVertFont;

	// Start track position
 
	// Start Track Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nStartTrackPos;

	// End tack position
 
	// End Track Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nEndTrackPos;
	

public:

	// Obtain the unit of the ruler.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Unit, Returns the specified value.
	//		Returns A FieldUnit value (Object).
	FieldUnit GetRulerUnit() const { return m_RulerUnit; }

	// Change the ruler unit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Unit, Sets a specify value to current class CFOPRulerBar
	// Parameters:
	//		&unit---Specifies a const FieldUnit &unit object(Value).
	void SetRulerUnit(const FieldUnit &unit) { m_RulerUnit = unit; }

	// Ruler type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Type, Returns the specified value.
	//		Returns A FOPRulerType value (Object).
	FOPRulerType GetRulerType() const { return m_nRulerType; }

	// Change ruler type 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Type, Sets a specify value to current class CFOPRulerBar
	// Parameters:
	//		&nType---&nType, Specifies a const FOPRulerType &nType object(Value).
	void SetRulerType(const FOPRulerType &nType) { m_nRulerType = nType; }

	// Is enable drawing tracking point or rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Track, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEnableTrack() const { return m_bEnableTrack; }

	// Set enable drawing tracking point or rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Draw Track, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableDrawTrack(const BOOL &bEnable) { m_bEnableTrack = bEnable; }

	// Is enable drawing border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Border, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEnableBorder() const { return m_bEnableBorder; }

	// Set enable drawing border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Draw Border, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableDrawBorder(const BOOL &bEnable) { m_bEnableBorder = bEnable; }

	// Obtain the total bounds rectangle of the ruler
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Bounds, Sets a specify value to current class CFOPRulerBar
	//		Returns a CRect type value.
	CRect SetTotalBounds() const;

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Initial Property Value, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL DoGetInitPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
	// Change the total bounds of the ruler
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Bounds, Sets a specify value to current class CFOPRulerBar
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rect---Specifies A CRect type value.
	BOOL SetTotalBounds(const CRect& rect);

	// Obtain the arrow count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow Count, Returns the specified value.
	//		Returns A USHORT value (Object).
    USHORT  GetArrowCount() const;

	// Obtain the pointer of the arrows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrows, Returns the specified value.
	//		Returns a pointer to the object const FOPRulerArrow,or NULL if the call failed
    const FOPRulerArrow*   GetArrows() const;

	// Calculate drawing steps.
	// nMinLevel -- min level value.
	// nUpperLevel -- upper level value.
	// pDSteps -- pointer of the ruler tick
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Ruler Steps, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMinLevel---Minimize Level, Specifies A integer value.  
	//		&nUpperLevel---Upper Level, Specifies A integer value.  
	//		*pDSteps---D Steps, A pointer to the FOPRulerTick  or NULL if the call failed.
	virtual void CalcRulerSteps(int &nMinLevel,int &nUpperLevel,FOPRulerTick *pDSteps);

	// Do update font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);
	
public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPRulerBar& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPRulerBar& src object(Value).
	CFOPRulerBar& operator=(const CFOPRulerBar& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Drawing arrows on the ruler bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Arrows, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nCenter---nCenter, Specifies A 32-bit long signed integer.
	virtual void OnDrawArrows(CDC *pDC, long nCenter );

	// Drawing custom border for the ruler.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Border, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcDraw---&rcDraw, Specifies a const FOPRect &rcDraw object(Value).
	virtual void OnDrawBorder(CDC *pDC, const FOPRect &rcDraw);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// Do Middle Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual void OnMButtonDown(UINT nFlags, CPoint pt);

	// Do middle button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual void OnMButtonUp(UINT nFlags, CPoint pt);

	// Do middle button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Enable drawing tracking point or rectangle.
 
	// Enable Track, This member sets TRUE if it is right.  
	BOOL			m_bEnableTrack;

	// Enable drawing border.
 
	// Enable Border, This member sets TRUE if it is right.  
	BOOL			m_bEnableBorder;

	// Ruler arrow
 
	// Arrows, This member maintains a pointer to the object FOPRulerArrow.  
	FOPRulerArrow*  pArrows;

	// Count of the arrow
 
	// Arrows, This member specify USHORT object.  
	USHORT          nArrows;

	// Ruler unit
 
	// Ruler Unit, This member specify FieldUnit object.  
	FieldUnit		m_RulerUnit;

	// Ruler type
 
	// Ruler Type, This member specify FOPRulerType object.  
	FOPRulerType	m_nRulerType;
	int Markp;
	int oldMark;
	bool Mpressed;
	int ActCol;
	int ActTab;
	double Scaling;
	int RulerCode;
	int MouseX;
	bool textEditMode;
	double ColGap;
	double lineCorr;
	int Cols;
	double RExtra;
	double Extra;
	double Indent;
	double First;
	double RMargin;
	bool Revers;
	double ItemPos;
	double ItemEndPos;
	double offs;
};


#endif // !defined(AFC_FOPRULERBAR_H__9A3049D8_7EBA_4492_ADE4_692493BD7EB1__INCLUDED_)
