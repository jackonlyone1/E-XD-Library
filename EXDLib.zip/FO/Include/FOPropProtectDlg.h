//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPROPPROTECTDLG_H__9BD83758_418B_4DD1_BC07_46326C6A5E5E__INCLUDED_)
#define AFX_FOPROPPROTECTDLG_H__9BD83758_418B_4DD1_BC07_46326C6A5E5E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPropProtectDlg.h : header file
//
#include "FOImageButton.h"
/////////////////////////////////////////////////////////////////////////////
// CFOPropProtectDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPropProtectDlg class derived from CDialog
//      F O Property Protect Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropProtectDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Protect Dialog, Constructs a CFOPropProtectDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropProtectDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPropProtectDlg)
	enum { IDD = IDD_FO_PROP_PROTECT };
 
	// Copy Prot, This member sets TRUE if it is right.  
	BOOL	m_bCopyProt;
 
	// Delete Prot, This member sets TRUE if it is right.  
	BOOL	m_bDeleteProt;
 
	// Move Prot, This member sets TRUE if it is right.  
	BOOL	m_bMoveProt;
 
	// Print Prot, This member sets TRUE if it is right.  
	BOOL	m_bPrintProt;
 
	// Resize Prot, This member sets TRUE if it is right.  
	BOOL	m_bResizeProt;
 
	// Rotate Prot, This member sets TRUE if it is right.  
	BOOL	m_bRotateProt;
 
	// Select Prot, This member sets TRUE if it is right.  
	BOOL	m_bSelectProt;
 
	// Aspect Ratio, This member sets TRUE if it is right.  
	BOOL	m_bAspectRatio;
 
	// Tab Order Prot, This member sets TRUE if it is right.  
	BOOL	m_bTabOrderProt;
 
	// Expand Center, This member sets TRUE if it is right.  
	BOOL	m_bExpandCenter;
 
	// X Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bXPosProtect;
 
	// Y Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bYPosProtect;
 
	// Width Protect, This member sets TRUE if it is right.  
	BOOL	m_bWidthProtect;
 
	// Height Protect, This member sets TRUE if it is right.  
	BOOL	m_bHeightProtect;
 
	// Text Protect, This member sets TRUE if it is right.  
	BOOL	m_bTextProtect;
	//}}AFX_DATA

 
	// Old Copy Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldCopyProt;
 
	// Old Delete Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldDeleteProt;
 
	// Old Move Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldMoveProt;
 
	// Old Print Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldPrintProt;
 
	// Old Resize Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldResizeProt;
 
	// Old Rotate Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldRotateProt;
 
	// Old Select Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldSelectProt;
 
	// Old Aspect Ratio, This member sets TRUE if it is right.  
	BOOL	m_bOldAspectRatio;
 
	// Old Tab Order Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldTabOrderProt;
 
	// Old Expand Center, This member sets TRUE if it is right.  
	BOOL	m_bOldExpandCenter;
 
	// Old X Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldXPosProtect;
 
	// Old Y Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldYPosProtect;
 
	// Old Width Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldWidthProtect;
 
	// Old Height Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldHeightProtect;
 
	// Old Text Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldTextProtect;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPropProtectDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropProtectDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button All, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button None, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonNone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPItemPropDlg dialog

 
//===========================================================================
// Summary:
//     The CFOPItemPropDlg class derived from CDialog
//      F O P Item Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOPItemPropDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Item Property Dialog, Constructs a CFOPItemPropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPItemPropDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPItemPropDlg)
	enum { IDD = IDD_FO_TOOLBOX_ITEMPROP };
 
	// Copy Prot, This member sets TRUE if it is right.  
	BOOL	m_bCopyProt;
 
	// Delete Prot, This member sets TRUE if it is right.  
	BOOL	m_bDeleteProt;
 
	// Move Prot, This member sets TRUE if it is right.  
	BOOL	m_bMoveProt;
 
	// Print Prot, This member sets TRUE if it is right.  
	BOOL	m_bPrintProt;
 
	// Resize Prot, This member sets TRUE if it is right.  
	BOOL	m_bResizeProt;
 
	// Rotate Prot, This member sets TRUE if it is right.  
	BOOL	m_bRotateProt;
 
	// Label Visible, This member sets TRUE if it is right.  
	BOOL	m_bLabelVisible;
 
	// Aspect Ratio, This member sets TRUE if it is right.  
	BOOL	m_bAspectRatio;
 
	// Tab Order Prot, This member sets TRUE if it is right.  
	BOOL	m_bTabOrderProt;
 
	// Movable, This member sets TRUE if it is right.  
	BOOL	m_bMovable;
 
	// Allow Select, This member sets TRUE if it is right.  
	BOOL	m_bAllowSelect;
 
	// X Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bXPosProtect;
 
	// Y Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bYPosProtect;
 
	// Width Protect, This member sets TRUE if it is right.  
	BOOL	m_bWidthProtect;
 
	// Height Protect, This member sets TRUE if it is right.  
	BOOL	m_bHeightProtect;
 
	// Text Protect, This member sets TRUE if it is right.  
	BOOL	m_bTextProtect;
 
	// Side, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nSide;
 
	// Allow Hit Child, This member sets TRUE if it is right.  
	BOOL	m_bAllowHitChild;
	//}}AFX_DATA

 
	// Old Copy Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldCopyProt;
 
	// Old Delete Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldDeleteProt;
 
	// Old Move Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldMoveProt;
 
	// Old Print Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldPrintProt;
 
	// Old Resize Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldResizeProt;
 
	// Old Rotate Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldRotateProt;
 
	// Old Label Visible, This member sets TRUE if it is right.  
	BOOL	m_bOldLabelVisible;
 
	// Old Aspect Ratio, This member sets TRUE if it is right.  
	BOOL	m_bOldAspectRatio;
 
	// Old Tab Order Prot, This member sets TRUE if it is right.  
	BOOL	m_bOldTabOrderProt;
 
	// Old Movable, This member sets TRUE if it is right.  
	BOOL	m_bOldMovable;
 
	// Old Allow Select, This member sets TRUE if it is right.  
	BOOL	m_bOldAllowSelect;
 
	// Old X Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldXPosProtect;
 
	// Old Y Position Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldYPosProtect;
 
	// Old Width Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldWidthProtect;
 
	// Old Height Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldHeightProtect;
 
	// Old Text Protect, This member sets TRUE if it is right.  
	BOOL	m_bOldTextProtect;
 
	// Old Allow Hit Child, This member sets TRUE if it is right.  
	BOOL	m_bOldAllowHitChild;
 
	// Old Side, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldSide;

	// Tool tip text
 
	// Tool Tip, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strToolTip;
	
	// Save tool tip text
 
	// Old Tool Tip, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldToolTip;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPItemPropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPItemPropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button All, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button None, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonNone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio3, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio3();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio4, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio4();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Radio5, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOPRadio5();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPROPPROTECTDLG_H__9BD83758_418B_4DD1_BC07_46326C6A5E5E__INCLUDED_)
