//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPEXPORTIMAGEFILE_H__9A55FF9B_BF1B_408E_8345_FDE3E9C87CAE__INCLUDED_)
#define AFX_FOPEXPORTIMAGEFILE_H__9A55FF9B_BF1B_408E_8345_FDE3E9C87CAE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPExportImageFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPExportImageFile

#include "jpeglib.h"
extern "C"
{
#define JPEG_CJPEG_DJPEG
#define JPEG_INTERNAL_OPTIONS
#include "jversion.h"
#include "jinclude.h"
#include "jerror.h"
#include "cderror.h"
}

#define	FOPReadOK(buffer, len)	(ReadData(buffer, len) == ((size_t) (len)))

/////////////////////////////////////////////////////////////
// CFOPJpegToBMPFile -- helper class that convert jpeg to bitmap file.

 
//===========================================================================
// Summary:
//     The CFOPJpegToBMPFile class derived from CObject
//      F O P Jpeg To B M P File
//===========================================================================

class FO_EXT_CLASS CFOPJpegToBMPFile : public CObject
{
 
	// F O P J P E G Compressor, This member specify friend class object.  
friend class CFOPJPEGCompressor;
 
	// O X J P E G Decompressor, This member specify friend class object.  
friend class COXJPEGDecompressor;

protected:
	// Bits per pixel.
 
	// Bits Per Pixel, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nBitsPerPixel;	

	// Call back
	JDIMENSION			(CFOPJpegToBMPFile::*m_pfnGetPixelRows)(j_compress_ptr dataInfo);

	// Specific Decompress members
 
	// Is O S2, This member sets TRUE if it is right.  
	BOOL				m_bIsOS2;

	// Data width.
 
	// Data Width, This member specify JDIMENSION object.  
	JDIMENSION			m_aDataWidth;

	// Pad bytes
 
	// Pad Bytes, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nPadBytes;

	// Row write
 
	// Write Row, This member specify JDIMENSION object.  
	JDIMENSION			m_aWriteRow;

	// Call back
	void				(CFOPJpegToBMPFile::*m_pfnPutPixelRows)(j_decompress_ptr dataInfo, JDIMENSION rows_supplied);

	// Pointer of file data
 
	// Data File, This member maintains a pointer to the object CFile.  
	CFile*				m_pDataFile;

	// File name
 
	// File Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strFileName;

		// Shared members
 
	// Image Data, This member specify jvirt_sarray_ptr object.  
	jvirt_sarray_ptr	m_aImageData;	

	// Row width
 
	// Row Width, This member specify JDIMENSION object.  
	JDIMENSION			m_aRowWidth;		

	// Specific Compress members
 
	// Information, This member specify j_compress_ptr object.  
	j_compress_ptr		m_aInfo;

	// Color map
 
	// Color Map, This member specify JSAMPARRAY object.  
	JSAMPARRAY			m_aColorMap;	
	
	// Row source
 
	// Source Row, This member specify JDIMENSION object.  
	JDIMENSION			m_aSourceRow;	

	// Buffer
 
	// Buffer, This member specify JSAMPARRAY object.  
	JSAMPARRAY			m_aBuffer;
	
	// Buffer height
 
	// Buffer Height, This member specify JDIMENSION object.  
	JDIMENSION			m_aBufferHeight;

	// Total reset
 
	// Total Reset, This member sets TRUE if it is right.  
	BOOL				m_bTotalReset;

// Member Functions
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg To B M P File, Constructs a CFOPJpegToBMPFile object.
	//		Returns A  value (Object).
	CFOPJpegToBMPFile(); 

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg To B M P File, Constructs a CFOPJpegToBMPFile object.
	//		Returns A  value (Object).  
	// Parameters:
	//		sFullPath---Full Path, Specifies A CString type value.
	CFOPJpegToBMPFile(CString sFullPath);  

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg To B M P File, Constructs a CFOPJpegToBMPFile object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pGFile---G File, A pointer to the CFile or NULL if the call failed.
	CFOPJpegToBMPFile(CFile* pGFile);  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Jpeg To B M P File, Destructor of class CFOPJpegToBMPFile
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPJpegToBMPFile();  

public:

	//  Gets the full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Full File Path, Returns the specified value.
	//		Returns a CString type value.
	CString GetFullFilePath();

	// This function is added to prevent or enforce the object to reset itself completely.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Reset, Sets a specify value to current class CFOPJpegToBMPFile
	// Parameters:
	//		bTotal---bTotal, Specifies A Boolean value.
	void SetTotalReset(BOOL bTotal);

	// Set with OS 2 format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set O S2 Format, Sets a specify value to current class CFOPJpegToBMPFile
	// Parameters:
	//		bIsOS2---Is O S2, Specifies A Boolean value.
	void SetOS2Format(BOOL bIsOS2)
		{ m_bIsOS2 = bIsOS2;}

	// Is OS2 format bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get O S2 Format, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetOS2Format()
		{ return m_bIsOS2;}

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDumpContext&---Dump Context&, Specifies a CDumpContext& object(Value).
	// Dump and assert valid.
#ifdef _DEBUG
	virtual void Dump(CDumpContext&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif //_DEBUG

protected:

	// Start read.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Read, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual BOOL StartRead(j_compress_ptr dataInfo);

	// End read.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Read, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual BOOL FinishRead(j_compress_ptr dataInfo);

	// Obtain pixel of rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pixel Rows, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A JDIMENSION value (Object).  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual JDIMENSION GetPixelRows(j_compress_ptr dataInfo);

	// Start write.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Write, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	virtual BOOL StartWrite(j_decompress_ptr dataInfo);

	// End write.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Write, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	virtual BOOL FinishWrite(j_decompress_ptr dataInfo);

	// Put pixel rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Pixel Rows, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		rowsSupplied---rowsSupplied, Specifies a JDIMENSION rowsSupplied object(Value).
	virtual BOOL PutPixelRows(j_decompress_ptr dataInfo, JDIMENSION rowsSupplied);

	// Init read
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Read, Call InitRead after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual BOOL InitRead(j_compress_ptr dataInfo);

	// Init write
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Write, Call InitWrite after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		bExtra---bExtra, Specifies A Boolean value.
	virtual BOOL InitWrite(j_decompress_ptr dataInfo, BOOL bExtra = FALSE);

	// Read data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Data, Call this function to read the specify data from an archive.
	//		Returns A size_t value (Object).  
	// Parameters:
	//		pBuffer---pBuffer, A pointer to the void or NULL if the call failed.  
	//		length---Specifies a size_t length object(Value).
	size_t ReadData(void* pBuffer, size_t length);

	// Write data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Data, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBuffer---pBuffer, A pointer to the const void or NULL if the call failed.  
	//		length---Specifies a size_t length object(Value).
	BOOL WriteData(const void* pBuffer, size_t length);

	// can throw file exceptions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OpenFile(UINT nOpenFlags);

	// Abort file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Abort File, Terminates this object, and erase it.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AbortFile();

	// Close file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close File, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CloseFile();

	// Read byte
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Byte, Call this function to read the specify data from an archive.
	//		Returns a int type value.
	int ReadByte();

	// Read color map
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Color Map, Call this function to read the specify data from an archive.
	// Parameters:
	//		cmaplen---Specifies A integer value.  
	//		mapentrysize---Specifies A integer value.
	void ReadColorMap(int cmaplen, int mapentrysize);

	// Obtain row 8 bits.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get8bit Row, Returns the specified value.
	//		Returns A JDIMENSION value (Object).  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	JDIMENSION Get8bitRow(j_compress_ptr dataInfo);

	// Obtain row 24 bits.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get24bit Row, Returns the specified value.
	//		Returns A JDIMENSION value (Object).  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	JDIMENSION Get24bitRow(j_compress_ptr dataInfo);

	// Preload image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Preload Image, .
	//		Returns A JDIMENSION value (Object).  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	JDIMENSION PreloadImage(j_compress_ptr dataInfo);

	// Put gray rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Gray Rows, .
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		rows_supplied---Specifies a JDIMENSION rows_supplied object(Value).
	void PutGrayRows(j_decompress_ptr dataInfo, JDIMENSION rows_supplied);

	// Put 24 pixel rows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put24 Pixel Rows, .
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		rows_supplied---Specifies a JDIMENSION rows_supplied object(Value).
	void Put24PixelRows(j_decompress_ptr dataInfo, JDIMENSION rows_supplied);

	// Write bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write B M P Header, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	void WriteBMPHeader(j_decompress_ptr dataInfo);

	// Write os2 header.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write O S2 Header, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	void WriteOS2Header(j_decompress_ptr dataInfo);

	// Write color map.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Color Map, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		map_colors---Specifies A integer value.  
	//		map_entry_size---Specifies A integer value.
	void WriteColorMap (j_decompress_ptr dataInfo, int map_colors, int map_entry_size);

};

////////////////////////////////////////////////////////////
// CFOPJpegSaveFile -- saving jpeg file.

 
//===========================================================================
// Summary:
//     The CFOPJpegSaveFile class derived from CObject
//      F O P Jpeg Save File
//===========================================================================

class FO_EXT_CLASS CFOPJpegSaveFile : public CObject
{
 
	// F O P J P E G Compressor, This member specify friend class object.  
friend class CFOPJPEGCompressor;
 
	// O X J P E G Decompressor, This member specify friend class object.  
friend class COXJPEGDecompressor;

protected:
	// Pointer of image file
 
	// Img File, This member maintains a pointer to the object CFile.  
	CFile*		m_pImgFile;

	// File name
 
	// File Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strFileName;

	// Total reset.
 
	// Total Reset, This member sets TRUE if it is right.  
	BOOL		m_bTotalReset;

// Member Functions
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg Save File, Constructs a CFOPJpegSaveFile object.
	//		Returns A  value (Object).
	CFOPJpegSaveFile();  

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg Save File, Constructs a CFOPJpegSaveFile object.
	//		Returns A  value (Object).  
	// Parameters:
	//		sFullPath---Full Path, Specifies A CString type value.
	CFOPJpegSaveFile(CString sFullPath);  

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Jpeg Save File, Constructs a CFOPJpegSaveFile object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pJPEGFile---J P E G File, A pointer to the CFile or NULL if the call failed.
	CFOPJpegSaveFile(CFile* pJPEGFile); 

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Jpeg Save File, Destructor of class CFOPJpegSaveFile
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPJpegSaveFile();  

public:

	// This function is added to prevent or enforce the object to reset itself completely.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Reset, Sets a specify value to current class CFOPJpegSaveFile
	// Parameters:
	//		bTotal---bTotal, Specifies A Boolean value.
	void SetTotalReset(BOOL bTotal);

	//  Gets the full path. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Full File Path, Returns the specified value.
	//		Returns a CString type value.
	CString GetFullFilePath();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDumpContext&---Dump Context&, Specifies a CDumpContext& object(Value).
	virtual void Dump(CDumpContext&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif //_DEBUG

protected:
	// Compression to JPG 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	static void init_destination (j_compress_ptr dataInfo);

	// Empty output buffer
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	static boolean empty_output_buffer (j_compress_ptr dataInfo);

	// teminate destination
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	static void term_destination(j_compress_ptr dataInfo);

	// Init jpg
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial J P G Destination, Call InitJPGDestination after creating a new object.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).  
	//		pOut---pOut, A pointer to the CFile or NULL if the call failed.
	void InitJPGDestination(j_compress_ptr dataInfo, CFile* pOut);

	// Init write
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Write, Call InitWrite after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).  
	//		bExtra---bExtra, Specifies A Boolean value.
	virtual BOOL InitWrite(j_compress_ptr dataInfo, BOOL bExtra = FALSE);

	// Start write
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Write, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual BOOL StartWrite(j_compress_ptr dataInfo);

	// Finish write
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Write, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).
	virtual BOOL FinishWrite(j_compress_ptr dataInfo);

	// Put row pixels
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Pixel Rows, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).  
	//		Buf---Buffer, Specifies a JSAMPARRAY Buf object(Value).  
	//		rowsSupplied---rowsSupplied, Specifies a JDIMENSION rowsSupplied object(Value).
	virtual BOOL PutPixelRows(j_compress_ptr dataInfo, JSAMPARRAY Buf, JDIMENSION rowsSupplied);

	// Decompression from JPG 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	static void init_source (j_decompress_ptr dataInfo);

	// Fill input buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	static boolean fill_input_buffer (j_decompress_ptr dataInfo);

	// Skip input data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		num_bytes---Specifies A 32-bit long signed integer.
	static void skip_input_data(j_decompress_ptr dataInfo, long num_bytes);

	// Term source
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	static void term_source(j_decompress_ptr dataInfo);

	// Init jpg source
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial J P G Source, Call InitJPGSource after creating a new object.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		pInfile---pInfile, A pointer to the CFile or NULL if the call failed.
	void InitJPGSource(j_decompress_ptr dataInfo, CFile* pInfile);

	// Init read
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Read, Call InitRead after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	virtual BOOL InitRead(j_decompress_ptr dataInfo);

	// Start read
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Read, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	virtual BOOL StartRead(j_decompress_ptr dataInfo);

	// Finish read
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Read, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).
	virtual BOOL FinishRead(j_decompress_ptr dataInfo);

	// Obtain rows pixel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pixel Rows, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A JDIMENSION value (Object).  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_decompress_ptr dataInfo object(Value).  
	//		scanlines---Specifies a JSAMPARRAY scanlines object(Value).  
	//		max_lines---Specifies a JDIMENSION max_lines object(Value).
	virtual JDIMENSION GetPixelRows(j_decompress_ptr dataInfo, JSAMPARRAY scanlines, JDIMENSION max_lines);

	// Translation from one JPG flavor to another
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Coefficients, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object jvirt_barray_ptr,or NULL if the call failed  
	// Parameters:
	//		srdataInfo---srdataInfo, Specifies a j_decompress_ptr srdataInfo object(Value).
	virtual jvirt_barray_ptr* ReadCoefficients(j_decompress_ptr srdataInfo);

	// Copy critical params
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Critical Params, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		srdataInfo---srdataInfo, Specifies a j_decompress_ptr srdataInfo object(Value).  
	//		dstinfo---Specifies a j_compress_ptr dstinfo object(Value).
	virtual void CopyCriticalParams(j_decompress_ptr srdataInfo, j_compress_ptr dstinfo);

	// Write coefficients.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Coefficients, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dstinfo---Specifies a j_compress_ptr dstinfo object(Value).  
	//		coef_arrays---A pointer to the jvirt_barray_ptr or NULL if the call failed.
	virtual void WriteCoefficients(j_compress_ptr dstinfo, jvirt_barray_ptr* coef_arrays);

	// General helper methods
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Data, Call this function to read the specify data from an archive.
	//		Returns A size_t value (Object).  
	// Parameters:
	//		pBuffer---pBuffer, A pointer to the void or NULL if the call failed.  
	//		length---Specifies a size_t length object(Value).
	size_t ReadData(void* pBuffer, size_t length);

	// Write data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Data, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns A size_t value (Object).  
	// Parameters:
	//		pBuffer---pBuffer, A pointer to the const void or NULL if the call failed.  
	//		length---Specifies a size_t length object(Value).
	size_t WriteData(const void* pBuffer, size_t length);

	// can throw file exceptions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OpenFile(UINT nOpenFlags);

	// Abort file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Abort File, Terminates this object, and erase it.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AbortFile();

	// Close file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close File, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CloseFile();

};

//////////////////////////////////////////////////////////////
// CFOPJPEGException -- converting exception.

enum FOP_EDiscreteCosTransf
{ 
	DC_Undefined 			=   0,
		DC_Int					=   1,
		DC_FastInt				= 	2,
		DC_Float				=	3
};

const FOP_EDiscreteCosTransf DC_FIRST = DC_Int;	
const FOP_EDiscreteCosTransf DC_LAST =  DC_Float;	

//////////////////////////////////////////////////////////////
// CFOPJPEGException

 
//===========================================================================
// Summary:
//     The CFOPJPEGException class derived from CException
//      F O P J P E G Exception
//===========================================================================

class FO_EXT_CLASS CFOPJPEGException : public CException
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPJPEGException---F O P J P E G Exception, Specifies a E-XD++ CFOPJPEGException object (Value).
	DECLARE_DYNAMIC( CFOPJPEGException )
public:
 
	// Error Code, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_dwErrorCode;	
	
protected:
 
	// Err Message, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_sErrMsg;

	// Member Functions
public:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P J P E G Exception, Constructs a CFOPJPEGException object.
	//		Returns A  value (Object).  
	// Parameters:
	//		dwErrorCode---Error Code, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pszErrMsg---Err Message, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	CFOPJPEGException(DWORD dwErrorCode, LPCTSTR pszErrMsg);  
	
	// retrieves the error string if available
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Error Message, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszError---lpszError, Specifies a LPTSTR lpszError object(Value).  
	//		nMaxError---Maximize Error, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pnHelpContext---Help Context, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL GetErrorMessage(LPTSTR lpszError, UINT nMaxError, PUINT pnHelpContext = NULL );

	// Destructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P J P E G Exception, Destructor of class CFOPJPEGException
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPJPEGException();  
	
};

//////////////////////////////////////////////////////////
// CFOPJPEGCompressor -- jpeg compressor.

 
//===========================================================================
// Summary:
//     The CFOPJPEGCompressor class derived from CObject
//      F O P J P E G Compressor
//===========================================================================

class FO_EXT_CLASS CFOPJPEGCompressor : public CObject
{

protected:
 
	// Running Codecs Map, This member specify CMapPtrToPtr object.  
	static CMapPtrToPtr m_RunningCodecsMap;
 
	// Warnings, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_sWarnings;

	// Common switches
 
	// Quality, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nQuality;
 
	// Gray Scale, This member sets TRUE if it is right.  
	BOOL				m_bGrayScale;
 
	// Optimize, This member sets TRUE if it is right.  
	BOOL				m_bOptimize;
 
	// Progressive, This member sets TRUE if it is right.  
	BOOL				m_bProgressive;
	
	// Advanced switches
 
	// Distance Cos Transf, This member specify FOP_EDiscreteCosTransf object.  
	FOP_EDiscreteCosTransf	m_eDisCosTransf;

	// Smooth
 
	// Smooth, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nSmooth;

	// Maximize memory
 
	// Maximize Memory, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nMaxMem;
	
	// Wizard switches
 
	// Base Line, This member sets TRUE if it is right.  
	BOOL				m_bBaseLine;

	// Member Functions
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P J P E G Compressor, Constructs a CFOPJPEGCompressor object.
	//		Returns A  value (Object).
	CFOPJPEGCompressor();  

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P J P E G Compressor, Destructor of class CFOPJPEGCompressor
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPJPEGCompressor(); 

public:
	
	//  a concatenated string (separator = \n) of warnings
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Warning Messages, Returns the specified value.
	//		Returns a CString type value.
	CString GetWarningMessages()
	{ return m_sWarnings; }

	// Common switches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Quality, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		nQuality---nQuality, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetQuality(UINT nQuality);
	
	// Obtain quality.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Quality, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetQuality()
	{ return m_nQuality;}
	
	// Change gray scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gray Scale, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		bGrayScale---Gray Scale, Specifies A Boolean value.
	void SetGrayScale(BOOL bGrayScale)
	{ m_bGrayScale = bGrayScale;}
	
	// Obtain gray scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gray Scale, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetGrayScale()
	{ return m_bGrayScale;}
	
	// Change optimize
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Optimize, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		bOptimize---bOptimize, Specifies A Boolean value.
	void SetOptimize(BOOL bOptimize);
	
	// Obtain optimize
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Optimize, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetOptimize()
	{ return m_bOptimize;}
	
	// Change progressive.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Progressive, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		bProgressive---bProgressive, Specifies A Boolean value.
	void SetProgressive(BOOL bProgressive);
	
	// Obtain progressive
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Progressive, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetProgressive()
	{ return m_bProgressive;}
	
	// Advanced switches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Distance Cos Tranf, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		eDisCosTransf---Distance Cos Transf, Specifies a FOP_EDiscreteCosTransf eDisCosTransf object(Value).
	void SetDisCosTranf(FOP_EDiscreteCosTransf eDisCosTransf);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance Cos Tranf, Returns the specified value.
	//		Returns A FOP_EDiscreteCosTransf value (Object).
	FOP_EDiscreteCosTransf GetDisCosTranf()
	{ return m_eDisCosTransf;}
	
	// Change smooth
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Smooth, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		nSmooth---nSmooth, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetSmooth(UINT nSmooth);
	
	// Obtain smooth
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Smooth, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetSmooth()
	{ return m_nSmooth;}
	
	// Change maximize memory
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Memory, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		nMaxMem---Maximize Memory, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetMaxMemory(UINT nMaxMem)
	{ m_nMaxMem = nMaxMem;}
	
	// Obtain maximize memory
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Memory, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetMaxMemory()
	{ return m_nMaxMem;}
	
	// Wizard switches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Base Line, Sets a specify value to current class CFOPJPEGCompressor
	// Parameters:
	//		bBaseLine---Base Line, Specifies A Boolean value.
	void SetBaseLine(BOOL bBaseLine)
	{ m_bBaseLine = bBaseLine;}
	
	// Obtain base line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Line, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetBaseLine()
	{ return m_bBaseLine;}
	
	// compresses the graphics file to the specified JPEG file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Compress, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A short value (Object).  
	// Parameters:
	//		pGraphicsFile---Graphics File, A pointer to the CFOPJpegToBMPFile or NULL if the call failed.  
	//		pJPEGFile---J P E G File, A pointer to the CFOPJpegSaveFile or NULL if the call failed.
	virtual short DoCompress(CFOPJpegToBMPFile* pGraphicsFile, CFOPJpegSaveFile* pJPEGFile);
	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDumpContext&---Dump Context&, Specifies a CDumpContext& object(Value).
	virtual void Dump(CDumpContext&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif //_DEBUG

protected:

	// Process
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process Switches, Call the Process member function to translate a caught exception.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_compress_ptr dataInfo object(Value).  
	//		bForReal---For Real, Specifies A Boolean value.
	virtual void ProcessSwitches(j_compress_ptr dataInfo, BOOL bForReal);

	// Exit error
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	static void error_exit(j_common_ptr dataInfo);

	// output message
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	static void output_message(j_common_ptr dataInfo);

	// emit message
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).  
	//		msg_level---Specifies A integer value.
	static void emit_message(j_common_ptr dataInfo, int msg_level);

	// format message
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).  
	//		buffer---A pointer to the TCHAR or NULL if the call failed.
	static void format_message(j_common_ptr dataInfo, TCHAR* buffer);

	// reset error mgr
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	static void reset_error_mgr(j_common_ptr dataInfo);
	
	// Write
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set J P E G Error Handling, Sets a specify value to current class CFOPJPEGCompressor
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		err---A pointer to the struct jpeg_error_mgr or NULL if the call failed.
	BOOL SetJPEGErrorHandling(struct jpeg_error_mgr* err);

	// Process Error
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process Error, Call the Process member function to translate a caught exception.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	virtual void ProcessError(j_common_ptr dataInfo);

	// Write message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Message, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	virtual void WriteMessage(j_common_ptr dataInfo);

	// Emit message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Emit Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).  
	//		msg_level---Specifies A integer value.
	virtual void EmitMessage(j_common_ptr dataInfo, int msg_level);

	// Format message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).  
	//		buffer---Specifies a LPTSTR buffer object(Value).
	virtual void FormatMessage(j_common_ptr dataInfo, LPTSTR buffer);

	// Reset error.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Error, Called this function to empty a previously initialized CFOPJPEGCompressor object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dataInfo---dataInfo, Specifies a j_common_ptr dataInfo object(Value).
	virtual void ResetError(j_common_ptr dataInfo);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPEXPORTIMAGEFILE_H__9A55FF9B_BF1B_408E_8345_FDE3E9C87CAE__INCLUDED_)
