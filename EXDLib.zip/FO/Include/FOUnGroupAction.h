//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOUNGROUPACTION_H__FC765E84_C623_11D5_A487_525400EA266C__INCLUDED_)
#define AFC_FOUNGROUPACTION_H__FC765E84_C623_11D5_A487_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Action for multi shapes
///////////////////////////////////////

#include "FOAction.h"
#include "FOGroupShape.h"
#include "FOActionMacro.h"

class CFOCompositeShape;

//////////////////////////////////////////////////////////////////////////////////
// CFOUnGroupAction -- action that ungroup a group shape.

 
//===========================================================================
// Summary:
//     The CFOUnGroupAction class derived from CFOAction
//      F O Un Group Action
//===========================================================================

class FO_EXT_CLASS CFOUnGroupAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOUnGroupAction---F O Un Group Action, Specifies a E-XD++ CFOUnGroupAction object (Value).
	DECLARE_ACTION(CFOUnGroupAction)

public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Un Group Action, Constructs a CFOUnGroupAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOUnGroupAction(CFODataModel* pModel);

	// Deconstructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Un Group Action, Destructor of class CFOUnGroupAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOUnGroupAction();

// Overrides
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Get a pointer to the group created by the action. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Group Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape,or NULL if the call failed
	CFOCompositeShape* GetGroupShape();

	// Set the group shape used by the action. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shape, Sets a specify value to current class CFOUnGroupAction
	// Parameters:
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	void SetGroupShape(CFOCompositeShape* pGroup);

	// Get back list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Back Component List, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	CFODrawShapeList* GetBackCompList() { return &m_BackList; }

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOUnGroupAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Ungroup, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pGroup---pGroup, A pointer to the CFOCompositeShape or NULL if the call failed.
	// Ungroup a group shape.
	// pGroup -- the pointer of group shape.
	virtual BOOL			Ungroup(CFOCompositeShape* pGroup);

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
	// Remove all order number.
	void RmeoveAllOrders();
	
	// Get order.
	BOOL GetOrder(CFODrawShape* pComp, int& nIndex) const;
	
	// Set order.
	void SetOrder(CFODrawShape* pComp, int nIndex);
	
	// Update indexes.
	void UpdateIndices(CFODrawShapeList* pCompSet);
	
	// Attributes
	
	// map orders.
	FOPShapeOrderMap m_mapIndices;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Comps list.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

	// Shape list.
 
	// Back List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_BackList;

	// Pointer of group shape
 
	// Group, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape*		m_pGroup;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

//////////////////////////////////////////////////////////////////////////////////
// CFOMultiUnGroupAction -- action that ungroup multiple shapes.

 
//===========================================================================
// Summary:
//     The CFOMultiUnGroupAction class derived from CFOActionMacro
//      F O Multiple Un Group Action
//===========================================================================

class FO_EXT_CLASS CFOMultiUnGroupAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiUnGroupAction---F O Multiple Un Group Action, Specifies a E-XD++ CFOMultiUnGroupAction object (Value).
	DECLARE_ACTION(CFOMultiUnGroupAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Un Group Action, Constructs a CFOMultiUnGroupAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOMultiUnGroupAction(CFODataModel* pModel);
	// Attributes

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	// Add shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOUnGroupAction  or NULL if the call failed.
	virtual void AddAction(CFOUnGroupAction *pAction);

	// Get full list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	virtual void GetShapesList(CFODrawShapeList *pList);

	// Attributes
protected:

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFC_FOUNGROUPACTION_H__FC765E84_C623_11D5_A487_525400EA266C__INCLUDED_)
