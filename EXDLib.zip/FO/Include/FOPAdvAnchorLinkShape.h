//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPADVANCHORLINKSHAPE_H__AC74472E_4D07_4DD4_B77E_D947F86A7B24__INCLUDED_)
#define AFC_FOPADVANCHORLINKSHAPE_H__AC74472E_4D07_4DD4_B77E_D947F86A7B24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOPAdvAnchorLinkShape -- link line shape with advance anchor point.
// Author: Author Name.
//------------------------------------------------------

#include "FOLinkShape.h"
#include "FOPortShape.h"
#include "FOCompositeShape.h"

 
//===========================================================================
// Summary:
//     The CFOPAdvAnchorLinkShape class derived from CFOLinkShape
//      F O P Advance Anchor Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPAdvAnchorLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPAdvAnchorLinkShape---F O P Advance Anchor Link Shape, Specifies a E-XD++ CFOPAdvAnchorLinkShape object (Value).
	DECLARE_SERIAL(CFOPAdvAnchorLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Advance Anchor Link Shape, Constructs a CFOPAdvAnchorLinkShape object.
	//		Returns A  value (Object).
	CFOPAdvAnchorLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Advance Anchor Link Shape, Constructs a CFOPAdvAnchorLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPAdvAnchorLinkShape& src object(Value).
	CFOPAdvAnchorLinkShape(const CFOPAdvAnchorLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Advance Anchor Link Shape, Destructor of class CFOPAdvAnchorLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPAdvAnchorLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPAdvAnchorLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the link shape from points.
	// ptArray -- points of link.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,long nWidth,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPAdvAnchorLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the link shape from points.
	// pptPoints -- points of link.
	// nCount -- total points of link.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(LPPOINT pptPoints, int nCount,long nWidth,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPAdvAnchorLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	// Creates the dim line shape from points.
	// ptStart -- start point.
	// ptEnd -- end point.
	// nWidth -- distance to the line.
	BOOL Create(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPAdvAnchorLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

public:

	// Get the points of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get plus spots
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Offset the current point.
	// pPort -- pointer of the port for tracking.
	// nIndex -- index of point
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL PortTrackOffsetPoint(CFOPortShape *pPort,int nIndex, CPoint ptOffset);

	// Offset all spots.
	// Offset the current point.
	// pPort -- pointer of the port for tracking.
	// ptOffset -- offset point
	// ptScroll -- scrolling point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void PortTrackOffsetAllPoints(CFOPortShape *pPort,CPoint ptOffset,CPoint ptScroll);

	// Offset all spots.
	// ptOffset -- offset point
	// ptScroll -- scrolling point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Other Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOtherPoints(CPoint ptOffset,CPoint ptScroll);

	// Offset the current point.
	// nIndex -- index of the point for tracking
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Link Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackLinkOffsetPoint(int nIndex, CPoint ptOffset);

	// Track Port local point.
	// pPort -- pointer of the port for tracking.
	// ptPoint -- new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Port Local Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL TrackPortLocalPoint(CFOPortShape *pPort,CPoint ptPoint);

	// Port local point.
	// pPort -- pointer of the port for tracking.
	// ptPoint -- new point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Local Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL PortLocalPoint(CFOPortShape *pPort,CPoint ptPoint);

	//////// First point
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetAnchorPoint(CPoint ptOffset);


	//////// Second point
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetExtAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetExtAnchorPoint(CPoint ptOffset);


	//////// Third point
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Third Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetThirdAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Third Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetThirdAnchorPoint(CPoint ptOffset);

	//////// Four point
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Four Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetFourAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Four Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetFourAnchorPoint(CPoint ptOffset);

	//////// Five point
	// Op.
	// Offset one point.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Five Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL		OffsetFiveAnchorPoint(CPoint ptOffset);
	
	// Offset the current point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Five Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetFiveAnchorPoint(CPoint ptOffset);


	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Generate points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Text Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.  
	//		&nTextHeight---Text Height, Specifies A integer value.
	virtual CPoint GenerateTextPoints(LPPOINT cCtlPt,const int &nTextHeight) const;

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPAdvAnchorLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPAdvAnchorLinkShape& src object(Value).
	CFOPAdvAnchorLinkShape& operator=(const CFOPAdvAnchorLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	// pArea -- pointer of the area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

public:
	///////////////////////////////////////////
	// Below methods can be override.

	// Calculate anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual CPoint CalcAnchorPoint(const CPoint &ptStart,const CPoint &ptEnd,
		const double &dWidth,const BOOL &bTrack) const;

	// Calculate anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual CPoint CalcExtAnchorPoint(const CPoint &ptStart,const CPoint &ptEnd,
		const double &dWidth,const BOOL &bTrack) const;

	// Calculate anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Third Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual CPoint CalcThirdAnchorPoint(const CPoint &ptStart,const CPoint &ptEnd,
		const double &dWidth,const BOOL &bTrack) const;

	// Calculate anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Four Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual CPoint CalcFourAnchorPoint(const CPoint &ptStart,const CPoint &ptEnd,
		const double &dWidth,const BOOL &bTrack) const;

	// Calculate anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Five Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&dWidth---&dWidth, Specifies a const double &dWidth object(Value).  
	//		&bTrack---&bTrack, Specifies A Boolean value.
	virtual CPoint CalcFiveAnchorPoint(const CPoint &ptStart,const CPoint &ptEnd,
		const double &dWidth,const BOOL &bTrack) const;

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the true shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

public:
	
	// Offset a spot.
	// nIndex -- index of the point.
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	// nIndex -- index of the point for tracking
	// ptOffset -- offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Return Use Custom Text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Use Custom Text, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetUseCustomText() const { return m_bUseCustomText;}

	// Change Use Custom Text value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use Custom Text, Sets a specify value to current class CFOPAdvAnchorLinkShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetUseCustomText( const BOOL &bValue ) {m_bUseCustomText = bValue; }

	// Return Show Label Inside value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Label Inside, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetShowLabelInside() const { return m_bShowLabelInside;}

	// Change Show Label Inside value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Label Inside, Sets a specify value to current class CFOPAdvAnchorLinkShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetShowLabelInside( const BOOL &bValue ) {m_bShowLabelInside = bValue; }

	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	// rRef1 -- mirror reference line point.
	// rRef2 -- mirror reference line point
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror with point ref1 and ref2.
	// rRef1 -- mirror reference line point.
	// rRef2 -- mirror reference line point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// Obtain the correct distance moved.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Correct Distance, .
	//		Returns A double value (Object).  
	// Parameters:
	//		&ptCalc---&ptCalc, Specifies A CPoint type value.  
	//		&ptSave---&ptSave, Specifies A CPoint type value.  
	//		&bSide---&bSide, Specifies A Boolean value.
	double CalcCorrectDistance(const CPoint &ptCalc,const CPoint &ptSave,BOOL &bSide);

	// Obtain the correct distance moved.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Correct Track Distance, .
	// Parameters:
	//		&ptCalc---&ptCalc, Specifies A CPoint type value.  
	//		&ptSave---&ptSave, Specifies A CPoint type value.  
	//		&dChangeDistance---Change Distance, Specifies a double &dChangeDistance object(Value).
	void CalcCorrectTrackDistance(const CPoint &ptCalc,const CPoint &ptSave,double &dChangeDistance);

	// Check current mirror side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Mirror Side, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.
	BOOL CheckMirrorSide(const CPoint& ptPnt,const CPoint &ptRef1) const;

	// Generate dimension text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Dimension Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	virtual CString GenerateDimText(int nLength);

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	//////// First point
	// Save width.
 
	// Save Width, This member specify double object.  
	double			m_dSaveWidth;

	// Track width.
 
	// Track Width, This member specify double object.  
	double			m_dTrackWidth;

	// Current side of mirror.
 
	// Side, This member sets TRUE if it is right.  
	BOOL			m_bSide;


	//////// Second point
	// Save width.
 
	// Save Width1, This member specify double object.  
	double			m_dSaveWidth1;

	// Track width.
 
	// Track Width1, This member specify double object.  
	double			m_dTrackWidth1;

	// Current side of mirror.
 
	// Side1, This member sets TRUE if it is right.  
	BOOL			m_bSide1;


	//////// Third point
	// Save width.
 
	// Save Width2, This member specify double object.  
	double			m_dSaveWidth2;

	// Track width.
 
	// Track Width2, This member specify double object.  
	double			m_dTrackWidth2;

	// Current side of mirror.
 
	// Side2, This member sets TRUE if it is right.  
	BOOL			m_bSide2;


	//////// Four point
	// Save width.
 
	// Save Width3, This member specify double object.  
	double			m_dSaveWidth3;

	// Track width.
 
	// Track Width3, This member specify double object.  
	double			m_dTrackWidth3;

	// Current side of mirror.
 
	// Side3, This member sets TRUE if it is right.  
	BOOL			m_bSide3;


	//////// Five point
	// Save width.
 
	// Save Width4, This member specify double object.  
	double			m_dSaveWidth4;

	// Track width.
 
	// Track Width4, This member specify double object.  
	double			m_dTrackWidth4;

	// Current side of mirror.
 
	// Side4, This member sets TRUE if it is right.  
	BOOL			m_bSide4;


	// Use custom label text.
 
	// Use Custom Text, This member sets TRUE if it is right.  
	BOOL			m_bUseCustomText;

	// Show label inside or not.
 
	// Show Label Inside, This member sets TRUE if it is right.  
	BOOL			m_bShowLabelInside;

};

//////////////////////////////////////////////////////////////
// CFOPSymbolLinkShape -- link line that can place symbols on it.

 
//===========================================================================
// Summary:
//     The CFOPSymbolLinkShape class derived from CFOLinkShape
//      F O P Symbol Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPSymbolLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSymbolLinkShape---F O P Symbol Link Shape, Specifies a E-XD++ CFOPSymbolLinkShape object (Value).
	DECLARE_SERIAL(CFOPSymbolLinkShape);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Symbol Link Shape, Constructs a CFOPSymbolLinkShape object.
	//		Returns A  value (Object).
	CFOPSymbolLinkShape();
	
	///-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Symbol Link Shape, Constructs a CFOPSymbolLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSymbolLinkShape& src object(Value).
	CFOPSymbolLinkShape(const CFOPSymbolLinkShape& src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Symbol Link Shape, Destructor of class CFOPSymbolLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSymbolLinkShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSymbolLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button Shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPSymbolLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSymbolLinkShape& src object(Value).
	CFOPSymbolLinkShape& operator=(const CFOPSymbolLinkShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;
	
	// Update shape's area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:

	// Composite symbol.
 
	// Symbol, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pSymbol;
};

#endif // !defined(AFC_FOPADVANCHORLINKSHAPE_H__AC74472E_4D07_4DD4_B77E_D947F86A7B24__INCLUDED_)
