//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPMDIFRAMEWND_H__9A25104F_E7DA_415E_A0E1_C4743782C12C__INCLUDED_)
#define AFX_FOPMDIFRAMEWND_H__9A25104F_E7DA_415E_A0E1_C4743782C12C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPMDIFrameWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPMDIFrameWnd frame

#include "FOPFrameWnd.h"
#include "FOPDockBar.h"
#include <afxtempl.h>
#include "FOPFullScreenImpl.h"

class CFOPControlBar;
class CFOPMenuTheme;

/////////////////////////////////////////////////////////////////////////////
// CFOPMDIFrameWnd frame

 
//===========================================================================
// Summary:
//     The CFOPMDIFrameWnd class derived from CMDIFrameWnd
//      F O P M D I Frame Window
//===========================================================================

class FO_EXT_CLASS CFOPMDIFrameWnd : public CMDIFrameWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMDIFrameWnd---F O P M D I Frame Window, Specifies a E-XD++ CFOPMDIFrameWnd object (Value).
	DECLARE_DYNCREATE(CFOPMDIFrameWnd)
		
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P M D I Frame Window, Constructs a CFOPMDIFrameWnd object.
	//		Returns A  value (Object).
	CFOPMDIFrameWnd();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P M D I Frame Window, Destructor of class CFOPMDIFrameWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMDIFrameWnd();

public:

	// Dock sizement.
	struct CFOPDockSize
	{
		// width -- width of the dock bar
		// height -- height of the dock bar
		// flag -- dock flag
		CFOPDockSize (double width = 1.0, int height = 150, DWORD flag = 0) : 
				m_dPtWidth(width), m_nHeight(height), m_aValue1(flag) {}
		
		// width of the dock bar
		double m_dPtWidth;

		// height of the dock bar
		int    m_nHeight;

		// dock flags.
		DWORD m_aValue1;
	};
	
	// Enable docking control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Docking, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		dwDockStyle---Dock Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwDockStyleEx---Dock Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void EnableDocking(DWORD dwDockStyle, DWORD dwDockStyleEx = 0);

	// Create a new dock bar control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Dock Bar, You construct a CFOPMDIFrameWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDockBar ,or NULL if the call failed
	virtual CDockBar * CreateNewDockBar();
	
	// Dock controlbar ex.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dWidth---dWidth, Specifies a double dWidth = 1.0 object(Value).  
	//		nHeight---nHeight, Specifies A integer value.
	virtual void DockControlBarEx(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Dock bar id
		UINT nDockBarID = 0, 
		// Width from(0.0- 1.0).
		double dWidth = 1.0,
		// Height
		int nHeight = 150
		);

	// Float control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Float  Bar, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void FloatControlBar(
		// Pointer of control bar
		CControlBar * pBar, 
		// Float start point.
		CPoint point,
		// Align position.
		DWORD dwStyle = CBRS_ALIGN_TOP
		);

	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Dock bar id.
		UINT nDockBarID = 0,
		// Rectangle
		LPCRECT lpRect = NULL
		);

	// Re dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Dock  Bar, .
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void ReDockControlBar(
		// Pointer of control bar.
		CControlBar * pBar,
		// Dock bar.
		CDockBar * pDockBar,
		// Rectangle.
		LPCRECT lpRect = NULL
		);

	// Show control bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show  Bar, Call this function to show the specify object.
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		bShow---bShow, Specifies A Boolean value.  
	//		bDelay---bDelay, Specifies A Boolean value.
	void ShowControlBar(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Show state.
		BOOL bShow, 
		// Delay show.
		BOOL bDelay
		);

	// Dock control bar left of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Left Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		LeftOf---Left Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarLeftOf(
		// Pointer of control bar.
		CControlBar* Bar,
		// Pointer of control bar.
		CControlBar* LeftOf
		);

	// Dock control bar bottom of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Bottom Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		BottomOf---Bottom Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarBottomOf(
		// Pointer of control bar.
		CControlBar* Bar,
		// Pointer of control bar.
		CControlBar* BottomOf
		);

	// Activate dock bar frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Dockable Frame, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFrameWnd---Frame Window, A pointer to the CFOPFrameWnd  or NULL if the call failed.  
	//		bForce---bForce, Specifies A Boolean value.
	virtual void ActivateDockableFrame(
		// Pointer of frame wnd.
		CFOPFrameWnd * pFrameWnd,
		BOOL bForce = FALSE);

	// De activate dock.
	// bAuto -- Auto Activate Sibline or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Deactivate Dockable Frame, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAuto---bAuto, Specifies A Boolean value.
	virtual void DeactivateDockableFrame(BOOL bAuto = TRUE);

	// Update frame title bar.
	// bAdd -- add to title bar or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Frame Title, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAdd---bAdd, Specifies A Boolean value.
	virtual void OnUpdateFrameTitle(BOOL bAdd);

	// Get active frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Frame, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFrameWnd,or NULL if the call failed
	virtual CFrameWnd* GetActiveFrame();

	//-----------------------------------------------------------------------
	// Summary:
	// Show Menu Image, Call this function to show the specify object.
	void ShowMenuImage();


	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPMDIFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);

	//-----------------------------------------------------------------------
	// Summary:
	// Enable Ole Containment Mode, Call this member function to enable or disable the specify object for this command.

	void EnableOleContainmentMode();

	// Set preview mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Preview Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bPreview---bPreview, Specifies A Boolean value.  
	//		pState---pState, A pointer to the CPrintPreviewState  or NULL if the call failed.
	virtual void OnSetPreviewMode(BOOL bPreview, CPrintPreviewState * pState);

	// Is full screen mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Full Screen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFullScreen() const;

	// Show full screen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Full Screen, Call this function to show the specify object.
	// Parameters:
	//		bWithMenu---With Menu, Specifies A Boolean value.
	void ShowFullScreen(BOOL bWithMenu = TRUE);

public:

	// Get menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu, Returns the specified value.
	//		Returns a pointer to the object CMenu ,or NULL if the call failed
	CMenu * GetMenu() const;

	// Handle of the default menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Menu, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).
	virtual HMENU GetDefaultMenu();

protected:

	// Process help message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process Help Message, Call the Process member function to translate a caught exception.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies a MSG & msg object(Value).  
	//		pContext---pContext, A pointer to the DWORD  or NULL if the call failed.
	BOOL ProcessHelpMsg(MSG & msg, DWORD * pContext);

	// Get window version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Windows Version, Returns the specified value.

	void GetWindowsVersion();

	// Notify active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Active View, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd  or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	virtual void NotifyActiveView (UINT nState, CWnd * pWndOther, BOOL bMinimized);

	// Menu from resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Menu From Resource, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual HMENU MenuFromResource(UINT nID);

	// Connect view.
	class CConnectView : public CView
	{ friend class CFOPMDIFrameWnd; };
	
public:
	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(CControlBar * pBar, CDockBar * pDockBar,LPCRECT lpRect = NULL);

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext & dc object(Value).
	virtual void Dump(CDumpContext & dc) const;
#endif

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPMDIFrameWnd)
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enter Idle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWhy---nWhy, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWho---pWho, A pointer to the CWnd  or NULL if the call failed.
	virtual void OnEnterIdle(UINT nWhy, CWnd * pWho);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bNotify---bNotify, Specifies A Boolean value.
	virtual void RecalcLayout(BOOL bNotify = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void  or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO  or NULL if the call failed.
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void * pExtra,AFX_CMDHANDLERINFO * pHandlerInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Frame Menu, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		hMenuAlt---Menu Alt, Specifies a HMENU hMenuAlt object(Value).
	virtual void OnUpdateFrameMenu(HMENU hMenuAlt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Menu, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIDMenuInfo---I D Menu Information, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void ActivateMenu(UINT nIDMenuInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Frame, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwDefaultStyle---Default Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	virtual BOOL LoadFrame(UINT nIDResource,DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE,CWnd * pParentWnd = NULL,CCreateContext * pContext = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create Client, Called as a part of window creation.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpcs---Specifies a LPCREATESTRUCT lpcs object(Value).  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext * pContext);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL	PreTranslateMessage(MSG * pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOPMDIFrameWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
#if _MSC_VER >= 1300
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd  or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd * pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command Help, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCommandHelp(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctx Menu, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCtxMenu(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void OnEnable(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpcs---Specifies a LPCREATESTRUCT lpcs object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpcs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnContextHelp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Minimize Maximize Information, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		lpMMI---M M I, A pointer to the MINMAXINFO FAR or NULL if the call failed.
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg FOPNcHitTestType value (Object).  
	// Parameters:
	//		point---Specifies A CPoint type value.
	afx_msg FOPNcHitTestType OnNcHitTest(CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// Dock bar state
 
	// Dock Bar[4][2], This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	static const DWORD dwValues1[4][2];
	
private:
	
 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
	
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CFOPMDIChildWnd frame

 
//===========================================================================
// Summary:
//     The CFOPMDIChildWnd class derived from CMDIChildWnd
//      F O P M D I Child Window
//===========================================================================

class FO_EXT_CLASS CFOPMDIChildWnd : public CMDIChildWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMDIChildWnd---F O P M D I Child Window, Specifies a E-XD++ CFOPMDIChildWnd object (Value).
	DECLARE_DYNCREATE(CFOPMDIChildWnd)
		
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P M D I Child Window, Constructs a CFOPMDIChildWnd object.
	//		Returns A  value (Object).
	CFOPMDIChildWnd();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P M D I Child Window, Destructor of class CFOPMDIChildWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMDIChildWnd();

public:

	// Dock sizement.
	struct CFOPDockSize
	{
		// width -- width of the dock bar
		// height -- height of the dock bar
		// flag -- dock flag
		CFOPDockSize (double width = 1.0, int height = 150, DWORD flag = 0) : 
				m_dPtWidth(width), m_nHeight(height), m_aValue1(flag) {}
		
		// width of the dock bar
		double m_dPtWidth;

		// height of the dock bar
		int    m_nHeight;

		// dock flags.
		DWORD m_aValue1;
	};
	
	// Enable docking control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Docking, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		dwDockStyle---Dock Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwDockStyleEx---Dock Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void EnableDocking(DWORD dwDockStyle, DWORD dwDockStyleEx = 0);

	// Create a new dock bar control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Dock Bar, You construct a CFOPMDIChildWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDockBar ,or NULL if the call failed
	virtual CDockBar * CreateNewDockBar();
	virtual void OnHome();
	virtual void OnPrev();
	virtual void OnNext();
	virtual void OnDel();
	virtual void OnAdd();
	virtual void PageChange(const int &nIndex);

	// Dock controlbar ex.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dWidth---dWidth, Specifies a double dWidth = 1.0 object(Value).  
	//		nHeight---nHeight, Specifies A integer value.
	virtual void DockControlBarEx(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Dock bar id
		UINT nDockBarID = 0, 
		// Width from(0.0- 1.0).
		double dWidth = 1.0,
		// Height
		int nHeight = 150
		);

	// Float control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Float  Bar, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void FloatControlBar(
		// Pointer of control bar
		CControlBar * pBar, 
		// Float start point.
		CPoint point,
		// Align position.
		DWORD dwStyle = CBRS_ALIGN_TOP
		);

	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Dock bar id.
		UINT nDockBarID = 0,
		// Rectangle
		LPCRECT lpRect = NULL
		);

	// Re dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Dock  Bar, .
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void ReDockControlBar(
		// Pointer of control bar.
		CControlBar * pBar,
		// Dock bar.
		CDockBar * pDockBar,
		// Rectangle.
		LPCRECT lpRect = NULL
		);

	// Show control bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show  Bar, Call this function to show the specify object.
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		bShow---bShow, Specifies A Boolean value.  
	//		bDelay---bDelay, Specifies A Boolean value.
	void ShowControlBar(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Show state.
		BOOL bShow, 
		// Delay show.
		BOOL bDelay
		);

	
	// Dock control bar left of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Left Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		LeftOf---Left Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarLeftOf(
		// Pointer of control bar.
		CControlBar* Bar,
		// Pointer of control bar.
		CControlBar* LeftOf
		);

	// Dock control bar bottom of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Bottom Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		BottomOf---Bottom Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarBottomOf(
		// Pointer of control bar.
		CControlBar* Bar,
		// Pointer of control bar.
		CControlBar* BottomOf
		);

	// Activate dock bar frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Dockable Frame, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFrameWnd---Frame Window, A pointer to the CFOPFrameWnd  or NULL if the call failed.  
	//		bForce---bForce, Specifies A Boolean value.
	virtual void ActivateDockableFrame(
		// Pointer of frame wnd.
		CFOPFrameWnd * pFrameWnd,
		BOOL bForce = FALSE);

	// De activate dock
	
	//-----------------------------------------------------------------------
	// Summary:
	// Deactivate Dockable Frame, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAuto---bAuto, Specifies A Boolean value.
	virtual void DeactivateDockableFrame(BOOL bAuto = TRUE);

	// Update frame title bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Frame Title, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bAdd---bAdd, Specifies A Boolean value.
	virtual void OnUpdateFrameTitle(BOOL bAdd);

	// Get active frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Frame, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFrameWnd,or NULL if the call failed
	virtual CFrameWnd* GetActiveFrame();

	// Set preview mode.
	// bPrview -- preview or not.
	// pState -- pointer of the print preview state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Preview Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bPreview---bPreview, Specifies A Boolean value.  
	//		pState---pState, A pointer to the CPrintPreviewState  or NULL if the call failed.
	virtual void OnSetPreviewMode(BOOL bPreview, CPrintPreviewState * pState);

	// Swap menu with specify id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Ole Containment Mode, Call this member function to enable or disable the specify object for this command.

	void EnableOleContainmentMode();

public:

	// Get menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu, Returns the specified value.
	//		Returns a pointer to the object CMenu ,or NULL if the call failed
	CMenu * GetMenu() const;

	// Obtain the handle of the default menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Menu, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).
	virtual HMENU GetDefaultMenu();

protected:

	// Is menu be used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Menu Be Use, Determines if the given value is correct or exist.
	// Parameters:
	//		pTemplate---pTemplate, A pointer to the CMultiDocTemplate  or NULL if the call failed.
	void IsMenuBeUse(CMultiDocTemplate * pTemplate);

protected:

	// Process help message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process Help Message, Call the Process member function to translate a caught exception.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies a MSG & msg object(Value).  
	//		pContext---pContext, A pointer to the DWORD  or NULL if the call failed.
	BOOL ProcessHelpMsg(MSG & msg, DWORD * pContext);

	// Get window version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Windows Version, Returns the specified value.

	void GetWindowsVersion();

	// Notify active view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Active View, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd  or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	virtual void NotifyActiveView (UINT nState, CWnd * pWndOther, BOOL bMinimized);

	// Menu from resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Menu From Resource, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual HMENU MenuFromResource(UINT nID);
	class CConnectView : public CView
	{ friend class CFOPMDIChildWnd; };
	
public:
	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(CControlBar * pBar, CDockBar * pDockBar,LPCRECT lpRect = NULL);

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext & dc object(Value).
	virtual void Dump(CDumpContext & dc) const;
#endif

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPMDIChildWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enter Idle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWhy---nWhy, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWho---pWho, A pointer to the CWnd  or NULL if the call failed.
	virtual void OnEnterIdle(UINT nWhy, CWnd * pWho);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bNotify---bNotify, Specifies A Boolean value.
	virtual void RecalcLayout(BOOL bNotify = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Menu, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIDMenuInfo---I D Menu Information, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void ActivateMenu(UINT nIDMenuInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL	PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Frame, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwDefaultStyle---Default Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd * pParentWnd, CCreateContext * pContext);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh Frame Menu, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pActiveWnd---Active Window, A pointer to the CWnd  or NULL if the call failed.
	virtual void RefreshFrameMenu(CWnd * pActiveWnd);		// smart refresh of current frame window menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Frame Menu, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		pActivateWnd---Activate Window, A pointer to the CWnd  or NULL if the call failed.  
	//		hMenuAlt---Menu Alt, Specifies a HMENU hMenuAlt object(Value).
	virtual void OnUpdateFrameMenu(BOOL bActive, CWnd * pActivateWnd,HMENU hMenuAlt);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOPMDIChildWnd)
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
#if _MSC_VER >= 1300
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd  or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd * pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctx Menu, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCtxMenu(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void OnEnable(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpcs---Specifies a LPCREATESTRUCT lpcs object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpcs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a int type value.  
	// Parameters:
	//		pDesktopWnd---Desktop Window, A pointer to the CWnd  or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg int OnMouseActivate(CWnd * pDesktopWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Child Activate, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChildActivate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnContextHelp();
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg FOPNcHitTestType value (Object).  
	// Parameters:
	//		point---Specifies A CPoint type value.
	afx_msg FOPNcHitTestType OnNcHitTest(CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	
	// Dock bar state
 
	// Dock Bar[4][2], This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	static const DWORD dwValues1[4][2];

private:

 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPMDIFRAMEWND_H__9A25104F_E7DA_415E_A0E1_C4743782C12C__INCLUDED_)
