//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBrushTypeControl.h: interface for the CFOBrushTypeControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBRUSHTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FOBRUSHTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBrushTypeCellObj.h"
#include "FOGlobals.h"

#define FO_TOTAL_BRUSHTYPECELLS		42

// Brush type message.
#define WM_FO_SELECTBRUSHTYPEOK				WM_USER+250 // Select brush type ok.
#define WM_FO_SELECTBRUSHTYPECANCEL			WM_USER+251 // Select brush type cancel.
#define WM_FO_SELECTBRUSHTYPECUSTOM			WM_USER+252 // Select brush type custom.
#define WM_FO_SELECTBRUSHTYPECHANGE			WM_USER+253 // Select brush type change.

 
//===========================================================================
// Summary:
//     The CFOBrushTypeControl class derived from CObject
//      F O Brush Type 
//===========================================================================

class FO_EXT_CLASS CFOBrushTypeControl : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBrushTypeControl---F O Brush Type , Specifies a E-XD++ CFOBrushTypeControl object (Value).
	DECLARE_SERIAL(CFOBrushTypeControl);

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Brush Type , Constructs a CFOBrushTypeControl object.
	//		Returns A  value (Object).
	CFOBrushTypeControl();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Brush Type , Destructor of class CFOBrushTypeControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBrushTypeControl();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBrushTypeControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		nDefaultType---Default Type, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bPopup---bPopup, Specifies A Boolean value.
	// Creates the shape and initializes the data members.
	virtual void Create(CWnd *pWnd,int nDefaultType,CRect &rcPos,BOOL bPopup = FALSE);
	

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data
	virtual void Serialize(CArchive &ar);
	
	// Initialize Control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial , Call InitControl after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitControl();
	
	// Adjust Cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Cells, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual void AdjustCells(CRect rcPos);
	
	// Compute Cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Cells, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ComputeCells();
	
	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	// UpdateAll
	virtual void UpdateAll();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType () const				{	return m_nCurBrushType; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void		SetBrushType(int nType);

	// Get Old Cell Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect		GetOldCellRect();
	
	// Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBrushTypeCellObj,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFOBrushTypeCellObj* HitTest(CPoint point);
	
	// Is Popup Style or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Popup Style, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPopupStyle() const		{ return m_bPopup; }
	
	// Set Popup Style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Popup Style, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&bPopup---&bPopup, Specifies A Boolean value.
	void		SetPopupStyle(const BOOL &bPopup)	{ m_bPopup = bPopup; }
	
	// Define for WM_TFC_SELECTOK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectOK(WPARAM wParam, LPARAM lParam);
	
	// Define for WM_TFC_SELECTCANCEL message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectCancel(WPARAM wParam, LPARAM lParam);
	
	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set F G Color, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetFGColor(const COLORREF &cr);

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set B K Color, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetBKColor(const COLORREF &cr);

protected:
	
	// 
 
	// Cells[ F O_ T O T A L_ B R U S H T Y P E C E L L S], This member specify E-XD++ CFOBrushTypeCellObj object.  
	CFOBrushTypeCellObj m_crCells[FO_TOTAL_BRUSHTYPECELLS];

	// Do draw gipper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Gipper, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rectGripper---rectGripper, Specifies A CRect type value.
	virtual void DoDrawGipper(CDC* pDC, CRect rectGripper);

	
public:
	// virtual void Serialize(CArchive &ar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get the pointer of file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release File.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Set wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetWnd(CWnd *pWnd)					{ m_pParent = pWnd; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	// Invalidates this gadget.
	void Invalidate(BOOL bRedraw = FALSE);
	
	// Update the given rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	void InvalRect(CRect rcPos);
	
	// Capture the mouse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Capture Mouse, .
	// Parameters:
	//		bCapture---bCapture, Specifies A Boolean value.
	void CaptureMouse(BOOL bCapture);
	
	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnRButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Panel Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetPanelRect() const						{ return m_rcPosition; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Panel Rectangle, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void  SetPanelRect(const CRect &rc)				{ m_rcPosition = rc; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Text, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void  SetCustomText(const CString &strText )	{ strCustom = strText; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Custom Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetCustomText() const				{ return strCustom; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Bar, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&bCustom---&bCustom, Specifies A Boolean value.
	void SetCustomBar(const BOOL &bCustom);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Border Size, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetMainBorderSize(const int &nBorder);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Border Size, Returns the specified value.
	//		Returns a int type value.
	int  GetMainBorderSize() const				{ return nMainBorderSize; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Border Size, Returns the specified value.
	//		Returns a int type value.
	int GetCellBorderSize() const				{ return nCellBorderSize; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Type, Sets a specify value to current class CFOBrushTypeControl
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBorderType(const UINT &nType)		{ nBorderType = nType; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetBorderType() const					{ return nBorderType; }

	//Update Custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Custom, Call this member function to update the object.

	void UpdateCustom();
public:
	
	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);
	
	// Draw Custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bHasColor---Has Color, Specifies A Boolean value.
	virtual void OnCustomDraw(CDC *pDC,BOOL bHasColor);
	
	//Draw Custom Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnCustomDrawSelect(CDC *pDC);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);

	// Draw a rectangle	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);
	
protected:
	
	// Cells rectangle
 
	// Cells, This member sets a CRect value.  
	CRect				rcCells;
	
	// Position rectangle
 
	// Position, This member sets a CRect value.  
	CRect				m_rcPosition;

	// Position of description.
 
	// Description, This member sets a CRect value.  
	CRect				m_rcDescription;
	
	// Custom rectangle
 
	// Custom, This member sets a CRect value.  
	CRect				rcCustom;
	
	// CustomSave rectangle
 
	// Custom Save, This member sets a CRect value.  
	CRect				rcCustomSave;
	
	//Current Brush Type
 
	// Current Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCurBrushType;
	
	//The Pointer to  Parent widow 
 
	// Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*				m_pParent;
	
	//Is Popup or not
 
	// Popup, This member sets TRUE if it is right.  
	BOOL				m_bPopup;
	
	// Is Custom Selected
 
	// Custom Select, This member sets TRUE if it is right.  
	BOOL				m_bCustomSelect;
	
	// Custom string 
 
	// Custom, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				strCustom;

	// Has it CustomBar or not
 
	// Has Custom Bar, This member sets TRUE if it is right.  
	BOOL				bHasCustomBar;

	// Mainimum Border Size
 
	// Main Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nMainBorderSize;

	// Cell Border Size
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nCellBorderSize;

	// Border Type
 
	// Border Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				nBorderType;

	// Rows
 
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nRows;

	// Columns
 
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCols;

};
typedef CTypedPtrList<CObList, CFOBrushTypeControl*> CFOBrushTypeControlList;

#endif // !defined(AFX_FOBRUSHTYPECONTROL_H__5B55AAC4_C753_11D5_A489_525400EA266C__INCLUDED_)
