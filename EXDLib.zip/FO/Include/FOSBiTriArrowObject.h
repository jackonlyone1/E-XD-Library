//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOSBITRIARROWOBJECT_H__23617BB6_DEF8_11D5_9467_0050BAE30439__INCLUDED_)
#define AFC_FOSBITRIARROWOBJECT_H__23617BB6_DEF8_11D5_9467_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Create Line end object.
///////////////////////////////////////

#include "FOBaseEndObject.h"

 
//===========================================================================
// Summary:
//     The CFOSBiTriArrowObject class derived from CFOBaseEndObject
//      F O S Bi Tri Arrow Object
//===========================================================================

class FO_EXT_CLASS CFOSBiTriArrowObject : public CFOBaseEndObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSBiTriArrowObject---F O S Bi Tri Arrow Object, Specifies a E-XD++ CFOSBiTriArrowObject object (Value).
	DECLARE_SERIAL(CFOSBiTriArrowObject);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O S Bi Tri Arrow Object, Constructs a CFOSBiTriArrowObject object.
	//		Returns A  value (Object).
	CFOSBiTriArrowObject();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O S Bi Tri Arrow Object, Constructs a CFOSBiTriArrowObject object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOSBiTriArrowObject& src object(Value).
	CFOSBiTriArrowObject(const CFOSBiTriArrowObject& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O S Bi Tri Arrow Object, Destructor of class CFOSBiTriArrowObject
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOSBiTriArrowObject();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOSBiTriArrowObject& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOSBiTriArrowObject& src object(Value).
	CFOSBiTriArrowObject& operator=(const CFOSBiTriArrowObject& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOBaseEndObject* Copy() const;

public:

	// Get round value of number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// More Near, .
	//		Returns a int type value.  
	// Parameters:
	//		fValue---fValue, Specifies A float value.
	int MoreNear(float fValue) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrack(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Create arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildLineEnd();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

};

#endif // !defined(AFC_FOSBITRIARROWOBJECT_H__23617BB6_DEF8_11D5_9467_0050BAE30439__INCLUDED_)
