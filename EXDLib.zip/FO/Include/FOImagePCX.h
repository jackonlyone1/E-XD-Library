//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEPCX_H__11837A6B_7A95_4829_AD41_5C56D8B79E8B__INCLUDED_)
#define AFX_FOIMAGEPCX_H__11837A6B_7A95_4829_AD41_5C56D8B79E8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImagePCX.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImagePCX window

#include "FOBitmap.h"

 
//===========================================================================
// Summary:
//     The CFOImagePCX class derived from CFOBitmap
//      F O Image P C X
//===========================================================================

class FO_EXT_CLASS CFOImagePCX : public CFOBitmap
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImagePCX---F O Image P C X, Specifies a E-XD++ CFOImagePCX object (Value).
    DECLARE_SERIAL(CFOImagePCX)
		
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image P C X, Constructs a CFOImagePCX object.
	//		Returns A  value (Object).
	CFOImagePCX();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image P C X, Destructor of class CFOImagePCX
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOImagePCX();

public:
	// Save document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    void Serialize(CArchive &ar);
	// Operations

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID, LPCTSTR pcszResourceType);

	// load icon file
	// strFileName -- file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);

};

/////////////////////////////////////////////////////////////////////////////
// CFODrawImagePCX class

 
//===========================================================================
// Summary:
//     The CFODrawImagePCX class derived from CFODrawImage
//      F O Draw Image P C X
//===========================================================================

class FO_EXT_CLASS CFODrawImagePCX : public CFODrawImage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImagePCX---F O Draw Image P C X, Specifies a E-XD++ CFODrawImagePCX object (Value).
	DECLARE_SERIAL(CFODrawImagePCX)
public:

	// Image pointer.
 
	// P C X, This member specify E-XD++ CFOImagePCX object.  
	CFOImagePCX m_imagePCX;

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap() { return &m_imagePCX; }

public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image P C X, Constructs a CFODrawImagePCX object.
	//		Returns A  value (Object).
	CFODrawImagePCX();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image P C X, Destructor of class CFODrawImagePCX
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImagePCX();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImagePCX &target object(Value).
	virtual BOOL operator==(const CFODrawImagePCX &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEPCX_H__11837A6B_7A95_4829_AD41_5C56D8B79E8B__INCLUDED_)
