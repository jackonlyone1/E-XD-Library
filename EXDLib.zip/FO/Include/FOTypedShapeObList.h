//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
//  FOTypedShapeObList.h: interface for the CFOTypedShapeObList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOTYPEDSHAPEOBLIST_H__2EEABBEC_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOTYPEDSHAPEOBLIST_H__2EEABBEC_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOCompList.h"
/////////////////////////////////////////////////////////////////////////////
// CFOTypedShapeObList< TYPE >

template< class TYPE >

///////////////////////////////////////////////////////////////////////////
// CFOTypedShapeObList -- shape object list.

 
//===========================================================================
// Summary:
//     The CFOTypedShapeObList class derived from CFOCompList
//      F O Typed Shape Ob List
//===========================================================================

class FO_EXT_CLASS CFOTypedShapeObList : public CFOCompList
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Typed Shape Ob List, Constructs a CFOTypedShapeObList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nBlockSize---Block Size, Specifies A integer value.
	CFOTypedShapeObList(int nBlockSize = 10) : CFOCompList(nBlockSize)
	{}
	
	// peek at head or tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns A TYPE& value (Object).
	TYPE& GetHead()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns A TYPE value (Object).
	{ return (TYPE&)CFOCompList::GetHead(); }

	TYPE GetHead() const
	{ return (TYPE)CFOCompList::GetHead(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns A TYPE& value (Object).
	TYPE& GetTail()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns A TYPE value (Object).
	{ return (TYPE&)CFOCompList::GetTail(); }

	TYPE GetTail() const
	{ return (TYPE)CFOCompList::GetTail(); }
	
	// get head or tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns A TYPE value (Object).
	TYPE RemoveHead()
	{ return (TYPE)CFOCompList::RemoveHead(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns A TYPE value (Object).
	TYPE RemoveTail()
	{ return (TYPE)CFOCompList::RemoveTail(); }
	
	// add before head or after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pNewOb---New Ob, Specifies a TYPE pNewOb object(Value).
	POSITION AddHead(TYPE pNewOb)
	{ return CFOCompList::AddHead(pNewOb); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pNewOb---New Ob, Specifies a TYPE pNewOb object(Value).
	POSITION AddTail(TYPE pNewOb)
	{ return CFOCompList::AddTail(pNewOb); }
	
	// add another list of elements before head or after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOTypedShapeObList< TYPE > or NULL if the call failed.
	void AddHead(CFOTypedShapeObList< TYPE >* pNewList)
	{ CFOCompList::AddHead(pNewList); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOTypedShapeObList< TYPE > or NULL if the call failed.
	void AddTail(CFOTypedShapeObList< TYPE >* pNewList)
	{ CFOCompList::AddTail(pNewList); }
	
	// iteration
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns A TYPE& value (Object).  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	TYPE& GetNext(POSITION& rPosition)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns A TYPE value (Object).  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	{ return (TYPE&)CFOCompList::GetNext(rPosition); }

	TYPE GetNext(POSITION& rPosition) const
	{ return (TYPE)CFOCompList::GetNext(rPosition); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns A TYPE& value (Object).  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	TYPE& GetPrev(POSITION& rPosition)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns A TYPE value (Object).  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	{ return (TYPE&)CFOCompList::GetPrev(rPosition); }

	TYPE GetPrev(POSITION& rPosition) const
	{ return (TYPE)CFOCompList::GetPrev(rPosition); }
	
	// getting/modifying an element at a given position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns A TYPE& value (Object).  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	TYPE& GetAt(POSITION position)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns A TYPE value (Object).  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	{ return (TYPE&)CFOCompList::GetAt(position); }

	TYPE GetAt(POSITION position) const
	{ return (TYPE)CFOCompList::GetAt(position); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At, Sets a specify value to current class CFOTypedShapeObList
	// Parameters:
	//		pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		pNewOb---New Ob, Specifies a TYPE pNewOb object(Value).
	void SetAt(POSITION pos, TYPE pNewOb)
	{ CFOCompList::SetAt(pos, pNewOb); }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// Parameters:
	//		pFirstComp---First Component, A pointer to the int( or NULL if the call failed.  
	//		pSecondComp)---Second Comp), Specifies a TYPE pSecondComp) object(Value).
	void Sort(int(*CompareFunc)(TYPE pFirstComp, TYPE pSecondComp) )
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// Parameters:
	//		posStart---posStart, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		nElements---nElements, Specifies A integer value.  
	//		pFirstComp---First Component, A pointer to the int( or NULL if the call failed.  
	//		pSecondComp)---Second Comp), Specifies a TYPE pSecondComp) object(Value).
	{ CFOCompList::Sort((int(*)(CRefObject*, CRefObject*))CompareFunc); }

	void Sort(POSITION posStart, int nElements, int(*CompareFunc)(TYPE pFirstComp, TYPE pSecondComp) )
	{ CFOCompList::Sort(posStart, nElements, (int(*)(CRefObject*, CRefObject*))CompareFunc); }

};

#endif // !defined(AFX_FOTypedShapeObList_H__2EEABBEC_F19E_11DD_A432_525400EA266C__INCLUDED_)
