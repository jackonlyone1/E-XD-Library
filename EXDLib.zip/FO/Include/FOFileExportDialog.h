//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOFileExportDialog.h: interface for the CFOFileExportDialog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOFILEEXPORTDIALOG_H__7BB50713_F4AC_11DD_A439_525400EA266C__INCLUDED_)
#define AFX_FOFILEEXPORTDIALOG_H__7BB50713_F4AC_11DD_A439_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 
//===========================================================================
// Summary:
//     The CFOFileExportDialog class derived from CFileDialog
//      F O File Export Dialog
//===========================================================================

class FO_EXT_CLASS CFOFileExportDialog : public CFileDialog
{
 
	// This member specify typedef CFileDialog object.  
	typedef CFileDialog base;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFileExportDialog---F O File Export Dialog, Specifies a E-XD++ CFOFileExportDialog object (Value).
	DECLARE_DYNAMIC(CFOFileExportDialog)
		
		//access Public Member Functions and Variables
public:
	
	// constructor, creates dialog title and filter buffers
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O File Export Dialog, Constructs a CFOFileExportDialog object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&title---Specifies A CString type value.  
	//		&filter---Specifies A CString type value.  
	//		&fileName---&fileName, Specifies A CString type value.
	CFOFileExportDialog(const CString &title, const CString &filter, const CString &fileName = _T(""));
	
	// destructor, destroys dialog title and filter buffers
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O File Export Dialog, Destructor of class CFOFileExportDialog
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFileExportDialog();
	
	// return current filter index (useful if two file formats have same extension)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filter Index, Returns the specified value.
	//		Returns a int type value.
	int GetFilterIndex() const		{ return m_CurrentFilterIndex; }
	
	//access Protected Member Functions and Variables
protected:
	
	//cmember
	// called when user selects other filetype, changes extension
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Type Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTypeChange();
	
	//{{AFX_MSG(CFOFileExportDialog)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
	//access Private Member Functions and Variables
private:
	
	//contains title string
 
	// Title Buffer, This member maintains a pointer to the object TCHAR.  
	TCHAR *m_pTitleBuffer;     

	//contains filter string
 
	// Filter Buffer, This member maintains a pointer to the object TCHAR.  
	TCHAR *m_pFilterBuffer;     
	
	//contains filename string
 
	// File Buffer, This member maintains a pointer to the object TCHAR.  
	TCHAR *m_pFileBuffer;       
	
	//current file type
 
	// Current Filter Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int   m_CurrentFilterIndex;  
	
};

#ifdef _WIN64
typedef INT_PTR XFOP_INT, *XFOP_PINT;
typedef UINT_PTR XFOP_UINT, *XFOP_PUINT;
#else	//WIN32
typedef int XFOP_INT, *XFOP_PINT;
typedef unsigned int XFOP_UINT, *XFOP_PUINT;
#endif	//_WIN64

///////////////////////////////////////////////////////////////////////////////
//

class CFOPCanvasCore;
class FO_EXT_CLASS CFOPFindReplaceDlg : public CDialog
{
public:
	enum CFOPFindReplaceAction
	{
		fopxIsTerminating,	
		fopxFindNext,			
		fopxMarkAll,			
		fopxReplaceCurrent,
		fopxReplaceAll		
	} m_Action;

public:
	CFOPFindReplaceDlg(); 

#ifdef _DEBUG
	virtual void AssertValid() const;
#endif
	CString GetFindString() const;
	CString GetReplaceString() const;
	BOOL MarkAll() const;
	BOOL MatchCase() const;
	BOOL MatchFull() const;
	int FindPropID() const;
	BOOL FindNext()const;
	BOOL ReplaceAll() const;
	BOOL ReplaceCurrent() const;
	BOOL ReplaceSelOnly();
	BOOL SearchDown() const;
	BOOL IsTerminating() const;
	void EnableReplaceSelOnly();
	void SetFindString(LPCTSTR lpszFindWhat);
	void SetMatchCase(BOOL bMatchCase);
	void SetMatchFull(BOOL bMatchFull);
	void SetFindPropID(int nProp);
	void SetReplaceSelOnly(BOOL bEnable);
	void SetReplaceString(LPCTSTR lpszReplaceWith);
	void SetSearchDown(BOOL bSearchDown);

protected:
	virtual void UpdateRegExpParams();
	virtual void UpdateStringLists();
	virtual void UpdateCombos();
	virtual BOOL EnableFindButton();


public:

	//{{AFX_DATA(CFOPFindReplaceDlg)
	enum { IDD = IDD_XFOP_REPLACE_DLG };
	CComboBox	m_cboReplaceWith;
	CComboBox	m_cboFindWhat;
	CString	m_strComboFindWhat;
	CString	m_strComboReplaceWith;
	BOOL	m_bMatchCase;
	BOOL	m_bMatchFull;
	BOOL	m_bRegExp;
	int		m_nRadioButton;
	CComboBox	m_Combo;
	int		m_nPropID;
	int		m_nSel;
	//}}AFX_DATA
	BOOL m_bBeFind;
	BOOL m_bWithReg;
	CFOPCanvasCore* m_pNotify;
	CStringList* m_pFindList;
	CStringList* m_pReplaceList;
	CMenu m_RegExpMenu;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPFindReplaceDlg)
	public:
	virtual XFOP_INT DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation

protected:
	BOOL m_bModal;
	BOOL m_bEnableReplaceSelOnly;

	// Generated message map functions
	//{{AFX_MSG(CFOPFindReplaceDlg)
	afx_msg void OnEditChangeComboFindWhat();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelChangeComboFindWhat();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnReplace();
	afx_msg void OnReplaceAll();
	afx_msg void OnMarkAll();
	afx_msg void OnReplaceSelOnly();
	afx_msg void OnReplaceInWholeFile();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnRegExp();
	afx_msg void OnSelchangeFoComboType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//

class FO_EXT_CLASS CFOPFindRepData : public CNoTrackObject
{
public:
	CFOPFindRepData();
	virtual ~CFOPFindRepData();
	CFOPFindReplaceDlg* m_pDlg; 
	BOOL m_bBeFind;
	CString m_strFind;
	CString m_strReplace;
	BOOL m_bMatchCase;
	BOOL m_bSearchDown;
	BOOL m_bMatchFull;
	BOOL m_bReplaceSelOnly;
	BOOL m_bRegExp;
	BOOL m_bWithReg;
	int m_nFindPropID;
	CStringList m_arSaveFind;
	CStringList m_arSaveReplace;
	CFOPCanvasCore* m_pCanvas;
};

class FOPIRegExp;

// CFOPRegExp.h
class FO_EXT_CLASS CFOPRegExp
{
public:
	CFOPRegExp();
	virtual ~CFOPRegExp();
	
	// ICFOPRegExp methods
	// Creation/ Initialization
	virtual BOOL DoInit();
	
	// Attributes
	virtual CString GetData() const;
	virtual void SetData(LPCTSTR lpszPattern);
	
	virtual BOOL GetNoCase() const;
	virtual void SetNoCase(BOOL bIgnoreCase);
	virtual BOOL CanNoCase() const;
	
	// Operations
	virtual BOOL GetMatch(LPCTSTR lpszSearch, int& nStart, int& nLength);
	virtual BOOL GetMatch(LPCTSTR lpszSearch, int& nStart, int& nLength, CString& strMatch);
	virtual BOOL Replace(CString& strSource, LPCTSTR lpszReplaceWith, BOOL bReplaceAll);
	
protected:
	FOPIRegExp* m_pRegExp;
};

#endif // !defined(AFX_FOFILEEXPORTDIALOG_H__7BB50713_F4AC_11DD_A439_525400EA266C__INCLUDED_)
