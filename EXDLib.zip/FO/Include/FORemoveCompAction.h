//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FORemoveCompAction.h: interface for the CFORemoveCompAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOREMOVECOMPACTION_H__2EEABBFD_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOREMOVECOMPACTION_H__2EEABBFD_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
#include "FODrawPortsShape.h"

class CFOCompositeShape;

//////////////////////////////////////////////////////////////////////////////////
// CFORemoveCompAction -- action that remove component from canvas.

 
//===========================================================================
// Summary:
//     The CFORemoveCompAction class derived from CFOAction
//      F O Remove Component Action
//===========================================================================

class FO_EXT_CLASS CFORemoveCompAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemoveCompAction---F O Remove Component Action, Specifies a E-XD++ CFORemoveCompAction object (Value).
	DECLARE_ACTION(CFORemoveCompAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Component Action, Constructs a CFORemoveCompAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFORemoveCompAction(CFODataModel* pModel, CFODrawShape* pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Component Action, Destructor of class CFORemoveCompAction
	//		Returns A  value (Object).
	~CFORemoveCompAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORemoveCompAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFORemoveCompAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Obtain index within list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index Within, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pCompList---Component List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	int GetIndexWithin(CFODrawShape *pShape, CFODrawShapeSet* pCompList);

	// Obtain index within list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index Within, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pCompList---Component List, A pointer to the CFODrawShapeList or NULL if the call failed.
	int GetIndexWithin(CFODrawShape *pShape, CFODrawShapeList* pCompList);


	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Attributes
protected:

	// The pointer of shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape* m_pShape;

	// Current index within.
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nIndex;

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORemoveCompAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFORemoveCompAction::GetShape()
{
	return m_pShape;
}

//////////////////////////////////////////////////////////////////////////////////
// CFORemovePortAction -- action that remove port from canvas.

 
//===========================================================================
// Summary:
//     The CFORemovePortAction class derived from CFOAction
//      F O Remove Port Action
//===========================================================================

class FO_EXT_CLASS CFORemovePortAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORemovePortAction---F O Remove Port Action, Specifies a E-XD++ CFORemovePortAction object (Value).
	DECLARE_ACTION(CFORemovePortAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Remove Port Action, Constructs a CFORemovePortAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFOPortShape or NULL if the call failed.
	CFORemovePortAction(CFODataModel* pModel, CFOPortShape* pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Remove Port Action, Destructor of class CFORemovePortAction
	//		Returns A  value (Object).
	~CFORemovePortAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORemovePortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetShape(CFOPortShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetShape();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed
	CFODrawPortsShape *GetCompShape() { return m_pPortsShape; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFORemovePortAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	virtual void SetCompShape(CFODrawPortsShape *pComp) { m_pPortsShape = pComp; }

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Attributes
protected:

	// The pointer of shape
 
	// Shape, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape* m_pShape;

	// member variable,a pointer to the composite shape.
 
	// Ports Shape, This member maintains a pointer to the object CFODrawPortsShape.  
	CFODrawPortsShape *m_pPortsShape;
    
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORemovePortAction::SetShape(CFOPortShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFOPortShape *CFORemovePortAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOREMOVECOMPACTION_H__2EEABBFD_F19E_11DD_A432_525400EA266C__INCLUDED_)
