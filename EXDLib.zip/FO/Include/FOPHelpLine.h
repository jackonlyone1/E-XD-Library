//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPHELPLINE_H__01284B1A_80C5_4B31_9EB0_5FFAA917CCD3__INCLUDED_)
#define AFX_FOPHELPLINE_H__01284B1A_80C5_4B31_9EB0_5FFAA917CCD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPHelpLine.h : header file
//

#include "FOPCollect.h"

enum FOP_LINEKIND
{
	FOP_LINE_POINT,
	FOP_LINE_VERTICAL,
	FOP_LINE_HORIZONTAL
};
#define FOP_LINE_MIN FOP_LINE_POINT
#define FOP_LINE_MAX FOP_LINE_HORIZONTAL

#define FOP_LINE_POINT_PIXELSIZE 15 /* PIXELSIZE*2+1 */

/////////////////////////////////////////////////////////////////////////////
// CFOPHelpLine object
//
// This class is the snap line object, snap lines are the lines drawing on the background
// of the canvas,you can drag and move them.
//
// When we creating new shape, moving shape, sizing shape, you can snap the point.
//

 
//===========================================================================
// Summary:
//     The CFOPHelpLine class derived from CObject
//      F O P Help Line
//===========================================================================

class FO_EXT_CLASS CFOPHelpLine : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHelpLine---F O P Help Line, Specifies a E-XD++ CFOPHelpLine object (Value).
	DECLARE_SERIAL(CFOPHelpLine);

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Help Line, Constructs a CFOPHelpLine object.
	//		Returns A  value (Object).
	CFOPHelpLine();

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Help Line, Constructs a CFOPHelpLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nNewKind---New Kind, Specifies a FOP_LINEKIND nNewKind object(Value).
	CFOPHelpLine(FOP_LINEKIND nNewKind);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Help Line, Constructs a CFOPHelpLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nNewKind---New Kind, Specifies a FOP_LINEKIND nNewKind object(Value).  
	//		rcNewPos---New Position, Specifies A CPoint type value.
	CFOPHelpLine(FOP_LINEKIND nNewKind, const CPoint& rcNewPos);

	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Help Line, Constructs a CFOPHelpLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPHelpLine& source object(Value).
	CFOPHelpLine(const CFOPHelpLine& source);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPHelpLine& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPHelpLine& source object(Value).
	CFOPHelpLine& operator=(const CFOPHelpLine& source);

	// == operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPHelpLine& aCmp object(Value).
	BOOL operator==(const CFOPHelpLine& aCmp) const
	{
		return m_ptPos == aCmp.m_ptPos && m_eKind == aCmp.m_eKind && 
			m_bLock == aCmp.m_bLock;
	}

	// != operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPHelpLine& aCmp object(Value).
	BOOL operator!=(const CFOPHelpLine& aCmp) const
	{
		return !operator == (aCmp);
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHelpLine,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPHelpLine* Copy() const;

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Help Line, Destructor of class CFOPHelpLine
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHelpLine();
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&szHorz---&szHorz, Specifies A CSize type value.  
	//		&szVert---&szVert, Specifies A CSize type value.
	// Draw the object.
	// pDC -- pointer of DC.
	// szHorz -- horz size.
	// szVert -- vertical size.
	virtual void Draw(CDC *pDC,const CSize &szHorz,const CSize &szVert);

	// Change the line kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Kind, Sets a specify value to current class CFOPHelpLine
	// Parameters:
	//		eNewKind---New Kind, Specifies a FOP_LINEKIND eNewKind object(Value).
	void SetKind(FOP_LINEKIND eNewKind)	{	m_eKind = eNewKind;	}

	// Get line kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Kind, Returns the specified value.
	//		Returns A FOP_LINEKIND value (Object).
	FOP_LINEKIND GetKind() const	{	return m_eKind;	}

	// Change line position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPHelpLine
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.
	void SetPos(const CPoint& rPnt)	{	m_ptPos = rPnt;	}

	// Get line position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns a CPoint type value.
	const CPoint& GetPos() const	{	return m_ptPos;	}

	// Is lock or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLock() const { return m_bLock; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock, .

	// Lock help line.
	void Lock() { m_bLock = TRUE; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Un Lock, .

	// Unlock help line.
	void UnLock() { m_bLock = FALSE; }

	// Hit test the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hit, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.  
	//		nTolLog---Tol Logical, Specifies A integer value.
	BOOL IsHit(const CPoint& rPnt, int nTolLog) const;

	// Get bound rectangle of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		&ptOrg---&ptOrg, Specifies A CPoint type value.  
	//		&szView---&szView, Specifies A CSize type value.
	CRect GetBoundRect(const CPoint &ptOrg,const CSize &szView) const;

	// Is visible equal
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Visible Equal, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rHelpLine---Help Line, Specifies a const CFOPHelpLine& rHelpLine object(Value).
	BOOL IsVisibleEqual(const CFOPHelpLine& rHelpLine) const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Position of line.
 
	// Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPos;

	// Lock or unlock.
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// Line style
 
	// Kind, This member specify FOP_LINEKIND object.  
	FOP_LINEKIND	m_eKind;

};


///////////////////////////////////////////////////////////////////////////////
// CFOPHelpLineSet -- container that stored all the help line object.

 
//===========================================================================
// Summary:
//     The CFOPHelpLineSet class derived from FOPContainer
//      F O P Help Line Set
//===========================================================================

class FO_EXT_CLASS CFOPHelpLineSet : public FOPContainer
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Help Line Set, Constructs a CFOPHelpLineSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFOPHelpLineSet(int nInit = 16, int nTotal = 16) : FOPContainer(1024, nInit, nTotal)	{}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Help Line Set, Destructor of class CFOPHelpLineSet
	//		Returns A  value (Object).
    ~CFOPHelpLineSet();

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddHead(CObject* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddTail(CObject* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOPHelpLineSet or NULL if the call failed.
	void AddHead(CFOPHelpLineSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOPHelpLineSet or NULL if the call failed.
	void AddTail(CFOPHelpLineSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();
};

// List of help line object.
typedef CTypedPtrList<CObList, CFOPHelpLine*> CFOPHelpLineList;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPHELPLINE_H__01284B1A_80C5_4B31_9EB0_5FFAA917CCD3__INCLUDED_)
