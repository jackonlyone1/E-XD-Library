//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPSHADOWPICKERDRAWPANEL_H__317F8296_D264_4386_9F91_B8F9BCA6B92A__INCLUDED_)
#define AFX_FOPSHADOWPICKERDRAWPANEL_H__317F8296_D264_4386_9F91_B8F9BCA6B92A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPShadowPickerDrawPanel.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// FOPShadowPickerDrawPanel window
#include "FOPDrawControlPanel.h"

const unsigned FOP_MSG__SHADOWPICKER_CHANGE		= 1;
const unsigned FOP_MSG__SHADOWPICKER_CYCLE		= 2;
const unsigned FOP_MSG__SHADOWPICKER_NONE		= 3;
const unsigned FOP_MSG__SHADOWPICKER_CUSTOM		= 4;
const unsigned FOP_MSG__SHADOWPICKER_CANCEL		= 5;
const unsigned FOP_MSG__SHADOWPICKER_BUTTON2	= 6;

// Shadow picker table entry.
struct FOPShadowPickerTableEntry 
{
	// shadow value.
    int			nShadowPicker;

	// shadow name.
    LPCTSTR		szName;
};

 
//===========================================================================
// Summary:
//     The FOPShadowPickerDrawPanel class derived from FOPDrawControlPanel
//      O P Shadow Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPShadowPickerDrawPanel : public FOPDrawControlPanel
{
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Shadow Picker Draw Panel, Constructs a FOPShadowPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
					FOPShadowPickerDrawPanel(HasHeaderBar ind = HeaderBarOne, 
						HasButton but = ButtonOne);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Shadow Picker Draw Panel, Destructor of class FOPShadowPickerDrawPanel
	//		Returns A  value (Object).
					~FOPShadowPickerDrawPanel();

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	const CString	GetMainGroupName(int iIndex);

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	const CString	GetExtraGroupName(int iIndex);

	// Draw main group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		iIndex---iIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawMainGroupFace(CDC& dc, CRect& rc, int iIndex, BOOL  enabled);

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		iIndex---iIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawExtraGroupFace(CDC& dc, CRect& rc, int iIndex, BOOL  enabled);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		iIndex---iIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		enabled---Specifies A Boolean value.
	// Do draw mode
	virtual void	Draw(CDC& DC, const CRect& rect, int iIndex, BOOL  transparent = FALSE, 
		BOOL  focus = FALSE, BOOL  enabled = TRUE);

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup);

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int iIndex, BOOL  IsPopup);

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int iIndex, BOOL  IsPopup);

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int iIndex, BOOL  IsPopup);

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int iIndex, BOOL  IsPopup);

	// Is main group enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	virtual BOOL 	IsMainGroupEnabled(int iIndex);

	// Get transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetTransparency()			{	return m_bTransparent;	}

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPShadowPickerDrawPanel
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void			SetTransparency(BOOL  bTransparent)	{	m_bTransparent = bTransparent;	}

	// Get pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
	int				GetPenWidth() const 		{		return m_nPenWidth;	}	

	// Set pen width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPShadowPickerDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetPenWidth(int nWidth)			{		m_nPenWidth = nWidth;		}


	// assessor functions
	//Get shadows.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Pickers, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		iIndex---iIndex, Specifies A integer value.
	const int&		GetShadowPickers(int iIndex) const	{	return ShadowPickers[iIndex].nShadowPicker;	}

	// Get shadow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Picker, Returns the specified value.
	//		Returns a int type value.
	int				GetShadowPicker();

	// Get fill color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetFillColor() const;

	// Set shadow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Picker, Sets a specify value to current class FOPShadowPickerDrawPanel
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			SetShadowPicker(const int& nWidth);

	// Set headerbar state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPShadowPickerDrawPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	void			SetHeaderBarState(HasHeaderBar ind);

	// Set sunken draw mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPShadowPickerDrawPanel
	// Parameters:
	//		bSunken---bSunken, Specifies A Boolean value.
	void			SetSunkenMode(BOOL  bSunken);

	// response functions
	// Do when shadow change action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Shadow Picker Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void	DoWellShadowPickerChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choose custom shadow button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Shadow Picker, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomShadowPicker();

	// Do when choose none shadow button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Shadow Picker None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellShadowPickerNone();

	// None shadow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Picker None, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.
	static const int	GetShadowPickerNone()		{	return (int) 0; }

	// Total number of shadow.
	enum { DefaultShadowOfPickers = 4};

protected:

	// Total number of shadow.
 
	// Shadow Picker, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nShadowPicker;

	// shadows.
 
	// Shadow Pickers, This member maintains a pointer to the object FOPShadowPickerTableEntry.  
	FOPShadowPickerTableEntry*		ShadowPickers;

	// Default shadows.
 
	// Shadow Pickers[ Default Shadow Of Pickers], This member specify FOPShadowPickerTableEntry object.  
	static FOPShadowPickerTableEntry	arShadowPickers[DefaultShadowOfPickers];

	// Transparent.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 							m_bTransparent;

	// Pen width.
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nPenWidth;
};

// DDX
void DDX_ShadowPickerWell(CDataExchange* pDX, FOPShadowPickerDrawPanel& w, int& nWidth);

struct FOPDropShadowPickerCallback
{
	// Do when shadow change
	virtual void	OnWellShadowPickerChange(const int& nWidth) = 0;

	// Do when cancel action.
	virtual void	OnWellCancel() = 0;

	// Do when choose custom shadow button action.
	virtual void	OnWellCustomShadowPicker() = 0;

	// Do when choose none shadow action.
	virtual void	OnWellShadowPickerNone() = 0;
};

 
//===========================================================================
// Summary:
//     The FOPDropShadowPickerDrawPanel class derived from FOPShadowPickerDrawPanel
//      O P Drop Shadow Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPDropShadowPickerDrawPanel : public FOPShadowPickerDrawPanel
{
protected:
	// Call back
 
	// This member maintains a pointer to the object FOPDropShadowPickerCallback.  
	FOPDropShadowPickerCallback* Button;
public:
	// response functions
	// Do when shadow change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Shadow Picker Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void DoWellShadowPickerChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCancel();

	// Do when choose custom shadow button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Shadow Picker, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCustomShadowPicker();

	// Do when choose none shadow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Shadow Picker None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellShadowPickerNone();

	// Set call back
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPDropShadowPickerDrawPanel
	// Parameters:
	//		button---A pointer to the FOPDropShadowPickerCallback or NULL if the call failed.
	void SetButton(FOPDropShadowPickerCallback* button)	{	Button = button;	}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Shadow Picker Draw Panel, Constructs a FOPDropShadowPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).  
	//		btn---A pointer to the FOPDropShadowPickerCallback or NULL if the call failed.
	FOPDropShadowPickerDrawPanel(HasHeaderBar ind = HeaderBarOne,
		HasButton but = ButtonOne, FOPDropShadowPickerCallback* btn = 0);

};
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPSHADOWPICKERDRAWPANEL_H__317F8296_D264_4386_9F91_B8F9BCA6B92A__INCLUDED_)
