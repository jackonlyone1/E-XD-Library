//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPUTIL_H__552B6457_FF85_4CDA_AD87_59DF7F79A9E1__INCLUDED_)
#define AFX_FOPUTIL_H__552B6457_FF85_4CDA_AD87_59DF7F79A9E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPUtil.h : header file
//
#include "FOPFraction.h"
#include "FODefines.h"
#pragma warning(disable: 4244)
#pragma warning(disable: 4101)
#pragma warning(disable: 4172)
#pragma warning(disable: 4189)
#pragma warning(disable: 4786)
#include <vector>
#pragma warning(disable: 4244)
#pragma warning(disable: 4101)
#pragma warning(disable: 4172)
#pragma warning(disable: 4189)
#pragma warning(disable: 4786)
/////////////////////////////////////////////////////////////////////////////
// FOPUtil window

typedef unsigned short			USHORT;
typedef unsigned long			ULONG;
typedef short					INT16;
typedef unsigned short			UINT16;

#include <math.h>

/////////////////////////////////////////////////////////////////////////////////
//
// FOXvec3 -- spline generator.
/////////////////////////////////////////////////////////////////////////////////

class FO_EXT_CLASS FOXvec3
{
public:
	
    // Constructors
    FOXvec3() : x(0), y(0), z(0)
	{}
	
	FOXvec3(float vx, float vy, float vz)
	{
		x = vx;
		y = vy;
		z = vz;
	}
	
	FOXvec3(const FOXvec3& v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
	}
	
	// Destructor
	~FOXvec3() {}
	
	// A minimal set of vector operations
	FOXvec3 operator * (float mult) const // result = this * arg
	{
		return FOXvec3(x * mult, y * mult, z * mult);
	}
	
	FOXvec3 operator + (const FOXvec3& v) const // result = this + arg
	{
		return FOXvec3(x + v.x, y + v.y, z + v.z);
	}
	
	FOXvec3 operator - (const FOXvec3& v) const // result = this - arg
	{
		return FOXvec3(x - v.x, y - v.y, z - v.z);
	}
	
	float x, y, z;
};

// Define float.


typedef struct tagFOFLOAT
{
    double x;
    double y;
} FOFLOAT, *PFOFLOAT, NEAR *NPFOFLOAT, FAR *LPFOFLOAT;

class FOPPoint;
class FO_EXT_CLASS FOPFloat : public tagFOFLOAT
{
public:
    // Constructors
    FOPFloat()
	{
		x = 0;
		y = 0;
	}

	
	FOPFloat(double vx, double vy)
	{
		x = vx;
		y = vy;
	}

	FOPFloat(FOFLOAT initPt)
	{
		x = initPt.x;
		y = initPt.y;
	}
	
	FOPFloat(const FOPFloat& v)
	{
		x = v.x;
		y = v.y;
	}

	FOPFloat(const CPoint& v)
	{
		x = (double)v.x;
		y = (double)v.y;
	}
	
	// Destructor
	~FOPFloat() {}

	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A 32-bit long signed integer.
	double X() const		{	return x;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A 32-bit long signed integer.
	double Y() const		{	return y;	}
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A 32-bit long signed integer.
	double& X()			{	return x;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A 32-bit long signed integer.
	double& Y()			{	return y;	}

	
	// A minimal set of vector operations
	FOPFloat operator * (double mult) const // result = this * arg
	{
		return FOPFloat(x * mult, y * mult);
	}
	
	// Operator +
	FOPFloat operator + (const FOPFloat& v) const // result = this + arg
	{
		return FOPFloat(x + v.x, y + v.y);
	}

	// Operator +
	FOPFloat operator + (const FOFLOAT& v) const // result = this + arg
	{
		return FOPFloat(x + v.x, y + v.y);
	}
	
	// Operator -
	FOPFloat operator - (const FOPFloat& v) const // result = this - arg
	{
		return FOPFloat(x - v.x, y - v.y);
	}

	// Operator -
	FOPFloat operator - (const FOFLOAT& v) const // result = this - arg
	{
		return FOPFloat(x - v.x, y - v.y);
	}

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nVal---nVal, Specifies A integer value.
	FOPFloat& operator /=(const double &nVal);
	BOOL operator==(POINT point) const;
	BOOL operator!=(POINT point) const;

	// Operator ==
	BOOL operator ==(const FOPFloat& fPt) const;
	BOOL operator !=(const FOPFloat& fPt) const;

	// Operator
	BOOL operator ==(const FOFLOAT& fPt) const;
	BOOL operator !=(const FOFLOAT& fPt) const;
	void operator+=(POINT point);
	void operator-=(POINT point);
	// Operator =
//	FOPFloat& operator=(const FOPFloat& pt);
	FOPFloat& operator=(const POINT& pt);
	FOPFloat& operator=(const FOFLOAT& pt);

	// Operators.
	inline void set(double vx, double vy) 
	{
        x = vx;
        y = vy;
      
    }

	// Set polar line.
    void setPolar(double radius, double angle);
	
	// Get 2d
    FOPFloat get2D() const 
	{
        return FOPFloat(x,y);
    }
	
	// Is valid or not
    bool isValid() const;

	// Obtain distance to.
	double getDistanceTo(const FOPFloat& v) const;

	// Obtain distance to 2d
    double getDistanceTo2d(const FOPFloat& v) const;

	// Change angle.
    void setAngle(double a);

	// Obtain angle
    double getAngle() const;

	// Obtain angle to plane x and y
    double getAngleToPlaneXY() const;

	// Obtain angle to
    double getAngleTo(const FOPFloat& v) const;

	// change magnitude 2d
    void setMagnitude2d(double m);

	// Obtain magnitude 2d
    double getMagnitude() const;

	// Obtain squared magnitude.
    double getSquaredMagnitude() const;

	// Obtain magnitude 2d
    double getMagnitude2d() const;

	// Obtain lerp
    FOPFloat getLerp(const FOPFloat& v, double t) const;

	// Obtain unit vector
    FOPFloat getUnitVector() const;

	// Change x
    void setX(double x);

	// Obtain x
    double getX();

	// Change y
    void setY(double y);

	// Obtain y
    double getY();

	// Move
    FOPFloat move(const FOPFloat& offset);

	// Rotate.
	FOPFloat rotate(double rotation);

	// Rotate
    FOPFloat rotate(double rotation, const FOPFloat& center);

	// Scale
	FOPFloat scale(double factor, const FOPFloat& center=FOPFloat(0, 0));

	// Scale
    FOPFloat scale(const FOPFloat& factors, const FOPFloat& center=FOPFloat(0, 0));

	void Scale(double dblRatioX, double dblRatioY,  const FOPFloat& ptOffset = FOPFloat())
	{
		x = ptOffset.x + (x - ptOffset.x) * dblRatioX;
		y = ptOffset.y + (y - ptOffset.y) * dblRatioY;
		
	}
	void Reflection(const FOPFloat& pt)
	{
		x = 2.0 * pt.x - x;
		y = 2.0 * pt.y - y;
		
	}
	// Obtain negated
	FOPFloat getNegated() const;
	
	// Normalize
    FOPFloat normalize();

	// Obtain normalized
    FOPFloat getNormalized() const;

	// Obtain get floor.
	FOPFloat getFloor() const;

	// Obtain ceil
    FOPFloat getCeil() const;

	// Obtain minimize
	static FOPFloat getMinimum(const FOPFloat& v1, const FOPFloat& v2);

	// Obtain maximize.
    static FOPFloat getMaximum(const FOPFloat& v1, const FOPFloat& v2);

	// Equals fuzzy
	bool equalsFuzzy(const FOPFloat& v, double tol = 2) const;

	// Obtain the average.
    static FOPFloat getAverage(const FOPFloat& v1, const FOPFloat& v2);

	// Obtain dot product.
    static double getDotProduct(const FOPFloat& v1, const FOPFloat& v2);

	// Create polar line.
    static FOPFloat createPolar(double radius, double angle) 
	{
        FOPFloat ret;
        ret.setPolar(radius, angle);
        return ret;
    }
	
	// Less than x
    static bool lessThanX(const FOPFloat& v1, const FOPFloat& v2) 
	{
        return v1.x < v2.x;
    }
	
	// Greater than x.
    static bool greaterThanX(const FOPFloat& v1, const FOPFloat& v2) 
	{
        return v1.x > v2.x;
    }
	
	// Less than y
    static bool lessThanY(const FOPFloat& v1, const FOPFloat& v2) 
	{
        return v1.y < v2.y;
    }
	
	// Greater than y.
    static bool greaterThanY(const FOPFloat& v1, const FOPFloat& v2) 
	{
        return v1.y > v2.y;
    }

	// Obtain the closet indexes.
	int getClosestIndex(const CArray<FOPFloat, FOPFloat>& list) const;

	// Obtain the closet distance points.
	double getClosestDistance(const CArray<FOPFloat, FOPFloat>& list, int counts);

	// Obtain the closet points.
	FOPFloat getClosest(const CArray<FOPFloat, FOPFloat>& list) const;
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPFloat& operator +=(const FOPFloat& ptPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPFloat& operator -=(const FOPFloat& ptPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPFloat& operator +=(const FOFLOAT& ptPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPFloat& operator -=(const FOFLOAT& ptPoint);
	
	FOPFloat operator+(POINT point) const;

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
//	friend _FOLIB_INLINE FOPFloat operator*(const FOPFloat& value1, const int &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
//	friend _FOLIB_INLINE FOPFloat operator*(const int &nVal2, const FOPFloat& value1);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
//	friend _FOLIB_INLINE FOPFloat operator/(const FOPFloat& value1, const int &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
//	friend _FOLIB_INLINE FOPFloat operator*(const FOPFloat& value1, const double &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
//	friend _FOLIB_INLINE FOPFloat operator*(const double &nVal2, const FOPFloat& value1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
//	friend _FOLIB_INLINE FOPFloat operator/(const FOPFloat& value1, const double &nVal2);

	
};

_FOLIB_INLINE BOOL FOPFloat::operator ==(const FOPFloat& fPt) const
{
	return ((x == fPt.x) && (y == fPt.y));
}

_FOLIB_INLINE BOOL FOPFloat::operator !=(const FOPFloat& fPt) const
{
	return ((x != fPt.x) || (y != fPt.y));
}

_FOLIB_INLINE BOOL FOPFloat::operator ==(const FOFLOAT& fPt) const
{
	return ((x == fPt.x) && (y == fPt.y));
}

_FOLIB_INLINE BOOL FOPFloat::operator !=(const FOFLOAT& fPt) const
{
	return ((x != fPt.x) || (y != fPt.y));
}

/////////////////////////////////////////////////////////////////////////////////

_FOLIB_INLINE FOPFloat operator*(const FOPFloat& value1, const int &nVal2)
{
	return FOPFloat(value1.x * nVal2, value1.y * nVal2);
}

_FOLIB_INLINE FOPFloat operator*(const int &nVal2, const FOPFloat& value1)
{
	return FOPFloat(value1.x * nVal2, value1.y * nVal2);
}

_FOLIB_INLINE FOPFloat operator/(const FOPFloat& value1, const int &nVal2)
{
	return FOPFloat(value1.x / nVal2, value1.y / nVal2);
}

_FOLIB_INLINE FOPFloat operator*(const FOPFloat& value1, const double &nVal2)
{
	return FOPFloat((value1.x * nVal2), (value1.y * nVal2));
}

_FOLIB_INLINE FOPFloat operator*(const double &nVal2, const FOPFloat& value1)
{
	return FOPFloat((value1.x * nVal2), (value1.y * nVal2));
}

_FOLIB_INLINE FOPFloat operator/(const FOPFloat& value1, const double &nVal2)
{
	return FOPFloat((value1.x / nVal2), (value1.y / nVal2));
}

/////////////////////////////////////////////////////////////////////////////////
//
// FOXSplineGen -- spline generator.
/////////////////////////////////////////////////////////////////////////////////

class FO_EXT_CLASS FOXSplineGen
{
public:
	
    // Constructors and destructor
    FOXSplineGen();
    FOXSplineGen(const FOXSplineGen&);
    ~FOXSplineGen();
	
    // Operations
    void AddSplinePoint(const FOXvec3& v);
	FOXvec3 GetInterpolatedSplinePoint(float t);   // t = 0...1; 0=vp[0] ... 1=vp[max]
	int GetNumPoints();
	FOXvec3& GetNthPoint(int n);
	
    // Static method for computing the Catmull-Rom parametric equation
    // given a time (t) and a vector quadruple (p1,p2,p3,p4).
    static FOXvec3 Eq(float t, const FOXvec3& p1, const FOXvec3& p2, const FOXvec3& p3, const FOXvec3& p4);
	
private:
    std::vector<FOXvec3> vp;
    float delta_t;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPair -- pair class.
/////////////////////////////////////////////////////////////////////////////////

class FOPointsArray;
//===========================================================================
// Summary:
//      To use a FOPPair object, just call the constructor.
//      O P Pair
//===========================================================================

class FO_EXT_CLASS FOPPair
{
public:
 
	// A, Specify a A 32-bit signed integer.  
	long nA;
 
	// B, Specify a A 32-bit signed integer.  
	long nB;

	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Pair, Constructs a FOPPair object.
	//		Returns A  value (Object).
	FOPPair();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Pair, Constructs a FOPPair object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nA---nA, Specifies A 32-bit long signed integer.  
	//		nB---nB, Specifies A 32-bit long signed integer.
	FOPPair(long nA, long nB);

	
	//-----------------------------------------------------------------------
	// Summary:
	// A, .
	//		Returns A 32-bit long signed integer.
	long A() const
	{
		return nA;
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// B, .
	//		Returns A 32-bit long signed integer.
	long B() const
	{
		return nB;
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// A, .
	//		Returns A 32-bit long signed integer.
	long& A()
	{
		return nA;
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// B, .
	//		Returns A 32-bit long signed integer.
	long& B()
	{
		return nB;
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPPair---F O P Pair, Specifies a const FOPPair& rFOPPair object(Value).
	BOOL operator ==(const FOPPair& rFOPPair) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPPair---F O P Pair, Specifies a const FOPPair& rFOPPair object(Value).
	BOOL operator !=(const FOPPair& rFOPPair) const;
};

_FOLIB_INLINE FOPPair::FOPPair()
{
	nA = nB = 0;
}

_FOLIB_INLINE FOPPair::FOPPair(long _nA, long _nB)
{
	FOPPair::nA = _nA;
	FOPPair::nB = _nB;
}

_FOLIB_INLINE BOOL FOPPair::operator ==(const FOPPair& rFOPPair) const
{
	return ((nA == rFOPPair.nA) && (nB == rFOPPair.nB));
}

_FOLIB_INLINE BOOL FOPPair::operator !=(const FOPPair& rFOPPair) const
{
	return ((nA != rFOPPair.nA) || (nB != rFOPPair.nB));
}

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPoint,this class is based on CPoint,so you can use it with the same way of 
// CPoint.
//

 
//===========================================================================
// Summary:
//     The FOPPoint class derived from CPoint
//      O P Point
//===========================================================================

class FO_EXT_CLASS FOPPoint : public CPoint
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Point, Constructs a FOPPoint object.
	//		Returns A  value (Object).
	FOPPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Point, Constructs a FOPPoint object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nX---nX, Specifies A 32-bit long signed integer.  
	//		nY---nY, Specifies A 32-bit long signed integer.
	FOPPoint(long nX, long nY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Point, Constructs a FOPPoint object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	FOPPoint(CPoint pt);

	//-----------------------------------------------------------------------
	// Summary:
	// O P Point, Constructs a FOPPoint object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	FOPPoint(FOPFloat pt);

	
	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A 32-bit long signed integer.
	long X() const		{	return x;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A 32-bit long signed integer.
	long Y() const		{	return y;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A 32-bit long signed integer.
	long& X()			{	return x;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A 32-bit long signed integer.
	long& Y()			{	return y;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		nHorzMove---Horizontal Move, Specifies A 32-bit long signed integer.  
	//		nVertMove---Vertical Move, Specifies A 32-bit long signed integer.
	void Move(long nHorzMove, long nVertMove);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Above, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	BOOL IsAbove(const FOPPoint& ptPoint) const;
	
	// Magnitude
	double Magnitude() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Is Below, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	BOOL IsBelow(const FOPPoint& ptPoint) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Left, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	BOOL IsLeft(const FOPPoint& ptPoint) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Right, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	BOOL IsRight(const FOPPoint& ptPoint) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance To, .
	//		Returns A double value (Object).  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	double DistanceTo(const FOPPoint& ptPoint) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Manhattan Length, .
	//		Returns A double value (Object).
	double ManhattanLength () const;

	// Sets a new position for the point in polar coordinates.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Polar, Sets a specify value to current class FOPPoint
	// Parameters:
	//		radius---Specifies a double radius object(Value).  
	//		angle---Specifies a double angle object(Value).
	void SetPolar(double radius, double angle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Angle, .
	//		Returns A double value (Object).
	// return The angle from zero to this vector (in radius).
	double Angle() const;

	// Swap x and y value.
	void Swap()
	{
		int tmp = x;
		x = y;
		y = tmp;
	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Angle To, .
	//		Returns A double value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.
	double AngleTo(const FOPPoint& pt1) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Lerp, .
	//		Returns a int type value.  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		t---Specifies a double t object(Value).
	// Lerp point
	FOPPoint Lerp(const FOPPoint& pt1, double t) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	//		Returns a int type value.  
	// Parameters:
	//		ang---Specifies a double ang object(Value).
	FOPPoint Rotate(double ang);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	//		Returns a int type value.  
	// Parameters:
	//		center---Specifies A integer value.  
	//		ang---Specifies a double ang object(Value).
	FOPPoint Rotate(FOPPoint center, double ang);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	//		Returns a int type value.  
	// Parameters:
	//		factor---Specifies A integer value.
	// Scales this point by the given factors with 0/0 as center.
	FOPPoint Scale(FOPPoint factor);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	//		Returns a int type value.  
	// Parameters:
	//		center---Specifies A integer value.  
	//		factor---Specifies A integer value.
	// Scales this point by the given factors with the given center.
    FOPPoint Scale(FOPPoint center, FOPPoint factor);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	//		Returns a int type value.  
	// Parameters:
	//		axisPoint1---axisPoint1, Specifies A integer value.  
	//		axisPoint2---axisPoint2, Specifies A integer value.
	// Mirrors this point at the given axis.
	FOPPoint Mirror(FOPPoint axisPoint1, FOPPoint axisPoint2);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPPoint& operator +=(const FOPPoint& ptPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPPoint& operator -=(const FOPPoint& ptPoint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nVal---nVal, Specifies A integer value.
	FOPPoint& operator *=(const int &nVal);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nVal---nVal, Specifies A integer value.
	FOPPoint& operator /=(const int &nVal);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nVal---nVal, Specifies a const double nVal object(Value).
	FOPPoint& operator *=(const double &nVal);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nVal---nVal, Specifies a const double nVal object(Value).
	FOPPoint& operator /=(const double &nVal);
	
	// Convert to string.
	CString ToString();

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	FOPPoint& operator=(const CPoint& pt);
	FOPPoint& operator=(const FOFLOAT& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimum, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.
	// Minimum
	static FOPPoint Minimum(const FOPPoint& pt1, const FOPPoint& pt2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Maximum, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.
    static FOPPoint Maximum(const FOPPoint& pt1, const FOPPoint& pt2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dot P, Do a event. 
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.
	static double DotP(const FOPPoint& pt1, const FOPPoint& pt2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cross P, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		v1---Specifies A integer value.  
	//		v2---Specifies A integer value.
	static FOPPoint CrossP(const FOPPoint& v1, const FOPPoint& v2);

	// friend operators
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		value2---Specifies A integer value.
	friend _FOLIB_INLINE FOPPoint operator+(const CPoint& value1, const CPoint& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		value2---Specifies A integer value.
	friend _FOLIB_INLINE FOPPoint operator-(const CPoint& value1, const CPoint& value2);
	 
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
	friend _FOLIB_INLINE FOPPoint operator*(const FOPPoint& value1, const int &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
	friend _FOLIB_INLINE FOPPoint operator*(const int &nVal2, const FOPPoint& value1);
	

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies A integer value.
	friend _FOLIB_INLINE FOPPoint operator/(const FOPPoint& value1, const int &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
	friend _FOLIB_INLINE FOPPoint operator*(const FOPPoint& value1, const double &nVal2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
	friend _FOLIB_INLINE FOPPoint operator*(const double &nVal2, const FOPPoint& value1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value1---Specifies A integer value.  
	//		nVal2---nVal2, Specifies a const double nVal2 object(Value).
	friend _FOLIB_INLINE FOPPoint operator/(const FOPPoint& value1, const double &nVal2);
};

/////////////////////////////////////////////////////////////////////////////////

_FOLIB_INLINE FOPPoint operator+(const CPoint& value1, const CPoint& value2)
{
	return FOPPoint(value1.x + value2.x, value1.y + value2.y);
}

_FOLIB_INLINE FOPPoint operator-(const CPoint& value1, const CPoint& value2)
{
	return FOPPoint(value1.x - value2.x, value1.y - value2.y);
}

_FOLIB_INLINE FOPPoint operator*(const FOPPoint& value1, const int &nVal2)
{
	return FOPPoint(value1.x * nVal2, value1.y * nVal2);
}

_FOLIB_INLINE FOPPoint operator*(const int &nVal2, const FOPPoint& value1)
{
	return FOPPoint(value1.x * nVal2, value1.y * nVal2);
}

_FOLIB_INLINE FOPPoint operator/(const FOPPoint& value1, const int &nVal2)
{
	return FOPPoint(value1.x / nVal2, value1.y / nVal2);
}

_FOLIB_INLINE FOPPoint operator*(const FOPPoint& value1, const double &nVal2)
{
	return FOPPoint((int)(value1.x * nVal2), (int)(value1.y * nVal2));
}

_FOLIB_INLINE FOPPoint operator*(const double &nVal2, const FOPPoint& value1)
{
	return FOPPoint((int)(value1.x * nVal2), (int)(value1.y * nVal2));
}

_FOLIB_INLINE FOPPoint operator/(const FOPPoint& value1, const double &nVal2)
{
	return FOPPoint((int)(value1.x / nVal2), (int)(value1.y / nVal2));
}

/////////////////////////////////////////////////////////////////////////////////
//
// FOPSize,this class is based on CSize class,so you can use it with the same way
// of CSize.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPSize class derived from CSize
//      O P Size
//===========================================================================

class FO_EXT_CLASS FOPSize : public CSize
{
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Size, Constructs a FOPSize object.
	//		Returns A  value (Object).
	FOPSize();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Size, Constructs a FOPSize object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---nHeight, Specifies A 32-bit long signed integer.
	FOPSize(long nWidth, long nHeight);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Size, Constructs a FOPSize object.
	//		Returns A  value (Object).  
	// Parameters:
	//		sz---Specifies A CSize type value.
	FOPSize(CSize sz);


	// Convert to string.
	CString ToString();

	//-----------------------------------------------------------------------
	// Summary:
	// Width, .
	//		Returns A 32-bit long signed integer.
	long Width() const		{	return cx;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Height, .
	//		Returns A 32-bit long signed integer.
	long Height() const		{	return cy;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Width, .
	//		Returns A 32-bit long signed integer.
	long& Width()			{	return cx;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Height, .
	//		Returns A 32-bit long signed integer.
	long& Height()			{	return cy;	}

	// Operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSize& value (Object).  
	// Parameters:
	//		sz---Specifies A CSize type value.
	FOPSize& operator=(const CSize& sz);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsNull() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size Empty, Sets a specify value to current class FOPSize

	void SetSizeEmpty();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Inflate, .
	// Parameters:
	//		w---Specifies A 32-bit long signed integer.  
	//		h---Specifies A 32-bit long signed integer.
	void Inflate(long w, long h);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Inflate, .
	// Parameters:
	//		sz---Specifies a const FOPSize& sz object(Value).
	void Inflate(const FOPSize& sz);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Deflate, .
	// Parameters:
	//		w---Specifies A 32-bit long signed integer.  
	//		h---Specifies A 32-bit long signed integer.
	void Deflate(long w, long h);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Deflate, .
	// Parameters:
	//		sz---Specifies a const FOPSize& sz object(Value).
	void Deflate(const FOPSize& sz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap, .

	void Swap();

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object const FOPSize& operator ,or NULL if the call failed  
	// Parameters:
	//		value---Specifies a double value object(Value).
	const FOPSize& operator *= (double value);	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPSize& operator value (Object).  
	// Parameters:
	//		value---Specifies a double value object(Value).
	const FOPSize& operator /= (double value);
};

#define FOP_RECT_EMPTY  ((short)-32767)

/////////////////////////////////////////////////////////////////////////////////
//
// FOPRect,this class is based on CRect,so you can use it with the same way of 
// CRect.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPRect class derived from CRect
//      O P Rectangle
//===========================================================================

class FO_EXT_CLASS FOPRect : public CRect
{
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).
	FOPRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptLeftTop---Left Top, Specifies A integer value.  
	//		ptRightBottom---Right Bottom, Specifies A integer value.
	FOPRect(const FOPPoint& ptLeftTop, const FOPPoint& ptRightBottom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptLeftTop---Left Top, Specifies A integer value.  
	//		sz---Specifies a const FOPSize& sz object(Value).
	FOPRect(const FOPPoint& ptLeftTop, const FOPSize& sz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		left---Specifies A 32-bit long signed integer.  
	//		top---Specifies A 32-bit long signed integer.  
	//		right---Specifies A 32-bit long signed integer.  
	//		bottom---Specifies A 32-bit long signed integer.
	FOPRect(long left, long top, long right, long bottom);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	FOPRect(LPPOINT points,int nCount);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rc---Specifies A CRect type value.
	FOPRect(CRect rc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, Constructs a FOPRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPPoint&ptCenter---O P Point&pt Center, Specifies A integer value.  
	//		&nRadius---&nRadius, Specifies A integer value.
	FOPRect(const FOPPoint&ptCenter, const int &nRadius);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Left, .
	//		Returns A 32-bit long signed integer.
	long Left() const	{	return left;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Right, .
	//		Returns A 32-bit long signed integer.
	long Right() const	{	return right;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top, .
	//		Returns A 32-bit long signed integer.
	long Top() const	{	return top;		}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom, .
	//		Returns A 32-bit long signed integer.
	long Bottom() const	{	return bottom;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Left, .
	//		Returns A 32-bit long signed integer.
	long& Left()		{	return left;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Right, .
	//		Returns A 32-bit long signed integer.
	long& Right()		{	return right;	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top, .
	//		Returns A 32-bit long signed integer.
	long& Top()			{	return top;		}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom, .
	//		Returns A 32-bit long signed integer.
	long& Bottom()		{	return bottom;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Top Left, .
	//		Returns a int type value.
	FOPPoint TopLeft() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top Right, .
	//		Returns a int type value.
	FOPPoint TopRight() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top Center, .
	//		Returns a int type value.
	FOPPoint TopCenter() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom Left, .
	//		Returns a int type value.
	FOPPoint BottomLeft() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom Right, .
	//		Returns a int type value.
	FOPPoint BottomRight() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom Center, .
	//		Returns a int type value.
	FOPPoint BottomCenter() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Left Center, .
	//		Returns a int type value.
	FOPPoint LeftCenter() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Right Center, .
	//		Returns a int type value.
	FOPPoint RightCenter() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Center, .
	//		Returns a int type value.
	FOPPoint Center() const;
	
	// Obtain point with angle.
	FOPPoint GetAnglePnt(const FOPRect& rR, long nAngle);

	//-----------------------------------------------------------------------
	// Summary:
	// Move To, .
	// Parameters:
	//		&ptMoveTo---Move To, Specifies A integer value.
	void MoveTo(const FOPPoint &ptMoveTo);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class FOPRect
	// Parameters:
	//		rSize---rSize, Specifies A CSize type value.
	void SetSize(const CSize& rSize);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetSize() const;

	// Resize rectangle.
	void ResizeRect(const FOPPoint& rRef, const FOPFraction& rxFact, const FOPFraction& ryFact, BOOL bNoJustify);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		nHorzMove---Horizontal Move, Specifies A 32-bit long signed integer.  
	//		nVertMove---Vertical Move, Specifies A 32-bit long signed integer.
	void Move(long nHorzMove, long nVertMove);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class FOPRect
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	void SetPos(const FOPPoint& ptPoint);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetWidth() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetHeight() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Union, .
	//		Returns A FOPRect& value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	FOPRect& Union(const FOPRect& rc);

	//-----------------------------------------------------------------------
	// Summary:
	// Union, .
	//		void.  
	// Parameters:
	//		pt---Specifies a const FOPRect& rc object(Value).
	void UnionPoint(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns A FOPRect& value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	FOPRect& Intersection(const FOPRect& rc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Union, Returns the specified value.
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	FOPRect GetUnion(const FOPRect& rc) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intersection, Returns the specified value.
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	FOPRect GetIntersection(const FOPRect& rc) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Center, You construct a FOPRect object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		&ptCenter---&ptCenter, Specifies A integer value.  
	//		&sz---Specifies a const FOPSize &sz object(Value).
	void CreateFromCenter(const FOPPoint &ptCenter, const FOPSize &sz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Center, You construct a FOPRect object in two steps. First call the constructor, then call Create, which creates the object.
	// Parameters:
	//		&ptCenter---&ptCenter, Specifies A integer value.  
	//		&sz---Specifies a const FOPSize &sz object(Value).
	void CreateFromPt(const FOPPoint &ptCenter, const FOPSize &sz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	// Parameters:
	//		points---Specifies A LPPOINT Points array.
	void GetPoints(LPPOINT points);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	// Parameters:
	//		*points---A pointer to the CPoint  or NULL if the call failed.
	void GetPoints(CPoint *points);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	// Parameters:
	//		arPoints---array of points.
	void GetPointsArray(CArray<CPoint, CPoint> &arPoints);

	
	// Obtain all points.
	void GetPoints(FOPointsArray *array);

	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void Draw(CDC *pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Justify, .

	void Justify();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Near, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPoint---rPoint, Specifies A integer value.  
	//		nTolerance---nTolerance, Specifies A 32-bit long signed integer.
	BOOL IsNear(const FOPPoint& rPoint, long nTolerance ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A integer value.
	BOOL HitTest(const FOPPoint& pt) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A integer value.
	BOOL XPtInRect(const FOPFloat& pt) const;

	// Offset rectangle
	void XOffsetRect(const FOPFloat& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	BOOL HitTest(const FOPRect& rc) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Over, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	BOOL IsOver(const FOPRect& rc) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Intersection, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	BOOL IsIntersection(const FOPRect& rc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	BOOL ContainsRect(const CRect &rc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns a float value.  
	// Parameters:
	//		&rPOINT---P O I N T, Specifies A integer value.  
	//		rClosest---rClosest, Specifies A integer value.
	float GetDistance( const FOPPoint &rPOINT, FOPPoint rClosest ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inside, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).
	BOOL IsInside( const FOPRect& rRect ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Empty, Sets a specify value to current class FOPRect

	void SetEmpty()	{	right = bottom = FOP_RECT_EMPTY; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Length, .
	//		Returns A double value (Object).
	double Length() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Area, .
	//		Returns A double value (Object).
	double Area() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Left Right, .

	void SwapLeftRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap Top Bottom, .

	void SwapTopBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Swap, .

	void Swap();

	// Convert to string.
	// Like "{X=20, Y=20, Width=100, Height=50}".
	CString ToString();

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPRect& value (Object).  
	// Parameters:
	//		rc---Specifies A CRect type value.
	FOPRect& operator=(const CRect& rc);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	BOOL operator ==(const FOPRect& rc) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	BOOL operator !=(const FOPRect& rc) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// setX, .
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	void setX(long n)
	{
		right += n - left; left = n;
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// setY, .
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	void setY(long n)
	{
		bottom += n - top; top = n;
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// setWidth, .
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	void setWidth(long n)
	{
		right = left + n;
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// setHeight, .
	// Parameters:
	//		n---Specifies A 32-bit long signed integer.
	void setHeight(long n)
	{
		bottom = top + n;
	}

	//-----------------------------------------------------------------------
	// Summary:
	// Do Calculate Attach Point, Do a event. 
	// Parameters:
	//		ptAttach---ptAttach, Specifies A integer value.  
	//		aDir---aDir, Specifies a FOPEscDir& aDir object(Value).  
	//		ptTail---ptTail, Specifies A integer value.  
	//		rcTextRect---Text Rectangle, Specifies a const FOPRect& rcTextRect object(Value).
	void DoCalcAttachPoint(FOPPoint& ptAttach, FOPEscDir& aDir,
		const FOPPoint& ptTail) const;

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPRect& operator value (Object).  
	// Parameters:
	//		pt---Specifies A integer value.
	FOPRect& operator +=(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPRect& operator value (Object).  
	// Parameters:
	//		pt---Specifies A integer value.
	FOPRect& operator -=(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPRect operator value (Object).  
	// Parameters:
	//		rt---Specifies a const FOPRect& rt object(Value).
	FOPRect operator & (const FOPRect& rt) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPRect operator value (Object).  
	// Parameters:
	//		rt---Specifies a const FOPRect& rt object(Value).
	FOPRect operator | (const FOPRect& rt) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE FOPRect operator value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).  
	//		pt---Specifies A integer value.
	friend _FOLIB_INLINE FOPRect operator +(const FOPRect& rc, const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE FOPRect operator value (Object).  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).  
	//		pt---Specifies A integer value.
	friend _FOLIB_INLINE FOPRect operator -(const FOPRect& rc, const FOPPoint& pt);
};
////////////////////////////////////////////////////////////////////////////////////
// FOPSizeF

class FO_EXT_CLASS FOPSizeF
{
// constructors & destructors
public:
	FOPSizeF()
		: cx(0.)
		, cy(0.)
	{
	}

	FOPSizeF(double w, double h)
		: cx(w)
		, cy(h)
	{
	}

	FOPSizeF(const FOPSizeF& sz)
		: cx(sz.cx)
		, cy(sz.cy)
	{
	}

	FOPSizeF(const CSize& sz)
		: cx((double)sz.cx)
		, cy((double)sz.cy)
	{
	}

// public member function
public:
	bool IsNull() const
	{
		return cx == 0.0 && cy == 0.0;
	}

	bool IsEmpty() const
	{
		return cx == 0.0 || cy == 0.0;
	}

	bool IsValid() const
	{
		return cx >= 0.0 && cy >= 0.0;
	}

	double Width() const
	{
		return cx;
	}

	double Height() const
	{
		return cy;
	}

	void SetSize(double w, double h)
	{
		cx = w;
		cy = h;
	}

	void SetSize(const FOPSizeF& sz)
	{
		SetSize (sz.cx, sz.cy);
	}

	void SetSizeEmpty()
	{
		SetSize(0.0, 0.0);
	}

	void Inflate(double w, double h)
	{
		cx += w;
		cy += h;
	}

	void Inflate(const FOPSizeF& sz)
	{
		Inflate(sz.cx, sz.cy);
	}

	void Deflate(double w, double h)
	{
		cx -= w;
		cy -= h;
	}

	void Deflate(const FOPSizeF& sz)
	{
		Deflate(sz.cx, sz.cy);
	}

	void Swap()
	{
		double tmp = cx;
		cx = cy;
		cy = tmp;
	}

	void Scale(double dblRatio)
	{
		Scale(dblRatio, dblRatio);
	}
	
	void Scale(double dblRatioX, double dblRatioY)
	{
		cx *= dblRatioX;
		cy *= dblRatioY;
	}

// public operators
public:
	const FOPSizeF& operator = (const FOPSizeF& sz)
	{
		cx = sz.cx;
		cy = sz.cy;
		return *this;
	}

	bool operator == (const FOPSizeF& sz) const
	{
		return cx == sz.cx && cy == sz.cy;
	}

	bool operator != (const FOPSizeF& sz) const
	{
		return cx != sz.cx || cy != sz.cy;
	}

	const FOPSizeF& operator += (const FOPSizeF& sz)
	{
		Inflate(sz.cx, sz.cy);
		return *this;
	}

	const FOPSizeF& operator -= (const FOPSizeF& sz)
	{
		Deflate(sz.cx, sz.cy);
		return *this;
	}

	const FOPSizeF& operator *= (double value)
	{
		cx *= value;
		cy *= value;
		return *this;
	}

	const FOPSizeF& operator /= (double value)
	{
		_ASSERTE(value != 0.0);
		cx /= value;
		cy /= value;
		return *this;
	}

	FOPSizeF operator + (const FOPSizeF& sz) const
	{
		return FOPSizeF(cx + sz.cx, cy + sz.cy);
	}

	FOPSizeF operator - (const FOPSizeF& sz) const
	{
		return FOPSizeF(cx - sz.cx, cy - sz.cy);
	}

	FOPSizeF operator * (double value) const
	{
		return FOPSizeF(cx * value, cy * value);
	}

	FOPSizeF operator / (double value) const
	{
		_ASSERTE(value != 0.0);
		return FOPSizeF(cx / value, cy / value);
	}

	operator CSize() const
	{
		return CSize((long)cx, (long)cy);
	}

public:
	double	cx;
	double	cy;
};

// Class for float rectangle.
class FO_EXT_CLASS FOPRectF
{
// constructors & destructors
public:
	FOPRectF()
		: left  (0.)
		, top   (0.)
		, right (0.)
		, bottom(0.)
	{
	}

	FOPRectF(double l, double t, double r, double b)
		: left  (l)
		, top   (t)
		, right (r)
		, bottom(b)
	{
	}

	FOPRectF(const FOPFloat& ptLT, const FOPFloat& ptRB)
		: left  (ptLT.x)
		, top   (ptLT.y)
		, right (ptRB.x)
		, bottom(ptRB.y)
	{
	}

	FOPRectF(const FOPFloat& pt, const FOPSize& sz)
		: left  (pt.x)
		, top   (pt.y)
		, right (pt.x + sz.cx)
		, bottom(pt.y + sz.cy)
	{
	}

	FOPRectF(const FOPRectF& rt)
		: left  (rt.left)
		, top   (rt.top)
		, right (rt.right)
		, bottom(rt.bottom)
	{
	}

	FOPRectF(const CRect& rt)
		: left  ((double)rt.left)
		, top   ((double)rt.top)
		, right ((double)rt.right)
		, bottom((double)rt.bottom)
	{
	}

public:
	enum FOP_POINT
	{
		FOP_POINT_FIRST         = 0,
		FOP_POINT_TOP_LEFT      = FOP_POINT_FIRST,
		FOP_POINT_TOP_CENTER    = 1,
		FOP_POINT_TOP_RIGHT     = 2, 
		FOP_POINT_CENTER_RIGHT  = 3,
		FOP_POINT_BOTTOM_RIGHT  = 4,
		FOP_POINT_BOTTOM_CENTER = 5,
		FOP_POINT_BOTTOM_LEFT   = 6,
		FOP_POINT_CENTER_LEFT   = 7,
		FOP_POINT_CENTER        = 8,
		FOP_POINT_NULL          = 9,
		FOP_POINT_LAST          = FOP_POINT_NULL
	};

// public member function
public:
	bool IsRectNull() const
	{
		return left == 0.0 && top == 0.0 && right == 0.0 && bottom == 0.0;
	}

	bool IsRectEmpty() const
	{
		return left == right || top == bottom;
	}

	bool IsValid() const
	{
		return left < right && top < bottom;
	}

	bool PtInRect(double x, double y) const
	{
		return left <= x && right >= x && top <= y && bottom >= y;
	}

	bool PtInRect(const FOPFloat& pt) const
	{
		return PtInRect (pt.x, pt.y);
	}

	bool RtInRect(double l, double t, double r, double b) const
	{
		return left <= l && right >= r && top <= t && bottom >= b;
	}

	bool RtInRect(const FOPRectF& rt) const
	{
		return RtInRect(rt.left, rt.top, rt.right, rt.bottom);
	}

	void Normalize()
	{
		if (right < left)
		{
			SwapLeftRight();
		}

		if (bottom < top)
		{
			SwapTopBottom();
		}
	}

	FOPRectF NormalizedRect () const
	{
		FOPRectF rect(*this);
		rect.Normalize ();
		return rect;
	}

	double Width() const
	{
		return right - left;
	}

	void SetWidth(double w)
	{
		right = left + w;
	}

	double Height() const
	{
		return bottom - top;
	}

	void SetHeight(double h)
	{
		bottom = top + h;
	}

	void OffsetRect(double x, double y)
	{
		left   += x;
		right  += x;
		top    += y;
		bottom += y;
	}

	void OffsetRect(const FOPFloat& pt)
	{
		OffsetRect (pt.x, pt.y);
	}

	void OffsetRect(const FOPSize& sz)
	{
		OffsetRect (sz.cx, sz.cy);
	}

	void SetPoint(double x, double y)
	{
		OffsetRect(x - left, y - top);
	}

	void SetPoint(const FOPFloat& pt)
	{
		SetPoint (pt.x, pt.y);
	}

	void SetSize(double w, double h)
	{
		right  = left + w;
		bottom = top  + h;
	}

	void SetSize(const FOPSize& sz)
	{
		SetSize (sz.cx, sz.cy);
	}

	FOPSize Size() const
	{
		return FOPSize(Width(), Height());
	}

	void SetRect(double l, double t, double r, double b)
	{
		left   = l;
		top    = t;
		right  = r;
		bottom = b;
	}

	void SetRect(const FOPFloat& ptLT, const FOPFloat& ptRB)
	{
		SetRect (ptLT.x, ptLT.y, ptRB.x, ptRB.y);
	}

	void SetRect(const FOPFloat& pt, const FOPSize& sz)
	{
		SetRect(pt.x, pt.y, pt.x + sz.cx, pt.y + sz.cy);
	}

	void SetRect(const FOPRectF& rt)
	{
		SetRect(rt.left, rt.top, rt.right, rt.bottom);
	}

	FOPFloat CenterPoint() const
	{
		return FOPFloat((left + right) / 2.0, (top + bottom) / 2.0);
	}

	double Length() const
	{
		FOPSize sz(Size());
		return 2.0 * ((sz.cx < 0.0 ? -sz.cx : sz.cx) + (sz.cy < 0.0 ? -sz.cy : sz.cy));
	}

	double Area() const
	{
		double a = Width() * Height();
		if (a < 0.0)
		{
			a = -a;
		}

		return a;
	}

	BOOL IntersectRect(const FOPRectF& rt)
	{
		*this &= rt;
		return !IsRectEmpty();
	}

	BOOL IntersectRect(const FOPRectF& rt1, const FOPRectF& rt2)
	{
		*this = rt1 & rt2;
		return !IsRectEmpty();
	}

	void UnionRect(const FOPRectF& rt)
	{
		*this |= rt;
	}

	void UnionRect(const FOPRectF& rt1, const FOPRectF& rt2)
	{
		*this = rt1 | rt2;
	}

	FOPFloat TopLeft() const
	{
		return FOPFloat(left, top);
	}

	FOPFloat TopCenter() const
	{
		return FOPFloat((left + right) / 2.0, top);
	}

	FOPFloat TopRight() const
	{
		return FOPFloat(right, top);
	}

	FOPFloat CenterRight() const
	{
		return FOPFloat(right, (top + bottom) / 2.0);
	}

	FOPFloat BottomRight() const
	{
		return FOPFloat(right, bottom);
	}

	FOPFloat BottomCenter() const
	{
		return FOPFloat((left + right) / 2.0, bottom);
	}

	FOPFloat BottomLeft() const
	{
		return FOPFloat(left, bottom);
	}

	FOPFloat CenterLeft() const
	{
		return FOPFloat(left, (top + bottom) / 2.0);
	}

	FOPFloat RectPoint(FOP_POINT point) const
	{
		switch (point)
		{
		case FOP_POINT_TOP_LEFT:
			return TopLeft();
		case FOP_POINT_TOP_CENTER:
			return TopCenter();
		case FOP_POINT_TOP_RIGHT:
			return TopRight();
		case FOP_POINT_CENTER_RIGHT:
			return CenterRight();
		case FOP_POINT_BOTTOM_RIGHT:
			return BottomRight();
		case FOP_POINT_BOTTOM_CENTER:
			return BottomCenter();
		case FOP_POINT_BOTTOM_LEFT:
			return BottomLeft();
		case FOP_POINT_CENTER_LEFT:
			return CenterLeft();
		case FOP_POINT_CENTER:
			return CenterPoint();
		}

		return FOPFloat();
	}

	void InflateRect(double l, double t, double r, double b)
	{
		left   -= l;
		top    -= t;
		right  += r;
		bottom += b;
	}

	void InflateRect(double x, double y)
	{
		InflateRect (x, y, x, y);
	}

	void InflateRect(const FOPFloat& pt)
	{
		InflateRect (pt.x, pt.y, pt.x, pt.y);
	}

	void InflateRect(const FOPSize& sz)
	{
		InflateRect (sz.cx, sz.cy, sz.cx, sz.cy);
	}

	void InflateRect(const FOPRectF& rt)
	{
		InflateRect (rt.left, rt.top, rt.right, rt.bottom);
	}

	void DeflateRect(double l, double t, double r, double b)
	{
		left   += l;
		top    += t;
		right  -= r;
		bottom -= b;
	}

	void DeflateRect(double x, double y)
	{
		DeflateRect (x, y, x, y);
	}

	void DeflateRect(const FOPFloat& pt)
	{
		DeflateRect (pt.x, pt.y, pt.x, pt.y);
	}

	void DeflateRect(const FOPSize& sz)
	{
		DeflateRect (sz.cx, sz.cy, sz.cx, sz.cy);
	}

	void DeflateRect(const FOPRectF& rt)
	{
		DeflateRect (rt.left, rt.top, rt.right, rt.bottom);
	}

	void SwapLeftRight()
	{
		double tmp = left;
		left = right;
		right = tmp;
	}

	void SwapTopBottom()
	{
		double tmp = top;
		top = bottom;
		bottom = tmp;
	}

	void Swap()
	{
		SwapLeftRight ();
		SwapTopBottom ();
	}

	void SetRectEmpty()
	{
		left = right = top = bottom = 0.;
	}

	void Scale(const FOPSize& szRatio, FOP_POINT point = FOP_POINT_NULL)
	{
		Scale(szRatio.cx, szRatio.cy, RectPoint(point));
	}

	void Scale(const FOPSize& szRatio, const FOPFloat& ptOffset)
	{
		Scale(szRatio.cx, szRatio.cy, ptOffset);
	}

	void Scale(double dblRatio, const FOPFloat& ptOffset = FOPFloat())
	{
		Scale(dblRatio, dblRatio, ptOffset);
	}

	void Scale(double dblRatioX, double dblRatioY, const FOPFloat& ptOffset = FOPFloat())
	{
		FOPSize size(Size());

		left = ptOffset.x + (left - ptOffset.x) * dblRatioX;
		top  = ptOffset.y + (top - ptOffset.y) * dblRatioY;
		SetSize (size.cx * dblRatioX, size.cy * dblRatioY);
	}

// public operators
public:
	const FOPRectF& operator = (const FOPRectF& rt)
	{
		left   = rt.left;
		top    = rt.top;
		right  = rt.right;
		bottom = rt.bottom;
		return *this;
	}

	bool operator == (const FOPRectF& rt) const
	{
		return left == rt.left && top == rt.top && right == rt.right && bottom == rt.bottom;
	}

	bool operator != (const FOPRectF& rt) const
	{
		return !(*this == rt);
	}

	const FOPRectF& operator &= (const FOPRectF& rt)
	{
		*this = *this & rt;
		return *this;
	}

	const FOPRectF& operator |= (const FOPRectF& rt)
	{
		*this = *this | rt;
		return *this;
	}

	const FOPRectF& operator += (const FOPFloat& pt)
	{
		OffsetRect (pt.x, pt.y);
		return *this;
	}

	const FOPRectF& operator -= (const FOPFloat& pt)
	{
		OffsetRect (-pt.x, -pt.y);
		return *this;
	}

	const FOPRectF& operator += (const FOPSize& sz)
	{
		SetSize (Width() + sz.cx, Height() + sz.cy);
		return *this;
	}

	const FOPRectF& operator -= (const FOPSize& sz)
	{
		SetSize (Width() - sz.cx, Height() - sz.cy);
		return *this;
	}

	FOPRectF operator & (const FOPRectF& rt) const
	{
		FOPRectF tmp;
		tmp.left   = max(left  , rt.left  );
		tmp.right  = min(right , rt.right );
		tmp.top    = max(top   , rt.top   );
		tmp.bottom = min(bottom, rt.bottom);

		if (tmp.left >= tmp.right || tmp.top >= tmp.bottom)
		{
			tmp.SetRectEmpty();
		}

		return tmp;
	}

	FOPRectF operator | (const FOPRectF& rt) const
	{
		if (IsValid())
		{
			if (rt.IsValid())
			{
				FOPRectF tmp;
				tmp.left   = min(left  , rt.left  );
				tmp.right  = max(right , rt.right );
				tmp.top    = min(top   , rt.top   );
				tmp.bottom = max(bottom, rt.bottom);
				return tmp;
			}
			else
			{
				return *this;
			}
		}
		else
		{
			FOPRectF tmp(rt);
			return tmp;
		}
	}

	FOPRectF operator + (const FOPFloat& pt) const
	{
		FOPRectF tmp;
		tmp.left   = left   + pt.x;
		tmp.right  = right  + pt.x;
		tmp.top    = top    + pt.y;
		tmp.bottom = bottom + pt.y;
		return tmp;
	}

	FOPRectF operator - (const FOPFloat& pt) const
	{
		FOPRectF tmp;
		tmp.left   = left   - pt.x;
		tmp.right  = right  - pt.x;
		tmp.top    = top    - pt.y;
		tmp.bottom = bottom - pt.y;
		return tmp;
	}

	operator FOPRectF() const
	{
		return FOPRectF(left, top, right, bottom);
	}

public:
	// Left side.
	double	left;

	// Right side.
	double	right;

	// Top side.
	double	top;

	// Bottom side.
	double	bottom;
};

// FOPRoundedRect

 
//===========================================================================
// Summary:
//      To use a FOPRoundedRect object, just call the constructor.
//      O P Rounded Rectangle
//===========================================================================

class FO_EXT_CLASS FOPRoundedRect
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rounded Rectangle, Constructs a FOPRoundedRect object.
	//		Returns A  value (Object).
	FOPRoundedRect();	
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rounded Rectangle, Constructs a FOPRoundedRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rectSrc---rectSrc, Specifies a const FOPRect& rectSrc object(Value).  
	//		radiusXSrc---X Source, Specifies A integer value.  
	//		radiusYSrc---Y Source, Specifies A integer value.
	FOPRoundedRect(const FOPRectF& rectSrc, double radiusXSrc, double radiusYSrc);	
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rounded Rectangle, Constructs a FOPRoundedRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		l---Specifies A integer value.  
	//		t---Specifies A integer value.  
	//		r---Specifies A integer value.  
	//		b---Specifies A integer value.  
	//		radiusXSrc---X Source, Specifies A integer value.  
	//		radiusYSrc---Y Source, Specifies A integer value.
	FOPRoundedRect(double l, double t, double r, double b, double radiusXSrc, double radiusYSrc);
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Scale rect.
	void Scale(const FOPSizeF& szRatio, FOPRectF::FOP_POINT point = FOPRectF::FOP_POINT_NULL)
	{
		Scale(szRatio.cx, szRatio.cy, rect.RectPoint(point));
	}
	
	// Scale rectangle.
	void Scale(const FOPSizeF& szRatio, const FOPFloat& ptOffset)
	{
		Scale(szRatio.cx, szRatio.cy, ptOffset);
	}
	
	// Scale rectangle
	void Scale(double dblRatioX, double dblRatioY, const FOPFloat& ptOffset = FOPFloat())
	{
		rect.Scale(dblRatioX, dblRatioY, ptOffset);
		radiusX *= dblRatioX;
		radiusY *= dblRatioY;
	}
public:
 
	// This member specify FOPRect object.  
	FOPRectF	rect;
 
	// X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double		radiusX;
 
	// Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double		radiusY;
};

////////////////////////////////////////////////////////////////////////////////////
// FOPEllipse

 
//===========================================================================
// Summary:
//      To use a FOPEllipse object, just call the constructor.
//      O P Ellipse
//===========================================================================

class FO_EXT_CLASS FOPEllipse
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ellipse, Constructs a FOPEllipse object.
	//		Returns A  value (Object).
	FOPEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ellipse, Constructs a FOPEllipse object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptSrc---ptSrc, Specifies A integer value.  
	//		radiusXSrc---X Source, Specifies A integer value.  
	//		radiusYSrc---Y Source, Specifies A integer value.
	FOPEllipse(const FOPFloat& ptSrc, double radiusXSrc, double radiusYSrc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ellipse, Constructs a FOPEllipse object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptSrc---ptSrc, Specifies A integer value.  
	//		szSrc---szSrc, Specifies a const FOPSize& szSrc object(Value).
	FOPEllipse(const FOPFloat& ptSrc, const FOPSizeF& szSrc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Ellipse, Constructs a FOPEllipse object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	FOPEllipse(const FOPRectF& rect);
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsNull() const;	
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, .
	//		Returns A operator value (Object).
	operator FOPRectF() const;

	//-----------------------------------------------------------------------
	// Summary:
	// O P Rectangle, .
	//		Returns A operator value (Object).
	operator FOPRect() const;
	
	// Scaling
	void Scale(const FOPSizeF& szRatio, FOPRectF::FOP_POINT pointIn = FOPRectF::FOP_POINT_NULL)
	{
		Scale(szRatio.cx, szRatio.cy, ((FOPRectF)*this).RectPoint(pointIn));
	}
	
	// Scale.
	void Scale(const FOPSizeF& szRatio, const FOPFloat& ptOffset)
	{
		Scale(szRatio.cx, szRatio.cy, ptOffset);
	}
	
	// Scale.
	void Scale(double dblRatioX, double dblRatioY, const FOPFloat& ptOffset = FOPFloat());

	// obtain a point on ellipse with angle
	FOPFloat GetPoint(double dblAngle, BOOL bInv = TRUE) const;

public:
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	point;
 
	// X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double			radiusX;
 
	// Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double			radiusY;
};

////////////////////////////////////////////////////////////////////////////////////
// FOPointsArray

 
//===========================================================================
// Summary:
//     The FOPointsArray class derived from CArray<FOPPoint
//      O Points Array
//===========================================================================

class FO_EXT_CLASS FOPointsArray: public CArray<CPoint, CPoint>
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Points Array, Constructs a FOPointsArray object.
	//		Returns A  value (Object).
	FOPointsArray();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Points Array, Constructs a FOPointsArray object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nNewSize---New Size, Specifies A integer value.  
	//		nGrowBy---Grow By, Specifies A integer value.
	FOPointsArray(int nNewSize, int nGrowBy = -1);

	FOPointsArray(const FOPointsArray &ary);

	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Points Array, Destructor of class FOPointsArray
	//		Returns A  value (Object).
	~FOPointsArray();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bounds Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
	FOPRect GetBoundsRect() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bounds Center, Returns the specified value.
	//		Returns a int type value.
	FOPPoint GetBoundsCenter() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Multiply, .
	// Parameters:
	//		value---Specifies a double value object(Value).
	void Multiply(double value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multiply, .
	// Parameters:
	//		valueX---valueX, Specifies a double valueX object(Value).  
	//		valueY---valueY, Specifies a double valueY object(Value).
	void Multiply(double valueX, double valueY);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset, .
	// Parameters:
	//		pt---Specifies A integer value.
	void Offset(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset, .
	// Parameters:
	//		valueX---valueX, Specifies A 32-bit long signed integer.  
	//		valueY---valueY, Specifies A 32-bit long signed integer.
	void Offset(long valueX, long valueY);

	void RemoveRange(int nIdx, int nCount);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		value---Specifies a double value object(Value).
	void Scale(double value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		valueX---valueX, Specifies a double valueX object(Value).  
	//		valueY---valueY, Specifies a double valueY object(Value).
	void Scale(double valueX, double valueY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		pt---Specifies A integer value.  
	//		valueX---valueX, Specifies a double valueX object(Value).  
	//		valueY---valueY, Specifies a double valueY object(Value).
	void Scale(const FOPPoint& pt, double valueX, double valueY);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		angle---Specifies a double angle object(Value).
	void Rotate(double angle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		pt---Specifies A integer value.  
	//		angle---Specifies a double angle object(Value).
	void Rotate(const FOPPoint& pt, double angle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		pt---Specifies A integer value.
	const FOPointsArray& operator +=(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		pt---Specifies A integer value.
	const FOPointsArray& operator -=(const FOPPoint& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value---Specifies a double value object(Value).
	const FOPointsArray& operator *=(double value);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		value---Specifies a double value object(Value).
	const FOPointsArray& operator /=(double value);
};
////////////////////////////////////////////////////////////////////////////////////
// FOPTransMatrxF

class FO_EXT_CLASS FOPTransMatrxF
{
public:
	void CreateTranslate(double x, double y);
	void CreateScale(double x, double y);
	void CreateRotate(double a, double x, double y);
	void CreateSkewX(double a);
	void CreateSkewY(double a);
	
	FOPTransMatrxF();
	FOPTransMatrxF& operator = (const FOPTransMatrxF& src);
	BOOL IsEmpty() const;
	BOOL CompareWith(const FOPTransMatrxF& other);
	
	CArray<double, double>	m_arMatrix;
	FOPFloat				m_ptRotateCenter;
	BOOL					m_bCheckRelativeTranslate;
};

typedef CArray<FOPTransMatrxF, const FOPTransMatrxF&> CFOPPTransformsArray;

////////////////////////////////////////////////////////////////////////////////////
// CFOBaseSegment


//===========================================================================
// Summary:
//     The CFOBaseSegment class derived from CObject, base segment class.
//===========================================================================

class FO_EXT_CLASS CFOBaseSegment : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseSegment---F O Tab Child Object, Specifies a E-XD++ CFOBaseSegment object (Value).
	DECLARE_SERIAL(CFOBaseSegment);
	
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Child Object, Constructs a CFOBaseSegment object.
	//		Returns A  value (Object).
	CFOBaseSegment();
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Child Object, Constructs a CFOBaseSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOBaseSegment& source object(Value).
	CFOBaseSegment(const CFOBaseSegment& source);
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBaseSegment& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOBaseSegment& source object(Value).
	CFOBaseSegment& operator=(const CFOBaseSegment& source);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseSegment,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOBaseSegment* Copy() const;
	
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Child Object, Destructor of class CFOBaseSegment
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseSegment();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// serialize
	virtual void Serialize(CArchive &ar);
	
public:
	
	
	
};
typedef CTypedPtrList<CObList, CFOBaseSegment*> CFOBaseSegmentList;

////////////////////////////////////////////////////////////////////////////////////
// FOPSplineGeometry

 
//===========================================================================
// Summary:
//     The FOPSplineGeometry class derived from CObject
//      O P Spline Geometry
//===========================================================================

enum FOP_SPLINE_TYPE
{
	FOP_SPLINE_TYPE_KB,
		FOP_SPLINE_TYPE_HERMITE,
};
	
class FO_EXT_CLASS FOPSplineGeometry : public CFOBaseSegment
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSplineGeometry---O P Spline Geometry, Specifies a FOPSplineGeometry object(Value).
	DECLARE_DYNAMIC(FOPSplineGeometry)
		
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Spline Geometry, Constructs a FOPSplineGeometry object.
	//		Returns A  value (Object).
	FOPSplineGeometry();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Spline Geometry, Constructs a FOPSplineGeometry object.
	//		Returns A  value (Object).  
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		type---Specifies a FOP_SPLINE_TYPE type object(Value).  
	//		bIsClosed---Is Closed, Specifies A Boolean value.  
	//		tension---Specifies a double tension = 0.0 object(Value).  
	//		bias---Specifies a double bias = 0.0 object(Value).  
	//		continuity---Specifies a double continuity = 0.0 object(Value).
	FOPSplineGeometry(const CArray<FOPFloat, FOPFloat>& arPoints, FOP_SPLINE_TYPE type, 
		BOOL bIsClosed = TRUE, double tension = 0.0, double bias = 0.0, double continuity = 0.0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Spline Geometry, Constructs a FOPSplineGeometry object.
	//		Returns A  value (Object).  
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		type---Specifies a FOP_SPLINE_TYPE type object(Value).  
	//		bIsClosed---Is Closed, Specifies A Boolean value.  
	//		tension---Specifies a double tension = 0.0 object(Value).  
	//		bias---Specifies a double bias = 0.0 object(Value).  
	//		continuity---Specifies a double continuity = 0.0 object(Value).
	FOPSplineGeometry(LPPOINT arPoints, int nPtCount, FOP_SPLINE_TYPE type, 
		BOOL bIsClosed = TRUE, double tension = 0.0, double bias = 0.0, double continuity = 0.0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Points, Sets a specify value to current class FOPSplineGeometry
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		type---Specifies a FOP_SPLINE_TYPE type object(Value).  
	//		bIsClosed---Is Closed, Specifies A Boolean value.  
	//		tension---Specifies a double tension = 0.0 object(Value).  
	//		bias---Specifies a double bias = 0.0 object(Value).  
	//		continuity---Specifies a double continuity = 0.0 object(Value).
	void SetPoints(const CArray<FOPFloat, FOPFloat>& arPoints, FOP_SPLINE_TYPE type, 
		BOOL bIsClosed = TRUE, double tension = 0.0, double bias = 0.0, double continuity = 0.0);

	//-----------------------------------------------------------------------
	// Summary:
	// Set Points, Sets a specify value to current class FOPSplineGeometry
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		type---Specifies a FOP_SPLINE_TYPE type object(Value).  
	//		bIsClosed---Is Closed, Specifies A Boolean value.  
	//		tension---Specifies a double tension = 0.0 object(Value).  
	//		bias---Specifies a double bias = 0.0 object(Value).  
	//		continuity---Specifies a double continuity = 0.0 object(Value).
	void SetPoints(LPPOINT arPoints, int nPtCount, FOP_SPLINE_TYPE type, 
		BOOL bIsClosed = TRUE, double tension = 0.0, double bias = 0.0, double continuity = 0.0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	//		Returns a int type value.
	const CArray<FOPFloat, FOPFloat>& GetPoints() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	void Clear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsNull() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClosed() const;
	
protected:
 
	// Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CArray<FOPFloat, FOPFloat>	m_arPoints;
 
	// Is Closed, This member sets TRUE if it is right.  
	BOOL			m_bIsClosed;
};


////////////////////////////////////////////////////////////////////////////////////
// FOPLineSegment

 
//===========================================================================
// Summary:
//     The FOPLineSegment class derived from CObject
//      O P Line Segment
//===========================================================================

class FO_EXT_CLASS FOPLineSegment : public CFOBaseSegment
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPLineSegment---O P Line Segment, Specifies a FOPLineSegment object(Value).
	DECLARE_DYNAMIC(FOPLineSegment)

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Segment, Constructs a FOPLineSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		point---Specifies A integer value.
	FOPLineSegment(const FOPFloat& ptPoint);

 
	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_Point;
};

////////////////////////////////////////////////////////////////////////////////////
// FOPBezierSegment

 
//===========================================================================
// Summary:
//     The FOPBezierSegment class derived from CObject
//      O P Bezier Segment
//===========================================================================

class FO_EXT_CLASS FOPBezierSegment : public CFOBaseSegment
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPBezierSegment---O P Bezier Segment, Specifies a FOPBezierSegment object(Value).
	DECLARE_DYNAMIC(FOPBezierSegment)

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Bezier Segment, Constructs a FOPBezierSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		point1---Specifies A integer value.  
	//		point2---Specifies A integer value.  
	//		point3---Specifies A integer value.
	FOPBezierSegment(const FOPFloat& point1, const FOPFloat& point2, const FOPFloat& point3);
 
	// Point1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_Point1;
 
	// Point2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_Point2;
 
	// Point3, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_Point3;
};

////////////////////////////////////////////////////////////////////////////////////
// FOPArcSegment

 
//===========================================================================
// Summary:
//     The FOPArcSegment class derived from CObject
//      O P Arc Segment
//===========================================================================

class FO_EXT_CLASS FOPArcSegment : public CFOBaseSegment
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPArcSegment---O P Arc Segment, Specifies a FOPArcSegment object(Value).
	DECLARE_DYNAMIC(FOPArcSegment)

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Arc Segment, Constructs a FOPArcSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		point---Specifies A integer value.  
	//		radius---Specifies a const FOPSize& radius object(Value).  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		dblRotationAngle---Rotation Angle, Specifies a double dblRotationAngle object(Value).
	FOPArcSegment(const FOPFloat& point, const FOPSizeF& radius, BOOL bIsClockwise, 
		BOOL bIsLargeArc, double dblRotationAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arc Center, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		ptFrom---ptFrom, Specifies A integer value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		rX---rX, Specifies a double& rX object(Value).  
	//		rY---rY, Specifies a double& rY object(Value).
	FOPFloat GetArcCenter(const FOPFloat& ptFrom, BOOL& bIsLargeArc, double& rX, double& rY) const;

	// Obtain bulge
	double getBulge(const FOPFloat &ptStart);

	// Obtain sweep angle.
	double GetSweep(const FOPFloat &ptStart);

	// Obtain start angle.
	double GetStartAngle(const FOPFloat &ptStart);

	// Obtain end angle.
	double GetEndAngle(const FOPFloat &ptEnd);

	// Obtain distance from start.
	double getDistanceFromStart(const FOPFloat &ptStart, const FOPFloat& p);

	// change end point.
	void SetEndPoint(const FOPFloat &ptStart,const FOPFloat &ptNewEnd);

	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_Point;
 
	// Radius, This member specify FOPSize object.  
	FOPSizeF		m_Radius;
 
	// Is Clockwise, This member sets TRUE if it is right.  
	BOOL		m_bIsClockwise;
 
	// Is Large Arc, This member sets TRUE if it is right.  
	BOOL		m_bIsLargeArc;
 
	// Rotation Angle, This member specify double object.  
	double		m_dblRotationAngle;
};

////////////////////////////////////////////////////////////////////////////////////
// FOP_CURVE_TYPE

enum FOP_CURVE_TYPE
{
	FOP_CURVE_TYPE_LINE,
	FOP_CURVE_TYPE_BEZIER,
};

////////////////////////////////////////////////////////////////////////////////////
// FOPComplexGeometry

 
//===========================================================================
// Summary:
//     The FOPComplexGeometry class derived from CObject
//      O P Complex Geometry
//===========================================================================

class FO_EXT_CLASS FOPComplexGeometry : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPComplexGeometry---O P Complex Geometry, Specifies a FOPComplexGeometry object(Value).
	DECLARE_DYNAMIC(FOPComplexGeometry)

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complex Geometry, Constructs a FOPComplexGeometry object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.  
	//		-1)---Specifies a -1) object(Value).  
	//		bIsClosed---Is Closed, Specifies A Boolean value.
	FOPComplexGeometry(const FOPFloat& ptStart = FOPFloat(-1, -1), BOOL bIsClosed = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Complex Geometry, Destructor of class FOPComplexGeometry
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPComplexGeometry();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Closed, Sets a specify value to current class FOPComplexGeometry
	// Parameters:
	//		bIsClosed---Is Closed, Specifies A Boolean value.
	void SetClosed(BOOL bIsClosed = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClosed() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start, Sets a specify value to current class FOPComplexGeometry
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.
	void MoveTo(const FOPFloat& ptStart);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.
	void LineTo(const FOPFloat& pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier, Adds an object to the specify list.
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.
	void BezierTo(const FOPFloat& pt1, const FOPFloat& pt2, const FOPFloat& pt3);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		szRadius---szRadius, Specifies a const FOPSize szRadius object(Value).  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		dblRotationAngle---Rotation Angle, Specifies a double dblRotationAngle = 0 object(Value).
	void ArcTo(const FOPFloat& pt, const FOPSizeF szRadius, 
		BOOL bIsClockwise = TRUE, BOOL bIsLargeArc = FALSE, double dblRotationAngle = 0);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		nBulge---bulge value.  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	void ArcTo(const FOPFloat& pt, const double &nBulge);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// Parameters:
	//		pt---Specifies A integer value.  
	//		ptEnd---end point.  
	//		bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	void ArcTo(const FOPFloat& ptCtrl, const FOPFloat& ptEnd);
	

	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// Parameters:
	//		arPoints---arPoints, Specifies A integer value.  
	//		curveType---curveType, Specifies a FOP_CURVE_TYPE curveType object(Value).
	void Lines(const FOPointsArray& arPoints, FOP_CURVE_TYPE curveType);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	void Clear();

	// Insert a segment.
	void InsertSeg(const int &nIndex, CFOBaseSegment *pSeg);

	// Obtain segment at a specify index.
	CFOBaseSegment *GetSegAt(const int &nIndex);

	// Remove segemtn at.
	void RemoveSegAt(const int &nIndex);

	// Obtain the count of segments.
	int countSegments() const { return m_arSegments.GetSize(); }


	// Change end segment.
	void SetSegEnd(const int &nIndex, const FOPFloat &ptNewEnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Point, Returns the specified value.
	//		Returns a int type value.
	const FOPFloat& GetStartPoint() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segments, Returns the specified value.
	//		Returns A const CObArray& value (Object).
	const CObArray& GetSegments() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsEmpty() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsNull() const;

	FOPRect rcBound;
protected:
 
	// Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPFloat	m_ptStart;

	// Current last point
	FOPFloat	m_ptLast;
 
	// Segments, This member specify CObArray object.  
	CObArray	m_arSegments;
 
	// Is Closed, This member sets TRUE if it is right.  
	BOOL		m_bIsClosed;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPAryPoints
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPAryPoints object, just call the constructor.
//      O P Array Points
//===========================================================================

class FO_EXT_CLASS FOPAryPoints 
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).
    FOPAryPoints();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		data---Specifies A integer value.
    FOPAryPoints(const FOPAryPoints& data);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
    FOPAryPoints(int nSize);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.
    FOPAryPoints(const FOPPoint& pt1);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.
    FOPAryPoints(const FOPPoint& pt1, const FOPPoint& pt2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.
    FOPAryPoints(const FOPPoint& pt1, const FOPPoint& pt2,
		const FOPPoint& pt3);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.  
	//		pt4---Specifies A integer value.
    FOPAryPoints(const FOPPoint& pt1, const FOPPoint& pt2,
		const FOPPoint& pt3, const FOPPoint& pt4);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.  
	//		pt4---Specifies A integer value.  
	//		pt5---Specifies A integer value.
    FOPAryPoints(const FOPPoint& pt1, const FOPPoint& pt2,
		const FOPPoint& pt3, const FOPPoint& pt4,
					   const FOPPoint& pt5);

	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		CArray<FOPPoint---Array< F O P Point, Specifies A CArray array.  
	//		*ptArray---*ptArray, A pointer to the FOPPoint>  or NULL if the call failed.
	FOPAryPoints(CArray<CPoint, CPoint> *ptArray);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	FOPAryPoints(LPPOINT lpPoints, int nCount);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		CArray<FOPPoint---Array< F O P Point, Specifies A CArray array.  
	//		*ptArray---*ptArray, A pointer to the FOPPoint>  or NULL if the call failed.  
	//		nMaxSize---Maximize Size, Specifies A integer value.
	FOPAryPoints(CArray<CPoint, CPoint> *ptArray, int nMaxSize);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Array Points, Constructs a FOPAryPoints object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		nMaxSize---Maximize Size, Specifies A integer value.
	FOPAryPoints(LPPOINT lpPoints, int nCount, int nMaxSize);
    
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Array Points, Destructor of class FOPAryPoints
	//		Returns A  value (Object).
	virtual ~FOPAryPoints();
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc,  Alloc the specify space for this object.
	// Parameters:
	//		num---Specifies A integer value.
	// Alloc data.
	void Alloc(int num);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clean, .

	// Clean data
    void Clean();

	// Obtain point
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
    FOPPoint get(int nIndex) const;

	// Obtain size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.
	int GetSize() const;

	// Change point
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptPoint---ptPoint, Specifies A integer value.
	void set(int nIndex, const FOPPoint& ptPoint);

	// Change point
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		pt---Specifies a const POINT& pt object(Value).
	void set2(int nIndex, const POINT& pt);

	// Obtain closest point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Closest, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		ptCood---ptCood, Specifies A integer value.  
	//		dDist---dDist, A pointer to the double or NULL if the call failed.  
	//		nIndex---nIndex, A pointer to the int or NULL if the call failed.
    FOPPoint GetClosest(const FOPPoint& ptCood, 
		double* dDist=NULL, int* nIndex=NULL) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dAngle---dAngle, Specifies a double dAngle object(Value).
	// Rotate from center
    void Rotate(FOPPoint ptCenter, double dAngle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		ptFactor---ptFactor, Specifies A integer value.
	// Scale from center
    void Scale(FOPPoint ptCenter, FOPPoint ptFactor);

	// Obtain points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points, Returns the specified value.
	//		Returns a int type value.
	FOPPoint *GetPoints() { return vector; }

	// Obtain the start point arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Arrow Cut Length, Returns the specified value.
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void GetStartArrowCutLength(FOPPoint &ptStart, const int &nArrowLen = 0);
	
	// Obtain the end point arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Arrow Cut Length, Returns the specified value.
	// Parameters:
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void GetEndArrowCutLength(FOPPoint &ptEnd, const int &nArrowLen = 0);
	
	// Obtain new arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Dimension Get Start Arrow Cut Length, .
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&nArrowLength---Arrow Length, Specifies A integer value.
	void FOPDimGetStartArrowCutLength(FOPPoint &ptStart, const CPoint &pt2, const int &nArrowLength);
	
	// Obtain new arrow cut length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Dimension Get End Arrow Cut Length, .
	// Parameters:
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void FOPDimGetEndArrowCutLength(FOPPoint &ptEnd, const CPoint &pt2, const int &nArrowLen);

	// Short start arrow length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Short Start Arrow, .
	// Parameters:
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void ShortStartArrow(const int &nArrowLen);
	
	// Short end arrow length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Short End Arrow, .
	// Parameters:
	//		&nArrowLen---Arrow Len, Specifies A integer value.
	void ShortEndArrow(const int &nArrowLen);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		s---Specifies A integer value.
	// Operator = 
	FOPAryPoints operator = (const FOPAryPoints& s);

protected:
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
    FOPPoint* vector;
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int num;
};

/////////////////////////////////////////////////////////////////////////////////

_FOLIB_INLINE FOPRect operator +(const FOPRect& rc, const FOPPoint& pt)
{
	FOPRect aRect(rc.left + pt.X(), rc.top + pt.Y(), 
		(rc.right == FOP_RECT_EMPTY) ? FOP_RECT_EMPTY : rc.right + pt.X(),
		(rc.bottom == FOP_RECT_EMPTY) ? FOP_RECT_EMPTY : rc.bottom + pt.Y());
	return aRect;
}

_FOLIB_INLINE FOPRect operator -(const FOPRect& rc, const FOPPoint& pt)
{
	FOPRect aRect(rc.left - pt.X(), rc.top - pt.Y(), 
		(rc.right == FOP_RECT_EMPTY) ? FOP_RECT_EMPTY : rc.right - pt.X(),
		(rc.bottom == FOP_RECT_EMPTY) ? FOP_RECT_EMPTY : rc.bottom - pt.Y());
	return aRect;
}

/////////////////////////////////////////////////////////////////////////////////
//
// FOPVectorData,this class is defined for class FOPCompleteWatcher
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPVectorData object, just call the constructor.
//      O P Vector Data
//===========================================================================

class FO_EXT_CLASS FOPVectorData
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Vector Data, Constructs a FOPVectorData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		dX---dX, Specifies a double dX = 0 object(Value).  
	//		dY---dY, Specifies a double dY = 0 object(Value).  
	//		dZ---dZ, Specifies a double dZ = 0 object(Value).
	FOPVectorData(double dX = 0, double dY = 0, double dZ = 0)
	{ V[0] = dX; V[1] = dY; V[2] = dZ; }
	
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Vector Data, Constructs a FOPVectorData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		dZ---dZ, Specifies a double dZ = 0 object(Value).
	FOPVectorData(const FOPPoint& rPnt, double dZ = 0);

	
	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A const double& value (Object).
	// X value
	const double& X() const { return V[0]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A const double& value (Object).
	// Y value
	const double& Y() const { return V[1]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Z, .
	//		Returns A const double& value (Object).
	// Z value
	const double& Z() const { return V[2]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// X, .
	//		Returns A double& value (Object).
	// X value
	double& X() { return V[0]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Y, .
	//		Returns A double& value (Object).
	// Y value.
	double& Y() { return V[1]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Z, .
	//		Returns A double& value (Object).
	// Z value
	double& Z() { return V[2]; }

	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const double& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const double& operator[] (int nPos) const { return V[nPos]; }

	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A double& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	double& operator[] (int nPos) { return V[nPos]; }
	
	// Obtain the length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		void---void
	double	GetLength(void) const;

	// Obtain the XY length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Y Length, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		void---void
	double	GetXYLength(void) const;

	// Obtain the XZ length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Z Length, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		void---void
	double	GetXZLength(void) const;

	// Obtain the YZ length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Z Length, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		void---void
	double	GetYZLength(void) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Normalize, .

	// Normalize the data
	void	Normalize();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimize, .
	// Parameters:
	//		rVec---rVec, Specifies a const FOPVectorData& rVec object(Value).
	// Obtain the minimize value
	void	Min(const FOPVectorData& rVec);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Maximize, .
	// Parameters:
	//		rVec---rVec, Specifies a const FOPVectorData& rVec object(Value).
	// Obtain the maximize value
	void	Max(const FOPVectorData& rVec);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Abs, .

	// Obtain the abs value
	void	Abs();
	
	// Calculate in between two value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate In Between, .
	// Parameters:
	//		vOld1---vOld1, Specifies a const FOPVectorData& vOld1 object(Value).  
	//		vOld2---vOld2, Specifies a const FOPVectorData& vOld2 object(Value).  
	//		t---Specifies a double t object(Value).
	void CalcInBetween(const FOPVectorData& vOld1, const FOPVectorData& vOld2, double t);
	
	// operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData&	operator+=	(const FOPVectorData&);

	// operator -=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData&	operator-=	(const FOPVectorData&);

	// operator +
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData	operator+ 	(const FOPVectorData&) const;

	// operator -
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData	operator-	(const FOPVectorData&) const;

	// operator -
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		void---void
	FOPVectorData	operator-	(void) const;
	
	// operator |=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData&	operator|=	(const FOPVectorData&);

	// operator |
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData	operator|	(const FOPVectorData&) const;
	
	// scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Value, .
	//		Returns A double value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	double ScaleValue(const FOPVectorData&) const;
	
	// operator /=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData&	operator/=	(const FOPVectorData&);

	// operator /
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	FOPVectorData	operator/	(const FOPVectorData&) const;

	// operator  *=
	FOPVectorData&	operator*=	(const FOPVectorData&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	// operator *
	FOPVectorData	operator*	(const FOPVectorData&) const;
	
	// operator *=
	FOPVectorData&	operator*=	(double);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	// operator *
	FOPVectorData	operator*	(double) const;

	// operator /=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	FOPVectorData&	operator/=	(double);

	// operator /
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	FOPVectorData	operator/	(double) const;
	
	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	BOOL		operator==	(const FOPVectorData&) const;

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		FOPVectorData&---O P Vector Data&, Specifies a const FOPVectorData& object(Value).
	BOOL		operator!=	(const FOPVectorData&) const;
	
protected:
	
	// Value of vector data.
 
	// This member specify double object.  
	double		V[3];

};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPString, this is an extend string class.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPString class derived from CString
//      O P String
//===========================================================================

class FO_EXT_CLASS FOPString : public CString
{
protected:
 
	// Decimal Character, This member specify TCHAR object.  
	static TCHAR cDecimalCharacter;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P String, Constructs a FOPString object.
	//		Returns A  value (Object).
	FOPString();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P String, Constructs a FOPString object.
	//		Returns A  value (Object).  
	// Parameters:
	//		sSource---sSource, Specifies A CString type value.
	FOPString::FOPString(LPCTSTR psz);
	FOPString(const CString& sSource);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P String, Constructs a FOPString object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSource---nSource, Specifies A 32-bit LONG signed integer.
	FOPString(LONG nSource);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P String, Constructs a FOPString object.
	//		Returns A  value (Object).  
	// Parameters:
	//		sString---sString, Specifies a const FOPString& sString object(Value).
	FOPString(const FOPString& sString);
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P String, Destructor of class FOPString
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPString();

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPString& value (Object).  
	// Parameters:
	//		sString---sString, Specifies a const FOPString& sString object(Value).
	FOPString& operator=(const FOPString& sString);

//	FOPString& operator=(const CString& sString);

	// Obtain int value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Int, Returns the specified value.
	//		Returns a int type value.
	int GetInt() const;

	static CString number(int number);
	static CString number(double fvalue, int nDot = 2);

	int toInt() const { return GetInt(); }
	
	double toDouble() const;

	// Obtain long value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Long Int, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetLongInt() const;

	// Removes leading white spaces
	
	//-----------------------------------------------------------------------
	// Summary:
	// Trim, .

	void LTrim();

	// Removes trailing white spaces
	
	//-----------------------------------------------------------------------
	// Summary:
	// Trim, .

	void RTrim();


	// Replaces multiple white space characters by one space character
	
	//-----------------------------------------------------------------------
	// Summary:
	// Trim, .

	void XTrim();


	// Whether the string contains only digits (TRUE) or not (FALSE)
	//		Digits are the characters 0 ... 9
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Int, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsInt();

	// Whether the string represents a valid number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Number, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsNumber();

	// Replaces all the vertical bars ('|') in this string
	//   by NULL-characters
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bar To Null, .

	void BarToNull();

	int RemoveFirst();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Trim All, .
	// This member function is a static function.
	// Parameters:
	//		s---Specifies A CString type value.
	static void TrimAll(CString& s);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Alpha Numeric, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		s---Specifies A CString type value.
	static BOOL IsAlphaNumeric(const CString& s);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Numbers, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		s---Specifies A CString type value.
	static BOOL HasNumbers(const CString& s);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Upper, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		s---Specifies A CString type value.
	static BOOL IsAllUpper(const CString& s);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Lower, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		s---Specifies A CString type value.
	static BOOL IsAllLower(const CString& s);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Word Char, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ch---Specifies a TCHAR ch object(Value).
	static BOOL IsWordChar(TCHAR ch);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last Word, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	static CString GetLastWord(const CString& strText);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Word Before Last, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	static CString GetWordBeforeLast(const CString& strText);

	enum EMatchFlag																				// Replace flags
	{																							//
		EMatchFlag_Word			= 1 << 0														// Match whole words only
	,	EMatchFlag_Case			= 1 << 1														// Match case
	,	EMatchFlag_RegExpr		= 1 << 2														// Search string is a regular expression 
	,	EMatchFlag_AllCases		= 1 << 3														// Match all cases
	};

																								
public:	
	
	// @CMEMBER	Finds the specified text while ignoring case
	int		FindNoCase		( const CString&	a_strText
									,		int			a_iStart		= 0		)	const	;	

	// Finds the specified text or it's upper or lower case representation
	int		FindAllCases	( const CString&	a_strText
									,		int			a_iStart		= 0		
									,		BOOL*		a_pbIsUpper		= NULL		
									,		BOOL*		a_pbIsLower		= NULL	)	const	;	

	// Replaces all instances of the find string with the replace string while ignoring the case of the find string
	int		ReplaceNoCase	( const CString&	a_strFind
									, const CString&	a_strReplace			)			;	


	// Replaces all instances of the find string with the replace string for each case (as-is, lower and upper)
	int		ReplaceAllCases	( const CString&	a_strFind
									, const CString&	a_strReplace			)			;	
 
				
public:	

	// Determines whether the string matches the specified search string
	BOOL	Matches			( const CString&	a_strFind		
									,		DWORD		a_dwFlags				)	const	;	
	
	// Finds the specfied text
	int		FindEx			( const CString&	a_strFind				
									,		DWORD		a_dwFlags				)	const	;	

	// Replaces all instances of the find string with the replace string 
	int		ReplaceEx		( const CString&	a_strFind				
									, const CString&	a_strReplace					
									,		DWORD		a_dwFlags				)			;	

};
 
/////////////////////////////////////////////////////////////////////////////////
//
// FOPValData,this class is defined for class FOPCompleteWatcher,
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPValData object, just call the constructor.
//      O P Value Data
//===========================================================================

class FO_EXT_CLASS FOPValData
{
public:

	// Constructor.
	// vPos -- position.
	// vSize -- size
	// bCenter -- center value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value Data, Constructs a FOPValData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		vPos---vPos, Specifies a const FOPVectorData& vPos object(Value).  
	//		vSize---vSize, Specifies a const FOPVectorData& vSize object(Value).  
	//		bCenter---bCenter, Specifies A Boolean value.
	FOPValData(const FOPVectorData& vPos, const FOPVectorData& vSize,
		BOOL bCenter = TRUE);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value Data, Constructs a FOPValData object.
	//		Returns A  value (Object).
	FOPValData();
	
	// Rest the data within the buffer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized FOPValData object.

	void Reset();

	// Is valid or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValid() const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Union, .
	//		Returns A FOPValData& value (Object).  
	// Parameters:
	//		vVol---vVol, Specifies a const FOPValData& vVol object(Value).
	// Union two value.
	FOPValData& Union(const FOPValData& vVol);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Union, .
	//		Returns A FOPValData& value (Object).  
	// Parameters:
	//		vVec---vVec, Specifies a const FOPVectorData& vVec object(Value).
	// Union two data.
	FOPValData& Union(const FOPVectorData& vVec);
	
	// Obtain the min value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Vec, Returns the specified value.
	//		Returns A const FOPVectorData& value (Object).
	const FOPVectorData& GetMinVec() const { return aMinVec; }

	// Obtain the min value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Vec, Returns the specified value.
	//		Returns A FOPVectorData& value (Object).
	FOPVectorData& GetMinVec() { return aMinVec; }
	
	// Obtain the maximize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Vec, Returns the specified value.
	//		Returns A const FOPVectorData& value (Object).
	const FOPVectorData& GetMaxVec() const { return aMaxVec; }

	// Obtain the maximize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Vec, Returns the specified value.
	//		Returns A FOPVectorData& value (Object).
	FOPVectorData& GetMaxVec() { return aMaxVec; }
	
	// Obtain the width value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns A double value (Object).
	double GetWidth()  const { return aMaxVec.X() - aMinVec.X(); }

	// Obtain the height value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns A double value (Object).
	double GetHeight() const { return aMaxVec.Y() - aMinVec.Y(); }

	// Obtain the depth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Depth, Returns the specified value.
	//		Returns A double value (Object).
	double GetDepth()  const { return aMaxVec.Z() - aMinVec.Z(); }

	// Obtain the size value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns A FOPVectorData value (Object).
	FOPVectorData GetSize() const;

	// Is inside.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inside, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rVec---rVec, Specifies a const FOPVectorData& rVec object(Value).
	BOOL IsInside(const FOPVectorData& rVec);
	
	// Operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		rVol---rVol, Specifies a const FOPValData& rVol object(Value).
	void operator=(const FOPValData& rVol)
	{
		aMinVec = rVol.GetMinVec();
		aMaxVec = rVol.GetMaxVec();
	}
	
protected:

	// Minimize value.
 
	// Minimize Vec, This member specify FOPVectorData object.  
	FOPVectorData aMinVec;

	// Maximize value.
 
	// Maximize Vec, This member specify FOPVectorData object.  
	FOPVectorData aMaxVec;
	
};

enum FOPGradientType
{
	FOP_GRADIENT_LINEAR						= 0,
	FOP_GRADIENT_AXIAL						= 1,
	FOP_GRADIENT_RADIAL						= 2,
	FOP_GRADIENT_ELLIPTICAL					= 3,
	FOP_GRADIENT_SQUARE						= 4,
	FOP_GRADIENT_RECT						= 5
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPGradientData, Data of gradient.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPGradientData object, just call the constructor.
//      O P Gradient Data
//===========================================================================

class FO_EXT_CLASS FOPGradientData
{
public:
 
	// Reference Count, This member specify USHORT object.  
	USHORT m_nRefCount;
 
	// Type, This member specify FOPGradientType object.  
	FOPGradientType m_aType;
 
	// Start, This member sets A 32-bit value used as a color value.  
	COLORREF m_crStart;
 
	// End, This member sets A 32-bit value used as a color value.  
	COLORREF m_crEnd;
 
	// Angle, This member specify USHORT object.  
	USHORT m_nAngle;
 
	// Border, This member specify USHORT object.  
	USHORT m_nBorder;
 
	// Offset X, This member specify USHORT object.  
	USHORT m_nOffsetX;
 
	// Offset Y, This member specify USHORT object.  
	USHORT m_nOffsetY;
 
	// Inten Start, This member specify USHORT object.  
	USHORT m_nIntenStart;
 
	// Inten End, This member specify USHORT object.  
	USHORT m_nIntenEnd;
 
	// Step Count, This member specify USHORT object.  
	USHORT m_nStepCount;

	// Image file
	CString m_strImageFile;
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient Data, Constructs a FOPGradientData object.
	//		Returns A  value (Object).
	FOPGradientData();
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient Data, Constructs a FOPGradientData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		axGradientData---Gradient Data, Specifies a const FOPGradientData& axGradientData object(Value).
	FOPGradientData(const FOPGradientData& axGradientData);
};

typedef struct FO_COLORSTOP
{
	float fOffset;
	COLORREF crStop;
	float fOpacity;
	
	FO_COLORSTOP()
	{
		fOffset = 0.0;
		crStop = RGB(255, 255, 255);
		fOpacity = 1.0;
	}
}FO_COLORSTOP;
typedef CArray<FO_COLORSTOP, FO_COLORSTOP> CFOColorStops;
typedef CList<FO_COLORSTOP*, FO_COLORSTOP*> CFOStopElementList;

/////////////////////////////////////////////////////////////////////////////////
//
// FOPGradient, gradient struct
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPGradient object, just call the constructor.
//      O P Gradient
//===========================================================================

class FO_EXT_CLASS FOPGradient
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient, Constructs a FOPGradient object.
	//		Returns A  value (Object).
	FOPGradient();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient, Constructs a FOPGradient object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	FOPGradient(const FOPGradient& aGradient);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient, Constructs a FOPGradient object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aType---aType, Specifies a FOPGradientType aType object(Value).
	FOPGradient(FOPGradientType aType);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient, Constructs a FOPGradient object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aType---aType, Specifies a FOPGradientType aType object(Value).  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.
	FOPGradient(FOPGradientType aType, const COLORREF& crStart, 
		const COLORREF& crEnd);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Gradient, Constructs a FOPGradient object.
	//		Returns A  value (Object).  
	// Parameters:
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		aType---aType, Specifies a FOPGradientType aType = FOP_GRADIENT_LINEAR object(Value).  
	//		nAngle---nAngle, Specifies a USHORT nAngle = 0 object(Value).  
	//		nXOfs---X Ofs, Specifies a USHORT nXOfs = 50 object(Value).  
	//		nYOfs---Y Ofs, Specifies a USHORT nYOfs = 50 object(Value).  
	//		nBorder---nBorder, Specifies a USHORT nBorder = 0 object(Value).  
	//		nStartIntens---Start Intens, Specifies a USHORT nStartIntens = 100 object(Value).  
	//		nEndIntens---End Intens, Specifies a USHORT nEndIntens = 100 object(Value).  
	//		nSteps---nSteps, Specifies a USHORT nSteps = 0 object(Value).
	FOPGradient( const COLORREF& crStart, const COLORREF& crEnd,
		FOPGradientType aType = FOP_GRADIENT_LINEAR, USHORT nAngle = 0,
		USHORT nXOfs = 50, USHORT nYOfs = 50, USHORT nBorder = 0,
		USHORT nStartIntens = 100, USHORT nEndIntens = 100,
			   USHORT nSteps = 0, const CString &strImage = _T("") );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Gradient, Destructor of class FOPGradient
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPGradient();

public:

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns A FOPGradientType value (Object).
	FOPGradientType GetType() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	const COLORREF& GetStartColor() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	const COLORREF& GetEndColor() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetAngle() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetBorder() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ofs X, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetOfsX() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ofs Y, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetOfsY() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Intensity, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetStartIntensity() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Intensity, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetEndIntensity() const;

	// Obtain gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Steps, Returns the specified value.
	//		Returns A USHORT value (Object).
	USHORT GetSteps() const;

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start Color, Sets a specify value to current class FOPGradient
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetStartColor(const COLORREF& crColor);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Color, Sets a specify value to current class FOPGradient
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetEndColor(const COLORREF& crColor);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Angle, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nAngle---nAngle, Specifies a USHORT nAngle object(Value).
	void SetAngle(USHORT nAngle);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nBorder---nBorder, Specifies a USHORT nBorder object(Value).
	void SetBorder(USHORT nBorder);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ofs X, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nOfsX---Ofs X, Specifies a USHORT nOfsX object(Value).
	void SetOfsX(USHORT nOfsX);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ofs Y, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nOfsY---Ofs Y, Specifies a USHORT nOfsY object(Value).
	void SetOfsY(USHORT nOfsY);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start Intensity, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nIntens---nIntens, Specifies a USHORT nIntens object(Value).
	void SetStartIntensity(USHORT nIntens);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Intensity, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nIntens---nIntens, Specifies a USHORT nIntens object(Value).
	void SetEndIntensity(USHORT nIntens);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Steps, Sets a specify value to current class FOPGradient
	// Parameters:
	//		nSteps---nSteps, Specifies a USHORT nSteps object(Value).
	void SetSteps(USHORT nSteps);

	// Change gradient data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class FOPGradient
	// Parameters:
	//		aType---aType, Specifies a FOPGradientType aType object(Value).
	void SetType(FOPGradientType aType);

	// Obtain image file name.
	CString GetImageFile();

	// Set image file name.
	void SetImageFile(const CString &strImage);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Equal, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	// Is equal or not
	BOOL Equal(const FOPGradient& aGradient) const;

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPGradient& value (Object).  
	// Parameters:
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	FOPGradient& operator=(const FOPGradient& aGradient);

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	BOOL operator==(const FOPGradient& aGradient) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	BOOL operator!=(const FOPGradient& aGradient) const
	{
		return !(FOPGradient::operator == (aGradient));
	}

	// Obtain stops.
	CFOColorStops *GetStops() { return &maStops; }

	// Update stops.
	void UpdateStops(CFOColorStops *pUpdate);

protected:  

	// Pointer of data.
 
	// Gradient Data, This member maintains a pointer to the object FOPGradientData.  
	FOPGradientData* m_aGradientData;

	CFOColorStops maStops;
	// Make unique.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Unique, .

	void BeUnique();
	
};

struct foExportOptions {
	int treeOption;
	int htmlOutOption;
	int navOption;
	int imgOption;
	int textOption;
	CString prfIndex;
	CString prfNet;
	CString prfToc;
	CString prfTextSingle;
	CString prfTextEverynode;
	CString pathIndex;
	CString pathTextSingle;
	CString pathNetwork;
	CString pathOutline;
	CString pathSvg;
	CString pathPng;
	CString htmlOutDir;
};

class FO_EXT_CLASS FOPHtmlWriter
{
public:
	FOPHtmlWriter();
	~FOPHtmlWriter();
	
	static void CreateFrame(CStdioFile& f, const CString& title, const CString& keystr, const foExportOptions& options);
	
	static void WriteOutlineStart(CStdioFile& olf, const CString& keystr, const CString& rootStr, const foExportOptions& options);
	static void WriteOutline(const CString& keyStr, const CString& itemStr, CStdioFile& olf, const foExportOptions& options);
	static void WriteOutlineEnd(CStdioFile& f);
	static CString RemoveCr(const CString &target);
	static void WriteBodyStart(CStdioFile& f);
	static void WriteBodyEnd(CStdioFile& f);
	static CString Parse(const CString& text);
	static void UlStart(CString& str, int& level, int& prevLevel);
	static void UlEnd(CString& str, int& level);
	static CString CreateInlineUrlLink(const CString& line);
	static void WriteHtmlHeader(CStdioFile& f);
	static void WriteTextStyle(CStdioFile& f, bool single = true);
	
	static void WriteSubTree(CStdioFile& olf, const CString& keystr, const CString& label, const foExportOptions& options);
	
	static void WriteSvgNetwork(CStdioFile& f, const CPoint& maxPt, const CString& pathSvg);
	static void WritePngNetworkStart(CStdioFile& nf, const CString& pathPng);
	static void WritePngNetworkEnd(CStdioFile& nf);
	
	static void WriteText(CStdioFile& f, const CString& keyStr, const CString& label, const CString& text);
	static void BuildLinkTo(CString& strLinks, const CString& keyStr, bool textIsolated, const CString& nodeLabel,
		const CString& linkLabel, const CString& textPrefix);
	static void BuildLinkFrom(CString& strLinks, const CString& keyStr, bool textIsolated, const CString& nodeLabel, 
		const CString& linkLabel, const CString& textPrefix);
	static void BuildUrlLink(CString& strLinks, const CString& url, const CString& label);
	static void WriteLinks(CStdioFile& f, const CString& strLinks);
	
	static void WriteChildrenStart(CStdioFile& f);
	static void WriteSiblingStart(CStdioFile& f);
	static void WriteSiblingEnd(CStdioFile& f);
};

#define FOP_MAX_ENUM 0x7fffffff

/////////////////////////////////////////////////////////////////////////////

// ------------------------------------------------------------------

#ifdef __cplusplus
_FOLIB_INLINE int FOPMin(int a, int b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE float FOPMin2(float a, float b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE double FOPMin(double a, double b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE int FOPMax(int a, int b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE char FOPMin(char a, char b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE char FOPMax(char a, char b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE BYTE FOPMin(BYTE a, BYTE b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE BYTE FOPMax(BYTE a, BYTE b)
{
	return (a > b ? a : b);
}

_FOLIB_INLINE float FOPMax(float a, float b)
{
	return (a > b ? a : b);
}

_FOLIB_INLINE double FOPMax(double a, double b)
{
	return (a > b ? a : b);
}

_FOLIB_INLINE short FOPMin(short a, short b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE short FOPMax(short a, short b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE USHORT FOPMin(USHORT a, USHORT b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE USHORT FOPMax(USHORT a, USHORT b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE UINT FOPMax_New(UINT a, UINT b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE long FOPMin(long a, long b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE long FOPMax(long a, long b)
{
	return (a > b ? a : b);
}
_FOLIB_INLINE ULONG FOPMin(ULONG a, ULONG b)
{
	return (a < b ? a : b);
}
_FOLIB_INLINE ULONG FOPMax(ULONG a, ULONG b)
{
	return (a > b ? a : b);
}

_FOLIB_INLINE char FOPAbs(char a)
{
	return (char)(a >= 0 ? a : -a);
}
_FOLIB_INLINE int FOPAbs(int a)
{
	return (a >= 0 ? a : -a);
}

_FOLIB_INLINE double FOPAbs(double a)
{
	return (a >= 0 ? a : -a);
}
_FOLIB_INLINE double FOPAtof(LPCTSTR string)
{
	TCHAR   *stopstring;
	return _tcstod(string,&stopstring);
}

_FOLIB_INLINE BOOL FOPEqual(double value1,double value2,double delta)
{
	return ((value1==value2)||( fabs(value1-value2)<fabs(delta)));
}


template <typename T>
inline T fpAbs(const T &t) { return t >= 0 ? t : -t; }

template <typename T>
inline const T &fpMin(const T &a, const T &b) { if (a < b) return a; return b; }

template <typename T>
inline const T &fpMax(const T &a, const T &b) { if (a < b) return b; return a; }

static inline bool FOPCompare(float p1, float p2)
{
    return fpAbs(p1 - p2) < 0.00001;
}

static inline bool FOPCompare(double p1, double p2)
{
    return fpAbs(p1 - p2) < 0.00001;
}
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPUTIL_H__552B6457_FF85_4CDA_AD87_59DF7F79A9E1__INCLUDED_)
