//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPFRACTION_H__8FBD6B81_261F_4605_B9B7_DCF5CEA75391__INCLUDED_)
#define AFX_FOPFRACTION_H__8FBD6B81_261F_4605_B9B7_DCF5CEA75391__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPFraction.h : header file
//

/////////////////////////////////////////////////////////////////////////////////
//
// FOPFraction,this class is defined for fraction calculate,you can use it with the following sample like:
//  FOPFraction num(1,2);
// 	FOPFraction num1(3,4);
// 	double dReturn = num * num1;
//  the dReturn will return 3/8,it means it will be 0.37500000
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPFraction object, just call the constructor.
//      O P Fraction
//===========================================================================

class FO_EXT_CLASS FOPFraction
{
protected:

	// Numerator value.
 
	// Numerator, Specify a A 32-bit signed integer.  
	long	m_nNumerator;

	// Denominator value.
 
	// Denominator, Specify a A 32-bit signed integer.  
	long	m_nDenominator;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Fraction, Constructs a FOPFraction object.
	//		Returns A  value (Object).
	FOPFraction();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Fraction, Constructs a FOPFraction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aVal---aVal, Specifies a const FOPFraction& aVal object(Value).
	FOPFraction(const FOPFraction& aVal);

	// Constructor.
	// nNum -- value of the numerator.
	// nDen -- value of the denominator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Fraction, Constructs a FOPFraction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nNum---nNum, Specifies A 32-bit long signed integer.  
	//		nDen---nDen, Specifies A 32-bit long signed integer.
	FOPFraction(long nNum, long nDen = 1);

	// Constructor.
	// nN1 -- first numerator value.
	// nN2 -- second numerator value.
	// nD1 -- first denominator value.
	// nD2 -- second denominator value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Fraction, Constructs a FOPFraction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nN1---nN1, Specifies A 32-bit long signed integer.  
	//		nN2---nN2, Specifies A 32-bit long signed integer.  
	//		nD1---nD1, Specifies A 32-bit long signed integer.  
	//		nD2---nD2, Specifies A 32-bit long signed integer.
	FOPFraction(long nN1, long nN2, long nD1, long nD2);

	// Constructor.
	// dVal -- value for denominator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Fraction, Constructs a FOPFraction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		dVal---dVal, Specifies a double dVal object(Value).
	FOPFraction(double dVal);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Fraction, Destructor of class FOPFraction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPFraction() {}

	// Is it valid value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValid() const;

	// Obtain the numerator value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Numerator, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetNumerator() const	{	return m_nNumerator;	}

	// Obtain the denominator value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Denominator, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetDenominator() const	{	return m_nDenominator;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operators that convert to long.
	operator		long() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A operator value (Object).
	// Operator that convert to double.
	operator		double() const;

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPFraction& value (Object).  
	// Parameters:
	//		val---Specifies a const FOPFraction& val object(Value).
	FOPFraction& operator=(const FOPFraction& val);

	// Operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPFraction& value (Object).  
	// Parameters:
	//		val---Specifies a const FOPFraction& val object(Value).
	FOPFraction& operator+=(const FOPFraction& val);

	// Operator -=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPFraction& value (Object).  
	// Parameters:
	//		val---Specifies a const FOPFraction& val object(Value).
	FOPFraction& operator-=(const FOPFraction& val);

	// Operator *=
	FOPFraction& operator*=(const FOPFraction& val);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPFraction& value (Object).  
	// Parameters:
	//		val---Specifies a const FOPFraction& val object(Value).

	// Operator /=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPFraction& value (Object).  
	// Parameters:
	//		val---Specifies a const FOPFraction& val object(Value).
	FOPFraction& operator/=(const FOPFraction& val);

	// Correct the sign.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Value, .
	// Parameters:
	//		nBits---nBits, Specifies a unsigned nBits object(Value).
	void CorrectValue(unsigned nBits);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPFraction value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   FOPFraction operator+(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPFraction value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   FOPFraction operator-(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPFraction value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   FOPFraction operator*(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A friend _FOLIB_INLINE   FOPFraction value (Object).  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   FOPFraction operator/(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator<=(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator>=(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend _FOLIB_INLINE   BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend _FOLIB_INLINE   BOOL operator!=(const FOPFraction& value1, const FOPFraction& value2);

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend  		BOOL operator==(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend  		BOOL operator<(const FOPFraction& value1, const FOPFraction& value2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns friend    BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value1---Specifies a const FOPFraction& value1 object(Value).  
	//		value2---Specifies a const FOPFraction& value2 object(Value).
	friend  		BOOL operator>(const FOPFraction& value1, const FOPFraction& value2);	
};

_FOLIB_INLINE FOPFraction operator+(const FOPFraction& value1, const FOPFraction& value2)
{
	FOPFraction aErg(value1);
	aErg += value2;
	return aErg;
}

_FOLIB_INLINE FOPFraction operator-(const FOPFraction& value1, const FOPFraction& value2)
{
	FOPFraction aErg(value1);
	aErg -= value2;
	return aErg;
}

_FOLIB_INLINE FOPFraction operator*(const FOPFraction& value1, const FOPFraction& value2)
{
	FOPFraction aErg(value1);
	aErg *= value2;
	return aErg;
}

_FOLIB_INLINE FOPFraction operator/(const FOPFraction& value1, const FOPFraction& value2)
{
	FOPFraction aErg(value1);
	aErg /= value2;
	return aErg;
}

_FOLIB_INLINE BOOL operator !=(const FOPFraction& value1, const FOPFraction& value2)
{
	return !(value1 == value2);
}

_FOLIB_INLINE BOOL operator <=(const FOPFraction& value1, const FOPFraction& value2)
{
	return !(value1 > value2);
}

_FOLIB_INLINE BOOL operator >=(const FOPFraction& value1, const FOPFraction& value2)
{
	return !(value1 < value2);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPFRACTION_H__8FBD6B81_261F_4605_B9B7_DCF5CEA75391__INCLUDED_)
