//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBitmap.h: interface for the CFOBitmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBITMAP_H__900D5BB3_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FOBITMAP_H__900D5BB3_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOIUnknown.h"
#include "FOActionStack.h"
#include "FOPExportImageFile.h"

/////////////////////////////////////////////////////////////////////////////
// CFOBitmap window

#define DS_BITMAP_FILEMARKER  ((WORD) ('M' << 8) | 'B')    // is always "BM" = 0x4D42

/////////////////////////////////////////////////////////////////////////////
// BITMAPINFO wrapper

struct FOP_DIBINFO : public BITMAPINFO
{
	RGBQUAD	 arColors[255];

	operator LPBITMAPINFO()          { return (LPBITMAPINFO) this; }
	operator LPBITMAPINFOHEADER()    { return &bmiHeader;          }
	RGBQUAD* ColorTable()            { return bmiColors;           }
};

/////////////////////////////////////////////////////////////////////////////
// LOGPALETTE wrapper

struct FOP_PALETTEINFO : public LOGPALETTE
{
    PALETTEENTRY arPalEntries[255];               // Palette entries

    FOP_PALETTEINFO() 
    {
        palVersion    = (WORD) 0x300;
        palNumEntries = 0;
        ::memset(palPalEntry, 0, 256*sizeof(PALETTEENTRY)); 
    }

    operator LPLOGPALETTE()   { return (LPLOGPALETTE) this;            }
    operator LPPALETTEENTRY() { return (LPPALETTEENTRY) (palPalEntry); }
};


#define FOP_TYPE_EMF  0
#define FOP_TYPE_WMF  1

#pragma pack(1)
class    FOP_PMFILEHEADER
{
public:
	DWORD    m_key;
	WORD     m_hmf;
	short    m_bboxLeft;
	short    m_bboxTop;
	short    m_bboxRight;
	short    m_bboxBottom;
	WORD     m_inch;
	DWORD    m_reserved;
	WORD     m_checksum;
};

#pragma pack(8)

/////////////////////////////////////////////////////////////////////////////
// FOPMetafile wrapper

class FO_EXT_CLASS FOPMetafile  
{
public:
	// Consulting.
	FOPMetafile();
	
	// Consulting.
	FOPMetafile(const FOPMetafile& source);
	
	// Consulting.
	FOPMetafile(HMETAFILE hmf);
	
	// Consulting.
	FOPMetafile(HENHMETAFILE hemf);
	
	// Destructor
	virtual ~FOPMetafile();
	
	// Operator.
	const FOPMetafile& FOPMetafile::operator=(const FOPMetafile& source); 
	
	// Remove data
	BOOL RemoveData();
	
	// Serialize
	virtual void Serialize(CArchive& ar);
	
	// Load meta file
	BOOL LoadMetafile(const CString& strFile);
	
	// Draw
	BOOL Draw(CDC* pDC, const CRect& rcDraw);
	
	// Obtain emf pointer.
	ENHMETAHEADER GetEMFPtr()const{ return m_header;}
	
	// Obtain bits
	const void* GetBits()const{ return m_ptrBits;}
	
	// Get meta file
	HMETAFILE GetMetafile( CString szFileName, FOP_PMFILEHEADER&    APMHeader);
	
	// Convert emf from wmf
	HENHMETAFILE ConvertWMFtoEMF(HMETAFILE hwmf);
	
	// Obtain width
	int GetWidth() const;
	
	// Obtain height.
	int GetHeight() const;
	
	// Create meta file.
	HENHMETAFILE CreateMetafile();
	
	// Obtain buffer size.
	LONG GetBufferSize()const{ return m_lBufferSize;}
	
protected: 
	
	// EMF Header
	ENHMETAHEADER m_header;
	
	// Datas
	LPVOID m_ptrBits;
	
	// Buffer size.
	LONG m_lBufferSize;
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOBitmap

#define FOP_BMP_MIRROR_NONE				0x00000000UL
#define FOP_BMP_MIRROR_HORZ				0x00000001UL
#define FOP_BMP_MIRROR_VERT				0x00000002UL

 
//===========================================================================
// Summary:
//     The CFOBitmap class derived from CObject
//      F O Bitmap
//===========================================================================

class FO_EXT_CLASS CFOBitmap : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBitmap---F O Bitmap, Specifies a E-XD++ CFOBitmap object (Value).
	DECLARE_SERIAL(CFOBitmap)
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap, Constructs a CFOBitmap object.
	//		Returns A  value (Object).
	CFOBitmap();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bitmap, Destructor of class CFOBitmap
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBitmap();

public:
	// Save document,this method will save the image data to a specify file,if you want to save it to 
	// bitmap image file type,please use Save(..) method instead of
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document,this method will open a specify data file,if you want to load a bitmap image file,please
	// use Read(..) method instead of.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    virtual void Serialize(CArchive &ar);

	// Load bitmap image from file.
	// strFileName -- file name of the bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
    virtual BOOL Read(CString strFileName);

	// Load emf or wmf from file.
	// strFileName -- file name of wmf or emf
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Meta File, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL ReadMetaFile(CString strFileName);

	// Load bitmap.
	BOOL LoadBitmap(UINT nResourceID);

	// Load bitmap.
	BOOL LoadBitmap(LPCTSTR szFileName);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	// Save image to file.
	// strFileName -- file name of the bitmap.
    virtual BOOL Save(CString strFileName);

	// Save file to jpeg format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save To Jpeg, Call this function to save the specify data to a file.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pszPath---pszPath, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL SaveToJpeg(LPCTSTR pszPath);

	// Save file to jpeg format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save To Jpeg, Call this function to save the specify data to a file.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.
	BOOL SaveToJpeg(CFile* pFile);

	// Is color RGB data valid or not,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsValidate() const 
		{ return (m_lpBMI != NULL); }

	// Init image data.
	// nWidth -- width of the image.
	// nHeight -- height  of the image.
	// nBPP -- bitmap bits number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial New, Call InitNew after creating a new object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		nBPP---B P P, Specifies A integer value.  
	//		bPng---bPng, Specifies A Boolean value.
	BOOL InitNew(int nWidth, int nHeight, int nBPP,BOOL bPng = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOBitmap object.

	// Reset all the data of the image.
	void Reset();

public:

	// Get image width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    DWORD			GetWidth();

	// Get image height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    DWORD			GetHeight();

	// Get image width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width Extend, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    DWORD			GetWidthExt();

	// Get image height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height Extend, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    DWORD			GetHeightExt();
	
	// Get number colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Clr Entries, Returns the specified value.
	//		Returns A 16-bit unsigned integer.
	WORD			GetNumClrEntries();

	// Convert to CBitmap.
	CBitmap *GetBitmap();
	
	// Create a copy from a specify bitmap data.
	// pBitmap -- pointer of the bitmap for copying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Backup, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pBitmap---*pBitmap, A pointer to the CFOBitmap  or NULL if the call failed.
    BOOL			Backup(CFOBitmap *pBitmap);

	// Build a new image.
	// pBitmap -- pointer of the bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Image, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pBitmap---*pBitmap, A pointer to the CFOBitmap  or NULL if the call failed.
    BOOL			BuildImage(CFOBitmap *pBitmap);
	
	// Create from CBitmap.
	// pDC -- pointer of the DC.
	// pBitmap -- pointer of the bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make New Bitmap, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pBitmap---*pBitmap, A pointer to the CBitmap  or NULL if the call failed.
	BOOL			MakeNewBitmap(CDC *pDC, CBitmap *pBitmap);  

	// Create to bitmap.
	// lpszFile -- bitmap file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Bitmap, .
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		*lpszFile---*lpszFile, A pointer to the const TCHAR  or NULL if the call failed.
    CBitmap*		ConvertToBitmap(const TCHAR *lpszFile);

	// Create bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Bitmap, .
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
    CBitmap*		CreateDDB(CDC *pDC);

	// Create rgn form bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Rgn From Bitmap, You construct a CFOBitmap object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HRGN value (Object).  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	HRGN			CreateRgnFromBitmap(CDC *pDC,COLORREF color);

	// Replace color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Color, .
	// This member function is a static function.
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		hBmp---hBmp, Specifies a HBITMAP hBmp object(Value).  
	//		cOldColor---Old Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		cNewColor---New Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		hBmpDC---Bitmap D C, Specifies a HDC hBmpDC object(Value).
	static HBITMAP	ReplaceColor(HBITMAP hBmp,COLORREF cOldColor,COLORREF cNewColor,HDC hBmpDC);

	// Copy wnd to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Window To Clipboard, Create a duplicate copy of this object.
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void			CopyWndToClipboard( CWnd *pWnd );

	// Flip vertical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flip V, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			FlipV();

	// Flip horizontal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flip H, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			FlipH();

	// Rotate image with 90 degree
	// bClockWise -- with clock wise or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate90, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bClockwise---&bClockwise, Specifies A Boolean value.
	BOOL			Rotate90(const BOOL &bClockwise);

	// Rotate image with 270 degree
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate270, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			Rotate270();

	// Constrast image.
	BOOL ContrastImage(short nShar);

	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nAngle10---nAngle10, Specifies A 32-bit long signed integer.  
	//		crFill---crFill, Specifies A 32-bit COLORREF value used as a color value.
	// Rotate freely
	// nAngle10 -- from 0 - 3599
	// crFill -- fill color when its 16,24,32 bits,it will use this color fill,
	// else it will use black instead of
	BOOL			Rotate( long nAngle10, const COLORREF& crFill );

	// Make mono
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Mono, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cThreshold---cThreshold, Specifies An 8-bit BYTE integer that is not signed.
	BOOL			MakeMono( BYTE cThreshold );

	//-----------------------------------------------------------------------
	// Summary:
	// Invert, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Invert bitmap.
	BOOL			Invert();

	// Replace color bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Color New, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&crNew---&crNew, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crOld---&crOld, Specifies A 32-bit COLORREF value used as a color value.
	BOOL			ReplaceColorNew(const COLORREF &crNew,const COLORREF &crOld);

	// Obtain the pixel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pixel Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.
	COLORREF GetPixelColor(long x,long y);

	// Obtian the pixel index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pixel Index, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.  
	// Parameters:
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.
	BYTE	GetPixelIndex(long x,long y);

	// Change pixel color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pixel Color, Sets a specify value to current class CFOBitmap
	// Parameters:
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.  
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetPixelColor(long x,long y,COLORREF cr);

	// Change pixel index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pixel Index, Sets a specify value to current class CFOBitmap
	// Parameters:
	//		x---Specifies A 32-bit long signed integer.  
	//		y---Specifies A 32-bit long signed integer.  
	//		i---Specifies An 8-bit BYTE integer that is not signed.
	void	SetPixelIndex(long x,long y,BYTE i);

	// Obtain nearest index color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Index, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.  
	// Parameters:
	//		c---Specifies a RGBQUAD c object(Value).
	BYTE GetNearestIndex(RGBQUAD c);

	// Convert to 24 bits.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To24 Bits, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			ConvertTo24Bits();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nLuminancePercent---Luminance Percent, Specifies a short nLuminancePercent = 0 object(Value).  
	//		nContrastPercent---Contrast Percent, Specifies a short nContrastPercent = 0 object(Value).  
	//		nChannelRPercent---Channel R Percent, Specifies a short nChannelRPercent = 0 object(Value).  
	//		nChannelGPercent---Channel G Percent, Specifies a short nChannelGPercent = 0 object(Value).  
	//		nChannelBPercent---Channel B Percent, Specifies a short nChannelBPercent = 0 object(Value).  
	//		fGamma---fGamma, Specifies a double fGamma = 10.0 object(Value).  
	//		bInvert---bInvert, Specifies A Boolean value.
	// Adjust the color of the bitmap.
	BOOL Adjust( short nLuminancePercent = 0,	// From -100 -- 100
				 short nContrastPercent = 0,	// From -100 -- 100
				 short nChannelRPercent = 0,	// From -100 -- 100
				 short nChannelGPercent = 0,	// From -100 -- 100
				 short nChannelBPercent = 0,	// From -100 -- 100
				 double fGamma = 10.0,			// From 0 -- 100.00
				 BOOL bInvert = FALSE );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMirrorFlags---Mirror Flags, Specifies A 32-bit LONG signed integer.
	// Mirror the bitmap.
	// nMirrorFlags -- it must be one of the following value:FOP_BMP_MIRROR_NONE,FOP_BMP_MIRROR_HORZ,FOP_BMP_MIRROR_VERT
	BOOL			Mirror( ULONG nMirrorFlags );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Crop, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rRectPixel---Rectangle Pixel, Specifies A CRect type value.
	// Crop image.
	BOOL			Crop( const CRect& rRectPixel );

	// Obtain the color table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color Table, Returns the specified value.
	//		Returns a pointer to the object RGBQUAD ,or NULL if the call failed
	RGBQUAD *		GetColorTable() { return m_lpData; }

	// Obtain the color table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color Table, Returns the specified value.
	//		Returns a pointer to the object const RGBQUAD ,or NULL if the call failed
	const RGBQUAD *	GetColorTable() const { return m_lpData; }

	//	Get the line array for this image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Array, Returns the specified value.
	// Parameters:
	//		&arr---A pointer to the CFOArray< BYTE  or NULL if the call failed.
	void			GetLineArray( CFOArray< BYTE * > &arr );

	// Get the line array of the image data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Array, Returns the specified value.
	// Parameters:
	//		&arr---A pointer to the CFOArray< const BYTE  or NULL if the call failed.
	void			GetLineArray( CFOArray< const BYTE * > &arr ) const;
	
	// When ending load the image call these method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// K End, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			OKEnd();

	// Obtain the size of the bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size Bytes, Returns the specified value.
	//		Returns A 32-bit LONG signed integer.
    LONG            GetSizeBytes();

	// Obtain the bit count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bit Count, Returns the specified value.
	//		Returns a UINT type value.
	UINT            GetBitCount() const;

	// Do jpeg compress.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do J P E G Compress, Do a event. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pszBMPFile---B M P File, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		pszJPGFile---J P G File, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	static BOOL DoJPEGCompress(LPCTSTR pszBMPFile, LPCTSTR pszJPGFile);

	// Do jpeg compress.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do J P E G Compress, Do a event. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pBMPFile---B M P File, A pointer to the CFOPJpegToBMPFile or NULL if the call failed.  
	//		pJPGFile---J P G File, A pointer to the CFOPJpegSaveFile or NULL if the call failed.
	static BOOL DoJPEGCompress(CFOPJpegToBMPFile* pBMPFile, CFOPJpegSaveFile* pJPGFile);

	// Convert from meta file.
	void DoLoadMetaFile(CDC *pDC,FOPMetafile *pFile,
		int nWidth,int nHeight,COLORREF crTrans);

	// Create from CFOBitmap.
	BOOL LoadMetaFile(const CString &strFile);
	
	// Create from specify bitmap object.
	BOOL CreateFromBitmap(CBitmap *pBmp);

public:
	
	// Draw image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stretch, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		XDest---Dest, Specifies A integer value.  
	//		YDest---Dest, Specifies A integer value.  
	//		cxDest---cxDest, Specifies A integer value.  
	//		cyDest---cyDest, Specifies A integer value.  
	//		XSrc---Source, Specifies A integer value.  
	//		YSrc---Source, Specifies A integer value.  
	//		cxSrc---cxSrc, Specifies A integer value.  
	//		cySrc---cySrc, Specifies A integer value.  
	//		dwType---dwType, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual int  Stretch(CDC *pDC, int XDest, int YDest, 
		int cxDest, int cyDest,
		int XSrc, int YSrc,
		int cxSrc, int cySrc, DWORD dwType);

	// Draw part of image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Simple, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcDest---rcDest, Specifies A CRect type value.  
	//		rcSrc---rcSrc, Specifies A CRect type value.
	BOOL DrawSimple(CDC* pDC, const CRect& rcDest, const CRect& rcSrc);
	
	// Draw image with tile
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Tile, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcDest---rcDest, Specifies A CRect type value.  
	//		rcSrc---rcSrc, Specifies A CRect type value.  
	//		bTile---bTile, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL DrawTile(CDC* pDC, const CRect& rcDest, const CRect& rcSrc, UINT bTile);

	// Draw image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Stretch, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		XDest---Dest, Specifies A integer value.  
	//		YDest---Dest, Specifies A integer value.  
	//		cxDest---cxDest, Specifies A integer value.  
	//		cyDest---cyDest, Specifies A integer value.  
	//		XSrc---Source, Specifies A integer value.  
	//		YSrc---Source, Specifies A integer value.  
	//		cxSrc---cxSrc, Specifies A integer value.  
	//		cySrc---cySrc, Specifies A integer value.  
	//		dwType---dwType, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void  ExtStretch(CDC *pDC, int XDest, int YDest, 
		int cxDest, int cyDest,
		int XSrc, int YSrc,
		int cxSrc, int cySrc, DWORD dwType);

	// Clear all data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Object, Deletes the given object.
	
	void DeleteObject();

protected:

	
	// Init image data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Image, Call InitImage after creating a new object.

	void InitImage();

	// Load image data from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image Data, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.
	virtual BOOL LoadImageData(CFile* pFile);

	// End load.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Load, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    virtual BOOL EndLoad();

	// Create palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Palette, You construct a CFOBitmap object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    virtual BOOL CreatePalette();

	// Get bytes per line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Bytes, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		wBits---wBits, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		wWidth---wWidth, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetLineBytes(DWORD wBits, DWORD wWidth);

	// Has been load.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Been Load, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasBeenLoad();

	// Pad
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Pad Bits, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL DoPadBits();  
	
	// Reload pad bits.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reload Pad Bits, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL ReloadPadBits();

	// Calc
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Line, .
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwBits---dwBits, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwPixels---dwPixels, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD CalcExtLine(DWORD dwBits, DWORD dwPixels) const;

	// Correct pixel value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Value, .
	//		Returns a int type value.  
	// Parameters:
	//		x---Specifies A integer value.
	int CorrectValue(int x);

	// Obtain bitmap bits
	LPVOID GetDataBits() const;

public:
	// Pre Multipled alpha
	BOOL PreAlpha(HBITMAP hbmp, BOOL bAutoCheckPremlt);

#ifdef _DEBUG

	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif //_DEBUG

public:

	// Data buffer.
 
	// Buffer, This member sets An 8-bit integer that is not signed.  
	LPBYTE			m_lpBuf;

	// Bitmap information.
 
	// B M I, This member specify LPBITMAPINFO object.  
    LPBITMAPINFO	m_lpBMI;
	
	// Color palette
 
	// Palette, This member maintains a pointer to the object CPalette.  
    CPalette*		m_hPalette;

	// Save palette.
 
	// Old Palette, This member maintains a pointer to the object CPalette.  
	CPalette *		m_hOldPalette;

	// Color table.
 
	// Data, This member specify LPRGBQUAD object.  
    LPRGBQUAD		m_lpData;

	// Per meter.
 
	// X Pels Per Meter, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT32			nXPelsPerMeter;

	// Per meter.
 
	// Y Pels Per Meter, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT32			nYPelsPerMeter;

	// Alpha
	BOOL			m_bAlpha;

	// Image list.
	CBitmap		*m_curImageList;

protected:

	// Use DrawDib routines for dithering?
 
	// Dither, This member sets TRUE if it is right.  
	BOOL			m_bDither;

	//
 
	// Source Bits, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSourceBits;

	// Current open file list.
 
	// File List, This member specify CPtrList object.  
	CPtrList		m_FileList;

	// Image width.
 
	// Width, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD			m_dwWidth;

	// Image height.
 
	// Height, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
    DWORD			m_dwHeight;

	//
 
	// System Bits, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSysBits;

	// Has been load.
 
	// Has Been Load, This member sets TRUE if it is right.  
    BOOL			m_bHasBeenLoad;

	//
 
	// Pad, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
    DWORD			m_dwPad; 

	// Current file pointer.
 
	// This member maintains a pointer to the object CFile.  
	CFile*			m_fp;

	// Images colors.
 
	// Image Colors, Specify A 16-bit unsigned integer.  
	WORD			m_wImageColors;

	// Custom.
 
	// Custom, Specify A 16-bit unsigned integer.  
    WORD			m_wCustom;

	// File length.
 
	// Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLength;

	// Handle to DIBSECTION
 
	// Bitmap, This member specify HBITMAP object.  
	HBITMAP			m_hBitmap;

	// Storage for previous bitmap in Memory DC
 
	// Old Bitmap, This member specify HBITMAP object.  
	HBITMAP			m_hOldBitmap;

	// Bitmap header & color table info
 
	// D I Binfo, This member specify FOP_DIBINFO object.  
    FOP_DIBINFO		m_DIBinfo;

	// Image size.
 
	// Image Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_dwImageSize;

};

 
//===========================================================================
// Summary:
//      To use a CFOPNewBitmap object, just call the constructor.
//      F O P New Bitmap
//===========================================================================

class FO_EXT_CLASS CFOPNewBitmap  
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Bitmap, Constructs a CFOPNewBitmap object.
	//		Returns A  value (Object).
	CFOPNewBitmap();
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Bitmap, Constructs a CFOPNewBitmap object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Source, Specifies a const CFOPNewBitmap& Src object(Value).
	CFOPNewBitmap(const CFOPNewBitmap& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Bitmap, Constructs a CFOPNewBitmap object.
	//		Returns A  value (Object).  
	// Parameters:
	//		daData---Dib Data, A pointer to the const BYTE or NULL if the call failed.  
	//		nLen---Data Length, Specifies A 32-bit LONG signed integer.
	CFOPNewBitmap(const BYTE* daData, ULONG nLen);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Bitmap, Destructor of class CFOPNewBitmap
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewBitmap();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// Parameters:
	//		bitmap---A pointer to the BITMAP or NULL if the call failed.
	void GetBitmap(BITMAP* bitmap) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save As D I B, Call this function to save the specify data to a file.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		szFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL SaveAsDIB(LPCTSTR strFile);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap Bits, Returns the specified value.
	//		Returns A LPVOID value (Object).
	LPVOID GetDataBits() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns A 32-bit LONG signed integer.
	LONG GetSize() const;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const CFOPNewBitmap& value (Object).  
	// Parameters:
	//		source---Source, Specifies a const CFOPNewBitmap& Src object(Value).
	const CFOPNewBitmap& operator=(const CFOPNewBitmap& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const CFOPNewBitmap& value (Object).  
	// Parameters:
	//		source---Source, Specifies a const BITMAP& Src object(Value).
	const CFOPNewBitmap& operator=(const BITMAP& source);
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Monocrome, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMonocrome();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mono Colors, Sets a specify value to current class CFOPNewBitmap
	// Parameters:
	//		crBack---B G, Specifies A 32-bit COLORREF value used as a color value.  
	//		crFront---F G, Specifies A 32-bit COLORREF value used as a color value.
	void SetMonoColors(COLORREF crBack, COLORREF crFront);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lBits---Bits Pixel, Specifies A 32-bit long signed integer.
	BOOL ConvertTo(long lBits);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pixels Offset, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetPixelsOffset();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Bitmap, You construct a CFOPNewBitmap object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hbitmap---hBmp, Specifies a HBITMAP hBmp object(Value).
	BOOL CreateFromBitmap(HBITMAP hbitmap);

	// Create from file.
	BOOL Load(const CString &strFile);

	// Create from meta file.
	BOOL LoadMetaFile(const CString &strFile);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Bitmap, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nDestX---Dest X, Specifies A 32-bit long signed integer.  
	//		nDestY---Dest Y, Specifies A 32-bit long signed integer.  
	//		nSrcX---Source X, Specifies A 32-bit long signed integer.  
	//		nSrcY---Source Y, Specifies A 32-bit long signed integer.  
	//		nWidth---lWidth, Specifies A 32-bit long signed integer.  
	//		nHeight---lHeight, Specifies A 32-bit long signed integer.  
	//		nMode---lMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	BOOL DrawBitmap(CDC* pDC, long nDestX = 0, long nDestY = 0, long nSrcX = 0, 
		long nSrcY = 0, long nWidth = -1, long nHeight = -1, DWORD dwMode = SRCCOPY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Tile Bitmap, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		fScale---Zoom Factor, Specifies A float value.  
	//		rcDraw---Specifies a const RECT& rc object(Value).  
	//		dwMode---lMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	BOOL DrawTileBitmap(CDC * pDC,  float fScale,
		const RECT& rcDraw, DWORD dwMode=SRCCOPY );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stretch Bitmap, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcDraw---Specifies a const RECT& rc object(Value).  
	//		dwMode---lMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	BOOL StretchBitmap(CDC* pDC, const RECT& rcDraw, 
		DWORD dwMode = SRCCOPY);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create D D B, You construct a CFOPNewBitmap object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	HBITMAP CreateDDB(CDC * pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmap, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nResourceID---Resource I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL LoadBitmap(UINT nResourceID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmap, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		szFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL LoadBitmap(LPCTSTR szFileName);
	
public:				
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a int type value.
	int GetType() const{ return m_ImageData.bmType;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns a int type value.
	int GetWidth() const{ return m_ImageData.bmWidth;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int GetHeight() const{ return m_ImageData.bmHeight;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width Bytes, Returns the specified value.
	//		Returns a int type value.
	int GetWidthBytes() const{ return m_ImageData.bmWidthBytes;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Planes, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.
	BYTE GetPlanes() const{ return (BYTE)m_ImageData.bmPlanes;}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bits Pixel, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.
	BYTE GetBitsPixel() const{ return (BYTE)m_ImageData.bmBitsPixel;}

	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Format, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lBitsPixel---Bits Pixel, Specifies A 32-bit long signed integer.  
	//		lPlanes---lPlanes, Specifies A 32-bit long signed integer.
	BOOL ConvertToFormat(long lBitsPixel, long lPlanes);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL Clear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	virtual void Serialize(CArchive& ar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// I T M A P, .
	//		Returns A operator value (Object).
	operator BITMAP()
	{	
		return m_ImageData; 
	}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Print, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		mode---Specifies A integer value.
	void Print(CDC *pDC,CRect rc,int mode);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Bitmap Via Memory D C, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcDraw---Big Rectangle, Specifies A CRect type value.  
	//		mode---Specifies A 32-bit long signed integer.
	void DrawImage(CDC* pDC, CRect rcDraw,long mode );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotated Bitmap, Returns the specified value.
	//		Returns A Boolean value.  
	// Parameters:
	//		lDegrees---lDegrees, Specifies A 32-bit long signed integer.  
	//		clrBack---clrBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		pbDibData---Dib Data, A pointer to the BYTE* or NULL if the call failed.  
	//		*ulDataLength---Data Length, A pointer to the ULONG  or NULL if the call failed.
	bool RotateBitmapX1( long lDegrees, COLORREF clrBack, BYTE** pbDibData, ULONG *ulDataLength);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transparent Bitblt, .
	// This member function is a static function.
	// Parameters:
	//		hdcDest---hdcDest, Specifies a HDC hdcDest object(Value).  
	//		nXDest---X Dest, Specifies A integer value.  
	//		nYDest---Y Dest, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		hBitmap---hBitmap, Specifies a HBITMAP hBitmap object(Value).  
	//		nXSrc---X Source, Specifies A integer value.  
	//		nYSrc---Y Source, Specifies A integer value.  
	//		colorTransparent---colorTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		hPal---hPal, Specifies a HPALETTE hPal object(Value).
	static void TransparentBlt( HDC hdcDest, int nXDest, int nYDest, int nWidth, 
		int nHeight, HBITMAP hBitmap, int nXSrc, int nYSrc,
		COLORREF colorTransparent, HPALETTE hPal );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bitmap To Region Transparent, .
	// This member function is a static function.
	//		Returns A HRGN value (Object).  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		hBmp---hBmp, Specifies a HBITMAP hBmp object(Value).  
	//		crColor1---Transparent Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		crColor2---color, Specifies A 32-bit COLORREF value used as a color value.
	static HRGN RegionHelper2 (HDC hDC,HBITMAP hBmp, COLORREF crColor1 = 0, COLORREF crColor2 = 0x101010);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bitmap To Region Same Color, .
	// This member function is a static function.
	//		Returns A HRGN value (Object).  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		hBmp---hBmp, Specifies a HBITMAP hBmp object(Value).  
	//		crColor1---Searched Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		crColor2---cTolerance, Specifies A 32-bit COLORREF value used as a color value.
	static HRGN RegionHelper1 (HDC hDC,HBITMAP hBmp, COLORREF crColor1 , COLORREF crColor2 = 0x101010);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotated Bitmap A, Returns the specified value.
	//		Returns A HANDLE value (Object).  
	// Parameters:
	//		nAngle---lDegrees, Specifies A 32-bit long signed integer.  
	//		crBack---clrBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		pbDibData---Dib Data, A pointer to the BYTE* or NULL if the call failed.  
	//		*lLength---Data Length, A pointer to the ULONG  or NULL if the call failed.
	HANDLE RotateBitmapX( long nAngle, COLORREF crBack, BYTE** pbDibData, ULONG *lLength);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert From Meta File, .
	// Parameters:
	//		*pDC---D C Compatible, A pointer to the CDC  or NULL if the call failed.  
	//		*mFile---A pointer to the FOPMetafile  or NULL if the call failed.  
	//		lWidth---lWidth, Specifies A 32-bit long signed integer.  
	//		lHeight---lHeight, Specifies A 32-bit long signed integer.  
	//		crColor---Transparent Color, Specifies A 32-bit COLORREF value used as a color value.
	void DoLoadMetaFile(CDC *pDC,FOPMetafile *mFile,long nWidth,long nHeight,COLORREF crColor);

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dib From Bitmap, .
	//		Returns A LPVOID value (Object).  
	// Parameters:
	//		hbm---Specifies a HBITMAP  hbm object(Value).  
	//		biBits---biBits, Specifies a WORD biBits object(Value).  
	//		hBmp---Specifies a HPALETTE hpal object(Value).
	LPVOID ConvertBitmapToDib ( HBITMAP  hBmp, WORD biBits, HPALETTE hPal);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bitmap From Dib, .
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		hDib---Specifies a LPVOID hdib object(Value).  
	//		hDC---Specifies a HDC hdc object(Value).  
	//		hPal---Specifies a HPALETTE hpal object(Value).
	HBITMAP ConvertDibToBitmap(LPVOID hDib, HDC hDC, HPALETTE hPal);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dib Number Colors, .
	//		Returns A 16-bit unsigned integer.  
	// Parameters:
	//		pv---A pointer to the VOID FAR  or NULL if the call failed.
	WORD DibNumColors (VOID FAR * pv);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Palette Size, .
	//		Returns A 16-bit unsigned integer.  
	// Parameters:
	//		pv---A pointer to the VOID FAR  or NULL if the call failed.
	WORD PaletteSize (VOID FAR * pv);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		daOld---Original, Specifies a LPVOID Original object(Value).  
	//		daCopy---Copy, Specifies a LPVOID Copy object(Value).  
	//		nDepth---Depth, Specifies A integer value.
	long Convert(LPVOID daOld, LPVOID daCopy, int nDepth);

protected:
 
	// Dib Length, Specify a A 32-bit signed integer.  
	LONG		m_lDataLength;
 
	// Bitmap, This member specify BITMAP object.  
	BITMAP		m_ImageData;
};



/////////////////////////////////////////////////////////////////////////////
// CFOImageIcon
 
 
//===========================================================================
// Summary:
//     The CFOImageIcon class derived from CFOBitmap
//      F O Image Icon
//===========================================================================

class FO_EXT_CLASS CFOImageIcon : public CFOBitmap
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageIcon---F O Image Icon, Specifies a E-XD++ CFOImageIcon object (Value).
    DECLARE_SERIAL(CFOImageIcon)
		
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Icon, Constructs a CFOImageIcon object.
	//		Returns A  value (Object).
	CFOImageIcon();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Icon, Destructor of class CFOImageIcon
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOImageIcon();

public:

	// Save document.
	// lpszPathName -- full path file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	// lpszPathName -- full path file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
    void Serialize(CArchive &ar);
	// Operations

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Read icon by id.
	// nID -- resource ID
	virtual BOOL Read(UINT nID);

	// load icon file
	// strFileName -- file name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.
	virtual BOOL Read(CString strFileName);
	
	// read from id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon I D, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual BOOL LoadIconID(UINT nID, COLORREF crTransparent = RGB(255,255,255));

	// read from file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFileName---File Name, Specifies A CString type value.  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	virtual BOOL LoadIconFile(CString strFileName, COLORREF crTransparent = RGB(255,255,255));
};

/////////////////////////////////////////////////////////////////////////////
// CFODrawImage

 
//===========================================================================
// Summary:
//     The CFODrawImage class derived from FOIUnknown
//      F O Draw Image
//===========================================================================

class FO_EXT_CLASS CFODrawImage : public FOIUnknown
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawImage---F O Draw Image, Specifies a E-XD++ CFODrawImage object (Value).
	DECLARE_SERIAL(CFODrawImage)

public:

	// Type of image
 
	// Image Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nImageType;

	//
 
	// Image Des, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strImageDes;

	// Image pointer.
 
	// B M P, This member specify E-XD++ CFOImageIcon object.  
	CFOImageIcon	m_imageBMP;

	// Get pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	virtual CFOBitmap *GetBitmap() { return &m_imageBMP; }

	// Obtain the bitmap of the frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Image, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed  
	// Parameters:
	//		nFrame---nFrame, Specifies A integer value.
	virtual CFOBitmap *GetFrameImage( int nFrame );

	//	Get the number of frames available.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetFrameCount() const;

	//	Get the number of milliseconds a frame shoudl be displayed for.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame Time, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetFrameTime( UINT nFrame ) const;

	// Get left of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetLeft( UINT nFrame ) const;

	// Get top of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nFrame---nFrame, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual int GetTop( UINT nFrame ) const;

public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Image, Constructs a CFODrawImage object.
	//		Returns A  value (Object).
	CFODrawImage();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Image, Destructor of class CFODrawImage
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawImage();

	// Operator ==.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&target---Specifies a const CFODrawImage &target object(Value).
	virtual BOOL operator==(const CFODrawImage &target);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////
// CFOImageData

typedef CFOSmartPtr<CFODrawImage> CFODrawImageData;
typedef CList<CFODrawImageData,CFODrawImageData> CFODataList;
 
//===========================================================================
// Summary:
//     The CFOImageData class derived from CFODataList
//      F O Image Data
//===========================================================================

class FO_EXT_CLASS CFOImageData : public CFODataList
{
public:

	// Constructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Data, Constructs a CFOImageData object.
	//		Returns A  value (Object).
	CFOImageData();
	
	// Destructor 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Data, Destructor of class CFOImageData
	//		Returns A  value (Object).
	~CFOImageData();

	// Find image by data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Image, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A E-XD++ CFODrawImageData& value (Object).  
	// Parameters:
	//		&pTarget---&pTarget, Specifies a E-XD++ CFODrawImageData &pTarget object (Value).
	CFODrawImageData& FindImage( CFODrawImageData &pTarget);
	
	// Remove data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Data, Call this function to remove a specify value from the specify object.

	void RemoveData();
};

/////////////////////////////////////////////////////////////////////////////
//

template<class T> void FOPMoveItemsMemOverlap( T *pSource, T *pDestination, UINT uItems )
{
    MoveMemory( pDestination, pSource, uItems * sizeof( T ) );
}

template<class T> void FOPMoveItemsNoMemOverlap( T *pSource, T *pDestination, UINT uItems )
{
    CopyMemory( pDestination, pSource, uItems * sizeof( T ) );
}

template<class T> void FOPCopyItems( const T *pSource, T *pDestination, UINT uItems )
{
    while( uItems-- )
    {
        *pDestination++ = *pSource++;
    }
}

template<class T> void FOPConstructItems( T *pItems, UINT uItems )
{
    ZeroMemory( pItems, uItems * sizeof( T ) );
    for( ; uItems--; pItems++ )
    {
        ::new((void*)pItems) T;
    }
}

template<class T> void FOPDestructItems( T *pItems, UINT uItems )
{
    for( ;uItems--; pItems++ )
    {
        pItems -> ~T();
    }
}

/////////////////////////////////////////////////////////////////////////////
// CFODataReadBase

 
//===========================================================================
// Summary:
//      To use a CFODataReadBase object, just call the constructor.
//      F O Data Read Base
//===========================================================================

class FO_EXT_CLASS CFODataReadBase
{
public:
	//	Read a part of datas from the stream
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Datas, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		*pBuffer---*pBuffer, A pointer to the void  or NULL if the call failed.  
	//		)---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual bool ReadDatas( void *pBuffer, UINT uCount ) = 0;

	// Read a specify byte data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Data, Call this function to read the specify data from an archive.
	//		Returns An 8-bit BYTE integer that is not signed.
	BYTE ReadData();
	
	//	Change to current position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Position, Sets a specify value to current class CFODataReadBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		)---Specifies A integer value.
	virtual bool SetCurPos( int nCur ) = 0;
	
	// Get the current position in the data stream
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual int GetCurrentPos() const = 0;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFODataReadBase object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
	//	Reset te positiojn to the begining
	virtual bool Reset() = 0;
	
	//	Get the size, in bytes, of this stream.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual int GetSize() const = 0;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Seek, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit long signed integer.  
	//		nCur)---nCur), Specifies A integer value.
	// Seek to position of the file.
	virtual bool Seek(long nVal, int nCur) = 0;
	
	// End of the file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Eof, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
	virtual bool Eof() = 0;
	
	//	Read a long in 8 format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Read, .
	//		Returns A Boolean value.  
	// Parameters:
	//		&data---Specifies A 32-bit long signed integer.
	bool ExtRead( long &data );
};

/////////////////////////////////////////////////////////////////////////////
// CFODataBufferRead

 
//===========================================================================
// Summary:
//     The CFODataBufferRead class derived from CFODataReadBase
//      F O Data Buffer Read
//===========================================================================

class FO_EXT_CLASS CFODataBufferRead : public CFODataReadBase  
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Buffer Read, Constructs a CFODataBufferRead object.
	//		Returns A  value (Object).
	CFODataBufferRead();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Data Buffer Read, Destructor of class CFODataBufferRead
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODataBufferRead();
	
protected:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Buffer Read, Constructs a CFODataBufferRead object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFODataBufferRead & src object(Value).
	CFODataBufferRead( const CFODataBufferRead & src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODataBufferRead& operator value (Object).  
	// Parameters:
	//		src---Specifies a const CFODataBufferRead & src object(Value).
	// Operator =
	CFODataBufferRead& operator = ( const CFODataBufferRead & src);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Open, .
	//		Returns A Boolean value.  
	// Parameters:
	//		*pBuffer---*pBuffer, A pointer to the BYTE  or NULL if the call failed.  
	//		nLen---nLen, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Open file data.
	bool Open( BYTE *pBuffer, UINT nLen );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Open, .
	//		Returns A Boolean value.  
	// Parameters:
	//		hInst---hInst, Specifies a HINSTANCE hInst object(Value).  
	//		pcszName---pcszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Open the buffer.
	bool Open( HINSTANCE hInst, LPCTSTR pcszName, LPCTSTR pcszResourceType );
	
	// Read bytes of the buffer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Datas, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		*pBuffer---*pBuffer, A pointer to the void  or NULL if the call failed.  
	//		uCount---uCount, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual bool ReadDatas( void *pBuffer, UINT uCount );

	// Change to specify pos of the buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Position, Sets a specify value to current class CFODataBufferRead
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		nCur---nCur, Specifies A integer value.
	virtual bool SetCurPos( int nCur);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFODataBufferRead object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.
	// Reset the file.
	virtual bool Reset();

	// Obtain the size of the buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSize() const;

	// Obtain the current position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCurrentPos() const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Seek, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit long signed integer.  
	//		nCur---nCur, Specifies A integer value.
	// Seek to specify position.
	virtual bool Seek(long nVal, int nCur);
	
	// End of the position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Eof, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.
	virtual bool	Eof();
	
protected:
	
	// Buffer of the data.
 
	// Buffer, This member maintains a pointer to the object BYTE.  
	BYTE *		m_pBuffer;

	// Current buffer of the data.
 
	// Current, This member maintains a pointer to the object BYTE.  
	BYTE *		m_pCurrent;

	// Length of the data.
 
	// Size, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_Size;

	// Resource.
 
	// Rsrc, This member specify HRSRC object.  
	HRSRC		m_hRsrc;

	// Global data.
 
	// Global, This member specify HGLOBAL object.  
	HGLOBAL		m_hGlobal;

	// Instance of the resource.
 
	// Inst, This member specify HINSTANCE object.  
	HINSTANCE	m_hInst;

};

/////////////////////////////////////////////////////////////////////////////
// CFODataFileRead

 
//===========================================================================
// Summary:
//     The CFODataFileRead class derived from CFODataReadBase
//      F O Data File Read
//===========================================================================

class FO_EXT_CLASS CFODataFileRead : public CFODataReadBase
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data File Read, Constructs a CFODataFileRead object.
	//		Returns A  value (Object).
	CFODataFileRead();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Data File Read, Destructor of class CFODataFileRead
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODataFileRead();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open, .
	//		Returns A Boolean value.  
	// Parameters:
	//		pcszFilename---pcszFilename, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Open the file.
	bool Open( LPCTSTR pcszFilename );

	// Read bytes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Datas, Call this function to read the specify data from an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		*pBuffer---*pBuffer, A pointer to the void  or NULL if the call failed.  
	//		uCount---uCount, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual bool ReadDatas( void *pBuffer, UINT uCount );

	// Change to specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Position, Sets a specify value to current class CFODataFileRead
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		nVal---nVal, Specifies A integer value.
	virtual bool SetCurPos( int nVal);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFODataFileRead object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.
	// Reset to the end of the file.
	virtual bool Reset();

	// Obtain the size of the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSize() const;

	// Obtain the position of the current file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCurrentPos() const;

	// End of the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Eof, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.
	virtual bool	Eof();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Seek, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Boolean value.  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit long signed integer.  
	//		nCur---nCur, Specifies A integer value.
	// Seek to a specify position of the file.
	virtual bool Seek(long nVal, int nCur);

protected:

	// Pointer of the file.
 
	// This member maintains a pointer to the object FILE.  
	FILE *		m_fp;

	// Is file closed.
 
	// Closed, Specify A Boolean value.  
	bool		m_bClosed;
};

#endif // !defined(AFX_FOBITMAP_H__900D5BB3_F3E6_11DD_A438_525400EA266C__INCLUDED_)
