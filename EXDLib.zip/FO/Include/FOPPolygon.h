//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPPOLY_TYPE_H__3228278A_36FB_46A3_8F3B_DEF97D36C4B1__INCLUDED_)
#define AFX_FOPPOLY_TYPE_H__3228278A_36FB_46A3_8F3B_DEF97D36C4B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPPolygon.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPPolygon window

#include "FOPUtil.h"
#include "FOPLine.h"

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolyStyle -- polygon style.
/////////////////////////////////////////////////////////////////////////////////

enum FOPPolyStyle
{
	FOP_POLY_TYPE_ARC			= 1,
	FOP_POLY_TYPE_PIE			= 2,
	FOP_POLY_TYPE_CHORD			= 3
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolyFlags -- polygon flag
/////////////////////////////////////////////////////////////////////////////////

enum FOPPolyFlags
{
	FOP_POLY_FLAG_NORMAL,
	FOP_POLY_FLAG_SMOOTH,
	FOP_POLY_FLAG_CONTROL,
	FOP_POLY_FLAG_SYMMTR
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolygonData -- polygon data.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPPolygonData object, just call the constructor.
//      O P Polygon Data
//===========================================================================

class FO_EXT_CLASS FOPPolygonData
{
public:
	// Points array.
 
	// Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint*		m_pptPoints;

	// Flags bytes array.
 
	// Flags, This member maintains a pointer to the object BYTE.  
	BYTE*			m_apFlags;

	// Count of points
 
	// Point Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointCount;

	// Count of reference.
 
	// Flag Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nFlagCount;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolygonBindData -- polygon binding data.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPPolygonBindData class derived from FOPPolygonData
//      O P Polygon Bind Data
//===========================================================================

class FO_EXT_CLASS FOPPolygonBindData : public FOPPolygonData
{
public:
	// Constructor.
	// nSize -- size of the polygon data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Bind Data, Constructs a FOPPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		bFlags---bFlags, Specifies A Boolean value.
	FOPPolygonBindData(int nSize, BOOL bFlags = FALSE);

	// Constructor.
	// nPoints -- count of points.
	// pPtAry -- points array.
	// pFlags -- Flags array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Bind Data, Constructs a FOPPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pPtAry---Point Array, A pointer to the const FOPPoint or NULL if the call failed.  
	//		pFlags---pFlags, A pointer to the const BYTE or NULL if the call failed.
	FOPPolygonBindData(int nPoints, const FOPPoint* pPtAry, const BYTE* pFlags = NULL);

	// Constructor.
	// aPoly -- target data object
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Bind Data, Constructs a FOPPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygonBindData& aPoly object(Value).
	FOPPolygonBindData(const FOPPolygonBindData& aPoly);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Polygon Bind Data, Destructor of class FOPPolygonBindData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPPolygonBindData();

	// Do change the size of the buffer.
	// nSize -- size of the polygon.
	// bResize -- need resize the polygon or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Size, Do a event. 
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		bResize---bResize, Specifies A Boolean value.
	void DoChangeSize(int nSize, BOOL bResize = TRUE);

	// Do create flags.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Flags, Do a event. 

	void DoCreateFlags();

	// Do split points.
	// nPos -- position to be splitted.
	// nSpace -- space split to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Split, Do a event. 
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nSpace---nSpace, Specifies A integer value.  
	//		pPoly---pPoly, A pointer to the FOPPolygonBindData or NULL if the call failed.
	void DoSplit(int nPos, int nSpace, FOPPolygonBindData* pPoly = NULL);

	// Do split points.
	// nPos -- position to be splitted.
	// nSpace -- space split to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Split, Do a event. 
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nSpace---nSpace, Specifies A integer value.  
	//		pPoly---pPoly, A pointer to the FOPPolygonBindData or NULL if the call failed.
	void DoSplit2(int nPos, int nSpace, LPPOINT pptPoints);

	// Do remove point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove, Do a event. 
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	void DoRemove(int nPos, int nCount);
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolyPolygonBindData -- polypolygon binding data.
/////////////////////////////////////////////////////////////////////////////////

class FOPPolygon;
typedef FOPPolygon* fopPOLYGON;
 
//===========================================================================
// Summary:
//      To use a FOPPolyPolygonBindData object, just call the constructor.
//      O P Polygon Polygon Bind Data
//===========================================================================

class FO_EXT_CLASS FOPPolyPolygonBindData
{
public:
	// Polygon array.
 
	// Polygon Array, This member maintains a pointer to the object fopPOLYGON.  
	fopPOLYGON*		m_apPolyAry;

	// Count of the polygon.
 
	// Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCount;

	// Count of the flags.
 
	// Flag Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nFlagCount;

	// Size.
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSize;

	// Resize size.
 
	// Resize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nResize;

	// Constructor.
	// nSize -- size of multiple polygon.
	// nResize -- resize number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon Bind Data, Constructs a FOPPolyPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPPolyPolygonBindData(int nSize, int nResize);

	// Constructor.
	// nSize -- size of multiple polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon Bind Data, Constructs a FOPPolyPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	FOPPolyPolygonBindData(int nSize);

	// Constructor.
	// aCompPoly -- target polygon data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon Bind Data, Constructs a FOPPolyPolygonBindData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygonBindData& aCompPoly object(Value).
	FOPPolyPolygonBindData(const FOPPolyPolygonBindData& aCompPoly);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Polygon Polygon Bind Data, Destructor of class FOPPolyPolygonBindData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPPolyPolygonBindData();
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolyOperatorData -- polygon operator data.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPPolyOperatorData object, just call the constructor.
//      O P Polygon Operator Data
//===========================================================================

class FO_EXT_CLASS FOPPolyOperatorData
{
protected:

	enum FOPDataType
	{
		DATA_NONE		= 0,
		DATA_ABSOLUT	= 1,
		DATA_PERCENT	= 2
	};

	// Data type.
 
	// Type, This member specify FOPDataType object.  
	FOPDataType m_eType;

	union
	{
		ULONG m_nAbsolut; 
		int m_nPercent;
	};

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Operator Data, Constructs a FOPPolyOperatorData object.
	//		Returns A  value (Object).
	FOPPolyOperatorData() : m_eType(DATA_NONE)	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Operator Data, Constructs a FOPPolyOperatorData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nAbsolut---nAbsolut, Specifies A 32-bit LONG signed integer.
	FOPPolyOperatorData(ULONG nAbsolut) : m_eType(DATA_ABSOLUT), m_nAbsolut(nAbsolut)	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Operator Data, Constructs a FOPPolyOperatorData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nPercent---nPercent, Specifies A integer value.
	FOPPolyOperatorData(int nPercent) : m_eType(DATA_PERCENT), m_nPercent(nPercent)	{}

	// Get abs value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Abs Value, Returns the specified value.
	//		Returns A 32-bit LONG signed integer.
	ULONG GetAbsValue() const	{	return m_nAbsolut;	}

	// Get percent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Percent Value, Returns the specified value.
	//		Returns a int type value.
	int GetPercentValue() const	{	return m_nPercent;	}
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolygon -- polygon class.
/////////////////////////////////////////////////////////////////////////////////

class FOPPolyPolygonBindData;
class FOPPolyPolygon;
 
//===========================================================================
// Summary:
//     The FOPPolygon class derived from CObject
//      O P Polygon
//===========================================================================

class FO_EXT_CLASS FOPPolygon : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPPolygon---O P Polygon, Specifies a FOPPolygon object(Value).
	DECLARE_SERIAL(FOPPolygon);

	// Polygon data.
 
	// Bind Polygon Data, This member maintains a pointer to the object FOPPolygonBindData.  
    FOPPolygonBindData* m_aBindPolyData;

public:

	// Get point array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Point Array, Do a event. 
	//		Returns a int type value.
    FOPPoint*           DoGetPointAry();

	// Get flag array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Flag Array, Do a event. 
	//		Returns a pointer to the object BYTE,or NULL if the call failed
    BYTE*               DoGetFlagAry();

	// Do reduce edges.
	// aPoly -- polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Reduce Edges, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		dArea---dArea, Specifies a const double& dArea object(Value).  
	//		nPercent---nPercent, Specifies A integer value.
	static void			DoReduceEdges( FOPPolygon& aPoly, const double& dArea, int nPercent );

public:
						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).
                        FOPPolygon();

						// Constructor.
						// nSize -- points size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
                        FOPPolygon( int nSize );

						// Constructor.
						// nPoints -- total points.
						// pPtAry -- points array.
						// pFlagAry -- flags array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pPtAry---Point Array, A pointer to the const FOPPoint or NULL if the call failed.  
	//		pFlagAry---Flag Array, A pointer to the const BYTE or NULL if the call failed.
                        FOPPolygon( int nPoints, const FOPPoint* pPtAry,
                                 const BYTE* pFlagAry = NULL );

						// Constructor,to create a rectangle
						// rcRect -- FOPRect object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).
                        FOPPolygon( const FOPRect& rcRect );

						// Constructor,to create a round rectangle.
						// rcRect -- FOPRect object.
						// nHorz -- Horz size of the round corner.
						// nVert -- Vert size of the round corner.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		nHorz---nHorz, Specifies A 32-bit LONG signed integer.  
	//		nVert---nVert, Specifies A 32-bit LONG signed integer.
                        FOPPolygon( const FOPRect& rcRect, 
								 ULONG nHorz, ULONG nVert );

						// Constructor,to create ellipse.
						// ptCenter -- Center point of the ellipse.
						// nRadX -- Rad x value.
						// RadY -- Rad y value.
						// nPoints -- points to be split to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRadX---Radius X, Specifies A 32-bit long signed integer.  
	//		nRadY---Radius Y, Specifies A 32-bit long signed integer.  
	//		nPoints---nPoints, Specifies A integer value.
                        FOPPolygon( const FOPPoint& ptCenter,
								 long nRadX, long nRadY,
                                 int nPoints = 0 );

						// Constructor,create arc,pie,and chord.
						// rcBound -- Bounding rectangle.
						// ptStart -- start point.
						// ptEnd -- end point.
						// ePolyStyle -- style to be created,it must be one of the following value:
						// enum FOPPolyStyle
						// {
						// 	FOP_POLY_TYPE_ARC			= 1,
						// 	FOP_POLY_TYPE_PIE			= 2,
						// 	FOP_POLY_TYPE_CHORD			= 3
						// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcBound---rcBound, Specifies a const FOPRect& rcBound object(Value).  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		ePolyStyle---Polygon Style, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
                        FOPPolygon( const FOPRect& rcBound,
                                 const FOPPoint& ptStart, const FOPPoint& ptEnd,
                                 UINT ePolyStyle = FOP_POLY_TYPE_ARC );

						// Constructor,create beizer line.
						// ptBezPt1 -- first bezier point.
						// ptCtrlPt1 -- first control point.
						// ptBezPt2 -- second bezier point.
						// ptCtrlPt2 -- second control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptBezPt1---Bez Pt1, Specifies A integer value.  
	//		ptCtrlPt1---Pt1, Specifies A integer value.  
	//		ptBezPt2---Bez Pt2, Specifies A integer value.  
	//		ptCtrlPt2---Pt2, Specifies A integer value.  
	//		nPoints---nPoints, Specifies A integer value.
						FOPPolygon( const FOPPoint& ptBezPt1, const FOPPoint& ptCtrlPt1, 
								 const FOPPoint& ptBezPt2, const FOPPoint& ptCtrlPt2,  
								 int nPoints = 0 );

						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon, Constructs a FOPPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
                        FOPPolygon( const FOPPolygon& aPoly );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Polygon, Destructor of class FOPPolygon
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual             ~FOPPolygon();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void		Serialize(CArchive &ar);

	// Change a specify point.
	// ptPt -- change to value.
	// nPos -- position to change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point, Sets a specify value to current class FOPPolygon
	// Parameters:
	//		ptPt---ptPt, Specifies A integer value.  
	//		nPos---nPos, Specifies A integer value.
    void                SetPoint( const FOPPoint& ptPt, int nPos );

	// Obtain a specify point.
	// nPos -- position to obtain.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    const FOPPoint&     GetPoint( int nPos ) const;

	// Change flags of polygon.
	// nPos -- position to change.
	// eFlags -- change to polygon flag,it must be one of the following value:
	// enum FOPPolyFlags
	// {
	// 	FOP_POLY_FLAG_NORMAL,
	// 	FOP_POLY_FLAG_SMOOTH,
	// 	FOP_POLY_FLAG_CONTROL,
	// 	FOP_POLY_FLAG_SYMMTR
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Polygon Flags, Sets a specify value to current class FOPPolygon
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		eFlags---eFlags, Specifies a FOPPolyFlags eFlags object(Value).
    void                SetPolyFlags( int nPos, FOPPolyFlags eFlags );

	// Get flags of polygon,it will return one of the following value:
	// enum FOPPolyFlags
	// {
	// 	FOP_POLY_FLAG_NORMAL,
	// 	FOP_POLY_FLAG_SMOOTH,
	// 	FOP_POLY_FLAG_CONTROL,
	// 	FOP_POLY_FLAG_SYMMTR
	// };
	// nPos -- position to obtain.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon Flags, Returns the specified value.
	//		Returns A FOPPolyFlags value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    FOPPolyFlags        GetPolyFlags( int nPos ) const;

	// Has flags or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Flag Support, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL				IsFlagSupport() const;

	// Is it a control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is , Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    BOOL                IsControl( int nPos ) const;

	// Is it smooth.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Smooth, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    BOOL                IsSmooth( int nPos ) const;

	// Is it rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rectangle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL				IsRect() const;

	// Change size
	// nNewSize -- new size of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class FOPPolygon
	// Parameters:
	//		nNewSize---New Size, Specifies A integer value.
    void                SetSize( int nNewSize );

	// Obtain the size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.
    int					GetSize() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data.
    void                Clear();

	// Get bound rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
    FOPRect				GetBoundRect() const;

	// Get area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Area, Returns the specified value.
	//		Returns A double value (Object).
    double              GetArea() const;

	// Get sign area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Signed Area, Returns the specified value.
	//		Returns A double value (Object).
    double              GetSignedArea() const;

	// Is inside.
	// ptPt -- logical point for hitting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPt---ptPt, Specifies A integer value.
    BOOL                HitTest( const FOPPoint& ptPt ) const;

	// Is right orientate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Right Orientated, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL                IsRightOrientated() const;

	// Calculate distance between two points.
	// nPt1 -- start position to Calculate.
	// nPt2 -- end position to Calculate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Distance, .
	//		Returns A double value (Object).  
	// Parameters:
	//		nPt1---nPt1, Specifies A integer value.  
	//		nPt2---nPt2, Specifies A integer value.
    double              CalcDistance( int nPt1, int nPt2 );

	// Calculate the total length of all points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Total Length, .
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		&bToLastPoint---To Last Point, Specifies A Boolean value.
	long				CalcTotalLength(const BOOL &bToLastPoint = TRUE);

	CPoint GetPolyPointByPercent(int &nPtIndex, double dPercent = 50.0);
	// Get the center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint				GetCenterPoint();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clipboard, .
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		bPolygon---bPolygon, Specifies A Boolean value.
	// Clip
	// rcRect -- Position.
    void                Clip( const FOPRect& rcRect, BOOL bPolygon = TRUE );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Operator, .
	// Parameters:
	//		nOpFlags---Op Flags, Specifies A 32-bit LONG signed integer.  
	//		pData---pData, A pointer to the const FOPPolyOperatorData or NULL if the call failed.
	// Operator
	// nOpFlags -- operator flag,it must be one of the following value:
	//  FOP_OPER_NONE    0x00000000UL
	//  FOP_OPER_OPEN    0x00000001UL
	//  FOP_OPER_CLOSE   0x00000002UL
	//  FOP_OPER_NO_SAME 0x00000004UL
	//  FOP_OPER_REDUCE  0x00000008UL
	//  FOP_OPER_EDGES   0x00000010UL
	void				Operator( ULONG nOpFlags, const FOPPolyOperatorData* pData = NULL );

	// Get simple
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Simple, Returns the specified value.
	// Parameters:
	//		aResult---aResult, Specifies a FOPPolygon& aResult object(Value).  
	//		nDelta---nDelta, Specifies A 32-bit long signed integer.
	void				GetSimple( FOPPolygon& aResult, long nDelta = 0 ) const;
   
	// Sub divide.
	// aResult -- result polygon that divide to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adaptive Subdivide, .
	// Parameters:
	//		aResult---aResult, Specifies a FOPPolygon& aResult object(Value).  
	//		d---Specifies a const double d = 1.0 object(Value).
    void 				AdaptiveSubdivide( FOPPolygon& aResult, const double d = 1.0 ) const;
	
	// Intersection.
	// aCompPoly -- Intersection target polygons.
	// aResult -- result polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intersection, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetIntersection( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// Union
	// aCompPoly -- Union target polygon.
	// aResult -- result polygons that unioned.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Union, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetUnion( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// Difference.
	// aCompPoly -- Difference target polygons.
	// aResult -- result polygons that differenced.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Difference, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetDifference( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// XOR
	// aCompPoly -- XOR target polygons.
	// aResult -- result polygons that XORed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X O R, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetXOR( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		xOffset---xOffset, Specifies A 32-bit long signed integer.  
	//		yOffset---yOffset, Specifies A 32-bit long signed integer.
	// Move
	// xOffset -- offset x value.
	// yOffset -- offset y value.
    void                Move( long xOffset, long yOffset );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		ptOffset---ptOffset, Specifies A integer value.
	// Translate.
	// ptOffset -- translate point.
    void                Translate( const FOPPoint& ptOffset );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		dScaleX---Scale X, Specifies a double dScaleX object(Value).  
	//		dScaleY---Scale Y, Specifies a double dScaleY object(Value).
	// Scale
	// dScaleX -- horz scale value.
	// dScaleY -- vertical scale value.
    void                Scale( double dScaleX, double dScaleY );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	// Rotate
	// ptCenter -- rotating center.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
    void                Rotate( const FOPPoint& ptCenter, double dSin, double dCos );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nAngle---nAngle, Specifies A integer value.
	// Rotate
	// ptCenter -- rotating center
	// nAngle -- 0 - 3600 angle value.
    void                Rotate( const FOPPoint& ptCenter, int nAngle );

	// Slant X
	// nYRef -- y reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant X, .
	// Parameters:
	//		nYRef---Y Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
    void                SlantX( long nYRef, double dSin, double dCos );

	// Slant Y
	// nXRef -- x reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant Y, .
	// Parameters:
	//		nXRef---X Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
    void                SlantY( long nXRef, double dSin, double dCos );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distort, .
	// Parameters:
	//		rcRef---rcRef, Specifies a const FOPRect& rcRef object(Value).  
	//		aDistorted---aDistorted, Specifies a const FOPPolygon& aDistorted object(Value).
	// Distort
	// rcRef -- reference rectangle.
	// aDistorted -- distort rectangle.
    void                Distort( const FOPRect& rcRef, const FOPPolygon& aDistorted );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		ptPt---ptPt, Specifies A integer value.  
	//		eFlags---eFlags, Specifies a FOPPolyFlags eFlags = FOP_POLY_FLAG_NORMAL object(Value).
	// Insert new point
	// nPos -- position to be inserted.
	// ptPt -- insert point value.
	// eFlags -- Flag of the point,it must be one of the following value:
	// enum FOPPolyFlags
	// {
	// 	FOP_POLY_FLAG_NORMAL,
	// 	FOP_POLY_FLAG_SMOOTH,
	// 	FOP_POLY_FLAG_CONTROL,
	// 	FOP_POLY_FLAG_SYMMTR
	// };
    void                Insert( int nPos, const FOPPoint& ptPt, FOPPolyFlags eFlags = FOP_POLY_FLAG_NORMAL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	// Insert a new polygon.
	// aPoly -- polygon to be inserted.
    void                Insert( int nPos, const FOPPolygon& aPoly );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	// Remove points.
	// nPos -- remove start position.
	// nCount -- total points to be removed.
    void                Remove( int nPos, int nCount );

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    const FOPPoint&     operator[]( int nPos ) const { return GetPoint( nPos ); }

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    FOPPoint&           operator[]( int nPos );

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPPolygon& value (Object).  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
    FOPPolygon&         operator=( const FOPPolygon& aPoly );

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
    BOOL                operator==( const FOPPolygon& aPoly ) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
    BOOL                operator!=( const FOPPolygon& aPoly ) const
                            { return !(FOPPolygon::operator==( aPoly )); }

	// Is equal or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	BOOL				IsEqual( const FOPPolygon& aPoly ) const;

	// Get points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Const Point Array, Returns the specified value.
	//		Returns a int type value.
    const FOPPoint*     GetConstPointAry() const;

	// Get flags.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Const Flag Array, Returns the specified value.
	//		Returns a pointer to the object const BYTE,or NULL if the call failed
    const BYTE*         GetConstFlagAry() const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPPolyPolygon -- polypolygon object.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPPolyPolygon class derived from CObject
//      O P Polygon Polygon
//===========================================================================

class FO_EXT_CLASS FOPPolyPolygon : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPPolyPolygon---O P Polygon Polygon, Specifies a FOPPolyPolygon object(Value).
	DECLARE_SERIAL(FOPPolyPolygon);

	// Pointer of polypolygon.
 
	// Bind Data, This member maintains a pointer to the object FOPPolyPolygonBindData.  
    FOPPolyPolygonBindData* m_aBindData;

	// Do create polypolygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Polygon Polygon, Do a event. 
	//		Returns a pointer to the object void,or NULL if the call failed
	void*				DoCreatePolyPolygon() const;

	// Do operation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Operation, Do a event. 
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).  
	//		nOperation---nOperation, Specifies A 32-bit LONG signed integer.
	void				DoOperation( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult, ULONG nOperation ) const;

public:

						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon, Constructs a FOPPolyPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
                        FOPPolyPolygon( int nSize = 16, int nResize = 16 );

						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon, Constructs a FOPPolyPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
                        FOPPolyPolygon( const FOPPolygon& aPoly );

						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon, Constructs a FOPPolyPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nPoly---nPoly, Specifies A integer value.  
	//		pPointCountAry---Point Count Array, A pointer to the const int or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the const FOPPoint or NULL if the call failed.
                        FOPPolyPolygon( int nPoly, const int* pPointCountAry,
                                     const FOPPoint* pPtAry );

						// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Polygon Polygon, Constructs a FOPPolyPolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
                        FOPPolyPolygon( const FOPPolyPolygon& aCompPoly );
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Polygon Polygon, Destructor of class FOPPolyPolygon
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual             ~FOPPolyPolygon();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void		Serialize(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Insert new polygon.
	// aPoly -- polygon to be inserted.
	// nPos -- insert at position.
    void                Insert( const FOPPolygon& aPoly, int nPos = 0xFFFF );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	// Remove at a specify position.
	// nPos -- position to removed.
    void                Remove( int nPos );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Replace a specify position.
	// aPoly -- replaced new polygon.
	// nPos -- which position to be replaced.
    void                Replace( const FOPPolygon& aPoly, int nPos );

	// Obtain a specify polygon.
	// nPos -- index of polygon to get.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns A const FOPPolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    const FOPPolygon&   GetObject( int nPos ) const;

	// Is it rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rectangle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL				IsRect() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear data.
    void                Clear();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Count, .
	//		Returns a int type value.
	// Obtain the count of polypolygon.
    int					Count() const;

	// Get bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
    FOPRect				GetBoundRect() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clipboard, .
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).
	// Clip
    void                Clip( const FOPRect& rcRect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Operator, .
	// Parameters:
	//		nOpFlags---Op Flags, Specifies A 32-bit LONG signed integer.  
	//		pData---pData, A pointer to the const FOPPolyOperatorData or NULL if the call failed.
	// Operator
	void				Operator( ULONG nOpFlags, const FOPPolyOperatorData* pData = NULL );

	// Get simple
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Simple, Returns the specified value.
	// Parameters:
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).  
	//		nDelta---nDelta, Specifies A 32-bit long signed integer.
	void				GetSimple( FOPPolyPolygon& aResult, long nDelta = 0 ) const;

	// Sub divide.
	// aResult -- result divide polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adaptive Subdivide, .
	// Parameters:
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).  
	//		d---Specifies a const double d = 1.0 object(Value).
    void 				AdaptiveSubdivide( FOPPolyPolygon& aResult, const double d = 1.0 ) const;

	// Get intersection.
	// aCompPoly -- polygons to be intersected.
	// aResult -- result polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Intersection, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetIntersection( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// Union
	// aCompPoly -- polygons to be unioned.
	// aResult -- result union polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Union, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetUnion( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// Difference.
	// aCompPoly -- polygons to be differenced.
	// aResult -- result difference polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Difference, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetDifference( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	// XOR
	// aCompPoly -- polygons to be XORed.
	// aResult -- result XOR polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X O R, Returns the specified value.
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).  
	//		aResult---aResult, Specifies a FOPPolyPolygon& aResult object(Value).
	void				GetXOR( const FOPPolyPolygon& aCompPoly, FOPPolyPolygon& aResult ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		xOffset---xOffset, Specifies A 32-bit long signed integer.  
	//		yOffset---yOffset, Specifies A 32-bit long signed integer.
	// Move
	// xOffset -- offset x value.
	// yOffset -- offset y value.
    void                Move( long xOffset, long yOffset );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		ptOffset---ptOffset, Specifies A integer value.
	// Translate.
	// ptOffset -- translate point.
    void                Translate( const FOPPoint& ptOffset );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		dScaleX---Scale X, Specifies a double dScaleX object(Value).  
	//		dScaleY---Scale Y, Specifies a double dScaleY object(Value).
	// Scale
	// dScaleX -- horz scale value.
	// dScaleY -- vertical scale value.
    void                Scale( double dScaleX, double dScaleY );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	// Rotate
	// ptCenter -- rotating center.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
    void                Rotate( const FOPPoint& ptCenter, double dSin, double dCos );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nAngle---nAngle, Specifies A integer value.
	// Rotate
	// ptCenter -- rotating center
	// nAngle -- 0 - 3600 angle value.
    void                Rotate( const FOPPoint& ptCenter, int nAngle );

	// Slant X
	// nYRef -- y reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant X, .
	// Parameters:
	//		nYRef---Y Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
    void                SlantX( long nYRef, double dSin, double dCos );

	// Slant Y
	// nXRef -- x reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant Y, .
	// Parameters:
	//		nXRef---X Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
    void                SlantY( long nXRef, double dSin, double dCos );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distort, .
	// Parameters:
	//		rcRef---rcRef, Specifies a const FOPRect& rcRef object(Value).  
	//		aDistorted---aDistorted, Specifies a const FOPPolygon& aDistorted object(Value).
	// Distort
	// rcRef -- reference rectangle.
	// aDistorted -- distort rectangle.
    void                Distort( const FOPRect& rcRef, const FOPPolygon& aDistorted );

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPPolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    const FOPPolygon&   operator[]( int nPos ) const { return GetObject( nPos ); }

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPPolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
    FOPPolygon&         operator[]( int nPos );

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPPolyPolygon& value (Object).  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
    FOPPolyPolygon&     operator=( const FOPPolyPolygon& aCompPoly );

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
    BOOL                operator==( const FOPPolyPolygon& aCompPoly ) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
    BOOL                operator!=( const FOPPolyPolygon& aCompPoly ) const
                            { return !(FOPPolyPolygon::operator==( aCompPoly )); }

	// Is equal or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
	BOOL				IsEqual( const FOPPolyPolygon& aCompPoly ) const;


public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOPBasicPathPolyPolygon -- path poly polygon path.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPBasicPathPolyPolygon class derived from FOPPolyPolygon
//      F O P Basic Path Polygon Polygon
//===========================================================================

class FO_EXT_CLASS CFOPBasicPathPolyPolygon : public FOPPolyPolygon
{
protected:
 
	// Closed, This member sets TRUE if it is right.  
	BOOL	bClosed;
	
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Basic Path Polygon Polygon, Constructs a CFOPBasicPathPolyPolygon object.
	//		Returns A  value (Object).
	CFOPBasicPathPolyPolygon() { bClosed = TRUE; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.

	// Initial.
	void    Init() { Clear(); bClosed = TRUE; };

	// Close path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Path, .

	void	ClosePath();
	
	// Add point to path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Point, Adds an object to the specify list.
	// Parameters:
	//		rPoint---rPoint, Specifies A integer value.
	void	AddPoint( const FOPPoint& rPoint );

	// Add polygon to path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon, Adds an object to the specify list.
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	void	AddPolygon( const FOPPolygon& aPoly );

	// Add bezier to path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier, Adds an object to the specify list.
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	void	AddBezier( const FOPPolygon& aPoly );

	// Add polyline to path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Line, Adds an object to the specify list.
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	void	AddPolyLine( const FOPPolygon& aPoly );

	// Add polypolygon object to path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon Polygon, Adds an object to the specify list.
	// Parameters:
	//		aPolyPolygon---Polygon Polygon, Specifies a const FOPPolyPolygon& aPolyPolygon object(Value).
	void	AddPolyPolygon( const FOPPolyPolygon& aPolyPolygon );
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPPOLY_TYPE_H__3228278A_36FB_46A3_8F3B_DEF97D36C4B1__INCLUDED_)
