//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPTABLESHAPE_H__3C8DE07D_A6D1_4333_9EC6_3BD0BA6C37E0__INCLUDED_)
#define FO_FOPTABLESHAPE_H__3C8DE07D_A6D1_4333_9EC6_3BD0BA6C37E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "FODrawShape.h"
#include "FOPTableCellBorder.h"
#include "FOPTableHelper.h"

class CFOPRemovedRow;
class CFOPTableShape;
class CFOPRemovedColumn;

/////////////////////////////////////////////////////////////////
// CFOPTableCell
// Table cell
// note A cell can be any type of control, but for now, we only support text!
//
//------------------------------------------------------
// Description: cell object of table.
// Author: Author Name.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPTableCell class derived from CObject
//      F O P Table Cell
//===========================================================================

class FO_EXT_CLASS CFOPTableCell : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPTableCell---F O P Table Cell, Specifies a E-XD++ CFOPTableCell object (Value).
	DECLARE_SERIAL(CFOPTableCell);

protected:
    
	// Current row.
 
	// Current Row, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    unsigned int	m_nCurRow;

	// Current column
 
	// Current Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	unsigned int	m_nCurCol;

	// Total rows.
 
	// Total Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    unsigned int	m_nTotalRows;
	
	// Total columns
 
	// Total Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	unsigned int	m_nTotalCols;
	
	// Is joined or not
 
	// Joined Cell, This member sets TRUE if it is right.  
    BOOL			m_bJoinedCell;

	// marker or not
 
	// Marker, This member sets TRUE if it is right.  
    BOOL			m_bMarker;

	// With label editing or not.
 
	// With Label Editing, This member sets TRUE if it is right.  
	BOOL			m_bWithLabelEditing;

protected:

	// Update cell state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Joined Cell State, Call this member function to update the object.

    void UpdateJoinedCellState() {m_bJoinedCell = ( (m_nTotalRows > 1) || (m_nTotalCols > 1)); }
    
public:
    //-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPTableCell object.
	//		Returns A  value (Object).
    CFOPTableCell();

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*table---A pointer to the CFOPTableShape  or NULL if the call failed.  
	//		row---Specifies A integer value.  
	//		col---Specifies A integer value.  
	//		name---Specifies A CString type value.
    CFOPTableCell( CFOPTableShape *table, unsigned int row, 
		unsigned int col, const CString & name = _T("") );

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		row---Specifies A integer value.  
	//		col---Specifies A integer value.  
	//		name---Specifies A CString type value.
    CFOPTableCell(unsigned int row, 
		unsigned int col, const CString & name = _T("") );

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*table---A pointer to the CFOPTableShape  or NULL if the call failed.  
	//		&original---Specifies a const CFOPTableCell &original object(Value).
    CFOPTableCell( CFOPTableShape *table, const CFOPTableCell &original );

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPTableCell& source object(Value).
	CFOPTableCell(const CFOPTableCell& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPTableCell& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPTableCell& source object(Value).
	CFOPTableCell& operator=(const CFOPTableCell& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPTableCell* Copy() const;

    //-----------------------------------------------------------------------
	// Summary:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Cell, Destructor of class CFOPTableCell
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPTableCell();

public:
	
	// Build table with this cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Table, .
	// Parameters:
	//		*table---A pointer to the CFOPTableShape  or NULL if the call failed.
	void BuildTable(CFOPTableShape *table);
    
    // frame management
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*_frame---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		recalc---Specifies A Boolean value.
    virtual void AddRect( CFOPCellRect *_frame, BOOL recalc = TRUE );
    
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);
	
    // Delete a rectangle from the set of rects this list has.
    //  rc The rect that should be deleted
    //  remove passing TRUE means that there can not be an undo of the action.
    //  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		*rc---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    void RemoveRect( CFOPCellRect *rc, BOOL remove = TRUE, BOOL recalc = TRUE ); // calls the virtual one
    
	// Delete a rectangle from the set of rects this list has.
	//  num The rect Number to be removed.
	//  remove passing TRUE means that there can not be an undo of the action.
	//  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		num---Specifies A integer value.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    virtual void RemoveRect( unsigned int num, BOOL remove = TRUE, BOOL recalc = TRUE );

	// Obtain the text drawing alignment format type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Format Type, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetDrawFormatType();

	// Get bitmap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

    // get a frame by number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame, Returns the specified value.
	//		Returns a pointer to the object CFOPCellRect ,or NULL if the call failed  
	// Parameters:
	//		_num---Specifies A integer value.
    CFOPCellRect *GetFrame( unsigned int _num );

	// Obtain the rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCellRect() { return *GetFrame(0); }
    
	// Delete all rects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Rects, Deletes the given object.

    void DeleteAllRects();

	// Delete all rect copies.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Copies, Deletes the given object.

    void DeleteAllCopies();
    
	// Obtain the first row number
	
	//-----------------------------------------------------------------------
	// Summary:
	// First Row, .
	//		Returns a UINT type value.
    UINT FirstRow() const { return m_nCurRow; }

	// Obtain the first column number
	
	//-----------------------------------------------------------------------
	// Summary:
	// First Column, .
	//		Returns a UINT type value.
    UINT FirstColumn() const { return m_nCurCol; }

	// Obtain the row span
	
	//-----------------------------------------------------------------------
	// Summary:
	// Row Span, .
	//		Returns a UINT type value.
    UINT RowSpan() const { return m_nTotalRows; }

	// Obtain the column span
	
	//-----------------------------------------------------------------------
	// Summary:
	// Column Span, .
	//		Returns a UINT type value.
    UINT ColumnSpan() const { return m_nTotalCols; }
    
	// Obtain the last row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Last Row, .
	//		Returns a UINT type value.
    UINT LastRow() const { return m_nCurRow + m_nTotalRows - 1; }

	// Obtain the last column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Last Column, .
	//		Returns a UINT type value.
    UINT LastColumn() const { return m_nCurCol + m_nTotalCols - 1; }

	// Obtain the rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Row After, .
	//		Returns a UINT type value.
    UINT RowAfter() const { return m_nCurRow + m_nTotalRows; }

	// Obtain the columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Column After, .
	//		Returns a UINT type value.
    UINT ColumnAfter() const { return m_nCurCol + m_nTotalCols; }
    
	// Change the first row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set First Row, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		row---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void SetFirstRow(UINT row) { m_nCurRow = row; }

	// Change the first column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set First Column, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		col---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void SetFirstColumn(UINT col) { m_nCurCol = col; }

	// Change the row span
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Span, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		rows---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void SetRowSpan(UINT rows) { m_nTotalRows = rows; UpdateJoinedCellState(); }

	// Change the column span
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Span, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		cols---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void SetColumnSpan(UINT cols) { m_nTotalCols = cols; UpdateJoinedCellState(); }
    
	// Is first grid position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is First Grid Position, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		row---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		col---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    BOOL IsFirstGridPosition(UINT row, UINT col) const;
    
	// Is first grid position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is First Grid Position Fast, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		row---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		col---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    BOOL IsFirstGridPositionFast(UINT row, UINT col) const;

	// Is cell above or left of
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Above Or Left Of, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		row---Specifies a unsigned row object(Value).  
	//		column---Specifies a unsigned column object(Value).
    BOOL IsAboveOrLeftOf( unsigned row, unsigned column ) const;

	// Contains cell or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Cell, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		row---Specifies a unsigned row object(Value).  
	//		column---Specifies a unsigned column object(Value).
    BOOL ContainsCell( unsigned row, unsigned column ) const;
    
	// Obtain the left border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Left Border, .
	//		Returns A double value (Object).
    double LeftBorder();

	// Obtain the right border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Right Border, .
	//		Returns A double value (Object).
    double RightBorder();

	// Obtain the top border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top Border, .
	//		Returns A double value (Object).
    double TopBorder();

	// Obtain the bottom border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom Border, .
	//		Returns A double value (Object).
    double BottomBorder();

	// Update rects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Rects, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		flags---Specifies A integer value.
    virtual void UpdateRects( int flags = 0xff );
    
	// Change left border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Border, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		newBorder---newBorder, Specifies a E-XD++ CFOPTableCellBorder newBorder object (Value).
    void SetLeftBorder(CFOPTableCellBorder newBorder);

	// Change right border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Right Border, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		newBorder---newBorder, Specifies a E-XD++ CFOPTableCellBorder newBorder object (Value).
    void SetRightBorder(CFOPTableCellBorder newBorder);

	// Change top border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top Border, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		newBorder---newBorder, Specifies a E-XD++ CFOPTableCellBorder newBorder object (Value).
    void SetTopBorder(CFOPTableCellBorder newBorder);

	// Change bottom border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bottom Border, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		newBorder---newBorder, Specifies a E-XD++ CFOPTableCellBorder newBorder object (Value).
    void SetBottomBorder(CFOPTableCellBorder newBorder);
   
	// Is joined cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Joined Cell, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsJoinedCell() const { return m_bJoinedCell; }

	// Clear mark
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Mark, Remove the specify data from the list.

    void ClearMark() { m_bMarker = FALSE; }

	// Change mark state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mark, Sets a specify value to current class CFOPTableCell

    void SetMark() { m_bMarker = TRUE; }

	// Is marked or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Marked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsMarked() const { return m_bMarker; }
    
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout, .
	// This member function is also a virtual function, you can Override it if you need,
	// Layout or not
    virtual void Layout() {}

	// Is validate or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// In Validate, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void InValidate() {}
   
    // set the visibility of the rects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOPTableCell
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVisible---bVisible, Specifies A Boolean value.
    virtual void SetVisible( BOOL bVisible ) { bVisible; }
    
    // Called once the frameset has been completely loaded or constructed.
    // The default implementation calls UpdateRects(). Call the parent :)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finalize, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void Finalize() {}
    
    // Drawing the cell
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.  
	//		*pMain---*pMain, A pointer to the CFOPTableShape  or NULL if the call failed.
    void OnDraw( CDC *pDC,BOOL bEditing, CFOPTableShape *pMain);

	// Draw the object with normal state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.  
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void DrawNormal(CDC *pDC,BOOL bEditing, CFODataModel *pModel);
	
	// Draw the object with select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Select, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.
	virtual void DrawSelect(CDC *pDC,BOOL bEditing);

	// Draw text specify,it do not draw the bullets of the text.
	// pDC -- pointer of the DC
	// str -- drawing text caption.
	// lpRect -- drawing text within position.
	// crText -- font color.
	// nFormat -- text alignment format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Extend, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		str---Specifies A CString type value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		&crText---&crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoDrawTextExt(CDC *pDC,const CString& str, LPRECT lpRect,
		const COLORREF &crText, UINT nFormat, int nArtType);

	// Calculate text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOPTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,CRect rcBox,CStringArray& arLines);

	// do flash timer.
	virtual void OnFlashTimer(UINT_PTR nTimerID);
	
	// start flash timer.
	void StartFlashCell();

	CFOPTableShape *m_pTable;

	// Flash timer ID.
	int		m_nFlashTimerID;
public:
	// Define for text.
	// Get Object Caption,this is also the label of some shapes,such as CFOTextShape,CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const { return m_strCaption;}

	// Set Object Caption,you can also call this method to change the label of shapes,such as label of CFOTextShape
	// CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(
		// Specify the new caption.
		const CString &str
		) { m_strCaption = str; }

	// Return With Label Editing value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get With Label Editing, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetWithLabelEditing() const { return m_bWithLabelEditing;}

	// Change With Label Editing value,if you want the text to be edited by double click on it,
	// this param must be TRUE,else it is FALSE.
	// bEdit -- editable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set With Label Editing, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bEdit---&bEdit, Specifies A Boolean value.
	void SetWithLabelEditing( const BOOL &bEdit ) {m_bWithLabelEditing = bEdit; }

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD GenEditingLabelAlign();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GenLabelAlign();

	// Obtain type of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type Of , Returns the specified value.
	//		Returns a int type value.
	int GetTypeOfControl() const { return m_nTypeControl; }

	// Change the type of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type Of , Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void SetTypeOfControl(const int &nType) { m_nTypeControl = nType; }

	// Obtain the choice text of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetChoiceText() const { return m_strChoice; }

	// Change the choice text of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice Text, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void SetChoiceText(const CString &strText ) { m_strChoice = strText; }
	
	
public:

	// Export data to svg file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export To S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strOut---strOut, Specifies A CString type value.
	virtual void ExportToSVG(CString* strOut);
	virtual void ExportToSVG(CStdioFile*);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Bezier(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Poly(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Line(const CPoint &ptStart, const CPoint &ptEnd);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Polyline(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Rect(const FOPRect &rect);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Ellipse(const FOPRect &rect);

	double PixXToPoint(double px);
	double PixYToPoint(double px);

	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ShapeToSVGString();

	// Generate fill svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Fill S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		nGrayScale---Gray Scale, Specifies A integer value.
	virtual CString SVG_Fill(COLORREF crColor, int nGrayScale);

	// Generate SVG gradient string.
	CString	SVG_Gradient(CString* sSVGdefs);

	// Generate SVG hatch string.
	CString	SVG_Hatch(CString* sSVGdefs);

	// Generate SVG arrow string.
	CString	SVG_Arrow(int position, UINT Arrow, int ArrowSize, CString* sSVGdefs);
	// Generate hatch svg string

	//-----------------------------------------------------------------------
	// Summary:
	// Generate SVG Text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		str---Specifies A CString type value.  
	//		&rcText---&rcText, Specifies A CRect type value.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&crText---&crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bFullSize---Full Size, Specifies A Boolean value.  
	//		&bRealDraw---Real Draw, Specifies A Boolean value.
	virtual CString SVGGenDrawText(CDC *pDC,const CString& str,const CRect &rcText, UINT nFormat,
		const COLORREF &crText,
		const BOOL &bFullSize = TRUE,const BOOL &bRealDraw = TRUE);
	
	CString       SVG_HtmlFilter(CString sInput);
	CString       SVG_NameStrFilter(CString sInput);
	CString       SVG_AddTextHeader();
	
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Obtain the svg drawing text position.
	virtual FOPRect GetSVGTextPosition(CDC *pDC, BOOL &bFullSize);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate Hatch S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		sDefault---sDefault, Specifies A CString type value.
	virtual CString GenHatchSVG(CString* sDefault);

	// Generate arrow svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Arrow S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nArrow---nArrow, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nArrowSize---Arrow Size, Specifies A integer value.  
	//		sDefault---sDefault, Specifies A CString type value.
	virtual CString GenArrowSVG(int nIndex, UINT nArrow, int nArrowSize, CString* sDefault);

public:
	// Is Select
 
	// Select, This member sets TRUE if it is right.  
	BOOL			bSelect;
    
	// Version of shape.
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nVersion;

	// Is lock or not.
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// Is expression support.
 
	// Is Expression, This member sets TRUE if it is right.  
	BOOL			m_bIsExpression;

	// Font Art type.
	int				m_nArtType;

	// Second expression
	CString			m_strSecondValue;

public:
	// Load image from file.
	BOOL LoadImageFile(const CString &strImage);
	
protected:
	
	// Load picture file
	void LoadPictureFile();
	
public:
	LPPICTURE	m_pPicture;
	int m_nImageWidth;
	int m_nImageHeight;
	CString m_strFileName;
public:

	/*************************************************************************
	|*
	|* Fill brush properties
	|*
	\************************************************************************/

	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	// crBkColor -- new back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Is It Transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTransparent() const;

	// Change to transparent fill mode.
	// bTransparent -- transparent or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void		SetTransparent(const BOOL &bTransparent);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// Get Brush Hatch
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushHatch() const;

	// Change Brush Hatch type,must be (nHatch < HS_HORIZONTAL || nHatch > HS_DIAGCROSS)
	// nHatch -- hatch style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Hatch, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetBrushHatch(const int &nHatch);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,shape use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	// cr -- new pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Define for brush.
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOPTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

// Attributes
public:
	// FODO:Add your properties items below.
	// Get Text Horizon Alignment
	// The alignment of text is one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Horizontal Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextHorzAlignment() const;

	// Set Text Horizon Alignment.
	// nT -- It must be one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextHorzAlignment(const UINT &nT);

	// Get Text Vertical Alignment
	// The text vert alignment returns one of the following value:
	//	enum TextVertAlign 
	//{
	//	  TextTop = 0,				// Top 
	//    TextCenter,					// Center
	//    TextBottom					// Bottom
	//}; 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Vertical Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextVertAlignment() const;

	// Set Text Vertical Alignment,for how to change text vert alignment,please see Text Properties Dialog.
	// nT -- It must be one of the following value:
	//	enum TextVertAlign 
	//{
	//	  TextTop = 0,				// Top 
	//    TextCenter,					// Center
	//    TextBottom					// Bottom
	//}; 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Vertical Alignment, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextVertAlignment(const UINT &nT);

	// Is It MultiLine,if the text is multiple lines,return TRUE,else returns FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsMultiLine() const;

	// Set MultiLine,you can call this method to change the text of CFOTextShape's label to multiple lines.
	// bMulti -- multiple lines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Line, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void		SetMultiLine(const BOOL &bMulti);

public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	// nPointSize -- font point size.
	// pDC -- pointer of the dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	// nHeight -- height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	// Change the Font Color
	// crColor -- font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	// bItalic -- italic or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	// bUnderline -- underline or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	// bStrikeout -- strikeout or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOPTableCell
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);


public:
	// Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOPTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont* CreateFont(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void ReleaseFontObject();

protected:

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// From Logical To Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
    
	// List of frames
 
	// Frame Rectangle, This member specify E-XD++ CFOPCellRect object.  
    CFOPCellRect m_FrameRect;

	// Saving text.
 
	// Save, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strSave;

	// Current flash frame.
	int			m_nCurFlash;

protected:
	// Caption value.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strCaption;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The transparent brush.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// The brush hatch type.
 
	// Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHatch;

	// Cached GDI brush. 
 
	// Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData		m_pBrush;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, This member specify E-XD++ CFOFontObjectData object.  
	CFOFontObjectData	m_pFont;

	// Define for win9x only.
 
	// New Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			*m_pNewFont;

	// Text alignment.
 
	// Text Horizontal Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextHorzAlignment;

	// Vert text alignment.
 
	// Text Vertical Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextVertAlignment;

	// Multi lines
 
	// Multiple Line, This member sets TRUE if it is right.  
	BOOL			m_bMultiLine;

	// Type of control in this table cell.
 
	// Type , This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTypeControl;

	// Options value.
 
	// Choice, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strChoice;
};

_FOLIB_INLINE int CFOPTableCell::GetBrushHatch() const
{
	return m_nHatch;
}

_FOLIB_INLINE int CFOPTableCell::GetBrushType() const
{
	return m_nBrushType;
}

_FOLIB_INLINE BOOL CFOPTableCell::GetTransparent() const
{
	return m_bTransparent;
}

_FOLIB_INLINE void CFOPTableCell::SetTransparent(const BOOL &bTransparent)
{
	ReleaseBrushObject();
	m_bTransparent = bTransparent;
}

_FOLIB_INLINE	COLORREF CFOPTableCell::GetBkColor() const					
{ 
	return m_crBkColor; 
}

_FOLIB_INLINE	void CFOPTableCell::SetBkColor(const COLORREF &crBkColor)	
{	
	ReleaseBrushObject();
	m_crBkColor = crBkColor;
}

_FOLIB_INLINE	void CFOPTableCell::SetPatternColor(const COLORREF &cr)	
{	
	ReleaseBrushObject();
	m_crHatch = cr;
}

_FOLIB_INLINE COLORREF CFOPTableCell::GetPatternColor() const
{
	return m_crHatch;
}

_FOLIB_INLINE	UINT CFOPTableCell::GetTextHorzAlignment()	const
{ 
	return m_nTextHorzAlignment;
}

_FOLIB_INLINE void CFOPTableCell::SetTextHorzAlignment(const UINT &nT)	
{ 
	m_nTextHorzAlignment = nT;
}

_FOLIB_INLINE	BOOL CFOPTableCell::IsMultiLine() const
{
	return m_bMultiLine;
}

_FOLIB_INLINE	void CFOPTableCell::SetMultiLine(const BOOL &bMulti)
{
	m_bMultiLine = bMulti;
}

_FOLIB_INLINE	UINT CFOPTableCell::GetTextVertAlignment()	const
{ 
	return m_nTextVertAlignment;
}

_FOLIB_INLINE void CFOPTableCell::SetTextVertAlignment(const UINT &nT)	
{ 
	m_nTextVertAlignment = nT;
}

_FOLIB_INLINE CString CFOPTableCell::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOPTableCell::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOPTableCell::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOPTableCell::GetFontColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOPTableCell::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOPTableCell::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOPTableCell::SetItalic(const BOOL &bItalic)
{
	ReleaseFontObject();
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOPTableCell::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOPTableCell::SetUnderline(const BOOL &bUnderline)
{
	ReleaseFontObject();
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOPTableCell::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOPTableCell::SetStrikeout(const BOOL &bStrikeout)
{
	ReleaseFontObject();
	m_bStrikeout = bStrikeout;
}

typedef CTypedPtrList<CObList, CFOPTableCell*> CFOPTableCellList;

/////////////////////////////////////////////////////////////
// Table Template define.

 
//===========================================================================
// Summary:
//     The FOPTableTemplate class derived from CObject
//      O P Table Template
//===========================================================================

class FO_EXT_CLASS FOPTableTemplate : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPTableTemplate---O P Table Template, Specifies a FOPTableTemplate object(Value).
	DECLARE_SERIAL(FOPTableTemplate)

// Construction/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Table Template, Constructs a FOPTableTemplate object.
	//		Returns A  value (Object).  
	// Parameters:
	//		name---Specifies A CString type value.
	FOPTableTemplate(const CString & name = _T("Template"));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Table Template, Constructs a FOPTableTemplate object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const FOPTableTemplate& propShape object(Value).
	FOPTableTemplate(const FOPTableTemplate& propShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Template, Destructor of class FOPTableTemplate
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPTableTemplate();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CObject,or NULL if the call failed
	// Create a copy of current object.
	virtual CObject* Copy();

public:
	
	// Return Name value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetName() const { return m_strName;}

	// Change Name value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Name, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetName( const CString &strValue ) {m_strName = strValue; }

	// Return m_firstRow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getfirst Row, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetfirstRow() const { return m_firstRow;}

	// Change m_firstRow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setfirst Row, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetfirstRow( const CFOPTableCell &daValue ) {m_firstRow = daValue; }

	// Return m_lastRow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getlast Row, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetlastRow() const { return m_lastRow;}

	// Change m_lastRow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setlast Row, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetlastRow( const CFOPTableCell &daValue ) {m_lastRow = daValue; }

	// Return m_firstCol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getfirst Column, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetfirstCol() const { return m_firstCol;}

	// Change m_firstCol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setfirst Column, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetfirstCol( const CFOPTableCell &daValue ) {m_firstCol = daValue; }

	// Return m_lastCol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getlast Column, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetlastCol() const { return m_lastCol;}

	// Change m_lastCol value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setlast Column, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetlastCol( const CFOPTableCell &daValue ) {m_lastCol = daValue; }

	// Return m_bodyCell value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getbody Cell, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetbodyCell() const { return m_bodyCell;}

	// Change m_bodyCell value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setbody Cell, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetbodyCell( const CFOPTableCell &daValue ) {m_bodyCell = daValue; }

	// Return m_topLeftCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gettop Left Corner, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GettopLeftCorner() const { return m_topLeftCorner;}

	// Change m_topLeftCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Settop Left Corner, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SettopLeftCorner( const CFOPTableCell &daValue ) {m_topLeftCorner = daValue; }

	// Return m_topRightCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gettop Right Corner, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GettopRightCorner() const { return m_topRightCorner;}

	// Change m_topRightCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Settop Right Corner, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SettopRightCorner( const CFOPTableCell &daValue ) {m_topRightCorner = daValue; }

	// Return m_bottomRightCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getbottom Right Corner, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetbottomRightCorner() const { return m_bottomRightCorner;}

	// Change m_bottomRightCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setbottom Right Corner, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetbottomRightCorner( const CFOPTableCell &daValue ) {m_bottomRightCorner = daValue; }

	// Return m_bottomLeftCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Getbottom Left Corner, Returns the specified value.
	//		Returns A E-XD++ CFOPTableCell value (Object).
	CFOPTableCell GetbottomLeftCorner() const { return m_bottomLeftCorner;}

	// Change m_bottomLeftCorner value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setbottom Left Corner, Sets a specify value to current class FOPTableTemplate
	// Parameters:
	//		&daValue---&daValue, Specifies a const CFOPTableCell &daValue object(Value).
	void SetbottomLeftCorner( const CFOPTableCell &daValue ) {m_bottomLeftCorner = daValue; }

// Attributes
protected:
	// FODO:Add your properties items below.
	// Name value.
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                           m_strName;

	// m_firstRow value.
 
	// Row, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_firstRow;

	// m_lastRow value.
 
	// Row, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_lastRow;

	// m_firstCol value.
 
	// Column, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_firstCol;

	// m_lastCol value.
 
	// Column, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_lastCol;

	// m_bodyCell value.
 
	// Cell, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_bodyCell;

	// m_topLeftCorner value.
 
	// Left Corner, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_topLeftCorner;

	// m_topRightCorner value.
 
	// Right Corner, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_topRightCorner;

	// m_bottomRightCorner value.
 
	// Right Corner, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_bottomRightCorner;

	// m_bottomLeftCorner value.
 
	// Left Corner, This member specify E-XD++ CFOPTableCell object.  
	CFOPTableCell                      m_bottomLeftCorner;


public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPTableTemplate& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const FOPTableTemplate& propEdit object(Value).
	FOPTableTemplate& operator=(const FOPTableTemplate& propEdit);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

_FOLIB_INLINE CObject* FOPTableTemplate::Copy()
{
	return new FOPTableTemplate(*this);
}

////////////////////////////////////////////////////////////////////////
// Table template list.

typedef CTypedPtrList<CObList, FOPTableTemplate*> FOPTableTemplateList;

//////////////////////////////////////////////////////////
// CFOPTableShape -- table shape, this is a MS Word like table control.
//			You can define multiple columns or rows, and change the width
//			of each column, split the table cell or merge multiple cells.
//			You can also define the font or fill style of each cell.
//
//			Each cell can be edited.
//			ID: FOP_TABLE_SHAPE 239
//

 
//===========================================================================
// Summary:
//     The CFOPTableShape class derived from CFODrawShape
//      F O P Table Shape
//===========================================================================

class FO_EXT_CLASS CFOPTableShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPTableShape---F O P Table Shape, Specifies a E-XD++ CFOPTableShape object (Value).
	DECLARE_SERIAL(CFOPTableShape);
	
public:
	// Implementation
 
	// F O P Table Cell, This member specify friend class object.  
	friend class CFOPTableCell;

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Shape, Constructs a CFOPTableShape object.
	//		Returns A  value (Object).
	CFOPTableShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Shape, Constructs a CFOPTableShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPTableShape& src object(Value).
	CFOPTableShape(const CFOPTableShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Shape, Destructor of class CFOPTableShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPTableShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of this shape.
	// strCaption -- caption
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nRow---&nRow, Specifies A integer value.  
	//		&nCol---&nCol, Specifies A integer value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of this shape.
	// nRow -- rows of table.
	// nCol -- columns of table.
	// strCaption -- caption
	virtual void Create(CRect &rcPos,const int &nRow, const int &nCol,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&ColWidths---Column Widths, Specifies A integer value.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&RowHeights---Row Heights, Specifies A integer value.  
	//		&strCaption---&strCaption, Specifies A CString type value.
	// Create the table shape with column width and row height.
	// ptStart -- start point of this shape.
	// ColWidths -- width of each column.
	// RowHeights -- height of each row.
	virtual void Create(const CPoint &ptStart, const CArray<int, int> &ColWidths, const CArray<int, int> &RowHeights, const CString &strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

public:

	// Assignment operator.
	virtual CFont *GetVirFont();
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPTableShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPTableShape& src object(Value).
	CFOPTableShape& operator=(const CFOPTableShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Initial Property Value, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL DoGetInitPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Get normal spot count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetNormalSpotCount() const;

	// Get plus spot count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetPlusSpotCount() const;

	// call this method to put the text object into edit in place mode.
	// pView -- pointer of view.
	// ptCursotSP -- cussor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		ptCursorSP---Cursor S P, Specifies A CPoint type value.
	virtual BOOL DoStartShowEdit(CFOPCanvasCore* pView, CPoint ptCursorSP);
    
	// Clear all the data of table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Datas, Remove the specify data from the list.

	void ClearAllDatas();
	
	// Get the sport point of control by drag handle,calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the plus spots of the control handles,override this method to calculate the new position of the handle.
	// mpSpot -- result of the spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location,override this method to calc the new rotating control handle.
	// ptHandle -- result rotating control handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

	// get a frame by number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame, Returns the specified value.
	//		Returns a pointer to the object CFOPCellRect ,or NULL if the call failed  
	// Parameters:
	//		_num---Specifies A integer value.
    CFOPCellRect *GetFrame( unsigned int _num ) const;
    
	// Apply table template.
	// pTemplate -- pointer of the template.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Table Template, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pTemplate---*pTemplate, A pointer to the FOPTableTemplate  or NULL if the call failed.
	virtual void ApplyTableTemplate(FOPTableTemplate *pTemplate);
	
public:
	// Update saving with all the labels of cells.
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

public:
	// Export to SVG
	virtual void ExportToSVG(CStdioFile*);

	//-----------------------------------------------------------------------
	// Summary:
	// Update Saving, Call this member function to update the object.

	void UpdateSaving();
	
	// Restore saving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Saving, .

	void RestoreSaving();
	
	// Update value with variable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Variable, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateVar();

	// Update value with variable.
	void UpdateVar(const CString &strVar, const CString &strValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the TRUEly shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	    
    /// Represents a row, for direct access to cells with m_aCurRowArray[row][column]
    class CFOTableRow 
    {
    public:
		// Operator []
        CFOPTableCell* operator[] ( UINT i ) const { return i < GetSize() ? m_aCellArray[i] : 0; }

		// size of cells
        UINT GetSize() const { return m_aCellArray.GetSize(); }

		// Count of cells.
        UINT GetCount() const { return m_aCellArray.GetCount(); }
        
		// Add new cell to this row
        void AddCell( CFOPTableCell *cell );

		// Remove cell from this row
        void RemoveCell( CFOPTableCell* cell );

		// Clear all the cells
		void ClearAll();
        
        // If a cell has m_nTotalCols = N, N values in this array point to the same cell.
        // (Same thing is a cell from a row above has m_nTotalRows > 1)
        FOTablePtrVector< CFOPTableCell > m_aCellArray;
        
    };
    
    // The three different types of CFOPTableIterators
    enum FOP_VISIT_TYPE
	{
		// This iterator visits each grid position once, ie every
		// location in the m_aCurRowArray rows. When some cells are joined, this
		// iterator will visit those cells more than once.
        VISIT_GRID = 1,
            
		// This iterator visits each cell in the table once, whether
		// or not some of the cells are joined. If you want to visit all the cells
		// fast and perform some read-only operation, this is the one to use.
		VISIT_CELL = 2,
			
		// Like VISIT_CELL it also visits each cell once, but has some other benefits. Slower.
		CHECKED = 3
    };
    
    // All the CFOPTableIterator templates are the same, except for the pre-increment
    // operator (operator++). There is a specialised version of this
    // operator method for each iterator type.
    template<int VisitStyle = VISIT_CELL>
        class CFOPTableIterator
	{
    public:
		// param table The table to iterate over. The current item is set to the CFOPTableCell
		// at row 0, column 0
        CFOPTableIterator (CFOPTableShape *table);
        
		// To first cell
        CFOPTableCell* ToFirstCell ();

		// Switch to cell
        void GoToCell(CFOPTableCell*);
        
		// operator *
        operator CFOPTableCell* () const { return m_pCell; }

		// Current
        CFOPTableCell * Current() const;

		// Operator ->
        CFOPTableCell * operator->() { return m_pCell; }

		// Operator ++
        CFOPTableCell * operator++ ();
        
    protected:

		// Pointer of table shape.
        CFOPTableShape *m_table;

		// Change limits
        void SetLimits(UINT left, UINT right, UINT high, UINT low)
        {
            m_limit[LEFT] = left;
            m_limit[RIGHT] = right;
            m_limit[HIGH] = high;
            m_limit[LOW] = low;
        }

    protected:
        // Pointer of cell.
        CFOPTableCell *m_pCell;

		// Current row.
        UINT m_pCurRow;

		// Current column.
        UINT m_nCurCol;
        
		// Direction
        enum Direction {LEFT, RIGHT, HIGH, LOW};

		// Limits
        UINT m_limit[4];
    };
    
	//	VISIT_CELL: This iterator visits each cell in the table once, whether
    //  or not some of the cells are joined. If you want to visit all the cells
    //  fast and perform some read-only operation, this is the one to use.
 
	// O P Table Iter, This member specify typedef CFOPTableIterator<VISIT_CELL> object.  
    typedef CFOPTableIterator<VISIT_CELL> FOPTableIter;

	//  VISIT_GRID: This iterator visits each grid position once, ie every
    //  location in the m_aCurRowArray rows. When some cells are joined, this
    //  iterator will visit those cells more than once.
 
	// O P Grid Iter, This member specify typedef CFOPTableIterator<VISIT_GRID> object.  
    typedef CFOPTableIterator<VISIT_GRID> FOPGridIter;

	// CHECKED: Also visits each cell once, but has some other benefits. Slower.
 
	// O P Checked Iter, This member specify typedef CFOPTableIterator<CHECKED> object.  
    typedef CFOPTableIterator<CHECKED> FOPCheckedIter;
    
    // This iterator does not look at the CFOPTableCell instance variables
    // during traversal, (except m_bMarker), so they can be safely
    // changed during the traversal. However, to the user it does
    // not visit every grid position, it visits each cell once.
    // (in spite of the fact that it inherits from a grid-visiting
    // iterator).
    // Only one MarkedIterator can be used at once.  See CFOPTableIterator
    class MarkedIterator : public CFOPTableIterator<VISIT_GRID> 
	{
    public:
        MarkedIterator(CFOPTableShape *table);
        CFOPTableCell *operator++();     // overridden from base but not virtual
        
    };
    
	// Draw borders of the table cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Borders, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		painter---Specifies A integer value.  
	//		&crect---Specifies A CRect type value.
    void OnDrawBorders( CDC& painter, const CRect &crect);

	// Clear all the cells data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Cells, Remove the specify data from the list.

	void ClearAllCells();

	// Same with UpdateRects
	void UpdateFrames(int flags );

public:
	
	// Reset all the selection.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Selection, Called this function to empty a previously initialized CFOPTableShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetAllSelection();

	// Select one row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select One Row, Call this function to select the given item.
	// Parameters:
	//		&nRowIndex---Row Index, Specifies A integer value.
	void SelectOneRow(const int &nRowIndex);

	// Select one Column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select One Column, Call this function to select the given item.
	// Parameters:
	//		&nColIndex---Column Index, Specifies A integer value.
	void SelectOneColumn(const int &nColIndex);

	// Select cells within rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Within, Call this function to select the given item.
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SelectWithin(const CRect &rc);

	// Select cells within rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Maximize Select Rectangle, .
	//		Returns a CRect type value.  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	CRect MaxSelectRect(const CRect &rc);

	// Obtain the true maximize rectangle of cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get True Maximize Grid Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTrueMaxGridRect();

	// On key down changing selection
	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*cell---A pointer to the CFOPTableCell  or NULL if the call failed.
	virtual void OnKeyDownSelect(UINT nChar, CFOPTableCell *cell);

	// Get all the selected cells within the table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Cells, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual void GetSelectCells(CFOPTableCellList *pSelectList);

	// Get total rows within the list of cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select Rows, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void GetTotalSelectRows(CFOPTableCellList *pSelectList,CArray<int, int> &arValues);

	// Get total columns within the list of cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select Columns, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void GetTotalSelectColumns(CFOPTableCellList *pSelectList,CArray<int, int> &arValues);

	// Get first row cell of all the selections.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Row Select Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell,or NULL if the call failed  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual CFOPTableCell* GetFirstRowSelectCell(CFOPTableCellList *pSelectList);

	// Get first column cell of all the selections.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Column Select Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell,or NULL if the call failed  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual CFOPTableCell* GetFirstColSelectCell(CFOPTableCellList *pSelectList);

	// Get last row cell of all the selections.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last Row Select Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell,or NULL if the call failed  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual CFOPTableCell* GetLastRowSelectCell(CFOPTableCellList *pSelectList);

	// Get last column cell of all the selections.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last Column Select Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell,or NULL if the call failed  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual CFOPTableCell* GetLastColSelectCell(CFOPTableCellList *pSelectList);

	// Obtain current cell's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Cell, Returns the specified value.
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed
	CFOPTableCell *GetCurrentCell();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		row---Specifies A integer value.  
	//		column---Specifies A integer value.
	// Cell at a specify row and column
    CFOPTableCell *cell( unsigned int row, unsigned int column ) const;

	// Obtain cell by position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell By Position, Returns the specified value.
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		x---Specifies a double x object(Value).  
	//		y---Specifies a double y object(Value).
    CFOPTableCell *GetCellByPos( double x, double y );
    
	// Cell size
    enum FOPTABLE_CELLSIZE
	{
        TblAuto = 0,
        TblManual
    };

	// Change current hit cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Hit Cell, .
	// Parameters:
	//		nRow---nRow, Specifies A integer value.  
	//		nCol---nCol, Specifies A integer value.
	void ChangeHitCell(int nRow, int nCol);

    // Calculate the absolute size of the complete table.
    //  From the first cell to the last, including page breaks et.
    //  return CRect which outlines the whole of the table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Inside Rectangle, Returns the specified value.
	//		Returns a CRect type value.
    CRect GetInsideRect();
    
    // Layout all cells to fit inside the rect, cells will however use a minimum size, so
    // the table might end up bigger.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Column Row Position, Call this member function to update the object.
	// Parameters:
	//		rect---Specifies A CRect type value.  
	//		widthMode---widthMode, Specifies a FOPTABLE_CELLSIZE widthMode object(Value).  
	//		heightMode---heightMode, Specifies a FOPTABLE_CELLSIZE heightMode object(Value).
    void UpdateColRowPosition( CRect rect, FOPTABLE_CELLSIZE widthMode, FOPTABLE_CELLSIZE heightMode );

	// Layout all cells to fit the cols and rows, cells will however use a minimum size, so
    // the table might end up bigger.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Column Row Position, Call this member function to update the object.
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&ColWidths---Column Widths, Specifies A integer value.  
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&RowHeights---Row Heights, Specifies A integer value.
    void UpdateColRowPosition(const CPoint &ptStart, const CArray<int, int> &ColWidths, const CArray<int, int> &RowHeights);
    
	// Layout all cells to fit the cols and rows, cells will however use a minimum size, so
    // the table might end up bigger.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Column Row Position, Call this member function to update the object.
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.
    void UpdateColRowPosition(const CPoint &ptStart);
    
    
    // Calculate the top postion of the cell(s) in the leftmost column
    // return double table leftmost position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Top Without Border, .
	//		Returns A double value (Object).
    double TopWithoutBorder();
    
    // Calculate the top postion of the cell(s) in the top row
    // return double table top position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Left Without Border, .
	//		Returns A double value (Object).
    double LeftWithoutBorder();
    
    //  change the width of the table, keeping the proportions of the cells
    // (if one is wider than the others, it is still wider after resize)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Width, .
	// Parameters:
	//		width---Specifies a double width object(Value).
    void ResizeWidth( double width );

	//  change the width of the table, keeping the proportions of the cells
    // (if one is wider than the others, it is still wider after resize)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Height, .
	// Parameters:
	//		height---Specifies a double height object(Value).
    void ResizeHeight( double height );
    
    // resize and position all cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Layout Cols, .
	// Parameters:
	//		column---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		row---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void ReLayoutCols(UINT column, UINT row);

	// Relayout rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Layout Rows, .
	// Parameters:
	//		column---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		row---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void ReLayoutRows(UINT column, UINT row);
    
    // move a column edge (i.e. col can be 0 to getCols()+1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Column, .
	// Parameters:
	//		col---Specifies A integer value.  
	//		x---Specifies a double x object(Value).
    void ResizeColumn( unsigned int col, double x );

    // move a row edge (i.e. row can be 0 to GetRows()+1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Row, .
	// Parameters:
	//		row---Specifies A integer value.  
	//		y---Specifies a double y object(Value).
    void ResizeRow( unsigned int row, double y );
    
	// Obtain the size of the column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Size, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		col---Specifies A integer value.
    double GetColumnSize( unsigned int col );

	// Obtain the size of the row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Size, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		col---Specifies A integer value.
    double GetRowSize( unsigned int col );
    
    // return the number of the column edge closest to x (between 0 and getCols()+1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Edge At, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		x---Specifies a double x object(Value).
    int GetColumnEdgeAt( double x ) const;

	// Hit test column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Column, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestColumn(const CPoint &ptHit, int &nHitIndex);

	// Hit test column to select one column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Column Header, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestColumnHeader(const CPoint &ptHit, int &nHitIndex);


	// Update edit control.
	// pView -- pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void DoUpdateEdit(CFOPCanvasCore* pView);

	// Obtain text box size.
	// pDC -- pointer of the DC
	// rcPos -- rectangle for contain the text.
	// strText -- text string for drawing.
	// nHeight -- total text height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		strText---strText, Specifies A CString type value.  
	//		&nHeight---&nHeight, Specifies A integer value.
	virtual CSize GetTextSize(CDC* pDC,CRect rcPos,CString strText,int &nHeight);

    // return the number of the row edge closest to x (between 0 and GetRows()+1)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Edge At, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		y---Specifies a double y object(Value).
    int GetRowEdgeAt( double y ) const;

	// Hit test Row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Row, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestRow(const CPoint &ptHit, int &nHitIndex);

	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
    virtual CFOPTableCell *HitTestGridSmall(CPoint pt);
    
	// Hit test Row header to select on row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Row Header, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestRowHeader(const CPoint &ptHit, int &nHitIndex);
    
	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
    virtual CFOPTableCell *HitTestGrid(CPoint pt);
    
	// Change cell text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Cell Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strCell---&strCell, Specifies A CString type value.
	virtual void ChangeCellText(const CString &strCell);

	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD GenEditingLabelAlign();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GenLabelAlign();
	
	// Return With Label Editing value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get With Label Editing, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetWithLabelEditing();

	// Calculate the label start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

    // returns the number of rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rows, Returns the specified value.
	//		Returns a int type value.
    unsigned int GetRows() const { return m_nTotalRows; }

    // returns the number of columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Columns, Returns the specified value.
	//		Returns a int type value.
    unsigned int GetColumns() const { return m_nTotalCols; }
    
    // returns the number of cells the table contains, this includes
    // temporary headers.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Cells, Returns the specified value.
	//		Returns a int type value.
    unsigned int GetNumCells()const { return m_nTotalCells; }

	// Check validate.
	BOOL BeColValidate(const int &nCol);
    
    // Check validate.
	BOOL BeRowValidate(const int &nRow);
    
    // move the whole of the table, this is mainly for anchored frames.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move By, .
	// Parameters:
	//		dx---Specifies a double dx object(Value).  
	//		dy---Specifies a double dy object(Value).
    void MoveBy( double dx, double dy );
    
    // insert a row of new cells, use the getCols() call to decide how many cells are created
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert New Row, Inserts a child object at the given index..
	// Parameters:
	//		_idx---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		_recalc---Specifies A Boolean value.  
	//		_removeable---Specifies A Boolean value.
    void InsertNewRow( UINT _idx, BOOL _recalc = TRUE, BOOL _removeable = FALSE );

    // insert a column of new cells use the GetRows() call to decide how many cells are created
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert New Column, Inserts a child object at the given index..
	// Parameters:
	//		_idx---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		width---Specifies a double width = 60 object(Value).
    void InsertNewColumn( UINT _idx, double width = 60);
    
    // Remove all the cells in a certain row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Row, Deletes the given object.
	// Parameters:
	//		_idx---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rr---Specifies a E-XD++ CFOPRemovedRow &rr object (Value).  
	//		_recalc---Specifies A Boolean value.
    void DeleteRow( UINT _idx, CFOPRemovedRow &rr, BOOL _recalc = TRUE);
    
    // remove all the cells in a certain column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Column, Deletes the given object.
	// Parameters:
	//		_idx---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rc---Specifies a E-XD++ CFOPRemovedColumn &rc object (Value).
    void DeleteColumn( UINT _idx, CFOPRemovedColumn &rc);
    
    // replace a row that was removed with DeleteRow()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Insert Row, .
	// Parameters:
	//		&row---Specifies a E-XD++ CFOPRemovedRow &row object (Value).
    void ReInsertRow(CFOPRemovedRow &row);

    // replace a column that was removed with DeleteColumn()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Insert Column, .
	// Parameters:
	//		&col---Specifies a E-XD++ CFOPRemovedColumn &col object (Value).
    void ReInsertColumn(CFOPRemovedColumn &col);
    
	// Is active or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Active, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsActive()const { return m_bActive; }
    
    // Merge cells to one cell. Will loose all text not in top-left cell
    //  FirstColumn the first column of the square of columns that will be used to merge
    //  FirstRow the first row
    //  endColumn the last column that will end up in the merged cell
    //  endRow last row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Join Cells, .
	// Parameters:
	//		FirstColumn---First Column, Specifies A integer value.  
	//		FirstRow---First Row, Specifies A integer value.  
	//		endColumn---endColumn, Specifies A integer value.  
	//		endRow---endRow, Specifies A integer value.
    void JoinCells(unsigned int FirstColumn,unsigned int FirstRow, unsigned int endColumn,unsigned int endRow);

    // Split one cell into a number of cells.
    //  intoRows the amount of rows the cell should be split into
    //  intoColumns the amount of columns the cell should be split into
    //  column the column of the cell to be split
    //  row the row of the cell to be split
    //  listFrameSet needed for undo reasons
    //  listFrame needed for undo reasons
    void SplitCell(unsigned int intoRows, unsigned int intoColumns, unsigned int column,
        unsigned int row, FOTablePtrList<CFOPTableCell> listFrameSet=FOTablePtrList<CFOPTableCell>(),
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer List< C F O P Cell Rect>list Frame= F O Table Pointer List< C F O P Cell Rect>, .
	//		Returns A  value (Object).  
	// Parameters:
	//		)---Specifies a ) object(Value).
            FOTablePtrList<CFOPCellRect>listFrame=FOTablePtrList<CFOPCellRect>());
    
    // do a number of complex tests to test the validity of the table. Missing/duplicate cells
    // and wrong values will be detected (and corrected)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Validate, .

    void Validate();
    
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finalize, .
	// This member function is also a virtual function, you can Override it if you need,
	// Finalize
    virtual void Finalize();

	// Get best insert before index.
	int GetBestInsertBefore(int nIdx1);

	// Get best row insert before index.
	int GetBestRowInsertBefore(int nIdx1);

	// Get best insert after index.
	int GetBestInsertAfter(int nIdx1);


	// Get best row insert after index.
	int GetBestRowInsertAfter(int nIdx1);

	// In validate
	
	//-----------------------------------------------------------------------
	// Summary:
	// In Validate, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void InValidate();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout, .
	// This member function is also a virtual function, you can Override it if you need,
	// Layout
    virtual void Layout();
    
	// Update rects or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Rects, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		flags---Specifies A integer value.
    virtual void UpdateRects( int flags = 0xff );

	// Set visible or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOPTableShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		v---Specifies A Boolean value.
    virtual void SetVisible( BOOL v );
    
    // Add a cell to this table, the cell should already have info like row, col and should
    // already have a frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Cell, Adds an object to the specify list.
	// Parameters:
	//		*cell---A pointer to the CFOPTableCell  or NULL if the call failed.
    void AddCell( CFOPTableCell *cell );
    
    // Remove a cell from this table (either to delete it, or to move it)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Cell, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		cell---A pointer to the CFOPTableCell or NULL if the call failed.
    void RemoveCell( CFOPTableCell* cell );
    
    // The normal mechanism doesn't apply to tables; cells are protected individually
    // (in terms of data; the GUI has an item for protecting all cells at once)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Protect Content, Sets a specify value to current class CFOPTableShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		BOOL---O O L, Specifies A Boolean value.
    virtual void SetProtectContent ( BOOL ) {}
	
	//-----------------------------------------------------------------------
	// Summary:
	// Protect Content, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    virtual BOOL ProtectContent() const { return FALSE; }
    
    // frame management
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*_frame---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		recalc---Specifies A Boolean value.
    virtual void AddRect( CFOPCellRect *_frame, BOOL recalc = TRUE );
    
    // Delete a rect from the set of rects this rect list has.
    //  frm The frame that should be deleted
    //  remove passing TRUE means that there can not be an undo of the action.
    //  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		*frm---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    void RemoveRect( CFOPCellRect *frm, BOOL remove = TRUE, BOOL recalc = TRUE ); // calls the virtual one
    
    // Delete a rect from the set of rects this rect list has.
    //  num The frameNumber to be removed.
    //  remove passing TRUE means that there can not be an undo of the action.
    //  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		num---Specifies A integer value.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    virtual void RemoveRect( unsigned int num, BOOL remove = TRUE, BOOL recalc = TRUE );
    
	// Delete all rects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Rects, Deletes the given object.

    void DeleteAllRects();

	// Delete all rect copies
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All Copies, Deletes the given object.

    void DeleteAllCopies();

    // Get rect number 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Frame From Pointer, .
	//		Returns a int type value.  
	// Parameters:
	//		*frame---A pointer to the CFOPCellRect  or NULL if the call failed.
    int FrameFromPtr( CFOPCellRect *frame );

  
protected:
    // Add cell to array
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Cell To Array, Adds an object to the specify list.
	// Parameters:
	//		cell---A pointer to the CFOPTableCell or NULL if the call failed.
    void AddCellToArray( CFOPTableCell* cell );

	// Do something after cell loading.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh Data, .
	// Parameters:
	//		cell---A pointer to the CFOPTableCell or NULL if the call failed.
    void RefreshData( CFOPTableCell* cell );

    
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position, .
	// Parameters:
	//		*theCell---*theCell, A pointer to the CFOPTableCell  or NULL if the call failed.  
	//		setMinFrameHeight---Minimize Frame Height, Specifies A Boolean value.
    // @brief position an individual cell in the grid
    // Adjusts the size of the cell frames.
    // It computes the sizes based on:
    // <ol>
    // <li>The values in the m_aCurColPositionList and m_aCurRowPositionList arrays.
    // <li>The width of the CFOPTableCell borders.
    // </ol>
    void Position(CFOPTableCell *theCell, BOOL setMinFrameHeight=FALSE);
    
    // @brief Returns the absolute top-position of the row in the grid
    //
    // Returns a double value from m_aCurRowPositionList. This is either the bottom
    // or top position of the row of cells @p row. Note that you cannot index
    // directly into m_aCurRowPositionList from a row value obtained from a cell,
    // eg cell->FirstRow(), because of the extra elements in m_aCurRowPositionList when
    // the table spans multiple pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position Of Row, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		row---Specifies A integer value.  
	//		bottom---Specifies A Boolean value.
    double GetPositionOfRow(unsigned int row, BOOL bottom=FALSE);
    
	// Insert an empty column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Empty Column, Inserts a child object at the given index..
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void InsertEmptyColumn(UINT index);
    
    //  insert a row in m_aCurRowArray at position index. rows after
    //  the inserted row are moved back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Row Vector, Inserts a child object at the given index..
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*row---A pointer to the CFOTableRow  or NULL if the call failed.
    void InsertRowVector(UINT index, CFOTableRow *row);
    
    //  remove the row from m_aCurRowArray at position index.
    //  rows after are moved forward
    //  @return the removed row
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Row Vector, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CFOTableRow,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    CFOTableRow* RemoveRowVector(UINT index);
    
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

protected:

	// Second Value, This member specify double object.  
	double				m_dSecondValue;

public:
	class FOPTableKeyData
	{
	public:
		// Total rows or columns.
		unsigned int m_nTotalRows, m_nTotalCols, m_nTotalCells;
		
		// Row array
		FOTablePtrVector< CFOTableRow > m_aCurRowArray;
		
		// The list of page boundaries.
		//   Each page the table spans has an entry in this list which points to the last _line_
		//   on a page.
		//   For a 1 page table there is no page break; and therefor for such tables this list is
		//   empty.
		FOPValueList<unsigned int> m_aPageBoundsList;
		
		// Row positions
		FOPValueList<double> m_aCurRowPositionList, m_aCurColPositionList;
		
		
	public:
		
		// Constructor.
		FOPTableKeyData() 
		{
			m_nTotalRows    = m_nTotalCols = m_nTotalCells = 0;
		};
		
		// Copy constructor.
		FOPTableKeyData(const FOPTableKeyData& src)
		{
			m_nTotalRows    = m_nTotalCols = m_nTotalCells = 0;
			*this				= src;
		};
		
		// Add a cell to this table, the cell should already have info like row, col and should
		// already have a frame.
		void AddCell( CFOPTableCell *daCell )
		{
			m_nTotalRows = max( daCell->RowAfter(), m_nTotalRows );
			m_nTotalCols = max( daCell->ColumnAfter(), m_nTotalCols );
			
			if ( m_aCurRowArray.GetSize() < daCell->RowAfter() )
			{
				m_aCurRowArray.resize( daCell->RowAfter() );
			}
			
			for ( UINT row = daCell->FirstRow() ;row < daCell->RowAfter(); ++row )
			{
				if ( !m_aCurRowArray[ row ] )
				{
					m_aCurRowArray.insert( row, new CFOTableRow );
				}
				
				m_aCurRowArray[ row ]->AddCell( daCell );
			}
		}

		// Destructor.
		virtual ~FOPTableKeyData()
		{
			DeleteAllRects();
			
			CFOPTableCellList m_cells;
			UINT i = 0;
			int j = 0;
			for(i = 0; i < m_aCurRowArray.GetSize(); ++i) 
			{
				CFOTableRow *r = m_aCurRowArray[i];
				
				int nCount = r->m_aCellArray.GetSize();
				for(j = 0; j < nCount; j++)
				{
					CFOPTableCell* cell = (CFOPTableCell*)r->m_aCellArray.at(j);
					if ( cell != NULL )
					{
						if(m_cells.Find(cell) == NULL)
						{
							m_cells.AddTail(cell);
						}
					}
				}
			}
			
			POSITION pos = m_cells.GetHeadPosition();
			while(pos != NULL)
			{
				delete m_cells.GetNext(pos);
			}
			
			m_cells.RemoveAll();
			
			for(i = 0; i < m_aCurRowArray.GetSize(); ++i) 
			{
				CFOTableRow *r = m_aCurRowArray[i];
				
				delete r;
				r = NULL;
			}
		};
	
		// Operator =
		// src -- target object
		virtual FOPTableKeyData& operator=(const FOPTableKeyData & src)
		{
			// m_aFrameList.
			
			m_nTotalRows		= m_nTotalCols = m_nTotalCells = 0;
			m_nTotalCells       = src.m_nTotalCells;
			m_nTotalRows        = src.m_nTotalRows;
			m_nTotalCols        = src.m_nTotalCols;
			
			// m_aPageBoundsList.
			m_aPageBoundsList.clear();
			int nSize = src.m_aPageBoundsList.GetCount();
			for ( int x1 = 0; x1 < nSize; x1++ )
			{
				m_aPageBoundsList.append(src.m_aPageBoundsList[x1]);
			}
			
			// m_aCurRowPositionList.
			m_aCurRowPositionList.clear();
			nSize = src.m_aCurRowPositionList.GetCount();
			for ( int x2 = 0; x2 < nSize; x2++ )
			{
				m_aCurRowPositionList.append(src.m_aCurRowPositionList[x2]);
			}
			
			// m_aCurColPositionList.
			m_aCurColPositionList.clear();
			nSize = src.m_aCurColPositionList.GetCount();
			for ( int x3 = 0; x3 < nSize; x3++ )
			{
				m_aCurColPositionList.append(src.m_aCurColPositionList[x3]);
			}
			
			ClearAllCells();
			
			int nRows = src.m_nTotalRows;
			int nCols = src.m_nTotalCols;
			
			for(int row = 0; row < nRows; row ++)
			{
				for(int col = 0; col < nCols; col ++)
				{
					CFOPTableCell* cellx = src.cell(row,col);// ->Copy();
					CFOPTableCell *pNew = new CFOPTableCell(row, col);
					AddCell(pNew);
					if(cellx != NULL)
					{
						*pNew = *cellx;
					}

					//			cellx->BuildTable(pNew);
				}
			}
			
			return *this;
		}
		
		// Create a duplicate copy of this object.
		virtual FOPTableKeyData* Copy() const
		{
			return (new FOPTableKeyData(*this));
		}
		
		// Delete all rects
		void DeleteAllRects();
		
		// frame management
		virtual void AddRect( CFOPCellRect *_frame);
		
		// Clear all the cells data.
		void ClearAllCells();
		
		// Cell at a specify row and column
		CFOPTableCell *cell( unsigned int row, unsigned int column ) const;
		
	};

public:
	/*************************************************************************
	|*
	|* TableKey data of the shape.
	|*
		\************************************************************************/
		
		// Create a new copy of data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Table Key Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPTableKeyData,or NULL if the call failed
		virtual FOPTableKeyData* NewTableKeyData() const
		{
			return new FOPTableKeyData;
		};
		
		// Create copying of the TableKeymetry data of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Table Key Data, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		src---Specifies a FOPTableKeyData& src object(Value).
		virtual void CopyTableKeyData(FOPTableKeyData& src) const
		{
			
			src.m_nTotalCells       = m_nTotalCells;
			src.m_nTotalRows        = m_nTotalRows;
			src.m_nTotalCols        = m_nTotalCols;
			
			// m_aPageBoundsList.
			src.m_aPageBoundsList.clear();
			int nSize = m_aPageBoundsList.GetCount();
			for ( int x1 = 0; x1 < nSize; x1++ )
			{
				src.m_aPageBoundsList.append(m_aPageBoundsList[x1]);
			}
			
			// m_aCurRowPositionList.
			src.m_aCurRowPositionList.clear();
			nSize = m_aCurRowPositionList.GetCount();
			for ( int x2 = 0; x2 < nSize; x2++ )
			{
				src.m_aCurRowPositionList.append(m_aCurRowPositionList[x2]);
			}
			
			// m_aCurColPositionList.
			src.m_aCurColPositionList.clear();
			nSize = m_aCurColPositionList.GetCount();
			for ( int x3 = 0; x3 < nSize; x3++ )
			{
				src.m_aCurColPositionList.append(m_aCurColPositionList[x3]);
			}
			
			src.ClearAllCells();
			
			int nRows = GetRows();
			int nCols = GetColumns();
			
			for(int row = 0; row < nRows; row ++)
			{
				for(int col = 0; col < nCols; col ++)
				{
					CFOPTableCell* cellx = cell(row,col);// ->Copy();
					
					CFOPTableCell *pNew = new CFOPTableCell(row, col);
					src.AddCell(pNew);
					if(cellx != NULL)
					{
						*pNew = *cellx;
					}
				}
			} 
		};
		
		// Rest the TableKeymetry data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rest Table Key Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		src---Specifies a const FOPTableKeyData& src object(Value).
		virtual void RestTableKeyData(const FOPTableKeyData& src)
		{
			ClearAllDatas();
			
			m_nTotalRows		= m_nTotalCols = m_nTotalCells = 0;
			m_bActive			= TRUE;
			m_nTotalCells       = src.m_nTotalCells;
			m_nTotalRows        = src.m_nTotalRows;
			m_nTotalCols        = src.m_nTotalCols;
		
			// m_aPageBoundsList.
			m_aPageBoundsList.clear();
			int nSize = src.m_aPageBoundsList.GetCount();
			for ( int x1 = 0; x1 < nSize; x1++ )
			{
				m_aPageBoundsList.append(src.m_aPageBoundsList[x1]);
			}
			
			// m_aCurRowPositionList.
			m_aCurRowPositionList.clear();
			nSize = src.m_aCurRowPositionList.GetCount();
			for ( int x2 = 0; x2 < nSize; x2++ )
			{
				m_aCurRowPositionList.append(src.m_aCurRowPositionList[x2]);
			}
			
			// m_aCurColPositionList.
			m_aCurColPositionList.clear();
			nSize = src.m_aCurColPositionList.GetCount();
			for ( int x3 = 0; x3 < nSize; x3++ )
			{
				m_aCurColPositionList.append(src.m_aCurColPositionList[x3]);
			}
			
//			ClearAllCells();
			
			int nRows = src.m_nTotalRows;
			int nCols = src.m_nTotalCols;
			
			for(int row = 0; row < nRows; row ++)
			{
				for(int col = 0; col < nCols; col ++)
				{
					CFOPTableCell* cellx = src.cell(row,col);// ->Copy();
					CFOPTableCell *pNew = new CFOPTableCell( this, row, col);
					if(cellx != NULL)
					{
						*pNew = *cellx;
					}
					// cellx->BuildTable(pNew);
				}
			}

			FOPRect rcPos = GetSnapRect();
			rcPos.DeflateRect(6,6,6,6);
			UpdateColRowPosition( rcPos.TopLeft());

			CRect crect = GetSnapRect();
			CRect rcInside = GetInsideRect();
			rcInside.InflateRect(6,6,6,6);
			BOOL bNeedTry = FALSE;
			CRect rcNew = crect;
			
			if(rcNew != rcInside)
			{
				rcNew = rcInside;
				bNeedTry = TRUE;
			}
			
			if(bNeedTry)
			{
				PositionShape(rcNew);
			}

		};
		
		// Obtain the TableKeymetry data of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Table Key Data, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPTableKeyData,or NULL if the call failed
		virtual FOPTableKeyData* GetTableKeyData()
		{
			FOPTableKeyData* pTableKey = NewTableKeyData();
			CopyTableKeyData(*pTableKey);
			return pTableKey;
		};
		
		// Set TableKeymetry data to the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Table Key Data, Sets a specify value to current class CFOPTableShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aData---aData, Specifies a const FOPTableKeyData& aData object(Value).
		virtual void SetTableKeyData(const FOPTableKeyData& aData)
		{
			RestTableKeyData(aData);
		};

		// do flash timer.
		virtual void OnFlashTimer(UINT_PTR nTimerID);

		// Update the whole shape, this method will call the InvalidateShape within the
		// CFOPCanvasCore to update this shape within the canvas.
		
		//-----------------------------------------------------------------------
		// Summary:
		// Update , Call this member function to update the object.
		// This member function is also a virtual function, you can Override it if you need,
		virtual void UpdateFlashCell(CFOPTableCell *pCell);

		// start flash timer.
		void StartFlashCell(CFOPTableCell *pCell);

protected:

	// Total rows or columns.
    unsigned int m_nTotalRows, m_nTotalCols, m_nTotalCells;

	// Active or not
 
	// Active, This member sets TRUE if it is right.  
    BOOL m_bActive;

	// Row array
 
	// Current Row Array, This member specify FOTablePtrVector< CFOTableRow > object.  
    FOTablePtrVector< CFOTableRow > m_aCurRowArray;
    
    // The list of page boundaries.
    //   Each page the table spans has an entry in this list which points to the last _line_
    //   on a page.
    //   For a 1 page table there is no page break; and therefor for such tables this list is
    //   empty.
 
	// Page Bounds List, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    FOPValueList<unsigned int> m_aPageBoundsList;

	// Redraw from column
 
	// Redraw From Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    unsigned int m_nRedrawFromCol;

	// Row positions
    FOPValueList<double> m_aCurRowPositionList, m_aCurColPositionList;

	// Current hit item.
 

public:
	// Current Hit, This member maintains a pointer to the object CFOPTableCell.  
	CFOPTableCell *	m_pCurHit;

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Line width = 1,label border pen.
 
	// Border Pen, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData	m_pBorderPen;

};

// all three templates specify operator++
template<>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<CFOPTableShape::VISIT_CELL>::operator++ ();

// Operator ++
template<>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<CFOPTableShape::VISIT_GRID>::operator++ ();

// Operator ++
template<>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<CFOPTableShape::CHECKED>::operator++ ();

template<int VisitStyle>
CFOPTableShape::CFOPTableIterator<VisitStyle>::CFOPTableIterator(CFOPTableShape *table) :
m_table(table)
{
    ASSERT(m_table);
    SetLimits(0, m_table->GetColumns() - 1, 0, m_table->GetRows() - 1);
    ToFirstCell();
}

// CHECKED specialises the constructor
template<>
CFOPTableShape::CFOPTableIterator<CFOPTableShape::CHECKED>::CFOPTableIterator(CFOPTableShape *table);


template<int VisitStyle>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<VisitStyle>::ToFirstCell ()
{
    m_pCell = m_table->cell(m_limit[HIGH], m_limit[LEFT]);
//    ASSERT(m_pCell);
    if ( !m_pCell )
        return 0;
    m_pCurRow = m_pCell->FirstRow();
    m_nCurCol = m_pCell->FirstColumn();
    return m_pCell;
}

template<int VisitStyle>
void
CFOPTableShape::CFOPTableIterator<VisitStyle>::GoToCell(CFOPTableCell *cell)
{
    m_pCell = cell;
    ASSERT( m_pCell );
    if ( m_pCell )
    {
        m_pCurRow = m_pCell->FirstRow();
        m_nCurCol = m_pCell->FirstColumn();
    }
}

// CHECKED specify to first cell
template<>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<CFOPTableShape::CHECKED>::ToFirstCell ();

template<int VisitStyle>
CFOPTableCell*
CFOPTableShape::CFOPTableIterator<VisitStyle>::Current() const 
{
    return m_pCell;
}

/////////////////////////////////////////////////////////////
// CFOPRemovedRow and CFOPRemovedColumn implement the Memento design pattern

 
//===========================================================================
// Summary:
//      To use a CFOPRemovedRow object, just call the constructor.
//      F O P Removed Row
//===========================================================================

class FO_EXT_CLASS CFOPRemovedRow 
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Removed Row, Constructs a CFOPRemovedRow object.
	//		Returns A  value (Object).
    CFOPRemovedRow();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Removed Row, Destructor of class CFOPRemovedRow
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPRemovedRow();
    
protected:
    // Current row.
    CFOPTableShape::CFOTableRow *m_pCurRow;

    // The row index that this row used to occupy
 
	// Index, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT m_nIndex;

	// Row height.
 
	// Current Row Height, This member specify double object.  
    double m_dCurRowHeight;
    
	// Obtain the index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns a UINT type value.
    UINT GetIndex() const { return m_nIndex; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Height, .
	//		Returns A double value (Object).
	// Obtain the height.
    double Height() const { return m_dCurRowHeight; }

	// Take row.
    CFOPTableShape::CFOTableRow *TakeRow();

	// Obtain row.
    CFOPTableShape::CFOTableRow *GetRow() { return m_pCurRow; }
    
 
	// F O P Table Shape, This member specify friend class object.  
    friend class CFOPTableShape;
    
};

/////////////////////////////////////////////////////////////
// CFOPRemovedColumn implement the Memento design pattern

 
//===========================================================================
// Summary:
//      To use a CFOPRemovedColumn object, just call the constructor.
//      F O P Removed Column
//===========================================================================

class FO_EXT_CLASS CFOPRemovedColumn 
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Removed Column, Constructs a CFOPRemovedColumn object.
	//		Returns A  value (Object).
    CFOPRemovedColumn();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Removed Column, Destructor of class CFOPRemovedColumn
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPRemovedColumn() {}
    
protected:

	// Cells for removing
 
	// Cells, This member specify FOTablePtrList<CFOPTableCell> object.  
    FOTablePtrList<CFOPTableCell> m_aCells;

	// Removed or not.
 
	// Removed, This member sets TRUE if it is right.  
    FOPValueList<BOOL> m_aRemoved;

	// Index of column
 
	// Index, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT m_nIndex;

	// Width
 
	// Width, This member specify double object.  
    double m_dWidth;

	// Initialized or not
 
	// Initialized, This member sets TRUE if it is right.  
    BOOL m_bInitialized;
    
 
	// F O P Table Shape, This member specify friend class object.  
    friend class CFOPTableShape;
    
};

#endif // !defined(FO_FOPTABLESHAPE_H__3C8DE07D_A6D1_4333_9EC6_3BD0BA6C37E0__INCLUDED_)
