//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPTableCellBorder.h: interface for the CFOPTableCellBorder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPTABLECELLBORDER_H__6FAD1865_FCA1_434A_90DF_37093BD76B2E__INCLUDED_)
#define AFX_FOPTABLECELLBORDER_H__6FAD1865_FCA1_434A_90DF_37093BD76B2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////////////////
// CFOPTableCellBorder
// Border of the table cell

 
//===========================================================================
// Summary:
//      To use a CFOPTableCellBorder object, just call the constructor.
//      F O P Table Cell Border
//===========================================================================

class FO_EXT_CLASS CFOPTableCellBorder
{
public:
    enum FOPBorderStyle {SOLID = 0, DASH = 1, DOT = 2, DASH_DOT = 3, DASH_DOT_DOT = 4, DOUBLE_LINE = 5};
    enum FOPBorderType { LeftBorder = 0, RightBorder, TopBorder, BottomBorder };

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell Border, Constructs a CFOPTableCellBorder object.
	//		Returns A  value (Object).
    CFOPTableCellBorder();

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell Border, Constructs a CFOPTableCellBorder object.
	//		Returns A  value (Object).  
	// Parameters:
	//		c---Specifies A 32-bit COLORREF value used as a color value.  
	//		s---Specifies a FOPBorderStyle s object(Value).  
	//		width---Specifies A integer value.
    CFOPTableCellBorder( const COLORREF & c, FOPBorderStyle s, int width );

public:
	
	// Color of the border
 
	// This member sets A 32-bit value used as a color value.  
    COLORREF color;

	// Change pen widht
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class CFOPTableCellBorder
	// Parameters:
	//		width---Specifies A integer value.
    void SetPenWidth(int width);

	// Change pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Style, Sets a specify value to current class CFOPTableCellBorder
	// Parameters:
	//		style---Specifies a FOPBorderStyle style object(Value).
    void SetStyle(FOPBorderStyle style);

    // Obtain pen border style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style, Returns the specified value.
	//		Returns A FOPBorderStyle value (Object).
    FOPBorderStyle GetStyle() const {return m_nStyle;}

	// Get gdi line style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get G D I Line Style, Returns the specified value.
	//		Returns a int type value.
	int GetGDILineStyle();

	// Set gdi line style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set G D I Line Style, Sets a specify value to current class CFOPTableCellBorder
	// Parameters:
	//		&nStyle---&nStyle, Specifies A integer value.
	void SetGDILineStyle(const int &nStyle);

	// Obtain pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
    int GetPenWidth() const{ return m_nPenWidth;}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.
	// Width of border
    int width() const { return m_nWidth; }

	// Operator == 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		brd---Specifies a const CFOPTableCellBorder brd object(Value).
    BOOL operator==( const CFOPTableCellBorder &brd ) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		brd---Specifies a const CFOPTableCellBorder brd object(Value).
    BOOL operator!=( const CFOPTableCellBorder &brd ) const;

    // Get a ready-to-use CPen for this border.
    // defaultColor is the color to use for COLORREF().
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Pen, Returns the specified value.
	// This member function is a static function.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		brd---Specifies a const CFOPTableCellBorder & brd object(Value).  
	//		width---Specifies A integer value.  
	//		defaultColor---defaultColor, Specifies A 32-bit COLORREF value used as a color value.
    static CPen* GetBorderPen( const CFOPTableCellBorder & brd, int width, COLORREF defaultColor );

    // Draws in dc the 4 borders on the _outside_ of rect.
    // If a border is of size 0, minborder will be applied (no border if 0, defaultPen otherwise)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Borders, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is a static function.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.  
	//		left---Specifies a const CFOPTableCellBorder& left object(Value).  
	//		right---Specifies a const CFOPTableCellBorder& right object(Value).  
	//		top---Specifies a const CFOPTableCellBorder& top object(Value).  
	//		bottom---Specifies a const CFOPTableCellBorder& bottom object(Value).  
	//		minborder---Specifies A integer value.  
	//		defaultPen---defaultPen, Specifies a const CPen& defaultPen object(Value).  
	//		drawTopBorder---Top Border, Specifies A Boolean value.  
	//		drawBottomBorder---Bottom Border, Specifies A Boolean value.
    static void OnDrawBorders( CDC& dc, const CRect& rect,
                             const CFOPTableCellBorder& left, const CFOPTableCellBorder& right,
                             const CFOPTableCellBorder& top, const CFOPTableCellBorder& bottom,
                             int minborder, const CPen& defaultPen, BOOL drawTopBorder = TRUE , BOOL drawBottomBorder = TRUE );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	void Serialize(CArchive &ar);

public:

	// width
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int m_nWidth;

	// Pen width
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int m_nPenWidth;

	// Pen style
 
	// Style, This member specify FOPBorderStyle object.  
    FOPBorderStyle m_nStyle;
};

///////////////////////////////////////////////////////////
// CFOPCellRect

 
//===========================================================================
// Summary:
//     The CFOPCellRect class derived from CRect
//      F O P Cell Rectangle
//===========================================================================

class FO_EXT_CLASS CFOPCellRect : public CRect
{
public:
    
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Cell Rectangle, Constructs a CFOPCellRect object.
	//		Returns A  value (Object).
	CFOPCellRect();

    //-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Cell Rectangle, Constructs a CFOPCellRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		left---Specifies a double left object(Value).  
	//		top---Specifies a double top object(Value).  
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).
    CFOPCellRect(double left, double top, double width, double height);

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Cell Rectangle, Constructs a CFOPCellRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		frame---A pointer to the CFOPCellRect  or NULL if the call failed.
    CFOPCellRect(CFOPCellRect * frame);

    //-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Cell Rectangle, Destructor of class CFOPCellRect
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPCellRect();

public:
	// Prevent operator=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPCellRect value (Object).  
	// Parameters:
	//		&_frame---Specifies a const CFOPCellRect &_frame object(Value).
    CFOPCellRect &operator=( const CFOPCellRect &_frame );

    // Prevent copy constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Cell Rectangle, Constructs a CFOPCellRect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&_frame---Specifies a const CFOPCellRect &_frame object(Value).
    CFOPCellRect ( const CFOPCellRect &_frame );

public:

    // All borders can be custom drawn with their own colors etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Border, .
	//		Returns A const CFOPTableCellBorder value (Object).
    const CFOPTableCellBorder &GetLeftBorder() const { return m_borderLeft; }

	// All borders can be custom drawn with their own colors etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Right Border, .
	//		Returns A const CFOPTableCellBorder value (Object).
    const CFOPTableCellBorder &GetRightBorder() const { return m_borderRight; }
	
	// All borders can be custom drawn with their own colors etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Border, .
	//		Returns A const CFOPTableCellBorder value (Object).
    const CFOPTableCellBorder &GetTopBorder() const { return m_borderTop; }

	// All borders can be custom drawn with their own colors etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Border, .
	//		Returns A const CFOPTableCellBorder value (Object).
    const CFOPTableCellBorder &GetBottomBorder() const { return m_borderBottom; }

	// Change the border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Border, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		_brd---Specifies a E-XD++ CFOPTableCellBorder _brd object (Value).
    void SetLeftBorder( CFOPTableCellBorder _brd ) { m_borderLeft = _brd; }

	// Change the border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Right Border, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		_brd---Specifies a E-XD++ CFOPTableCellBorder _brd object (Value).
    void SetRightBorder( CFOPTableCellBorder _brd ) { m_borderRight = _brd; }

	// Change the border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top Border, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		_brd---Specifies a E-XD++ CFOPTableCellBorder _brd object (Value).
    void SetTopBorder( CFOPTableCellBorder _brd ) { m_borderTop = _brd; }

	// Change the border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bottom Border, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		_brd---Specifies a E-XD++ CFOPTableCellBorder _brd object (Value).
    void SetBottomBorder( CFOPTableCellBorder _brd ) { m_borderBottom = _brd; }

    /// set left Padding (distance between frame contents and frame border)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Padding Left, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		b---Specifies a double b object(Value).
    void SetPaddingLeft( double b ) { m_PaddingLeft = b; }

    /// set right Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Padding Right, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		b---Specifies a double b object(Value).
    void SetPaddingRight( double b ) { m_PaddingRight = b; }

    /// set top Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Padding Top, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		b---Specifies a double b object(Value).
    void SetPaddingTop( double b ) { m_PaddingTop = b; }

    /// set bottom Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Padding Bottom, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		b---Specifies a double b object(Value).
    void SetPaddingBottom( double b ) { m_PaddingBottom = b; }

    /// get left Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Padding Left, Returns the specified value.
	//		Returns A double value (Object).
    double GetPaddingLeft() const { return m_PaddingLeft; }

    /// get right Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Padding Right, Returns the specified value.
	//		Returns A double value (Object).
    double GetPaddingRight() const { return m_PaddingRight; }

    /// get top Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Padding Top, Returns the specified value.
	//		Returns A double value (Object).
    double GetPaddingTop() const { return m_PaddingTop; }

    /// get bottom Padding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Padding Bottom, Returns the specified value.
	//		Returns A double value (Object).
    double GetPaddingBottom() const { return m_PaddingBottom; }

    // returns a copy of self
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Copy, Returns the specified value.
	//		Returns a pointer to the object CFOPCellRect ,or NULL if the call failed
    CFOPCellRect *GetCopy();

	// Copy settings
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Settings, Create a duplicate copy of this object.
	// Parameters:
	//		*frm---A pointer to the CFOPCellRect  or NULL if the call failed.
    void CopySettings(CFOPCellRect *frm);

    // The property minimum frame height is used to make the automatic frame shrinking code stop.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimum Frame Height, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		height---Specifies a double height object(Value).
    void SetMinimumFrameHeight(double height) { m_minFrameHeight = height; }

    // return the minimum frame height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Frame Height, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		void---void
    double GetMinimumFrameHeight(void)const {return m_minFrameHeight;}

    // Return if the point is on the frame.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Frame At Position, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPoint---nPoint, Specifies A CPoint type value.  
	//		borderOfFrameOnly---Of Frame Only, Specifies A Boolean value.
    BOOL FrameAtPos( const CPoint& nPoint, BOOL borderOfFrameOnly=FALSE ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	void Serialize(CArchive &ar);

	// Draws in dc the 4 borders on the _outside_ of rect.
    // If a border is of size 0, minborder will be applied (no border if 0, defaultPen otherwise)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Borders, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rect---Specifies A CRect type value.
    void OnDrawBorders( CDC& dc, const CRect& rect, const BOOL &bHorzGrid = TRUE, const BOOL &bVertGrid = TRUE);

	// Change line color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class CFOPCellRect
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetLineColor(const COLORREF &crColor);

public:

	// Paddings
    double m_PaddingLeft, m_PaddingRight, m_PaddingTop, m_PaddingBottom;

	// Min frame height
 
	// Frame Height, This member specify double object.  
    double m_minFrameHeight;

	// Borders
    CFOPTableCellBorder m_borderLeft, m_borderRight, m_borderTop, m_borderBottom;

};

#endif // !defined(AFX_FOPTABLECELLBORDER_H__6FAD1865_FCA1_434A_90DF_37093BD76B2E__INCLUDED_)
