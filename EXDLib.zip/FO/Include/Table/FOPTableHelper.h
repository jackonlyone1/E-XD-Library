// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOPTableHelper.h: interface for the CFOPTableHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOPTABLEHELPER_H__66EA4AD6_A44F_40AC_8E19_E6109DEF4F61__INCLUDED_)
#define AFX_FOPTABLEHELPER_H__66EA4AD6_A44F_40AC_8E19_E6109DEF4F61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning( push,3 )
#include <list>
#pragma warning( pop)

////////////////////////////////////////////////////////////
// FOPShared

struct FOPShared
{
    FOPShared() : m_nRef( 1 ) {/* Do nothing*/}

	// Increase the count of reference
    void AddRef()		{ m_nRef++; }

	// Decrease the count of reference
    BOOL DeRef()		{ return !--m_nRef; }

	// refer
    UINT m_nRef;
};


////////////////////////////////////////////////////////////
// FOPValueListNode

template <class T>
 
//===========================================================================
// Summary:
//      To use a FOPValueListNode object, just call the constructor.
//      O P Value List Node
//===========================================================================

class FOPValueListNode
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Node, Constructs a FOPValueListNode object.
	//		Returns A  value (Object).  
	// Parameters:
	//		t---Specifies a const T& t object(Value).
    FOPValueListNode( const T& t ) : data( t ) {/* Do nothing*/ }

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Node, Constructs a FOPValueListNode object.
	//		Returns A  value (Object).
    FOPValueListNode() {}

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Value List Node, Destructor of class FOPValueListNode
	//		Returns A  value (Object).
	~FOPValueListNode() {}
	
public:
	// next pointer
 
	// This member maintains a pointer to the object FOPValueListNode<T>.  
    FOPValueListNode<T>* next;

	// previous pointer
 
	// This member maintains a pointer to the object FOPValueListNode<T>.  
    FOPValueListNode<T>* prev;

	// data
 
	// This member specify T object.  
    T data;
};

////////////////////////////////////////////////////////////
// FOPValueListIterator

template<class T>
 
//===========================================================================
// Summary:
//      To use a FOPValueListIterator object, just call the constructor.
//      O P Value List Iterator
//===========================================================================

class FOPValueListIterator
{
public:
 
	// Node Pointer, This member maintains a pointer to the object typedef FOPValueListNode<T>.  
    typedef FOPValueListNode<T>* NodePtr;
    typedef std::bidirectional_iterator_tag  iterator_category;
 
	// This member specify typedef T object.  
    typedef T			value_type;
 
	// This member specify typedef size_t object.  
    typedef size_t		size_type;
 
	// This member specify typedef ptrdiff_t object.  
    typedef ptrdiff_t	difference_type;
 
	// This member maintains a pointer to the object typedef T.  
    typedef T*			pointer;
 
	// This member specify typedef T& object.  
    typedef T&			reference;

public:

	// Node
 
	// This member specify NodePtr object.  
    NodePtr				node;
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Iterator, Constructs a FOPValueListIterator object.
	//		Returns A  value (Object).
    FOPValueListIterator() : node( 0 ) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Iterator, Constructs a FOPValueListIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptr---Specifies a NodePtr ptr object(Value).
    FOPValueListIterator( NodePtr ptr ) : node( ptr ) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Iterator, Constructs a FOPValueListIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueListIterator<T>& da object(Value).
    FOPValueListIterator( const FOPValueListIterator<T>& da ) : node( da.node ) {}
	
public:
	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueListIterator<T>& da object(Value).
    BOOL operator==( const FOPValueListIterator<T>& da ) const { return node == da.node; }

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueListIterator<T>& da object(Value).
    BOOL operator!=( const FOPValueListIterator<T>& da ) const { return node != da.node; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T& value (Object).
	// operator *
    const T& operator*() const { return node->data; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A T& value (Object).
	// operator *
    T& operator*() { return node->data; }
	
	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T>& value (Object).
    FOPValueListIterator<T>& operator++() {
		node = node->next;
		return *this;
    }
	
	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T> value (Object).  
	// Parameters:
	//		int---Specifies A integer value.
    FOPValueListIterator<T> operator++(int) {
		FOPValueListIterator<T> tmp = *this;
		node = node->next;
		return tmp;
    }
	
	// operator --
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T>& value (Object).
    FOPValueListIterator<T>& operator--() {
		node = node->prev;
		return *this;
    }
	
	// operator --
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T> value (Object).  
	// Parameters:
	//		int---Specifies A integer value.
    FOPValueListIterator<T> operator--(int) {
		FOPValueListIterator<T> tmp = *this;
		node = node->prev;
		return tmp;
    }
	
	// operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T>& value (Object).  
	// Parameters:
	//		index---Specifies A integer value.
    FOPValueListIterator<T>& operator+=( int index ) {
		while ( index-- )
			node = node->next;
		return *this;
    }
	
	// operator -=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListIterator<T>& value (Object).  
	// Parameters:
	//		index---Specifies A integer value.
    FOPValueListIterator<T>& operator-=( int index ) {
		while ( index-- )
			node = node->prev;
		return *this;
    }
	
};

////////////////////////////////////////////////////////////
// FOPValueListConstIterator

template<class T>
 
//===========================================================================
// Summary:
//      To use a FOPValueListConstIterator object, just call the constructor.
//      O P Value List Const Iterator
//===========================================================================

class FOPValueListConstIterator
{
public:
 
	// Node Pointer, This member maintains a pointer to the object typedef FOPValueListNode<T>.  
    typedef FOPValueListNode<T>* NodePtr;
    typedef std::bidirectional_iterator_tag  iterator_category;
 
	// This member specify typedef T object.  
    typedef T			value_type;
 
	// This member specify typedef size_t object.  
    typedef size_t		size_type;
 
	// This member specify typedef ptrdiff_t object.  
    typedef ptrdiff_t	difference_type;
 
	// This member maintains a pointer to the object typedef const T.  
    typedef const T*	pointer;
 
	// This member specify typedef const T& object.  
    typedef const T&	reference;
	
public:

	// Node
 
	// This member specify NodePtr object.  
    NodePtr node;
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Const Iterator, Constructs a FOPValueListConstIterator object.
	//		Returns A  value (Object).
    FOPValueListConstIterator() : node( 0 ) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Const Iterator, Constructs a FOPValueListConstIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptr---Specifies a NodePtr ptr object(Value).
    FOPValueListConstIterator( NodePtr ptr ) : node( ptr ) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Const Iterator, Constructs a FOPValueListConstIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueListConstIterator<T>& da object(Value).
    FOPValueListConstIterator( const FOPValueListConstIterator<T>& da ) : node( da.node ) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Const Iterator, Constructs a FOPValueListConstIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueListIterator<T>& da object(Value).
    FOPValueListConstIterator( const FOPValueListIterator<T>& da ) : node( da.node ) {}
	
public:
	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueListConstIterator<T>& da object(Value).
    BOOL operator==( const FOPValueListConstIterator<T>& da ) const { return node == da.node; }

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueListConstIterator<T>& da object(Value).
    BOOL operator!=( const FOPValueListConstIterator<T>& da ) const { return node != da.node; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T& value (Object).
	// operator *
    const T& operator*() const { return node->data; }
	
	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListConstIterator<T>& value (Object).
    FOPValueListConstIterator<T>& operator++() {
		node = node->next;
		return *this;
    }
	
	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListConstIterator<T> value (Object).  
	// Parameters:
	//		int---Specifies A integer value.
    FOPValueListConstIterator<T> operator++(int) {
		FOPValueListConstIterator<T> tmp = *this;
		node = node->next;
		return tmp;
    }
	
	// operator --
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListConstIterator<T>& value (Object).
    FOPValueListConstIterator<T>& operator--() {
		node = node->prev;
		return *this;
    }
	
	// operator --
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueListConstIterator<T> value (Object).  
	// Parameters:
	//		int---Specifies A integer value.
    FOPValueListConstIterator<T> operator--(int) {
		FOPValueListConstIterator<T> tmp = *this;
		node = node->prev;
		return tmp;
    }
};

////////////////////////////////////////////////////////////
// FOPValueListPrivate

template <class T>
 
//===========================================================================
// Summary:
//     The FOPValueListPrivate class derived from FOPShared
//      O P Value List Private
//===========================================================================

class FOPValueListPrivate : public FOPShared
{
public:
 
	// This member specify typedef FOPValueListIterator<T> object.  
    typedef FOPValueListIterator<T> Iterator;
 
	// Const Iterator, This member specify typedef FOPValueListConstIterator<T> object.  
    typedef FOPValueListConstIterator<T> ConstIterator;
 
	// This member specify typedef FOPValueListNode<T> object.  
    typedef FOPValueListNode<T> Node;
 
	// Node Pointer, This member maintains a pointer to the object typedef FOPValueListNode<T>.  
    typedef FOPValueListNode<T>* NodePtr;
 
	// This member specify typedef size_t object.  
    typedef size_t size_type;
	
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Private, Constructs a FOPValueListPrivate object.
	//		Returns A  value (Object).
    FOPValueListPrivate();

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List Private, Constructs a FOPValueListPrivate object.
	//		Returns A  value (Object).  
	// Parameters:
	//		_p---Specifies a const FOPValueListPrivate<T>& _p object(Value).
    FOPValueListPrivate( const FOPValueListPrivate<T>& _p );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// De Reference And Delete, .

    void DeRefAndDelete()
    {
		if ( DeRef() )
			delete this;
    }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Value List Private, Destructor of class FOPValueListPrivate
	//		Returns A  value (Object).
    ~FOPValueListPrivate();
	
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Iterator value (Object).  
	// Parameters:
	//		da---Specifies a Iterator da object(Value).  
	//		x---Specifies a const T& x object(Value).
	// insert
    Iterator insert( Iterator da, const T& x );

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Iterator value (Object).  
	// Parameters:
	//		da---Specifies a Iterator da object(Value).
	// remove
    Iterator remove( Iterator da );

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A NodePtr value (Object).  
	// Parameters:
	//		start---Specifies a NodePtr start object(Value).  
	//		x---Specifies a const T& x object(Value).
	// find
    NodePtr find( NodePtr start, const T& x ) const;

	// find index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		start---Specifies a NodePtr start object(Value).  
	//		x---Specifies a const T& x object(Value).
    int FindIndex( NodePtr start, const T& x ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains, .
	//		Returns a UINT type value.  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// contains
    UINT Contains( const T& x ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a UINT type value.  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// remove
    UINT remove( const T& x );

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A NodePtr value (Object).  
	// Parameters:
	//		i---Specifies a size_type i object(Value).
	// at
    NodePtr at( size_type i ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// clear
    void clear();
	
public:
	// node
 
	// This member specify NodePtr object.  
    NodePtr node;

	// total of nodes
 
	// Size, This member specify size_type object.  
    size_type m_nSize;
};

template <class T>
_FOLIB_INLINE FOPValueListPrivate<T>::FOPValueListPrivate()
{
    node = new Node; node->next = node->prev = node; m_nSize = 0;
}

template <class T>
_FOLIB_INLINE FOPValueListPrivate<T>::FOPValueListPrivate( const FOPValueListPrivate<T>& _p )
: FOPShared()
{
    node = new Node; node->next = node->prev = node; m_nSize = 0;
    Iterator b( _p.node->next );
    Iterator e( _p.node );
    Iterator i( node );
    while( b != e )
		insert( i, *b++ );
}

template <class T>
_FOLIB_INLINE FOPValueListPrivate<T>::~FOPValueListPrivate() {
    NodePtr p = node->next;
    while( p != node ) {
		NodePtr x = p->next;
		delete p;
		p = x;
    }
    delete node;
}

template <class T>
_FOLIB_INLINE typename FOPValueListPrivate<T>::Iterator FOPValueListPrivate<T>::insert( typename FOPValueListPrivate<T>::Iterator it, const T& x )
{
    NodePtr p = new Node( x );
    p->next = it.node;
    p->prev = it.node->prev;
    it.node->prev->next = p;
    it.node->prev = p;
    m_nSize++;
    return p;
}

template <class T>
_FOLIB_INLINE typename FOPValueListPrivate<T>::Iterator FOPValueListPrivate<T>::remove( typename FOPValueListPrivate<T>::Iterator it )
{
    ASSERT ( it.node != node );
    NodePtr next = it.node->next;
    NodePtr prev = it.node->prev;
    prev->next = next;
    next->prev = prev;
    delete it.node;
    m_nSize--;
    return Iterator( next );
}

template <class T>
_FOLIB_INLINE typename FOPValueListPrivate<T>::NodePtr FOPValueListPrivate<T>::find( typename FOPValueListPrivate<T>::NodePtr start, const T& x ) const
{
    ConstIterator first( start );
    ConstIterator last( node );
    while( first != last) {
		if ( *first == x )
			return first.node;
		++first;
    }
    return last.node;
}

template <class T>
_FOLIB_INLINE int FOPValueListPrivate<T>::FindIndex( typename FOPValueListPrivate<T>::NodePtr start, const T& x ) const
{
    ConstIterator first( start );
    ConstIterator last( node );
    int pos = 0;
    while( first != last) {
		if ( *first == x )
			return pos;
		++first;
		++pos;
    }
    return -1;
}

template <class T>
_FOLIB_INLINE UINT FOPValueListPrivate<T>::Contains( const T& x ) const
{
    UINT result = 0;
    Iterator first = Iterator( node->next );
    Iterator last = Iterator( node );
    while( first != last) {
		if ( *first == x )
			++result;
		++first;
    }
    return result;
}

template <class T>
_FOLIB_INLINE UINT FOPValueListPrivate<T>::remove( const T& _x )
{
    const T x = _x;
    UINT result = 0;
    Iterator first = Iterator( node->next );
    Iterator last = Iterator( node );
    while( first != last) {
		if ( *first == x ) {
			first = remove( first );
			++result;
		} else
			++first;
    }
    return result;
}

template <class T>
_FOLIB_INLINE typename FOPValueListPrivate<T>::NodePtr FOPValueListPrivate<T>::at( size_type i ) const
{
	ASSERT( i <= m_nSize );
    NodePtr p = node->next;
    for( size_type x = 0; x < i; ++x )
		p = p->next;
    return p;
}

template <class T>
_FOLIB_INLINE void FOPValueListPrivate<T>::clear()
{
    m_nSize = 0;
    NodePtr p = node->next;
    while( p != node ) {
		NodePtr next = p->next;
		delete p;
		p = next;
    }
    node->next = node->prev = node;
}

////////////////////////////////////////////////////////////
// FOPValueList

template <class T>
 
//===========================================================================
// Summary:
//      To use a FOPValueList object, just call the constructor.
//      O P Value List
//===========================================================================

class FOPValueList
{
public:
	// Typedefs
 
	// This member specify typedef FOPValueListIterator<T> object.  
    typedef FOPValueListIterator<T> iterator;
 
	// This member specify typedef FOPValueListConstIterator<T> object.  
    typedef FOPValueListConstIterator<T> const_iterator;
 
	// This member specify typedef T object.  
    typedef T value_type;
 
	// This member maintains a pointer to the object typedef value_type.  
    typedef value_type* pointer;
 
	// This member maintains a pointer to the object typedef const value_type.  
    typedef const value_type* const_pointer;
 
	// This member specify typedef value_type& object.  
    typedef value_type& reference;
 
	// This member specify typedef const value_type& object.  
    typedef const value_type& const_reference;
 
	// This member specify typedef size_t object.  
    typedef size_t size_type;
 
	// This member specify typedef ptrdiff_t object.  
    typedef ptrdiff_t  difference_type;

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List, Constructs a FOPValueList object.
	//		Returns A  value (Object).
    FOPValueList() { sh = new FOPValueListPrivate<T>; }

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Value List, Constructs a FOPValueList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueList<T>& da object(Value).
    FOPValueList( const FOPValueList<T>& da ) { sh = da.sh; sh->AddRef(); }

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
    FOPValueList( const std::list<T>& da )
    {
		sh = new FOPValueListPrivate<T>;
		qCopy( da.begin(), da.end(), std::back_inserter( *this ) );
    }

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Value List, Destructor of class FOPValueList
	//		Returns A  value (Object).
    ~FOPValueList() { sh->DeRefAndDelete(); }
	
public:

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueList<T>& value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueList<T>& da object(Value).
    FOPValueList<T>& operator= ( const FOPValueList<T>& da )
    {
		da.sh->AddRef();
		sh->DeRefAndDelete();
		sh = da.sh;
		return *this;
    }

	// operator =
    FOPValueList<T>& operator= ( const std::list<T>& da )
    {
		Detach();
		qCopy( da.begin(), da.end(), std::back_inserter( *this ) );
		return *this;
    }

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueList<T>& da object(Value).
    BOOL operator== ( const std::list<T>& da ) const
    {
		if ( GetSize() != da.GetSize() )
			return FALSE;
		const_iterator it2 = begin();
		typename	std::list<T>::const_iterator it = da.begin();
		for ( ; it2 != end(); ++it2, ++it )
			if ( !((*it2) == (*it)) )
				return FALSE;
			return TRUE;
    }

	// operator ==
    BOOL operator== ( const FOPValueList<T>& da ) const;

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		da---Specifies a const FOPValueList<T>& da object(Value).
    BOOL operator!= ( const FOPValueList<T>& da ) const { return !( *this == da ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).
	// obtain the begin object
    iterator begin() { Detach(); return iterator( sh->node->next ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_iterator value (Object).
	// obtain the begin object
    const_iterator begin() const { return const_iterator( sh->node->next ); }

	// Const begin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Const Begin, .
	//		Returns A const_iterator value (Object).
    const_iterator ConstBegin() const { return const_iterator( sh->node->next ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).
	// Obtain the end object
    iterator end() { Detach(); return iterator( sh->node ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_iterator value (Object).
	// Obtain the end object
    const_iterator end() const { return const_iterator( sh->node ); }

	// const end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Const End, .
	//		Returns A const_iterator value (Object).
    const_iterator ConstEnd() const { return const_iterator( sh->node ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		da---Specifies a iterator da object(Value).  
	//		x---Specifies a const T& x object(Value).
	// insert at
    iterator insert( iterator da, const T& x ) { Detach(); return sh->insert( da, x ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a UINT type value.  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// Remove at
    UINT remove( const T& x ) { Detach(); return sh->remove( x ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// clear
    void clear();
	
	// operator <<
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueList<T>& value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    FOPValueList<T>& operator<< ( const T& x )
    {
		append( x );
		return *this;
    }
	
	// Obtain the size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns A size_type value (Object).
    size_type GetSize() const { return sh->nodes; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// empty or not
    BOOL empty() const { return sh->nodes == 0; }

	// push front
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    void push_front( const T& x ) { Detach(); sh->insert( begin(), x ); }

	// push back
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    void push_back( const T& x ) { Detach(); sh->insert( end(), x ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		pos---Specifies a iterator pos object(Value).
	// erase
    iterator erase( iterator pos ) { Detach(); return sh->remove( pos ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		first---Specifies a iterator first object(Value).  
	//		last---Specifies a iterator last object(Value).
	// erase
    iterator erase( iterator first, iterator last );

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A reference value (Object).
	// front
    reference front() { return *begin(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_reference value (Object).
	// front reference
    const_reference front() const { return *begin(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A reference value (Object).
	// back ref
    reference back() { return *(--end()); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_reference value (Object).
	// back ref
    const_reference back() const { return *(--end()); }

	// pop front
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

    void pop_front() {  erase( begin() ); }

	// pop back
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

    void pop_back() {
		iterator tmp = end();
		erase( --tmp );
    }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		pos---Specifies a iterator pos object(Value).  
	//		n---Specifies a size_type n object(Value).  
	//		x---Specifies a const T& x object(Value).
	// insert at
    void insert( iterator pos, size_type n, const T& x );
	
	// operator +
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueList<T> value (Object).  
	// Parameters:
	//		da---Specifies a const FOPValueList<T>& da object(Value).
    FOPValueList<T> operator+ ( const FOPValueList<T>& da ) const;

	// operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueList<T>& value (Object).  
	// Parameters:
	//		a---Specifies a const FOPValueList<T>& a object(Value).
    FOPValueList<T>& operator+= ( const FOPValueList<T>& a );
	
	// from last
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Last, .
	//		Returns A iterator value (Object).
    iterator FromLast() { Detach(); return iterator( sh->node->prev ); }

	// from last
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Last, .
	//		Returns A const_iterator value (Object).
    const_iterator FromLast() const { return const_iterator( sh->node->prev ); }
	
	// Is empty or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsEmpty() const { return ( sh->m_nSize == 0 ); }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// append
    iterator append( const T& x ) { Detach(); return sh->insert( end(), x ); }

	// pre pend
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Pend, .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    iterator PrePend( const T& x ) { Detach(); return sh->insert( begin(), x ); }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		da---Specifies a iterator da object(Value).
	// remove at
    iterator remove( iterator da ) { Detach(); return sh->remove( da ); }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A T& value (Object).
	// first object
    T& first() {  Detach(); return sh->node->next->data; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T& value (Object).
	// first data
    const T& first() const {  return sh->node->next->data; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A T& value (Object).
	// last object
    T& last() {  Detach(); return sh->node->prev->data; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T& value (Object).
	// last object
    const T& last() const {  return sh->node->prev->data; }
	
	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A T& value (Object).  
	// Parameters:
	//		i---Specifies a size_type i object(Value).
    T& operator[] ( size_type i ) {  Detach(); return sh->at(i)->data; }

	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T& value (Object).  
	// Parameters:
	//		i---Specifies a size_type i object(Value).
    const T& operator[] ( size_type i ) const {  return sh->at(i)->data; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		i---Specifies a size_type i object(Value).
	// at
    iterator at( size_type i ) {  Detach(); return iterator( sh->at(i) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_iterator value (Object).  
	// Parameters:
	//		i---Specifies a size_type i object(Value).
	// at
    const_iterator at( size_type i ) const {  return const_iterator( sh->at(i) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// find
    iterator find( const T& x ) { Detach(); return iterator( sh->find( sh->node->next, x) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_iterator value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// find
    const_iterator find( const T& x ) const { return const_iterator( sh->find( sh->node->next, x) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A iterator value (Object).  
	// Parameters:
	//		da---Specifies a iterator da object(Value).  
	//		x---Specifies a const T& x object(Value).
	// find
    iterator find( iterator da, const T& x ) { Detach(); return iterator( sh->find( da.node, x ) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const_iterator value (Object).  
	// Parameters:
	//		da---Specifies a const_iterator da object(Value).  
	//		x---Specifies a const T& x object(Value).
	// find
    const_iterator find ( const_iterator da, const T& x ) const { return const_iterator( sh->find( da.node, x ) ); }

	// find index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    int FindIndex( const T& x ) const { return sh->FindIndex( sh->node->next, x) ; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains, .
	//		Returns A size_type value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
	// contains
    size_type Contains( const T& x ) const { return sh->Contains( x ); }
	
	// get count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns A size_type value (Object).
    size_type GetCount() const { return sh->m_nSize; }
	
	// operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPValueList<T>& value (Object).  
	// Parameters:
	//		x---Specifies a const T& x object(Value).
    FOPValueList<T>& operator+= ( const T& x )
    {
		append( x );
		return *this;
    }

	//
 
	// This member specify typedef FOPValueListIterator<T> object.  
    typedef FOPValueListIterator<T> Iterator;
 
	// Const Iterator, This member specify typedef FOPValueListConstIterator<T> object.  
    typedef FOPValueListConstIterator<T> ConstIterator;
 
	// Value Type, This member specify typedef T object.  
    typedef T ValueType;
	
protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach, .

	// Detach
    void Detach() { if ( sh->m_nRef > 1 ) DetachInternal(); }
 
	// This member maintains a pointer to the object FOPValueListPrivate<T>.  
    FOPValueListPrivate<T>* sh;

	// detach internal
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach Internal, .

    void DetachInternal();
};

template <class T>
_FOLIB_INLINE void FOPValueList<T>::DetachInternal()
{
    sh->DeRef(); sh = new FOPValueListPrivate<T>( *sh );
}

//////////////////////////////////////////////////
// inherited by all collections

 
//===========================================================================
// Summary:
//      To use a FOTableCollection object, just call the constructor.
//      O Table Collection
//===========================================================================

class FOTableCollection
{
public:
	// auto delete or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// autoDelete, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL autoDelete()	const	       { return del_item; }

	// enable auto delete or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Automatic Delete, .
	// Parameters:
	//		enable---Specifies A Boolean value.
    void setAutoDelete( BOOL enable )  { del_item = enable; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
    virtual UINT  GetCount() const = 0;
	
	// delete all objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
    virtual void  clear() = 0;			
	
	// generic collection item
 
	// Item, This member maintains a pointer to the object typedef void.  
    typedef void *Item;					
	
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// no deletion of objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Collection, Constructs a FOTableCollection object.
	//		Returns A  value (Object).
    FOTableCollection() { del_item = FALSE; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Collection, Constructs a FOTableCollection object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableCollection & object(Value).
    FOTableCollection(const FOTableCollection &) { del_item = FALSE; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Collection, Destructor of class FOTableCollection
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~FOTableCollection() {}
	
	// default FALSE
 
	// This member sets TRUE if it is right.  
    BOOL del_item;						
	
	// create object
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A Item value (Object).  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).
    virtual Item     NewItem( Item );
	
	// delete object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		)---Specifies a Item ) = 0 object(Value).
    virtual void     DeleteItem( Item ) = 0;	
};

/////////////////////////////////////////////////////
// generic vector

 
//===========================================================================
// Summary:
//     The FOTableVector class derived from FOTableCollection
//      O Table Vector
//===========================================================================

class FOTableVector : public FOTableCollection	
{
 
	// O Table List, This member specify friend class object.  
	friend class FOTableList;				// needed by FOTableList::toVector
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Items, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).  
	//		Item---Item, Specifies a Item object(Value).
    virtual int CompareItems( Item, Item );
	
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// create empty vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Vector, Constructs a FOTableVector object.
	//		Returns A  value (Object).
    FOTableVector();
	
	//-----------------------------------------------------------------------
	// Summary:
	// create vector with nullptrs
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Vector, Constructs a FOTableVector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		size---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    FOTableVector( UINT size );				
	
	//-----------------------------------------------------------------------
	// Summary:
	// make copy of other vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Vector, Constructs a FOTableVector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&v---Specifies a const FOTableVector &v object(Value).
    FOTableVector( const FOTableVector &v );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Vector, Destructor of class FOTableVector
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~FOTableVector();
	
protected:
	
	// assign from other vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTableVector value (Object).  
	// Parameters:
	//		&v---Specifies a const FOTableVector &v object(Value).
    FOTableVector &operator=( const FOTableVector &v );	
	
	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&v---Specifies a const FOTableVector &v object(Value).
    BOOL operator==( const FOTableVector &v ) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object Item ,or NULL if the call failed
	// data
    Item	 *data()    const	{ return vec; }

	// Obtain the size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetSize()    const	{ return m_nSize; }

	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCount()   const	{ return m_nItems; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		Item---Item, Specifies a Item object(Value).
	// insert item at index
    BOOL  insert( UINT index, Item );		
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// remove item
    BOOL  remove( UINT index );			
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Item value (Object).  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// take out item
    Item	  take( UINT index );			
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// clear vector
    void  clear();				
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		newsize---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// resize vector
    BOOL  resize( UINT newsize );		
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).  
	//		flen---Specifies A integer value.
	// resize and fill vector
    BOOL  fill( Item, int flen );		
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// sort vector
    void  sort();			
	
	// binary search (when sorted)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search, .
	//		Returns a int type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).
    int	  BSearch( Item ) const;			
	
	// find exact item in vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Reference, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).  
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    int	  FindRef( Item, UINT index ) const;	
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).  
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// find equal item in vector
    int	  find( Item, UINT index ) const;	
	
	// get number of exact matches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Reference, .
	//		Returns a UINT type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).
    UINT  ContainsRef( Item ) const;	
	
	// get number of equal matches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains, .
	//		Returns a UINT type value.  
	// Parameters:
	//		Item---Item, Specifies a Item object(Value).
    UINT  Contains( Item ) const;		
	
	// return indexed item
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Item value (Object).  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    Item	  at( UINT index ) const		
    {
		return vec[index];
    }
	
	// insert, expand if necessary
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Expand, Inserts a child object at the given index..
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		Item---Item, Specifies a Item object(Value).
    BOOL InsertExpand( UINT index, Item );	
	
protected:
	// item
 
	// This member maintains a pointer to the object Item.  
    Item		*vec;

	// length
 
	// Size, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT		m_nSize;

	// num of items
 
	// Items, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT		m_nItems;
	
};

//////////////////////////////////////////////
// FOTablePtrVector

template<class type>
 
//===========================================================================
// Summary:
//     The FOTablePtrVector class derived from FOTableVector
//      O Table Pointer Vector
//===========================================================================

class FOTablePtrVector : public FOTableVector
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer Vector, Constructs a FOTablePtrVector object.
	//		Returns A  value (Object).
    FOTablePtrVector()				{}

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer Vector, Constructs a FOTablePtrVector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		size---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    FOTablePtrVector( UINT size ) : FOTableVector(size) { }

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer Vector, Constructs a FOTablePtrVector object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&var---Specifies a const FOTablePtrVector<type> &var object(Value).
    FOTablePtrVector( const FOTablePtrVector<type> &var ) : FOTableVector( var ) { }

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Pointer Vector, Destructor of class FOTablePtrVector
	//		Returns A  value (Object).
    ~FOTablePtrVector()				{ clear(); }

public:

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTablePtrVector<type> value (Object).  
	// Parameters:
	//		&v---Specifies a const FOTablePtrVector<type> &v object(Value).
    FOTablePtrVector<type> &operator=(const FOTablePtrVector<type> &v)
	{ return (FOTablePtrVector<type>&)FOTableVector::operator=(v); }

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&v---Specifies a const FOTablePtrVector<type> &v object(Value).
    BOOL operator==( const FOTablePtrVector<type> &v ) const { return FOTableVector::operator==(v); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
	// data
    type **data()   const		{ return (type **)FOTableVector::data(); }

	// Obtain the size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetSize()    const		{ return FOTableVector::GetSize(); }

	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCount()   const		{ return FOTableVector::GetCount(); }

	// Is empty or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  IsEmpty() const		{ return FOTableVector::GetCount() == 0; }

	// Is null or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  IsNull()  const		{ return FOTableVector::GetSize() == 0; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		size---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// resize
    BOOL  resize( UINT size )		{ return FOTableVector::resize(size); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*da---A pointer to the const type  or NULL if the call failed.
	// insert at
    BOOL  insert( UINT index, const type *da){ return FOTableVector::insert(index,(Item)da); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// remove at
    BOOL  remove( UINT index )		{ return FOTableVector::remove(index); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// take at
    type *take( UINT index )		{ return (type *)FOTableVector::take(index); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// clear all
    void  clear()			{ FOTableVector::clear(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.  
	//		size---Specifies A integer value.
	// fill
    BOOL  fill( const type *da, int size=-1 )
	{ return FOTableVector::fill((Item)da,size);}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// sort
    void  sort()			{ FOTableVector::sort(); }

	// Bin search
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search, .
	//		Returns a int type value.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.
    int	  BSearch( const type *da ) const{ return FOTableVector::BSearch((Item)da); }

	// Find reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Reference, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.  
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    int	  FindRef( const type *da, UINT index=0 ) const
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.  
	//		index---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	{ return FOTableVector::FindRef((Item)da,index);}

	// Find i
    int	  find( const type *da, UINT index= 0 ) const
	{ return FOTableVector::find((Item)da,index); }

	// Contains ref or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Reference, .
	//		Returns a UINT type value.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.
    UINT  ContainsRef( const type *da ) const
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains, .
	//		Returns a UINT type value.  
	// Parameters:
	//		*da---A pointer to the const type  or NULL if the call failed.
				{ return FOTableVector::ContainsRef((Item)da); }

	// Contains data
    UINT  Contains( const type *da ) const
	{ return FOTableVector::Contains((Item)da); }

	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
    type *operator[]( int index ) const	{ return (type *)FOTableVector::at(index); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// at index
    type *at( UINT num ) const		{ return (type *)FOTableVector::at(num); }

	// to list
	
	//-----------------------------------------------------------------------
	// Summary:
	// To List, .
	// Parameters:
	//		*list---A pointer to the FOTableList  or NULL if the call failed.
    void  ToList( FOTableList *list ) const	{ FOTableVector::toList(list); }
	
protected:
	// Delete item at
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// Parameters:
	//		da---Specifies a Item da object(Value).
    void  DeleteItem( Item da );
};

template<> _FOLIB_INLINE void FOTablePtrVector<void>::DeleteItem( FOTableCollection::Item )
{
}

template<class type> _FOLIB_INLINE void FOTablePtrVector<type>::DeleteItem( FOTableCollection::Item d )
{
    if ( del_item ) delete (type *)d;
}

///////////////////////////////////////////////////
// FOTableNode

 
//===========================================================================
// Summary:
//      To use a FOTableNode object, just call the constructor.
//      O Table Node
//===========================================================================

class FOTableNode
{
 
	// O Table List, This member specify friend class object.  
	friend class FOTableList;
 
	// O Table List Iterator, This member specify friend class object.  
	friend class FOTableListIterator;
 
	// O Table List Std Iterator, This member specify friend class object.  
	friend class FOTableListStdIterator;
public:
	// Obtain the data
    FOTableCollection::Item GetData()	{ return data; }

protected:
	// data object
    FOTableCollection::Item data;

	// pointer of previous
 
	// This member maintains a pointer to the object FOTableNode.  
    FOTableNode *prev;

	// pointer of the next
 
	// This member maintains a pointer to the object FOTableNode.  
    FOTableNode *next;

	// constructor
    FOTableNode( FOTableCollection::Item da ) { data = da; }
};


////////////////////////////////////////////////////
// FOTableList

class FOTableListIteratorList;
 
//===========================================================================
// Summary:
//     The FOTableList class derived from FOTableCollection
//      O Table List
//===========================================================================

class FOTableList : public FOTableCollection
{
 
	// O Table List Iterator, This member specify friend class object.  
	friend class FOTableListIterator;
 
	// O Table List Iterator List, This member specify friend class object.  
	friend class FOTableListIteratorList;
 
	// O Table Vector, This member specify friend class object.  
	friend class FOTableVector;
public:

	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCount() const;
	
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// create empty list
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table List, Constructs a FOTableList object.
	//		Returns A  value (Object).
    FOTableList();						
	
	//-----------------------------------------------------------------------
	// Summary:
	// make copy of other list
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table List, Constructs a FOTableList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableList & object(Value).
    FOTableList( const FOTableList & );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table List, Destructor of class FOTableList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~FOTableList();
	
protected:
	// assign from other list
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTableList value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableList & object(Value).
    FOTableList &operator=( const FOTableList & );	

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		FOTableList&---O Table List&, Specifies a const FOTableList& object(Value).
    BOOL operator==( const FOTableList& ) const;
	
	// add item sorted in list
    void InSort( FOTableCollection::Item );		
	
	// add item at end of list
    void append( FOTableCollection::Item );		
	
	// add item at i'th position
    BOOL InsertAt( UINT index, FOTableCollection::Item ); 
	
	// relink as first item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relink Node, .
	// Parameters:
	//		*---A pointer to the FOTableNode  or NULL if the call failed.
    void RelinkNode( FOTableNode * );		
	
	// remove node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Node, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*---A pointer to the FOTableNode  or NULL if the call failed.
    BOOL RemoveNode( FOTableNode * );			
	
	// remove item (0=current)
    BOOL remove( FOTableCollection::Item = 0 );	
	
	// remove item (0=current)
    BOOL RemoveRef( FOTableCollection::Item = 0 );	
	
	// remove first item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove First, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL RemoveFirst();					
	
	// remove last item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Last, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL RemoveLast();				
	
	// remove item at i'th position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    BOOL RemoveAt( UINT );						
	
	// replace item at position i with item
    BOOL ReplaceAt( UINT, FOTableCollection::Item ); 
	
	// take out node
    FOTableCollection::Item TakeNode( FOTableNode * );	
	
	// take out current item
    FOTableCollection::Item take();				
	
	// take out item at i'th pos
    FOTableCollection::Item TakeAt( UINT index );	
	
	// take out first item
    FOTableCollection::Item TakeFirst();		
	
	// take out last item
    FOTableCollection::Item TakeLast();			
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// sort all items;
    void sort();                        
	
	// remove all items
	
	//-----------------------------------------------------------------------
	// Summary:
	// .

    void clear();								
	
	// find exact item in list
    int	 FindRef( FOTableCollection::Item, BOOL = TRUE ); 
	
	// find equal item in list
    int	 find( FOTableCollection::Item, BOOL = TRUE ); 
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.
	// get number of exact matches
    UINT ContainsRef( FOTableCollection::Item ) const;	
	
	// get number of equal matches
    UINT Contains( FOTableCollection::Item ) const;	
	
	// access item at i'th pos
    FOTableCollection::Item at( UINT index );	
	
	// get current index
    int	  at() const;				
	
	// get current node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Current Node, .
	//		Returns a pointer to the object FOTableNode ,or NULL if the call failed
    FOTableNode *CurrentNode() const;		
	
	// get current item
    FOTableCollection::Item get() const;		
	
	// get ptr to first list item
    FOTableCollection::Item CFirst() const;	
	
	// get ptr to last list item
    FOTableCollection::Item CLast()  const;	
	
	// set first item in list curr
    FOTableCollection::Item first();		
	
	// set last item in list curr
    FOTableCollection::Item last();		
	
	// set next item in list curr
    FOTableCollection::Item next();		
	
	// set prev item in list curr
    FOTableCollection::Item prev();		
	
	// put items in vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Vector, .
	// Parameters:
	//		*---A pointer to the FOTableVector  or NULL if the call failed.
    void  ToVector( FOTableVector * ) const;		
	
	// Compare items.
    virtual int CompareItems( FOTableCollection::Item, FOTableCollection::Item );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOTableNode,or NULL if the call failed
	// begin pointer
    FOTableNode* begin() const { return firstNode; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOTableNode,or NULL if the call failed
	// end pointer
    FOTableNode* end() const { return 0; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOTableNode,or NULL if the call failed  
	// Parameters:
	//		data---A pointer to the FOTableNode or NULL if the call failed.
	// erase data
    FOTableNode* erase( FOTableNode* data );
	
protected:
	
	// add item at start of list
    void  PrePend( FOTableCollection::Item );	

	// push down
    void HeapSortPushDown( FOTableCollection::Item* heap, int first, int last );
	
	// first node
 
	// Node, This member maintains a pointer to the object FOTableNode.  
    FOTableNode *firstNode;		
	
	// last node
 
	// Node, This member maintains a pointer to the object FOTableNode.  
    FOTableNode *lastNode;		
	
	// current node
 
	// Node, This member maintains a pointer to the object FOTableNode.  
    FOTableNode *curNode;			
	
	// current index
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int curIndex;					
	
	// number of nodes
 
	// Nodes, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT numNodes;				
	
	// list of iterators
 
	// This member maintains a pointer to the object FOTableListIteratorList.  
    FOTableListIteratorList *iterators; 	
	
	// get node at i'th pos
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOTableNode ,or NULL if the call failed  
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    FOTableNode *locate( UINT );	
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object FOTableNode ,or NULL if the call failed
	// unlink node
    FOTableNode *unlink();				
};


_FOLIB_INLINE UINT FOTableList::GetCount() const
{
    return numNodes;
}

_FOLIB_INLINE BOOL FOTableList::RemoveFirst()
{
    first();
    return remove();
}

_FOLIB_INLINE BOOL FOTableList::RemoveLast()
{
    last();
    return remove();
}

_FOLIB_INLINE int FOTableList::at() const
{
    return curIndex;
}

_FOLIB_INLINE FOTableCollection::Item FOTableList::at( UINT index )
{
    FOTableNode *n = locate( index );
    return n ? n->data : 0;
}

_FOLIB_INLINE FOTableNode *FOTableList::CurrentNode() const
{
    return curNode;
}

_FOLIB_INLINE FOTableCollection::Item FOTableList::get() const
{
    return curNode ? curNode->data : 0;
}

_FOLIB_INLINE FOTableCollection::Item FOTableList::CFirst() const
{
    return firstNode ? firstNode->data : 0;
}

_FOLIB_INLINE FOTableCollection::Item FOTableList::CLast() const
{
    return lastNode ? lastNode->data : 0;
}

/////////////////////////////////////////////////
// FOTableList iterator

 
//===========================================================================
// Summary:
//      To use a FOTableListIterator object, just call the constructor.
//      O Table List Iterator
//===========================================================================

class FOTableListIterator			
{
 
	// O Table List, This member specify friend class object.  
	friend class FOTableList;
 
	// O Table List Iterator List, This member specify friend class object.  
	friend class FOTableListIteratorList;
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table List Iterator, Constructs a FOTableListIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableList & object(Value).
    FOTableListIterator( const FOTableList & );

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table List Iterator, Constructs a FOTableListIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableListIterator & object(Value).
    FOTableListIterator( const FOTableListIterator & );

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTableListIterator value (Object).  
	// Parameters:
	//		&---Specifies a const FOTableListIterator & object(Value).
    FOTableListIterator &operator=( const FOTableListIterator & );

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table List Iterator, Destructor of class FOTableListIterator
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOTableListIterator();
	
public:
	// test if at first item
	
	//-----------------------------------------------------------------------
	// Summary:
	// At First, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  AtFirst() const;		
	
	// test if at last item
	
	//-----------------------------------------------------------------------
	// Summary:
	// At Last, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  AtLast()  const;	
	
	// move to first item
    FOTableCollection::Item	  ToFirst();
	
	// move to last item
    FOTableCollection::Item	  ToLast();				
	
	// get current item
    FOTableCollection::Item	  get() const;		
	
	// get current and move to next
    FOTableCollection::Item	  operator()();			
	
	// move to next item (prefix)
    FOTableCollection::Item	  operator++();		
	
	// move n positions forward
    FOTableCollection::Item	  operator+=(UINT);			
	
	// move to prev item (prefix)
    FOTableCollection::Item	  operator--();		
	
	// move n positions backward
    FOTableCollection::Item	  operator-=(UINT);			
	
protected:
	// reference to list
 
	// This member maintains a pointer to the object FOTableList.  
    FOTableList *list;				
	
private:
	// current node in list
 
	// Node, This member maintains a pointer to the object FOTableNode.  
    FOTableNode  *curNode;				
};

_FOLIB_INLINE BOOL FOTableListIterator::AtFirst() const
{
    return curNode == list->firstNode;
}

_FOLIB_INLINE BOOL FOTableListIterator::AtLast() const
{
    return curNode == list->lastNode;
}

_FOLIB_INLINE FOTableCollection::Item FOTableListIterator::get() const
{
    return curNode ? curNode->data : 0;
}

//////////////////////////////////////////////////////////
// FOTableListStdIterator

 
//===========================================================================
// Summary:
//      To use a FOTableListStdIterator object, just call the constructor.
//      O Table List Std Iterator
//===========================================================================

class FOTableListStdIterator
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table List Std Iterator, Constructs a FOTableListStdIterator object.
	//		Returns A _FOLIB_INLINE value (Object).  
	// Parameters:
	//		data---A pointer to the FOTableNode or NULL if the call failed.
    _FOLIB_INLINE FOTableListStdIterator( FOTableNode* data ) : node( data ){}

	// operator *
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Node, .
	//		Returns A _FOLIB_INLINE operator value (Object).
    _FOLIB_INLINE operator FOTableNode* () { return node; }
protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object _FOLIB_INLINE FOTableNode ,or NULL if the call failed
	// next pointer
    _FOLIB_INLINE FOTableNode *next() { return node->next; }

	// node
 
	// This member maintains a pointer to the object FOTableNode.  
    FOTableNode *node;
};

//////////////////////////////////////////////////////////
// FOTablePtrListStdIterator

template<class type>
 
//===========================================================================
// Summary:
//     The FOTablePtrListStdIterator class derived from FOTableListStdIterator
//      O Table Pointer List Std Iterator
//===========================================================================

class FOTablePtrListStdIterator : public FOTableListStdIterator
{
public:

	// constuctor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer List Std Iterator, Constructs a FOTablePtrListStdIterator object.
	//		Returns A _FOLIB_INLINE value (Object).  
	// Parameters:
	//		data---A pointer to the FOTableNode or NULL if the call failed.
    _FOLIB_INLINE FOTablePtrListStdIterator( FOTableNode* data ): FOTableListStdIterator(data) {}

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
	// operator *
    type *operator*() { return node ? (type *)node->GetData() : 0; }

	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE FOTablePtrListStdIterator<type> value (Object).
    _FOLIB_INLINE FOTablePtrListStdIterator<type> operator++()
    { node = next(); return *this; }

	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE FOTablePtrListStdIterator<type> value (Object).  
	// Parameters:
	//		int---Specifies A integer value.
    _FOLIB_INLINE FOTablePtrListStdIterator<type> operator++(int)
    { FOTableNode* data = node; node = next(); return FOTablePtrListStdIterator<type>( data ); }

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		data---Specifies a const FOTablePtrListStdIterator<type>& data object(Value).
    _FOLIB_INLINE BOOL operator==( const FOTablePtrListStdIterator<type>& data ) const { return node == data.node; }

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns _FOLIB_INLINE BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		data---Specifies a const FOTablePtrListStdIterator<type>& data object(Value).
    _FOLIB_INLINE BOOL operator!=( const FOTablePtrListStdIterator<type>& data ) const { return node != data.node; }
};


//////////////////////////////////////////////////////////
// FOTablePtrList

template<class type>
 
//===========================================================================
// Summary:
//     The FOTablePtrList class derived from FOTableList
//      O Table Pointer List
//===========================================================================

class FOTablePtrList : public FOTableList
{
public:
	
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer List, Constructs a FOTablePtrList object.
	//		Returns A  value (Object).
    FOTablePtrList()				{}

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer List, Constructs a FOTablePtrList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&data---Specifies a const FOTablePtrList<type> &data object(Value).
    FOTablePtrList( const FOTablePtrList<type> &data ) : FOTableList(data) {}

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Pointer List, Destructor of class FOTablePtrList
	//		Returns A  value (Object).
    ~FOTablePtrList()				{ clear(); }

public:

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTablePtrList<type> value (Object).  
	// Parameters:
	//		&data---Specifies a const FOTablePtrList<type> &data object(Value).
    FOTablePtrList<type> &operator=(const FOTablePtrList<type> &data)
	{ return (FOTablePtrList<type>&)FOTableList::operator=(data); }

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&list---Specifies a const FOTablePtrList<type> &list object(Value).
    BOOL operator==( const FOTablePtrList<type> &list ) const
    { return FOTableList::operator==( list ); }

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&list---Specifies a const FOTablePtrList<type> &list object(Value).
    BOOL operator!=( const FOTablePtrList<type> &list ) const
    { return !FOTableList::operator==( list ); }

	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCount()   const		{ return FOTableList::GetCount(); }

	// Is empty or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  IsEmpty() const		{ return FOTableList::GetCount() == 0; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*data---A pointer to the const type  or NULL if the call failed.
	// insert
    BOOL  insert( UINT num, const type *data){ return FOTableList::InsertAt(num,(FOTableCollection::Item)data); }

	// In sort
	
	//-----------------------------------------------------------------------
	// Summary:
	// In Sort, .
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    void  InSort( const type *data )	{ FOTableList::InSort((FOTableCollection::Item)data); }

	// Pre pend
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Pend, .
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    void  PrePend( const type *data )	{ FOTableList::InsertAt(0,(FOTableCollection::Item)data); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
	// append new data
    void  append( const type *data )	{ FOTableList::append((FOTableCollection::Item)data); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// remove at index
    BOOL  remove( UINT num )		{ return FOTableList::RemoveAt(num); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// remove
    BOOL  remove()			{ return FOTableList::remove((FOTableCollection::Item)0); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
	// remove
    BOOL  remove( const type *data )	{ return FOTableList::remove((FOTableCollection::Item)data); }

	// remove reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Reference, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    BOOL  RemoveRef( const type *data )	{ return FOTableList::RemoveRef((FOTableCollection::Item)data); }

	// Remove node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Node, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		*nd---A pointer to the FOTableNode  or NULL if the call failed.
    void  RemoveNode( FOTableNode *nd )	{ FOTableList::RemoveNode(nd); }

	// remove first
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove First, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  RemoveFirst()			{ return FOTableList::RemoveFirst(); }

	// remove last
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Last, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  RemoveLast()			{ return FOTableList::RemoveLast(); }

	// get data at index
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    type *take( UINT num )		{ return (type *)FOTableList::TakeAt(num); }

	// obtain the pointer of the data
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *take()			{ return (type *)FOTableList::take(); }

	// Take node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Node, .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		*nd---A pointer to the FOTableNode  or NULL if the call failed.
    type *TakeNode( FOTableNode *nd )		{ return (type *)FOTableList::TakeNode(nd); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// clear
    void  clear()			{ FOTableList::clear(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .

	// sort
    void  sort()			{ FOTableList::sort(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
	// find
    int	  find( const type *data )		{ return FOTableList::find((FOTableCollection::Item)data); }

	// find next
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Next, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    int	  FindNext( const type *data )	{ return FOTableList::find((FOTableCollection::Item)data,FALSE); }

	// find ref
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Reference, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    int	  FindRef( const type *data )	{ return FOTableList::FindRef((FOTableCollection::Item)data); }

	// find next reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Next Reference, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    int	  FindNextRef( const type *data ){ return FOTableList::FindRef((FOTableCollection::Item)data,FALSE);}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains, .
	//		Returns a UINT type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
	// contains
    UINT  Contains( const type *data ) const { return FOTableList::Contains((FOTableCollection::Item)data); }

	// contains reference
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Reference, .
	//		Returns a UINT type value.  
	// Parameters:
	//		*data---A pointer to the const type  or NULL if the call failed.
    UINT  ContainsRef( const type *data ) const
	{ return FOTableList::ContainsRef((FOTableCollection::Item)data); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*data---A pointer to the const type  or NULL if the call failed.
	// replace
    BOOL replace( UINT num, const type *data ) { return FOTableList::ReplaceAt( num, (FOTableCollection::Item)data ); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		num---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    type *at( UINT num )			{ return (type *)FOTableList::at(num); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.
    int	  at() const			{ return FOTableList::at(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *current()  const		{ return (type *)FOTableList::get(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Current Node, .
	//		Returns a pointer to the object FOTableNode ,or NULL if the call failed
    FOTableNode *CurrentNode()  const	{ return FOTableList::CurrentNode(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First, Returns the specified value.
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *GetFirst() const		{ return (type *)FOTableList::CFirst(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last, Returns the specified value.
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *GetLast()  const		{ return (type *)FOTableList::CLast(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *first()			{ return (type *)FOTableList::first(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *last()			{ return (type *)FOTableList::last(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *next()			{ return (type *)FOTableList::next(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *prev()			{ return (type *)FOTableList::prev(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Vector, .
	// Parameters:
	//		*vec---A pointer to the FOTableVector  or NULL if the call failed.
    void  ToVector( FOTableVector *vec )const{ FOTableList::ToVector(vec); }

    // standard iterators
 
	// This member specify typedef FOTablePtrListStdIterator<type> object.  
    typedef FOTablePtrListStdIterator<type> Iterator;
 
	// Const Iterator, This member specify typedef FOTablePtrListStdIterator<type> object.  
    typedef FOTablePtrListStdIterator<type> ConstIterator;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE Iterator value (Object).
    _FOLIB_INLINE Iterator begin() { return FOTableList::begin(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE ConstIterator value (Object).
	// begin
    _FOLIB_INLINE ConstIterator begin() const { return FOTableList::begin(); }

	// const begin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Const Begin, .
	//		Returns A _FOLIB_INLINE ConstIterator value (Object).
    _FOLIB_INLINE ConstIterator ConstBegin() const { return FOTableList::begin(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE Iterator value (Object).
	// end
    _FOLIB_INLINE Iterator end() { return FOTableList::end(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE ConstIterator value (Object).
	// end
    _FOLIB_INLINE ConstIterator end() const { return FOTableList::end(); }

	// const end
	
	//-----------------------------------------------------------------------
	// Summary:
	// Const End, .
	//		Returns A _FOLIB_INLINE ConstIterator value (Object).
    _FOLIB_INLINE ConstIterator ConstEnd() const { return FOTableList::end(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A _FOLIB_INLINE Iterator value (Object).  
	// Parameters:
	//		iter---Specifies a Iterator iter object(Value).
	// erase
    _FOLIB_INLINE Iterator erase( Iterator iter ) { return FOTableList::erase( iter ); }

    // stl syntax compatibility
 
	// This member specify typedef Iterator object.  
    typedef Iterator iterator;
 
	// This member specify typedef ConstIterator object.  
    typedef ConstIterator const_iterator;

protected:

	// Delete item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// Parameters:
	//		data---Specifies a Item data object(Value).
    void  DeleteItem( Item data );
};

template<> _FOLIB_INLINE void FOTablePtrList<void>::DeleteItem( FOTableCollection::Item )
{
}

template<class type> _FOLIB_INLINE void FOTablePtrList<type>::DeleteItem( FOTableCollection::Item data )
{
    if ( del_item ) delete (type *)data;
}


//////////////////////////////////////////////////////////
// FOTablePtrListIterator

template<class type>
 
//===========================================================================
// Summary:
//     The FOTablePtrListIterator class derived from FOTableListIterator
//      O Table Pointer List Iterator
//===========================================================================

class FOTablePtrListIterator : public FOTableListIterator
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Table Pointer List Iterator, Constructs a FOTablePtrListIterator object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&data---Specifies a const FOTablePtrList<type> &data object(Value).
    FOTablePtrListIterator(const FOTablePtrList<type> &data) :FOTableListIterator((FOTableList &)data) {}

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Pointer List Iterator, Destructor of class FOTablePtrListIterator
	//		Returns A  value (Object).
    ~FOTablePtrListIterator()	      {}

public:
	// Obtain the count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCount()   const     { return list->GetCount(); }

	// Is empty or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  IsEmpty() const     { return list->GetCount() == 0; }

	// Is the first node
	
	//-----------------------------------------------------------------------
	// Summary:
	// At First, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  AtFirst() const     { return FOTableListIterator::AtFirst(); }

	// Is the last node
	
	//-----------------------------------------------------------------------
	// Summary:
	// At Last, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL  AtLast()  const     { return FOTableListIterator::AtLast(); }

	// Obtain the pointer of the first node
	
	//-----------------------------------------------------------------------
	// Summary:
	// To First, .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *ToFirst()	      { return (type *)FOTableListIterator::ToFirst(); }

	// Obtain the pointer of the last node.
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Last, .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *ToLast()	      { return (type *)FOTableListIterator::ToLast(); }

	// Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    operator type *() const   { return (type *)FOTableListIterator::get(); }

	// pointer
    type *operator*()         { return (type *)FOTableListIterator::get(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
	// Current pointer
    type *current()   const   { return (type *)FOTableListIterator::get(); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		)(---Specifies a )( object(Value).
	// operator ()
    type *operator()()	      { return (type *)FOTableListIterator::operator()();}

	// operator ++
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *operator++()	      { return (type *)FOTableListIterator::operator++(); }

	// operator +=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		number---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    type *operator+=(UINT number)  { return (type *)FOTableListIterator::operator+=(number);}

	// operator --
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed
    type *operator--()	      { return (type *)FOTableListIterator::operator--(); }

	// operator -=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object type ,or NULL if the call failed  
	// Parameters:
	//		number---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    type *operator-=(UINT number)  { return (type *)FOTableListIterator::operator-=(number);}

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOTablePtrListIterator<type>& value (Object).  
	// Parameters:
	//		FOTablePtrListIterator<type>&data---O Table Pointer List Iterator<type>&data, Specifies a const FOTablePtrListIterator<type>&data object(Value).
    FOTablePtrListIterator<type>& operator=(const FOTablePtrListIterator<type>&data)
			      { FOTableListIterator::operator=(data); return *this; }
};

#endif // !defined(AFX_FOPTABLEHELPER_H__66EA4AD6_A44F_40AC_8E19_E6109DEF4F61__INCLUDED_)
