//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTABLECELLSACTION_H__6E4CEB02_A558_47C1_BF62_A157BE607B27__INCLUDED_)
#define FO_FOTABLECELLSACTION_H__6E4CEB02_A558_47C1_BF62_A157BE607B27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "FOAction.h"
#include "FOPTableShape.h"
#include "FOXNewTableShape.h"

////////////////////////////////////////////////////////////////////////////////
// CFOTableCellTextChangeAction
///////////////////////////////////////
// Description: CFOTableCellTextChangeAction -- table cell text changing action.
// Author: Author
///////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOTableCellTextChangeAction class derived from CFOAction
//      F O Table Cell Text Change Action
//===========================================================================

class FO_EXT_CLASS CFOTableCellTextChangeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTableCellTextChangeAction---F O Table Cell Text Change Action, Specifies a E-XD++ CFOTableCellTextChangeAction object (Value).
	DECLARE_ACTION(CFOTableCellTextChangeAction)
		
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Cell Text Change Action, Constructs a CFOTableCellTextChangeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pTableCell---Table Cell, A pointer to the CFOPTableCell  or NULL if the call failed.  
	//		crText---crText, Specifies A CString type value.
	CFOTableCellTextChangeAction(CFODataModel* pModel,CFOPTableCell *pTableCell,CString crText);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Table Cell Text Change Action, Destructor of class CFOTableCellTextChangeAction
	//		Returns A  value (Object).
	~CFOTableCellTextChangeAction();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new TableCell to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Table Cell, Sets a specify value to current class CFOTableCellTextChangeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pTableCell---Table Cell, A pointer to the CFOPTableCell  or NULL if the call failed.
	virtual void SetTableCell(CFOPTableCell *pTableCell);
	
	// Return the pointer of the TableCell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Table Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed
	virtual CFOPTableCell *GetTableCell();
	
	// Get the current text color of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text Color, Returns the specified value.
	//		Returns a CString type value.
	CString GetCurrentTextColor()			  { return m_crTextNew; }
	
	// Set the current back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Color, Sets a specify value to current class CFOTableCellTextChangeAction
	// Parameters:
	//		crText---crText, Specifies A CString type value.
	void SetCurrentTextColor(CString crText) { m_crTextNew = crText; }
	
protected:
	
	// The pointer to TableCell
 
	// Table Cell, This member maintains a pointer to the object CFOPTableCell.  
	CFOPTableCell*	m_pTableCell;
	
	// New Text Color 
 
	// Text New, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_crTextNew;
	
	// Old Text Color
 
	// Text Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_crTextOld;
	
	// Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
 
	// F O P Table Shape, This member specify friend class object.  
	friend class CFOPTableShape;
};

// Set pointer to  TableCell
_FOLIB_INLINE void CFOTableCellTextChangeAction::SetTableCell(CFOPTableCell *pTableCell)
{
	if (m_pTableCell != pTableCell)
	{
		m_pTableCell = pTableCell;
	}
}

//	 Get  TableCell
_FOLIB_INLINE CFOPTableCell *CFOTableCellTextChangeAction::GetTableCell()
{
	return m_pTableCell;
}


//===========================================================================
// Summary:
//     The CFOSdrTableCellTextAction class derived from CFOAction
//      F O Table Cell Text Change Action
//===========================================================================

class FO_EXT_CLASS CFOSdrTableCellTextAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSdrTableCellTextAction---F O Table Cell Text Change Action, Specifies a E-XD++ CFOSdrTableCellTextAction object (Value).
	DECLARE_ACTION(CFOSdrTableCellTextAction)
		
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Table Cell Text Change Action, Constructs a CFOSdrTableCellTextAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pTableCell---Table Cell, A pointer to the CFOPNewTableCell  or NULL if the call failed.  
	//		crText---crText, Specifies A CString type value.
	CFOSdrTableCellTextAction(CFODataModel* pModel,CFOPNewTableCell *pTableCell,CString crText);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Table Cell Text Change Action, Destructor of class CFOSdrTableCellTextAction
	//		Returns A  value (Object).
	~CFOSdrTableCellTextAction();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new TableCell to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Table Cell, Sets a specify value to current class CFOSdrTableCellTextAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pTableCell---Table Cell, A pointer to the CFOPNewTableCell  or NULL if the call failed.
	virtual void SetTableCell(CFOPNewTableCell *pTableCell);
	
	// Return the pointer of the TableCell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Table Cell, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPNewTableCell ,or NULL if the call failed
	virtual CFOPNewTableCell *GetTableCell();
	
	// Get the current text color of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text Color, Returns the specified value.
	//		Returns a CString type value.
	CString GetCurrentTextColor()			  { return m_crTextNew; }
	
	// Set the current back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text Color, Sets a specify value to current class CFOSdrTableCellTextAction
	// Parameters:
	//		crText---crText, Specifies A CString type value.
	void SetCurrentTextColor(CString crText) { m_crTextNew = crText; }
	
protected:
	
	// The pointer to TableCell
 
	// Table Cell, This member maintains a pointer to the object CFOPNewTableCell.  
	CFOPNewTableCell*	m_pTableCell;
	
	// New Text Color 
 
	// Text New, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_crTextNew;
	
	// Old Text Color
 
	// Text Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_crTextOld;
	
	// Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
 
	// F O P Table Shape, This member specify friend class object.  
	friend class FOXNewTableShape;
};

// Set pointer to  TableCell
_FOLIB_INLINE void CFOSdrTableCellTextAction::SetTableCell(CFOPNewTableCell *pTableCell)
{
	if (m_pTableCell != pTableCell)
	{
		m_pTableCell = pTableCell;
	}
}

//	 Get  TableCell
_FOLIB_INLINE CFOPNewTableCell *CFOSdrTableCellTextAction::GetTableCell()
{
	return m_pTableCell;
}

//////////////////////////////////////////////////////////////////////////////////
// CFOPTableKeyDataAction -- table key data action.

 
//===========================================================================
// Summary:
//     The CFOPTableKeyDataAction class derived from CFOAction
//      F O P Table Key Data Action
//===========================================================================

class FO_EXT_CLASS CFOPTableKeyDataAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPTableKeyDataAction---F O P Table Key Data Action, Specifies a E-XD++ CFOPTableKeyDataAction object (Value).
	DECLARE_ACTION(CFOPTableKeyDataAction)
public:
	
	// Constructor.
	// pModel -- pointer of the data model.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Key Data Action, Constructs a CFOPTableKeyDataAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOPTableShape  or NULL if the call failed.
	CFOPTableKeyDataAction(CFODataModel* pModel,CFOPTableShape *pShape);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Key Data Action, Destructor of class CFOPTableKeyDataAction
	//		Returns A  value (Object).
	~CFOPTableKeyDataAction();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	// strLabel -- label for the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new shape to the action.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPTableKeyDataAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPTableShape  or NULL if the call failed.
	virtual void SetShape(CFOPTableShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableShape ,or NULL if the call failed
	virtual CFOPTableShape *GetShape();

	// Get reset selection state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Reset Select State, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetResetSelectState() const { return m_bResetSelect; }

	// Change reset selection state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Reset Select State, Sets a specify value to current class CFOPTableKeyDataAction
	// Parameters:
	//		&bReset---&bReset, Specifies A Boolean value.
	void SetResetSelectState(const BOOL &bReset) { m_bResetSelect = bReset; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	
	// pointer of the shape
 
	// Shape, This member maintains a pointer to the object CFOPTableShape.  
	CFOPTableShape *		m_pShape;

	// Reset selection state.
 
	// Reset Select, This member sets TRUE if it is right.  
	BOOL					m_bResetSelect;
	
	// pointer of the new geometry data
	CFOPTableShape::FOPTableKeyData*		pNewGeo;
	
	// pointer of the old geometry data.
	CFOPTableShape::FOPTableKeyData*		pOldGeo;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
 
	// F O P Table Shape, This member specify friend class object.  
	friend class CFOPTableShape;
};

_FOLIB_INLINE void CFOPTableKeyDataAction::SetShape(CFOPTableShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}

_FOLIB_INLINE CFOPTableShape *CFOPTableKeyDataAction::GetShape()
{
	return m_pShape;
}
//===========================================================================

class FO_EXT_CLASS CFOPSdrTableGeoAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSdrTableGeoAction---F O P Table Key Data Action, Specifies a E-XD++ CFOPSdrTableGeoAction object (Value).
	DECLARE_ACTION(CFOPSdrTableGeoAction)
public:
	
	// Constructor.
	// pModel -- pointer of the data model.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Key Data Action, Constructs a CFOPSdrTableGeoAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the FOXNewTableShape  or NULL if the call failed.
	CFOPSdrTableGeoAction(CFODataModel* pModel,FOXNewTableShape *pShape);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Key Data Action, Destructor of class CFOPSdrTableGeoAction
	//		Returns A  value (Object).
	~CFOPSdrTableGeoAction();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	// strLabel -- label for the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new shape to the action.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPSdrTableGeoAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the FOXNewTableShape  or NULL if the call failed.
	virtual void SetShape(FOXNewTableShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOXNewTableShape ,or NULL if the call failed
	virtual FOXNewTableShape *GetShape();

	// Get reset selection state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Reset Select State, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetResetSelectState() const { return m_bResetSelect; }

	// Change reset selection state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Reset Select State, Sets a specify value to current class CFOPSdrTableGeoAction
	// Parameters:
	//		&bReset---&bReset, Specifies A Boolean value.
	void SetResetSelectState(const BOOL &bReset) { m_bResetSelect = bReset; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
public:
	
	// pointer of the shape
 
	// Shape, This member maintains a pointer to the object FOXNewTableShape.  
	FOXNewTableShape *		m_pShape;

	// Reset selection state.
 
	// Reset Select, This member sets TRUE if it is right.  
	BOOL					m_bResetSelect;
	
	// pointer of the new geometry data
	FOXTableModel*		pNewGeo;
	
	// pointer of the old geometry data.
	FOXTableModel*		pOldGeo;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
 
	// F O P Table Shape, This member specify friend class object.  
	friend class FOXNewTableShape;
};

_FOLIB_INLINE void CFOPSdrTableGeoAction::SetShape(FOXNewTableShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}

_FOLIB_INLINE FOXNewTableShape *CFOPSdrTableGeoAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(FO_FOTABLECELLSACTION_H__6E4CEB02_A558_47C1_BF62_A157BE607B27__INCLUDED_)
