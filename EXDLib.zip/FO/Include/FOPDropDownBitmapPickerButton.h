//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNBITMAPPICKERBUTTON_H__0FB2BEB7_3BDC_4053_9F64_CFB2607F66AC__INCLUDED_)
#define AFX_FOPDROPDOWNBITMAPPICKERBUTTON_H__0FB2BEB7_3BDC_4053_9F64_CFB2607F66AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownBitmapPickerButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownBitmapPickerButton window
#include "FOPDropDownComplexPickerButtonBase.h"

 
//===========================================================================
// Summary:
//     The FOPDropDownBitmapPickerButton class derived from FOPDropDownComplexPickerButtonBase
//      O P Drop Down Bitmap Picker Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownBitmapPickerButton : public FOPDropDownComplexPickerButtonBase
{
// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Bitmap Picker Button, Constructs a FOPDropDownBitmapPickerButton object.
	//		Returns A  value (Object).  
	// Parameters:
	//		id---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		useSystemColors---System Colors, Specifies A Boolean value.  
	//		Transparent---Transparent, Specifies A Boolean value.
	FOPDropDownBitmapPickerButton(UINT id, BOOL  useSystemColors = TRUE, BOOL  Transparent = TRUE);

// Attributes
public:

	// Set use system color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Use System Colors, Sets a specify value to current class FOPDropDownBitmapPickerButton
	// Parameters:
	//		bSys---bSys, Specifies A Boolean value.
	void		SetUseSystemColors(BOOL  bSys);

	// Get minimum height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	//		Returns a int type value.
	int  		GetMinimumHeight() const;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownBitmapPickerButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Bitmap Picker Button, Destructor of class FOPDropDownBitmapPickerButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownBitmapPickerButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownBitmapPickerButton)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNBITMAPPICKERBUTTON_H__0FB2BEB7_3BDC_4053_9F64_CFB2607F66AC__INCLUDED_)
