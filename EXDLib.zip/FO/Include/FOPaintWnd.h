//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPAINTWND_H__AA19F1D4_B867_11D5_A476_525400EA266C__INCLUDED_)
#define AFX_FOPAINTWND_H__AA19F1D4_B867_11D5_A476_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPaintWnd.h : header file
//

///////////////////////////////////////////////////////////////////
// Image tools.
///////////////////////////////////////////////////////////////////
enum FO_IMAGE_TOOL
{
	FO_IMAGE_TOOL_PEN = 0,
	FO_IMAGE_TOOL_FILL,
	FO_IMAGE_TOOL_LINE,
	FO_IMAGE_TOOL_RECT,
	FO_IMAGE_TOOL_ELLIPSE,
	FO_IMAGE_TOOL_ROUNDRECT,
	FO_IMAGE_TOOL_FILLRECT,
	FO_IMAGE_TOOL_FILLELLIPSE,
	FO_IMAGE_TOOL_FILLROUNDRECT,
	FO_IMAGE_TOOL_EMPTYRECT,
	FO_IMAGE_TOOL_EMPTYELLIPSE,
	FO_IMAGE_TOOL_EMPTYROUNDRECT,
	FO_IMAGE_TOOL_COLOR
};

/////////////////////////////////////////////////////////////////////////////
// CFOPaintWnd window
 
//===========================================================================
// Summary:
//     The CFOPaintWnd class derived from CWnd
//      F O Paint Window
//===========================================================================

class FO_EXT_CLASS CFOPaintWnd : public CWnd
{

	// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Paint Window, Constructs a CFOPaintWnd object.
	//		Returns A  value (Object).
	CFOPaintWnd();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPaintWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a new wnd.
	// dwStyle -- the window style.
	// rcPos -- the position of window.
	// pParent -- the pointer to parent window.
	// nID -- id value.
	BOOL Create(DWORD dwStyle,CRect rcPos, CWnd* pParent,UINT nID);


	// Attributes
public:

	// set or get current tool
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Tool, Sets a specify value to current class CFOPaintWnd
	// Parameters:
	//		nTool---nTool, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetCurrentTool(const UINT nTool);

	// Get current tool.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Tool, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetCurrentTool() const;

	// set color of font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOPaintWnd
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetFontColor(COLORREF crColor);

	// change a bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Bitmap, .
	// Parameters:
	//		pBitmap---pBitmap, A pointer to the CBitmap or NULL if the call failed.
	void ChangeBitmap(CBitmap* pBitmap);

public:
	
	// Save rectangle.
 
	// Save, This member sets a CRect value.  
	CRect		 m_rcSave;

	// Operations
protected:

	// Draw state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

protected:
	
	// Fill pixel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Pixel, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void FillPixel(const CPoint& point);

	// Make bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Bitmap, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual void MakeBitmap(CPoint& pt);

	// Client rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client Rectangle, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void ClientRect(CRect& rect);

	// Fill pixel extend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Pixel Extend, .
	// Parameters:
	//		pt---Specifies a POINT pt object(Value).
	void FillPixelExt(POINT pt);

public:


	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPaintWnd)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL


	// Implementation
public:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Paint Window, Destructor of class CFOPaintWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPaintWnd();

	// Generated message map functions
	//{{AFX_MSG(CFOPaintWnd)

	// when left button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	// when left button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	// when mouse move
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);

	// at cancel mode 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();

	// when erasing background
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	// when set cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// color
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crColor;	
	
	// mem device context
 
	// D C, This member specify CDC object.  
	CDC					m_memDC;
	
	// image size
 
	// Image, This member sets a CSize value.  
	CSize				m_szImage;		

	// pointer of bitmap
 
	// Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*			m_pBitmap;		

	// current tool
 
	// Current Tool, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nCurTool;		
	
	// size of drawitem
 
	// Draw Item, This member sets a CSize value.  
	CSize				m_szDrawItem;	

	// pen for drawing
 
	// Draw, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen				m_penDraw;	
	
	// pen 
 
	// Stretch, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen				m_penStretch;	

	// Grid line pen.
 
	// Grid, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen				m_penGrid;	
	
	// window rect
 
	// Window, This member sets a CRect value.  
	CRect				m_rcWindow;     

protected:

	// cursor of pen 
 
	// Pen, This member specify HCURSOR object.  
	HCURSOR				m_curPen;	
	
	// cursor of filling	
 
	// Fill, This member specify HCURSOR object.  
	HCURSOR				m_curFill;	
	
	// cursor of line
 
	// Line, This member specify HCURSOR object.  
	HCURSOR				m_curLine;     
	
	// cursor of rect
 
	// Rectangle, This member specify HCURSOR object.  
	HCURSOR				m_curRect;		

	// cursor of ellipse
 
	// Ellipse, This member specify HCURSOR object.  
	HCURSOR				m_curEllipse;	

	// cursor of roundrect
 
	// Round Rectangle, This member specify HCURSOR object.  
	HCURSOR				m_curRoundRect;	

	// cursor of color
 
	// Color, This member specify HCURSOR object.  
	HCURSOR				m_curColor;		
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPAINTWND_H__AA19F1D4_B867_11D5_A476_525400EA266C__INCLUDED_)
