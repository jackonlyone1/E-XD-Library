//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOROTATEACTION_H__6086C900_089F_11D6_A501_525400EA266C__INCLUDED_)
#define AFC_FOROTATEACTION_H__6086C900_089F_11D6_A501_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
#include "FOActionMacro.h"

///////////////////////////////////////////////////////////
// CFORotateAction -- all the shapes rotating with its own control handle
///////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFORotateAction class derived from CFOActionMacro
//      F O Rotate Action
//===========================================================================

class FO_EXT_CLASS CFORotateAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORotateAction---F O Rotate Action, Specifies a E-XD++ CFORotateAction object (Value).
	DECLARE_ACTION(CFORotateAction)

public:

	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rotate Action, Constructs a CFORotateAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFORotateAction(CFODataModel* pModel);
	// Attributes

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).  
	//		nAngle---nAngle, Specifies A integer value.
	virtual void AddShapes(CFODrawShapeList &list,int nAngle);

	// Attributes
protected:

    // a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

     // Declear	friend class CFOPCanvasCore 
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

///////////////////////////////////////////////////////////
// CFORotateExtendAction -- rotating only one shape
// with its own control handle
///////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFORotateExtendAction class derived from CFOAction
//      F O Rotate Extend Action
//===========================================================================

class FO_EXT_CLASS CFORotateExtendAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORotateExtendAction---F O Rotate Extend Action, Specifies a E-XD++ CFORotateExtendAction object (Value).
	DECLARE_ACTION(CFORotateExtendAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rotate Extend Action, Constructs a CFORotateExtendAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nAngle---nAngle, Specifies A integer value.
	CFORotateExtendAction(CFODataModel* pModel,CFODrawShape *pShape,int nAngle);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Rotate Extend Action, Destructor of class CFORotateExtendAction
	//		Returns A  value (Object).
	~CFORotateExtendAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Set shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFORotateExtendAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Gets the origin to be used for rotation. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Point, Returns the specified value.
	// Parameters:
	//		dX---dX, Specifies a double& dX object(Value).  
	//		dY---dY, Specifies a double& dY object(Value).
	void GetRotatePoint(double& dX, double& dY) const;
	
	// Sets the origin to be used for rotation. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rotate Point, Sets a specify value to current class CFORotateExtendAction
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	void SetRotatePoint(double dX, double dY);

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// Shape pointer.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	// Current rotate angle.
 
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nAngle;

	// X start point.
 
	// X Rotate, This member specify double object.  
	double				dXRotate;

	// Y start point.
 
	// Y Rotate, This member specify double object.  
	double				dYRotate;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFORotateExtendAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFORotateExtendAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////////
// CFONewRotateAction -- rotating only all the shapes
// with the same control handle
///////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFONewRotateAction class derived from CFOAction
//      F O New Rotate Action
//===========================================================================

class FO_EXT_CLASS CFONewRotateAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFONewRotateAction---F O New Rotate Action, Specifies a E-XD++ CFONewRotateAction object (Value).
	DECLARE_ACTION(CFONewRotateAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O New Rotate Action, Constructs a CFONewRotateAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&dOrgX---Org X, Specifies a const double &dOrgX object(Value).  
	//		&dOrgY---Org Y, Specifies a const double &dOrgY object(Value).  
	//		&nAngle---&nAngle, Specifies A integer value.
	CFONewRotateAction(CFODataModel* pModel,const CFODrawShapeList& list,
		const CFODrawShapeList& listCenter,
	const double &dOrgX,const double &dOrgY,const int &nAngle);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O New Rotate Action, Destructor of class CFONewRotateAction
	//		Returns A  value (Object).
	~CFONewRotateAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get total bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTotalSnapRect() const;

protected:

	// a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

	// a list of shape
 
	// Center Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listCenterShapes;

	// X start point.
 
	// X Rotate, This member specify double object.  
	double				dXRotate;

	// Y start point.
 
	// Y Rotate, This member specify double object.  
	double				dYRotate;

	// Current rotate angle.
 
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAngle;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFC_FOROTATEACTION_H__6086C900_089F_11D6_A501_525400EA266C__INCLUDED_)
