//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOANGLEEDITBOX_H__93991A6D_2F03_4FEA_92BD_BDFE2D6348E8__INCLUDED_)
#define AFX_FOANGLEEDITBOX_H__93991A6D_2F03_4FEA_92BD_BDFE2D6348E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOAngleEditBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOAngleEditBox window

#include "FOAngleWnd.h"

 
//===========================================================================
// Summary:
//     The CFOAngleEditBox class derived from CEdit
//      F O Angle Edit Box
//===========================================================================

class FO_EXT_CLASS CFOAngleEditBox : public CEdit
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Angle Edit Box, Constructs a CFOAngleEditBox object.
	//		Returns A  value (Object).
	CFOAngleEditBox();

// Attributes
public:
	// Attach to angle box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach To Angle Box, Attaches this object.
	// Parameters:
	//		*pBox---*pBox, A pointer to the CFOAngleWnd  or NULL if the call failed.
	void AttachToAngleBox(CFOAngleWnd *pBox);

	// Update angle box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Angle Box, Call this member function to update the object.
	// Parameters:
	//		*szText---*szText, A pointer to the TCHAR  or NULL if the call failed.
	void UpdateAngleBox(TCHAR *szText);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOAngleEditBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Angle Edit Box, Destructor of class CFOAngleEditBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAngleEditBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOAngleEditBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChange();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// The attached angle box control.
 
	// Angle Window, This member maintains a pointer to the object CFOAngleWnd.  
	CFOAngleWnd *m_pAngleWnd;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOANGLEEDITBOX_H__93991A6D_2F03_4FEA_92BD_BDFE2D6348E8__INCLUDED_)
