//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOCOLORDIALOG_H__2C04B373_E5F7_11D5_A4B9_525400EA266C__INCLUDED_)
#define AFX_FOCOLORDIALOG_H__2C04B373_E5F7_11D5_A4B9_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOColorDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOColorDialog dialog
#include "FOColorButton.h"
#include "FODropPaletteWnd.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOColorDialog class derived from CDialog
//      F O Color Dialog
//===========================================================================

class FO_EXT_CLASS CFOColorDialog : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Color Dialog, Constructs a CFOColorDialog object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOColorDialog(CWnd* pParent = NULL);   // standard constructor

	// Destructor.
	BOOL		mbPickNow;
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Color Dialog, Destructor of class CFOColorDialog
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOColorDialog();
// Dialog Data
	//{{AFX_DATA(CFOColorDialog)
	enum { IDD = IDD_FO_COLORPICKER };
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strValue;
 
	// Color, This member specify CStatic object.  
	CStatic	m_staticColor;
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Cursor.
	HCURSOR		m_curPick;

	
	// Be
	static BOOL s_beFore;
	// Color select wnd.
 
	// Color, This member specify E-XD++ CFODropPaletteWnd object.  
	CFODropPaletteWnd	m_wndColor;	

	// Color select button.
 
	// Color, This member specify E-XD++ CFOColorButton object.  
	CFOColorButton		m_btnColor;	

	// Idle
	static BOOL s_Idle;

	// set the select color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOColorDialog
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void	 SetColor(COLORREF cr)	{ crColor = cr; }

	// get the select color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetColor()				{ return crColor; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Palette, You construct a CFOColorDialog object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	// CreatePalette.
	virtual void CreatePalette(BOOL bRedraw = TRUE);

	// Color palette
 
	// Palette, This member specify CPalette object.  
	CPalette m_Palette;
	CFOImageButton	m_btnSelect;
protected:

	// Stop capture the mouse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stop Capture, Call this function to stop
	// This member function is also a virtual function, you can Override it if you need,
	virtual void StopCapture();		// Capture the mouse.

    // Copy specify string to windows clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy To Clipboard, Create a duplicate copy of this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	BOOL CopyToClipboard(CString strText);

protected:

	// Current color.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crColor;
	
	// Is capture state.
 
	// Capturing, This member sets TRUE if it is right.  
	BOOL		m_bCapturing;		

	// Blank icon.
 
	// Icon Blank, This member specify HICON object.  
	HICON		m_hIconBlank;

	// Picker icon.
 
	// Icon Picker, This member specify HICON object.  
	HICON		m_hIconPicker;

	// Picker cursor.
 
	// Cursor Picker, This member specify HCURSOR object.  
	HCURSOR		m_hCursorPicker;
	
	// Previous cursor.
 
	// Cursor Previous, This member specify HCURSOR object.  
	HCURSOR		m_hCursorPrev;	

	// Has palette or not.
 
	// Palette, This member sets TRUE if it is right.  
	BOOL		m_bPalette;			

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOColorDialog)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOColorDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	afx_msg void OnColorSelect();
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Color Custom, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoColorCustom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query New Palette, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL OnQueryNewPalette();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Palette Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		OnDestroy(---On Destroy(, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	// when select day -> OK
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Day O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT	OnSelectDayOK(WPARAM wParam, LPARAM lParam);

	// when slect custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Custom, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT	OnSelectCustom(WPARAM wParam, LPARAM lParam);

#if (_MSC_VER < 1300)
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#else
	afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#endif
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOCOLORDIALOG_H__2C04B373_E5F7_11D5_A4B9_525400EA266C__INCLUDED_)
