//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMoveCompAction.h: interface for the CFOMoveCompAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMOVECOMPACTION_H__3645F724_F20C_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOMOVECOMPACTION_H__3645F724_F20C_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOMoveCompAction -- action that defined for moving component.

 
//===========================================================================
// Summary:
//     The CFOMoveCompAction class derived from CFOAction
//      F O Move Component Action
//===========================================================================

class FO_EXT_CLASS CFOMoveCompAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveCompAction---F O Move Component Action, Specifies a E-XD++ CFOMoveCompAction object (Value).
	DECLARE_ACTION(CFOMoveCompAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Component Action, Constructs a CFOMoveCompAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		sizeOffset---sizeOffset, Specifies A CSize type value.
	CFOMoveCompAction(CFODataModel* pModel,CFODrawShape *pShape,CSize sizeOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Component Action, Destructor of class CFOMoveCompAction
	//		Returns A  value (Object).
	~CFOMoveCompAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveCompAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Get the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get current size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetCurrentSize()			{ return szOffset; }

	// Set new size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Size, Sets a specify value to current class CFOMoveCompAction
	// Parameters:
	//		sz---Specifies A CSize type value.
	void SetCurrentSize(CSize sz)   { szOffset = sz; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	// Offset size.
 
	// Offset, This member sets a CSize value.  
	CSize				szOffset;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOMoveCompAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveCompAction::GetShape()
{
	return m_pShape;
}


/////////////////////////////////////////////////////////////////////////////
// CFOPositionShapeAction -- shape position change action.

 
//===========================================================================
// Summary:
//     The CFOPositionShapeAction class derived from CFOAction
//      F O Position Shape Action
//===========================================================================

class FO_EXT_CLASS CFOPositionShapeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPositionShapeAction---F O Position Shape Action, Specifies a E-XD++ CFOPositionShapeAction object (Value).
	DECLARE_ACTION(CFOPositionShapeAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Position Shape Action, Constructs a CFOPositionShapeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&rcNew---&rcNew, Specifies A CRect type value.
	CFOPositionShapeAction(CFODataModel* pModel,CFODrawShape *pShape,const CRect &rcNew);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Position Shape Action, Destructor of class CFOPositionShapeAction
	//		Returns A  value (Object).
	~CFOPositionShapeAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPositionShapeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of the shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.

	// New position of the shape.
 
	// New, This member sets a CRect value.  
	CRect			m_rcNew;

	// Old position of the shape.
 
	// Old, This member sets a CRect value.  
	CRect			m_rcOld;
   

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOPositionShapeAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFOPositionShapeAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOMOVECOMPACTION_H__3645F724_F20C_11DD_A432_525400EA266C__INCLUDED_)
