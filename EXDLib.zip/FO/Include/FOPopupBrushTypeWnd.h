//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPOPUPBrushTypeWND_H__5B55AAC6_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FOPOPUPBrushTypeWND_H__5B55AAC6_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPopupBrushTypeWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPopupBrushTypeWnd window

#include "FOBrushTypeWnd.h"

 
//===========================================================================
// Summary:
//     The CFOPopupBrushTypeWnd class derived from CFOBrushTypeWnd
//      F O Popup Brush Type Window
//===========================================================================

class FO_EXT_CLASS CFOPopupBrushTypeWnd : public CFOBrushTypeWnd
{

	// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Popup Brush Type Window, Constructs a CFOPopupBrushTypeWnd object.
	//		Returns A  value (Object).
	CFOPopupBrushTypeWnd();


	// Attributes
public:

	// Create a new control.
	virtual BOOL Create(DWORD dwStyle,
			CRect &rect,
			CWnd *pParent,
			int nDefaultType = 1,
			CSize szPopup = CSize(300,200),
			CCreateContext *pContext = NULL);

	// Operations
public:


	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPopupBrushTypeWnd)
	//}}AFX_VIRTUAL


	// Implementation
public:

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Popup Brush Type Window, Destructor of class CFOPopupBrushTypeWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPopupBrushTypeWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPopupBrushTypeWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPOPUPBrushTypeWND_H__5B55AAC6_C753_11D5_A489_525400EA266C__INCLUDED_)
