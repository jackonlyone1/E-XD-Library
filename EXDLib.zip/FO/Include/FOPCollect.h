//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCOLLECT_H__C20CFBDC_3536_4D7E_BC1E_CEA1B0CCDBC7__INCLUDED_)
#define AFX_FOPCOLLECT_H__C20CFBDC_3536_4D7E_BC1E_CEA1B0CCDBC7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPCollect.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPCollect window

typedef void* PVOID;

#define FOPCONTAINER_MAXBLOCKSIZE      ((int)0x3FF0)
#define FOPCONTAINER_ENTRY_NOTFOUND    ((long)0xFFFF)

class FOPBlock;

/////////////////////////////////////////////////////////////////////////////////
//
// FOPContainer -- container for pointers, use this collect to store any pointers
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPContainer object, just call the constructor.
//      O P Container
//===========================================================================

class FO_EXT_CLASS FOPContainer
{
public:
	// Pointer of the first block.
 
	// First Block, This member maintains a pointer to the object FOPBlock.  
    FOPBlock*    m_pFirstBlock;

	// Pointer of the current block.
 
	// Current Block, This member maintains a pointer to the object FOPBlock.  
    FOPBlock*    m_pCurBlock;

	// Pointer of the last block.
 
	// Last Block, This member maintains a pointer to the object FOPBlock.  
    FOPBlock*    m_pLastBlock;

	// Index of current block.
 
	// Current Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int			 m_nCurIndex;

	// Block size.
 
	// Block Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int			 m_nBlockSize;

	// Init size of the container.
 
	// Initial Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int          m_nInitSize;

	// Resize number.
 
	// Total Re Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int          m_nTotalReSize;

	// Count of the data.
 
	// Count, Specify a A 32-bit signed integer.  
    long         m_nCount;

protected:
	// Insert new data to the container
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Insert, Do a event. 
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.  
	//		pBlock---pBlock, A pointer to the FOPBlock or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
    void        DoInsert( void* pData, FOPBlock* pBlock, int nIndex );

	// Remove data from the container
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove, Do a event. 
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pBlock---pBlock, A pointer to the FOPBlock or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
    void*       DoRemove( FOPBlock* pBlock, int nIndex );

	// Obtain the pointer of the object within the container
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Object, Do a event. 
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
    void*       DoGetObject( long nIndex ) const;

	// Get only nodes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Only Nodes, Do a event. 
	//		Returns a pointer to the object void*,or NULL if the call failed
    void**      DoGetOnlyNodes() const;

	// Obtain the ptr of the object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Pointer, Returns the specified value.
	//		Returns a pointer to the object void*,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
    void**      GetObjectPtr( long nIndex );

public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Container, Constructs a FOPContainer object.
	//		Returns A  value.  
	// Parameters:
	//		m_nBlockSize---Block Size, Specifies A integer value.  
	//		m_nInitSize---Initial Size, Specifies A integer value.  
	//		m_nTotalReSize---Total Re Size, Specifies A integer value.
                FOPContainer( int m_nBlockSize,
                           int m_nInitSize,
                           int m_nTotalReSize );
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Container, Constructs a FOPContainer object.
	//		Returns A  value.  
	// Parameters:
	//		nSize---nSize, Specifies A 32-bit long signed integer.
                FOPContainer( long nSize );

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Container, Constructs a FOPContainer object.
	//		Returns A  value.  
	// Parameters:
	//		rFOPContainer---F O P Container, Specifies a const FOPContainer& rFOPContainer object.
                FOPContainer( const FOPContainer& rFOPContainer );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Container, Destructor of class FOPContainer
	//		Returns A  value.
				~FOPContainer();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.
	// Insert new data.
    void        Insert( void* pData );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Insert new data to the container.
	// nIndex -- insert index.
    void        Insert( void* pData, long nIndex );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		pNew---pNew, A pointer to the void or NULL if the call failed.  
	//		pOld---pOld, A pointer to the void or NULL if the call failed.
	// Insert new data and replace the old data.
	// pNew -- new Insert data.
	// pOld -- Replace old data pointer.
    void        Insert( void* pNew, void* pOld );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object void,or NULL if the call failed
	// Remove data.
    void*       Remove();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Remove data.
	// nIndex -- index of the data.
    void*       Remove( long nIndex );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.
	// Remove data from the container.
	// p -- pointer of the data.
    void*       Remove( void* pData )   { return Remove( GetPos( pData ) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.
	// Replace data.
	// p -- replace data pointer.
    void*       Replace( void* pData );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Replace data.
	// p -- replace data pointer.
	// nIndex -- index of the data.
    void*       Replace( void* pData, long nIndex );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pNew---pNew, A pointer to the void or NULL if the call failed.  
	//		pOld---pOld, A pointer to the void or NULL if the call failed.
	// Replace data of the container.
	// pNew -- new data pointer.
	// pOld -- the old replace data pointer.
    void*       Replace( void* pNew, void* pOld )  { return Replace( pNew, GetPos( pOld ) ); }

	// Change the size of the container.
	// nNewSize -- new size of the container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class FOPContainer
	// Parameters:
	//		nNewSize---New Size, Specifies A 32-bit long signed integer.
    void        SetSize( long nNewSize );

	// Obtain the size of the container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns A 32-bit long signed integer.
    long        GetSize() const { return m_nCount; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Count, .
	//		Returns A 32-bit long signed integer.
	// Get count of data.
    long        Count() const { return m_nCount; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data,
    void        Clear();

	// Get current object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Object, Returns the specified value.
	//		Returns a pointer to the object void,or NULL if the call failed
    void*       GetCurObject() const;

	// Obtain the current position of the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.
    long        GetCurPos() const;

	// Obtain the data.
	// nIndex -- index of the data within the container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
    void*       GetObject( long nIndex ) const;

	// Obtain the data.
	// nIndex -- index of the data within the container.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
    void*       GetAt( long nIndex ) const;

	// Obtain the index of the data.
	// p -- the pointer of the data to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pData---pData, A pointer to the const void or NULL if the call failed.
    long        GetPos( const void* pData ) const;

	// Obtain the index of the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		pData---pData, A pointer to the const void or NULL if the call failed.  
	//		nStartIndex---Start Index, Specifies A 32-bit long signed integer.  
	//		bForward---bForward, Specifies A Boolean value.
    long        GetPos( const void* pData, long nStartIndex,
                        BOOL bForward = TRUE ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Seek, .
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.
	// Seek the data by a specify index.
    void*       Seek( long nIndex );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Seek, .
	//		Returns a pointer to the object void,or NULL if the call failed  
	// Parameters:
	//		pData---pData, A pointer to the void or NULL if the call failed.
	// Seek to the data.
    void*       Seek( void* pData )		{ return Seek( GetPos( pData ) ); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// First, .
	//		Returns a pointer to the object void,or NULL if the call failed
	// Goto the first position.
    void*       First();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Last, .
	//		Returns a pointer to the object void,or NULL if the call failed
	// Goto the last position.
    void*       Last();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Next, .
	//		Returns a pointer to the object void,or NULL if the call failed
	// Goto the next position.
    void*       Next();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Previous, .
	//		Returns a pointer to the object void,or NULL if the call failed
	// Goto the previous position.
    void*       Prev();


	BOOL Find(CObject *pObj);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPContainer&  operator value.  
	// Parameters:
	//		rFOPContainer---F O P Container, Specifies a const FOPContainer& rFOPContainer object.
	// Operator =
    FOPContainer&  operator =( const FOPContainer& rFOPContainer );

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL        operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPContainer---F O P Container, Specifies a const FOPContainer& rFOPContainer object.
	// Operator == 
    BOOL        operator ==( const FOPContainer& rFOPContainer ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL        operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPContainer---F O P Container, Specifies a const FOPContainer& rFOPContainer object.
	// Operator !=
    BOOL        operator !=( const FOPContainer& rFOPContainer ) const
                    { return !(FOPContainer::operator==( rFOPContainer )); }
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPList -- list of pointers.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPList class derived from FOPContainer
//      O P List
//===========================================================================

class FO_EXT_CLASS FOPList : public FOPContainer
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P List, Constructs a FOPList object.
	//		Returns A  value.  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	FOPList(int nInit = 16, int nTotal = 16) : FOPContainer(1024, nInit, nTotal)	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P List, Constructs a FOPList object.
	//		Returns A  value.  
	// Parameters:
	//		nBlockSize---Block Size, Specifies A integer value.  
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	FOPList(int nBlockSize, int nInit, int nTotal) : FOPContainer(nBlockSize, nInit, nTotal)	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P List, Constructs a FOPList object.
	//		Returns A  value.  
	// Parameters:
	//		rFOPList---F O P List, Specifies a const FOPList& rFOPList object.
	FOPList(const FOPList& rFOPList) : FOPContainer(rFOPList)	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPList& operator value.  
	// Parameters:
	//		rFOPList---F O P List, Specifies a const FOPList& rFOPList object.
	FOPList& operator =(const FOPList& rFOPList)	{	FOPContainer::operator = (rFOPList); return *this;	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPList---F O P List, Specifies a const FOPList& rFOPList object.
	// Operator ==.
	BOOL operator ==(const FOPList& rFOPList) const	{	return FOPContainer::operator == (rFOPList);	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOL operatorvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rFOPList---F O P List, Specifies a const FOPList& rFOPList object.
	// Operator !=
	BOOL operator !=(const FOPList& rFOPList) const	{	return FOPContainer::operator != (rFOPList);	}
};

/////////////////////////////////////////////////////////////////////////////////
//
// Sort the container
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a FOPContainerSorter object, just call the constructor.
//      O P Container Sorter
//===========================================================================

class FO_EXT_CLASS FOPContainerSorter 
{
protected:
	// Container
 
	// Cont, This member specify FOPContainer& object.  
	FOPContainer& aCont;

protected:
	// Sort sub long value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Imp Child Sort, .
	// Parameters:
	//		nL---nL, Specifies A 32-bit long signed integer.  
	//		nR---nR, Specifies A 32-bit long signed integer.
	void ImpSubSort(long nL, long nR) const;

public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Container Sorter, Constructs a FOPContainerSorter object.
	//		Returns A  value.  
	// Parameters:
	//		rNewCont---New Cont, Specifies a FOPContainer& rNewCont object.
	FOPContainerSorter(FOPContainer& rNewCont): aCont(rNewCont)		{}

	// Do sort action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Sort, Do a event. 
	// Parameters:
	//		a---Specifies A 32-bit LONG signed integer.  
	//		b---Specifies A 32-bit LONG signed integer.
	void DoSort(ULONG a=0, ULONG b = 0xFFFF) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pElem1---pElem1, A pointer to the const void or NULL if the call failed.  
	//		const---A pointer to the const void or NULL if the call failed.
	// Compare virtual method,it must be override.
	virtual int Compare(const void* pElem1, const void* pElem2) const=0;
};

/////////////////////////////////////////////////////////////////////////////////
//
// DECLARE_LIST Macro
/////////////////////////////////////////////////////////////////////////////////

#define FOP_DECLARE_LIST( FOPClassName, Type )  							\
class FO_EXT_CLASS FOPClassName : private FOPList							\
{   																		\
public: 																	\
		using FOPList::Clear; 												\
		using FOPList::Count; 												\
		using FOPList::GetCurPos; 											\
																			\
				FOPClassName( int nInit = 16,   							\
						   int nTotal = 16 ) : 								\
					FOPList( nInit, nTotal ) {}  							\
				FOPClassName( int nBlockSize, int nInit,					\
						   int nTotal ) :  									\
					FOPList( nBlockSize, nInit, nTotal ) {} 				\
				FOPClassName( const FOPClassName& rFOPClassName ) : 		\
					FOPList( rFOPClassName ) {} 							\
																			\
	void		Insert( Type pData, long nIndex )  							\
					{ FOPList::Insert( (void*)pData, nIndex ); }			\
	void		Insert2( Type pData )										\
					{ FOPList::Insert( (void*)pData ); }					\
	void		Insert3( Type pNew, Type pOld )  							\
					{ FOPList::Insert( (void*)pNew, (void*)pOld ); }		\
	Type		Remove()													\
					{ return (Type)FOPList::Remove(); } 					\
	Type		Remove2( long nIndex )  									\
					{ return (Type)FOPList::Remove( nIndex ); } 			\
	Type		Remove3( Type pData )										\
					{ return (Type)FOPList::Remove( (void*)pData ); }   	\
	Type		Replace( Type pData )   									\
					{ return (Type)FOPList::Replace( (void*)pData ); }  	\
	Type		Replace2( Type pData, long nIndex ) 						\
					{ return (Type)FOPList::Replace( (void*)pData, nIndex ); }	\
	Type		Replace3( Type pNew, Type pOld ) 							\
					{ return (Type)FOPList::Replace( (void*)pNew,   		\
												  (void*)pOld ); }  		\
																			\
	Type		GetCurObject() const										\
					{ return (Type)FOPList::GetCurObject(); }   			\
	Type		GetObject( long nIndex ) const 								\
					{ return (Type)FOPList::GetObject( nIndex ); }  		\
	long   		GetPos( const Type pData ) const							\
					{ return FOPList::GetPos( (const void*)pData ); }   	\
	long   		GetPos( const Type pData, long nStartIndex,					\
						BOOL bForward = TRUE ) const						\
					{ return FOPList::GetPos( (const void*)pData,			\
								nStartIndex,bForward ); }					\
																			\
	Type		Seek( long nIndex )											\
					{ return (Type)FOPList::Seek( nIndex ); }   			\
	Type		Seek( void* pData )											\
					{ return (Type)FOPList::Seek( pData ); }				\
	Type		First() 		{ return (Type)FOPList::First(); }  		\
	Type		Last()  		{ return (Type)FOPList::Last(); }   		\
	Type		Next()  		{ return (Type)FOPList::Next(); }   		\
	Type		Prev()  		{ return (Type)FOPList::Prev(); }   		\
																			\
	FOPClassName&  operator =( const FOPClassName& rFOPClassName )  		\
					{ FOPList::operator =( rFOPClassName ); return *this; } \
																			\
	BOOL		operator ==( const FOPClassName& rFOPList ) const   		\
					{ return FOPList::operator ==( rFOPList ); }			\
	BOOL		operator !=( const FOPClassName& rFOPList ) const   		\
					{ return FOPList::operator !=( rFOPList ); }			\
};

// Guid of ptr
typedef struct
{
    unsigned long	Data1;
    unsigned short	Data2;
    unsigned short	Data3;
    unsigned char	Data4[8];
} FOP_ID;

//////////////////////////////////////////////////////////////
// CFOPCachePtrList -- cache pointer.

 
//===========================================================================
// Summary:
//     The CFOPCachePtrList class derived from CObject
//      F O P Cache Pointer List
//===========================================================================

class FO_EXT_CLASS CFOPCachePtrList: public CObject
{
protected:
	
	// Ptr list
	typedef struct FOPPtrListTag
	{
		BOOL    isUsed;
		LPVOID	pointer;
		long	param;
		FOP_ID	id;
	}FOPPtrList;

	// Array of ptr
 
	// Pointer Array, This member maintains a pointer to the object FOPPtrList.  
	FOPPtrList * m_PtrArray;

 
	// Elem Maximize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_ElemMax;
 
	// Current Used, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_CurUsed;

	// function is called when maximum allowed items
	// is reached.  It is called in attempt to allocate
	// additional memory required.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Space, Adds an object to the specify list.
	//		Returns a int type value.
	int AddNewSpace();

public:
	// construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Cache Pointer List, Constructs a CFOPCachePtrList object.
	//		Returns A  value.
	CFOPCachePtrList();

	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Cache Pointer List, Destructor of class CFOPCachePtrList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CFOPCachePtrList();

public:
	// called to remove individual pointer from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Pointer, Deletes the given object.
	//		Returns a int type value.  
	// Parameters:
	//		index---Specifies A integer value.
	int DeletePtr(int index);

	// called to remove all of the items in the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete All, Deletes the given object.
	//		Returns a int type value.
	int DeleteAll();

	// is called to retrieve the number of items in the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount();

	// called to receive current maximum number of 
	// allowed items in the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Count, Returns the specified value.
	//		Returns a int type value.
	int GetMaxCount();

	// function is called to add a generic (void) pointer
	// to the link list.  The list will be created if
	// it does not contain any elements
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pointer, Adds an object to the specify list.
	//		Returns a int type value.  
	// Parameters:
	//		*ptr---A pointer to the void  or NULL if the call failed.  
	//		param---Specifies A 32-bit long signed integer.  
	//		*id---A pointer to the FOP_ID  or NULL if the call failed.
	int AddPtr(void *ptr,long param = 0,FOP_ID *id = NULL);
	
	// called to receive the pointer stored
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pointer, Returns the specified value.
	//		Returns A LPVOID value.  
	// Parameters:
	//		index---Specifies A integer value.
	LPVOID GetPtr(int index);

	// is called to obtain the current value of the param.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Parameter, Returns the specified value.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		index---Specifies A integer value.
	long GetParam(int index);

	// Obtain guid of ptr
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	//		Returns a pointer to the object FOP_ID,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	FOP_ID* GetID(int index);

	// called to retrieve index of given pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pointer Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		ptr---A pointer to the void  or NULL if the call failed.
	int GetPtrIndex(void * ptr);

	// function is called to update the 'param' portion
	// of the list item.  The 'param' is used to store
	// information on how many times this pointer is
	// referenced.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Parameter, Call this member function to update the object.
	//		Returns a int type value.  
	// Parameters:
	//		index---Specifies A integer value.  
	//		param---Specifies A 32-bit long signed integer.
	int UpdateParam(int index,long param);

};

/////////////////////////////////////////////////////////////////////////////


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCOLLECT_H__C20CFBDC_3536_4D7E_BC1E_CEA1B0CCDBC7__INCLUDED_)
