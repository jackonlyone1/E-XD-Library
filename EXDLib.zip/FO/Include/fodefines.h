//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODefines.h: Defines of E-XD++ Library class.
//
//////////////////////////////////////////////////////////////////////
#ifndef _FO_IDDEFINES
#define _FO_IDDEFINES

/********************************************************************
// Action ID.
//
*********************************************************************/
#define 	FO_ACTION_BASE					0x0000
#define		FO_ACTION_ADDSHAPE				FO_ACTION_BASE+1	//CFOAddCompAction
#define		FO_ACTION_ADDSHAPES				FO_ACTION_BASE+2	//CFOAddCompsAction
#define		FO_ACTION_REMOVESHAPE			FO_ACTION_BASE+3	//CFORemoveCompAction
#define		FO_ACTION_REMOVESHAPES			FO_ACTION_BASE+4	//CFORemoveCompsAction
#define		FO_ACTION_MOVESHAPE				FO_ACTION_BASE+5	//CFOMoveCompAction
#define		FO_ACTION_MOVESHAPES			FO_ACTION_BASE+6	//CFOMoveCompsAction
#define		FO_ACTION_SCALESHAPE			FO_ACTION_BASE+7	//CFOScaleAction
#define		FO_ACTION_ALIGNSHAPES			FO_ACTION_BASE+8	//CFOAlignAction
#define		FO_ACTION_SIZESHAPES			FO_ACTION_BASE+9	//CFOSizeAction
#define		FO_ACTION_SPACESHAPES			FO_ACTION_BASE+10   //CFOSpacingAction
#define		FO_ACTION_FORMSIZECHANGE		FO_ACTION_BASE+11	//CFOFormSizeAction
#define		FO_ACTION_FORM_POS_NAME_CHANGE	FO_ACTION_BASE+12	//CFOFormSizeAndNameAction
#define		FO_ACTION_SHAPE_ORDER_SINGLE	FO_ACTION_BASE+13	//CFOOrderSingleAction
#define		FO_ACTION_SHAPE_ORDER			FO_ACTION_BASE+14	//CFOOrderAction
#define		FO_ACTION_SHAPE_FORWARD			FO_ACTION_BASE+15	//None used.
#define		FO_ACTION_SINGLE_SHAPE			FO_ACTION_BASE+16	//Single prop change action and None used now.
#define		FO_ACTION_MULTI_SHAPE			FO_ACTION_BASE+17	//Multi prop change action and None used now.
#define		FO_ACTION_SIZE_SPOT				FO_ACTION_BASE+18	//CFOSizeSpotAction
#define		FO_ACTION_BACK_TEXT_COLOR_CHANGE FO_ACTION_BASE+19	//CFOColorChangeAction
#define		FO_ACTION_FORM_COLOR_CHANGE		FO_ACTION_BASE+20	//CFOFormColorChangeAction
#define		FO_ACTION_GROUP					FO_ACTION_BASE+21	//CFOGroupAction
#define		FO_ACTION_UNGROUP				FO_ACTION_BASE+22	//CFOUnGroupAction
#define		FO_ACTION_SIZE_PORT				FO_ACTION_BASE+23	//CFOSizePortAction
#define		FO_ACTION_ADDLINK				FO_ACTION_BASE+24	//CFOAddLinkAction
#define		FO_ACTION_REMOVELINK			FO_ACTION_BASE+25	//CFORemoveLinkAction
#define		FO_ACTION_EXTEND_SCALESHAPE		FO_ACTION_BASE+26	//CFOScaleExtendAction
#define		FO_ACTION_EXTEND_ROTATESHAPE	FO_ACTION_BASE+27	//CFORotateExtendAction
#define		FO_ACTION_ROTATESHAPE			FO_ACTION_BASE+28	//CFORotateAction
#define		FO_ACTION_ADDSPOT				FO_ACTION_BASE+29	//CFOAddSpotAction
#define		FO_ACTION_REMOVESPOT			FO_ACTION_BASE+30	//CFORemoveSpotAction
#define		FO_DIRECT_MACRO_ACTION			FO_ACTION_BASE+33	//CFODirectActionMacro
#define		FO_ACTION_MULTI_UNGROUP			FO_ACTION_BASE+34   //CFOMultiUnGroupAction
#define		FO_ACTION_MULTI_GROUP			FO_ACTION_BASE+35   //CFOMultiGroupAction
#define		FO_ACTION_MOVE_ANCHOR			FO_ACTION_BASE+36   //CFOMoveAnchorAction
#define		FO_ACTION_MOVE_EXTANCHOR		FO_ACTION_BASE+37	//CFOMoveExtAnchorAction

#define		FO_SHAPE_ACTION_BOOL			FO_ACTION_BASE+38	//CFOShapeBoolAction
#define		FO_SHAPE_ACTION_INT				FO_ACTION_BASE+39	//CFOShapeIntAction
#define		FO_SHAPE_ACTION_STRING			FO_ACTION_BASE+40	//CFOShapeStringAction
#define		FO_SHAPE_ACTION_FLOAT			FO_ACTION_BASE+41	//CFOShapeFloatAction
#define		FO_SHAPE_ACTION_DOUBLE			FO_ACTION_BASE+42	//CFOShapeDoubleAction
#define		FO_SHAPE_ACTION_DWORD			FO_ACTION_BASE+43	//CFOShapeDWordAction
#define		FO_SHAPE_ACTION_DATETIME		FO_ACTION_BASE+44	//CFOShapeDateTimeAction
#define		FO_SHAPE_ACTION_COLORREF		FO_ACTION_BASE+45	//CFOShapeColorAction

#define		FO_ACTION_BREAK_LINK			FO_ACTION_BASE+46	//CFOBreakLinkAction
#define		FO_ACTION_MOVE_THIRDANCHOR		FO_ACTION_BASE+47	//CFOMoveThirdAnchorAction
#define		FO_ACTION_MOVE_FOURANCHOR		FO_ACTION_BASE+48	//CFOMoveFourAnchorAction
#define		FO_ACTION_MOVE_FIVEANCHOR		FO_ACTION_BASE+49	//CFOMoveFiveAnchorAction

#define		FO_ACTION_SKEWX_ACTION			FO_ACTION_BASE+50	//CFOPSkewXAction
#define		FO_ACTION_SKEWY_ACTION			FO_ACTION_BASE+51	//CFOPSkewYAction

#define		FOP_POSITION_SHAPE_ACTION		FO_ACTION_BASE+52	//CFOPositionShapeAction

#define		FO_MULTI_SHAPE_PROP_ACTION		FO_ACTION_BASE+55	//CFOMultiShapePropAction
#define		FO_ACTION_SCALEMULTISHAPE		FO_ACTION_BASE+56	//CFONewMultiScaleAction
#define		FO_ACTION_ROTATEMULTISHAPE		FO_ACTION_BASE+57	//CFONewScaleAction
#define		FO_ACTION_MIRRORMULTISHAPE		FO_ACTION_BASE+58	//CFOMirrorShapesAction

#define		FO_MODEL_ACTION_BOOL			FO_ACTION_BASE+60	//CFOModelBoolAction
#define		FO_MODEL_ACTION_INT				FO_ACTION_BASE+61	//CFOModelIntAction
#define		FO_MODEL_ACTION_STRING			FO_ACTION_BASE+62	//CFOModelStringAction
#define		FO_MODEL_ACTION_FLOAT			FO_ACTION_BASE+63	//CFOModelFloatAction
#define		FO_MODEL_ACTION_DOUBLE			FO_ACTION_BASE+64	//CFOModelDoubleAction
#define		FO_MODEL_ACTION_DWORD			FO_ACTION_BASE+65	//CFOModelDWordAction
#define		FO_MODEL_ACTION_DATETIME		FO_ACTION_BASE+66	//CFOModelDateTimeAction
#define		FO_MODEL_ACTION_COLORREF		FO_ACTION_BASE+67	//CFOModelColorAction
#define		FO_ACTION_MOVE_CENTERANCHOR		FO_ACTION_BASE+68	//CFOMoveCenterAnchorAction
#define		FO_ACTION_MOVE_TEXTANCHOR		FO_ACTION_BASE+69	//CFOMoveTextAnchorAction

#define		FO_MULTI_MODEL_PROP_ACTION		FO_ACTION_BASE+70	//CFOMultiModelPropAction

#define		FOP_ADD_LAYER					FO_ACTION_BASE+80	//CFOPAddLayerAction
#define		FOP_REMOVE_LAYER				FO_ACTION_BASE+81	//CFORemoveLayerAction
#define		FOP_CHANGE_LAYER				FO_ACTION_BASE+82	//CFOPChangeLayerAction
#define		FOP_MOVE_LAYER					FO_ACTION_BASE+83	//CFOPMoveLayerAction
#define		FOP_RENAME_LAYER				FO_ACTION_BASE+84	//CFOPRenameLayerAction
#define		FOP_GEO_CHANGE					FO_ACTION_BASE+85   //CFOGeoAction
#define		FOP_SHAPE_ORDER_NUM				FO_ACTION_BASE+86	//CFOChangeOrdNum
#define		FOP_SHAPE_EXCHGE_ORDER_NUM		FO_ACTION_BASE+87	//CFOExChangeOrdNum

#define		FO_ACTION_ADDSHAPES_BACK		FO_ACTION_BASE+88	//CFOAddShapesToBackAction
#define		FO_ACTION_REMOVESHAPES_BACK		FO_ACTION_BASE+89	//CFORemoveShapesFromBackAction
#define		FO_ACTION_EXPANDSHAPE			FO_ACTION_BASE+90	//CFOPHitExpandAction
#define		FO_ACTION_COLLECTSHAPE			FO_ACTION_BASE+91	//CFOPHitCollectAction
#define		FO_ACTION_EXPAND_ALLSHAPE		FO_ACTION_BASE+92	//CFOPHitExpandAllAction
#define		FO_ACTION_COLLECT_ALLSHAPE		FO_ACTION_BASE+93	//CFOPHitCollectAllAction
#define		FO_ACTION_SIZE_CENTERSPOT		FO_ACTION_BASE+94	//CFOSizeCenterSpotAction

#define		FO_ACTION_ADDNEW_PORT			FO_ACTION_BASE+95	//CFOAddPortAction
#define		FO_ACTION_REMOVE_PORT			FO_ACTION_BASE+96	//CFORemovePortAction

#define		FO_ACTION_ADDSHAPES_COMPOSITE		FO_ACTION_BASE+97	//CFOAddShapesToCompositeAction
#define		FO_ACTION_REMOVESHAPES_COMPOSITE	FO_ACTION_BASE+98	//CFORemoveShapesFromCompositeAction
#define		FO_ACTION_LINKLAYOUT				FO_ACTION_BASE+99	//CFOPLinkAutoLayoutStateAction
#define		FOP_TABLE_DATA_CHANGE				FO_ACTION_BASE+100   //CFOPTableKeyDataAction
#define		FO_ACTION_TABLE_TEXT_CHANGE			FO_ACTION_BASE+101	 //CFOTableCellTextChangeAction

#define		FO_ACTION_GEO_VISIOANCHOR			FO_ACTION_BASE+102	//CFOMoveVisioGeoAction
#define		FO_ACTION_MOVE_VISIOANCHOR			FO_ACTION_BASE+103	//CFOMoveVisioHandleAction
#define		FO_ACTION_BREAK_THIRD_PORT			FO_ACTION_BASE+104	//CFOBreakThirdPortAction

#define		FO_ACTION_BREAK_HEAD_LINK			FO_ACTION_BASE+105	//CFOBreakLinkHeadAction
#define		FO_ACTION_MOVE_USERANCHOR			FO_ACTION_BASE+106	//CFOMoveUserAnchorAction
#define		FO_ACTION_ADD_USERPOINT				FO_ACTION_BASE+107	//CFOAddUserPointAction
#define		FO_ACTION_REMOVE_USERPOINT			FO_ACTION_BASE+108	//CFORemoveUserPointAction

#define		FOP_SDR_TABLE_CHANGE				FO_ACTION_BASE+109   //CFOPSdrTableGeoAction
#define		FO_ACTION_SDR_TABLE_TEXT_CHANGE		FO_ACTION_BASE+110	 //CFOSdrTableCellTextAction
#define		FOP_NEW_GEO_CHANGE					FO_ACTION_BASE+111	//CFONewGeoAction

// Custom action.
// Use the following ID to start your own action.
#define		FO_ACTION_CUSTOM					FO_ACTION_BASE+200    // The start value of your own customize action.


/********************************************************************
// Properties ID.
//
*********************************************************************/
#define FO_BASE_PROP_ID						5000
#define FO_CAPTION_PROP_ID					FO_BASE_PROP_ID			// CFOCaptionProperties
#define FO_DEFAULT_PROP_ID					FO_BASE_PROP_ID + 1		// CFOFillProperties
#define FO_EXTA_PROP_ID						FO_BASE_PROP_ID + 2		// CFOExtCompProperties
#define FO_EXT_IMAGE_PROP_ID				FO_BASE_PROP_ID + 3     // CFOImageExtProp
#define FO_EXT_FONTWORK_PROP_ID				FO_BASE_PROP_ID + 4     // CFOFontworkExtProp
#define FO_EXT_FONT_PROP_ID					FO_BASE_PROP_ID + 8		// CFOFontProperties
#define FO_EXT_EVENT_PROP_ID				FO_BASE_PROP_ID + 9		// CFOEventProperties
#define FO_EXT_SHADOW_PROP_ID				FO_BASE_PROP_ID + 11	// CFOShadowProperties
#define FO_EXT_LINE_PROP_ID					FO_BASE_PROP_ID + 12	// CFOLineProperties
#define FO_EXT_FLAT_PROP_ID					FO_BASE_PROP_ID + 13	// CFOFlatProperties
#define FO_EXT_NAME_PROP_ID					FO_BASE_PROP_ID + 14	// CFONameProperties
#define FO_EXT_TRANSPARENT_PROP_ID			FO_BASE_PROP_ID + 15	// CFOTransparentProperties
#define FO_EXT_TOOLTIP_PROP_ID				FO_BASE_PROP_ID + 16	// CFOToolTipProperties
#define FO_EXT_CURSOR_PROP_ID				FO_BASE_PROP_ID + 17	// CFOCursorProperties
  
#define FO_DEFAULT_FORM_PROP_ID				FO_BASE_PROP_ID + 20	// CFOFormProperties
#define FO_DEFAULT_PAGE_PROP_ID				FO_BASE_PROP_ID + 30	// CFOPageProperties

// User define properties start ID.
#define FO_CUSTOM_PROP_ID					FO_BASE_PROP_ID + 10000 // The start property value ID of your own customize property value


/********************************************************************
// Shape ID.
//
*********************************************************************/
#define FO_SHAPE_BASE						0
#define	FO_COMP_NONE						0
#define FO_COMP_STATICRECT					FO_SHAPE_BASE+1		//CFOStaticRectShape
#define FO_COMP_STATIC						FO_SHAPE_BASE+2		//CFOStaticShape
#define FO_COMP_EDITBOX						FO_SHAPE_BASE+3		//CFOEditBoxShape
#define FO_COMP_FRAME						FO_SHAPE_BASE+4		//CFOFrameShape
#define FO_COMP_BUTTON						FO_SHAPE_BASE+5		//CFOButtonShape
#define FO_COMP_CHECKBOX					FO_SHAPE_BASE+6		//CFOCheckShape
#define FO_COMP_RADIO						FO_SHAPE_BASE+7		//CFORadioShape
#define FO_COMP_COMBOBOX					FO_SHAPE_BASE+8		//CFOComboBoxShape
#define FO_COMP_LISTBOX						FO_SHAPE_BASE+9		//CFOListBoxShape
#define FO_COMP_HORSCROLL					FO_SHAPE_BASE+10	//CFOHorzScrollBarShape
#define FO_COMP_VERSCROLL					FO_SHAPE_BASE+11	//CFOVertScrollBarShape
#define FO_COMP_SPINEDIT					FO_SHAPE_BASE+12	//CFOSpinEditShape
#define FO_COMP_PROGRESS					FO_SHAPE_BASE+13	//CFOProgressCtrlShape
#define FO_COMP_SLIDER						FO_SHAPE_BASE+14	//CFOSliderShape
#define FO_COMP_LISTCTRL					FO_SHAPE_BASE+15	//CFOListCtrlShape
#define FO_COMP_TAB							FO_SHAPE_BASE+16	//CFOTabShape
#define FO_COMP_CALENDAR					FO_SHAPE_BASE+17	//CFOCalendarShape
#define FO_COMP_SEPARATOR					FO_SHAPE_BASE+18	//CFOSeparatorShape
#define FO_COMP_ROUNDBUTTON					FO_SHAPE_BASE+19	//CFORoundButtonShape
#define FO_COMP_MARQUEE						FO_SHAPE_BASE+20	//CFOMarqueeShape
#define FO_COMP_SELECTEDIT					FO_SHAPE_BASE+21	//CFOEditWithButtonShape
#define FO_COMP_IMAGE						FO_SHAPE_BASE+22	//CFOImageShape
#define FO_COMP_ELLIPSE2					FO_SHAPE_BASE+23	//CFOEllipseShape2
#define FO_COMP_LINE						FO_SHAPE_BASE+24	//CFOLineShape
#define FO_COMP_ARROWLINE					FO_SHAPE_BASE+25	//CFOLineShape with an arrow
#define FO_COMP_POLYLINE					FO_SHAPE_BASE+26	//CFOLineShape with multi points.
#define FO_COMP_POLYGON						FO_SHAPE_BASE+27	//CFOPolygonShape
#define FO_COMP_ROUND						FO_SHAPE_BASE+28	//CFOBezierLineShape
#define FO_COMP_CLOSEBEZIER					FO_SHAPE_BASE+29	//CFOCloseBezierShape
#define FO_COMP_RECTANGLE					FO_SHAPE_BASE+30	//CFORectShape
#define FO_COMP_LINKLABEL					FO_SHAPE_BASE+31	//None used.
#define FO_COMP_HYLINK						FO_SHAPE_BASE+32	//CFOHyLinkShape
#define FO_COMP_WMFIMAGE					FO_SHAPE_BASE+33	//CFOWMFShape
#define FO_COMP_COMPOSITE					FO_SHAPE_BASE+34	//CFOCompositeShape
#define FO_COMP_EMFIMAGE					FO_SHAPE_BASE+35	//CFOEMFShape
#define FO_COMP_ARROWBEZIERLINE				FO_SHAPE_BASE+36	//CFOLineShape with an arrow
#define FO_COMP_FREELINE					FO_SHAPE_BASE+37	//CFOFreeLineShape
#define FO_COMP_FREECLOSELINE				FO_SHAPE_BASE+38	//CFOPolygonShape
#define FO_COMP_CROSSLINE					FO_SHAPE_BASE+39	//CFOLineShape with an arrow
#define FO_COMP_ROUNDRECT					FO_SHAPE_BASE+40    //CFOPNewRoundRectShape
#define FO_COMP_DIMLINE 					FO_SHAPE_BASE+41    //CFODimLineShape
#define FO_COMP_GRID						FO_SHAPE_BASE+42	//CFOGridShape
#define FO_COMP_MASKEDIT					FO_SHAPE_BASE+43	//CFOMaskEditShape
#define FO_COMP_PASSWORD					FO_SHAPE_BASE+44	//CFOPasswordShape
#define FO_COMP_TABCOMBOBOX					FO_SHAPE_BASE+45	//CFOTabbedComboShape
#define FO_COMP_DATETIME					FO_SHAPE_BASE+46	//CFODateTimeShape
#define FO_COMP_ARCLINE						FO_SHAPE_BASE+47	//CFOPArcShape
#define FO_COMP_PIE							FO_SHAPE_BASE+48	//CFOPPieShape
#define FO_COMP_CHORD						FO_SHAPE_BASE+49	//CFOPChordShape
#define FO_COMP_SYSTEM						FO_SHAPE_BASE+50	//Saved id(from 50 to 80) Currently 71

#define FO_COMP_ARC2						FO_SHAPE_BASE+81	//CFOPArcShape2
#define FO_COMP_MENUEDIT					FO_SHAPE_BASE+82    //CFODropMenuEditShape
#define FO_COMP_PATH						FO_SHAPE_BASE+83	//CFOPathShape
#define FO_COMP_CAPTION						FO_SHAPE_BASE+84	//CFOCaptionShape
#define FOP_ROUND_CALLOUT					FO_SHAPE_BASE+85	//CFOPRoundCalloutShape
#define FOP_RECT_CALLOUT					FO_SHAPE_BASE+86	//CFOPRectCalloutShape
#define FOP_CLOUD_CALLOUT					FO_SHAPE_BASE+87	//CFOPCloudCalloutShape

#define FO_COMP_GROUP						FO_SHAPE_BASE+89	//CFOGroupShape
#define	FO_COMP_PORT						FO_SHAPE_BASE+90	//CFOPortShape
#define	FO_COMP_LINK						FO_SHAPE_BASE+91	//CFOLinkShape
#define FO_COMP_UPRIGHTLINK					FO_SHAPE_BASE+92	//CFOUpRightLinkShape
#define FO_COMP_CORNERLINK					FO_SHAPE_BASE+93	//CFOCornerLinkShape
#define FO_COMP_BEZIERLINK					FO_SHAPE_BASE+94	//CFOBezierLinkShape
#define FO_COMP_XNDATETIME					FO_SHAPE_BASE+95	//CFOXNDateTimeShape

#define FO_COMP_CHECKLISTBOX				FO_SHAPE_BASE+96	//CFOCheckListBoxShape
#define FO_COMP_CHECKCOMBOBOX				FO_SHAPE_BASE+97	//CFOCheckComboShape
#define FO_COMP_ANIMATETEXT					FO_SHAPE_BASE+98	//CFOPAnimateTextShape
#define FO_COMP_EXTCOMBOSHAPE				FO_SHAPE_BASE+99	//CFOPExtendComboShape
#define FO_COMP_EXTLISTBOXSHAPE				FO_SHAPE_BASE+100	//CFOPExtendListBoxShape

#define FOP_HORZ_DIMLINE					FO_SHAPE_BASE+201	//CFOPHorzDimLineShape
#define FOP_VERT_DIMLINE					FO_SHAPE_BASE+202	//CFOPVertDimLineShape
#define FOP_RADIUS_DIMLINE					FO_SHAPE_BASE+203	//CFOPRadiusDimLineShape
#define FOP_EXTEND_LINE						FO_SHAPE_BASE+204	//CFOPExtLineShape
#define FOP_COMP_NEW_GRID					FO_SHAPE_BASE+205	//CFOPNewGridShape
#define FOP_NUMBER_EDITSHAPE				FO_SHAPE_BASE+206	//CFONumberEditShape
#define FOP_COMP_AUTOFONTTEXT				FO_SHAPE_BASE+207	//CFOAutoFontTextShape
#define FOP_COMP_TURNCORNERLINK				FO_SHAPE_BASE+208	//CFOTurnCornerLinkShape
#define FOP_COMP_BREAKCENTERLINK			FO_SHAPE_BASE+209	//CFOPBreakCenterLinkShape
#define FOP_COMP_OLE						FO_SHAPE_BASE+210	//CFOPOleShape
#define FOP_COMP_RICHEDIT					FO_SHAPE_BASE+211	//CFOPRichEditShape
#define FO_COMP_ELLIPSE						FO_SHAPE_BASE+212	//CFOEllipseShape
#define FOP_ADVANCE_LINESHAPE				FO_SHAPE_BASE+213	//CFOPAdvAnchorShape
#define FOP_FONTWORK_SHAPE					FO_SHAPE_BASE+214	//CFOPFontworkShape
#define FOP_ADVANCE_LINK_SHAPE				FO_SHAPE_BASE+215	//CFOPAdvAnchorLinkShape
#define FOP_CALC_EDITSHAPE					FO_SHAPE_BASE+216	//CFOPCalcEditShape
#define FOP_ICON_SHAPE						FO_SHAPE_BASE+217	//CFOIconShape
#define FOP_BITMAP_SHAPE					FO_SHAPE_BASE+218	//CFOBitmapShape
#define FO_COMP_POSTNUMBER					FO_SHAPE_BASE+219	//CFOPostNumberShape
#define FOP_COMP_SUBGRAPH					FO_SHAPE_BASE+220	//CFOPSubGraphShape
#define FOP_NEW_SINGLEARROWSHAPE			FO_SHAPE_BASE+221	//CFOPNewSingleArrowShape
#define FOP_NEW_REVERSE_SINGLEARROWSHAPE	FO_SHAPE_BASE+222	//CFOPNewReverseSingleArrowShape
#define FOP_NEW_DOUBLEARROWSHAPE			FO_SHAPE_BASE+223	//CFOPNewDoubleArrowShape
#define FOP_NEW_COMMSHAPE					FO_SHAPE_BASE+224	//CFOPCommShape
#define FOP_NEW_SINGLEARROW_LINKSHAPE		FO_SHAPE_BASE+225	//CFOPNewSingleArrowLinkShape
#define FOP_NEW_REVERSE_SINGLEARROW_LINKSHAPE FO_SHAPE_BASE+226	//CFOPNewReverseSingleArrowLinkShape
#define FOP_NEW_DOUBLEARROW_LINKSHAPE		FO_SHAPE_BASE+227	//CFOPNewDoubleArrowLinkShape
#define FOP_NEW_COMM_LINKSHAPE				FO_SHAPE_BASE+228	//CFOPCommLinkShape
#define FOP_COMP_OCTAGON					FO_SHAPE_BASE+229	//CFOOctagonShape
#define FOP_COMP_EXTLINKSHAPE				FO_SHAPE_BASE+230	//CFOPExtLinkShape	
#define FO_COMP_EXT_CORNERLINK				FO_SHAPE_BASE+231	//CFOPExtCornerLinkShape			
#define FO_COMP_EXT_BEZIERLINE				FO_SHAPE_BASE+232	//CFOPExtBezierLineShape			
#define FOP_NEW_CURVE_LINKSHAPE				FO_SHAPE_BASE+233	//CFOPNewCurveLinkShape
#define FOP_NEW_LINEAR_LINKSHAPE			FO_SHAPE_BASE+234	//CFOPNewLinearLinkShape
#define FOP_NEW_SIMPLE_LINKSHAPE			FO_SHAPE_BASE+235	//CFOPNewSimpleLinkShape
#define FOP_ROUND_UPRIGHT_LINKSHAPE			FO_SHAPE_BASE+236	//CFOPRoundUpRightLinkShape
#define FOP_ROUND_TURNCORNER_LINKSHAPE		FO_SHAPE_BASE+237	//CFORoundTurnCornerLinkShape
#define FOP_IMAGELIST_SHAPE					FO_SHAPE_BASE+238	//CFOImageListShape

#define FOP_TABLE_SHAPE						FO_SHAPE_BASE+239	//CFOPTableShape
#define FOP_GAUGE_CIRCULAR_SHAPE			FO_SHAPE_BASE+240	//CFOPGaugeCircularShape
#define FOP_GAUGE_LINEAR_SHAPE				FO_SHAPE_BASE+241	//CFOPGaugeLinearShape
#define FOP_GAUGE_VERTLINE_SHAPE			FO_SHAPE_BASE+242	//CFOPGaugeVertLineShape
#define FO_COMP_EXT_BEZIERLINK				FO_SHAPE_BASE+243	//CFOPExtBezierLinkShape			

#define FOP_CHART_SHAPE						FO_SHAPE_BASE+244	//CFOPChartShape
#define FOP_NEWSTYLE_DATE_SHAPE				FO_SHAPE_BASE+245	//CFONewStyleDataTimeShape
#define FOP_MULTITEXT_SHAPE					FO_SHAPE_BASE+246	//CFOMultiTextShape
#define FOP_NEW_SUB_GRAPH_SHAPE				FO_SHAPE_BASE+247	//CFOPNewSubGraphShape

#define FOP_BITMAP_BOX_SHAPE				FO_SHAPE_BASE+248	//CFOPBitmapBoxShape
#define FOP_IMAGELIST_BOX_SHAPE				FO_SHAPE_BASE+249	//CFOPImageListBoxShape
#define FOP_ARC_LINK_SHAPE					FO_SHAPE_BASE+250	//CFOPArcLinkShape
#define FOP_CLOUND_SHAPE					FO_SHAPE_BASE+251	//CFOPCloudShape
#define FOP_LABEL_SHAPE						FO_SHAPE_BASE+252	//CFOLabelShape
#define FOP_ADVANCE_SHAPE					FO_SHAPE_BASE+253	//CFOPNewAnchorLineShape
#define FO_COMP_EXT_TWO_BEZIERLINK			FO_SHAPE_BASE+254	//CFOPExtTwoAnchorBezierLinkShape			

#define FO_COMP_CENTER_ARROW_LINK			FO_SHAPE_BASE+255	//CFOPCenterArrowLink			
#define FO_TIME_CHART_SHAPE					FO_SHAPE_BASE+256	//CFOTimeChartShape
#define FO_SIMPLE_LABLE						FO_SHAPE_BASE+257	//CFOPSimpleLabelShape
#define FO_BORDER_SHAPE						FO_SHAPE_BASE+258	//CFOPBorderShape
#define FO_VERT_DYNAMIC_LINK_SHAPE			FO_SHAPE_BASE+259   //CFOPVertDynamicLinkShape
#define FO_HORZ_DYNAMIC_LINK_SHAPE			FO_SHAPE_BASE+260   //CFOPHorzDynamicLinkShape
#define FO_SIDE_LINK_SHAPE					FO_SHAPE_BASE+261   //CFOPSideLinkShape
#define FO_NEW_LINK_SHAPE					FO_SHAPE_BASE+262	//CFOPNewLinkShape
#define FO_SIGN_LINK_SHAPE					FO_SHAPE_BASE+263	//CFOSignLinkShape
#define FO_COMP_MENUBUTTON					FO_SHAPE_BASE+264	//CFOMenuButtonShape
#define FO_COMP_BITMAP_BUTTON				FO_SHAPE_BASE+265	//CFOBitmapButtonShape
#define FO_COMP_PIPE_SHAPE				    FO_SHAPE_BASE+267	//CFOPipeShape
#define FO_COMP_PIPE_LINKSHAPE				FO_SHAPE_BASE+268	//CFOPipeLinkShape
#define FO_COMP_LIQUID_LINESHAPE			FO_SHAPE_BASE+269	//CFOPLiquidLineShape
#define FO_COMP_CURVED_LINKSHAPE			FO_SHAPE_BASE+270	//CFOPCurvedLinkShape
#define FO_COMP_LIQUID_LINKSHAPE			FO_SHAPE_BASE+271	//CFOPLiquidLinkShape
#define FOP_COMP_AUTOFONTFILLBOX			FO_SHAPE_BASE+272	//CFOAutoFontFillShape
#define FO_COMP_EXT_CLOSEBEZIER 			FO_SHAPE_BASE+273	//CFOPExtCloseBezierShape	

#define FO_CENTER_ELLIPSE 					FO_SHAPE_BASE+274	//CFOEllipseShape2		
#define FO_MULTI_ELLIPSE_GAUGE_SHAPE	    FO_SHAPE_BASE+275	//CFOPNewGaugeMultiPhaseEllipseShape		
#define FO_TANK_GAUGE_SHAPE					FO_SHAPE_BASE+276	//CFOPNewGaugeTankShape
#define FO_KNOB_GAUGE_SHAPE					FO_SHAPE_BASE+277	//CFOPNewGaugeKnobShape
#define FO_SLIDER_ELLIPSE_GAUGE_SHAPE		FO_SHAPE_BASE+278	//CFOSliderMeterEllipticalShape
#define FO_MULTI_BAR_GAUGE_SHAPE			FO_SHAPE_BASE+279	//CFOPNewGaugeMultiPhaseBarShape
#define FO_LINEAR_SCALE_SHAPE				FO_SHAPE_BASE+280	//CFOPLinearScaleShape
#define FO_COMP_HIGH						FO_SHAPE_BASE+281	//CFOHighShape
#define FO_ELLIPTICAL_SCALE_SHAPE			FO_SHAPE_BASE+282	//CFOPEllipticalScaleShape
#define FO_COMP_PIN							FO_SHAPE_BASE+283	//CFOPinShape
#define FO_COMP_WATER_HIGH					FO_SHAPE_BASE+284	//CFOPWaterHighShape
#define FO_COMP_MOVEPATH_SHAPE				FO_SHAPE_BASE+285	//CFOPMovePathShape
#define FOP_NEW_OLE_COMP					FO_SHAPE_BASE+286	//CFOPNewOleShape
#define FO_COMP_POLY_BUTTON					FO_SHAPE_BASE+287	//CFOPPolygonButtonShape

#define FO_COMP_ANIMATE_LINK				FO_SHAPE_BASE+288   //CFOAnimatedLinkShape
#define FO_DEFERENT_SHAPE					FO_SHAPE_BASE+289   //CFODeferentShape
#define	FO_EXT_HORZ_SLIDER					FO_SHAPE_BASE+290   //CFOExtHorzSliderShape
#define	FO_EXT_VERT_SLIDER					FO_SHAPE_BASE+291   //CFOExtVertSliderShape
#define FO_EXT_PIE_PROGRESS					FO_SHAPE_BASE+292   //CFOPieProgressShape
#define FO_NEW_PIPE_SHAPE					FO_SHAPE_BASE+293	//CFOPNewPipeShape
#define FO_SCALE_REF_SHAPE					FO_SHAPE_BASE+294	//CFOPScaleRefShape

#define FO_ADV_CIRCULAR_GAUGE_SHAPE			FO_SHAPE_BASE+295   //CFOPAdvGaugeCircularShape
#define FO_ADV_MULTI_ELLIPSE_GAUGE_SHAPE    FO_SHAPE_BASE+296   //CFOPAdvGaugeMultiPhaseEllipseShape
#define FO_ADV_KNOB_GAUGE_SHAPE				FO_SHAPE_BASE+297	//CFOPAdvGaugeKnobShape
#define FO_ADV_SLIDER_ELLIPSE_GAUGE_SHAPE   FO_SHAPE_BASE+298	//CFOAdvSliderMeterEllipticalShape

#define FO_HMI_LABEL_SHAPE					FO_SHAPE_BASE+299	//CFOPHMILabelShape
#define FO_HMI_BUTTON_SHAPE1				FO_SHAPE_BASE+300	//CFOHMIButtonShape

#define FO_HMI_GAUGE_SHAPE1					FO_SHAPE_BASE+301	//CFOHMIGaugeShape1
#define FO_HMI_GAUGE_SHAPE2					FO_SHAPE_BASE+302	//CFOHMIGaugeShape2
#define FO_HMI_GAUGE_SHAPE3					FO_SHAPE_BASE+303	//CFOHMIGaugeShape3
#define FO_HMI_GAUGE_SHAPE4					FO_SHAPE_BASE+304	//CFOHMIGaugeShape4
#define FO_HMI_GAUGE_SHAPE5					FO_SHAPE_BASE+305	//CFOHMIGaugeShape5
#define FO_HMI_GAUGE_SHAPE6					FO_SHAPE_BASE+306	//CFOHMIGaugeShape6
#define FO_HMI_GAUGE_SHAPE7					FO_SHAPE_BASE+307	//CFOHMIGaugeShape7
#define FO_HMI_GAUGE_SHAPE8					FO_SHAPE_BASE+308	//CFOHMIGaugeShape8
#define FO_HMI_GAUGE_SHAPE9					FO_SHAPE_BASE+309	//CFOHMIGaugeShape9
#define FO_HMI_GAUGE_SHAPE10				FO_SHAPE_BASE+310	//CFOHMIGaugeShape10
#define FO_HMI_GAUGE_SHAPE11				FO_SHAPE_BASE+311	//CFOHMIGaugeShape11
#define FO_HMI_GAUGE_SHAPE12				FO_SHAPE_BASE+312	//CFOHMIGaugeShape12
#define FO_HMI_GAUGE_SHAPE13				FO_SHAPE_BASE+313	//CFOHMIGaugeShape13
#define FO_HMI_GAUGE_SHAPE14				FO_SHAPE_BASE+314	//CFOHMIGaugeShape14

#define FO_HMI_KNOB_SHAPE1					FO_SHAPE_BASE+320	//CFOHMIKnobShape1
#define FO_HMI_KNOB_SHAPE2					FO_SHAPE_BASE+321	//CFOHMIKnobShape2
#define FO_HMI_KNOB_SHAPE3					FO_SHAPE_BASE+323	//CFOHMIKnobShape3


#define FO_HMI_LED_SHAPE1					FO_SHAPE_BASE+330	//CFOHMILedShape1
#define FO_HMI_LED_SHAPE2					FO_SHAPE_BASE+331	//CFOHMILedShape2

#define FO_ARROW_FLOW_LINK					FO_SHAPE_BASE+332	//CFOArrowFlowLinkShape
#define FO_GIS_LABEL						FO_SHAPE_BASE+333	//CFOGisLabelShape
#define FO_COOL_BUTTON						FO_SHAPE_BASE+334	//CFOPCoolButtonShape

#define FO_ONE_IMAGEBOX_SHAPE				FO_SHAPE_BASE+335	//CFOPOneImageBoxShape
#define FO_TWO_IMAGEBOX_SHAPE				FO_SHAPE_BASE+336	//CFOPTwoImageBoxShape
#define FO_THREE_IMAGEBOX_SHAPE				FO_SHAPE_BASE+337	//CFOPThreeImageBoxShape
#define FO_FOUR_IMAGEBOX_SHAPE				FO_SHAPE_BASE+338	//CFOPFourImageBoxShape

#define FO_TWO_IMAGEBUTTON_SHAPE			FO_SHAPE_BASE+339	//CFOPImageButtonShape
#define FO_HMI_NEW_LABEL_SHAPE				FO_SHAPE_BASE+340	//CFOPHMINewLabelShape	
#define FO_WATER_ROUND_SHAPE				FO_SHAPE_BASE+341	//CFOWaterRoundShape
#define FO_IMAGE_NEW_SHAPE					FO_SHAPE_BASE+342	//CFONewImageShape
#define FO_COMP_NEW_ZHI_LINK				FO_SHAPE_BASE+343	//CFONewUpRightLinkShape
#define FO_X_IMAGE_SHAPE					FO_SHAPE_BASE+344	//CFOXImageShape
#define FO_DOT_PORT_SHAPE					FO_SHAPE_BASE+345	//CFODotPortShape
#define FO_CAD_ELLIPSE_SHAPE				FO_SHAPE_BASE+346	//CFOPCADEllipseShape
#define FO_DEF_SYMBOL_SHAPE					FO_SHAPE_BASE+347	// for teamplate file
#define FO_ROTATE_ELLIPSE_SHAPE				FO_SHAPE_BASE+348   // CFORotateEllipseShape
#define FO_ROTATE_RECT_SHAPE				FO_SHAPE_BASE+349   // CFORotateRectShape
#define FO_2D_SLIDER_SHAPE					FO_SHAPE_BASE+350   // CFOP2DSliderShape
#define FOP_GAUGE_HORIZ_SHAPE				FO_SHAPE_BASE+351	//CFOPGaugeHorizLineShape

#define FOP_NEW_X_TABLE						FO_SHAPE_BASE+352	//FOXNewTableShape
#define FOP_NEWPOLY_LINE					FO_SHAPE_BASE+353	//CFOPNewPolyLineShape
#define FOP_OLD_ROUNDRECT					FO_SHAPE_BASE+354   //CFORoundRectShape

#define FO_NEWPATH_SHAPE					FO_SHAPE_BASE+360	//CFOPNewPathShape
#define FO_NEWRECT_SHAPE					FO_SHAPE_BASE+361	//CFOPNewPathShape
#define FO_REGPOLY_SHAPE					FO_SHAPE_BASE+362	//CFOPNewPathShape
#define FO_SPIRCAL_SHAPE					FO_SHAPE_BASE+363	//CFOPPathShape
#define FO_CAD_POINT_SHAPE					FO_SHAPE_BASE+364	//CFOCADPointShape
#define FO_LIST_PORT_SHAPE					FO_SHAPE_BASE+365	//CFOListPortShape
#define FO_HMI_LED_SHAPE3					FO_SHAPE_BASE+366	//CFOHMILedShape3
#define FO_COMP_RING						FO_SHAPE_BASE+367	//CFOPRingShape

#define FOP_COMP_POWERLINK					FO_SHAPE_BASE+368	//CFOTurnCornerLinkShape
#define FOP_ROUND_POWERLINK					FO_SHAPE_BASE+369	//CFORoundTurnCornerLinkShape

// Define your own shape start ID.
#define FO_COMP_CUSTOM						FO_SHAPE_BASE+600	// The start type value of your own customize component.

#define FO_DROP_TOOLBOX_SHAPE_TYPE			FO_SHAPE_BASE + 92365 // This type value is defined for drag and drop from toolbox window.
//////////////////////////////////////////////////////////////
// FOPBridgeStyle, bridge style of link line, it is designed for link route.

const unsigned short FO_BARHEIGHTMIN = 6;

const DWORD FO_STCOUNTER0    = 252;
const DWORD FO_STCOUNTER1    = 96;
const DWORD FO_STCOUNTER2    = 218;
const DWORD FO_STCOUNTER3    = 242;
const DWORD FO_STCOUNTER4    = 102;
const DWORD FO_STCOUNTER5    = 182;
const DWORD FO_STCOUNTER6    = 190;
const DWORD FO_STCOUNTER7    = 224;
const DWORD FO_STCOUNTER8    = 254;
const DWORD FO_STCOUNTER9    = 246;
const DWORD FO_STCOUNTER10  = 2;		// The minus sign [2]
const DWORD FO_STCOUNTER11  = 256;	  // The "point"
const DWORD FO_STCOUNTER12  = 257;	  // The "colon" (:)
const DWORD FO_STCOUNTERALL  = 999;

const DWORD FO_NOTCH1 = 128;
const DWORD FO_NOTCH2 = 64;
const DWORD FO_NOTCH3 = 32;
const DWORD FO_NOTCH4 = 16;
const DWORD FO_NOTCH5 = 8;
const DWORD FO_NOTCH6 = 4;
const DWORD FO_NOTCH7 = 2;		// The minus sign
const DWORD FO_NOTCH8 = 1;		// Not used...

enum FOPBridgeStyle
{
	FOPCap = 0,
	FOPArc,			// Arc style
	FOPSquare,		// square style
	FOPSides2,		// 2 sides style
	FOPSides3,		// 3 sides style
	FOPSides4,		// 4 sides style
	FOPSides5,		// 5 sides style
	FOPSides6,		// 6 sides style
	FOPSides7		// 7 sides style
};

/////////////////////////////////////////////////////////////////////////////
// Gui Style of framework

enum FO_GUI_TYPE
{
	GUI_STANDARD = 0,			// Cross grid line
	GUI_BLUE,					// Dot grid.
	GUI_SILVER,					// Rectangle grid line.
	GUI_AQUA,					// Aqua style
	GUI_OTHER				
};

/////////////////////////////////////////////////////////////////////////////
// Grid line style

enum FO_GRIDLINE_TYPE
{
	GRID_CROSSLINE = 0,			// Cross grid line
	GRID_DOT,					// Dot grid.
	GRID_RECTANGLE,				// Rectangle grid line.
	GRID_VISIO					// Visio style grid line.
};

/////////////////////////////////////////////////////////////////////////////
// Below are merge mode.

enum FOP_MERGE_MODE
{
	FOP_MERGE,					// Merge two selected shapes.
	FOP_SUBSTRACT,				// Substract a shape from other shape
	FOP_INTERSECT				// Intersect two selected shapes.
};

// Shape fill state
enum FOP_FILL_STATE
{
	FOP_FILL_NONE = 0,					// None fill,be transparent
	FOP_FILL_FIRST,						// Fill with the first selected color
	FOP_FILL_SECOND,					// Fill with the second selected color
	FOP_FILL_CUSTOM						// Fill with custom type.
};

// Style of the caption
enum FOPCaptionType
{
	FOP_CAPTION_TYPE1,					// Caption type 1
	FOP_CAPTION_TYPE2,					// caption type 2
	FOP_CAPTION_TYPE3					// caption type 3
};

// Direction of the link line
enum FOPCaptionDir
{
	FOP_CAPTION_HORIZONTAL,				// Horizontal caption
	FOP_CAPTION_VERTICAL,				// Vertical caption.
	FOP_CAPTION_BESTFIT					// Best fit caption.
};

// Fit style
enum FOPEscDir
{
	FOP_LEFTFIT,						// Left fit
	FOP_RIGHTFIT,						// Right fit
	FOP_TOPFIT,							// Top fit
	FOP_BOTTOMFIT						// Bottom fit
};

#define FOP_CMD_START			30999
#define FOP_CMD_TEST1			31020
#define FOP_CMD_TEST2			31021
#define FOP_CMD_TEST3			31022
#define FOP_CMD_TEST4			31023
#define FOP_CMD_TEST5			31024
#define FOP_CMD_TEST6			31025
#define FOP_CMD_END				31100
#define FOP_DTCEM_DESTROY_CALENDAR			(WM_USER+1)
#define FOP_DTCEM_RECREATE					(WM_USER+2)

///////////////////////////////////////////////////////////////////
// Gradient fill type.
///////////////////////////////////////////////////////////////////
enum FOPCalcCommand
{
	idCommandNone     = 0,
		idCommandMult	  = 1,
		idCommandPlus     = 2,
		idCommandMinus    = 3,
		idCommandDivide   = 4,
		idCommandPercent  = 5,
		idCommandEquals   = 6,
		idCommandClear    = 7,
		idCommandClearE	  = 8,
		idCommand0		  = 9,
		idCommand1        = 10,
		idCommand2        = 11,
		idCommand3        = 12,
		idCommand4        = 13,
		idCommand5        = 14,
		idCommand6        = 15,
		idCommand7        = 16,
		idCommand8        = 17,
		idCommand9        = 18,
		idCommandDecimal  = 19,
		idCommandBackspace = 20,
		idCommandMemAdd	   = 21,
		idCommand00		   = 22,
		idCommandSqrt	   = 23,
		idCommandRev	   = 24
};

// Graident style.

enum FO_GRADIENT_TYPE
{
	GRADIENT_HORZ_TOP_BOTTOM = 0,
	GRADIENT_HORZ_BOTTOM_TOP,	
	GRADIENT_VERT_LEFT_RIGHT,
	GRADIENT_VERT_RIGHT_LEFT,
	GRADIENT_HORZ_CENTER_OUT,
	GRADIENT_HORZ_CENTER_IN,
	GRADIENT_VERT_MIDDLE_OUT,
	GRADIENT_VERT_MIDDLE_IN,
	GRADIENT_CORNER_TOP_LEFT,
	GRADIENT_CORNER_RIGHT_TOP,
	GRADIENT_CORNER_RIGHT_BOTTOM,
	GRADIENT_CORNER_BOTTOM_LEFT,
	GRADIENT_TITLE_OUT,
	GRADIENT_TITLE_IN,
	GRADIENT_ELLIPSE_OUT,
	GRADIENT_ELLIPSE_IN,
	GRADIENT_ANGLE_45,
	GRADIENT_ANGLE_135,
	GRADIENT_ANGLE_225,
	GRADIENT_ANGLE_315
};

// Unit that need to be converted to.
enum FOP_UNIT
{
	FOP_UINT_100S_MM,
	FOP_UINT_10S_MM,
	FOP_UINT_MM,
	FOP_UINT_CM,
	FOP_UINT_1000S_INCH,
	FOP_UINT_100S_INCH,
	FOP_UINT_10S_INCH,
	FOP_UINT_INCH,
	FOP_UINT_POINT,
	FOP_UINT_TWIP,
	FOP_UINT_PIXEL
};

// Paper type.
enum FO_PAPER
{
	FOP_PAPER_A0,
	FOP_PAPER_A1,
	FOP_PAPER_A2,
	FOP_PAPER_A3,
	FOP_PAPER_A4,
	FOP_PAPER_A5,
	FOP_PAPER_B4,
	FOP_PAPER_B5,
	FOP_PAPER_LETTER,
	FOP_PAPER_LEGAL,
	FOP_PAPER_TABLOID,
	FOP_PAPER_USER,
	FOP_PAPER_B6,
	FOP_PAPER_C4,
	FOP_PAPER_C5,
	FOP_PAPER_C6,
	FOP_PAPER_C65,
	FOP_PAPER_DL,
	FOP_PAPER_DIA,
	FOP_PAPER_SCREEN,
	FOP_PAPER_A,
	FOP_PAPER_B,
	FOP_PAPER_C,
	FOP_PAPER_D,
	FOP_PAPER_E,
	FOP_PAPER_EXECUTIVE,
	FOP_PAPER_LEGAL2,
	FOP_PAPER_MONARCH,
	FOP_PAPER_COM675,
	FOP_PAPER_COM9,
	FOP_PAPER_COM10,
	FOP_PAPER_COM11,
	FOP_PAPER_COM12,
	FOP_PAPER_KAI16,
	FOP_PAPER_KAI32,
	FOP_PAPER_KAI32BIG,
	FOP_PAPER_B4_JIS,
	FOP_PAPER_B5_JIS,
	FOP_PAPER_B6_JIS
};

/////////////////////////////////////////////////////////////////////////////
// Path control handle point flags.

enum fopPathType
{
	FOP_PATH_NONE,				// No path
	FOP_PATH_LINE,				// Line corner
	FOP_PATH_CURVE				// Curve corner
};


/////////////////////////////////////////////////////////////////////////////
// Path control handle smooth flags.

enum fopPathSmoothType  
{
	FOP_SMOOTH_NONE,			// None
	FOP_SMOOTH_ANGULAR,			// Angular style
	FOP_SMOOTH_ASYMMETRIC,		// Asymmetric style.
	FOP_SMOOTH_SYMMETRIC		// Symmetric style
};

// Grid list
typedef struct _tagNM_FOP_GRIDLIST
{
	NMHDR hdr;
	LPARAM lParam;
	
	_tagNM_FOP_GRIDLIST()
	{
		ZeroMemory(this,sizeof(_tagNM_FOP_GRIDLIST));
	}
	
} NM_FOP_GRIDLIST, * LPNM_FOP_GRIDLIST;

// Context menu.
typedef struct _tagFOP_CONTEXTMENU
{    
	CMenu* pMenu;
	CPoint point;
	
	_tagFOP_CONTEXTMENU()
	{
		ZeroMemory(this,sizeof(_tagFOP_CONTEXTMENU));
	}
	
} FOP_CONTEXTMENU, * LPFOP_CONTEXTMENU;

#if _MSC_VER < 1400
#ifndef DWORD_PTR // for VC++ 6
	typedef DWORD DWORD_PTR;
#endif
#endif

// FOP_EUseExtendedData
enum FOP_EUseExtendedData
{
	X_EDNo = 1,
	X_EDAdding = 2,
	X_EDYes = 3,
	X_EDRemoving = 4,
};

/////////////////////////////////////////////////////////////////////////////
// extend point
struct fopPointExt
{
	long nLX;
	long nLY;
};
typedef const fopPointExt* FOPCONSTPOINT;

/////////////////////////////////////////////////////////////////////////////
// Port shape style.

enum FO_PORT_TYPE
{
	FO_PORT_NOTSHOW = -1,
	FO_PORT_RECT,
	FO_PORT_ELLIPSE,
	FO_PORT_DIAMOND,
	FO_PORT_TRIANGLE,
	FO_PORT_INVERT_TRIANGLE,
	FO_PORT_CROSSLINE,
	FO_PORT_CROSSLINENEW,
	FO_PORT_LEFTRIGHT_TRIANGLE,
	FO_PORT_INVERT_LEFTRIGHT_TRIANGLE,
	FO_PORT_MATLAB_IN,
	FO_PORT_MATLAB_OUT,
	FO_PORT_CUSTOM
};

/////////////////////////////////////////////////////////////////////////////
// Split mode

#define	FOP_SPLIT_LINE			(0x0001)
#define	FOP_SPLIT_START1		(0x0002)
#define	FOP_SPLIT_START2		(0x0004)
#define	FOP_SPLIT_END1			(0x0008)
#define	FOP_SPLIT_END2			(0x0010)

#define	FOP_SPLIT_ALL			(FOP_SPLIT_LINE|FOP_SPLIT_START1|FOP_SPLIT_START2|FOP_SPLIT_END1|FOP_SPLIT_END2)
#define	FOP_SPLIT_DEFAULT		(FOP_SPLIT_LINE|FOP_SPLIT_START2|FOP_SPLIT_END2)

/////////////////////////////////////////////////////////////////////////////
// Zoom mode.

enum 
{
	FOP_ZOOMMODE_PANOVER, 
	FOP_ZOOMMODE_NORMAL,
	FOP_ZOOMMODE_FIT
};

///////////////////////////////////////////////////////////////////
// Text Bullets tools.

enum FO_BULLETS_TYPE
{
	FO_BULLET_NULL = 0,
	FO_BULLET_MAX_ELLIPSE,
	FO_BULLET_FILL_RECTANGLE,
	FO_BULLET_RHOMBUS,
	FO_BULLET_EMPTY_RECTANGLE,
	FO_BULLET_ARROW,
	FO_BULLET_MIN_CIRCLE,
	FO_BULLET_PLUM	
};

// canvas's Axis direction.
enum FOCanvasAxisDirection
{
	FO_YAXIS_UP		= -1, // y axis is up
	FO_YAXIS_DOWN	= 1	  // y axis is down
};

// Horizontal alignment.
enum FOPHorzAlign  
{
	FOPHALIGN_NONE = 0,
	FOPHALIGN_LEFT,
	FOPHALIGN_RIGHT,
	FOPHALIGN_CENTER
};

// Vertical alignment
enum FOPVertAlign 
{
	FOPVALIGN_NONE = 0,
	FOPVALIGN_TOP,
	FOPVALIGN_BOTTOM,
	FOPVALIGN_CENTER
};

// Distribute horizontal type
enum FOPDistributeHorizontal
{
	FOPDistributeHorizontalNone = 0,
	FOPDistributeHorizontalLeft,
	FOPDistributeHorizontalCenter,
	FOPDistributeHorizontalDistance,
	FOPDistributeHorizontalRight
};

// Distribute vertical type
enum FOPDistributeVertical
{
	FOPDistributeVerticalNone = 0,
	FOPDistributeVerticalTop,
	FOPDistributeVerticalCenter,
	FOPDistributeVerticalDistance,
	FOPDistributeVerticalBottom
};

/////////////////////////////////////////////////////////////////////////////
// Define for color.

typedef struct tagFO_COLOR
{
	COLORREF	crText;			 // Text color.
	COLORREF	crBack;			 // Back color.
	COLORREF	crFront;		 // Front color.
} FO_COLOR;


/////////////////////////////////////////////////////////////////////////////
// Port scale values.

typedef struct tagFO_PORTVALUE
{
	double		dScaleX;		 // X Scale value.
	double		dScaleY;		 // Y Scale value
} FOPORTVALUE;


/////////////////////////////////////////////////////////////////////////////
// Define for image type.

enum FO_IMAGETYPE
{
	FO_IMAGE_BMP = 0, // CFOImageShape
	FO_IMAGE_ICO,	  // CFOImageShape
	FO_IMAGE_PCX,	  // CFOImageShape
	FO_IMAGE_JPG,	  // CFOImageShape
	FO_IMAGE_PNG,	  // CFOImageShape
	FO_IMAGE_GIF,	  // CFOImageShape
	FO_IMAGE_TGA,	  // CFOImageShape
	FO_IMAGE_MNG,	  // CFOImageShape
	FO_IMAGE_EMF,	  // CFOEMFShape
	FO_IMAGE_WMF,	  // CFOWMFShape
	FO_IMAGE_UNKNOWN
};

// Action state.
// Only define for image.
#define FO_STATE_DRAW_IMAGE					22

// Compare
#define FORMMIN(X,Y)						(((X) < (Y)) ? (X) : (Y))
#define FORMMAX(X,Y)						(((X) > (Y)) ? (X) : (Y))

// Multiple pages manager destroy notify.
#define FOP_MP_MSG_MANGR_DELETE				3084

// Tab pages manager destroy notify.
#define FOP_TP_MSG_NANGR_DELETE				3085

// Data model pages manager destroy notify.
#define FOP_MD_MSG_DELETE					3086

// picker alignment.
#define FO_ALIGNBOTTOMLEFT					0x0001	

// Form change message.
#define WM_FO_RESETSLECTCOMPONET_STATE		WM_USER+210	// Reset selected shapes's state.
#define WM_FO_COLORHASCHANGED				WM_USER+211	// Color well changed message.

// Color change message.
#define WM_FO_SELECTCOLOROK					WM_USER+220	// Select color ok.
#define WM_FO_SELECTCOLORCANCEL				WM_USER+221	// Select color cancel.
#define WM_FO_SELECTCOLORCUSTOM				WM_USER+222	// Select color custom.
#define WM_FO_SELECTCOLORCHANGE				WM_USER+223 // Select color change.

// Line width message.
#define WM_FO_SELECTLINEWIDTHOK				WM_USER+230 // Select line width ok.
#define WM_FO_SELECTLINEWIDTHCANCEL			WM_USER+231 // Select line width cancel.
#define WM_FO_SELECTLINEWIDTHCUSTOM			WM_USER+232 // Select line width custom.
#define WM_FO_SELECTLINEWIDTHCHANGE			WM_USER+233 // Select line width change.

// Line type message.
#define WM_FO_SELECTLINETYPEOK				WM_USER+240 // Select line type ok.
#define WM_FO_SELECTLINETYPECANCEL			WM_USER+241 // Select line type cancel.
#define WM_FO_SELECTLINETYPECUSTOM			WM_USER+242 // Select line type custom.
#define WM_FO_SELECTLINETYPECHANGE			WM_USER+243 // Select line change.

// Tab sheet message.
#define WM_FO_TABSWITCH						WM_USER+300
#define WM_FO_TABDBLCLK						WM_USER+301
#define WM_FO_CANTABSWITCH					WM_USER+302
#define WM_FO_CHANGEDTAB					WM_USER+303
#define WM_FO_CANACTIVATE					WM_USER+304
#define WM_FO_EDITEND						WM_USER+305
#define WM_FO_EDITCANCEL					WM_USER+306
#define WM_FOP_INITTAB						WM_USER+307

// Tab Control Messages
#define WM_FO_TAB_SELECTTAB					WM_USER+410
#define WM_FO_TAB_DOUBLECLICK				WM_USER+411
#define WM_FO_TAB_ACTIVATETAB				WM_USER+412
#define WM_FOP_CALC_TEXT					WM_USER+413

// Undo / Redo selection message.
#define WM_FO_UNDOREDO						WM_USER+500
#define WM_FO_TOOLTIP_NOTIFY				WM_USER+501

#define WM_FO_CLICKEND						WM_USER+550

#define FOP_GENERIC_TOOL_TIMER_ID           9093

// Define for static edit control ID.
#define IDC_FO_LABEL_TEXTEDIT				2234

// Define for edit box shape control ID.
#define IDC_FO_EDITBOX_EDIT					2235

// Define for list box control ID
#define IDC_FO_LISTBOX_CONTROL_ID			2236

// Define notify data.
const UINT IDN_FO_NOTIFY =					200;

// Tab Control Styles
#define FOP_TS_ALIGN_BOTTOM					0x0010
#define FOP_TS_ALIGN_TOP					0x0020
#define FOP_TS_ALIGN_LEFT					0x0040
#define FOP_TS_ALIGN_RIGHT					0x0080

// Tab bound window's ID value.
#define FO_TAB_BUNDY_ID						52514


/////////////////////////////////////////////////////////////////////////////
// border style

enum BorderShape 
{
	BORDER_NONE = 0,
	BORDER_SINGLE_IN,
	BORDER_SINGLE_OUT,
	BORDER_DOUBLE_IN,
	BORDER_DOUBLE_OUT,
	BORDER_SUNKEN,	
	BORDER_LOW,	
	BORDER_UP,	
	BORDER_HIGH,
	BORDER_FLAT,
	BORDER_FRAME,
	BORDER_LIGHT_FRAME,	
	BORDER_THIN_FRAME,
	BORDER_THIN_LIGHT_FRAME,
	BORDER_ETCHED,	
	BORDER_ETCHED2,	
	BORDER_SIMPLE
};	

///////////////////////////////////////////////////////////////////
// Shape control handle position.
///////////////////////////////////////////////////////////////////
enum FO_CONTROL_HANDLE
{
	foTopLeft = 0,				// 1.Top left handle.
	TopMiddle,					// 2.Top middle handle.		
	foTopRight,					// 3.Top right handle.        1*********2*********3
	SideRight,					// 4.Right side handle.       *					  *
	foBottomRight,				// 5.Bottom right handle	  *		9			  *
	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	foBottomLeft,					// 7.Bottom left handle		  *					  *
	SideLeft,					// 8.Side left handle.		  *					  *
	BeCenter					// 9.Center handle.			  7*********6*********5
};													

static int fopLinkMaxrix[5][5] =
{
	{0, 0, 1, 2, 2},
	{0, 0, 1, 2, 2},
	{7, 7, 8, 3, 3},
	{6, 6, 5, 4, 4},
	{6, 6, 5, 4, 4}
};
/////////////////////////////////////////////////////////////////////////////
// Extra anchor type

enum FO_ANCHOR_HANDLE
{
	BeAnchor = 0,				// 1.Anchor point..
	BeExtAnchor,				// 2.Extend anchor point.
	BeThirdAnchor,				// 3.Third anchor point.
	BeFourAnchor,				// 4.Four anchor point.
	BeFiveAnchor,				// 5.Five anchor point.
	BeCenterAnchor,				// 6.Center anchor point.
	BeTextAnchor				// 7.Text anchor point.
};													


/////////////////////////////////////////////////////////////////////////////
// Ruler measure style

enum FO_RULER_TYPE
{
	RULER_INCH = 0,				// Show inch ruler mark.
	RULER_CM,					// Show cm ruler mark.
	RULER_MM					// Show mm ruler mark.
};

///////////////////////////////////////////////////////////////////
// Horz Text alignment.
///////////////////////////////////////////////////////////////////
// Text horizontal alignment
enum TextHorzAlign 
{
	TextLeft=0,					// Left
    TextMiddle,					// Center
    TextRight					// Right
};

///////////////////////////////////////////////////////////////////
// Vert Text alignment.
///////////////////////////////////////////////////////////////////
// Text vertical alignment.
enum TextVertAlign 
{
	TextTop = 0,				// Top 
    TextCenter,					// Center
    TextBottom					// Bottom
}; 

// Layout direction.
enum FOPLayoutDirection
{
	// Fields
	FOP_LAYOUT_DOWN = 1,
    FOP_LAYOUT_LEFT = 2,
    FOP_LAYOUT_RIGHT = 0,
    FOP_LAYOUT_UP = 3
};

// Layout: Search path length, sink, source
enum FOPInitIndices
{
	// Fields
	FOP_LAYER_SEARCH1 = 1,
    FOP_LAYER_SEARCH2 = 0,
    FOP_LAYER_SEARCH3 = 2
};

// Layout: Path checking, outward, inward, naive
enum FOPPathCheck
{
	// Fields
	FOP_PATH_DEPTH1 = 0,
    FOP_PATH_DEPTH2,
    FOP_PATH_DEPTH3
};

///////////////////////////////////////////////////////////////////
// Action state.
///////////////////////////////////////////////////////////////////
enum action_stateflags
{
	State_SelectNone = 0,

	// Select state.
	State_SelectBegin,
	State_DoSelect,

	// Zoom state.
	State_ZoomWithInRect,
	State_ZoomBegin,
	State_DoZoom,//5

	// Drag and drop state.
	State_DropBegin,
	State_DoDrop,

	// Size shape state.
	State_SizeBegin,
	State_DoSize,	

	// Mirrow shape state.
	State_MirrorBegin,//10
	State_DoMirror,	

	// Shear shape state.
	State_ShearBegin,
	State_DoShear,

	// Distort shape state.
	State_DistortBegin,
	State_DoDistort,//15

	// Distort shape state.
	State_BendBegin,
	State_DoBend,

	// Ellipse state.
	State_DrawEllipse,
	State_DrawEllipseStart,
	State_DoDrawEllipse,//20

	// Form size change state.
	State_FormSizeBegin,
	State_DoFormSize,
	
	// Draw rectangle state.
	State_DrawRect,
	State_DrawRectStart,
	State_DoDrawRect,//25

	// Draw horz help line.
	State_DrawHorzHelpLine,
	State_DrawHorzHelpLineStart,
	State_DoDrawHorzHelpLine,

	// Draw vert help line.
	State_DrawVertHelpLine,
	State_DrawVertHelpLineStart,//30
	State_DoDrawVertHelpLine,

	// Move horz help line.
	State_MoveHorzHelpLine,
	State_MoveHorzHelpLineStart,
	State_DoMoveHorzHelpLine,

	// Move snap point.
	State_MoveSnapPointStart,//35
	State_DoMoveSnapPoint,

	// Move mirror help line.
	State_MoveMirrorLine,
	State_MoveMirrorLineStart,
	State_DoMoveMirrorLine,

	// Move mirror help line.
	State_MoveMirrorPoint,//40
	State_MoveMirrorPointStart,
	State_DoMoveMirrorPoint,

	// Move vert help line.
	State_MoveVertHelpLine,
	State_MoveVertHelpLineStart,
	State_DoMoveVertHelpLine,//45

	// Draw port.
	State_PortStart_Begin,
	State_PortStart,

	// Draw rectangle state.
	State_DrawRoundRect,
	State_DrawRoundRectStart,
	State_DoDrawRoundRect,//50

	// Draw shape state.
	State_DrawShape,
	State_DrawShapeStart,
	State_DoDrawShape,
	
	// Draw line state.
	State_DrawLine,
	State_DrawLineStart,//55
	State_DoDrawLine,

	// Draw line state.
	State_DrawDimLine,
	State_DrawDimLineStart,
	State_DoDrawDimLine,

	// Draw caption line state.
	State_DrawCapLine,//60
	State_DrawCapLineStart,
	State_DoDrawCapLine,

	// Draw arc line state.
	State_DrawArcLine,
	State_DrawArcLineStart,
	State_DoDrawArcLine,//65

	// Draw ellipse Arc2 state.
	State_DrawArc2,
	State_DrawArc2Start,
	State_DoDrawArc2,
	State_DrawArc2Line1Start,
	State_DoDrawArc2Line1,//70
	State_DrawArc2Line2Start,
	State_DoDrawArc2Line2,

	// Draw pie state.
	State_DrawPie,
	State_DrawPieStart,
	State_DoDrawPie,//75
	State_DrawPieLine1Start,
	State_DoDrawPieLine1,
	State_DrawPieLine2Start,
	State_DoDrawPieLine2,

	// Draw ellipse chord state.
	State_DrawChord,//80
	State_DrawChordStart,
	State_DoDrawChord,
	State_DrawChordLine1Start,
	State_DoDrawChordLine1,
	State_DrawChordLine2Start,//85
	State_DoDrawChordLine2,

	// Draw bezier line state.
	State_DrawBezierLine,
	State_DrawBezierLineStart,
	State_DoDrawBezierLine,

	// Draw free line state.
	State_DrawFreeLine,//90
	State_DoDrawFreeLine,

	// Draw close free line state.
	State_DrawFreeCloseLine,
	State_DoDrawFreeCloseLine,

	// Draw polyline state.
	State_DrawPLine,
	State_DrawPLineStart,//95
	State_DoDrawPLine,

	// Draw polygon state.
	State_DrawPolygon,
	State_DrawPolygonStart,
	State_DoDrawPolygon,

	// Draw bezier line state.
	State_DrawBezier,//100
	State_DrawBezierStart,
	State_DoDrawBezier,

	// Draw close bezier state.
	State_DrawCloseBezier,
	State_DrawCloseBezierStart,
	State_DoDrawCloseBezier,//105

	// Auto scroll state.
	State_AutoMoveScroll,
	State_AutoMoveStart,
	State_AutoMoving,

	// Draw link state.
	State_LinkReady,
	State_BeginLink,//110
	State_DrawLink,

	// Move port state.
	State_MovePortStart,
	State_MovingPort,

	// Move shape state.
	State_MoveBegin,
	State_DoMove,//115

	// Move handle spot state.
	State_MoveSpotBegin,
	State_DoMoveSpot,

	// Move handle spot state.
	State_MovePathBegin,
	State_DoMovePath,

	// Move handle spot state.
	State_MoveCenterSpotBegin,//120
	State_DoMoveCenterSpot,

	// Move handle spot state.
	State_MoveAnchorBegin,
	State_DoMoveAnchor,

	// Move handle spot state.
	State_MoveExtAnchorBegin,
	State_DoMoveExtAnchor,//125

	// Move handle spot state.
	State_MoveThirdAnchorBegin,
	State_DoMoveThirdAnchor,

	// Move handle spot state.
	State_MoveFourAnchorBegin,
	State_DoMoveFourAnchor,

	// Move handle spot state.
	State_MoveFiveAnchorBegin,//130
	State_DoMoveFiveAnchor,

	// Move handle spot state.
	State_MoveCenterAnchorBegin,
	State_DoMoveCenterAnchor,

	// Move handle spot state.
	State_MoveTextAnchorBegin,
	State_DoMoveTextAnchor,//135

	// In front of state.
	State_DoInfront_Shape,

	// Behind of shape state
	State_DoBehind_Shape,

	// Rotate state.
	State_SelectRotate,
	State_RotateBegin,
	State_DoRotate,//140

	// Editing new grid.
	State_EditNewGrid,

	// Only hitted locked shape.
	State_HitLocked,

	// Only for additional hit.
	State_HitAddi,

	// Draw rectangle state.
	State_OnlyDrop,
	State_DoOnlyDrop,//145
	State_OnlyDropStart,

	// Move table shape's column line spot state.
	State_ResizeColBegin,
	State_DoResizeCol,

	// Move table shape's row line spot state.
	State_ResizeRowBegin,
	State_DoResizeRow,//150

	// Select state.
	State_SelectTableBegin,
	State_DoTableSelect,

	// Move visio like spot.
	State_MoveVisioHandleBegin,
	State_DoMoveVisioHandle,

	// Move handle spot state.
	State_MoveUserAnchorBegin,//155
	State_DoMoveUserAnchor

};

///////////////////////////////////////////////////////////////////
// Font structure.
///////////////////////////////////////////////////////////////////
// Define for font.
typedef struct tagFO_FONT
{
	CString		m_strFaceName;		// Font face name.
	int			m_nHeight;			// Font height.
	int			m_nPointSize;		// Font point size.
	int			m_nWeight;			// Font weight.
	BOOL		m_bItalic;			// Italic.
	BOOL		m_bUnderline;		// Underline.
	BOOL		m_bStrikeout;		// Strikeout.
	COLORREF	m_crColor;			// Font color.
} FO_FONT;


/////////////////////////////////////////////////////////////////////////////
// color palette style

enum ColorPaletteShape 
{									// Rows X Cols
	COLOR_SHAPE_16X9 = 0,			// 16 X 9
	COLOR_SHAPE_12X12,				// 12 X 12
	COLOR_SHAPE_24X6,				// 24 X 6
	COLOR_SHAPE_48X3,				// 48 X 3
	COLOR_SHAPE_9X16,				// 9 X 16
	COLOR_SHAPE_6X24,				// 6 X 24
	COLOR_SHAPE_3X48				// 3 X 48
};
//------------------------------------------------------
// FOPGridScrollBars
// 
//------------------------------------------------------

// Grid scroll bars.
typedef enum FOPGridScrollBars
{
    FOP_GRID_SB_HORIZONTAL = 100,
    FOP_GRID_SB_VERTICAL

} FOPGridScrollBar;

//------------------------------------------------------
// FOPGridViewElements
// 
//------------------------------------------------------

// Grid view elements type
typedef enum FOPGridViewElements
{
    FOP_GRID_ELEMENT_NONE,
    FOP_GRID_ELEMENT_TITLEBAR,
    FOP_GRID_ELEMENT_COLUMNBAR,
    FOP_GRID_ELEMENT_LEFT_COLUMN_BAR,
    FOP_GRID_ELEMENT_SCROLLBAR_HORIZ,
    FOP_GRID_ELEMENT_SCROLLBAR_VERT,
    FOP_GRID_ELEMENT_CLIENT_AREA,
    FOP_GRID_ELEMENT_PICTEXT_PICTURE,
    FOP_GRID_ELEMENT_PICTEXT_TEXT,
    FOP_GRID_SUBELEMENT_NONE = 100,
    FOP_GRID_SUBELEMENT_COLUMNBAR_BUTTON,
    FOP_GRID_SUBELEMENT_COLUMNBAR_GAP,
    FOP_GRID_SUBELEMENT_SCROLLBAR_HORIZ_LEFT_BTN,
    FOP_GRID_SUBELEMENT_SCROLLBAR_HORIZ_RIGHT_BTN,
    FOP_GRID_SUBELEMENT_SCROLLBAR_HORIZ_DRAGGABLEBOX,
    FOP_GRID_SUBELEMENT_SCROLLBAR_HORIZ_SPACE_RIGHT,
    FOP_GRID_SUBELEMENT_SCROLLBAR_HORIZ_SPACE_LEFT,
    FOP_GRID_SUBELEMENT_SCROLLBAR_VERT_TOP_BTN,
    FOP_GRID_SUBELEMENT_SCROLLBAR_VERT_BOTTOM_BTN,
    FOP_GRID_SUBELEMENT_SCROLLBAR_VERT_DRAGGABLEBOX,
    FOP_GRID_SUBELEMENT_SCROLLBAR_VERT_SPACE_TOP,
    FOP_GRID_SUBELEMENT_SCROLLBAR_VERT_SPACE_BOTTOM,
    FOP_GRID_SUBELEMENT_TITLEBAR_MINIMIZE_BTN
} FOPGridViewElement;

//------------------------------------------------------
// FOPGridRectStruct
// 
//------------------------------------------------------

// Grid rectangle
struct FOPGridRectStruct
{
    void ResetAllRects();

    CRect		m_rcGrid;
    CRect		m_rcTitleBar;
    CRect		m_rcClientArea;
    CRect		m_rcClientAreaNoSB;
    CRect		m_rcColumnBar;
    CRect		m_rcColumnBarNoSB;
    CRect		m_rcColumnLeftColumn;
    CRect		m_rcHorzScrollBarOverall;
    CRect		m_rcHorzScrollBar;
    CRect		m_rcHorzScrollBarDraggable;
    CRect		m_rcHorzScrollBarScrollArea;
    CRect		m_rcHorzScrollBarScrollAreaRight;
    CRect		m_rcHorzScrollBarScrollAreaLeft;
    CRect		m_rcHorzScrollBarLeftBtn;
    CRect		m_rcHorzScrollBarRightBtn;
    CRect		m_rcVertScrollBarOverall;
    CRect		m_rcVertScrollBar;
    CRect		m_rcVertScrollBarDraggable;
    CRect		m_rcVertScrollBarScrollArea;
    CRect		m_rcVertScrollBarScrollAreaTop;
    CRect		m_rcVertScrollBarScrollAreaBottom;
    CRect		m_rcVertScrollBarTopBtn;
    CRect		m_rcVertScrollBarBottomBtn;
    CRect		m_rcTotalLeftColumnBar;
    CRect		m_rcRowsColumnsLogicalSize;
    CRect		m_rcTitleBarMinimizeBtn;
    CRect		m_rcPictureViewImage;
    CRect		m_rcPictureViewText;
};

#define foRICHTEXT_DRAW_TEXT	0
#define foRICHTEXT_SIZE			1
#define foRICHTEXT_RECALCULATE	2

// This macro is similar to the MFC <f ASSERT_NULL_OR_POINTER> macro
// except it calls <mf CObject::IsKindOf> to make sure the pointer
// is of the correct type..
#define FO_IsKindOf(p, class_name) (p)->IsKindOf(RUNTIME_CLASS(class_name))

//
// This template method are a debug version of static_cast. In a
// debug build, they have an ASSERT to make sure that the cast is safe.
//

template <class TYPE, class INPUT_TYPE>
_FOLIB_INLINE TYPE ucc_cast(INPUT_TYPE * pObject)
{
	ASSERT((pObject == NULL) || dynamic_cast<TYPE>(pObject) != NULL);

	return(static_cast<TYPE>(pObject));
}

// define 2PI, PI, PI/2 and PI/4 if they have not been defined yet. A
// few compilers don't seem to be fully compliant with ANSI C and
// don't provide certain ANSI C macros.

#ifndef F_PI
#define F_PI	3.141592653589793238426433832795
#endif
#ifndef F_PI2
#define F_PI2   1.57079632679489661923
#endif
#ifndef F_PI4
#define F_PI4   0.785398163397448309616
#endif
#ifndef F_PI180
#define F_PI180   0.01745329251994
#endif
#ifndef F_PI1800
#define F_PI1800  0.001745329251994
#endif
#ifndef F_PI18000
#define F_PI18000 0.000174532925199432957692222
#endif
#ifndef F_2PI
#define F_2PI   6.28318530717958647694
#endif

#if (_MSC_VER <= 1200) && !defined(_WIN64)

//------------------------------
// Windows 64 bit compatibility:
//------------------------------

#ifndef GetClassLongPtr
#define GetClassLongPtr		GetClassLong
#endif

#ifndef SetClassLongPtr
#define SetClassLongPtr		SetClassLong
#endif

#ifndef SetWindowLongPtr
#define SetWindowLongPtr	SetWindowLong
#endif

#ifndef GetWindowLongPtr
#define GetWindowLongPtr	GetWindowLong
#endif

// IA64 Macros:
#ifndef DWORD_PTR
#define DWORD_PTR DWORD
#endif

#ifndef UINT_PTR
#define UINT_PTR UINT
#endif

#ifndef INT_PTR
#define INT_PTR int
#endif

#ifndef ULONG_PTR
#define ULONG_PTR ULONG
#endif

#ifndef LONG_PTR
#define LONG_PTR long
#endif

#ifndef GWLP_WNDPROC
#define	GWLP_WNDPROC		GWL_WNDPROC
#endif

#ifndef GCLP_HICON
#define	GCLP_HICON			GCL_HICON
#endif

#ifndef GCLP_HICONSM
#define	GCLP_HICONSM		GCL_HICONSM
#endif

#ifndef GCLP_MENUNAME
#define GCLP_MENUNAME       (-8)
#endif

#ifndef GCLP_HCURSOR
#define GCLP_HCURSOR        (-12)
#endif

#ifndef GCLP_HBRBACKGROUND
#define GCLP_HBRBACKGROUND	GCL_HBRBACKGROUND
#endif

#ifndef GCLP_HMODULE
#define GCLP_HMODULE        (-16)
#endif

#ifndef GWLP_HINSTANCE
#define GWLP_HINSTANCE      (-6)
#endif

#ifndef GWLP_HWNDPARENT
#define GWLP_HWNDPARENT     (-8)
#endif

#ifndef GWLP_USERDATA
#define GWLP_USERDATA       (-21)
#endif

#ifndef GWLP_ID
#define GWLP_ID             (-12)
#endif

#endif // _MSC_VER

#if (_MSC_VER > 1200) && !defined(_WIN64)

#ifdef SetWindowLongPtrA
#undef SetWindowLongPtrA
inline LONG_PTR SetWindowLongPtrA( HWND hWnd, int nIndex, LONG_PTR dwNewLong )
{
	return( ::SetWindowLongA( hWnd, nIndex, LONG( dwNewLong ) ) );
}
#endif

#ifdef SetWindowLongPtrW
#undef SetWindowLongPtrW
inline LONG_PTR SetWindowLongPtrW( HWND hWnd, int nIndex, LONG_PTR dwNewLong )
{
	return( ::SetWindowLongW( hWnd, nIndex, LONG( dwNewLong ) ) );
}
#endif

#ifdef GetWindowLongPtrA
#undef GetWindowLongPtrA
inline LONG_PTR GetWindowLongPtrA( HWND hWnd, int nIndex )
{
	return( ::GetWindowLongA( hWnd, nIndex ) );
}
#endif

#ifdef GetWindowLongPtrW
#undef GetWindowLongPtrW
inline LONG_PTR GetWindowLongPtrW( HWND hWnd, int nIndex )
{
	return( ::GetWindowLongW( hWnd, nIndex ) );
}
#endif

#ifdef SetClassLongPtrA
#undef SetClassLongPtrA
inline LONG_PTR SetClassLongPtrA( HWND hWnd, int nIndex, LONG_PTR dwNewLong )
{
	return( ::SetClassLongA( hWnd, nIndex, LONG( dwNewLong ) ) );
}
#endif

#ifdef SetClassLongPtrW
#undef SetClassLongPtrW
inline LONG_PTR SetClassLongPtrW( HWND hWnd, int nIndex, LONG_PTR dwNewLong )
{
	return( ::SetClassLongW( hWnd, nIndex, LONG( dwNewLong ) ) );
}
#endif

#ifdef GetClassLongPtrA
#undef GetClassLongPtrA
inline LONG_PTR GetClassLongPtrA( HWND hWnd, int nIndex )
{
	return( ::GetClassLongA( hWnd, nIndex ) );
}
#endif

#ifdef GetClassLongPtrW
#undef GetClassLongPtrW
inline LONG_PTR GetClassLongPtrW( HWND hWnd, int nIndex )
{
	return( ::GetClassLongW( hWnd, nIndex ) );
}
#endif

#endif

#define AfxDeferRegisterClass(fClass) AfxEndDeferRegisterClass(fClass)

#if (_MSC_VER <= 1100)
extern BOOL AFXAPI AfxEndDeferRegisterClass(short fClass);
#else
BOOL AFXAPI AfxEndDeferRegisterClass(LONG fToRegister);
#endif

#define AFX_WNDCOMMCTLS_REG             0x00010 // means all original Win95
#define AFX_WNDCOMMCTL_BAR_REG          0x01000
#define AFX_WNDCOMMCTL_USEREX_REG       0x10000
#define AFX_WNDCOMMCTL_DATE_REG         0x20000

#undef SAFE_DELETE
#define SAFE_DELETE(ptr) \
	if (ptr) { delete ptr; ptr = NULL; }

#ifndef CBRS_GRIPPER
#define CBRS_GRIPPER                    0x00400000L
#endif

#ifndef WS_EX_LAYOUTRTL
#define WS_EX_LAYOUTRTL                 0x00400000L
#endif

#ifndef WS_EX_NOACTIVATE
#define WS_EX_NOACTIVATE        		0x08000000L
#endif

#ifndef DT_WORD_ELLIPSIS
#define DT_WORD_ELLIPSIS                0x00040000L
#endif

#if (_MSC_VER >= 1300)
template<> AFX_INLINE UINT AFXAPI HashKey<UINT_PTR>(UINT_PTR key) {
	return (DWORD)(((DWORD_PTR)key)>>4);
}
#endif

#if _MSC_VER >= 1400
#define FOPNcHitTestType	LRESULT
#else
#define FOPNcHitTestType	UINT
#endif

#define FOP_TIMER_ID 1021

// Predefined font point size.
static int nFO_FontDefSizes[] =  {8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72,80,88,96,128,168,272,405,524,624};

#endif _FO_IDDEFINES
