//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMODELPROPACTION_H__2FB05021_C5F1_494B_8E1F_25CB7AFC9B9B__INCLUDED_)
#define AFC_FOMODELPROPACTION_H__2FB05021_C5F1_494B_8E1F_25CB7AFC9B9B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FOAction.h"

//////////////////////////////////////////////
// CFOModelBoolAction -- Defined for BOOL property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelBoolAction class derived from CFOAction
//      F O Model Bool Action
//===========================================================================

class FO_EXT_CLASS CFOModelBoolAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelBoolAction---F O Model Bool Action, Specifies a E-XD++ CFOModelBoolAction object (Value).
	DECLARE_ACTION(CFOModelBoolAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Bool Action, Constructs a CFOModelBoolAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelBoolAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Bool Action, Destructor of class CFOModelBoolAction
	//		Returns A  value (Object).
	~CFOModelBoolAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&bValue---&bValue, Specifies A Boolean value.
	void ChangePropValue(const int &nPropID,const BOOL &bValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member sets TRUE if it is right.  
	BOOL	m_bNewValue;

	// Save old value.
 
	// Old Value, This member sets TRUE if it is right.  
	BOOL	m_bOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelBoolAction::ChangePropValue(const int &nPropID,const BOOL &bValue)
{
	m_nPropId = nPropID;
	m_bNewValue = bValue;
}

//////////////////////////////////////////
// CFOModelIntAction -- Defined for int property value
//////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOModelIntAction class derived from CFOAction
//      F O Model Int Action
//===========================================================================

class FO_EXT_CLASS CFOModelIntAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelIntAction---F O Model Int Action, Specifies a E-XD++ CFOModelIntAction object (Value).
	DECLARE_ACTION(CFOModelIntAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Int Action, Constructs a CFOModelIntAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelIntAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Int Action, Destructor of class CFOModelIntAction
	//		Returns A  value (Object).
	~CFOModelIntAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;


	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&nValue---&nValue, Specifies A integer value.
	void ChangePropValue(const int &nPropID,const int &nValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nNewValue;

	// Save old value.
 
	// Old Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int	m_nOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelIntAction::ChangePropValue(const int &nPropID,const int &nValue)
{
	m_nPropId = nPropID;
	m_nNewValue = nValue;
}


//////////////////////////////////////////////
// CFOModelStringAction -- action that defined for String property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelStringAction class derived from CFOAction
//      F O Model String Action
//===========================================================================

class FO_EXT_CLASS CFOModelStringAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelStringAction---F O Model String Action, Specifies a E-XD++ CFOModelStringAction object (Value).
	DECLARE_ACTION(CFOModelStringAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model String Action, Constructs a CFOModelStringAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelStringAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model String Action, Destructor of class CFOModelStringAction
	//		Returns A  value (Object).
	~CFOModelStringAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&strValue---&strValue, Specifies A CString type value.
	void ChangePropValue(const int &nPropID,const CString &strValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strNewValue;

	// Save old value.
 
	// Old Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelStringAction::ChangePropValue(const int &nPropID,const CString &strValue)
{
	m_nPropId = nPropID;
	m_strNewValue = strValue;
}


//////////////////////////////////////////////
// CFOModelFloatAction -- action that defined for float property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelFloatAction class derived from CFOAction
//      F O Model Float Action
//===========================================================================

class FO_EXT_CLASS CFOModelFloatAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelFloatAction---F O Model Float Action, Specifies a E-XD++ CFOModelFloatAction object (Value).
	DECLARE_ACTION(CFOModelFloatAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Float Action, Constructs a CFOModelFloatAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelFloatAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Float Action, Destructor of class CFOModelFloatAction
	//		Returns A  value (Object).
	~CFOModelFloatAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&fValue---&fValue, Specifies A float value.
	void ChangePropValue(const int &nPropID,const float &fValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fNewValue;

	// Save old value.
 
	// Old Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float	m_fOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelFloatAction::ChangePropValue(const int &nPropID,const float &fValue)
{
	m_nPropId = nPropID;
	m_fNewValue = fValue;
}


//////////////////////////////////////////////
// CFOModelDoubleAction -- action that defined for double property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelDoubleAction class derived from CFOAction
//      F O Model Double Action
//===========================================================================

class FO_EXT_CLASS CFOModelDoubleAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelDoubleAction---F O Model Double Action, Specifies a E-XD++ CFOModelDoubleAction object (Value).
	DECLARE_ACTION(CFOModelDoubleAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Double Action, Constructs a CFOModelDoubleAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelDoubleAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Double Action, Destructor of class CFOModelDoubleAction
	//		Returns A  value (Object).
	~CFOModelDoubleAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void ChangePropValue(const int &nPropID,const double &dValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify double object.  
	double	m_dNewValue;

	// Save old value.
 
	// Old Value, This member specify double object.  
	double	m_dOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelDoubleAction::ChangePropValue(const int &nPropID,const double &dValue)
{
	m_nPropId = nPropID;
	m_dNewValue = dValue;
}

//////////////////////////////////////////////
// CFOModelDWordAction -- action that defined for DWORD property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelDWordAction class derived from CFOAction
//      F O Model D Word Action
//===========================================================================

class FO_EXT_CLASS CFOModelDWordAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelDWordAction---F O Model D Word Action, Specifies a E-XD++ CFOModelDWordAction object (Value).
	DECLARE_ACTION(CFOModelDWordAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model D Word Action, Constructs a CFOModelDWordAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelDWordAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model D Word Action, Destructor of class CFOModelDWordAction
	//		Returns A  value (Object).
	~CFOModelDWordAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dwValue---&dwValue, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void ChangePropValue(const int &nPropID,const DWORD &dwValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwNewValue;

	// Save old value.
 
	// Old Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD	m_dwOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelDWordAction::ChangePropValue(const int &nPropID,const DWORD &dwValue)
{
	m_nPropId = nPropID;
	m_dwNewValue = dwValue;
}


//////////////////////////////////////////////
// CFOModelDateTimeAction -- action that defined for date time property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelDateTimeAction class derived from CFOAction
//      F O Model Date Time Action
//===========================================================================

class FO_EXT_CLASS CFOModelDateTimeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelDateTimeAction---F O Model Date Time Action, Specifies a E-XD++ CFOModelDateTimeAction object (Value).
	DECLARE_ACTION(CFOModelDateTimeAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Date Time Action, Constructs a CFOModelDateTimeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelDateTimeAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Date Time Action, Destructor of class CFOModelDateTimeAction
	//		Returns A  value (Object).
	~CFOModelDateTimeAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&dtValue---&dtValue, Specifies a const COleDateTime &dtValue object(Value).
	void ChangePropValue(const int &nPropID,const COleDateTime &dtValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member specify COleDateTime object.  
	COleDateTime	m_dtNewValue;

	// Save old value.
 
	// Old Value, This member specify COleDateTime object.  
	COleDateTime	m_dtOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelDateTimeAction::ChangePropValue(const int &nPropID,const COleDateTime &dtValue)
{
	m_nPropId = nPropID;
	m_dtNewValue = dtValue;
}


//////////////////////////////////////////////
// CFOModelColorAction -- action that defined for color property value.
/////////////////////////////////////////////
 
//===========================================================================
// Summary:
//     The CFOModelColorAction class derived from CFOAction
//      F O Model Color Action
//===========================================================================

class FO_EXT_CLASS CFOModelColorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOModelColorAction---F O Model Color Action, Specifies a E-XD++ CFOModelColorAction object (Value).
	DECLARE_ACTION(CFOModelColorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model Color Action, Constructs a CFOModelColorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOModelColorAction(CFODataModel* pModel);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model Color Action, Destructor of class CFOModelColorAction
	//		Returns A  value (Object).
	~CFOModelColorAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Change prop value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Property Value, .
	// Parameters:
	//		&nPropID---Property I D, Specifies A integer value.  
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void ChangePropValue(const int &nPropID,const COLORREF &crValue);


public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	//TODO:Add your code here.
	// New value.
 
	// New Value, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crNewValue;

	// Save old value.
 
	// Old Value, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crOldValue;

	// Prop id.
 
	// Property Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nPropId;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOModelColorAction::ChangePropValue(const int &nPropID,const COLORREF &crValue)
{
	m_nPropId = nPropID;
	m_crNewValue = crValue;
}

#endif // !defined(AFC_FOMODELPROPACTION_H__2FB05021_C5F1_494B_8E1F_25CB7AFC9B9B__INCLUDED_)
