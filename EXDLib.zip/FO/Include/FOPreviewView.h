//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPREVIEWVIEW_H__3D49260A_925F_425A_A656_BA17A29ACFA9__INCLUDED_)
#define AFX_FOPREVIEWVIEW_H__3D49260A_925F_425A_A656_BA17A29ACFA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPreviewView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPreviewView window
#include "FOImageButton.h"
#include <afxpriv.h>		// MFC support for docking windows
#include "FOGlobals.h"
#include "FOPFlatComboBox.h"

class CFODrawView;
class CFOExtView;
class CFOPCanvasCore;

// Print preview.
FO_API_DECL void AFX_API FOPrintPreview(CView* pView);

 
//===========================================================================
// Summary:
//     The CFOPreviewView class derived from CPreviewView
//      F O Preview View
//===========================================================================

class FO_EXT_CLASS CFOPreviewView : public CPreviewView
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPreviewView---F O Preview View, Specifies a E-XD++ CFOPreviewView object (Value).
    DECLARE_DYNCREATE(CFOPreviewView)

protected:
    
    // Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Preview View, Constructs a CFOPreviewView object.
	//		Returns A  value (Object).
    CFOPreviewView();

    // Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Preview View, Destructor of class CFOPreviewView
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPreviewView();

    //{{AFX_VIRTUAL(CFOPreviewView)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
    //}}AFX_VIRTUAL

    //{{AFX_MSG(CFOPreviewView)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Number Page Change, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
    afx_msg void OnUpdateNumPageChange(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Pagesetup Button, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPagesetupButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Pagesetup Button, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPagesetupButton(CCmdUI* pCmdUI);
    //}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create Bar, Called as a part of window creation.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCreateBar(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()

public:
	// Refresh the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh View, .

	void RefreshView();

protected:

    // Print button.
 
	// Button Print, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnPrint;

	// Next page button.
 
	// Button Next, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnNext;

	// Previous page button.
 
	// Button Previous, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnPrevious;

	// Page change
 
	// Button Pages, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnPages;

	// zoom in button
 
	// Button Zoom In, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnZoomIn;

	// Zoom out button
 
	// Button Zoom Out, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnZoomOut;

	// Close button.
 
	// Button Close, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_BtnClose;

	// Page setup button.
 
	// Button Setup, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton m_BtnSetup;

	// Image list.
 
	// List, This member is a collection of same-sized images.  
	CImageList		m_imgList;

	// Flat combo box
 
	// Size Combo, This member specify E-XD++ CFOPFlatComboBox object.  
	CFOPFlatComboBox	m_SizeCombo;

	// Enum printers
 
	// Printer , This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CFOEnumPrinters		m_PrinterControl;

	// Obtain the default printer name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Printer1, Returns the specified value.
	//		Returns a CString type value.
	CString				GetDefaultPrinter1();

 
	// F O Draw View, This member specify friend class object.  
	friend class CFODrawView;
 
	// F O Extend View, This member specify friend class object.  
	friend class CFOExtView;
};
/////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOPPreviewDialogBar class derived from CDialogBar
//      F O P Preview Dialog Bar
//===========================================================================

class FO_EXT_CLASS CFOPPreviewDialogBar : public CDialogBar
{

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Preview Dialog Bar, Constructs a CFOPPreviewDialogBar object.
	//		Returns A  value (Object).
	CFOPPreviewDialogBar();

public:
	
	// pointer of the view
 
	// View, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore *m_pView;

	// pointer of the preview.
 
	// Preview, This member maintains a pointer to the object CFOPreviewView.  
	CFOPreviewView *m_pPreview;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Bar, Call this member function to update the object.

	void UpdateBar();
 
	// Landscape, This member sets TRUE if it is right.  
	BOOL		m_bLandscape;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPreviewDialogBar)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Preview Dialog Bar, Destructor of class CFOPPreviewDialogBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPreviewDialogBar();

	// Generated message map functions
protected:

	//{{AFX_MSG(CFOPPreviewDialogBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change Fop Printers Combobox, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeFopPrintersCombobox();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Pagesetup Button, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPagesetupButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Check Landscape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCheckLandscape();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPREVIEWVIEW_H__3D49260A_925F_425A_A656_BA17A29ACFA9__INCLUDED_)
