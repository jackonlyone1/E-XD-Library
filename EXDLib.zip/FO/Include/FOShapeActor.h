//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOShapeActor.h: interface for the CFOShapeActor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSHAPEACTOR_H__971B27D4_F28B_11DD_A434_525400EA266C__INCLUDED_)
#define AFX_FOSHAPEACTOR_H__971B27D4_F28B_11DD_A434_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODrawShape.h"
#include "FOGlobals.h"

class CFOShapeActor;

// List of actor shapes.
typedef CTypedPtrList<CObList, CFOShapeActor*> CFOShapeActorList;

////////////////////////////////////////////////////////////////
// CFOShapeActorSet -- shape actor set.

 
//===========================================================================
// Summary:
//     The CFOShapeActorSet class derived from FOPContainer
//      F O Shape Actor Set
//===========================================================================

class FO_EXT_CLASS CFOShapeActorSet : public FOPContainer
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Actor Set, Constructs a CFOShapeActorSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFOShapeActorSet(int nInit = 32, int nTotal = 32) : FOPContainer(1024, nInit, nTotal)	{}

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Actor Set, Destructor of class CFOShapeActorSet
	//		Returns A  value (Object).
    ~CFOShapeActorSet();
public:

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object CObject,or NULL if the call failed
	CObject* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddHead(CObject* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the CObject or NULL if the call failed.
	void AddTail(CObject* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOShapeActorSet or NULL if the call failed.
	void AddHead(CFOShapeActorSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOShapeActorSet or NULL if the call failed.
	void AddTail(CFOShapeActorSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();
};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOShapeActor -- actor of shape
//
// This class is defined for tracking shapes on the canvas.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOShapeActor class derived from CObject
//      F O Shape Actor
//===========================================================================

class FO_EXT_CLASS CFOShapeActor : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeActor---F O Shape Actor, Specifies a E-XD++ CFOShapeActor object (Value).
	DECLARE_SERIAL(CFOShapeActor)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	// pShape -- point of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Actor, Constructs a CFOShapeActor object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOShapeActor(CFODrawShape* pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Actor, Destructor of class CFOShapeActor
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOShapeActor();

public:

	// Track the shape,this method draws the tracking line of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawTrack(CDC* pDC);

	// Track the shape,this method draws the tracking line of the shape of moving only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Move Track, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawMoveTrack(CDC* pDC);

	// Track the form,this method draws the tracking line of the form
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Form, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawTrackForm(CDC* pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serializes the data to the file.
	virtual void Serialize(CArchive& ar);

public:

	// Set shape,change the shape of the actor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOShapeActor
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	void SetShape(CFODrawShape* pShape);

	// Obtain the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	CFODrawShape* GetShape();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes
protected:

	// Shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	
};

// Obtain the pointer of the shape
_FOLIB_INLINE CFODrawShape* CFOShapeActor::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFX_FOSHAPEACTOR_H__971B27D4_F28B_11DD_A434_525400EA266C__INCLUDED_)
