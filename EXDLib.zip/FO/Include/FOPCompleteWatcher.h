//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCOMPLETEWATCHER_H__415CB716_06A4_4918_AD0E_71E2E557AC76__INCLUDED_)
#define AFX_FOPCOMPLETEWATCHER_H__415CB716_06A4_4918_AD0E_71E2E557AC76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPCompleteWatcher.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPCompleteWatcher data class

#include "fodefines.h"
#include "FOPSimplePolygon.h"

/////////////////////////////////////////////////////////////////////////////
// FOPSmallData

class FOPCompleteData;
class FOPSmallData;
class FOPCompleteWatcher;
 
//===========================================================================
// Summary:
//      To use a FOPSmallData object, just call the constructor.
//      O P Small Data
//===========================================================================

class FO_EXT_CLASS FOPSmallData
{
public:
	// Constructor.
	// nInitSize -- init size of the data.
	// nDataResize -- resize size of the data
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Small Data, Constructs a FOPSmallData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInitSize---Initial Size, Specifies A integer value.  
	//		nDataResize---Data Resize, Specifies A integer value.
	FOPSmallData(int nInitSize = 4, int nDataResize = 4);

	// Constructor.
	// aData -- data object
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Small Data, Constructs a FOPSmallData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aData---aData, Specifies a const FOPSmallData& aData object(Value).
	FOPSmallData(const FOPSmallData& aData);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Small Data, Destructor of class FOPSmallData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSmallData();

	// Clear all the data within the data buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.

	void ClearAll();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize, .
	// Parameters:
	//		nNewSize---New Size, Specifies A integer value.  
	//		bRemoveOld---Remove Old, Specifies A Boolean value.
	// Resize the data buffer to obtain the new size.
	// nNewSize -- new size of the data buffer.
	// bRemoveOld -- empty the old data buffer.
	void Resize(int nNewSize, BOOL bRemoveOld = TRUE);

	// Insert a new data buffer at a specify position.
	// nPos -- a specify position to inserted.
	// nCount -- count buffer size to be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Alloc Buffer, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	void ReAllocBuffer(int nPos, int nCount);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	// Remove buffer at a specify position.
	// nPos -- a specify position to be removed.
	// nCount -- count buffer size to be removed.
	void Remove(int nPos, int nCount);

public:

	// Array of the points.
 
	// Array Points, This member maintains a pointer to the object FOPVectorData.  
	FOPVectorData*			m_pAryPoints;

	// Array of the old points.
 
	// Old Array Points, This member maintains a pointer to the object FOPVectorData.  
	FOPVectorData*			m_pOldAryPoints;
	
	// Delete the old array or not.
	BOOL					m_bDeleteOldAry : TRUE;

	// Close the polygon or not.
	BOOL					m_bClosed : TRUE;

	// Size of the data buffer.
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nSize;

	// The new resize size of the data buffer.
 
	// Resize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nResize;

	// Total of the points within the buffer.
 
	// Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nPoints;

	// Reference count.
 
	// Reference Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int  					m_nRefCount;

};

/////////////////////////////////////////////////////////////////////////////
// FOPSmallWatcher

 
//===========================================================================
// Summary:
//     The FOPSmallWatcher class derived from CObject
//      O P Small Watcher
//===========================================================================

class FO_EXT_CLASS FOPSmallWatcher : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSmallWatcher---O P Small Watcher, Specifies a FOPSmallWatcher object(Value).
	DECLARE_SERIAL(FOPSmallWatcher);

public:
	// Constructor.
	// nSize -- default size
	// nResize -- resize value
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Small Watcher, Constructs a FOPSmallWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPSmallWatcher(int nSize = 4, int nResize = 4);

	// Constructor.
	// aWatcher -- watcher object
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Small Watcher, Constructs a FOPSmallWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).
	FOPSmallWatcher(const FOPSmallWatcher& aWatcher);

	// Constructor.
	// aSimplePoly -- polygon object.
	// dScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Small Watcher, Constructs a FOPSmallWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimplePoly---Simple Polygon, Specifies a const FOPSimplePolygon& aSimplePoly object(Value).  
	//		dScale---dScale, Specifies a double dScale = 1.0 object(Value).
	FOPSmallWatcher(const FOPSimplePolygon& aSimplePoly, double dScale = 1.0);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Small Watcher, Destructor of class FOPSmallWatcher
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSmallWatcher();

	// Alloc a new buffer for the data.
	// nSize -- size of the buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Buffer,  Alloc the specify space for this object.
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void AllocBuffer(int nSize);

	// Obtain the size of the data buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.
	int GetSize() const;

	// Set the count of the points within the buffer.
	// nPoints -- total of the points within the buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Count, Sets a specify value to current class FOPSmallWatcher
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.
	void SetPointCount(int nPoints);

	// Obtain the count of the points within the buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count, Returns the specified value.
	//		Returns a int type value.
	int GetPointCount() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	// Remove buffer at a specify position.
	// nPos -- a specify position to be removed.
	// nCount -- count buffer size to be removed.
	void Remove(int nPos, int nCount);

	// Operator []
	// nPos -- specify index
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPVectorData& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPVectorData&	operator[](int nPos) const;

	// Operator []
	// nPos -- specify index
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPVectorData& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	FOPVectorData& operator[](int nPos);

	// Operator =
	// aWatcher -- watcher object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSmallWatcher& value (Object).  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).
	FOPSmallWatcher& operator= (const FOPSmallWatcher& aWatcher);

	// Operator ==
	// aWatcher -- watcher object for comparing
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).
	BOOL operator==(const FOPSmallWatcher& aWatcher) const;

	// Operator !=
	// aWatcher -- watcher object for comparing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).
	BOOL operator!=(const FOPSmallWatcher& aWatcher) const;

	// Check if it is the correct value.
	// rNormal -- compare data object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Correct, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rNormal---&rNormal, Specifies a const FOPVectorData &rNormal object(Value).
	BOOL IsCorrect(const FOPVectorData &rNormal) const;

	// Check if it is the correct value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Correct, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCorrect() const { FOPVectorData aNrm(0.0, 0.0, 1.0); return IsCorrect(aNrm); }

	// Obtain the vector data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal, Returns the specified value.
	//		Returns A FOPVectorData value (Object).
	FOPVectorData GetNormal() const;

	// Do shape's flip operator..
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flip, Do a event. 

	void DoFlip();

	// Is the polygon data closed or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClosed() const;

	// Close the polygon.
	// bNew -- new close or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Closed, Sets a specify value to current class FOPSmallWatcher
	// Parameters:
	//		bNew---bNew, Specifies A Boolean value.
	void SetClosed(BOOL bNew);

	// Remove the same points within the data buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Same, Call this function to remove a specify value from the specify object.

	void RemoveSame();

	// Is vector inside the polygon.
	// ptHit -- hit test point
	// bWithBorder -- check with border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inside, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies a const FOPVectorData& ptHit object(Value).  
	//		bWithBorder---With Border, Specifies A Boolean value.
	BOOL IsInside(const FOPVectorData& ptHit, BOOL bWithBorder=FALSE) const;

	// Is vector inside the polygon.
	// aWatcher --data watcher
	// bWithBorder -- check with border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inside, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).  
	//		bWithBorder---With Border, Specifies A Boolean value.
	BOOL IsInside(const FOPSmallWatcher& aWatcher, BOOL bWithBorder=TRUE) const;

	// Obtain the simple polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Simple Polygon, Returns the specified value.
	//		Returns A FOPSimplePolygon value (Object).
	FOPSimplePolygon GetSimplePolygon() const;

	// Obtain the polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon, Returns the specified value.
	//		Returns A FOPPolygon value (Object).
	FOPPolygon GetPolygon() const;

	// Obtain the length of the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns A double value (Object).
	double GetLength() const;

	// Do search cut point within the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Search Cut, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		nEdge1---nEdge1, Specifies A integer value.  
	//		nEdge2---nEdge2, Specifies A integer value.  
	//		nCutFlags---Cut Flags, Specifies A integer value.  
	//		pCut1---pCut1, A pointer to the double or NULL if the call failed.  
	//		pCut2---pCut2, A pointer to the double or NULL if the call failed.
	int DoSearchCut(int nEdge1, int nEdge2, 
		int nCutFlags = FOP_SPLIT_DEFAULT, 
		double* pCut1 = 0L, double* pCut2 = 0L) const;

	// Do search cut point within the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Search Cut, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		nEdge1---nEdge1, Specifies A integer value.  
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).  
	//		nEdge2---nEdge2, Specifies A integer value.  
	//		nCutFlags---Cut Flags, Specifies A integer value.  
	//		pCut1---pCut1, A pointer to the double or NULL if the call failed.  
	//		pCut2---pCut2, A pointer to the double or NULL if the call failed.
	int DoSearchCut(int nEdge1, const FOPSmallWatcher& aWatcher, int nEdge2,
		int nCutFlags = FOP_SPLIT_DEFAULT, 
		double* pCut1 = 0L, double* pCut2 = 0L) const;

	// Do search cut point within the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Search Cut, Do a event. 
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		aEdge1Start---Edge1 Start, Specifies a const FOPVectorData& aEdge1Start object(Value).  
	//		aEdge1Delta---Edge1 Delta, Specifies a const FOPVectorData& aEdge1Delta object(Value).  
	//		aEdge2Start---Edge2 Start, Specifies a const FOPVectorData& aEdge2Start object(Value).  
	//		aEdge2Delta---Edge2 Delta, Specifies a const FOPVectorData& aEdge2Delta object(Value).  
	//		nCutFlags---Cut Flags, Specifies A integer value.  
	//		pCut1---pCut1, A pointer to the double or NULL if the call failed.  
	//		pCut2---pCut2, A pointer to the double or NULL if the call failed.
	static int DoSearchCut(
		const FOPVectorData& aEdge1Start, const FOPVectorData& aEdge1Delta,
		const FOPVectorData& aEdge2Start, const FOPVectorData& aEdge2Delta,
		int nCutFlags = FOP_SPLIT_DEFAULT,
		double* pCut1 = 0L, double* pCut2 = 0L);

	// Do search cut point within the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Point In Line, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.  
	//		aEdgeStart---Edge Start, Specifies a const FOPVectorData& aEdgeStart object(Value).  
	//		aEdgeDelta---Edge Delta, Specifies a const FOPVectorData& aEdgeDelta object(Value).  
	//		pCut---pCut, A pointer to the double or NULL if the call failed.
	static BOOL FindPointInLine(const FOPVectorData& ptPoint,
		const FOPVectorData& aEdgeStart, const FOPVectorData& aEdgeDelta, 
		double* pCut = 0L);

	// Correct reference value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Reference, .

	void CorrectRef();

	// Obtain the best fit edge.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Best Edge, Returns the specified value.
	//		Returns a int type value.
	int GetBestEdge() const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of the data.
 
	// Small Data, This member maintains a pointer to the object FOPSmallData.  
	FOPSmallData*				m_pSmallData;

};

/////////////////////////////////////////////////////////////////////////////
// FOPCompleteWatcher

 
//===========================================================================
// Summary:
//     The FOPCompleteWatcher class derived from CObject
//      O P Complete Watcher
//===========================================================================

class FO_EXT_CLASS FOPCompleteWatcher : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPCompleteWatcher---O P Complete Watcher, Specifies a FOPCompleteWatcher object(Value).
	DECLARE_SERIAL(FOPCompleteWatcher);

public:

	// Constructor.
	// nInitSize -- init size of the watcher.
	// nResize -- resize value of the watcher
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complete Watcher, Constructs a FOPCompleteWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInitSize---Initial Size, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPCompleteWatcher(int nInitSize = 4, int nResize = 4);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complete Watcher, Constructs a FOPCompleteWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).
	FOPCompleteWatcher(const FOPSmallWatcher& aWatcher);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complete Watcher, Constructs a FOPCompleteWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aWatcherPoly---Watcher Polygon, Specifies a const FOPCompleteWatcher& aWatcherPoly object(Value).
	FOPCompleteWatcher(const FOPCompleteWatcher& aWatcherPoly);

	// Constructor.
	// aSimplePoly -- simple polygon object
	// dScale -- scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complete Watcher, Constructs a FOPCompleteWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimplePoly---Simple Polygon, Specifies a const FOPSimplePolygon& aSimplePoly object(Value).  
	//		dScale---dScale, Specifies a double dScale = 1.0 object(Value).
	FOPCompleteWatcher(const FOPSimplePolygon& aSimplePoly, double dScale = 1.0);

	// Constructor.
	// aSimpleCompPoly -- simple composite polygon object.
	// dScale -- scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Complete Watcher, Constructs a FOPCompleteWatcher object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimpleCompPoly---Simple Component Polygon, Specifies a const FOPSimpleCompositePolygon& aSimpleCompPoly object(Value).  
	//		dScale---dScale, Specifies a double dScale = 1.0 object(Value).
	FOPCompleteWatcher(const FOPSimpleCompositePolygon& aSimpleCompPoly, double dScale = 1.0);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Complete Watcher, Destructor of class FOPCompleteWatcher
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPCompleteWatcher();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPCompleteWatcher& aWatcher object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Insert a new complete watcher at a specify position.
	// aWatcher -- complete watcher object.
	// nPos -- insert position
	void Insert(const FOPCompleteWatcher& aWatcher, int nPos = 0xFFFF);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns A FOPSmallWatcher value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	// Remove a complete watcher at a specify position.
	// nPos -- specify position that to be removed.
	FOPSmallWatcher Remove(int nPos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns A FOPSmallWatcher value (Object).  
	// Parameters:
	//		aWatcher---aWatcher, Specifies a const FOPSmallWatcher& aWatcher object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Replace a watcher at a specify position.
	// aWatcher -- specify object that replaced with.
	// nPos -- replace position.
	FOPSmallWatcher Replace(const FOPSmallWatcher& aWatcher, int nPos);

	// Obtain the object of the watcher at specify position.
	// nPos -- specify position to be obtained.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns A const FOPSmallWatcher& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPSmallWatcher& GetObject(int nPos) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data within the buffer.
	void Clear();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Count, .
	//		Returns a int type value.
	// Obtain the count of the data within the buffer.
	int Count() const;

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPSmallWatcher& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPSmallWatcher& operator[](int nPos) const { return GetObject(nPos); }

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSmallWatcher& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	FOPSmallWatcher& operator[](int nPos);

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPCompleteWatcher& value (Object).  
	// Parameters:
	//		aCompleteWatcher---Complete Watcher, Specifies a const FOPCompleteWatcher& aCompleteWatcher object(Value).
	FOPCompleteWatcher& operator=(const FOPCompleteWatcher& aCompleteWatcher);

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompleteWatcher---Complete Watcher, Specifies a const FOPCompleteWatcher& aCompleteWatcher object(Value).
	BOOL operator==(const FOPCompleteWatcher& aCompleteWatcher) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompleteWatcher---Complete Watcher, Specifies a const FOPCompleteWatcher& aCompleteWatcher object(Value).
	BOOL operator!=(const FOPCompleteWatcher& aCompleteWatcher) const;

	// Do flip action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Flips, Do a event. 

	void DoFlips();

	// Change the vector data.
	// rNormal -- data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Vector Data, Sets a specify value to current class FOPCompleteWatcher
	// Parameters:
	//		rNormal---rNormal, Specifies a const FOPVectorData& rNormal object(Value).
	void SetVectorData(const FOPVectorData& rNormal);

	// Remove the double value within the data buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Same, Call this function to remove a specify value from the specify object.

	void RemoveSame();

	// Remove hole polygons.
	// bRemoveHoles -- remove holes or not.
	// bWithBorder -- check with border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Contained Polygons, Call this function to remove a specify value from the specify object.
	//		Returns a int type value.  
	// Parameters:
	//		bRemoveHoles---Remove Holes, Specifies A Boolean value.  
	//		bWithBorder---With Border, Specifies A Boolean value.
	int RemoveContainedPolygons(BOOL bRemoveHoles=FALSE, BOOL bWithBorder=TRUE);

	// Obtain the simple composite polygon object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get S Component Polygon, Returns the specified value.
	//		Returns A FOPSimpleCompositePolygon value (Object).
	FOPSimpleCompositePolygon GetSCompPolygon() const;

	// Obtain the composite polygon object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon Polygon, Returns the specified value.
	//		Returns A FOPPolyPolygon value (Object).
	FOPPolyPolygon GetPolyPolygon() const;

	// Do merge action
	// bUserCloseWise-- clock wise.
	// bInvert -- invert or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Merge, Do a event. 
	// Parameters:
	//		bUseClockwise---Use Clockwise, Specifies A Boolean value.  
	//		bInvert---bInvert, Specifies A Boolean value.
	void DoMerge(BOOL bUseClockwise = TRUE, BOOL bInvert = FALSE);

	// Check the reference value of the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Reference, .

	void CorrectRef();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of the data buffer.
 
	// Complete Data, This member maintains a pointer to the object FOPCompleteData.  
	FOPCompleteData*			m_pCompleteData;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCOMPLETEWATCHER_H__415CB716_06A4_4918_AD0E_71E2E557AC76__INCLUDED_)
