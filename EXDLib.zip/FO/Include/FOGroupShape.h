//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOGROUPSHAPE_H__FC765E81_C623_11D5_A487_525400EA266C__INCLUDED_)
#define AFC_FOGROUPSHAPE_H__FC765E81_C623_11D5_A487_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FOStaticShape.h"
#include "FOEditBoxShape.h"
#include "FOInsideBaseShape.h"
#include "FOPCollect.h"
#include "FOCompositeShape.h"

//////////////////////////////////////////////////////////////
// CFOGroupShape -- group shape, it is designed for Group / Ungroup event. ID: FO_COMP_GROUP 89

 
//===========================================================================
// Summary:
//     The CFOGroupShape class derived from CFOCompositeShape
//      F O Group Shape
//===========================================================================

class FO_EXT_CLASS CFOGroupShape : public CFOCompositeShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOGroupShape---F O Group Shape, Specifies a E-XD++ CFOGroupShape object (Value).
	DECLARE_SERIAL(CFOGroupShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Group Shape, Constructs a CFOGroupShape object.
	//		Returns A  value (Object).
	CFOGroupShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Group Shape, Constructs a CFOGroupShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGroupShape& src object(Value).
	CFOGroupShape(const CFOGroupShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Group Shape, Destructor of class CFOGroupShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOGroupShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOGroupShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the group shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));


	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOGroupShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOGroupShape& src object(Value).
	CFOGroupShape& operator=(const CFOGroupShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
public:
	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Hit test text.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Label, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOStaticShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFOStaticShape *HitTestLabel(const CPoint &ptHit);

	// Hit test child shape,return the pointer of the shape.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Child, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFODrawShape *HitTestChild(const CPoint &ptHit);

	// Hit test edit box.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Edit Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestEditBox(const CPoint& ptHit);

	// Hit test inside box.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test  Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestCtrlBox(const CPoint& ptHit);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Do convert shape to poly or path shape,it will keep all the children shapes.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObjNew(CDC *pDC,const BOOL &bBezier);

	// Change the pointer of the data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOGroupShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFODataModel or NULL if the call failed.
	virtual void SetModel(CFODataModel* pNewModel);

	// Hit test label pos.
	// ptHit -- hit test point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Label Text Position, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual BOOL HitLabelTextPos(const CPoint& ptHit);

	// Recalc font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);

	// Get plus spots
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Is shape within the composite
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Within, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL IsShapeWithin(CFODrawShape* pShape) const;

	// Change IndexForLink value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index For Link, Sets a specify value to current class CFOGroupShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	virtual void SetIndexForLink(int &nValue );

	// Generate all ports indexs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Ports Indexs, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void GenPortsIndexs();

	// Add all shapes to the prepare shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Prepare, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*lShape---*lShape, A pointer to the FOPContainer  or NULL if the call failed.
	virtual void AddToPrepare(FOPContainer *lShape);

	// Add all shapes to the prepare shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Links, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_LinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &m_LinkList object (Value).
	virtual void AddToLinks(CFODrawShapeSet &m_LinkList);

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dCenterX---Center X, Specifies a double &dCenterX object(Value).  
	//		&dCenterY---Center Y, Specifies a double &dCenterY object(Value).
	virtual void GetRotateCenter(double &dCenterX,double &dCenterY) const;

	// Obtain the true center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

public:

	// Define for text.
	
	//SetGroup Text Horz Alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Text Horizontal Alignment, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void	SetGroupTextHorzAlignment(const UINT &nT);

	//SetGroup Text Vertical Alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Text Vertical Alignment, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void	SetGroupTextVertAlignment(const UINT &nT);

	//SetGroup Multi_Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Multiple Line, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void	SetGroupMultiLine(const BOOL &bMulti);

	//SetGroup Object Caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Object Caption, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetGroupObjectCaption(const CString &str);

public:


	//SetGroup Object Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Object Name, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetGroupObjectName(const CString &str);

	//SetGroup Visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Visible, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bV---&bV, Specifies A Boolean value.
	void	SetGroupVisible(const BOOL &bV);
	
	//SetGroup Disabled
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Tab Order Protect, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bD---&bD, Specifies A Boolean value.
	void	SetGroupTabOrderProtect(const BOOL &bD);


	//SetGroup Flat
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Flat, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bF---&bF, Specifies A Boolean value.
	void	SetGroupFlat(const BOOL &bF);
	
	//Lock Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Group Shape, .
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void	LockGroupShape(const BOOL &bL);

	// Draws the flat status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws the 3D status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

public:

	// Define for line.

	//SetGroup Line Width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Line Width, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void	SetGroupLineWidth(const int &nWidth);

	//SetGroup Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Line Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupLineColor(const COLORREF &crColor);

	// Set group null pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Null Pen, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bNull---&bNull, Specifies A Boolean value.
	void	SetGroupNullPen(const BOOL &bNull);

	// Set group pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Pen Style, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nPenStyle---Pen Style, Specifies A integer value.
	void	SetGroupPenStyle(const int &nPenStyle);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxRect();

	// Get max position of track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

public:

	// Put group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Group Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual void PutGroupPropValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Group Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetGroupPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	//Define for font.
	//SetGroup Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Face Name, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void	SetGroupFaceName(LPCTSTR lpszFaceName);

	// Set group font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Point Size, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void	SetGroupPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Set group font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Height, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void	SetGroupHeight(const int &nHeight, CDC* pDC = NULL);

	// Set group font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Font Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupFontColor(const COLORREF &crColor);

	// Set group font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Weight, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void	SetGroupWeight(const int &nWeight);

	// Set group font italic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Italic, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void	SetGroupItalic(const BOOL &bItalic);

	// Set group font underline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Underline, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void	SetGroupUnderline(const BOOL &bUnderline);

	// Set group font strikeout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Strikeout, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void	SetGroupStrikeout(const BOOL &bStrikeout);

public:
	// Define for brush.

	//SetGroup  Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Background Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupBkColor(const COLORREF &crBkColor);

	// SetGroup transparent mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Transparent, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void	SetGroupTransparent(const BOOL &bTransparent);

	// SetGroup brush type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Brush Type, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void	SetGroupBrushType(const int &nType);
	
	// SetGroup brush hatch type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Brush Hatch, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void	SetGroupBrushHatch(const int &nHatch);


	// SetGroup pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Pattern Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupPatternColor(const COLORREF &cr);

	// SetGroup user data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Item Data, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		pData---pData, A pointer to the CObject or NULL if the call failed.
	void SetGroupItemData(CObject* pData);

public:

	// Set the truely properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Bulleted Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnBulletedProperties();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Set the line properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

	// Set the shadow properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Shadow Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnShadowEditProperties();

	// Set the event properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Event Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnEventProperties();

	// Set the truely properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

public:

	// Set wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOGroupShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCanvas---*pCanvas, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pCanvas);

	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
public:

	// Define for shadow brush.
	
	// Set shadow color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetGroupShadowColor(const COLORREF &crColor);

	// Set shadow pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Pattern Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetGroupShadowPatternColor(const COLORREF &crColor);

	// Set Shadow offset x.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Offset X, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&offset---Specifies A integer value.
	void		SetGroupShadowOffsetX(const int &offset);

	
	// Set Shadow offset y.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Offset Y, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&offset---Specifies A integer value.
	void		SetGroupShadowOffsetY(const int &offset);

	// Set shadow brush type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Brush Type, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetGroupShadowBrushType(const UINT &nType);

	// Set shadow burhs hatch.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Brush Hatch, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetGroupShadowBrushHatch(const int &nHatch);

	// Set shadow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetGroupShadow(const BOOL &bHas);

public:
	// Define for bulleted.
	// Set bulleted color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Bulleted Color, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetGroupBulletedColor(const COLORREF &crColor);

	// Set bulleted type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Bulleted Type, Sets a specify value to current class CFOGroupShape
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void SetGroupBulletedType(const int &nType);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get all ports of the list shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search All Ports, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLstPorts---Lst Ports, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&list---Specifies a const CFODrawShapeList &list object(Value).
	virtual void SearchAllPorts(CFODrawShapeList *pLstPorts,const CFODrawShapeList &list);

	// Find port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&strName---&strName, Specifies A CString type value.
	virtual CFOPortShape *FindPortName(const CFODrawShapeList& list,const CString &strName);

	// Check port to link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Full Link, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aShapes---aShapes, Specifies a FOPContainer aShapes object(Value).  
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void RebuildFullLink(const FOPContainer &aShapes,const CFODrawShapeSet& list);

	// Check all links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Link Names, Called this function to empty a previously initialized CFOGroupShape object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&bNeedProp---Need Property, Specifies A Boolean value.
	virtual void ResetLinkNames(const CFODrawShapeList& list, const BOOL &bNeedProp = TRUE);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Dot track
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Dot Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DrawDotBorder(CDC* pDC);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dfOY---O Y, Specifies a double dfOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dfOY);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dfY---dfY, Specifies a double dfY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dfY, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Position shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror with point ref1 and ref2.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// skewing shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewXShape(int nAngle, double dOX, double dOY);

	// skewing shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewYShape(int nAngle, double dOX, double dOY);

	// skewing track shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackXShape(int nAngle, double dOX, double dOY);

	// skewing track shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackYShape(int nAngle, double dOX, double dOY);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Reset update flags.
	virtual void UpdateHardWay();

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Change the layer ID of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer, Sets a specify value to current class CFOGroupShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nLayer---nLayer, Specifies a FOPLayerID nLayer object(Value).
	virtual void   SetLayer(FOPLayerID nLayer);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
public:

	// Get first child.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	CFODrawShape *GetFirstChild(POSITION &pos);

	// Get next child by a specify pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	CFODrawShape *GetNextChild(POSITION &pos);

	// add shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShape(CFODrawShape *pShape);

	// add shape list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void AddShapes(CFODrawShapeList &m_list);

	// remove shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape *pShape);

	// remove shape list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void RemoveShapes(CFODrawShapeList &m_list);

	// remove all shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

};


#endif // !defined(AFC_FOGROUPSHAPE_H__FC765E81_C623_11D5_A487_525400EA266C__INCLUDED_)
