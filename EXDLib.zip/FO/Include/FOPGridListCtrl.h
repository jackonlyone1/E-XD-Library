//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPGRIDLISTCTRL_H__A1F82501_8C7D_4A86_83C6_30ECFD329D24__INCLUDED_)
#define AFX_FOPGRIDLISTCTRL_H__A1F82501_8C7D_4A86_83C6_30ECFD329D24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPGridListCtrl.h : header file
//

#include "FOGlobals.h"
#include "FOPMenuWndImpl.h"

//////////////////////////////////////////////////////////////////
// CFOPGridHeader -- control, this control is defined for this grid like
//				list control only.

 
//===========================================================================
// Summary:
//     The CFOPGridHeader class derived from CHeaderCtrl
//      F O P Grid Header
//===========================================================================

class FO_EXT_CLASS CFOPGridHeader : public CHeaderCtrl
{
 
	// F O P Grid List , This member specify friend class object.  
	friend class CFOPGridListCtrl;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPGridHeader---F O P Grid Header, Specifies a E-XD++ CFOPGridHeader object (Value).
	DECLARE_DYNAMIC(CFOPGridHeader);

protected:

	// Can be resizing or not
 
	// Resizing, This member sets TRUE if it is right.  
	BOOL			m_bResizing;

	// index of sort column
 
	// Sort Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSortCol;

	// Sort order
 
	// Sort Order, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSortOrder;
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructs the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Header, Constructs a CFOPGridHeader object.
	//		Returns A  value (Object).
	CFOPGridHeader();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Grid Header, Destructor of class CFOPGridHeader
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGridHeader();

	
public:

	// Redraw header control in order to show visual hints on sorted column and sort direction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Column, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCol---nCol, Specifies A integer value.  
	//		nSortOrder---Sort Order, Specifies A integer value.
	BOOL SortColumn(int nCol, int nSortOrder);
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPGridHeader)
	//}}AFX_VIRTUAL
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	// Draw items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void  DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	
	//{{AFX_MSG(CFOPGridHeader)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Hdr  Notify, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnHdrCtrlNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
protected:
	// Mouse process method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mouse Process Function, .
	// This member function is a static function.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		nCode---nCode, Specifies A integer value.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	static LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam);

	// Mouse hook
 
	// Mouse Hook, This member specify HHOOK object.  
	static HHOOK m_hMouseHook;

	// Previous mouse moved wnd pointer.
 
	// Previous Mouse Move Window, This member specify HWND object.  
	static HWND m_hwndPrevMouseMoveWnd;           
};

////////////////////////////////////////////////////////////////
// CFOPGridEditBox -- grid like list control's edit box.

 
//===========================================================================
// Summary:
//     The CFOPGridEditBox class derived from CEdit
//      F O P Grid Edit Box
//===========================================================================

class FO_EXT_CLASS CFOPGridEditBox : public CEdit
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPGridEditBox---F O P Grid Edit Box, Specifies a E-XD++ CFOPGridEditBox object (Value).
	DECLARE_DYNAMIC(CFOPGridEditBox);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructs the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid Edit Box, Constructs a CFOPGridEditBox object.
	//		Returns A  value (Object).
	CFOPGridEditBox();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of the object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Grid Edit Box, Destructor of class CFOPGridEditBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGridEditBox();
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.

	// Initializes the object
	//	This function should be called before subclassing an edit control
	void Initialize();
	
	// Set the new window text of this control
	//	This text will only be set during the next OnSize event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Defered Window Text, Sets a specify value to current class CFOPGridEditBox
	// Parameters:
	//		lpszString---lpszString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void SetDeferedWindowText(LPCTSTR lpszString);
	
	// This new position will be used to override every other position
	//	during a OnWindowPosChanging
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window Position, Sets a specify value to current class CFOPGridEditBox
	// Parameters:
	//		pt---Specifies A CPoint type value.
	void SetWindowPos(const CPoint& pt);
	
	// This height will be used to override every other height
	//	during a OnWindowPosChanging
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window Height, Sets a specify value to current class CFOPGridEditBox
	// Parameters:
	//		nHeight---nHeight, Specifies A integer value.
	void SetWindowHeight(int nHeight);
	
	// By setting this additional width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Window Width, .
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void AdjustWindowWidth(int nWidth);
	
	// Get end key
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Key, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bShift---bShift, Specifies A Boolean value.  
	//		bCtrl---bCtrl, Specifies A Boolean value.
	BOOL GetEndKey(UINT& nChar, BOOL& bShift, BOOL& bCtrl);
	
	// sets the flag that specifies the way the size of the control is adjusted
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Fit To Client, Sets a specify value to current class CFOPGridEditBox
	// Parameters:
	//		bFitToClient---Fit To Client, Specifies A Boolean value.
	inline void SetFitToClient(BOOL bFitToClient) { m_bFitToClient=bFitToClient; }
	
	// retrieves the flag that specifies the way the size of the control is adjusted
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fit To Client, Returns the specified value.
	//		Returns inline BOOLvalue, TRUE on success; FALSE otherwise.
	inline BOOL GetFitToClient() const { return m_bFitToClient; }
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPGridEditBox)
	//}}AFX_VIRTUAL

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
		
protected:
	//{{AFX_MSG(CFOPGridEditBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Position Changing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		lpwndpos---A pointer to the WINDOWPOS FAR or NULL if the call failed.
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	
	// End key char
 
	// End Key Char, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nEndKeyChar;

	// right parent border
 
	// Right Parent Border, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nRightParentBorder;

	// fit to client.
 
	// Fit To Client, This member sets TRUE if it is right.  
	BOOL				m_bFitToClient;

	// Defined for window text
 
	// Defered Window Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_sDeferedWindowText;

	// or not
 
	// Defered Window Text, This member sets TRUE if it is right.  
	BOOL				m_bDeferedWindowText;

	// Window position
 
	// Window Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint				m_ptWindowPos;

	// Window pos or not
 
	// Window Position, This member sets TRUE if it is right.  
	BOOL				m_bWindowPos;

	// Window height
 
	// Window Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nWindowHeight;

	// Or not
 
	// Window Height, This member sets TRUE if it is right.  
	BOOL				m_bWindowHeight;

	// offset
 
	// C X Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCXOffset;

	// End key shift
 
	// End Key Shift, This member sets TRUE if it is right.  
	BOOL				m_bEndKeyShift;

	// End key ctrl
 
	// End Key , This member sets TRUE if it is right.  
	BOOL				m_bEndKeyCtrl;

	// Adjust window width or not
 
	// Adjust Window Width, This member sets TRUE if it is right.  
	BOOL				m_bAdjustWindowWidth;
	
};

////////////////////////////////////////////////////////////////
// CFOPGridListCtrl -- this is a grid like list control, you can use it 
//					instead of CListCtrl

 
//===========================================================================
// Summary:
//     The CFOPGridListCtrl class derived from CListCtrl
//      F O P Grid List 
//===========================================================================

class FO_EXT_CLASS CFOPGridListCtrl : public CListCtrl
{
protected:
   
 
	// Grid Pen, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
    CPen				m_GridPen;
 
	// Grid Lines, This member sets TRUE if it is right.  
    BOOL				m_bGridLines;
 
	// Horizontal Grid Lines, This member sets TRUE if it is right.  
    BOOL				m_bHorizontalGridLines;
 
	// Vertical Grid Lines, This member sets TRUE if it is right.  
    BOOL				m_bVerticalGridLines;
 
	// Last Row Was Visible, This member sets TRUE if it is right.  
	BOOL				m_bLastRowWasVisible;
 
	// Initialized, This member sets TRUE if it is right.  
    BOOL				m_bInitialized;
 
	// Sortable, This member sets TRUE if it is right.  
    BOOL				m_bSortable;
 
	// Checkable, This member sets TRUE if it is right.  
    BOOL				m_bCheckable;
 
	// Automatic Edit, This member sets TRUE if it is right.  
    BOOL				m_bAutoEdit;
 
	// Show Select, This member sets TRUE if it is right.  
    BOOL				m_bShowSel;
 
	// Sort Ascending, This member sets TRUE if it is right.  
	BOOL				m_bSortAscending;
    
 
	// Check Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
    UINT				m_nCheckStyle;
 
	// Number Of Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nNumOfCols;
 
	// Image Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int					m_nImageColumn;
 
	// Sort Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nSortCol;

 
	// Selected Rectangle, This member sets a CRect value.  
    CRect				m_SelectedRect;
 
	// Text Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
    CFont				m_TextFont;
 
	// Images, This member is a collection of same-sized images.  
    CImageList			m_stateImages;
    
 
	// Edit, This member specify E-XD++ CFOPGridEditBox object.  
    CFOPGridEditBox		m_gridEdit;
 
	// Click Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint				m_lastClickPos;
 
	// Edit Child Item, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int					m_nEditSubItem;
    
 
	// Editable, This member specify CWordArray object.  
    CWordArray			m_rgbEditable;
 
	// Header, This member specify E-XD++ CFOPGridHeader object.  
    CFOPGridHeader		m_gridHeader;
    
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
    CMenu*				m_pContextMenu;
 
	// Compare Function, This member specify PFNLVCOMPARE object.  
    PFNLVCOMPARE		m_pCompareFunc;
    
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Grid List , Constructs a CFOPGridListCtrl object.
	//		Returns A  value (Object).
	CFOPGridListCtrl();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor of object
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Grid List , Destructor of class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPGridListCtrl();
	
public:

	// Sets text color, text background color and the text font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Grid, Call InitGrid after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitGrid();
	
	// Sets the Grid in an automatic sort mode.  When clicking a header
	// the strings in that column will be sorted
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sortable, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bSortable---bSortable, Specifies A Boolean value.
	BOOL SetSortable(BOOL bSortable = TRUE);

	// whether automatic sorting is supported or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sortable, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetSortable() const;
	
	// Sets the Grid columns to be resized or not through the header
	// bResizing -- resize state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Resizing, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bResizing---bResizing, Specifies A Boolean value.
	BOOL SetResizing(BOOL bResizing = TRUE);
	
	// Resizing or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resizing, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetResizing();
	
	// Compare function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Compare Function, Sets a specify value to current class CFOPGridListCtrl
	// Parameters:
	//		pCompareFunc---Compare Function, Specifies a PFNLVCOMPARE pCompareFunc object(Value).
	void SetGridCompareFunc( PFNLVCOMPARE pCompareFunc );

	// Sorts the contents of the control by sorting a specific column
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Column, .
	//		Returns inline BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nColumn---nColumn, Specifies A integer value.  
	//		bSortAscending---Sort Ascending, Specifies A Boolean value.
	inline BOOL SortColumn(int nColumn, BOOL bSortAscending) 
	{
		m_bSortAscending=bSortAscending;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort Column, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nColumn---nColumn, Specifies A integer value.
		return SortColumn(nColumn);
	}

	// Sort column
	virtual BOOL SortColumn(int nColumn = 0);

	// Get Sort column 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Sort Column, Returns the specified value.
	//		Returns a int type value.
	int GetSortColumn();
	
	// Get columns number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Cols, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetNumCols() const;

	// Rearranges the inserted columns to have an equal width
	// that is equidistant divided within the width of the list ctrl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Equal Width, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL SetEqualWidth();
	

	// The list ctrl can show grid lines with a special color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Lines, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bGridLines---Grid Lines, Specifies A Boolean value.  
	//		LineColor---Line Color, Specifies A 32-bit COLORREF value used as a color value.  
	//		0---Specifies a 0 object(Value).  
	//		0)---Specifies a 0) object(Value).  
	//		bUpdate---bUpdate, Specifies A Boolean value.
	virtual BOOL SetGridLines(BOOL bGridLines = TRUE,
		COLORREF LineColor = RGB(0,0,0), BOOL bUpdate = TRUE);
	
	// Get grid lines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Lines, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bGridLines---Grid Lines, Specifies A Boolean value.  
	//		LineColor---Line Color, Specifies A 32-bit COLORREF value used as a color value.
	virtual BOOL GetGridLines(BOOL& bGridLines, COLORREF& LineColor) const;
	
	// By default both horizontal and vertical grid lines will be shown
	// Make sure the general setting to show grid lines (SetGridLines())
	// is set to true
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Line Orientation, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bHorizontal---bHorizontal, Specifies A Boolean value.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual BOOL SetGridLineOrientation(BOOL bHorizontal = TRUE,
		BOOL bVertical = TRUE);
	
	// Get grid line orientation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Line Orientation, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bHorizontal---bHorizontal, Specifies A Boolean value.  
	//		bVertical---bVertical, Specifies A Boolean value.
	BOOL GetGridLineOrientation(BOOL& bHorizontal, BOOL& bVertical) const;
	
	// Get Current selected selection
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Select, Returns the specified value.
	//		Returns a int type value.
	int GetCurSel() const;

	// Selects or unselects an item(s)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Select, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nSelectionItem---Selection Item, Specifies A integer value.  
	//		bSelect---bSelect, Specifies A Boolean value.
	BOOL SetCurSel(int nSelectionItem, BOOL bSelect = TRUE);

	// Sets selection display mode.  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Select, Sets a specify value to current class CFOPGridListCtrl
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	void SetShowSel(BOOL bShow = TRUE);

	// Get select count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Count, Returns the specified value.
	//		Returns a int type value.
	int GetSelCount() const;
	

	// Is selected or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	BOOL IsSelected( int nItem ) const;
	
	// get focus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Focus, Returns the specified value.
	//		Returns a int type value.
	int GetCurFocus() const;

	// Sets or lose the focus of the specified item
	// Note that at most one item can have focus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Focus, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFocusItem---Focus Item, Specifies A integer value.  
	//		bFocus---bFocus, Specifies A Boolean value.
	BOOL SetCurFocus(int nFocusItem, BOOL bFocus = TRUE);
	
	// Sets a new font to draw the row text with
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Font, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pFont---pFont, A pointer to the CFont or NULL if the call failed.  
	//		bUpdate---bUpdate, Specifies A Boolean value.
	virtual BOOL SetTextFont(CFont* pFont = NULL, BOOL bUpdate = TRUE);
	
	// Sets selection display mode.  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Select Always, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bShowSelAlways---Show Select Always, Specifies A Boolean value.
	virtual BOOL SetShowSelAlways(BOOL bShowSelAlways = TRUE);
	

	// Show select state always or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Select Always, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetShowSelAlways() const;
	
	// Whether to allow multiple selection or not 
	// By default it is not allowed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Selection, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMultiple---bMultiple, Specifies A Boolean value.
	virtual void SetMultipleSelection(BOOL bMultiple = TRUE);
	
	// Is multiple selected or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Selection, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetMultipleSelection() const;
	
	// Whether to allow a subitem of a specified column to be edited or not
	// By default editing is not allowed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Editable, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bEdit---bEdit, Specifies A Boolean value.  
	//		nColumn---nColumn, Specifies A integer value.
	virtual void SetEditable(BOOL bEdit = TRUE, int nColumn = -1);

	// Get column editable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Editable, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nColumn---nColumn, Specifies A integer value.
	BOOL GetEditable(int nColumn) const;
	
	// Sets this control in checkable mode.  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Checkable, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bCheckable---bCheckable, Specifies A Boolean value.
	virtual BOOL SetCheckable(BOOL bCheckable = TRUE);

	// Is checkable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Checkable, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetCheckable() const;
	
	// Change check style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Check Style, Sets a specify value to current class CFOPGridListCtrl
	// Parameters:
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetCheckStyle(UINT nStyle = BS_AUTOCHECKBOX);
	

	// Obtain check style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Check Style, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetCheckStyle() const;

	// Whether this control in in checkable mode.  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Check, Sets a specify value to current class CFOPGridListCtrl
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nCheck---nCheck, Specifies A integer value.
	void SetCheck(int nIndex, int nCheck);
	
	// The present check state of the specified item.  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Check, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	int GetCheck(int nIndex) const;

	// Whether to proceed (TRUE) or abort the check (FALSE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Check, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCheckItem---Check Item, Specifies A integer value.
	virtual BOOL OnCheck(int nCheckItem);

	// Whether to proceed (TRUE) or abort the check (FALSE);
	// The user clicked an item and because this item was selected
	// its check state will change as well
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Check Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nCheckItem---Check Item, Specifies A integer value.  
	//		nCheck---nCheck, Specifies A integer value.
	virtual BOOL OnCheckChange(int nCheckItem, int nCheck);
	
	// Whether it succeeded or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Edit, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bAutoEdit---Automatic Edit, Specifies A Boolean value.
	virtual BOOL SetAutoEdit(BOOL bAutoEdit = TRUE);
	
	// Whether the control is in auto edit mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Automatic Edit, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetAutoEdit() const;
	
	// If successful, a pointer to the CEdit object that is used to edit the item text; 
	//  otherwise NULL.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Edit Label, .
	//		Returns a pointer to the object CEdit,or NULL if the call failed  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	CEdit* EditLabel(int nItem, int nSubItem);
	
	// succeeded or not
	// assigns the column to show the images attached to an item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Column, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nColumnIndex---Column Index, Specifies A integer value.  
	//		bUpdate---bUpdate, Specifies A Boolean value.
	BOOL SetImageColumn(int nColumnIndex, BOOL bUpdate = TRUE);

	// the index of the column where the small icons currently appear
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Column, Returns the specified value.
	//		Returns a int type value.
	int GetImageColumn() const;
	
	// Dialog base units based on the font selected into the DC
	// If no special font selected, calls ::GetDialogBaseUnits()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dialog Base Units, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	DWORD GetDlgBaseUnits(CDC* pDC);
	
	// Whether the last row is completely visible (TRUE)
	//  FALSE is returned when the last row is not visible 
	//  or only partially visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Last Row Visible, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsLastRowVisible() const;

	// This overridable function will be called when the last
	// row of the window was not completely visible before
	// and becomes completely visible now.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Last Row Appear, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLastRowAppear();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	// Called by CDialog::OnDrawItem for an owner drawn listview, for every
	// item that needs redrawing.
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	
	// Ensures that the specified subitem is visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ensure Visible, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		bPartialOK---Partial O K, Specifies A Boolean value.
	BOOL EnsureVisible(int nItem, int nSubItem, BOOL bPartialOK);

	// Converts coordinates to index of item and subitem
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Child Item From Point, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pos---Specifies A CPoint type value.  
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		rect---Specifies A CRect type value.
	BOOL GetSubItemFromPoint(CPoint pos, int& nItem, int& nSubItem, CRect& rect) const;
	
	// Converts index of item and subitem to a rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rectangle From Child Item, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		bIncludeImages---Include Images, Specifies A Boolean value.
	CRect GetRectFromSubItem(int nItem, int nSubItem, BOOL bIncludeImages = FALSE) const;
	
	// The header control of this grid list control
	//  This pointer may be temporary and should not be stored for later use
	//  NULL is returned when no no header control exists
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header , Returns the specified value.
	//		Returns a pointer to the object CHeaderCtrl,or NULL if the call failed
	CHeaderCtrl* GetHeaderCtrl();

	//The handle of the header control of this grid list control
	//  or NULL when no header control exists
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header  Handle, Returns the specified value.
	//		Returns A HWND value (Object).
	HWND GetHeaderCtrlHandle();

	// assigns new context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Context Menu, Attaches this object.
	//		Returns a pointer to the object inline CMenu,or NULL if the call failed  
	// Parameters:
	//		pMenu---pMenu, A pointer to the CMenu or NULL if the call failed.
	inline CMenu* AttachContextMenu(CMenu* pMenu) 
	{
		CMenu* pOldMenu=m_pContextMenu;
		m_pContextMenu=pMenu;
		return pOldMenu;
	}
	
	// Obtain the pointer of context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Context Menu, Returns the specified value.
	//		Returns a pointer to the object inline CMenu,or NULL if the call failed
	inline CMenu* GetContextMenu() { return m_pContextMenu; }
	
	// Retrieves pointer to edit control that will be used to edit 
	// the grid data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Grid Edit , Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPGridEditBox,or NULL if the call failed
	virtual CFOPGridEditBox* GetGridEditCtrl() { return &m_gridEdit; }

	// Search original item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Original Item Data, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		dwItemData---Item Data, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	int FindOriginalItemData(DWORD_PTR dwItemData);
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDumpContext&---Dump Context&, Specifies a CDumpContext& object(Value).
	virtual void Dump(CDumpContext&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif //_DEBUG
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPGridListCtrl)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void PreSubclassWindow();
    //}}AFX_VIRTUAL

protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty, .

	// Empty
	void Empty();

	// Grid compare process
	
	//-----------------------------------------------------------------------
	// Summary:
	// Grid Compare Process Function, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		LPARAM---P A R A M, Specifies A LPARAM value.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	static int CALLBACK GridCompareProc(LPARAM, LPARAM, LPARAM);
	
	// Change check state image list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Check State Image List, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL SetCheckStateImageList();

	// Draw grid lines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Grid Lines, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual BOOL DrawGridLines(CDC* pDC, LPDRAWITEMSTRUCT lpDIS);

	// Change row text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Row Text, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).  
	//		bShowItemSel---Show Item Select, Specifies A Boolean value.
	virtual void SetRowText(LPDRAWITEMSTRUCT lpDIS, BOOL bShowItemSel);

	// Change column item text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Column Item Text, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		sCellText---Cell Text, Specifies A CString type value.  
	//		rectText---rectText, Specifies A CRect type value.  
	//		nJustify---nJustify, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void SetColItemText(CDC* pDC, CString& sCellText, CRect& rectText, 
		UINT nJustify, UINT nFormat=DT_END_ELLIPSIS|DT_NOPREFIX);
	
	// Get extended data state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extended Data State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOP_EUseExtendedData value (Object).
	virtual FOP_EUseExtendedData GetExtendedDataState();

	// Set extended data state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Extended Data State, Sets a specify value to current class CFOPGridListCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		eUseExtendedData---Use Extended Data, Specifies a FOP_EUseExtendedData eUseExtendedData object(Value).
	virtual void SetExtendedDataState(FOP_EUseExtendedData eUseExtendedData);

	// Add extended data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Extended Data, Adds an object to the specify list.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL AddExtendedData();

	// Remove extend data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Extended Data, Call this function to remove a specify value from the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL RemoveExtendedData();

	// Adjust notification
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Notification, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMListView---N M List View, A pointer to the NM_LISTVIEW or NULL if the call failed.
	BOOL AdjustNotification(NM_LISTVIEW* pNMListView);
	
	// Refresh focus item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh Focus Item, .

	void RefreshFocusItem();

	// Refresh select items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh Select Items, .

	void RefreshSelItems();
	
	// Draw image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Image, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rectText---rectText, Specifies A CRect type value.  
	//		iItemID---Item I D, Specifies A integer value.  
	//		bSelected---bSelected, Specifies A Boolean value.
	BOOL DrawImage(CDC* pDC,  CRect& rectText, int iItemID, BOOL bSelected);

	// Change item text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Item Text, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.  
	//		pszText---pszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL ChangeItemText(int nItem, int nSubItem, LPCTSTR pszText);

	// Get original item data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Original Item Data, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	DWORD_PTR GetOriginalItemData(int nItem);

	// Set original item data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Original Item Data, Sets a specify value to current class CFOPGridListCtrl
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		dwData---dwData, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	BOOL SetOriginalItemData(int nItem, DWORD_PTR dwData);
	
	// Check from point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Check Item From Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	int GetCheckItemFromPoint(const CPoint& point) const;

	// Post edit label
	
	//-----------------------------------------------------------------------
	// Summary:
	// Post Edit Label, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	BOOL PostEditLabel(int nItem, int nSubItem);

	// Search next edit item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search Next Edit Item, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nItemOffset---Item Offset, Specifies A integer value.  
	//		nSubItemOffset---Child Item Offset, Specifies A integer value.  
	//		nItem---nItem, Specifies A integer value.  
	//		nSubItem---Child Item, Specifies A integer value.
	BOOL SearchNextEditItem(int nItemOffset, int nSubItemOffset, int& nItem, int& nSubItem);
	
	// Send GL notification
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send G L Notification, .
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		pNMGL---N M G L, Specifies a LPNM_FOP_GRIDLIST pNMGL object(Value).
	LRESULT SendGLNotification(LPNM_FOP_GRIDLIST pNMGL);
	
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPGridListCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Insert Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnInsertItem(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Insert Column, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnInsertColumn(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete Column, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteColumn(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete All Items, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteAllItems(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteItem(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Find Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnFindItem(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnGetItem(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Item, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSetItem(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Label, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnEditLabel(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Beginlabeledit, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Columnclick, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Column, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSetColumn(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Endlabeledit, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On List  Notify, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnListCtrlNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnSetFocus(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Lost Focus, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnLostFocus(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Parent Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg void OnParentNotify(UINT message, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Extend data
 
	// Use Extended Data, This member specify FOP_EUseExtendedData object.  
	FOP_EUseExtendedData	m_eUseExtendedData;

	// First
 
	// First E D, This member specify FOP_EUseExtendedData object.  
    static FOP_EUseExtendedData m_eFirstED;
 
	// Last E D, This member specify FOP_EUseExtendedData object.  
    static FOP_EUseExtendedData m_eLastED;

	// x offset
 
	// X Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int			m_nXOffset;

	// y offset
 
	// Y Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    static int			m_nYOffset;

	// cy offset
 
	// C Y Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    static int			m_nCYOffset;

	// cx offset
 
	// C X Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    static int			m_nCXOffset;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPGRIDLISTCTRL_H__A1F82501_8C7D_4A86_83C6_30ECFD329D24__INCLUDED_)
