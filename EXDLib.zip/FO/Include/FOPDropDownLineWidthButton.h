//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNLINEWIDTHBUTTON_H__3FB26F35_B291_4F90_9EB6_6238E790F215__INCLUDED_)
#define AFX_FOPDROPDOWNLINEWIDTHBUTTON_H__3FB26F35_B291_4F90_9EB6_6238E790F215__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownLineWidthButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownLineWidthButton window
#include "FOPLineWidthPickerDrawPanel.h"
#include "FOPDropDownButtonBase.h"
#include "FOPPickerBaseWnd.h"

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownLineWidthButton window
void FO_API_DECL AFXAPI DDX_LineWidthDropDown(CDataExchange *pDX, int nIDC, int& nLineWidth);

 
//===========================================================================
// Summary:
//     The FOPDropDownLineWidthButton class derived from FOPDropDownButtonBase
//      O P Drop Down Line Width Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownLineWidthButton : public FOPDropDownButtonBase, FOPDropLineWidthCallback
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownLineWidthButton---O P Drop Down Line Width Button, Specifies a FOPDropDownLineWidthButton object(Value).
	DECLARE_DYNCREATE(FOPDropDownLineWidthButton);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Line Width Button, Constructs a FOPDropDownLineWidthButton object.
	//		Returns A  value (Object).
	FOPDropDownLineWidthButton();

// Attributes
public:
	// Drop wnd
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Auto ptr draw impl
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPDropLineWidthPickerDrawPanel.  
	FOPDropLineWidthPickerDrawPanel* pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPDropLineWidthPickerDrawPanel.  
	FOPDropLineWidthPickerDrawPanel*	pDrawImpl;

	// Line Width value
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							nLineWidth;
// Operations
public:

	// Share draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownLineWidthButton& button object(Value).
	void						ShareDrawImpl(FOPDropDownLineWidthButton& button);

	// Get Line Width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int		 					GetLineWidth()	const		{	return(nLineWidth);	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPDropLineWidthPickerDrawPanel& value (Object).
	const FOPDropLineWidthPickerDrawPanel&	GetDrawImpl() const	{	return *pDrawImpl;	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPDropLineWidthPickerDrawPanel& value (Object).
	FOPDropLineWidthPickerDrawPanel&	GetDrawImpl()		{	return *pDrawImpl;	}

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int					GetMinimumHeight() const;

	// Set Line Width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class FOPDropDownLineWidthButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void						SetLineWidth(int nWidth);

	// Do drop down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		r---Specifies A CRect type value.  
	//		BOOL---O O L, Specifies A Boolean value.
	// Draw state
	void						Draw(CDC& dc, const CRect& r, BOOL );

	// Do when Line Width change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Width Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellLineWidthChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom Line Width button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Line Width, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomLineWidth();

	// Do when choose none Line Width action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Width None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellLineWidthNone();

	// Set transparentcy
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPDropDownLineWidthButton
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void						SetTransparency(BOOL  bTransparent);

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 						IsTransparent()	const	{	return m_bTransparent;		}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownLineWidthButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Line Width Button, Destructor of class FOPDropDownLineWidthButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownLineWidthButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownLineWidthButton)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Transparent
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 						m_bTransparent;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNLINEWIDTHBUTTON_H__3FB26F35_B291_4F90_9EB6_6238E790F215__INCLUDED_)
