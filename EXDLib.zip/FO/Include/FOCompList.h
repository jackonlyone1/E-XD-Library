//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOCompList.h: interface for the CFOCompList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCOMPLIST_H__2EEABBEB_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOCOMPLIST_H__2EEABBEB_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOIUnknown.h"
#include "FOPCollect.h"
#include "FOPUtil.h"
#include "FOPSimplePolygon.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOCompList is identical to CObList except that it provides specialized 
// functionality in conjuction with FOIUnknown.  FOIUnknown's lifetimes are 
// maintained by reference count.  This list (which can only be used with 
// FOIUnknown derived objects) will automatically maintain object reference counts.

 
//===========================================================================
// Summary:
//     The CFOCompList class derived from CObject
//      F O Component List
//===========================================================================

class FO_EXT_CLASS CFOCompList : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOCompList---F O Component List, Specifies a E-XD++ CFOCompList object (Value).
	DECLARE_SERIAL(CFOCompList)
		
protected:

	//Node Item structure
	struct CNodeItem
	{
		CNodeItem* pNext;
		CNodeItem* pPrev;
		FOIUnknown* data;
	};
	
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Component List, Constructs a CFOCompList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nBlockSize---Block Size, Specifies A integer value.
	CFOCompList(int nBlockSize = 10);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Component List, Destructor of class CFOCompList
	//		Returns A  value (Object).
	~CFOCompList();
		
	// Operations
public:

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown*& GetHead();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown*& GetTail();

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* GetTail() const;

	// New Node
	
	//-----------------------------------------------------------------------
	// Summary:
	// New Node, .
	//		Returns a pointer to the object CNodeItem,or NULL if the call failed  
	// Parameters:
	//		CNodeItem*---Node Item*, A pointer to the CNodeItem or NULL if the call failed.  
	//		CNodeItem*---Node Item*, A pointer to the CNodeItem or NULL if the call failed.
	CNodeItem*	NewNode(CNodeItem*, CNodeItem*);

	// Free Node
	
	//-----------------------------------------------------------------------
	// Summary:
	// Free Node, .
	// Parameters:
	//		CNodeItem*---Node Item*, A pointer to the CNodeItem or NULL if the call failed.
	void		FreeNode(CNodeItem*);
		
	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* RemoveTail();
		
	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	POSITION AddHead(FOIUnknown* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	POSITION AddTail(FOIUnknown* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail No Backup, Adds an object to the specify list.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	POSITION AddTailNoBackup(FOIUnknown* pNewOb);
		
	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOCompList or NULL if the call failed.
	void AddHead(CFOCompList* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOCompList or NULL if the call failed.
	void AddTail(CFOCompList* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail No Backup, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFOCompList or NULL if the call failed.
	void AddTailNoBackup(CFOCompList* pNewList);
		
	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();

	// Remove all items from the list, and release the memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Extend, Call this function to remove a specify value from the specify object.

	void RemoveAllExt();
		
	// Return Head Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	POSITION GetHeadPosition() const;
	
	// Return the tail item's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	POSITION GetTailPosition() const;
	
	// return *Position++
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown*& GetNext(POSITION& rPosition); 

	 // return *Position++
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown* GetNext(POSITION& rPosition) const;

	// return *Position--
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown*& GetPrev(POSITION& rPosition); 
	 
	// return *Position--
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		rPosition---rPosition, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown* GetPrev(POSITION& rPosition) const;

	//	Get At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown*& GetAt(POSITION position);

	// Get At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	FOIUnknown* GetAt(POSITION position) const;

	// Set At pos
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set At, Sets a specify value to current class CFOCompList
	// Parameters:
	//		pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	void SetAt(POSITION pos, FOIUnknown* pNewOb);

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	void RemoveAt(POSITION position);

	// Insert Before position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Before, Inserts a child object at the given index..
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	POSITION InsertBefore(POSITION position, FOIUnknown* pNewOb);

	// Insert After position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert After, Inserts a child object at the given index..
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		position---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	POSITION InsertAfter(POSITION position, FOIUnknown* pNewOb);
		
	// Get POSITION of object, return NULL if not found
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		pFindComp---Find Component, A pointer to the FOIUnknown or NULL if the call failed.  
	//		startAfter---startAfter, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	POSITION Find(FOIUnknown* pFindComp, POSITION startAfter = NULL) const;
	
	// Get the 'nIndex'th element (may return NULL)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Index, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	POSITION FindIndex(int nIndex) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// Parameters:
	//		pFirstComp---First Component, A pointer to the int(*CompareFunc)(FOIUnknown or NULL if the call failed.  
	//		FOIUnknown*pSecondComp)---O I Unknown*p Second Comp), A pointer to the FOIUnknown or NULL if the call failed.
	// Sort	
	void Sort(int(*CompareFunc)(FOIUnknown* pFirstComp, FOIUnknown*pSecondComp));

	
	//-----------------------------------------------------------------------
	// Summary:
	// Sort, .
	// Parameters:
	//		posStart---posStart, Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	//		nElements---nElements, Specifies A integer value.  
	//		pFirstComp---First Component, A pointer to the int (*CompareFunc)(FOIUnknown or NULL if the call failed.  
	//		pSecondComp)---Second Comp), A pointer to the FOIUnknown or NULL if the call failed.
	// Sort
	void Sort(POSITION posStart, int nElements, int (*CompareFunc)(FOIUnknown* pFirstComp, FOIUnknown* pSecondComp));
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rects Dirty, Sets a specify value to current class CFOCompList
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetRectsDirty();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Props Dirty, Sets a specify value to current class CFOCompList
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetPropsDirty();

	// Be a specify shape can be dismantle or not.
	// aCompositePoly -- polygons that to be dismantle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Shape Can Dismantle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompositePoly---Composite Polygon, Specifies a const FOPSimpleCompositePolygon& aCompositePoly object(Value).  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual BOOL BeShapeCanDismantle(const FOPSimpleCompositePolygon& aCompositePoly, BOOL bCreateLines) const;
	
	// Be a specify shape can be dismantle or not.
	// pObj-- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Shape Can Dismantle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pObj---pObj, A pointer to the const FOIUnknown or NULL if the call failed.  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual BOOL BeShapeCanDismantle(const FOIUnknown* pObj, BOOL bCreateLines) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Object Snap Rectangle, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	const FOPRect& GetAllObjSnapRect() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Object Bound Rectangle, Returns the specified value.
	//		Returns A const FOPRect& value (Object).
	const FOPRect& GetAllObjBoundRect() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Cannot Rotated, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllCannotRotated();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Cannot Resized, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllCannotResized();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Cannot Copied, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllCannotCopied();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Cannot Deleted, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllCannotDeleted();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllLocked();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Group, Returns the specified value.
	//		Returns a int type value.
	int GetAllGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Child Graph, Returns the specified value.
	//		Returns a int type value.
	int GetAllSubGraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Moved, Returns the specified value.
	//		Returns a int type value.
	int GetAllMoved();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Rotated, Returns the specified value.
	//		Returns a int type value.
	int GetAllRotated();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Sized, Returns the specified value.
	//		Returns a int type value.
	int GetAllSized();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Links, Returns the specified value.
	//		Returns a int type value.
	int GetAllLinks();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Cells, Returns the specified value.
	//		Returns a int type value.
	int GetAllCells();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Be Dismantle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanBeDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Be Dismantle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanBeBreak();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllClosed();

	// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArchive&---Archive&, Specifies a CArchive& object(Value).
	// Serialize data
	virtual void Serialize(CArchive&);
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CDumpContext&---Dump Context&, Specifies a CDumpContext& object(Value).
	virtual void Dump(CDumpContext&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
#endif

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Rects, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcRects();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Props, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcProps();
	// Attributes
protected:

	// Hedd Node
 
	// Node Head, This member maintains a pointer to the object CNodeItem.  
	CNodeItem*		m_pNodeHead;

	// Tail Node
 
	// Node Tail, This member maintains a pointer to the object CNodeItem.  
	CNodeItem*		m_pNodeTail;

	// Count
 
	// Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCount;

	// Free Node
 
	// Node Free, This member maintains a pointer to the object CNodeItem.  
	CNodeItem*		m_pNodeFree;

	// The pointer to Blocks
 
	// Blocks, This member maintains a pointer to the object struct CPlex.  
	struct CPlex*	m_pBlocks;

	// Block Size
 
	// Block Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nBlockSize;

	// Out bounding rectangle.
 
	// Out Rectangle, This member specify FOPRect object.  
	FOPRect			aOutRect;

	// Total snap rectangle.
 
	// Snap Rectangle, This member specify FOPRect object.  
	FOPRect			aSnapRect;

	// Is it property changed.
 
	// Property Dirty, This member sets TRUE if it is right.  
	BOOL			bPropDirty;

	// Is it modified.
 
	// Rects Dirty, This member sets TRUE if it is right.  
	BOOL			bRectsDirty;

	// Is all shapes cann't be rotated.
 
	// Is All Not Rotated, This member sets TRUE if it is right.  
	BOOL			m_bIsAllNotRotated;

	// Is all shapes cann't be resized.
 
	// Is All Not Resized, This member sets TRUE if it is right.  
	BOOL			m_bIsAllNotResized;

	// Is all shapes locked.
 
	// Is All Locked, This member sets TRUE if it is right.  
	BOOL			m_bIsAllLocked;

	// Is all shapes cann't copied.
 
	// Is All Not Copied, This member sets TRUE if it is right.  
	BOOL			m_bIsAllNotCopied;

	// Is all shapes cann't deleted.
 
	// Is All Not Deleted, This member sets TRUE if it is right.  
	BOOL			m_bIsAllNotDeleted;

	// Count of all movable.
 
	// Total Moved, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalMoved;

	// Count of all rotated.
 
	// Total Rotated, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalRotated;

	// Count of all resized.
 
	// Total Sized, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalSized;

	// Count of all group.
 
	// Total Group, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalGroup;

	// Count of all sub - graph.
 
	// Total Child Graph, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalSubGraph;

	// Count of total links.
 
	// Total Links, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalLinks;

	// Count of table cells.
 
	// Total Cells, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalCells;

	// Is shape be dismantle.
 
	// Can Dismantle, This member sets TRUE if it is right.  
	BOOL			m_bCanDismantle;

	// Can break to lines.
	BOOL			m_bCanBreakLines;

	// Close state.
 
	// Close State, This member sets TRUE if it is right.  
	BOOL			m_bCloseState;
};

////////////////////////////////////////////////////////////////
// CFODrawShapeSet -- components set, it is much like the list.
//

 
//===========================================================================
// Summary:
//     The CFODrawShapeSet class derived from FOPContainer
//      F O Draw Shape Set
//===========================================================================

class FO_EXT_CLASS CFODrawShapeSet : public FOPContainer
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Shape Set, Constructs a CFODrawShapeSet object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInit---nInit, Specifies A integer value.  
	//		nTotal---nTotal, Specifies A integer value.
	CFODrawShapeSet(int nInit = 16, int nTotal = 16) : FOPContainer(1024, nInit, nTotal)	{}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Shape Set, Destructor of class CFODrawShapeSet
	//		Returns A  value (Object).
    ~CFODrawShapeSet();

	// Get Count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	//		Returns a int type value.
	int GetCount() const;

	// Is it Empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEmpty() const;

	// Get head (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Head, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* RemoveHead();

	// Get tail (and remove it) - don't call on empty list!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tail, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* RemoveTail();

	// Get Head Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Head, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* GetHead() const;

	// Get Tail Pointer	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tail, Returns the specified value.
	//		Returns a pointer to the object FOIUnknown,or NULL if the call failed
	FOIUnknown* GetTail() const;

	// Remove At position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		position---Specifies A 32-bit long signed integer.
	void RemoveAt(long position);

	// Add before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	void AddHead(FOIUnknown* pNewOb);

	// Add before after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewOb---New Ob, A pointer to the FOIUnknown or NULL if the call failed.
	void AddTail(FOIUnknown* pNewOb);

	// Add another list of elements before head
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Head, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	void AddHead(CFODrawShapeSet* pNewList);

	// Add another list of elements after tail
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tail, Adds an object to the specify list.
	// Parameters:
	//		pNewList---New List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	void AddTail(CFODrawShapeSet* pNewList);

	// Remove all items from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

	void RemoveAll();

	// Find shape index.
	virtual int FindIndex(FOIUnknown *pShape) const;

};

#include "FOCompList.inl"

#endif // !defined(AFX_FOCOMPLIST_H__2EEABBEB_F19E_11DD_A432_525400EA266C__INCLUDED_)
