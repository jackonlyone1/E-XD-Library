//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMatrix.h: interface for the CFOMatrix class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMATRIX_H__6A7890B3_A693_11D6_A621_0050BAE30439__INCLUDED_)
#define AFX_FOMATRIX_H__6A7890B3_A693_11D6_A621_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////////
//
// M3D -- 3 key values.
/////////////////////////////////////////////////////////////////////////////////
#include "FOPUtil.h"

 
//===========================================================================
// Summary:
//      To use a M3D object, just call the constructor.
//      M3 D
//===========================================================================

class FO_EXT_CLASS M3D
{
protected:

	// 3 Dimension
 
	// This member specify double object.  
	double	V[3];

	// Protected methods.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Impl Homogenize, .

	void ImplHomogenize();

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// M3 D, Constructs a M3D object.
	//		Returns A  value (Object).  
	// Parameters:
	//		m00---Specifies a double m00 = 0.0 object(Value).  
	//		m01---Specifies a double m01 = 0.0 object(Value).  
	//		m02---Specifies a double m02 = 1.0 object(Value).
	M3D(double m00 = 0.0, double m01 = 0.0, double m02 = 1.0)
		{ V[0] = m00; V[1] = m01; V[2] = m02; }

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// M3 D, Constructs a M3D object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rPnt---rPnt, Specifies A CPoint type value.  
	//		fW---fW, Specifies a double fW = 1.0 object(Value).
	M3D(const CPoint& rPnt, double fW = 1.0);

	
	//-----------------------------------------------------------------------
	// Summary:
	// M0, .
	//		Returns A const double& value (Object).
	// M0 value
	const double& M0() const { return V[0]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// M1, .
	//		Returns A const double& value (Object).
	const double& M1() const { return V[1]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// M2, .
	//		Returns A const double& value (Object).
	const double& M2() const { return V[2]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// M0, .
	//		Returns A double& value (Object).
	double& M0() { return V[0]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// M1, .
	//		Returns A double& value (Object).
	double& M1() { return V[1]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// M2, .
	//		Returns A double& value (Object).
	double& M2() { return V[2]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const double& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const double& operator[] (int nPos) const { return V[nPos]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A double& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	double& operator[] (int nPos) { return V[nPos]; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Homogenize, .

	void	Homogenize() { if(V[2] != 1.0) ImplHomogenize(); }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimize, .
	// Parameters:
	//		rVec---rVec, Specifies a const M3D& rVec object(Value).
	void	Min(const M3D& rVec);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Maximize, .
	// Parameters:
	//		rVec---rVec, Specifies a const M3D& rVec object(Value).
	void	Max(const M3D& rVec);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Abs, .

	void	Abs();

	// Methods
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate In Between, .
	// Parameters:
	//		rOld1---rOld1, Specifies a M3D& rOld1 object(Value).  
	//		rOld2---rOld2, Specifies a M3D& rOld2 object(Value).  
	//		t---Specifies a double t object(Value).
	void CalcInBetween(M3D& rOld1, M3D& rOld2, double t);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Middle, .
	// Parameters:
	//		rOld1---rOld1, Specifies a M3D& rOld1 object(Value).  
	//		rOld2---rOld2, Specifies a M3D& rOld2 object(Value).
	void CalcMiddle(M3D& rOld1, M3D& rOld2);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Middle, .
	// Parameters:
	//		rOld1---rOld1, Specifies a M3D& rOld1 object(Value).  
	//		rOld2---rOld2, Specifies a M3D& rOld2 object(Value).  
	//		rOld3---rOld3, Specifies a M3D& rOld3 object(Value).
	void CalcMiddle(M3D& rOld1, M3D& rOld2, M3D& rOld3);

	// Operator
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D&	operator+=	(const M3D&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D&	operator-=	(const M3D&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D		operator+ 	(const M3D&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D		operator-	(const M3D&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		void---void
	M3D		operator-	(void) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D&	operator*=	(const M3D&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D&	operator/=	(const M3D&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D		operator* 	(const M3D&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	M3D		operator/	(const M3D&) const;

	// Extroa operator.
	M3D&	operator*=	(double);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	M3D		operator*	(double) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	M3D&	operator/=	(double);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	M3D		operator/	(double) const;

	// Operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	BOOL		operator==	(const M3D&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		M3D&---M3 D&, Specifies a const M3D& object(Value).
	BOOL		operator!=	(const M3D&) const;

};

/////////////////////////////////////////////////////////////////////////////////
//
// CFOMatrix -- metrix class, this is a 3 X 3 metrix, it is used for shaping moving
//				rotating, etc.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOMatrix class derived from CObject
//      F O Matrix
//===========================================================================

class FO_EXT_CLASS CFOMatrix : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMatrix---F O Matrix, Specifies a E-XD++ CFOMatrix object (Value).
	DECLARE_SERIAL(CFOMatrix)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Matrix, Constructs a CFOMatrix object.
	//		Returns A  value (Object).
	CFOMatrix();

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Matrix, Constructs a CFOMatrix object.
	//		Returns A  value (Object).  
	// Parameters:
	//		m00---Specifies a double m00 object(Value).  
	//		m01---Specifies a double m01 object(Value).  
	//		m02---Specifies a double m02 object(Value).  
	//		m10---Specifies a double m10 object(Value).  
	//		m11---Specifies a double m11 object(Value).  
	//		m12---Specifies a double m12 object(Value).  
	//		m20---Specifies a double m20 object(Value).  
	//		m21---Specifies a double m21 object(Value).  
	//		m22---Specifies a double m22 object(Value).
	CFOMatrix(
		double m00, double m01, double m02,
		double m10, double m11, double m12,
		double m20, double m21, double m22
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Matrix, Constructs a CFOMatrix object.
	//		Returns A  value (Object).  
	// Parameters:
	//		F0---F0, Specifies a const M3D& F0 object(Value).  
	//		F1---F1, Specifies a const M3D& F1 object(Value).  
	//		F2---F2, Specifies a const M3D& F2 object(Value).
	CFOMatrix( const M3D& F0, const M3D& F1, const M3D& F2 );

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Matrix, Constructs a CFOMatrix object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOMatrix& src object(Value).
	CFOMatrix(const CFOMatrix& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Matrix, Destructor of class CFOMatrix
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMatrix();

	//-----------------------------------------------------------------------
	// Summary:
	// Zeri matrix
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zero Matrix, .

	void ZeroMatrix();

	//-----------------------------------------------------------------------
	// Summary:
	// Initial the default values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Matrix, Call InitMatrix after creating a new object.

	void InitMatrix();

	//-----------------------------------------------------------------------
	// Summary:
	// Initial the default values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Matrix, Call InitMatrix after creating a new object.
	// Parameters:
	//		m00---Specifies a double m00 object(Value).  
	//		m01---Specifies a double m01 object(Value).  
	//		m02---Specifies a double m02 object(Value).  
	//		m10---Specifies a double m10 object(Value).  
	//		m11---Specifies a double m11 object(Value).  
	//		m12---Specifies a double m12 object(Value).  
	//		m20---Specifies a double m20 object(Value).  
	//		m21---Specifies a double m21 object(Value).  
	//		m22---Specifies a double m22 object(Value).
	void InitMatrix(
		double m00, double m01, double m02,
		double m10, double m11, double m12,
		double m20, double m21, double m22
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Is default value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has No Change, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasNoChange();

	//-----------------------------------------------------------------------
	// Summary:
	// Convert to XFORM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To X F O R M, .
	// Parameters:
	//		&m_Form---&m_Form, Specifies a XFORM &m_Form object(Value).
	void ConvertToXFORM(XFORM &m_Form);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Trace, .
	//		Returns A double value (Object).
	// Trace
	double Trace();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transpose, .

	// Transpose
	void Transpose();

public:

	// Methods.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A M3D& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	M3D& operator[](int nPos) { return M[nPos]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const M3D& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const M3D& operator[](int nPos) const { return M[nPos]; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Vector, Returns the specified value.
	//		Returns A M3D value (Object).  
	// Parameters:
	//		nCol---nCol, Specifies A integer value.
	M3D GetColumnVector(int nCol) const	{ return M3D(M[0][nCol], M[1][nCol], M[2][nCol]); }

	// Operators.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix& value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix&  operator=	(const CFOMatrix&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix& value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix&	operator+=	(const CFOMatrix&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix& value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix&	operator-=	(const CFOMatrix&);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix	operator+ 	(const CFOMatrix&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix	operator-	(const CFOMatrix&) const;

public:
	// Operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	BOOL		operator==	(const CFOMatrix&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	BOOL		operator!=	(const CFOMatrix&) const;

public:
	// Operator.
	CFOMatrix&	operator*=	(double);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	CFOMatrix	operator*	(double) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix& value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	CFOMatrix&	operator/=	(double);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		double---Specifies a double object(Value).
	CFOMatrix	operator/	(double) const;

public:

	// Operator *
	CFOMatrix	operator*=	(const CFOMatrix&) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOMatrix value (Object).  
	// Parameters:
	//		CFOMatrix&---F O Matrix&, Specifies a const CFOMatrix& object(Value).
	CFOMatrix	operator*	(const CFOMatrix&) const;

public:
	
	// Rotation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		dAngle---dAngle, Specifies a double dAngle object(Value).
	void Rotate(double dAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	void Rotate(double dSin, double dCos );

	// Rotating value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Value, Returns the specified value.
	//		Returns a int type value.
	int GetRotateValue();

	// Is rotated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Rotated, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShapeRotated();

	// Rotating value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Simple Rotate Value, Returns the specified value.
	//		Returns A double value (Object).
	double GetSimpleRotateValue();

public:

	// Translation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	void Move(double dX, double dY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	void Move(const CPoint& ptOffset);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move X, .
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).
	void MoveX(double dValue);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Y, .
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).
	void MoveY(double dValue);

	// Move value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Move Value, Returns the specified value.
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	void GetMoveValue(CPoint &ptOffset);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent Value Exist, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTransValueExist() const;

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear, .
	// Parameters:
	//		dSx---dSx, Specifies a double dSx object(Value).  
	//		dSy---dSy, Specifies a double dSy object(Value).
	// Shearing-Matrices
	void Shear(double dSx, double dSy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear X, .
	// Parameters:
	//		dSx---dSx, Specifies a double dSx object(Value).
	void ShearX(double dSx);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Y, .
	// Parameters:
	//		dSy---dSy, Specifies a double dSy object(Value).
	void ShearY(double dSy);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X, .
	// Parameters:
	//		dAngle---dAngle, Specifies a double dAngle object(Value).
	// SkewX
	void SkewX(double dAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y, .
	// Parameters:
	//		dAngle---dAngle, Specifies a double dAngle object(Value).
	void SkewY(double dAngle);

public:
	// Scaling
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize, .
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).
	void Resize(double dX, double dY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize, .
	// Parameters:
	//		szResize---szResize, Specifies A CSize type value.
	void Resize(const CSize& szResize);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize X, .
	// Parameters:
	//		dFactor---dFactor, Specifies a double dFactor object(Value).
	void ResizeX(double dFactor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Y, .
	// Parameters:
	//		dFactor---dFactor, Specifies a double dFactor object(Value).
	void ResizeY(double dFactor);

	// Resize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resize Value, Returns the specified value.
	// Parameters:
	//		dResizeX---Resize X, Specifies a double& dResizeX object(Value).  
	//		dResizeY---Resize Y, Specifies a double& dResizeY object(Value).
	void GetResizeValue(double& dResizeX, double& dResizeY);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class CFOMatrix
	// Parameters:
	//		&dXValue---X Value, Specifies a double &dXValue object(Value).  
	//		&dYValue---Y Value, Specifies a double &dYValue object(Value).
	void SetValue(double &dXValue,double &dYValue);
	
	// Is shape resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Resized, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShapeResized();

	// Is shape stretched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Stretched, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShapeStretched();
public:

	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		&szValue---&szValue, Specifies A CSize type value.
	void ChangeValue(CSize &szValue);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		&ptPoint---&ptPoint, Specifies A CPoint type value.
	void ChangeValue(CPoint &ptPoint);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		&ptPoint---&ptPoint, Specifies A CPoint type value.
	void XChangeValue(FOPFloat &ptPoint);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		ptPoints---ptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	void ChangeValue(LPPOINT ptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		ptPoints---ptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	void ChangeValue(LPFOFLOAT ptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value, .
	// Parameters:
	//		ptPoints---ptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	void XChangeValue(FOPFloat *ptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value with matrix.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value2, .
	// Parameters:
	//		&xValue---&xValue, Specifies a double &xValue object(Value).  
	//		&yValue---&yValue, Specifies a double &yValue object(Value).
	void ChangeValue2(double &xValue, double &yValue);


	//-----------------------------------------------------------------------
	// Summary:
	// Change value back with current matrix.
	// point - point for changing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value Back, .
	// Parameters:
	//		&point---Specifies A CPoint type value.
	void ChangeValueBack(CPoint &point);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value back with current matrix.
	// point - point for changing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value Back, .
	// Parameters:
	//		&point---Specifies A CPoint type value.
	void ChangeValueBack(FOPFloat &point);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value back with current matrix.
	// ptPoints -- points for changing
	// nCount -- count point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value Back, .
	// Parameters:
	//		ptPoints---ptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	void ChangeValueBack(LPPOINT ptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Change value back with current matrix.
	// ptPoints -- points for changing
	// nCount -- count point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Value Back, .
	// Parameters:
	//		ptPoints---ptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	void ChangeValueBack(LPFOFLOAT ptPoints, int nCount);

public:

	
	// Is modified or not.
	BOOL IsModified() const { return m_bModify; }
	
	// Change modified flag.
	void SetModified(const BOOL &bModify) { m_bModify = bModify; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive& ar);

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Matrix value.
 
	// This member specify M3D object.  
	M3D			M[3];

protected:
	// Is area modified or not.
	BOOL				m_bModify;

};

#endif // !defined(AFX_FOMATRIX_H__6A7890B3_A693_11D6_A621_0050BAE30439__INCLUDED_)
