//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOIUnknown.h: interface for the FOIUnknown class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOIUNKNOWN_H__2EEABBEA_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOIUNKNOWN_H__2EEABBEA_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////////
//
// CFOObserver
//
// UpdateObserver must be override
//
/////////////////////////////////////////////////////////////////////////////////

#define FO_EVENT_VALUECHANGE 3301

//===========================================================================
// Summary:
//      To use a CFOObserver object, just call the constructor.
//      F O Observer
//===========================================================================

class FO_EXT_CLASS CFOObserver
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Observer, Destructor of class CFOObserver
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOObserver();
	
	// Methods
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update observer method,by default,system use DataModel - Observer mode instead of the Document - View
	// mode of MFC,each data model can include as many observer as you want,for each observer,it must use 
	// CFOObserver as base class,such as CFOPCanvasCore is an observer.
	//
	// Each observer must override this method to handle the messages that come from the datamodel,when the data
	// within the data model be changed,all the observer will be notified.
	//
	// pModel -- Pointer of the data model.
	// lHint -- messages flags.
	// pHint -- messages body.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint)---Object*p Hint), A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( CObject * pModel,LPARAM lHint, CObject*pHint) = 0;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Obtain page margins
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margins, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargins---rcMargins, Specifies A CRect type value.
	virtual void GetMargins(CRect& rcMargins)
	{
		rcMargins = CRect(0,0,0,0);
	}
	
	// constructor
protected:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Observer, Constructs a CFOObserver object.
	//		Returns A  value (Object).
	CFOObserver();
	
};

/////////////////////////////////////////////////////////////////////////////////
// FOIUnknown -- define the reference for each shape, all shape base class.

 
//===========================================================================
// Summary:
//     The FOIUnknown class derived from CObject
//      O I Unknown
//===========================================================================

class FO_EXT_CLASS FOIUnknown : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOIUnknown---O I Unknown, Specifies a FOIUnknown object(Value).
	DECLARE_SERIAL(FOIUnknown)

	// Construction/destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// O I Unknown, Constructs a FOIUnknown object.
	//		Returns A  value (Object).
	FOIUnknown();

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O I Unknown, Destructor of class FOIUnknown
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOIUnknown();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get file
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Increment reference count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Reference, Adds an object to the specify list.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD AddRef();

	// Decrement reference count.  Object will be deleted when the reference count reaches zero.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release, .
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD Release();

	// Returns the current reference count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Reference Count, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetRefCount() const;

	// Change ref count to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Reference Count, Sets a specify value to current class FOIUnknown
	// Parameters:
	//		dwNew---dwNew, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void SetRefCount(DWORD dwNew);

	// Just delete me.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Just Delete Me, .

	void JustDeleteMe();

protected:

	// Attributes
	// Ref count.
 
	// Reference Count, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_dwRefCount;

};

#endif // !defined(AFX_FOIUNKNOWN_H__2EEABBEA_F19E_11DD_A432_525400EA266C__INCLUDED_)
