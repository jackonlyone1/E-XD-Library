//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// //////////////////////////////////////////////////////////////////////////
// FOColorButton.h: interface for the CFOColorButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCOLORBUTTON_H__900D5BB5_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FOCOLORBUTTON_H__900D5BB5_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOColorCellObj.h"

 
//===========================================================================
// Summary:
//     The CFOColorButton class derived from CButton
//      F O Color Button
//===========================================================================

class FO_EXT_CLASS CFOColorButton : public CButton
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOColorButton---F O Color Button, Specifies a E-XD++ CFOColorButton object (Value).
	DECLARE_DYNAMIC(CFOColorButton)

public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Color Button, Constructs a CFOColorButton object.
	//		Returns A  value (Object).
	CFOColorButton(); 

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Color Button, Destructor of class CFOColorButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOColorButton(); 

	// Attach
	BOOL Attach(const UINT nID, 
		CWnd* pParent, 
		const COLORREF crColor =		RGB(192, 192, 192),
		const COLORREF crOldColor =		RGB(1, 1, 1),
		const COLORREF DisabledColor =  RGB(128, 128, 128),
		const UINT nBevel =				2
		);

	// Set Current Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button Color, Sets a specify value to current class CFOColorButton
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetButtonColor(COLORREF crColor);

	// Get Old Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Color, Sets a specify value to current class CFOColorButton
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crOld---crOld, Specifies A 32-bit COLORREF value used as a color value.
	COLORREF SetOldColor(COLORREF crOld)		{ return m_crOldColor = crOld; }	

protected:

	// Draw Item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);

	// Draw Frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Frame, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*DC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		R---R, Specifies A CRect type value.  
	//		Inset---Inset, Specifies A integer value.
	virtual void DrawFrame(CDC *DC, CRect R, int Inset);

	// Draw Filled Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Filled Rectangle, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*DC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		R---R, Specifies A CRect type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawFilledRect(CDC *DC, CRect R, COLORREF color);

	// Draw Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*DC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		EndPoints---End Points, Specifies A CRect type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawLine(CDC *DC, CRect EndPoints, COLORREF color);

	// Draw Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*DC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		left---Specifies A 32-bit long signed integer.  
	//		top---Specifies A 32-bit long signed integer.  
	//		right---Specifies A 32-bit long signed integer.  
	//		bottom---Specifies A 32-bit long signed integer.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void DrawLine(CDC *DC, long left, long top, long right, long bottom, COLORREF color);
protected:
	//{{AFX_MSG(CFOColorButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
			
private:

	// Old Color
 
	// Old Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crOldColor;

	// Current Color
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crColor;

	// Disabled Color
 
	// This member sets A 32-bit value used as a color value.  
	COLORREF	m_disabled;

	// Bevel
 
	// This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_bevel;
	
};

#endif // !defined(AFX_FOCOLORBUTTON_H__900D5BB5_F3E6_11DD_A438_525400EA266C__INCLUDED_)
