//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOCompProperties.h: interface for the CFOFillProperties class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCOMPPROPERTIES_H__2EEABBF3_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOCOMPPROPERTIES_H__2EEABBF3_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseProperties.h"
#include "FODefines.h"

/////////////////////////////////////////////////////////////
// Property IDs define.

// Name
#define P_ID_NAME                               1000 // CString

// Caption
#define P_ID_CAPTION                            1001 // CString

// Three key values that defined for each shape on the canvas.

// Key ID1
#define P_ID_ID1								1002 // CString

// Key ID2
#define P_ID_ID2								1003 // CString

// Key ID3
#define P_ID_ID3								1004 // CString

// This property value define a hot spot editing mode for ellipse, rectangle and polygon shapes.
#define P_ID_HOTSPOT							1005 // BOOL

// This property value define for composite shape, to allow hit children shape or not.
#define P_ID_ALLOW_HIT_CHILD					1006 // BOOL

// Check if this composite shape is modified or not.
#define P_ID_COMP_MODIFIED						1007

/////////////////////////////////////////////////////////////
// Extra properties, the following property values are defined for e-form solution only.

// The choice list text.
#define P_ID_EXT_CHOICELIST						1100 // CString

// Border showing property values.

// With left border.
#define P_ID_EXT_LEFTBORDER						1101 // BOOL

// With top border.
#define P_ID_EXT_TOPBORDER						1102 // BOOL

// With right border
#define P_ID_EXT_RIGHTBORDER					1103 // BOOL

// With bottom border.
#define P_ID_EXT_BOTTOMBORDER					1104 // BOOL

// Minimize value or maximize value.

// Minimize value.
#define P_ID_EXT_MINVALUE						1105 // double

// Maximize value.
#define P_ID_EXT_MAXVALUE						1106 // double

// Printing with border or not.
#define P_ID_EXT_PRINTWITHBORDER				1108 // BOOL

// Is this e-form object needed for database loading / saving or not.
#define P_ID_EXT_NEEDFORDB						1109 // BOOL

// Connect database field name.
#define P_ID_EXT_DBNAME							1110 // CString


///////////////////////////////////////////////////////////////////////
// Define for check box shape.

// The text shows at right of check box or not.
#define  P_ID_CHECKBOX_BUTTONRIGHT				1112 // BOOL

// Size of check box.
#define	 P_ID_CHECKBOX_SIZE						1113 // INT

// Style of check box.
#define	 P_ID_CHECKBOX_STYLE					1114 // UINT

////////////////////////////////////////////////////////////////////////
// Define for composite shape.
#define  P_ID_COMPOSITE_ALLOWLABEL_SELECT		1115 // BOOL
#define  P_ID_COMPOSITE_HITLABEL_VISIBLE		1116 // BOOL

////////////////////////////////////////////////////////////////////////
// Define for corner link shape's corner size, with class CFOCornerLinkShape.
#define	 P_ID_CORNER_LINK_CORNER_SIZE			1117 // INT

#define  P_ID_PIN_HORZ							1118 // BOOL
#define  P_ID_PIN_LABEL							1119 // String
#define  P_ID_PIN_INVERT						1120 // BOOL
#define  P_ID_LINE_SHOW							1121 // BOOL

/////////////////////////////////////////////////////////////
// The following property values are defined for CFOPortShape.
// Property IDs define.

#define P_ID_PORTWIDTH                          1200 // INT
#define P_ID_PORTHEIGHT                         1201 // INT
#define P_ID_PORTTYPE                           1202 // UINT
#define P_ID_PORTSIDE                           1203 // UINT

/////////////////////////////////////////////////////////////
// Protected property values for each shape.
// Property IDs define.

#define P_ID_RESIZEPROTECT                      1300 // BOOL
#define P_ID_SELECTPROTECT                      1301 // BOOL
#define P_ID_MOVEPROTECT                        1302 // BOOL
#define P_ID_ROTATEPROTECT                      1303 // BOOL
#define P_ID_PRINTPROTECT                       1304 // BOOL
#define P_ID_COPYPROTECT                        1305 // BOOL
#define P_ID_DELETEPROTECT                      1306 // BOOL
#define P_ID_ASPECTRATIO                        1307 // BOOL
#define P_ID_EXPANDEDITCENTER                   1308 // BOOL
#define P_ID_VISIBLE                            1309 // BOOL
#define P_ID_LOCK                               1310 // BOOL
#define P_ID_TABORDERPROTECT                    1311 // BOOL
#define P_ID_XPOSPROTECT						1312 // BOOL
#define P_ID_YPOSPROTECT						1313 // BOOL
#define P_ID_WIDTHPROTECT                       1314 // BOOL
#define P_ID_HEIGHTPROTECT                      1315 // BOOL
#define P_ID_AUTO_RESIZE						1316 // BOOL
#define P_ID_WITH_TEXT_ROTATE					1317 // BOOL

// Initial angle value for text rotating.
#define P_ID_FONT_INT_ROTATE_ANGLE				1318 // INT

// For path shape.
#define P_ID_PATHSHAPE_SMOOTHEDIT				1319 // BOOL

///////////////////////////////////////////////////////////////////
// The following two property values are defined for sub - graph shape only.
// For sub children shape.
#define P_ID_SUBGRAPH_CONSIDER_CHILD			1320 // BOOL
#define P_ID_SUBGRAPH_SCALEALL					1321 // BOOL

// For showing center line, it is not used now.
#define P_ID_SHOW_CENTERLINE					1322 // BOOL

// For dimension text.
#define P_ID_DIM_SHOW_INSIDE					1323 // BOOL

// For line upright mode
#define	P_ID_LINE_UPRIGHT_MODE					1324 // BOOL

///////////////////////////////////////////////////////////////////////
// Defined for link shape only, CFOLinkShape
// For link shape.
#define P_ID_LINK_LOCK_START					1325 // BOOL
#define P_ID_LINK_LOCK_END						1326 // BOOL
#define P_ID_LINK_WITH_LABEL_BORDER				1327 // BOOL
#define P_ID_LINK_WITH_BRIDGE					1328 // BOOL

// For radio button shape only.
#define P_ID_RADIO_HORIZ_SHOW					1329 // BOOL
#define P_ID_RADIO_BUTTON_RIGHT					1330 // BOOL

/////////////////////////////////////////////////////////////////////////////
// Allowing label editing or not.
#define P_ID_LABEL_EDITING						1331 // BOOL

// Composite shape's label default position.
#define P_ID_LABEL_POSITION						1332 // INT

// Font art type.
#define P_ID_FONT_ART_TYPE						1333 // INT

// Script text
#define P_ID_CLICK_SCRIPT						1350 // STRING
#define P_ID_LD_SCRIPT							1351 // STRING
#define P_ID_LU_SCRIPT							1352 // STRING

// With simple two status support for composite shape at running time.
#define P_ID_WITH_TWO_STATUS					1353 // BOOL

// High shape style.
#define P_ID_HIGH_SHAPE_STYLE					1354 // INT, 0-UP, 1- DOWN, 2-LEFT, 3- RIGHT

/////////////////////////////////////////////////////////////
// The following property values are defined for line shape's arrow style.
// Property IDs define.

#define P_ID_STARTARROW                         1400 // BOOL
#define P_ID_ENDARROW                           1401 // BOOL
#define P_ID_STARTARROWWIDTH                    1402 // INT
#define P_ID_ENDARROWWIDTH                      1403 // INT
#define P_ID_STARTARROWLENGTH                   1404 // INT
#define P_ID_ENDARROWLENGTH                     1405 // INT

/////////////////////////////////////////////////////////////
// Font and text alignment property IDs define.

#define P_ID_TEXT_HORZ							1501 // UINT
#define P_ID_TEXT_VERT							1502 // UINT
#define P_ID_TEXT_MULTILINE						1503 // BOOL
#define P_ID_FONT_FACENAME						1504 // CString
#define P_ID_FONT_POINTSIZE						1505 // INT
#define P_ID_FONT_HEIGHT						1506 // INT
#define P_ID_FONT_COLOR							1507 // COLORREF
#define P_ID_FONT_WEIGHT						1508 // INT
#define P_ID_FONT_ITALIC						1509 // BOOL
#define P_ID_FONT_UNDERLINE						1510 // BOOL
#define P_ID_FONT_STRIKEOUT						1511 // BOOL
#define P_ID_BULLET_COLOR						1512 // COLORREF
#define P_ID_BULLET_TYPE						1513 // INT

// With simple two status button state for composite shape at running time.
#define P_ID_WITH_TWO_BUTTONCLICK				1530 // BOOL

#define P_ID_ENABLE_GAUGE_STEP					1531 // BOOL
#define P_ID_GAUGE_STEP_VALUE					1532 // Double
#define P_ID_WITH_CYCLE_ANIMATE					1533 // BOOL
#define P_ID_WITH_VISIBLE_SET					1534 // BOOL
#define P_ID_VISIBLE_CONDITION					1535 // CString
#define	P_ID_SCALE_TYPE							1537 // INT Scale vertical or horizontal or all, 0 -- scale with height, 1 -- scale with width, 2 -- scale both width and height.
#define P_ID_SCALE_ORIGIN						1538 // INT 0 -- Top, left, 1 -- Bottom, Right, 2 -- center
#define P_ID_ENABLE_DRAG						1539 // BOOL

#define P_ID_WITH_BLINK_SET						1540 // BOOL
#define P_ID_BLINK_CONDITION					1541 // CString
#define P_ID_BLINK_COLOR						1542 // COLORREF

#define P_ID_WITH_VALUE_SET						1543 // BOOL
#define P_ID_VALUE_CONDITION					1544 // String			

#define P_ID_WITH_DISABLE_SET					1545 // BOOL
#define P_ID_DISABLE_CONDITION					1546 // CString

#define P_ID_REVERSE_FLOW						1547 // BOOL
#define P_ID_BLINK_TYPE							1548 // INT

/////////////////////////////////////////////////////////////////////////////
// CFOImageExtProp

#define ID_FOP_PROP_BLUE                         1600 // INT
#define ID_FOP_PROP_RED                          1601 // INT
#define ID_FOP_PROP_GREEN                        1602 // INT
#define ID_FOP_PROP_BRIGHT                       1603 // INT
#define ID_FOP_PROP_CONT                         1604 // INT
#define ID_FOP_PROP_GAMMA                        1605 // INT

// Width of pipe line, it is defined for pipe shape.
#define P_ID_PIPE_LINE_WIDTH                     1606 // INT

#define FO_PIPE_OPEN_END						 1607 // BOOL
#define FO_PIPE_COLOR							 1608 // Color
#define FO_WITH_ANIMATE							 1609 // BOOL

#define FO_UML_ARROW_TYPE						 1610 // int from 0 - 5
#define FO_UML_LABEL_TYPE						 1611 // int from 0 - 5
#define FO_UML_LABEL1							 1612 // CString
#define FO_UML_LABEL2							 1613 // CString


// Flat or not.
#define P_ID_FLAT								 1700 // BOOL

///////////////////////////////////////////////////////////////////////////
// Line style property IDs.
#define P_ID_LINE_WIDTH							 1701 // INT
#define P_ID_LINE_COLOR							 1702 // COLORREF
#define P_ID_PEN_STYLE							 1703 // INT
#define P_ID_NULL_PEN							 1704 // BOOL

////////////////////////////////////////////////////////////////////////////
// Shadow property IDs.
#define P_ID_SHADOW_COLOR						 1705 // COLOREF
#define P_ID_SHADOW_PATTERN_COLOR				 1706 // COLOREF
#define P_ID_SHADOW_OFFSETX						 1707 // INT
#define P_ID_SHADOW_OFFSETY						 1708 // INT
#define P_ID_SHADOW_BRUSHTYPE					 1709 // INT
#define P_ID_SHADOW_BRUSHHATCH					 1710 // INT
#define P_ID_SHADOW								 1711 // BOOL

///////////////////////////////////////////////////////////////////////////
// Fill style property IDs.
#define P_ID_BK_COLOR							 1712 // COLORREF
#define P_ID_PATTERNCOLOR						 1713 // COLORREF
#define P_ID_TRANSPARENT						 1714 // BOOL
#define P_ID_BURSHTYPE							 1715 // INT
#define P_ID_BRUSHHATCH							 1716 // INT

//////////////////////////////////////////////////////////////////////////
// The following property value is defined for GDI+ drawing only.
#define P_ID_TRANSPARENTVALUE					 1717 // INT

//////////////////////////////////////////////////////////////////////////
// Layer property IDs
#define P_ID_LAYER_ID							 1718 // INT

// Label showing or hiding.
#define P_ID_LABEL_SHOW							 1719 // BOOL

//////////////////////////////////////////////////////////////////////////
// Custom gradient drawing property IDs.
#define P_ID_GRADIENT_TYPE						 1720 // INT
#define P_ID_GRADIENT_ANGLE						 1721 // INT
#define P_ID_GRADIENT_BORDER					 1722 // INT
#define P_ID_GRADIENT_CENTERX					 1723 // INT
#define P_ID_GRADIENT_CENTERY					 1724 // INT
#define P_ID_IMAGE_FILE							 1725 // CString

// Up - right link shape's center arrow.
#define P_ID_SHOW_UPRIGHTLINK_CENTER_ARROW		 1730 // BOOL
#define P_ID_SHOW_UPRIGHTLINK_CORNER_DOT		 1731 // BOOL

// Border style.
#define P_ID_BORDER_TYPE						 1732 // int

// Is disable with button or not.
#define P_ID_DISABLED							 1733 // BOOL

// Show or hide in pan window
#define P_ID_PAN_SHOW							 1734 // BOOL
#define P_ID_ALLOW_CLICKONPATH					 1735 // BOOL

/////////////////////////////////////////////////////////////
// Property IDs define, these property values defined for font work shape only.

#define P_ID_LABEL                               1800 // BOOL
#define P_ID_FACENAME                            1801 // CString
#define P_ID_FONTSIZE                            1802 // INT
#define P_ID_BOLD                                1803 // BOOL
#define P_ID_ITALIC                              1804 // BOOL
#define P_ID_WITH_SVG_EXPORT					 1805 // BOOL

// Event style
#define P_ID_EVENT_TYPE							 1900 // INT
#define P_ID_CURSOR_TYPE						 1901 // INT
#define P_ID_EVENT_STRING						 1902 // CString
#define P_ID_TOOPTIP							 1903 // CString

// Value change script text.
#define P_ID_VALUECHANGE_SCRIPT					 1904 // CString.

///////////////////////////////////////////////////////////////////////////////
// Define gauge property IDs
#define P_ID_GAUGE_MAJOR_TICK_WIDTH				 1908 // INT
#define P_ID_GAUGE_TICK_WIDTH					 1909 // INT
#define P_ID_GAUGE_SIMPLE_TEXT					 1910 // BOOL
#define P_ID_GAUGE_LABEL_STYLE					 1911 // INT
#define P_ID_GAUGE_MAJOR_MARK_STYLE				 1912 // INT
#define P_ID_GAUGE_MARK_STYLE					 1913 // INT
#define P_ID_GAUGE_MAJOR_TICK_COLOR				 1914 // COLORREF
#define P_ID_GAUGE_TICK_COLOR					 1915 // COLORREF
#define P_ID_GAUGE_NEEDLE_COLOR					 1916 // COLORREF
#define	P_ID_GAUGE_NEEDLE_TYPE					 1917 // INT
#define P_ID_GAUGE_ARCLINE_SHOW					 1918 // BOOL
#define P_ID_GAUGE_BORDER_SHOW					 1919 // BOOL
#define P_ID_GAUGE_START_ANGLE					 1920 // INT
#define P_ID_GAUGE_SWEEP_ANGLE					 1921 // INT
#define P_ID_GAUGE_AUTO_START					 1924 // BOOL
#define P_ID_STATE_VALUE						 1925 // CString
#define P_ID_STATE_STRING						 1926 // CString
#define P_ID_GAUGE_INDICATOR_LEN				 1927 // INT

// Port connect type
#define P_ID_PORT_CONNECT_TYPE					 1928 // INT 0 -- Can be connect in and out, 1--can only be in, 2-- can only be out

// Sign link mark type.
#define P_ID_SIGN_LINK_MARK_TYPE				 1929 // INT

// Port connect allowing links number.
#define P_ID_PORT_CONNECT_NUMBER				 1930 // INT number links that can link to this port, default -1, it means no limit, it can be -1, 0, 1, ... etc.

#define P_ID_GAUGE_SCALE_BORDER_COLOR1			 1931 // Color
#define P_ID_GAUGE_SCALE_BORDER_COLOR2			 1932 // Color
#define P_ID_LINK_MOVE_PATH_SHAPE				 1933 // String

#define P_ID_GAUGE_TICK_UNIT					 1934 // INT

// enum FO_CONTROL_HANDLE
// {
// 	TopLeft = 0,				// 1.Top left handle.
// 	TopMiddle,					// 2.Top middle handle.		
// 	TopRight,					// 3.Top right handle.        0*********1*********2
// 	SideRight,					// 4.Right side handle.       *					  *
// 	BottomRight,				// 5.Bottom right handle	  *					  *
// 	BottomMiddle,				// 6.Bottom middle handle	  7			8		  3				
// 	BottomLeft,					// 7.Bottom left handle		  *					  *
// 	SideLeft,					// 8.Side left handle.		  *					  *
// 	BeCenter					// 9.Center handle.			  6*********5*********4
// };
#define P_ID_GAUGE_INDICATOR_ORIGIN              1935 // INT 0 - 8
#define P_ID_GAUGE_METER_POSITION				 1936 // INT	
#define P_ID_GAUGE_DRAW_TYPE					 1937 // INT, 0-2, 0 -- Ellipse, 1 -- Rect, 2 -- Draw none				

////////////////////////////////////////////////////////////////
// Property IDs defined for dash line.

#define ID_FOP_DOTS                              1940 // INT
#define ID_FOP_DOTLENGTH                         1941 // INT
#define ID_FOP_DASHES                            1942 // INT
#define ID_FOP_DASHLENGTH                        1943 // INT
#define ID_FOP_DISTANCE                          1944 // INT
#define ID_PROP_NNEWLINEWIDTH                    1945 // INT

// Drop arrow property ID value.
#define ID_PROP_DROPARROW_SHOW                   1946 // BOOL

// Drop menu property ID value
#define ID_PROP_DROPMENU_SHOW                    1947 // BOOL

// Table border line width.
#define ID_TABLE_BORDER_LINE_WIDTH				 1948 // INT
#define ID_TABLE_BORDER_LINE_COLOR				 1949 // COLOR

#define ID_IMAGE_RESIZE_TYPE					 1950 // 0 -- no resize, 1 - resize freely, 2 resize ratio

/////////////////////////////////////////////////////////////////////////////
// CFOFillProperties, this class is used for each default shape.

//************************************************************
//   CFOFillProperties
//
// This class defines all the fill default properties values for CFODrawShape,
// you can call FindProperty which is defined within class CFODrawShape to search
// this properties object.
//
//************************************************************

class CFOBitmap;

 
//===========================================================================
// Summary:
//     The CFOFillProperties class derived from CFOBaseProperties
//      F O Fill Properties
//===========================================================================

class FO_EXT_CLASS CFOFillProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFillProperties---F O Fill Properties, Specifies a E-XD++ CFOFillProperties object (Value).
	DECLARE_SERIAL(CFOFillProperties)

// Construction/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor with ID,each property class must have an unique ID,the IDs below FO_CUSTOM_PROP_ID is protected by ucancode
	// for its use,your own property ID must be higher than FO_CUSTOM_PROP_ID.
	// nCurID -- ID value of the property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fill Properties, Constructs a CFOFillProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOFillProperties(int nCurID = FO_DEFAULT_PROP_ID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fill Properties, Constructs a CFOFillProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOFillProperties& propShape object(Value).
	CFOFillProperties(const CFOFillProperties& propShape);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Fill Properties, Destructor of class CFOFillProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFillProperties();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Copy Properties
	// Create a copying of the property values.
	virtual CFOBaseProperties* Copy();

public:

	/*************************************************************************
	|*
	|* Fill brush properties
	|*
	\************************************************************************/

	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	// crBkColor -- new back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Is It Transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTransparent() const;

	// Change to transparent fill mode.
	// bTransparent -- transparent or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void		SetTransparent(const BOOL &bTransparent);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// Get Brush Hatch
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushHatch() const;

	// Change Brush Hatch type,must be (nHatch < HS_HORIZONTAL || nHatch > HS_DIAGCROSS)
	// nHatch -- hatch style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Hatch, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetBrushHatch(const int &nHatch);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,shape use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	// cr -- new pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Obtain the pattern bitmap pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed
	CFOBitmap*  GetPatBitmap() const { return m_pPatBitmap; }
	
	// Change the pointer of the patter bitmap.
	// pPat -- pattern bitmap pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Bitmap, Sets a specify value to current class CFOFillProperties
	// Parameters:
	//		pPat---pPat, A pointer to the CFOBitmap or NULL if the call failed.
	void		SetPatBitmap(CFOBitmap* pPat);

public:

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Specify the ID of property.
		// All the property ID is defined at the header of this class.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	
	// Define for brush.
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOFillProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateBrush(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);


	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

protected:

	// Get bitmap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

public:
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOFillProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFillProperties& propEdit object(Value).
	virtual CFOFillProperties& operator=(const CFOFillProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFillProperties propEdit object(Value).
	virtual BOOL operator==(const CFOFillProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize Data
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

// Attributes
protected:

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The transparent brush.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// The brush hatch type.
 
	// Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHatch;

	// Cached GDI brush. 
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*			m_pBrush;

	// Fill pattern bitmap.
 
	// Pattern Bitmap, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap*		m_pPatBitmap;

	// Bitmap pointer.
 
	// Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*		m_ptrBitmap;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;

};

///////////////////////////////////////////////////////////////////////////
// CFOTransparentProperties

 
//===========================================================================
// Summary:
//     The CFOTransparentProperties class derived from CFOBaseProperties
//      F O Transparent Properties
//===========================================================================

class FO_EXT_CLASS CFOTransparentProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTransparentProperties---F O Transparent Properties, Specifies a E-XD++ CFOTransparentProperties object (Value).
	DECLARE_SERIAL(CFOTransparentProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID,each property class must have an unique ID,the IDs below FO_CUSTOM_PROP_ID is protected by ucancode
	// for its use,your own property ID must be higher than FO_CUSTOM_PROP_ID.
	// nCurID -- ID value of the property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Transparent Properties, Constructs a CFOTransparentProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOTransparentProperties(int nCurID = FO_EXT_TRANSPARENT_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Transparent Properties, Constructs a CFOTransparentProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOTransparentProperties& propShape object(Value).
	CFOTransparentProperties(const CFOTransparentProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Transparent Properties, Destructor of class CFOTransparentProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTransparentProperties();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Copy Properties
	// Create a copying of the property values.
	virtual CFOBaseProperties* Copy();
	
public:
	
	
	// Get transparent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent Value, Returns the specified value.
	//		Returns An 8-bit BYTE integer that is not signed.
	BYTE		GetTransparentValue() const { return m_nTransparent; }
	
	// Change transparent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent Value, Sets a specify value to current class CFOTransparentProperties
	// Parameters:
	//		&nTrans---&nTrans, Specifies An 8-bit BYTE integer that is not signed.
	void		SetTransparentValue(const BYTE &nTrans) { m_nTransparent = nTrans; }
	
public:
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Specify the ID of property.
		// All the property ID is defined at the header of this class.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOTransparentProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOTransparentProperties& propEdit object(Value).
	virtual CFOTransparentProperties& operator=(const CFOTransparentProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOTransparentProperties propEdit object(Value).
	virtual BOOL operator==(const CFOTransparentProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize Data
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Attributes
protected:
	
	// Transparent value, it is defined for only GDI+ drawing.
 
	// Transparent, This member sets An 8-bit integer that is not signed.  
	BYTE			m_nTransparent;
	
};


//////////////////////////////////////////////////////////////////////
// CFOLineProperties, this class defined the line properties of shape.

 
//===========================================================================
// Summary:
//     The CFOLineProperties class derived from CFOBaseProperties
//      F O Line Properties
//===========================================================================

class FO_EXT_CLASS CFOLineProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOLineProperties---F O Line Properties, Specifies a E-XD++ CFOLineProperties object (Value).
	DECLARE_SERIAL(CFOLineProperties)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Properties, Constructs a CFOLineProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOLineProperties(int nCurID = FO_EXT_LINE_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Properties, Constructs a CFOLineProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOLineProperties& propShape object(Value).
	CFOLineProperties(const CFOLineProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Line Properties, Destructor of class CFOLineProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOLineProperties();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

	//Define for brush.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pen, You construct a CFOLineProperties object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreatePen(CDC* pDC = NULL);
	
	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetPen(CDC* pDC = NULL);
	
	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen Object, .

	void ReleasePenObject();
	
public:
	
	/*************************************************************************
	|*
	|* Pen properties
	|*
	\************************************************************************/
	
	// Get Line Width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int			GetLineWidth() const		{ return m_nLineWidth; }
	
	// Change the line with.
	// nWidth -- new line width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class CFOLineProperties
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void		SetLineWidth(const int &nWidth);
	
	// Get Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetLineColor() const		{ return m_crLine; }
	
	// Change the Line Color
	// crColor -- new line color or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class CFOLineProperties
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetLineColor(const COLORREF &crColor);
	
	// Is It Null Pen
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null Pen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsNullPen() const;
	
	// Set Null Pen,with null pen,the pen width is 0.
	// bNull -- null pen or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Null Pen, Sets a specify value to current class CFOLineProperties
	// Parameters:
	//		&bNull---&bNull, Specifies A Boolean value.
	void		SetNullPen(const BOOL &bNull);
	
	// Get Pen Style,return with PS_SOLID,PS_DOT...etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Style, Returns the specified value.
	//		Returns a int type value.
	int			GetPenStyle() const;
	
	// Change the Pen Style.
	// nPenStyle -- must be the PS_SOLID,PT_DOT...etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Style, Sets a specify value to current class CFOLineProperties
	// Parameters:
	//		&nPenStyle---Pen Style, Specifies A integer value.
	void		SetPenStyle(const int &nPenStyle);
	
// Attributes
protected:
	// FODO:Add your properties items below.

public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOLineProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOLineProperties& propEdit object(Value).
	virtual CFOLineProperties& operator=(const CFOLineProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOLineProperties propEdit object(Value).
	virtual BOOL operator==(const CFOLineProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// The line width.
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineWidth;
	
	// The line color.
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLine;
	
	// Transparent pen.
 
	// Null Pen, This member sets TRUE if it is right.  
	BOOL			m_bNullPen;
	
	// Pen style.
 
	// Pen Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPenStyle;
	
	// Pen.
 
	// Pen, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen*			m_pPen;

};

_FOLIB_INLINE CFOBaseProperties* CFOLineProperties::Copy()
{
	return new CFOLineProperties(*this);
}

////////////////////////////////////////////////////////////////////////
// CFOShadowProperties, this is the shadow properties of all shapes

 
//===========================================================================
// Summary:
//     The CFOShadowProperties class derived from CFOBaseProperties
//      F O Shadow Properties
//===========================================================================

class FO_EXT_CLASS CFOShadowProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShadowProperties---F O Shadow Properties, Specifies a E-XD++ CFOShadowProperties object (Value).
	DECLARE_SERIAL(CFOShadowProperties)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shadow Properties, Constructs a CFOShadowProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOShadowProperties(int nCurID = FO_EXT_SHADOW_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shadow Properties, Constructs a CFOShadowProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOShadowProperties& propShape object(Value).
	CFOShadowProperties(const CFOShadowProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shadow Properties, Destructor of class CFOShadowProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOShadowProperties();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

protected:
	
	// Get bitmap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

public:
	
	/*************************************************************************
	|*
	|* Shadow properties
	|*
	\************************************************************************/
	
	// Define for shadow.
	// Get shadow color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetShadowColor() const;
	
	// Change the shadow color,this is used by shadow brush,the shadow brush type must be 1.
	// crColor -- shadow color or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Color, Sets a specify value to current class CFOShadowProperties
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetShadowColor(const COLORREF &crColor);
	
	// Get shadow pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetShadowPatternColor() const;
	
	// Set shadow pattern color,change the shadow pattern color,this is used by shdow pattern color,the shadow brush type
	// must be 2.
	// crColor -- shadow pattern color or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Pattern Color, Sets a specify value to current class CFOShadowProperties
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetShadowPatternColor(const COLORREF &crColor);
	
	// Get shadow brush type,it is a value from 0 - 91,
	// 0 -- Null brush.
	// 1 -- fill with shadow color.
	// 2 -- fill with shadow pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Brush Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetShadowBrushType() const;
	
	// Change shadow brush type,
	// 0 -- Null brush.
	// 1 -- fill with shadow color.
	// 2 -- fill with shadow pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Brush Type, Sets a specify value to current class CFOShadowProperties
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetShadowBrushType(const UINT &nType);
	
	// Get shadow brush hatch.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetShadowBrushHatch() const;
	
	// Change the shadow brush hatch.
	// nHatch -- shadow brush hatch or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Brush Hatch, Sets a specify value to current class CFOShadowProperties
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetShadowBrushHatch(const int &nHatch);

public:
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Shadow Brush, You construct a CFOShadowProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateShadowBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetShadowBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Shadow Brush Object, .

	void ReleaseShadowBrushObject();

	//Define for shadow pen.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Shadow Pen, You construct a CFOShadowProperties object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreateShadowPen(CDC* pDC = NULL);
	
	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetShadowPen(CDC* pDC = NULL);
	
	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Shadow Pen Object, .

	void ReleaseShadowPenObject();

// Attributes
protected:
	// FODO:Add your properties items below.

public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOShadowProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOShadowProperties& propEdit object(Value).
	virtual CFOShadowProperties& operator=(const CFOShadowProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOShadowProperties propEdit object(Value).
	virtual BOOL operator==(const CFOShadowProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Define for shadow.
	
	// Shadow pen pointer.
 
	// Shadow, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen*			m_penShadow;

	// Define for shadow color.
 
	// Shadow Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crShadowColor;
	
	// Define for shadow pattern.
 
	// Shadow Pattern Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crShadowPatternColor;

	// The brush type.
 
	// Shadow Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nShadowBrushType;
	
	// The brush hatch type.
 
	// Shadow Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nShadowHatch;
	
	// Cached GDI brush. 
 
	// Shadow Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*			m_pShadowBrush;

};

/////////////////////////////////////////////////////////////
// Property IDs define.

 
//===========================================================================
// Summary:
//     The CFOEventProperties class derived from CFOBaseProperties
//      F O Event Properties
//===========================================================================

class FO_EXT_CLASS CFOEventProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOEventProperties---F O Event Properties, Specifies a E-XD++ CFOEventProperties object (Value).
	DECLARE_SERIAL(CFOEventProperties)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Event Properties, Constructs a CFOEventProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOEventProperties(int nCurID = FO_EXT_EVENT_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Event Properties, Constructs a CFOEventProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOEventProperties& propShape object(Value).
	CFOEventProperties(const CFOEventProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Event Properties, Destructor of class CFOEventProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOEventProperties();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	/*************************************************************************
	|*
	|* Event properties.
	|*
	\************************************************************************/

	// Event type.
	// Get event type,it returns a value from 0 - 5,
	// 0 -- None event.
	// 1 -- Send email event.
	// 2 -- Open URL
	// 3 -- Execute a file.
	// 4 -- Execute an application.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Event Type, Returns the specified value.
	//		Returns a int type value.
	int GetEventType() const;

	// Change the event type,
	// nEvent -- it must be one of the value from 0 - 5
	// 0 -- None event.
	// 1 -- Send email event.
	// 2 -- Open URL
	// 3 -- Execute a file.
	// 4 -- Execute an application.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Event Type, Sets a specify value to current class CFOEventProperties
	// Parameters:
	//		&nEvent---&nEvent, Specifies A integer value.
	void SetEventType(const int &nEvent);

	// Get event string.
	// It returns one of the following string:
	// Event type 0 -- Null string
	// Event type 1 -- email address,like: mailto:support@ucancode.net.
	// Event type 2 -- URL address,like:http://www.ucancode.net
	// Event type 3 -- File name,like:c:\\1.txt.
	// Event type 4 -- Application name,like: c:\\visioapp.exe.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Event String, Returns the specified value.
	//		Returns a CString type value.
	CString GetEventString() const;

	// Set event string.
	// str -- It must be one of the following string:
	// Event type 0 -- Null string
	// Event type 1 -- email address,like: mailto:support@ucancode.net.
	// Event type 2 -- URL address,like:http://www.ucancode.net
	// Event type 3 -- File name,like:c:\\1.txt.
	// Event type 4 -- Application name,like: c:\\visioapp.exe.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Event String, Sets a specify value to current class CFOEventProperties
	// Parameters:
	//		&str---Specifies A CString type value.
	void SetEventString(const CString &str);

// Attributes
protected:
	// FODO:Add your properties items below.
	// Event type.
 
	// Event Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nEventType;

	// Event string.
 
	// Event String, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strEventString;

public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOEventProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOEventProperties& propEdit object(Value).
	virtual CFOEventProperties& operator=(const CFOEventProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOEventProperties propEdit object(Value).
	virtual BOOL operator==(const CFOEventProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

_FOLIB_INLINE CFOBaseProperties* CFOEventProperties::Copy()
{
	return new CFOEventProperties(*this);
}

// Get event type.
_FOLIB_INLINE int CFOEventProperties::GetEventType() const 
{ 
	return m_nEventType; 
}

	// Set event type.
_FOLIB_INLINE void CFOEventProperties::SetEventType(const int &nEvent) 
{ 
	m_nEventType = nEvent; 
}

	// Get event string.
_FOLIB_INLINE CString CFOEventProperties::GetEventString() const 
{ 
	return m_strEventString; 
}

	// Set event string.
_FOLIB_INLINE void CFOEventProperties::SetEventString(const CString &str) 
{ 
	m_strEventString = str; 
}

/////////////////////////////////////////////////////////////////////
// CFOToolTipProperties

 
//===========================================================================
// Summary:
//     The CFOToolTipProperties class derived from CFOBaseProperties
//      F O Tool Tip Properties
//===========================================================================

class FO_EXT_CLASS CFOToolTipProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOToolTipProperties---F O Tool Tip Properties, Specifies a E-XD++ CFOToolTipProperties object (Value).
	DECLARE_SERIAL(CFOToolTipProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Tip Properties, Constructs a CFOToolTipProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOToolTipProperties(int nCurID = FO_EXT_TOOLTIP_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Tip Properties, Constructs a CFOToolTipProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOToolTipProperties& propShape object(Value).
	CFOToolTipProperties(const CFOToolTipProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Tip Properties, Destructor of class CFOToolTipProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolTipProperties();
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
	
/*************************************************************************
|*
|* Basic properties
|*
	\************************************************************************/
	
	
	// Return ToolTip value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tool Tip, Returns the specified value.
	//		Returns a CString type value.
	CString GetToolTip() const { return m_strToolTip;}
	
	// Change ToolTip value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tool Tip, Sets a specify value to current class CFOToolTipProperties
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetToolTip( const CString &strValue ) {m_strToolTip = strValue; }
	
	// Attributes
protected:
	// FODO:Add your properties items below.
	
	// ToolTip value.
 
	// Tool Tip, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strToolTip;
	
public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOToolTipProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOToolTipProperties& propEdit object(Value).
	virtual CFOToolTipProperties& operator=(const CFOToolTipProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOToolTipProperties propEdit object(Value).
	virtual BOOL operator==(const CFOToolTipProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

_FOLIB_INLINE CFOBaseProperties* CFOToolTipProperties::Copy()
{
	return new CFOToolTipProperties(*this);
}

//////////////////////////////////////////////////////////////////
// CFOCursorProperties

 
//===========================================================================
// Summary:
//     The CFOCursorProperties class derived from CFOBaseProperties
//      F O Cursor Properties
//===========================================================================

class FO_EXT_CLASS CFOCursorProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOCursorProperties---F O Cursor Properties, Specifies a E-XD++ CFOCursorProperties object (Value).
	DECLARE_SERIAL(CFOCursorProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Cursor Properties, Constructs a CFOCursorProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOCursorProperties(int nCurID = FO_EXT_CURSOR_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Cursor Properties, Constructs a CFOCursorProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOCursorProperties& propShape object(Value).
	CFOCursorProperties(const CFOCursorProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Cursor Properties, Destructor of class CFOCursorProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCursorProperties();
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
/*************************************************************************
|*
|* Cursor properties.
|*
	\************************************************************************/
	
	// Get cursor type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cursor Type, Returns the specified value.
	//		Returns a int type value.
	int GetCursorType() const;
	
	// Change the cursor type,
	// nType -- the Resource ID of the cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cursor Type, Sets a specify value to current class CFOCursorProperties
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void SetCursorType(const int &nType);
	
	// Attributes
protected:
	
	// cursor type.
 
	// Cursor Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCursorType;
	
	
public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOCursorProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOCursorProperties& propEdit object(Value).
	virtual CFOCursorProperties& operator=(const CFOCursorProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOCursorProperties propEdit object(Value).
	virtual BOOL operator==(const CFOCursorProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

_FOLIB_INLINE CFOBaseProperties* CFOCursorProperties::Copy()
{
	return new CFOCursorProperties(*this);
}

// Get event type.
_FOLIB_INLINE int CFOCursorProperties::GetCursorType() const 
{ 
	return m_nCursorType; 
}

// Set event type.
_FOLIB_INLINE void CFOCursorProperties::SetCursorType(const int &nType) 
{ 
	m_nCursorType = nType; 
}

///////////////////////////////////////
// Default bullet color.
const COLORREF  fo_DefaultBulletColor		= RGB(0,0,0);

 
//===========================================================================
// Summary:
//     The CFOFontProperties class derived from CFOBaseProperties
//      F O Font Properties
//===========================================================================

class FO_EXT_CLASS CFOFontProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFontProperties---F O Font Properties, Specifies a E-XD++ CFOFontProperties object (Value).
	DECLARE_SERIAL(CFOFontProperties)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Properties, Constructs a CFOFontProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOFontProperties(int nCurID = FO_EXT_FONT_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Font Properties, Constructs a CFOFontProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOFontProperties& propShape object(Value).
	CFOFontProperties(const CFOFontProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Font Properties, Destructor of class CFOFontProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontProperties();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

protected:
	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*			m_pFont;

public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	// nPointSize -- font point size.
	// pDC -- pointer of the dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	// nHeight -- height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	// Change the Font Color
	// crColor -- font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	// bItalic -- italic or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	// bUnderline -- underline or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	// bStrikeout -- strikeout or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOFontProperties
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

public:
	// Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOFontProperties object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont* CreateFont(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void ReleaseFontObject();

protected:

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// From Logical To Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOFontProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFontProperties& propEdit object(Value).
	virtual CFOFontProperties& operator=(const CFOFontProperties& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFontProperties propEdit object(Value).
	virtual BOOL operator==(const CFOFontProperties &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

_FOLIB_INLINE CFOBaseProperties* CFOFontProperties::Copy()
{
	return new CFOFontProperties(*this);
}


_FOLIB_INLINE CString CFOFontProperties::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOFontProperties::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOFontProperties::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOFontProperties::GetFontColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOFontProperties::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOFontProperties::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOFontProperties::SetItalic(const BOOL &bItalic)
{
	ReleaseFontObject();
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOFontProperties::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOFontProperties::SetUnderline(const BOOL &bUnderline)
{
	ReleaseFontObject();
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOFontProperties::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOFontProperties::SetStrikeout(const BOOL &bStrikeout)
{
	ReleaseFontObject();
	m_bStrikeout = bStrikeout;
}

///////////////////////////////////////
// Default arrow information

 
//===========================================================================
// Summary:
//     The CFOCaptionProperties class derived from CFOBaseProperties
//      F O Caption Properties
//===========================================================================

class FO_EXT_CLASS CFOCaptionProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOCaptionProperties---F O Caption Properties, Specifies a E-XD++ CFOCaptionProperties object (Value).
	DECLARE_SERIAL(CFOCaptionProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Caption Properties, Constructs a CFOCaptionProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOCaptionProperties(int nCurID = FO_CAPTION_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Caption Properties, Constructs a CFOCaptionProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOCaptionProperties& propShape object(Value).
	CFOCaptionProperties(const CFOCaptionProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Caption Properties, Destructor of class CFOCaptionProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCaptionProperties();
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
	/*************************************************************************
	|*
	|* Basic properties
	|*
	\************************************************************************/
	
	
	// Define for text.
	// Get Object Caption,this is also the label of some shapes,such as CFOTextShape,CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const { return m_strCaption;}
	
	// Set Object Caption,you can also call this method to change the label of shapes,such as label of CFOTextShape
	// CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFOCaptionProperties
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(
		// Specify the new caption.
		const CString &str
		) { m_strCaption = str; }
	
	// Attributes
protected:
	// FODO:Add your properties items below.
	
	// Caption value.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strCaption;
	
public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOCaptionProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOCaptionProperties& propEdit object(Value).
	virtual CFOCaptionProperties& operator=(const CFOCaptionProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOCaptionProperties propEdit object(Value).
	virtual BOOL operator==(const CFOCaptionProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

_FOLIB_INLINE CFOBaseProperties* CFOCaptionProperties::Copy()
{
	return new CFOCaptionProperties(*this);
}

////////////////////////////////////////////////////////////////////
// CFOFlatProperties

 
//===========================================================================
// Summary:
//     The CFOFlatProperties class derived from CFOBaseProperties
//      F O Flat Properties
//===========================================================================

class FO_EXT_CLASS CFOFlatProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFlatProperties---F O Flat Properties, Specifies a E-XD++ CFOFlatProperties object (Value).
	DECLARE_SERIAL(CFOFlatProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Flat Properties, Constructs a CFOFlatProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOFlatProperties(int nCurID = FO_EXT_FLAT_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Flat Properties, Constructs a CFOFlatProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOFlatProperties& propShape object(Value).
	CFOFlatProperties(const CFOFlatProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Flat Properties, Destructor of class CFOFlatProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFlatProperties();
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
	
	// Is IT Flat,when it is flat,view call OnDrawFlat(..) method for drawing the shape,
	// else it call OnDraw3d(..) method for drawing the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Flat, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsFlat() const;
	
	// Set Flat,when it is flat,view call OnDrawFlat(..) method for drawing the shape,
	// else it call OnDraw3d(..) method for drawing the shape.
	// bF -- be flat or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Flat, Sets a specify value to current class CFOFlatProperties
	// Parameters:
	//		&bF---&bF, Specifies A Boolean value.
	void		SetFlat(const BOOL &bF);
	
	// Attributes
protected:
	
	// Is Flat or not
 
	// Flat, This member sets TRUE if it is right.  
	BOOL			m_bFlat;
	
public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOFlatProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFlatProperties& propEdit object(Value).
	virtual CFOFlatProperties& operator=(const CFOFlatProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFlatProperties propEdit object(Value).
	virtual BOOL operator==(const CFOFlatProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

_FOLIB_INLINE CFOBaseProperties* CFOFlatProperties::Copy()
{
	return new CFOFlatProperties(*this);
}
////////////////////////////////////////////////////////////////////
// CFONameProperties

 
//===========================================================================
// Summary:
//     The CFONameProperties class derived from CFOBaseProperties
//      F O Name Properties
//===========================================================================

class FO_EXT_CLASS CFONameProperties : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFONameProperties---F O Name Properties, Specifies a E-XD++ CFONameProperties object (Value).
	DECLARE_SERIAL(CFONameProperties)
		
		// Construction/Destruction
public:
	
	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Name Properties, Constructs a CFONameProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFONameProperties(int nCurID = FO_EXT_NAME_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Name Properties, Constructs a CFONameProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFONameProperties& propShape object(Value).
	CFONameProperties(const CFONameProperties& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Name Properties, Destructor of class CFONameProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFONameProperties();
	
	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();
	
	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);
	
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);
	
public:
/*************************************************************************
|*
|* Basic properties
|*
	\************************************************************************/
	
	// Get Object Name,returns the name of the shape,the object name is not used for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectName()	const { return m_strName;}
	
	// Get Object Name,change the name of the shape,if you need unique name,please override the:
	// GetUniqueName(..) method that defined within class CFODataModel.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Name, Sets a specify value to current class CFONameProperties
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectName(
		// Specify the name of shape.
		const CString &str
		) { m_strName = str; }
	
	// Attributes
protected:
	// FODO:Add your properties items below.
	// Name value.
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strName;
	
public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFONameProperties& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFONameProperties& propEdit object(Value).
	virtual CFONameProperties& operator=(const CFONameProperties& propEdit);
	
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);
	
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);
	
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFONameProperties propEdit object(Value).
	virtual BOOL operator==(const CFONameProperties &propEdit) const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);
	
	// Implementation
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

_FOLIB_INLINE CFOBaseProperties* CFONameProperties::Copy()
{
	return new CFONameProperties(*this);
}

///////////////////////////////////////
// Default port information
const int       fo_DefaultPortWidth         = 4;
const int       fo_DefaultPortHeight        = 4;
// PORT TYPE MUST BE ONE OF THE FOLLOWING VALUE:
// enum FO_PORT_TYPE
// {
// 	FO_PORT_NOTSHOW = -1,
// 	FO_PORT_RECT,
// 	FO_PORT_ELLIPSE,
// 	FO_PORT_DIAMOND,
// 	FO_PORT_TRIANGLE,
// 	FO_PORT_INVERT_TRIANGLE,
// 	FO_PORT_CROSSLINE,
// 	FO_PORT_CROSSLINENEW,
// 	FO_PORT_CUSTOM
// };
const FO_PORT_TYPE fo_DefaultPortType       = FO_PORT_CROSSLINENEW;

/////////////////////////////////////////////////////////////////////////////
// CFOExtCompProperties

//************************************************************
//   CFOExtCompProperties
//
// This properties object is only defined for Control shape.
//
//************************************************************

//************************************************************
//   CFOImageExtProp
//
// This properties object is only defined for image shape only.
//
//************************************************************

 
//===========================================================================
// Summary:
//     The CFOImageExtProp class derived from CFOBaseProperties
//      F O Image Extend Property
//===========================================================================

class FO_EXT_CLASS CFOImageExtProp : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageExtProp---F O Image Extend Property, Specifies a E-XD++ CFOImageExtProp object (Value).
	DECLARE_SERIAL(CFOImageExtProp)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Extend Property, Constructs a CFOImageExtProp object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOImageExtProp(int nCurID = FO_EXT_IMAGE_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Extend Property, Constructs a CFOImageExtProp object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOImageExtProp& propShape object(Value).
	CFOImageExtProp(const CFOImageExtProp& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Extend Property, Destructor of class CFOImageExtProp
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageExtProp();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	
	// Return Blue value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Blue, Returns the specified value.
	//		Returns a int type value.
	int GetBlue() const { return m_nBlue;}

	// Change Blue value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Blue, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetBlue( const int &nValue ) {m_nBlue = nValue; }

	// Return Red value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Red, Returns the specified value.
	//		Returns a int type value.
	int GetRed() const { return m_nRed;}

	// Change Red value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Red, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetRed( const int &nValue ) {m_nRed = nValue; }

	// Return Green value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Green, Returns the specified value.
	//		Returns a int type value.
	int GetGreen() const { return m_nGreen;}

	// Change Green value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Green, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetGreen( const int &nValue ) {m_nGreen = nValue; }

	// Return Bright value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bright, Returns the specified value.
	//		Returns a int type value.
	int GetBright() const { return m_nBright;}

	// Change Bright value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bright, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetBright( const int &nValue ) {m_nBright = nValue; }

	// Return Cont value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cont, Returns the specified value.
	//		Returns a int type value.
	int GetCont() const { return m_nCont;}

	// Change Cont value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cont, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetCont( const int &nValue ) {m_nCont = nValue; }

	// Return Gamma value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gamma, Returns the specified value.
	//		Returns a float value.
	float GetGamma() const { return m_fGamma;}

	// Change Gamma value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gamma, Sets a specify value to current class CFOImageExtProp
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetGamma( const float &fValue ) {m_fGamma = fValue; }

// Attributes
protected:
	// FODO:Add your properties items below.
	// Blue value.
 
	// Blue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nBlue;

	// Red value.
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nRed;

	// Green value.
 
	// Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nGreen;

	// Bright value.
 
	// Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nBright;

	// Cont value.
 
	// Cont, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nCont;

	// Gamma value.
 
	// Gamma, This member specify The float keyword designates a 32-bit floating-point number.  
	float                    m_fGamma;

public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOImageExtProp& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOImageExtProp& propEdit object(Value).
	virtual CFOImageExtProp& operator=(const CFOImageExtProp& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOImageExtProp propEdit object(Value).
	virtual BOOL operator==(const CFOImageExtProp &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

_FOLIB_INLINE CFOBaseProperties* CFOImageExtProp::Copy()
{
	return new CFOImageExtProp(*this);
}

 
//===========================================================================
// Summary:
//     The CFOFontworkExtProp class derived from CFOBaseProperties
//      F O Fontwork Extend Property
//===========================================================================

class FO_EXT_CLASS CFOFontworkExtProp : public CFOBaseProperties
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFontworkExtProp---F O Fontwork Extend Property, Specifies a E-XD++ CFOFontworkExtProp object (Value).
	DECLARE_SERIAL(CFOFontworkExtProp)

// Construction/Destruction
public:

	// Constructor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fontwork Extend Property, Constructs a CFOFontworkExtProp object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nCurID---Current I D, Specifies A integer value.
	CFOFontworkExtProp(int nCurID = FO_EXT_FONTWORK_PROP_ID);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fontwork Extend Property, Constructs a CFOFontworkExtProp object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOFontworkExtProp& propShape object(Value).
	CFOFontworkExtProp(const CFOFontworkExtProp& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Fontwork Extend Property, Destructor of class CFOFontworkExtProp
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFontworkExtProp();

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of current object.
	virtual CFOBaseProperties* Copy();

	// Take the name of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:
	
	// Return Label value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label, Returns the specified value.
	//		Returns a CString type value.
	CString GetLabel() const { return m_strLabel;}

	// Change Label value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label, Sets a specify value to current class CFOFontworkExtProp
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetLabel( const CString &strValue ) {m_strLabel = strValue; }

	// Return FaceName value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetFaceName() const { return m_strFaceName;}

	// Change FaceName value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOFontworkExtProp
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetFaceName( const CString &strValue ) {m_strFaceName = strValue; }

	// Return FontSize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a int type value.
	int GetFontSize() const { return m_nFontSize;}

	// Change FontSize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Size, Sets a specify value to current class CFOFontworkExtProp
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetFontSize( const int &nValue ) {m_nFontSize = nValue; }

	// Return Bold value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bold, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetBold() const { return m_bBold;}

	// Change Bold value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bold, Sets a specify value to current class CFOFontworkExtProp
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetBold( const BOOL &bValue ) {m_bBold = bValue; }

	// Return Italic value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetItalic() const { return m_bItalic;}

	// Change Italic value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOFontworkExtProp
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetItalic( const BOOL &bValue ) {m_bItalic = bValue; }

// Attributes
protected:
	// FODO:Add your properties items below.
	// Label value.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                           m_strLabel;

	// FaceName value.
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString                           m_strFaceName;

	// FontSize value.
 
	// Font Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                               m_nFontSize;

	// Bold value.
 
	// Bold, This member sets TRUE if it is right.  
	BOOL                              m_bBold;

	// Italic value.
 
	// Italic, This member sets TRUE if it is right.  
	BOOL                              m_bItalic;


public:
	
	// Sets this set of font properties equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOFontworkExtProp& value (Object).  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFontworkExtProp& propEdit object(Value).
	virtual CFOFontworkExtProp& operator=(const CFOFontworkExtProp& propEdit);

	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		propEdit---propEdit, Specifies a const CFOFontworkExtProp propEdit object(Value).
	virtual BOOL operator==(const CFOFontworkExtProp &propEdit) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

_FOLIB_INLINE CFOBaseProperties* CFOFontworkExtProp::Copy()
{
	return new CFOFontworkExtProp(*this);
}

#include "FOCompProperties.inl"

#endif // !defined(AFX_FOCOMPPROPERTIES_H__2EEABBF3_F19E_11DD_A432_525400EA266C__INCLUDED_)
