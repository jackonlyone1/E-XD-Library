//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOGRIDPROPDLG_H__900D5BB6_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FOGRIDPROPDLG_H__900D5BB6_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOGridPropDlg.h : header file
//
#include "FOPDropDownColorPickerButton.h"
#include "FOSliderEdit.h"
#include "FOImageButton.h"

/////////////////////////////////////////////////////////////////////////////
// CFOGridPropDlg dialog

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOGridPropDlg class derived from CDialog
//      F O Grid Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOGridPropDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Grid Property Dialog, Constructs a CFOGridPropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOGridPropDlg(CFODataModel *pModel,CWnd* pParent = NULL);   // standard constructor

	// Dialog Data
	//{{AFX_DATA(CFOGridPropDlg)
	enum { IDD = IDD_FO_GRIDPROP };			// dialog
 
	// Step, This member specify double object.  
	double	m_xStep;							// step of spin x	
 
	// Step, This member specify double object.  
	double	m_yStep;							// step of spin y
 
	// Show Grid, This member sets TRUE if it is right.  
	BOOL	m_bShowGrid;					// flag of show grid
 
	// Snap To Grid, This member sets TRUE if it is right.  
	BOOL	m_bSnapToGrid;					// Snap to gird.
 
	// Glue To Handle, This member sets TRUE if it is right.  
	BOOL	m_bGlueToHandle;				// Glue to handle.
 
	// Glue Spot, This member sets TRUE if it is right.  
	BOOL	m_bGlueSpot;
 
	// Glue Help Lines, This member sets TRUE if it is right.  
	BOOL	m_bGlueHelpLines;
 
	// Glue Interset Point, This member sets TRUE if it is right.  
	BOOL	m_bGlueIntersetPoint;
	//}}AFX_DATA
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnColor;			// object of class 
 
	// Grid, This member sets A 32-bit value used as a color value.  
	COLORREF			crGrid;				// color of grid
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *		m_pModel;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOGridPropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOGridPropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOGRIDPROPDLG_H__900D5BB6_F3E6_11DD_A438_525400EA266C__INCLUDED_)
