//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOImageShape.h: interface for the CFOImageShape class.
//
//////////////////////////////////////////////////////////////////////
 
#if !defined(AFX_FOIMAGESHAPE_H__900D5BB4_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FOIMAGESHAPE_H__900D5BB4_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Image Shape.
//------------------------------------------------------
#include "FOBitmap.h"
#include "FODrawPortsShape.h"
#include "FODefines.h"

/////////////////////////////////////////////////////////////////////////////
// FOImageObj
//************************************************************
//   FOImageObj
//
// This data object is only defined for image shape only.
//
//************************************************************

// Vert align
enum FOPImage_Box_Align 
{
	FOP_ALIGN_TOP = 0,
	FOP_ALIGN_BOTTOM,
	FOP_ALIGN_LEFT,
	FOP_ALIGN_RIGHT
};

///////////////////////////////////////////////////////////
// FOImageObj -- image object

 
//===========================================================================
// Summary:
//      To use a FOImageObj object, just call the constructor.
//      O Image Object
//===========================================================================

class FO_EXT_CLASS FOImageObj
{
public:
	// Pointer of the image
 
	// Draw Bitmap, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *				pDrawBitmap;

	// Angle.
 
	// Angle, Specify a A 32-bit signed integer.  
	long					 m_nAngle;

protected:

	// Blue value.
 
	// Blue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nBlue;

	// Red value.
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nRed;

	// Green value.
 
	// Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nGreen;

	// Bright value.
 
	// Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nBright;

	// Cont value.
 
	// Cont, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int                      m_nCont;

	// Gamma value.
 
	// Gamma, This member specify The float keyword designates a 32-bit floating-point number.  
	float                    m_fGamma;

public:
	
	// Return Blue value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Blue, Returns the specified value.
	//		Returns a int type value.
	int GetBlue() const { return m_nBlue;}

	// Change Blue value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Blue, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetBlue( const int &nValue ) {m_nBlue = nValue; }

	// Return Red value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Red, Returns the specified value.
	//		Returns a int type value.
	int GetRed() const { return m_nRed;}

	// Change Red value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Red, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetRed( const int &nValue ) {m_nRed = nValue; }

	// Return Green value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Green, Returns the specified value.
	//		Returns a int type value.
	int GetGreen() const { return m_nGreen;}

	// Change Green value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Green, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetGreen( const int &nValue ) {m_nGreen = nValue; }

	// Return Bright value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bright, Returns the specified value.
	//		Returns a int type value.
	int GetBright() const { return m_nBright;}

	// Change Bright value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bright, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetBright( const int &nValue ) {m_nBright = nValue; }

	// Return Cont value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cont, Returns the specified value.
	//		Returns a int type value.
	int GetCont() const { return m_nCont;}

	// Change Cont value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cont, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetCont( const int &nValue ) {m_nCont = nValue; }

	// Return Gamma value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gamma, Returns the specified value.
	//		Returns a float value.
	float GetGamma() const { return m_fGamma;}

	// Change Gamma value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gamma, Sets a specify value to current class FOImageObj
	// Parameters:
	//		&fValue---&fValue, Specifies A float value.
	void SetGamma( const float &fValue ) {m_fGamma = fValue; }

public:
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Image Object, Constructs a FOImageObj object.
	//		Returns A  value (Object).
	FOImageObj();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Object, Destructor of class FOImageObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOImageObj();

	// Is changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rotate Changed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nAngle---&nAngle, Specifies A 32-bit long signed integer.
	BOOL IsRotateChanged(const long &nAngle);

	// Is adjust values changed.
	// nLuminancePercent -- luminance value.
	// nContrastPercent -- contrast value
	// nChannelRPercent	-- rdd channel
	// nChannelGPercent -- green channel
	// nChannelBPercent -- blue channel
	// fGamma -- gamma value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Adjust Changed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nLuminancePercent---Luminance Percent, Specifies A integer value.  
	//		nContrastPercent---Contrast Percent, Specifies A integer value.  
	//		nChannelRPercent---Channel R Percent, Specifies A integer value.  
	//		nChannelGPercent---Channel G Percent, Specifies A integer value.  
	//		nChannelBPercent---Channel B Percent, Specifies A integer value.  
	//		fGamma---fGamma, Specifies A float value.
	virtual BOOL IsAdjustChanged(int nLuminancePercent,
									int nContrastPercent,
									int nChannelRPercent, 
									int nChannelGPercent, 
									int nChannelBPercent,
									float fGamma);

	// Rebuild bitmap image.
	// pImage -- pointer of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Image, .
	// Parameters:
	//		*pImage---*pImage, A pointer to the CFOBitmap  or NULL if the call failed.
	void RebuildImage(CFOBitmap *pImage);

};

/////////////////////////////////////////////////////////////////////////////
// CFOImageShape -- image shape that can load many kind of image files such as
//                  jpeg, gif, png, or mng files. ID: FO_COMP_IMAGE 22

 
//===========================================================================
// Summary:
//     The CFOImageShape class derived from CFODrawPortsShape
//      F O Image Shape
//===========================================================================

class FO_EXT_CLASS CFOImageShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageShape---F O Image Shape, Specifies a E-XD++ CFOImageShape object (Value).
	DECLARE_SERIAL(CFOImageShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Shape, Constructs a CFOImageShape object.
	//		Returns A  value (Object).
	CFOImageShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Shape, Constructs a CFOImageShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOImageShape& src object(Value).
	CFOImageShape(const CFOImageShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Shape, Destructor of class CFOImageShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOImageShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the image shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOImageShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pBitmap---*pBitmap, A pointer to the CBitmap  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Create from CBitmap pointer.
	virtual void Create(CBitmap *pBitmap, CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Load image from file.
	// strImagePath -- full path of image file.
	// crTransparent -- transparent color.
	// nImageType -- image type,it must be one of the following value:
	// enum FO_IMAGETYPE
	// {
	// 	FO_IMAGE_BMP = 0,
	// 	FO_IMAGE_ICO,
	// 	FO_IMAGE_PCX,
	// 	FO_IMAGE_JPG,
	// 	FO_IMAGE_PNG,
	// 	FO_IMAGE_GIF,
	// 	FO_IMAGE_TGA
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.  
	//		&nImageType---Image Type, Specifies a const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP object(Value).  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL LoadImage(CString strImagePath,const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP,COLORREF crTransparent = RGB(255,255,255));

	//-----------------------------------------------------------------------
	// Summary:
	// Load image from resource id.
	// nID -- image resource id.
	// crTransparent -- transparent color.
	// nImageType -- image type,it must be one of the following value:
	// enum FO_IMAGETYPE
	// {
	// 	FO_IMAGE_BMP = 0,
	// 	FO_IMAGE_ICO,
	// 	FO_IMAGE_PCX,
	// 	FO_IMAGE_JPG,
	// 	FO_IMAGE_PNG,
	// 	FO_IMAGE_GIF,
	// 	FO_IMAGE_TGA
	// };
	// pcszResourceType -- Resource type name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pcszResourceType---Resource Type, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&nImageType---Image Type, Specifies a const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP object(Value).  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL LoadImage(UINT nID,LPCTSTR pcszResourceType,const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP,COLORREF crTransparent = RGB(255,255,255));

	// Export to image.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	//-----------------------------------------------------------------------
	// Summary:
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOImageShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOImageShape& src object(Value).
	CFOImageShape& operator=(const CFOImageShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// called as object moved/resized
	// pArea -- pointer of the area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);
	
public:

	// Get image data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Data, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap ,or NULL if the call failed
	CFOBitmap *GetImageData() const	{ return m_pImagePtr->GetBitmap(); }

	// Image ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pointer, Returns the specified value.
	//		Returns a pointer to the object CFODrawImage,or NULL if the call failed
	CFODrawImage* GetPtr()				{ return m_pImagePtr; }

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOImageShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);

	// Is poly object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Polygon Object, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsPolyObject() const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Return the image property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Property, Returns the specified value.
	//		Returns a pointer to the object CFOImageExtProp ,or NULL if the call failed
	CFOImageExtProp *GetImageProperty() const;

	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

public:

	// Init image position.
	// nImageWidth -- image width.
	// nImageHeight -- image height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draw image in a box.
	// pDC -- pointer of the DC.
	// rcPos -- position of the image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual void DoDrawImage(CDC *pDC,CRect rcPos);

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bImageTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOImageShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Get transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetImageTransparentColor() const { return m_crImageTransparent; }

	// Set transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent Color, Sets a specify value to current class CFOImageShape
	// Parameters:
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	void SetImageTransparentColor(const COLORREF crTrans);

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );

	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();

	// Restore to default size of image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Default Size, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL RestoreDefaultSize();

	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Image Rectangle, .
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		&rcOld---&rcOld, Specifies a const FOPRect &rcOld object(Value).  
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	FOPRect CorrectImageRect(const FOPRect &rcOld, int nImageWidth, int nImageHeight);

	// Is validate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsValidate();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

protected:
	
	// Image data.
 
	// Image Data, This member specify E-XD++ CFOImageData object.  
	static CFOImageData m_ImageData;

protected:
	
	// Image data.
 
	// Image Pointer, This member specify E-XD++ CFODrawImageData object.  
	CFODrawImageData	m_pImagePtr;
	
	// Image data.
 
	// Image Rotate Pointer, This member maintains a pointer to the object CFODrawImage.  
	CFODrawImage*	   m_pImageRotatePtr;

	// Is transparent or not.
 
	// Image Transparent, This member sets TRUE if it is right.  
	BOOL				m_bImageTransparent;

	// Transparent color.
 
	// Image Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crImageTransparent;

	// And mask image object.
 
	// Image Pointer And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *			m_pImagePtrAndMask;

	// Or mask image object.
 
	// Image Pointer Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *			m_pImagePtrOrMask;

	// Image file type.
 
	// Image Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nImageType;

	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;

	// Current frame
 
	// Frame, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nFrame;

	// Is gif or not.
 
	// Gif, This member sets TRUE if it is right.  
	BOOL				m_bGif;

	// Drawing image.
 
	// Draw Image, This member specify FOImageObj object.  
	FOImageObj			m_DrawImage;
};


/////////////////////////////////////////////////////////////////////////////
// CFOIconShape -- shape that loading and showing icon file, an anchor point is 
//                 added for moving label. ID: FOP_ICON_SHAPE 217
//                  

 
//===========================================================================
// Summary:
//     The CFOIconShape class derived from CFODrawPortsShape
//      F O Icon Shape
//===========================================================================

class FO_EXT_CLASS CFOIconShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOIconShape---F O Icon Shape, Specifies a E-XD++ CFOIconShape object (Value).
	DECLARE_SERIAL(CFOIconShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Icon Shape, Constructs a CFOIconShape object.
	//		Returns A  value (Object).
	CFOIconShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Icon Shape, Constructs a CFOIconShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOIconShape& src object(Value).
	CFOIconShape(const CFOIconShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Icon Shape, Destructor of class CFOIconShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOIconShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOIconShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nIcon---&nIcon, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the icon shape from a CRect object.
	// nIcon -- icon resource ID.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const UINT &nIcon,CRect &rcPos,CString strCaption = _T(""));

public:
	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);


	// Change icon resource ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Resource, Sets a specify value to current class CFOIconShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetIconRes(const UINT &nRes) { m_nIconID = nRes; }

	// Change icon width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon Width, Sets a specify value to current class CFOIconShape
	// Parameters:
	//		&nW---&nW, Specifies A integer value.
	void SetIconWidth(const int &nW) { m_nIconWidth = nW; }

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOIconShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOIconShape& src object(Value).
	CFOIconShape& operator=(const CFOIconShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:
	// Id of the icon.
 
	// Icon I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT m_nIconID;

	// Icon item width and height.
 
	// Icon Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nIconWidth;

	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize m_szSavLabel;
};

/////////////////////////////////////////////////////////////////////////////
// CFOBitmapShape -- shape that loading and showing bitmap resource file, an anchor point is 
//                 added for moving label. ID: FOP_BITMAP_SHAPE 218
//                  

 
//===========================================================================
// Summary:
//     The CFOBitmapShape class derived from CFODrawPortsShape
//      F O Bitmap Shape
//===========================================================================

class FO_EXT_CLASS CFOBitmapShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBitmapShape---F O Bitmap Shape, Specifies a E-XD++ CFOBitmapShape object (Value).
	DECLARE_SERIAL(CFOBitmapShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Shape, Constructs a CFOBitmapShape object.
	//		Returns A  value (Object).
	CFOBitmapShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Shape, Constructs a CFOBitmapShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBitmapShape& src object(Value).
	CFOBitmapShape(const CFOBitmapShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bitmap Shape, Destructor of class CFOBitmapShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBitmapShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBitmapShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nBitmap---&nBitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the bitmap shape from a CRect object.
	// nBitmap -- bitmap resource ID
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const UINT &nBitmap,CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBitmapShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strBitmap---&strBitmap, Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the rectangle shape from a CRect object.
	// strBitmap -- bitmap resource name
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const CString &strBitmap,CRect &rcPos,CString strCaption = _T(""));

public:
	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Change to new image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap Resource, Sets a specify value to current class CFOBitmapShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBitmapRes(const UINT &nRes);


	// Change to new image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap Resource, Sets a specify value to current class CFOBitmapShape
	// Parameters:
	//		&strRes---&strRes, Specifies A CString type value.
	void SetBitmapRes(const CString &strRes);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;
	
	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBitmapShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBitmapShape& src object(Value).
	CFOBitmapShape& operator=(const CFOBitmapShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bImageTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOBitmapShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:
	// Id of the Bitmap.
 
	// Bitmap I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT m_nBitmapID;

	// Resource name.
 
	// Resource Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strResName;

	// Bitmap cache.
 
	// Bitmap Cache, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap * m_pBitmapCache;

	// Is transparent or not.
 
	// Image Transparent, This member sets TRUE if it is right.  
	BOOL	m_bImageTransparent;

	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize m_szSavLabel;
};


/////////////////////////////////////////////////////////////////////////////
// CFOImageListShape -- shape that loading and showing image list resource file, an anchor point is 
//                 added for moving label. ID: FOP_IMAGELIST_SHAPE 238
//                  

 
//===========================================================================
// Summary:
//     The CFOImageListShape class derived from CFODrawPortsShape
//      F O Image List Shape
//===========================================================================

class FO_EXT_CLASS CFOImageListShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageListShape---F O Image List Shape, Specifies a E-XD++ CFOImageListShape object (Value).
	DECLARE_SERIAL(CFOImageListShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image List Shape, Constructs a CFOImageListShape object.
	//		Returns A  value (Object).
	CFOImageListShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image List Shape, Constructs a CFOImageListShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOImageListShape& src object(Value).
	CFOImageListShape(const CFOImageListShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image List Shape, Destructor of class CFOImageListShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageListShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Creates the image list shape from a CRect object.
	// nImageId -- bitmap resource ID
	// nItemCount -- image item's count.
	// nCurItem -- current drawing item.
	// crTrans -- transparent color.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const UINT &nImageId,CRect &rcPos,
		const int &nCurItem = 0,
		const int &nItemWidth = 16,
		const COLORREF &crTrans = RGB(255,255,255),
	
	//-----------------------------------------------------------------------
	// Summary:
	// _T, .
	//		Returns a CString type value.  
	// Parameters:
	//		"")---Specifies a "") object(Value).
		CString strCaption = _T(""));

public:
	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Change to new image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap Resource, Sets a specify value to current class CFOImageListShape
	// Parameters:
	//		&nRes---&nRes, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBitmapRes(const UINT &nRes);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;
	
	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOImageListShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOImageListShape& src object(Value).
	CFOImageListShape& operator=(const CFOImageListShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

protected:

	// Bitmap cache.
 
	// Image List, This member is a collection of same-sized images.  
	CImageList* m_pImageList;

	// Current drawing item.
 
	// Current Draw Item, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurDrawItem;

	// Current item's width.
 
	// Item Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nItemWidth;

	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTrans;

	// Id of the Bitmap.
 
	// Bitmap I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nBitmapID;

	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize m_szSavLabel;
};

const FOPPoint fo_ImageDefaultConer = FOPPoint(12,12);
/////////////////////////////////////////////////////////////////////////////
// CFOPBitmapBoxShape -- shape that loading and showing bitmap file, an anchor point is 
//                 added for moving label. ID: FOP_BITMAP_BOX_SHAPE 248
//                  

 
//===========================================================================
// Summary:
//     The CFOPBitmapBoxShape class derived from CFOBitmapShape
//      F O P Bitmap Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPBitmapBoxShape : public CFOBitmapShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPBitmapBoxShape---F O P Bitmap Box Shape, Specifies a E-XD++ CFOPBitmapBoxShape object (Value).
	DECLARE_SERIAL(CFOPBitmapBoxShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Bitmap Box Shape, Constructs a CFOPBitmapBoxShape object.
	//		Returns A  value (Object).
	CFOPBitmapBoxShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Bitmap Box Shape, Constructs a CFOPBitmapBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPBitmapBoxShape& src object(Value).
	CFOPBitmapBoxShape(const CFOPBitmapBoxShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Bitmap Box Shape, Destructor of class CFOPBitmapBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPBitmapBoxShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPBitmapBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPBitmapBoxShape& src object(Value).
	CFOPBitmapBoxShape& operator=(const CFOPBitmapBoxShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;
	
public:

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Image alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Alignment, Sets a specify value to current class CFOPBitmapBoxShape
	// Parameters:
	//		nAlignment---nAlignment, Specifies a FOPImage_Box_Align nAlignment object(Value).
	void SetImageAlignment(FOPImage_Box_Align nAlignment);


	// Obtain image alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Alignment, Returns the specified value.
	//		Returns A FOPImage_Box_Align value (Object).
	FOPImage_Box_Align GetImageAlignment() const;


	// Enable cool back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Cool Back, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableCoolBack(const BOOL &bEnable) { m_bCoolBack = bEnable; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
public:

	//Draw flat status.
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Image horz align.
 
	// Image Alignment, This member specify FOPImage_Box_Align object.  
	FOPImage_Box_Align		m_nImageAlign;

	// With cool background.
 
	// Cool Back, This member sets TRUE if it is right.  
	BOOL					m_bCoolBack;

};

////////////////////////////////////////////////////////////////
// CFOPImageListBoxShape class

 
//===========================================================================
// Summary:
//     The CFOPImageListBoxShape class derived from CFOImageListShape
//      F O P Image List Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPImageListBoxShape : public CFOImageListShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPImageListBoxShape---F O P Image List Box Shape, Specifies a E-XD++ CFOPImageListBoxShape object (Value).
	DECLARE_SERIAL(CFOPImageListBoxShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image List Box Shape, Constructs a CFOPImageListBoxShape object.
	//		Returns A  value (Object).
	CFOPImageListBoxShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image List Box Shape, Constructs a CFOPImageListBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPImageListBoxShape& src object(Value).
	CFOPImageListBoxShape(const CFOPImageListBoxShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Image List Box Shape, Destructor of class CFOPImageListBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPImageListBoxShape();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPImageListBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPImageListBoxShape& src object(Value).
	CFOPImageListBoxShape& operator=(const CFOPImageListBoxShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Image alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Alignment, Sets a specify value to current class CFOPImageListBoxShape
	// Parameters:
	//		nAlignment---nAlignment, Specifies a FOPImage_Box_Align nAlignment object(Value).
	void SetImageAlignment(FOPImage_Box_Align nAlignment);


	// Obtain image alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Alignment, Returns the specified value.
	//		Returns A FOPImage_Box_Align value (Object).
	FOPImage_Box_Align GetImageAlignment() const;


	// Enable cool back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Cool Back, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableCoolBack(const BOOL &bEnable) { m_bCoolBack = bEnable; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
public:

	//Draw flat status.
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the Shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Image horz align.
 
	// Image Alignment, This member specify FOPImage_Box_Align object.  
	FOPImage_Box_Align		m_nImageAlign;

	// With cool background.
 
	// Cool Back, This member sets TRUE if it is right.  
	BOOL					m_bCoolBack;

};

 
//===========================================================================
// Summary:
//     The CFOPOneImageBoxShape class derived from CFOImageShape
//      F O P One Image Box Shape
//===========================================================================

class FO_EXT_CLASS CFOPOneImageBoxShape : public CFOImageShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPOneImageBoxShape---F O P One Image Box Shape, Specifies a E-XD++ CFOPOneImageBoxShape object (Value).
	DECLARE_SERIAL(CFOPOneImageBoxShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P One Image Box Shape, Constructs a CFOPOneImageBoxShape object.
	//		Returns A  value (Object).
	CFOPOneImageBoxShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P One Image Box Shape, Constructs a CFOPOneImageBoxShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPOneImageBoxShape& src object(Value).
	CFOPOneImageBoxShape(const CFOPOneImageBoxShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P One Image Box Shape, Destructor of class CFOPOneImageBoxShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPOneImageBoxShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPOneImageBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Init image position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

	// Calc text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOPOneImageBoxShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,CRect rcBox,CStringArray& arLines);

	// Get text box size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		strText---strText, Specifies A CString type value.
	virtual CSize GetTextSize(CDC* pDC,CRect rcPos,CString strText, const BOOL &bNeedFont = TRUE);

	// Get format type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Format Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetDrawFormatType();

	// Export to image.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bResize---&bResize, Specifies A Boolean value.
	virtual BOOL DoStartShowEdit(const BOOL &bResize = FALSE);

	// Show full size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Full Size, Do a event. 

	void DoShowFullSize();
    
	//-----------------------------------------------------------------------
	// Summary:
	// Load image from file.
	// strImagePath -- full path of image file.
	// crTransparent -- transparent color.
	// nImageType -- image type,it must be one of the following value:
	// enum FO_IMAGETYPE
	// {
	// 	FO_IMAGE_BMP = 0,
	// 	FO_IMAGE_ICO,
	// 	FO_IMAGE_PCX,
	// 	FO_IMAGE_JPG,
	// 	FO_IMAGE_PNG,
	// 	FO_IMAGE_GIF,
	// 	FO_IMAGE_TGA
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.  
	//		&nImageType---Image Type, Specifies a const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP object(Value).  
	//		crTransparent---crTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		255---Specifies a 255 object(Value).  
	//		255)---Specifies a 255) object(Value).
	BOOL LoadImage(CString strImagePath,const FO_IMAGETYPE &nImageType = FO_IMAGE_BMP,COLORREF crTransparent = RGB(255,255,255));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPOneImageBoxShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPOneImageBoxShape& src object(Value).
	CFOPOneImageBoxShape& operator=(const CFOPOneImageBoxShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		fOX---O X, Specifies A float value.  
	//		fOY---O Y, Specifies A float value.
	virtual void RotateShape(double nAngle, float fOX, float fOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		fOX---O X, Specifies A float value.  
	//		fOY---O Y, Specifies A float value.
	virtual void RotateTrackShape(double nAngle, float fOX, float fOY);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Image, Call this function to remove a specify value from the specify object.

	void RemoveOldImage();

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

 
	// Normal Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalPath;
 
	// Normal File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalFile;

};



#endif // !defined(AFX_FOIMAGESHAPE_H__900D5BB4_F3E6_11DD_A438_525400EA266C__INCLUDED_)
