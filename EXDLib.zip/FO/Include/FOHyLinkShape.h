//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOHYLINKSHAPE_H__233326F0_0A20_11D6_A504_525400EA266C__INCLUDED_)
#define AFC_FOHYLINKSHAPE_H__233326F0_0A20_11D6_A504_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FOStaticShape.h"
#include "FORectShape.h"
#include "E_Form\FOButtonShape.h"

///////////////////////////////////////////////////////////
// CFOHyLinkShape -- button link shape with Hyper Link feature, ID: FO_COMP_HYLINK 32

 
//===========================================================================
// Summary:
//     The CFOHyLinkShape class derived from CFOStaticShape
//      F O Hy Link Shape
//===========================================================================

class FO_EXT_CLASS CFOHyLinkShape : public CFOStaticShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOHyLinkShape---F O Hy Link Shape, Specifies a E-XD++ CFOHyLinkShape object (Value).
	DECLARE_SERIAL(CFOHyLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Hy Link Shape, Constructs a CFOHyLinkShape object.
	//		Returns A  value (Object).
	CFOHyLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Hy Link Shape, Constructs a CFOHyLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHyLinkShape& src object(Value).
	CFOHyLinkShape(const CFOHyLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Hy Link Shape, Destructor of class CFOHyLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOHyLinkShape();

	// Create button.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Change button shade style
	void SetShade(UINT shadeID=0,BYTE granularity=8,BYTE highlight=10,BYTE coloring=0,COLORREF color=0);
	
	//dotted margin offset
	short	m_FocusRectMargin;	


	// Drawing data.
	CFOPButtonDib	m_dNormal,m_dDown,m_dDisabled,m_dOver,m_dh,m_dv;

	// Capture the mouse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Capture Mouse, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bCapture---bCapture, Specifies A Boolean value.
	virtual void CaptureMouse(BOOL bCapture);

	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	
	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

public:
	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_KEYUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_SETCURSOT message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);

	// WM_COMMAND message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Action, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnAction(WPARAM wParam, LPARAM lParam);

	// WM_KILLFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	virtual void OnKillFocus(CWnd* pNewWnd);

	//	WM_SETFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	virtual  void OnSetFocus(CWnd* pOldWnd);

	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOHyLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOHyLinkShape& src object(Value).
	CFOHyLinkShape& operator=(const CFOHyLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;


public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws the Select status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcTotal---rcTotal, Specifies A CRect type value.
	virtual void OnDrawSelect(CDC *pDC,CRect rcTotal);

	// Draws the Select status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcTotal---rcTotal, Specifies A CRect type value.
	virtual void OnDrawFace(CDC *pDC,CRect rcTotal);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);
	
	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Mouse pressed.
 
	// Pressed, This member sets TRUE if it is right.  
	BOOL	m_bPressed;

	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL	m_bMouseDown;

	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL	m_bCanPress;

};

/////////////////////////////////////////////////////////////
// CFOPBorderShape -- shape with border support, it supports many kind of border style
//                    ID: FO_BORDER_SHAPE 258

 
//===========================================================================
// Summary:
//     The CFOPBorderShape class derived from CFORectShape
//      F O P Border Shape
//===========================================================================

class FO_EXT_CLASS CFOPBorderShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPBorderShape---F O P Border Shape, Specifies a E-XD++ CFOPBorderShape object (Value).
	DECLARE_SERIAL(CFOPBorderShape);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Border Shape, Constructs a CFOPBorderShape object.
	//		Returns A  value (Object).
	CFOPBorderShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Border Shape, Constructs a CFOPBorderShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPBorderShape& src object(Value).
	CFOPBorderShape(const CFOPBorderShape& src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Border Shape, Destructor of class CFOPBorderShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPBorderShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPBorderShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));
	
public:
	
	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPBorderShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPBorderShape& src object(Value).
	CFOPBorderShape& operator=(const CFOPBorderShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	

	// Get button background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Back Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetButtonBackColor();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);
	
	// Draw a rectangle	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);
	
	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draw border for the control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// new virtual function used to draw the button background in particular
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button Background, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		buttonRect---buttonRect, Specifies A CRect type value.
	virtual void DrawButtonBackground(CDC* pDC, CRect buttonRect);
	
	// calculates the parameters that define the shape of the button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Sphere Radius, .
	//		Returns a CSize type value.  
	// Parameters:
	//		nSphereExtRadius---Sphere Extend Radius, Specifies A integer value.  
	//		nSphereIntRadius---Sphere Int Radius, Specifies A integer value.
	CSize CalcSphereRadius(int nSphereExtRadius, int nSphereIntRadius);

	// new virtual function used to draw the button background in particular
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Button Background1, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		buttonRect---buttonRect, Specifies A CRect type value.
	virtual void DrawButtonBackground1(CDC* pDC, CRect buttonRect);
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

///////////////////////////////////////////////////////////////
// CFOPImageButtonShape -- image button that supports two images.

 
//===========================================================================
// Summary:
//     The CFOPImageButtonShape class derived from CFORectShape
//      F O P Image Button Shape
//===========================================================================

class FO_EXT_CLASS CFOPImageButtonShape : public CFORectShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPImageButtonShape---F O P Image Button Shape, Specifies a E-XD++ CFOPImageButtonShape object (Value).
	DECLARE_SERIAL(CFOPImageButtonShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image Button Shape, Constructs a CFOPImageButtonShape object.
	//		Returns A  value (Object).
	CFOPImageButtonShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Image Button Shape, Constructs a CFOPImageButtonShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPImageButtonShape& src object(Value).
	CFOPImageButtonShape(const CFOPImageButtonShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Image Button Shape, Destructor of class CFOPImageButtonShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPImageButtonShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPImageButtonShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the button component from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	// Show full size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Full Size, Do a event. 

	void DoShowFullSize();
    
public:
	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_KEYUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_SETCURSOT message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);

	// WM_KILLFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	virtual void OnKillFocus(CWnd* pNewWnd);

	//	WM_SETFOCUS message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	virtual  void OnSetFocus(CWnd* pOldWnd);

	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPImageButtonShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPImageButtonShape& src object(Value).
	CFOPImageButtonShape& operator=(const CFOPImageButtonShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this component.
	virtual CFODrawShape* Copy() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);


public:
	
	// Set the properties of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadImage(CString strImagePath);

	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Image, Call this function to remove a specify value from the specify object.

	void RemoveOldImage();

	// Load image from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Click Image, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strImagePath---Image Path, Specifies A CString type value.
	BOOL LoadClickImage(CString strImagePath);
	
	// Remove old image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Old Click Image, Call this function to remove a specify value from the specify object.

	void RemoveOldClickImage();

	// Init image position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Image Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		nImageWidth---Image Width, Specifies A integer value.  
	//		nImageHeight---Image Height, Specifies A integer value.
	virtual CRect DoInitImagePos(int nImageWidth,int nImageHeight);

	
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// call this method to put the text object into edit in place mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Show Edit, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bResize---&bResize, Specifies A Boolean value.
	virtual BOOL DoStartShowEdit(const BOOL &bResize = FALSE);
    
public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the Select status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Draws the 3D status of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareMask();

	// Create masks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Click Mask, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PrepareClickMask();

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Image Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsImageTransparent() const { return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent, Sets a specify value to current class CFOPImageButtonShape
	// Parameters:
	//		bTrans---bTrans, Specifies A Boolean value.
	void SetImageTransparent(const BOOL bTrans);

	// Get transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Transparent Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetImageTransparentColor() const { return m_crTransparent; }

	// Set transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Transparent Color, Sets a specify value to current class CFOPImageButtonShape
	// Parameters:
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	void SetImageTransparentColor(const COLORREF crTrans);
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

 
	// Normal Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalPath;
 
	// Normal File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strNormalFile;

 
	// Click Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strClickPath;
 
	// Click File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strClickFile;

 
	// Over Path, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOverPath;
 
	// Over File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOverFile;

	// Change the hit test color of polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Colors, Sets a specify value to current class CFOPImageButtonShape
	// Parameters:
	//		highlightClr---highlightClr, Specifies A 32-bit COLORREF value used as a color value.  
	//		downclr---Specifies A 32-bit COLORREF value used as a color value.
	void SetColors(COLORREF highlightClr, COLORREF  downclr)
	{
		m_clrHighlight = highlightClr;   // default ::GetSysColor(COLOR_3DHIGHLIGHT)
		m_clrShadow = downclr;           // default ::GetSysColor(COLOR_3DSHADOW);
	}
	
protected:
	
	// Mouse pressed.
 
	// Pressed, This member sets TRUE if it is right.  
	BOOL	m_bPressed;
	
	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL	m_bMouseDown;
	
	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL	m_bCanPress;
	
	// Colors for hit.
	COLORREF m_clrHighlight, m_clrShadow;
protected:
	
	// Image pointer.
 
	// Click Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImage;		
	
	// Is transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL m_bTransparent;
	
	// Transparent color.
 
	// Transparent, This member sets A 32-bit value used as a color value.  
	COLORREF m_crTransparent;
	
	// And mask image object.
 
	// Click Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageAndMask;
	
	// Or mask image object.
 
	// Click Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImageOrMask;
protected:

	// Image pointer.
 
	// Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImage;		

	// And mask image object.
 
	// Image And Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageAndMask;

	// Or mask image object.
 
	// Image Or Mask, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pImageOrMask;
};

#endif // !defined(AFC_FOHYLINKSHAPE_H__233326F0_0A20_11D6_A504_525400EA266C__INCLUDED_)
