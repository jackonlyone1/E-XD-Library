//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPTOOLBARBUTTON_H__8A69F251_6AC6_48EE_A463_367B01A206BA__INCLUDED_)
#define AFX_FOPTOOLBARBUTTON_H__8A69F251_6AC6_48EE_A463_367B01A206BA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPToolBarButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBarButton window
#include "FOPLineTypePickerDrawPanel.h"
#include "FOPImagePickerDrawPanel.h"
#include "FOPDropColorPickerDrawPanel.h"
#include "FOPPickerBaseWnd.h"
#include "FOPLineWidthPickerDrawPanel.h"
#include "FOPArrowPickerDrawPanel.h"
#include "FOPShadowPickerDrawPanel.h"
#include "FOUndoRedoWnd.h"
#include "FOPFlatComboBox.h"
#include "FOFontNameCombo.h"

// Drop arrow state of the toolbar button
enum fopDropArrow
{	
	AlwaysSingle, 
	AlwaysDropArrow, 
	DropArrowWhenHorizontal	
};

// Button style
enum FOPButtonStyle
{	
	BS_OWNERDRAWN = 1, 
	BS_DROPDOWNTOOLBAR = 2,
	BS_LARGESMALL = 4,
	BS_SINGLE = 8,
	BS_DROPARROWHORZ = 16
};

class CFOPToolBar;
/////////////////////////////////////////////////////////////////////////////
// CFOPBtnDrawHelper

 
//===========================================================================
// Summary:
//     The CFOPBtnDrawHelper class derived from CObject
//      F O P Button Draw Helper
//===========================================================================
class CFOPImage;
class FO_EXT_CLASS CFOPBtnDrawHelper : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPBtnDrawHelper---F O P Button Draw Helper, Specifies a E-XD++ CFOPBtnDrawHelper object (Value).
	DECLARE_SERIAL(CFOPBtnDrawHelper);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Button Draw Helper, Constructs a CFOPBtnDrawHelper object.
	//		Returns A  value (Object).
	CFOPBtnDrawHelper();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Button Draw Helper, Destructor of class CFOPBtnDrawHelper
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPBtnDrawHelper();

public:

	// D C Help, This member specify CDC object.  
	CDC m_dcTemp1;

	// D C, This member specify CDC object.  
	CDC m_dcTemp2;

	// Draw D C, This member specify CDC object.  
	CDC m_dcTemp3;

	// Border, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush m_brBorder;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Helper D C, Returns the specified value.
	//		Returns a pointer to the object CDC ,or NULL if the call failed
	CDC *GetDrawHelperDC() { return &m_dcTemp1; }

	//-----------------------------------------------------------------------
	// Summary:
	// Do method
	void DoMethodB4();
	
	// Set bitmap handle
	// hBmp -- handle of the bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bitmap, Sets a specify value to current class CFOPBtnDrawHelper
	// Parameters:
	//		hBmp---hBmp, Specifies a HBITMAP hBmp object(Value).
	void SetBitmap(CFOPImage* pBmp);

	CFOPImage *GetBitmap();

	//-----------------------------------------------------------------------
	// Summary:
	// Do method

	BOOL DoMethodB3(CDC & dc, int nWidth,int nHeight, CFOPToolBar* pBar);

	//-----------------------------------------------------------------------
	// Summary:
	// Do method

	void DoMethodB2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do method

	static HBRUSH DoMethodB1();
	
protected:

	// This member specify class object.  
	class Private;
	
	// This member maintains a pointer to the object Private.  
    Private * const m_d;
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBarButton

 
//===========================================================================
// Summary:
//      To use a CFOPToolBarButton object, just call the constructor.
//      F O P Tool Bar Button
//===========================================================================

class FO_EXT_CLASS CFOPToolBarButton
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Tool Bar Button, Constructs a CFOPToolBarButton object.
	//		Returns A  value (Object).
	CFOPToolBarButton();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Tool Bar Button, Destructor of class CFOPToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPToolBarButton();

public:
	
	// Support button type.
	enum FOPButtonType
	{
		FOP_NORMBUTTON,		// CFOPToolBarButton
		FOP_DROPARROW,		// CFOPDropArrowToolBarButton
		FOP_COMBOBUTTON,	// CFOPComboToolBarButton
		FOP_COMBOFONTBUTTON,	// CFOPFontFaceComboBox
		FOP_COMBOLAYERBUTTON,    // CFOPLayerComboBox
		FOP_TEXTBUTTON		// Text button.
	};
	
	struct FOPStyleChange
	{
		DWORD dwAddStyle;
		DWORD dwRemoveStyle;
	};
	
	// Button id.
 
	// I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nID;

	// Button image id.
 
	// Image, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nImage;

	// Button style.
 
	// Style, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nStyle;
	
	// Start x point.
 
	// Start X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_ptStartX;

	// Start y point.
 
	// Start Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_ptStartY;

	// Item width.
 
	// Item Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nItemWidth;

	// Item height.
 
	// Item Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nItemHeight;

	// Item type.
 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nType;

public:

	// Get item start x.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Start X, Returns the specified value.
	//		Returns a int type value.
	int GetItemStartX() const { return m_ptStartX; }

	// Get item start y.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Start Y, Returns the specified value.
	//		Returns a int type value.
	int GetItemStartY() const { return m_ptStartY; }

	// Get item width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Width, Returns the specified value.
	//		Returns a int type value.
	int GetItemWidth() const { return m_nItemWidth; }

	// Get item height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Height, Returns the specified value.
	//		Returns a int type value.
	int GetItemHeight() const { return m_nItemHeight; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize Data
	virtual void	Serialize(CArchive &ar);

	// Save Document
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle, .
	//		Returns a CRect type value.
	// Rectangle of the button item
	CRect GetARect()  { CRect r(m_ptStartX, m_ptStartY, m_ptStartX + m_nItemWidth, m_ptStartY + m_nItemHeight);	return r;}

public:

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		pBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.
	void MethodTemp17(CFOPToolBar * pBar);

	// Get button item position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		rc---Specifies A CRect type value.
	void MethodTemp16(CRect& rc) const;

	// Is hidden.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hidden, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsHidden() const;

	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void SetMode(BOOL bMode);

	// Set style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Style, Sets a specify value to current class CFOPToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void SetStyle(UINT nStyle);

	// Get style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetStyle() const;

	// Has specify style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Style, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL FindStyle(UINT nStyle) const;

	// Set position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetPos(int x, int y);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bErase---bErase, Specifies A Boolean value.
	// Invalidate.
	virtual void Invalidate(BOOL bErase = FALSE) const;
	
	// Transparent blt.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transparent Bitblt, .
	// Parameters:
	//		hdcDest---hdcDest, Specifies a HDC hdcDest object(Value).  
	//		nXDest---X Dest, Specifies A integer value.  
	//		nYDest---Y Dest, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		pDcSrc---Dc Source, A pointer to the CDC or NULL if the call failed.  
	//		nXSrc---X Source, Specifies A integer value.  
	//		nYSrc---Y Source, Specifies A integer value.  
	//		colorTransparent---colorTransparent, Specifies A 32-bit COLORREF value used as a color value.  
	//		nWidthDest---Width Dest, Specifies A integer value.  
	//		nHeightDest---Height Dest, Specifies A integer value.
	void TransparentBlt(HDC hdcDest, int nXDest, int nYDest, int nWidth, 
								int nHeight, CDC* pDcSrc, int nXSrc, int nYSrc,
								COLORREF crTransparent,int nWidthDest = -1, int nHeightDest = -1);
public:

	// Init button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoInit(CFOPToolBar * pBar,const UINT * pData);

	// Can drag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Drag, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL CanDrag() const { return TRUE; }

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper & data object (Value).
	virtual void MethodTemp14(CDC& dc, CFOPBtnDrawHelper& data);

	// Draw separator
	
	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).
	virtual BOOL MethodTemp13(CDC& dc);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL MethodTemp12(CPoint point);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void MethodTemp11(CPoint point);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp10();

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual UINT MethodTemp9(CPoint point);

	// On hide.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Hide, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnHide() {}

	// On hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO  or NULL if the call failed.
	virtual INT_PTR  OnToolHitTest(CPoint point,TOOLINFO * pTI) const;

	// Send require message button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void  or NULL if the call failed.
	virtual void SendMessageToButton(UINT nCode, void * pData);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp15();

	// Send notify message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Notify Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		code---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lParam---lParam, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual LRESULT SendNotifyMsg(UINT code, DWORD wParam = 0, DWORD lParam = 0);
	
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp8(CFOPBtnDrawHelper& data, BOOL bForce, int& x, int& y, int& nWidth,
		int& nHeight, int nImgWidth = - 1);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp7(int xImg , int yImg , int nImgWidth , int nImgHeight,
		CFOPBtnDrawHelper& data , int xDest , int yDest);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp6(CFOPBtnDrawHelper& data, int x, int y, int nWidth, int nHeight, COLORREF crBack);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp5(CFOPBtnDrawHelper& data, int x, int y, int nWidth, int nHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp4(CFOPBtnDrawHelper& data, int x, int y, int nWidth, int nHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp3(CFOPBtnDrawHelper& data, int x, int y, int nWidth, int nHeight);
	
	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void MethodTemp2(CFOPBtnDrawHelper& data);
	
	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	virtual void OnMethodTemp8(CDC &dc, CFOPBtnDrawHelper& data);

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// MethodTemp
	void MethodTemp1(CFOPBtnDrawHelper &data, int x, int y, int nWidth, int nHeight);
	
protected:

	// Parent toolbar.
 
	// Tool Bar, This member maintains a pointer to the object CFOPToolBar.  
	CFOPToolBar * m_pToolBar;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBarComboButtonBase

#define FOP_INIT_COMBO 0x0101
 
//===========================================================================
// Summary:
//     The CFOPToolBarComboButtonBase class derived from CFOPToolBarButton
//      F O P Tool Bar Combo Button Base
//===========================================================================

class FO_EXT_CLASS CFOPToolBarComboButtonBase : public CFOPToolBarButton
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Tool Bar Combo Button Base, Constructs a CFOPToolBarComboButtonBase object.
	//		Returns A  value (Object).
	CFOPToolBarComboButtonBase();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Tool Bar Combo Button Base, Destructor of class CFOPToolBarComboButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPToolBarComboButtonBase(){}

public:
	
	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPToolBarComboButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void SetMode(BOOL bVertical);

	// Set style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Style, Sets a specify value to current class CFOPToolBarComboButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void SetStyle(UINT nStyle);

	// Set position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPToolBarComboButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetPos(int x,int y);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bErase---bErase, Specifies A Boolean value.
	// Invalidate.
	virtual void Invalidate(BOOL bErase = FALSE) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	//Serialize Data
	virtual void	Serialize(CArchive &ar);

	// Save Document
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	// Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	

public:

	// Left button message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Down, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL LButtonDown(UINT nFlags,CPoint point);

	// On left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Up, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL LButtonUp(UINT nFlags,CPoint point);

	// On left button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Double click Clk, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL LButtonDblClk(UINT nFlags,CPoint point);

	// Right button message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Down, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL RButtonDown(UINT nFlags,CPoint point);

	// On right button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Up, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL RButtonUp(UINT nFlags,CPoint point);

	// On right button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Button Double click Clk, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL RButtonDblClk(UINT nFlags,CPoint point);

	// Set cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Hide, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnHide();
	
protected:

	// Send message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Owner Message, .
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	void SendOwnerMessage(UINT nMessage,WPARAM wParam = 0,LPARAM lParam = 0);

	// Send notify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Notify, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SendNotify(UINT nCode);
	
public:

	// Init data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoInit(CFOPToolBar * pToolBar,const UINT * pData);

	// On draw button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper & data object (Value).
	virtual void MethodTemp14(CDC & dc,CFOPBtnDrawHelper & data);

	// On hit test tool
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO  or NULL if the call failed.
	virtual INT_PTR  OnToolHitTest(CPoint point,TOOLINFO * pTI) const;

	// Send require message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void  or NULL if the call failed.
	virtual void SendMessageToButton(UINT nCode,void * pData);

	// Adjust size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp15();
	
protected:

	// Get wnd pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd ,or NULL if the call failed  
	// Parameters:
	//		)---Specifies a ) = 0 object(Value).
	virtual CWnd * GetWnd() = 0;

	// Create wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CFOPToolBarComboButtonBase object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies A CRect type value.  
	//		nID)---I D), Specifies A integer value.
	virtual BOOL CreateWnd(CWnd * pParentWnd,DWORD dwStyle,CRect& rc,int nID) = 0;

protected:

	// Is wnd visible.
 
	// Visible W, This member sets TRUE if it is right.  
	BOOL		m_bVisibleW;

	// Size.
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSize;

	// Min size.
 
	// Minimize Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nMinSize;

	// Height.
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nHeight;

	// Real height.
 
	// Real Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRealHeight;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPComboEdit

 
//===========================================================================
// Summary:
//     The CFOPComboEdit class derived from CEdit
//      F O P Combo Edit
//===========================================================================

class FO_EXT_CLASS CFOPComboEdit : public CEdit
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Combo Edit, Constructs a CFOPComboEdit object.
	//		Returns A  value (Object).
	CFOPComboEdit();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Combo Edit, Destructor of class CFOPComboEdit
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPComboEdit() {}
	
public:

	// Wnd handle.
 
	// Combo, This member maintains a pointer to the object CFOPToolBarComboButtonBase.  
	CFOPToolBarComboButtonBase * m_pCombo;

	// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPComboEdit)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOPComboEdit)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd * pWnd,UINT nHitTest,UINT message);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPComboToolBarButton

#define FOP_ENTER_ON_COMBO 0x0201
 
//===========================================================================
// Summary:
//     The CFOPComboToolBarButton class derived from CFOPFlatComboBox
//      F O P Combo Tool Bar Button
//===========================================================================

class FO_EXT_CLASS CFOPComboToolBarButton : public CFOPFlatComboBox,public CFOPToolBarComboButtonBase
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Combo Tool Bar Button, Constructs a CFOPComboToolBarButton object.
	//		Returns A  value (Object).
	CFOPComboToolBarButton() { m_nType = FOP_COMBOBUTTON; }

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Combo Tool Bar Button, Destructor of class CFOPComboToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPComboToolBarButton() {}

public:
	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPComboToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void	SetMode(BOOL bVertical);
	
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize Data
	virtual void	Serialize(CArchive &ar);

	// Save Document
	// lpszPathName -- file name with full path
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	// lpszPathName -- file name with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	

protected:

	// Get handle of wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	virtual CWnd * GetWnd();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPComboToolBarButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CFOPComboToolBarButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies A CRect type value.  
	//		nID---I D, Specifies A integer value.
	virtual BOOL CreateWnd(CWnd * pParentWnd,DWORD dwStyle,CRect& rc,int nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Font Create And Set, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFontCreateAndSet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp15();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPComboToolBarButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags,CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd * pWnd,UINT nHitTest,UINT message);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Edit combobox.
 
	// This member specify E-XD++ CFOPComboEdit object.  
	CFOPComboEdit	m_edit;

	// Font.
 
	// The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			m_font;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPFontFaceComboBox

 
//===========================================================================
// Summary:
//     The CFOPFontFaceComboBox class derived from CFOPFlatComboBox
//      F O P Font Face Combo Box
//===========================================================================

class FO_EXT_CLASS CFOPFontFaceComboBox : public CFOPFlatComboBox, public CFOPToolBarComboButtonBase
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Font Face Combo Box, Constructs a CFOPFontFaceComboBox object.
	//		Returns A  value (Object).
	CFOPFontFaceComboBox();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Font Face Combo Box, Destructor of class CFOPFontFaceComboBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPFontFaceComboBox();
	
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	//Serialize Data
	virtual void	Serialize(CArchive &ar);

	//Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	//Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	

	// Operations
public:
	
	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPFontFaceComboBox
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void SetMode(BOOL bVertical);

	// Get pointer of wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWnd();
	
public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPComboToolBarButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CFOPFontFaceComboBox object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies A CRect type value.  
	//		nID---I D, Specifies A integer value.
	virtual BOOL CreateWnd(CWnd * pParentWnd,DWORD dwStyle,CRect& rc,int nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Font Create And Set, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFontCreateAndSet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp15();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDELETEITEMSTRUCT lpDIS object(Value).
	virtual void DeleteItem(LPDELETEITEMSTRUCT lpDIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		lpCompareItemStruct---Compare Item Struct, Specifies a LPCOMPAREITEMSTRUCT lpCompareItemStruct object(Value).
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
	//}}AFX_VIRTUAL
	
protected:
	//{{AFX_MSG(CFOPFontFaceComboBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Dropdown, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnDropdown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

public:
	// Gen fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Fonts, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFontType---Font Type, Specifies A integer value.  
	//		nCharSet---Char Set, Specifies An 8-bit BYTE integer that is not signed.  
	//		nPitchAndFamily---Pitch And Family, Specifies An 8-bit BYTE integer that is not signed.
	BOOL GenFonts(int nFontType = DEVICE_FONTTYPE | RASTER_FONTTYPE | TRUETYPE_FONTTYPE,
		BYTE nCharSet = DEFAULT_CHARSET,
		BYTE nPitchAndFamily = DEFAULT_PITCH);

	// Set current font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Select, Sets a specify value to current class CFOPFontFaceComboBox
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pData---pData, A pointer to the CFOPFontData or NULL if the call failed.
	BOOL SetCurFontSel(CFOPFontData* pData);

	// Set current font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Font Select, Sets a specify value to current class CFOPFontFaceComboBox
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszName---lpszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nCharSet---Char Set, Specifies An 8-bit BYTE integer that is not signed.
	BOOL SetCurFontSel(LPCTSTR lpszName, BYTE nCharSet = DEFAULT_CHARSET);

	// Get cur font sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Font Select, Returns the specified value.
	//		Returns a pointer to the object CFOPFontData,or NULL if the call failed
	CFOPFontData* GetCurFontSel() const;

	// Enum fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enum Fam Basic Call Back Ex, .
	// This member function is a static function.
	//		Returns BOOL CALLBACK AFX_EXPORTvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONTEX or NULL if the call failed.  
	//		NEWTEXTMETRICEX*---E W T E X T M E T R I C E X*, A pointer to the NEWTEXTMETRICEX or NULL if the call failed.  
	//		FontType---Font Type, Specifies A integer value.  
	//		pThis---pThis, Specifies a LPVOID pThis object(Value).
	static BOOL CALLBACK AFX_EXPORT EnumFamBasicCallBackEx(ENUMLOGFONTEX* pelf, NEWTEXTMETRICEX* /*lpntm*/, 
		int FontType,
		LPVOID pThis);

	// Enum fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enum Fam Extend Call Back Ex, .
	// This member function is a static function.
	//		Returns BOOL CALLBACK AFX_EXPORTvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONTEX or NULL if the call failed.  
	//		NEWTEXTMETRICEX*---E W T E X T M E T R I C E X*, A pointer to the NEWTEXTMETRICEX or NULL if the call failed.  
	//		FontType---Font Type, Specifies A integer value.  
	//		pThis---pThis, Specifies a LPVOID pThis object(Value).
	static BOOL CALLBACK AFX_EXPORT EnumFamExtendCallBackEx(ENUMLOGFONTEX* pelf, NEWTEXTMETRICEX* /*lpntm*/, 
		int FontType, 
		LPVOID pThis);

	// Add font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Font, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pelf---A pointer to the ENUMLOGFONT or NULL if the call failed.  
	//		nType---nType, Specifies A integer value.  
	//		lpszScript---lpszScript, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL AddFont(ENUMLOGFONT* pelf, int nType, LPCTSTR lpszScript);

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Drop Width, .

	void RecalcDropWidth();

protected:

	// Init font data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Font Data, Call InitFontData after creating a new object.

	void InitFontData();

	// Clear all font cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache, Remove the specify data from the list.

	void ClearCache();

	// Build fonts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Fonts, .

	void BuildFonts();


protected:

	// Current font height.
 
	// Font Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nFontHeight;

	// Crrent font image list.
 
	// Font Name, This member is a collection of same-sized images.  
	CImageList		m_imgFontName;	

	// Pitch
 
	// Pitch, This member sets An 8-bit integer that is not signed.  
	BYTE			m_nPitch;

	// Edit combobox.
 
	// This member specify E-XD++ CFOPComboEdit object.  
	CFOPComboEdit	m_edit;

	// Font.
 
	// The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			m_font;

	// List for font data.
 
	// Font Data, This member specify CObList object.  
	CObList			m_listFontData;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropArrowToolBarButton

 
//===========================================================================
// Summary:
//     The CFOPDropArrowToolBarButton class derived from CFOPToolBarButton
//      F O P Drop Arrow Tool Bar Button
//===========================================================================

class FO_EXT_CLASS CFOPDropArrowToolBarButton : public CFOPToolBarButton
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Arrow Tool Bar Button, Constructs a CFOPDropArrowToolBarButton object.
	//		Returns A  value (Object).
	CFOPDropArrowToolBarButton();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Arrow Tool Bar Button, Destructor of class CFOPDropArrowToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropArrowToolBarButton() {}

public:

	// Drop arrow mode.
 
	// Drop Arrow, This member sets TRUE if it is right.  
	BOOL		m_bDropArrow;

	// Other id.
 
	// Other I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nOtherID;

	// Dis ID.
 
	// Distance I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nDisID;

	// Image index.
 
	// Image Index, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nImageIndex;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	//Serialize Data
	virtual void	Serialize(CArchive &ar);

	//Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	//Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	
	
public:

	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPDropArrowToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void SetMode(BOOL bVertical);
	
	// Adjust sizement.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp15();

	// Init control data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoInit(CFOPToolBar * pToolBar,const UINT * pData);

protected:

	// Draw button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper & data object (Value).
	virtual void MethodTemp14(CDC & dc,CFOPBtnDrawHelper & data);

	// Draw button face method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper & data object (Value).  
	//		bForce---bForce, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		nImgWidth---Img Width, Specifies A integer value.
	virtual void MethodTemp8(CFOPBtnDrawHelper & data,BOOL bForce,int & x,int & y,int & nWidth,
		int & nHeight,int nImgWidth = - 1);

	// On mouse message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL MethodTemp12(CPoint point);

	// Do mouse move action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void MethodTemp11(CPoint point);

	// Do cancel click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp10();

	// Do click up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual UINT MethodTemp9(CPoint point);
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropMenuToolBarButton

 
//===========================================================================
// Summary:
//     The CFOPDropMenuToolBarButton class derived from CFOPToolBarButton
//      F O P Drop Menu Tool Bar Button
//===========================================================================

class FO_EXT_CLASS CFOPDropMenuToolBarButton : public CFOPToolBarButton
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Menu Tool Bar Button, Constructs a CFOPDropMenuToolBarButton object.
	//		Returns A  value (Object).
	CFOPDropMenuToolBarButton();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Menu Tool Bar Button, Destructor of class CFOPDropMenuToolBarButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropMenuToolBarButton() {}

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	//Serialize Data
	virtual void	Serialize(CArchive &ar);

	//Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	//Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	
	
public:

	// Init control data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoInit(CFOPToolBar * pToolBar,const UINT * pData);

	// On mouse message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL MethodTemp12(CPoint point);

	// Do click up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual UINT MethodTemp9(CPoint point);

protected:

	// Sub menu item.
 
	// Child Menu, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nSubMenu;

	// Align placement.
 
	// Menu Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nMenuAlign;

	// Menu handle.
 
	// Show Menu, This member specify CMenu object.  
	CMenu		m_ShowMenu;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropPickerToolButtonBase

 
//===========================================================================
// Summary:
//     The CFOPDropPickerToolButtonBase class derived from CFOPDropArrowToolBarButton
//      F O P Drop Picker Tool Button Base
//===========================================================================

class FO_EXT_CLASS CFOPDropPickerToolButtonBase : public CFOPDropArrowToolBarButton
{									
public:
	// Do click down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Down, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	BOOL			MethodTemp12(CPoint point);

	// Do click up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Up, Do a event. 
	//		Returns a UINT type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	UINT			MethodTemp9(CPoint point);

	// Do draw button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		dc---Specifies a CDC & dc object(Value).  
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper & data object (Value).
	void			MethodTemp14(CDC & dc,CFOPBtnDrawHelper & data);

	// Do mouse move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// Parameters:
	//		point---Specifies A CPoint type value.
	void			MethodTemp11(CPoint point);

	// Send command
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Command, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	SendCommand();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify, .
	// Parameters:
	//		code---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Notify
	void			Notify(UINT  code);

	// Buttons
	
	//-----------------------------------------------------------------------
	// Summary:
	// Inform Identical Btns, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void			InformIdenticalBtns(UINT nCode, void* pData);

	// Get state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Arrow State, Returns the specified value.
	//		Returns A fopDropArrow value (Object).
	fopDropArrow	GetDropArrowState() const		{	return(m_nDropArrowState);	}

	// Set state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drop Arrow State, Sets a specify value to current class CFOPDropPickerToolButtonBase
	// Parameters:
	//		nState---nState, Specifies a fopDropArrow nState object(Value).
	void			SetDropArrowState(fopDropArrow nState);
	
	// Set mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPDropPickerToolButtonBase
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	void			SetMode(BOOL bVertical);

	// Remove
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Pressed State, Call this function to remove a specify value from the specify object.

	void			RemovePressedState();

protected:
	
	// Drop arrow state.
 
	// Drop Arrow State, This member specify fopDropArrow object.  
	fopDropArrow		m_nDropArrowState;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropPickerWellButton

 
//===========================================================================
// Summary:
//     The CFOPDropPickerWellButton class derived from CFOPDropPickerToolButtonBase
//      F O P Drop Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropPickerWellButton : public CFOPDropPickerToolButtonBase
{

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Picker Well Button, Constructs a CFOPDropPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropPickerWellButton();

	// Send command
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Command, .

	void					SendCommand();

	// Get well wnd pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Well, Returns the specified value.
	//		Returns a pointer to the object FOPDrawControlPanel,or NULL if the call failed
	FOPDrawControlPanel* 	GetWell()	{	return m_pWellControl;}

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void					SendMessageToButton(UINT nCode, void* pData);

	// Codes informing us to take some kind of action
	enum InformCode
	{
		IBase   = 0x1000,
		IGetHeaderBarState,
		ISetHeaderBarState,
		IGetButtonState,
		ISetButtonState,
		ISetHeaderBarOneStr,
		ISetHeaderBarTwoStr,
		ISetButtonOneStr,
		ISetButtonTwoStr,
		ISetColumns,
		IGetDrawImpl,
		IGetDrawSunkenMode,
		ISetDrawSunkenMode,
		IDump,
		IFirst  = IGetHeaderBarState,
		ILast	= IDump
	};

protected:

	// Drop wnd handle.
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd		m_DropWnd;

	// Contorl panel
 
	// Well , This member maintains a pointer to the object FOPDrawControlPanel.  
	FOPDrawControlPanel*	m_pWellControl;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		)---Specifies a )=0 object(Value).
	virtual		void		SyncWell()=0;

	// Drop down toolbar mode
 
	// Drop Mode, This member sets TRUE if it is right.  
	BOOL					m_bDropMode;

	// Match draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Match Draw Impl, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		l---Specifies A 32-bit long signed integer.
	BOOL					MatchDrawImpl(unsigned long& l);
	
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropColorPickerWellButton

 
//===========================================================================
// Summary:
//     The CFOPDropColorPickerWellButton class derived from CFOPDropPickerWellButton
//      F O P Drop Color Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropColorPickerWellButton : public CFOPDropPickerWellButton, public FOPDropColorPickerCallback
{
public:
	
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Color Picker Well Button, Constructs a CFOPDropColorPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropColorPickerWellButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Color Picker Well Button, Destructor of class CFOPDropColorPickerWellButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropColorPickerWellButton();

	// Do init data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// function to draw button with any pixels matching ReplacedColor drawn as m_crReplaceColor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Replaced Color, Sets a specify value to current class CFOPDropColorPickerWellButton
	// Parameters:
	//		c---Specifies A 32-bit COLORREF value used as a color value.
	void 						SetReplacedColor(const COLORREF& c) {	m_crReplacedColor= c;		}

	// Set new color value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOPDropColorPickerWellButton
	// Parameters:
	//		c---Specifies A 32-bit COLORREF value used as a color value.
	void			 			SetColor(const COLORREF& c) 		{	m_crReplaceColor = c; BuildTipsText(); Invalidate();			}

	// Set initial color value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Color, Sets a specify value to current class CFOPDropColorPickerWellButton
	// Parameters:
	//		c---Specifies A 32-bit COLORREF value used as a color value.
	void 						SetInitialColor(const COLORREF& c)	{	m_crReplacedColor= c;		}

	// Get color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	const COLORREF&				GetColor() const					{	return m_crReplaceColor;	}

	// Draw face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		bF---bF, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		W---W, Specifies A integer value.  
	//		H---H, Specifies A integer value.  
	//		ImgW---Img W, Specifies A integer value.
	void 						MethodTemp8(CFOPBtnDrawHelper& data, BOOL bF, int& x, int& y, 
		int& W, int& H, int ImgW = -1);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void 						SendMessageToButton(UINT nCode, void* pData);

	// On tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR					OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Recache tooltip text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Tips Text, .

	void						BuildTipsText();
	
	// Do when value change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	virtual void				OnWellColorChange(const COLORREF& color);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom color button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Color, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomColor();

	// Do when choose color none button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellColorNone();

	// Do when choose color automatic button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color Automatic, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellColorAuto();

	// Do when choose button two.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Button Two, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellButtonTwo();

	// Codes informing us to take some kind of action
	enum InformCode			
	{
		IBase				= ILast,
		ISetReplacedColor   = IBase + 1,
		ISetColor,
		ISetWellColor,
		IGetColor,
		ISetTooltipBaseStr
	};
	
protected:

	// Tooltip text.
 
	// Tooltip Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strTooltipText;

	// Tooltip base text
 
	// Base Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strBaseText;

	// Replace color
 
	// Replace Color, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crReplaceColor;

	// Replaced color
 
	// Replaced Color, This member sets A 32-bit value used as a color value.  
	static COLORREF 			m_crReplacedColor;
	
	// Initial color
 
	// Initial Color, This member sets A 32-bit value used as a color value.  
	static COLORREF 			m_crInitialColor;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void						SyncWell();
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropLineWidthPickerWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPDropLineWidthPickerWellButton class derived from CFOPDropPickerWellButton
//      F O P Drop Line Width Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropLineWidthPickerWellButton : public CFOPDropPickerWellButton, public FOPDropLineWidthCallback
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Line Width Picker Well Button, Constructs a CFOPDropLineWidthPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropLineWidthPickerWellButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Line Width Picker Well Button, Destructor of class CFOPDropLineWidthPickerWellButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropLineWidthPickerWellButton();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// function to draw button with any pixels matching replace line width drawn as m_crReplaceColor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Replaced Line Width, Sets a specify value to current class CFOPDropLineWidthPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetReplacedLineWidth(const int& nWidth) {	m_nReplacedLineWidth= nWidth;		}

	// Set line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class CFOPDropLineWidthPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			 			SetLineWidth(const int& nWidth) 		{	m_nReplaceLineWidth = nWidth;BuildTipsText(); Invalidate();	}

	// Set initial line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Line Width, Sets a specify value to current class CFOPDropLineWidthPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetInitialLineWidth(const int& nWidth)	{	m_nReplacedLineWidth= nWidth;		}

	// Get line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	const int&					GetLineWidth() const					{	return m_nReplaceLineWidth;	}

	// Draw face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		bF---bF, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		W---W, Specifies A integer value.  
	//		H---H, Specifies A integer value.  
	//		ImgW---Img W, Specifies A integer value.
	void 						MethodTemp8(CFOPBtnDrawHelper& data, BOOL bF, int& x, int& y, 
								int& W, int& H, int ImgW = -1);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void 						SendMessageToButton(UINT nCode, void* pData);

	// On tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR					OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Recache tooltip text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Tips Text, .

	void						BuildTipsText();
	
	// callbacks
	// Do when line width change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Width Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellLineWidthChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom line width button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Line Width, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomLineWidth();

	// Do when choose none line width action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Width None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellLineWidthNone();

	// Codes informing us to take some kind of action
	enum InformCode			
	{
		IBase					= ILast,
		ISetReplacedLineWidth	= IBase + 1,
		ISetLineWidth,
		ISetWellLineWidth,
		IGetLineWidth,
		ISetTooltipBaseStr
	};

protected:
	// Tooltip text
 
	// Tooltip Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strTooltipText;

	// Tooltip base text
 
	// Base Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strBaseText;

	// Replace line width
 
	// Replace Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nReplaceLineWidth;

	// Replaced line width
 
	// Replaced Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nReplacedLineWidth;

	// Initial line width
 
	// Initial Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nInitialLineWidth;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void						SyncWell();
};

/////////////////////////////////////////////////////////////////////////////
// CFOPComplexWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPComplexWellButton class derived from CFOPDropPickerWellButton
//      F O P Complex Well Button
//===========================================================================

class FO_EXT_CLASS CFOPComplexWellButton : public CFOPDropPickerWellButton, public FOPComplexPickerCallback
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Complex Well Button, Constructs a CFOPComplexWellButton object.
	//		Returns A  value (Object).
	CFOPComplexWellButton();
	
	// function to draw button with bitmap
	// Set index value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFOPComplexWellButton
	// Parameters:
	//		i---Specifies A integer value.
	void 			SetIndex(int i) 	 { m_nIndex = i; Invalidate();		}

	// Get index value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns a int type value.
	int				GetIndex() const	 { return m_nIndex;				}

	// Set owner draw mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Owner Drawn, Sets a specify value to current class CFOPComplexWellButton
	// Parameters:
	//		b---Specifies A Boolean value.
	void			SetOwnerDrawn(BOOL b){ m_bOwnerDrawn = b;		}

	// Get owner draw mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Owner Drawn, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetOwnerDrawn() const{ return m_bOwnerDrawn;		}

	// Draw face blt
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Face Bitblt, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		xD---xD, Specifies A integer value.  
	//		yD---yD, Specifies A integer value.
	void			MethodTemp7(int x, int y, int w, int h, CFOPBtnDrawHelper& data, int xD,int yD);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void			SendMessageToButton(UINT nCode, void* pData);

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void			DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// call backs
	// Do when index change action
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Index Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		i---Specifies A integer value.
	virtual void	OnWellIndexChange(int i);

	// Do cancel action
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	OnWellCancel();
	
	// NOTA NOTA BENE: if you change these codes, update CFOPComplexWellButton::Inform
	enum InformCode
	{
		IBase	   = ILast,
		ISetIndex  = IBase + 1,
		ISetWellIndex,
		IGetIndex,
		IGetCount,
		ISetTransparentDraw,
		ISetOwnerDrawn,
		IGetOwnerDrawn,
	};

protected:

	// Owner draw button
 
	// Owner Drawn, This member sets TRUE if it is right.  
	BOOL			m_bOwnerDrawn;

	// Index
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nIndex;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void			SyncWell();

	// Create draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Draw Impl, You construct a CFOPComplexWellButton object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object FOPComplexPickerDrawBase,or NULL if the call failed  
	// Parameters:
	//		pData)---pData), Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual FOPComplexPickerDrawBase* CreateDrawImpl(const UINT* pData) = 0;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropBitmapPickerWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPDropBitmapPickerWellButton class derived from CFOPComplexWellButton
//      F O P Drop Bitmap Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropBitmapPickerWellButton : public CFOPComplexWellButton
{
protected:
	// Create draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Draw Impl, You construct a CFOPDropBitmapPickerWellButton object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object FOPComplexPickerDrawBase,or NULL if the call failed  
	// Parameters:
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	FOPComplexPickerDrawBase* CreateDrawImpl(const UINT* pData);

public:
	// Tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR		OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Adjust size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .

	void			MethodTemp15();
};


/////////////////////////////////////////////////////////////////////////////
// CFOPDropLineTypePickerWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPDropLineTypePickerWellButton class derived from CFOPDropPickerWellButton
//      F O P Drop Line Type Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropLineTypePickerWellButton : public CFOPDropPickerWellButton, public FOPDropLineTypeCallback
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Line Type Picker Well Button, Constructs a CFOPDropLineTypePickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropLineTypePickerWellButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Line Type Picker Well Button, Destructor of class CFOPDropLineTypePickerWellButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropLineTypePickerWellButton();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// function to draw button with any pixels matching replace line width drawn as m_crReplaceColor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Replaced Line Type, Sets a specify value to current class CFOPDropLineTypePickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetReplacedLineType(const int& nWidth) {	m_nReplacedLineType= nWidth;		}

	// Set Line Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Type, Sets a specify value to current class CFOPDropLineTypePickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			 			SetLineType(const int& nWidth) 		{	m_nReplaceLineType = nWidth;BuildTipsText(); Invalidate();	}

	// Set initial Line Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Line Type, Sets a specify value to current class CFOPDropLineTypePickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetInitialLineType(const int& nWidth)	{	m_nReplacedLineType= nWidth;		}

	// Get Line Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Type, Returns the specified value.
	//		Returns a int type value.
	const int&					GetLineType() const					{	return m_nReplaceLineType;	}

	// Draw face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		bF---bF, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		W---W, Specifies A integer value.  
	//		H---H, Specifies A integer value.  
	//		ImgW---Img W, Specifies A integer value.
	void 						MethodTemp8(CFOPBtnDrawHelper& data, BOOL bF, int& x, int& y, 
								int& W, int& H, int ImgW = -1);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void 						SendMessageToButton(UINT nCode, void* pData);

	// On tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR					OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Recache tooltip text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Tips Text, .

	void						BuildTipsText();
	
	// callbacks
	// Do when Line Type change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Type Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellLineTypeChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom Line Type button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Line Type, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomLineType();

	// Do when choose none Line Type action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Line Type None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellLineTypeNone();

	// Codes informing us to take some kind of action
	enum InformCode			
	{
		IBase					= ILast,
		ISetReplacedLineType	= IBase + 1,
		ISetLineType,
		ISetWellLineType,
		IGetLineType,
		ISetTooltipBaseStr
	};

protected:
	// Tooltip text
 
	// Tooltip Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strTooltipText;

	// Tooltip base text
 
	// Base Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strBaseText;

	// Replace Line Type
 
	// Replace Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nReplaceLineType;

	// Replaced Line Type
 
	// Replaced Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nReplacedLineType;

	// Initial Line Type
 
	// Initial Line Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nInitialLineType;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void						SyncWell();
};


/////////////////////////////////////////////////////////////////////////////
// CFOPDropArrowPickerWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPDropArrowPickerWellButton class derived from CFOPDropPickerWellButton
//      F O P Drop Arrow Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropArrowPickerWellButton : public CFOPDropPickerWellButton, public FOPDropArrowCallback
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Arrow Picker Well Button, Constructs a CFOPDropArrowPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropArrowPickerWellButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Arrow Picker Well Button, Destructor of class CFOPDropArrowPickerWellButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropArrowPickerWellButton();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// function to draw button with any pixels matching replace arrow drawn as m_crReplaceColor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Replaced Arrow, Sets a specify value to current class CFOPDropArrowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetReplacedArrow(const int& nWidth) {	m_nReplacedArrow= nWidth;		}

	// Set Arrow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow, Sets a specify value to current class CFOPDropArrowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			 			SetArrow(const int& nWidth) 		{	m_nReplaceArrow = nWidth;BuildTipsText(); Invalidate();	}

	// Set initial Arrow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Arrow, Sets a specify value to current class CFOPDropArrowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetInitialArrow(const int& nWidth)	{	m_nReplacedArrow= nWidth;		}

	// Get Arrow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow, Returns the specified value.
	//		Returns a int type value.
	const int&					GetArrow() const					{	return m_nReplaceArrow;	}

	// Draw face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		bF---bF, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		W---W, Specifies A integer value.  
	//		H---H, Specifies A integer value.  
	//		ImgW---Img W, Specifies A integer value.
	void 						MethodTemp8(CFOPBtnDrawHelper& data, BOOL bF, int& x, int& y, 
								int& W, int& H, int ImgW = -1);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void 						SendMessageToButton(UINT nCode, void* pData);

	// On tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR					OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Recache tooltip text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Tips Text, .

	void						BuildTipsText();
	
	// callbacks
	// Do when Arrow change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Arrow Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellArrowChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom Arrow button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Arrow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomArrow();

	// Do when choose none Arrow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Arrow None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellArrowNone();

	// Codes informing us to take some kind of action
	enum InformCode			
	{
		IBase					= ILast,
		ISetReplacedArrow		= IBase + 1,
		ISetArrow,
		ISetWellArrow,
		IGetArrow,
		ISetTooltipBaseStr
	};

protected:
	// Tooltip text
 
	// Tooltip Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strTooltipText;

	// Tooltip base text
 
	// Base Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strBaseText;

	// Replace Arrow
 
	// Replace Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nReplaceArrow;

	// Replaced Arrow
 
	// Replaced Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nReplacedArrow;

	// Initial Arrow
 
	// Initial Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nInitialArrow;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void						SyncWell();
};


/////////////////////////////////////////////////////////////////////////////
// CFOPDropShadowPickerWellButton frame

 
//===========================================================================
// Summary:
//     The CFOPDropShadowPickerWellButton class derived from CFOPDropPickerWellButton
//      F O P Drop Shadow Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropShadowPickerWellButton : public CFOPDropPickerWellButton, public FOPDropShadowPickerCallback
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Shadow Picker Well Button, Constructs a CFOPDropShadowPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropShadowPickerWellButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Drop Shadow Picker Well Button, Destructor of class CFOPDropShadowPickerWellButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDropShadowPickerWellButton();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
	// function to draw button with any pixels matching replace shadow drawn as m_crReplaceColor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Replaced Shadow Picker, Sets a specify value to current class CFOPDropShadowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetReplacedShadowPicker(const int& nWidth) {	m_nReplacedShadowPicker= nWidth;		}

	// Set Shadow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shadow Picker, Sets a specify value to current class CFOPDropShadowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void			 			SetShadowPicker(const int& nWidth) 		{	m_nReplaceShadowPicker = nWidth;BuildTipsText(); Invalidate();	}

	// Set initial Shadow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Initial Shadow Picker, Sets a specify value to current class CFOPDropShadowPickerWellButton
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void 						SetInitialShadowPicker(const int& nWidth)	{	m_nReplacedShadowPicker= nWidth;		}

	// Get Shadow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shadow Picker, Returns the specified value.
	//		Returns a int type value.
	const int&					GetShadowPicker() const					{	return m_nReplaceShadowPicker;	}

	// Draw face
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Face, Draws current object to the specify device.
	// Parameters:
	//		data---Specifies a E-XD++ CFOPBtnDrawHelper& data object (Value).  
	//		bF---bF, Specifies A Boolean value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		W---W, Specifies A integer value.  
	//		H---H, Specifies A integer value.  
	//		ImgW---Img W, Specifies A integer value.
	void 						MethodTemp8(CFOPBtnDrawHelper& data, BOOL bF, int& x, int& y, 
								int& W, int& H, int ImgW = -1);

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void 						SendMessageToButton(UINT nCode, void* pData);

	// On tool hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR					OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

	// Recache tooltip text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Tips Text, .

	void						BuildTipsText();
	
	// callbacks
	// Do when Shadow change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Shadow Picker Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void				OnWellShadowPickerChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom Shadow button action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Shadow Picker, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomShadowPicker();

	// Do when choose none Shadow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Shadow Picker None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellShadowPickerNone();

	// Codes informing us to take some kind of action
	enum InformCode			
	{
		IBase						= ILast,
		ISetReplacedShadowPicker	= IBase + 1,
		ISetShadowPicker,
		ISetWellShadowPicker,
		IGetShadowPicker,
		ISetTooltipBaseStr
	};

protected:
	// Tooltip text
 
	// Tooltip Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strTooltipText;

	// Tooltip base text
 
	// Base Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString						m_strBaseText;

	// Replace Shadow
 
	// Replace Shadow Picker, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nReplaceShadowPicker;

	// Replaced Shadow
 
	// Replaced Shadow Picker, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nReplacedShadowPicker;

	// Initial Shadow
 
	// Initial Shadow Picker, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int		 			m_nInitialShadowPicker;

	// Sync well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sync Well, .

	void						SyncWell();
};


/////////////////////////////////////////////////////////////////////////////
// CFOPDropUndoListPickerWellButton

 
//===========================================================================
// Summary:
//     The CFOPDropUndoListPickerWellButton class derived from CFOPDropPickerToolButtonBase
//      F O P Drop Undo List Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropUndoListPickerWellButton : public CFOPDropPickerToolButtonBase, public FOPDropUndoRedoPickerCallback
{

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Undo List Picker Well Button, Constructs a CFOPDropUndoListPickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropUndoListPickerWellButton();

	// Send command
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Command, .

	void				SendCommand();

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void				SendMessageToButton(UINT nCode, void* pData);

	// Change redo mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Undo Mode, Sets a specify value to current class CFOPDropUndoListPickerWellButton
	// Parameters:
	//		&bMode---&bMode, Specifies A Boolean value.
	void SetUndoMode(const BOOL &bMode) { m_bUndoMode = bMode; }

	// Set drop undo list strings.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Undo Strings, Sets a specify value to current class CFOPDropUndoListPickerWellButton
	// Parameters:
	//		*pArray---*pArray, Specifies A CString type value.
	void SetUndoStrings(CStringArray *pArray) { m_pUndoStrings = pArray; }

	// Finish picker method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Picker, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		OnFinishPicker();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void						DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
protected:

	// Drop wnd handle
 
	// Drop Undo Window, This member specify E-XD++ CFOUndoRedoWnd object.  
	CFOUndoRedoWnd		m_DropUndoWnd;

	// Drop down toolbar mode.
 
	// Drop Mode, This member sets TRUE if it is right.  
	BOOL				m_bDropMode;

	// If being TRUE,it is undo mode else redo mode.
 
	// Undo Mode, This member sets TRUE if it is right.  
	BOOL				m_bUndoMode;

	// Undo drop string list.
 
	// Undo Strings, The member supports arrays of CString objects.  
	CStringArray*		m_pUndoStrings;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPDropTablePickerWellButton

 
//===========================================================================
// Summary:
//     The CFOPDropTablePickerWellButton class derived from CFOPDropPickerToolButtonBase
//      F O P Drop Table Picker Well Button
//===========================================================================

class FO_EXT_CLASS CFOPDropTablePickerWellButton : public CFOPDropPickerToolButtonBase,
 public FOPDropTablePickerCallback
{

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Table Picker Well Button, Constructs a CFOPDropTablePickerWellButton object.
	//		Returns A  value (Object).
	CFOPDropTablePickerWellButton();

	// Send command
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Command, .

	void				SendCommand();

	// Send message to button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Button, .
	// Parameters:
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void or NULL if the call failed.
	void				SendMessageToButton(UINT nCode, void* pData);

	// Finish picker method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Picker, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		OnFinishPicker();

	// Do init
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.  
	//		pData---pData, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void				DoInit(CFOPToolBar * pToolBar, const UINT* pData);
	
protected:

	// Drop wnd handle
 
	// Drop Undo Window, This member specify E-XD++ CFOPTableWnd object.  
	CFOPTableWnd		m_DropUndoWnd;

	// Drop down toolbar mode.
 
	// Drop Mode, This member sets TRUE if it is right.  
	BOOL				m_bDropMode;

};

_FOLIB_INLINE void CFOPDropPickerToolButtonBase::SetDropArrowState(fopDropArrow e)
{
	ASSERT(e==AlwaysSingle || m_nImageIndex);
	m_nDropArrowState = e;
}

/////////////////////////////////////////////////////////////////////////////
// CFOPLayerComboBox

 
//===========================================================================
// Summary:
//     The CFOPLayerComboBox class derived from CFOPFlatComboBox
//      F O P Layer Combo Box
//===========================================================================

class FO_EXT_CLASS CFOPLayerComboBox : public CFOPFlatComboBox, public CFOPToolBarComboButtonBase
{
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer Combo Box, Constructs a CFOPLayerComboBox object.
	//		Returns A  value (Object).
	CFOPLayerComboBox();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Layer Combo Box, Destructor of class CFOPLayerComboBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLayerComboBox();

	// Init the combobox fonts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Fonts, Call DoOtherMehod after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoOtherMehod();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	//Serialize Data
	virtual void	Serialize(CArchive &ar);

	//Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	SaveDocument(LPCTSTR lpszPathName);

	//Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL	OpenDocument(LPCTSTR lpszPathName);

	//Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*			GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void	ReleaseFile(CFile* pFile, BOOL bAbort);	

	// Add new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Item, Adds an object to the specify list.
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.  
	//		&bVisible---&bVisible, Specifies A Boolean value.
	void AddItem(const CString &strName,const BOOL &bVisible);

	// Operations
public:
	
	// Set mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPLayerComboBox
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void SetMode(BOOL bVertical);

	// Get pointer of wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWnd();
	
public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPComboToolBarButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Window, You construct a CFOPLayerComboBox object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies A CRect type value.  
	//		nID---I D, Specifies A integer value.
	virtual BOOL CreateWnd(CWnd * pParentWnd,DWORD dwStyle,CRect& rc,int nID);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Font Create And Set, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFontCreateAndSet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void MethodTemp15();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Item, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDELETEITEMSTRUCT lpDIS object(Value).
	virtual void DeleteItem(LPDELETEITEMSTRUCT lpDIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMeasureItemStruct---Measure Item Struct, Specifies a LPMEASUREITEMSTRUCT lpMeasureItemStruct object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	//}}AFX_VIRTUAL
	
protected:
	//{{AFX_MSG(CFOPLayerComboBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Crrent font image list.
 
	// Layer Name, This member is a collection of same-sized images.  
	CImageList		m_imgLayerName;

protected:

	// Edit combobox.
 
	// This member specify E-XD++ CFOPComboEdit object.  
	CFOPComboEdit	m_edit;

	// Font.
 
	// The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			m_font;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPTOOLBARBUTTON_H__8A69F251_6AC6_48EE_A463_367B01A206BA__INCLUDED_)
