//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNBUTTONBASE_H__E5B18AEC_CA7F_4C3E_B708_0C7E6404F11D__INCLUDED_)
#define AFX_FOPDROPDOWNBUTTONBASE_H__E5B18AEC_CA7F_4C3E_B708_0C7E6404F11D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownButtonBase.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownButtonBase window

#define WELLN_DROPDOWN WM_APP + 1
#define ON_WELL_DROPDOWN(id, memberFxn) \
	ON_CONTROL(WELLN_DROPDOWN, id, memberFxn)

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownButtonBase window

 
//===========================================================================
// Summary:
//     The FOPDropDownButtonBase class derived from CButton
//      O P Drop Down Button Base
//===========================================================================

class FO_EXT_CLASS FOPDropDownButtonBase : public CButton
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownButtonBase---O P Drop Down Button Base, Specifies a FOPDropDownButtonBase object(Value).
	DECLARE_DYNCREATE(FOPDropDownButtonBase);

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Button Base, Constructs a FOPDropDownButtonBase object.
	//		Returns A  value (Object).
	FOPDropDownButtonBase();
    
// Attributes
public:

	// Text font.
 
	// Text Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont	TextFont;

public:

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int 	GetMinimumHeight() const;

	// Finish drop down picker
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Drop Down, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	FinishDropDown();

	// Do drop down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		r---Specifies A CRect type value.  
	//		bDraw---bDraw, Specifies A Boolean value.
	// Draw state.
	virtual void	Draw(CDC& dc, const CRect& r, BOOL bDraw);

	// Notify system color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify System Color Change, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	NotifySysColorChange();	

	// Set drop horizontal
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drop Horizontal, Sets a specify value to current class FOPDropDownButtonBase
	// Parameters:
	//		dh---Specifies A Boolean value.
	void			SetDropHorizontal(BOOL  dh)	{	m_bDropHorizontal = dh; Invalidate();	}

	// Get drop horizontal
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Horizontal, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDropHorizontal()	const	{	return m_bDropHorizontal;				}

	// whether to display a disabled drop down well
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Drop Disabled, Sets a specify value to current class FOPDropDownButtonBase
	// Parameters:
	//		ds---Specifies A Boolean value.
	void			SetDropDisabled(BOOL  ds = TRUE) { m_bDropDisabled = ds;					}

	// Get drop disabled mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Disabled, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetDropDisabled()			{	return m_bDropDisabled;				}

	// whether well control value automatically mirrors the displayed value 
	//	on the button or has to be set separately
	// Get well auto mirror button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Well Automatic Mirrors Button, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetWellAutoMirrorsButton()	{	return m_bWellAutoMirrorsButton;		}

	// Set well auto mirror button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Well Automatic Mirrors Button, Sets a specify value to current class FOPDropDownButtonBase
	// Parameters:
	//		a---Specifies A Boolean value.
	void			SetWellAutoMirrorsButton(BOOL  a = TRUE) {m_bWellAutoMirrorsButton = a;	}

	// Enable button height automatic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Automatic Height, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void			EnableAutoHeight(const BOOL &bEnable) { m_bAutoHeight = bEnable;	}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownButtonBase)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
 	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnSysColorChange();

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Button Base, Destructor of class FOPDropDownButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownButtonBase();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownButtonBase)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	
	// Edge size.
 
	// Edge, This member sets a CSize value.  
	CSize			m_szEdge;

	// Arrow rectangle
 
	// Arrow Rectangle, This member sets a CRect value.  
	CRect			m_rcArrowRect;

	// Mouse down
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL 			m_bMouseDown;

	// Drop horizontal state.
 
	// Drop Horizontal, This member sets TRUE if it is right.  
	BOOL 			m_bDropHorizontal;

	// Drop disabled state.
 
	// Drop Disabled, This member sets TRUE if it is right.  
	BOOL 			m_bDropDisabled;

	// Button with automatic height.
 
	// Automatic Height, This member sets TRUE if it is right.  
	BOOL			m_bAutoHeight;

	// unset this flag if popup well can be in a different state from button
 
	// Well Automatic Mirrors Button, This member sets TRUE if it is right.  
	BOOL 			m_bWellAutoMirrorsButton;

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constrain Window Size, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ConstrainWindowSize();

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNBUTTONBASE_H__E5B18AEC_CA7F_4C3E_B708_0C7E6404F11D__INCLUDED_)
