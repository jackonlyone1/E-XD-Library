//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOUNDOREDOWND_H__1E577C63_B344_4C0A_A4F3_D52031BE0097__INCLUDED_)
#define AFX_FOUNDOREDOWND_H__1E577C63_B344_4C0A_A4F3_D52031BE0097__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOUndoRedoWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOUndoRedoWnd window

#include "FOUndoRedoListBox.h"

// Drop undo/redo picker call back
struct FOPDropUndoRedoPickerCallback
{
	virtual void	OnFinishPicker() = 0;
};

// Drop table picker call back
struct FOPDropTablePickerCallback
{
	virtual void	OnFinishPicker() = 0;
};

//////////////////////////////////////////////////////////////////////
// Summary: CFOUndoRedoWnd is a CWnd derived class that is used
//          by undo/redo list box to create the drop down undo/redo list

 
//===========================================================================
// Summary:
//     The CFOUndoRedoWnd class derived from CWnd
//      F O Undo Redo Window
//===========================================================================

class FO_EXT_CLASS CFOUndoRedoWnd : public CWnd
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Undo Redo Window, Constructs a CFOUndoRedoWnd object.
	//		Returns A  value (Object).
	CFOUndoRedoWnd();

// Attributes
public:
	
	// Create a new control.
	virtual BOOL Create(
		// Undo mode or Redo Mode.
		BOOL bUndoMode,
		// String list of actions
		CStringArray *pActions,
		// Control style.
		DWORD dwStyle,
		// Rectangle
		CRect &rect,
		// Pointer of parent.
		CWnd *pParent,
		// Popup window size.
		CSize szPopup = CSize(300,200),
		// Pointer of context
		CCreateContext *pContext = NULL);

	// Create a new control with popup mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Popup, You construct a CFOUndoRedoWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pActions---*pActions, Specifies A CString type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL CreatePopup(
		// String list of actions.
		CStringArray *pActions,
		// Control style.
		DWORD dwStyle,
		// Position of control.
		CRect rcPos, 
		// Pointer of parent window.
		CWnd* pParent,
		// Resource ID.
		UINT nID
		);

// Operations
public:
	// Handle cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Cancel, .

	void HandleCancel();

	// Do undo actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Undo, Do a event. 

	void DoUndo();

	// Set the bottom label text.
	// strLabel -- label
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label, Sets a specify value to current class CFOUndoRedoWnd
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	void SetLabel (const CString& strLabel);

	// Notify window handle.
	// pWnd -- notify window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify Window, Sets a specify value to current class CFOUndoRedoWnd
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetNotifyWnd(CWnd *pWnd) { pNotifyWnd = pWnd; }
	
	// Set call back button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class CFOUndoRedoWnd
	// Parameters:
	//		button---A pointer to the FOPDropUndoRedoPickerCallback or NULL if the call failed.
	void SetButton(FOPDropUndoRedoPickerCallback* button)	{	Button = button;	}

protected:

	// Fill background.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Background, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rectClient---&rectClient, Specifies A CRect type value.
	virtual void OnFillBackground (CDC* pDC,const CRect &rectClient);

	// This member function will draw a shadow rect to the device context
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Shadow Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	void				DrawShadowRect(CDC *pDC,const CRect& rect);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOUndoRedoWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Undo Redo Window, Destructor of class CFOUndoRedoWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOUndoRedoWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOUndoRedoWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
#if _MSC_VER > 1200 //MFC 7.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
    afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif //MFC 7.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Initial size of the tip window.
 
	// Window, This member sets a CRect value.  
	CRect			m_rcWindow;

	// Initial size of the tip window shadow.
 
	// Shadow, This member sets a CRect value.  
	CRect			m_rcShadow;

	// Undo list box.
 
	// List, This member specify E-XD++ CFOUndoRedoListBox object.  
	CFOUndoRedoListBox	m_wndList;

	// Label position.
 
	// Label, This member sets a CRect value.  
	CRect			m_rectLabel;

	// Label height.
 
	// Label Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLabelHeight;

	// Label text.
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strLabel;

	// TRUE - is undo mode,FALSE - is redo mode.
 
	// Undo Mode, This member sets TRUE if it is right.  
	BOOL			m_bUndoMode;

	// Call back.
 
	// This member maintains a pointer to the object FOPDropUndoRedoPickerCallback.  
	FOPDropUndoRedoPickerCallback* Button;

	// Notify wnd pointer.
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			pNotifyWnd;

};

/////////////////////////////////////////////////////////////////////////////
// CFOPTableWnd window

#define WM_FO_SETPARAMS		(WM_APP+534)

 
//===========================================================================
// Summary:
//     The CFOPTableWnd class derived from CWnd
//      F O P Table Window
//===========================================================================

class FO_EXT_CLASS CFOPTableWnd : public CWnd
{
// Construction
public:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Window, Constructs a CFOPTableWnd object.
	//		Returns A  value (Object).  
	// Parameters:
	//		maxx---Specifies A integer value.  
	//		maxy---Specifies A integer value.  
	//		nX---nX, Specifies A integer value.  
	//		nY---nY, Specifies A integer value.  
	//		nId---nId, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPTableWnd(int maxx,int maxy,int nX,int nY,UINT nId = WM_FO_SETPARAMS);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	// Create a window
	// pParent -- pointer of the parent window.
	// x -- start x value.
	// y -- start y value
	BOOL Create(CWnd *pParent,int x,int y);

// Attributes
public:

	// Handle cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Cancel, .

	void HandleCancel();

	// Notify window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Notify Window, Sets a specify value to current class CFOPTableWnd
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetNotifyWnd(CWnd *pWnd) { pNotifyWnd = pWnd; }
	
	// Set call back button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class CFOPTableWnd
	// Parameters:
	//		button---A pointer to the FOPDropTablePickerCallback or NULL if the call failed.
	void SetButton(FOPDropTablePickerCallback* button)	{	Button = button;	}

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPTableWnd)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Post Nc Destroy, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Window, Destructor of class CFOPTableWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPTableWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPTableWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
#if _MSC_VER > 1200 //MFC 7.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
    afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif //MFC 7.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

public:

	// Recal size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Size, .
	//		Returns a CSize type value.  
	// Parameters:
	//		nx---Specifies A integer value.  
	//		ny---Specifies A integer value.
	CSize RelayoutSize(int nx,int ny);

	// Draw text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Text, Draws current object to the specify device.
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	void DrawText(int x,int y);

	// Move static
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Tip Window, .

	void MoveTipWindow();

protected:
	// Static window
 
	// Static, This member specify CStatic object.  
	CStatic		m_wndStatic;

	// pointer of the parent window
 
	// Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *		m_pParent;

	// Is inited or not
 
	// Initial Over, This member sets TRUE if it is right.  
	BOOL		m_bInitOver;

	// Font
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		m_Font;

	// Max x and Max y values.
	int m_nMaxX,m_nMaxY;

	// Number x and number y value
	int m_nNumX,m_nNumY;

	// Sel x and y value
	int m_nSelX,m_nSelY;

	// Capture or not
 
	// Captured, This member sets TRUE if it is right.  
	BOOL		m_bCaptured;

	// Rectangle
 
	// Rectangle, This member sets a CRect value.  
	CRect		m_Rect;

	// Message
 
	// Message Id, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		n_nMessageId;

	// Call back.
 
	// This member maintains a pointer to the object FOPDropTablePickerCallback.  
	FOPDropTablePickerCallback* Button;

	// Notify wnd pointer.
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			pNotifyWnd;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOUNDOREDOWND_H__1E577C63_B344_4C0A_A4F3_D52031BE0097__INCLUDED_)
