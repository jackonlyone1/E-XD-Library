//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOCORNERLINKSHAPE_H__19D05237_B3FF_11D6_A633_0050BAE30439__INCLUDED_)
#define AFC_FOCORNERLINKSHAPE_H__19D05237_B3FF_11D6_A633_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOLinkShape.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOCornerLinkShape -- corner link line shape, it's ID is: FO_COMP_CORNERLINK 93
//  

 
//===========================================================================
// Summary:
//     The CFOCornerLinkShape class derived from CFOLinkShape
//      F O Corner Link Shape
//===========================================================================

class FO_EXT_CLASS CFOCornerLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOCornerLinkShape---F O Corner Link Shape, Specifies a E-XD++ CFOCornerLinkShape object (Value).
	DECLARE_SERIAL(CFOCornerLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Corner Link Shape, Constructs a CFOCornerLinkShape object.
	//		Returns A  value (Object).
	CFOCornerLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Corner Link Shape, Constructs a CFOCornerLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOCornerLinkShape& src object(Value).
	CFOCornerLinkShape(const CFOCornerLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Corner Link Shape, Destructor of class CFOCornerLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCornerLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the corner link shape from points.
	// ptArray -- points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the corner link shape from points.
	// pptPoints -- points of shape.
	// nCount -- total points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOCornerLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOCornerLinkShape& src object(Value).
	CFOCornerLinkShape& operator=(const CFOCornerLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Relayout state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Corner Size, Returns the specified value.
	//		Returns a int type value.
	int GetCornerSize() const;

	// Set corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Corner Size, Sets a specify value to current class CFOCornerLinkShape
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void SetCornerSize(const int nSize);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//////////////////////////////////////////////////////////////////////////
// CFOPExtCornerLinkShape -- Extent corner link line shape, it's ID is: FO_COMP_EXT_CORNERLINK 231
//

 
//===========================================================================
// Summary:
//     The CFOPExtCornerLinkShape class derived from CFOLinkShape
//      F O P Extend Corner Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPExtCornerLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPExtCornerLinkShape---F O P Extend Corner Link Shape, Specifies a E-XD++ CFOPExtCornerLinkShape object (Value).
	DECLARE_SERIAL(CFOPExtCornerLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Extend Corner Link Shape, Constructs a CFOPExtCornerLinkShape object.
	//		Returns A  value (Object).
	CFOPExtCornerLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Extend Corner Link Shape, Constructs a CFOPExtCornerLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPExtCornerLinkShape& src object(Value).
	CFOPExtCornerLinkShape(const CFOPExtCornerLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Extend Corner Link Shape, Destructor of class CFOPExtCornerLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPExtCornerLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the corner link shape from points.
	// ptArray -- points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the corner link shape from points.
	// pptPoints -- points of shape.
	// nCount -- total points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPExtCornerLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPExtCornerLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPExtCornerLinkShape& src object(Value).
	CFOPExtCornerLinkShape& operator=(const CFOPExtCornerLinkShape& src);

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Relayout state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Corner Size, Returns the specified value.
	//		Returns a int type value.
	int GetCornerSize() const;
	
	// Set corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Corner Size, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void SetCornerSize(const int nSize);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();


	// Obtain the line info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Information, Returns the specified value.
	//		Returns A FOPLineInfo value (Object).
	FOPLineInfo GetLineInfo() const { return m_aLineInfo; }

	// Change the line info object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Information, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&LineInfo---Line Information, Specifies a const FOPLineInfo &LineInfo object(Value).
	void SetLineInfo(const FOPLineInfo &LineInfo);

	// Return Show Center Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Show Center Line, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetShowCenterLine() const { return m_bShowCenterLine;}

	// Change Show Center Line value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Center Line, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetShowCenterLine( const BOOL &bValue ) {m_bShowCenterLine = bValue; }

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Return Dots value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dots, Returns the specified value.
	//		Returns a int type value.
	int GetDots();
	
	// Change Dots value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dots, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDots( const int &nValue );
	
	// Return DotLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dot Length, Returns the specified value.
	//		Returns a int type value.
	int GetDotLength();
	
	// Change DotLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dot Length, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDotLength( const int &nValue );
	
	// Return Dashes value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dashes, Returns the specified value.
	//		Returns a int type value.
	int GetDashes();
	
	// Change Dashes value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dashes, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashes( const int &nValue );
	
	// Return DashLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Length, Returns the specified value.
	//		Returns a int type value.
	int GetDashLength();
	
	// Change DashLength value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Length, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashLength( const int &nValue );
	
	// Return Distance value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dash Distance, Returns the specified value.
	//		Returns a int type value.
	int GetDashDistance();
	
	// Change Distance value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dash Distance, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetDashDistance( const int &nValue );
	
	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetNewLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Line Width, Sets a specify value to current class CFOPExtCornerLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetNewLineWidth( const int &nValue );

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Extend line information.
 
	// Line Information, This member specify FOPLineInfo object.  
	FOPLineInfo			m_aLineInfo;

	// Show Center Line value.
 
	// Show Center Line, This member sets TRUE if it is right.  
	BOOL                m_bShowCenterLine;

};


/////////////////////////////////////////////////////////////////////////////////
//
// CFONewUpRightLinkShape -- corner link line shape, it's ID is: FO_COMP_CORNERLINK 93
//  

 
//===========================================================================
// Summary:
//     The CFONewUpRightLinkShape class derived from CFOLinkShape
//      F O Corner Link Shape
//===========================================================================

class FO_EXT_CLASS CFONewUpRightLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFONewUpRightLinkShape---F O Corner Link Shape, Specifies a E-XD++ CFONewUpRightLinkShape object (Value).
	DECLARE_SERIAL(CFONewUpRightLinkShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Corner Link Shape, Constructs a CFONewUpRightLinkShape object.
	//		Returns A  value (Object).
	CFONewUpRightLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Corner Link Shape, Constructs a CFONewUpRightLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFONewUpRightLinkShape& src object(Value).
	CFONewUpRightLinkShape(const CFONewUpRightLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Corner Link Shape, Destructor of class CFONewUpRightLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFONewUpRightLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONewUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the corner link shape from points.
	// ptArray -- points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONewUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the corner link shape from points.
	// pptPoints -- points of shape.
	// nCount -- total points of shape.
	// pFrom -- start link port.
	// pTo -- end link port.
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONewUpRightLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFONewUpRightLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFONewUpRightLinkShape& src object(Value).
	CFONewUpRightLinkShape& operator=(const CFONewUpRightLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Relayout state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Get corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Corner Size, Returns the specified value.
	//		Returns a int type value.
	int GetCornerSize() const;

	// Set corner size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Corner Size, Sets a specify value to current class CFONewUpRightLinkShape
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void SetCornerSize(const int nSize);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#endif // !defined(AFC_FOCORNERLINKSHAPE_H__19D05237_B3FF_11D6_A633_0050BAE30439__INCLUDED_)
