//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOModelListBAR_H__7DFEADE7_B927_11D5_A477_525400EA266C__INCLUDED_)
#define AFX_FOModelListBAR_H__7DFEADE7_B927_11D5_A477_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOModelListBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOModelListBar window

#include "FOPControlBar.h"
#include "FOTemplateWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CFOModelListBar dialog

 
//===========================================================================
// Summary:
//     The CFOModelListBar class derived from CFOPControlBar
//      F O Model List Bar
//===========================================================================

class FO_EXT_CLASS CFOModelListBar : public CFOPControlBar
{

	// Construction
public:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Model List Bar, Constructs a CFOModelListBar object.
	//		Returns A  value (Object).
	CFOModelListBar();


	// Attributes
public:

	// Attributes
public:

	// pointer of template wnd.
 
	// Tool, This member specify E-XD++ CFOTemplateWnd object.  
	CFOTemplateWnd m_wndTool;

public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOModelListBar)
	//}}AFX_VIRTUAL

// Implementation
public:

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Model List Bar, Destructor of class CFOModelListBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOModelListBar();

	// Generated message map functions
protected:

	//{{AFX_MSG(CFOModelListBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd( CDC* pDC );
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOModelListBAR_H__7DFEADE7_B927_11D5_A477_525400EA266C__INCLUDED_)
