//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODROPBRUSHTYPEBUTTON_H__5B55AAC7_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FODROPBRUSHTYPEBUTTON_H__5B55AAC7_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODropBrushTypeButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFODropBrushTypeButton window

#include "FOPopupBrushTypeWnd.h"

void FO_API_DECL AFXAPI DDX_FODropBrushTypeButton(CDataExchange *pDX, int nIDC, int& nBrushType);

 
//===========================================================================
// Summary:
//     The CFODropBrushTypeButton class derived from CButton
//      F O Drop Brush Type Button
//===========================================================================

class FO_EXT_CLASS CFODropBrushTypeButton : public CButton
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODropBrushTypeButton---F O Drop Brush Type Button, Specifies a E-XD++ CFODropBrushTypeButton object (Value).
	DECLARE_DYNCREATE(CFODropBrushTypeButton);
	
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Brush Type Button, Constructs a CFODropBrushTypeButton object.
	//		Returns A  value (Object).
    CFODropBrushTypeButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Brush Type Button, Destructor of class CFODropBrushTypeButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropBrushTypeButton();
	
	// Attributes
public:
	
	// Get Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
    virtual int		 GetBrushType();

	// Set Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFODropBrushTypeButton
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies A integer value.
    virtual void     SetBrushType(int nType); 

	// Set None Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set None Text, Sets a specify value to current class CFODropBrushTypeButton
	// Parameters:
	//		&str---Specifies A CString type value.
	void			SetNoneText(const CString &str)		{ m_strNone = str; }

	//Get None Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get None Text, Returns the specified value.
	//		Returns a CString type value.
	CString			GetNoneText() const					{ return m_strNone; }
	
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFODropBrushTypeButton object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw brush with type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Brush, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&m_rc---Specifies A CRect type value.
	virtual void DrawBrush(CDC *pDC,CRect &m_rc);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	//Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set F G Color, Sets a specify value to current class CFODropBrushTypeButton
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetFGColor(const COLORREF &cr);

	//Get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get F G Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFGColor() const				{ return m_crFG; }

	//Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set B K Color, Sets a specify value to current class CFODropBrushTypeButton
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetBKColor(const COLORREF &cr);

	//Get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get B K Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetBKColor() const				{ return m_crBack; }

	// Get pattern bitmap by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

	// System colors.
 
	// System Colors, This member specify CDWordArray object.  
	CDWordArray m_arSysColors;

	// Draw pattern bitmap with given color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Pattern Bitmap, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void DrawPatternBitmap(CDC* pDC,const CRect& rect, COLORREF crColor);

	// Draw pattern bitmap with given color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Pattern Bitmap, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		dx---Specifies A integer value.  
	//		dy---Specifies A integer value.  
	//		rcColor---rcColor, Specifies A 32-bit COLORREF value used as a color value.
	void DrawPatternBitmap(CDC* pDC,int x,int y,int dx,int dy, COLORREF rcColor);

	// Get color by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		n1---Specifies A integer value.  
	//		n2---Specifies A integer value.
	COLORREF XGetColor(int n1, int n2);

	// Get color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	COLORREF XGetColor(COLORREF crColor);

	// Get system color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get System Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	COLORREF XGetSysColor(int nIndex);
	// Operations
public:
	
	//pointer to  Popup Line Window
 
	// Popup Line Window, This member maintains a pointer to the object CFOPopupBrushTypeWnd.  
	CFOPopupBrushTypeWnd *m_pPopupLineWnd;
	
	// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CFODropBrushTypeButton)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
    virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void PreSubclassWindow();
    //}}AFX_VIRTUAL	
	// Implementation
	
protected:

	// Adjust Window Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Window Size, .

    void AdjustWindowSize();

	// Draw drop combobox.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Combo Box, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		lpDS---D S, Specifies a LPDRAWITEMSTRUCT lpDS object(Value).
	virtual void OnDrawComboBox(CDC& dc,LPDRAWITEMSTRUCT lpDS);
	
    // Generated message map functions
protected:
    //{{AFX_MSG(CFODropBrushTypeButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Clicked, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL OnClicked();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Brush O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		lParam---lParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit LONG signed integer.
    afx_msg LRESULT OnSelectBrushOK(WPARAM lParam, LPARAM wParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Brush Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		lParam---lParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit LONG signed integer.
    afx_msg LRESULT OnSelectBrushCancel(WPARAM lParam, LPARAM wParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Brush Custom, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		lParam---lParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Specifies A 32-bit LONG signed integer.
    afx_msg LRESULT OnSelBrushCustom(WPARAM lParam, LPARAM wParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()
		
protected:

	// Is Force or not
 
	// Force, This member sets TRUE if it is right.  
    BOOL			m_bForce; 

	// Current Brush Type
 
	// Current Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    int				m_nCurBrushType;

	// Pointer to  Parent Window 
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			m_pParentWnd;

	// Arrow Rectangle
 
	// Arrow Rectangle, This member sets a CRect value.  
	CRect			m_ArrowRect;

	// Line Color
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLine;
protected:

	// Button Rectangle
 
	// Button, This member sets a CRect value.  
	CRect			m_rcButton;

	// Popup Size
 
	// Popup, This member sets a CSize value.  
	CSize			m_szPopup;

	//Is Popup
 
	// Popup, This member sets TRUE if it is right.  
	BOOL			m_bPopup;
	
	// Current cell FG color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crFG;

	// Current cell back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;
	
	// Brush.
 
	// Brush Cell, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*			m_pBrushCell;

	// None text.
 
	// None, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strNone;

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODROPBRUSHTYPEBUTTON_H__5B55AAC7_C753_11D5_A489_525400EA266C__INCLUDED_)
