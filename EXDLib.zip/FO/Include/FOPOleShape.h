// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPOLESHAPE_H__71D38529_7630_4BD5_B1F8_1D3329CB3253__INCLUDED_)
#define AFC_FOPOLESHAPE_H__71D38529_7630_4BD5_B1F8_1D3329CB3253__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

#include "FODrawShape.h"

class CFOPNewOleShape;
class CFOPDocumentBase;
class CFOPOleShape;
class CFODrawView;

/////////////////////////////////////////////////////////////////////////////
// CScript command target
//http://www.vckbase.com/document/viewdoc/?id=1462
#include <comdef.h>
 
/////////////////////////////////////////////////////////////////////////////
// CFOPNewOleClientItem implementation

 
//===========================================================================
// Summary:
//     The CFOPBaseObjectItem class derived from COleDocObjectItem
//      F O P Base Object Item
//===========================================================================

class FO_EXT_CLASS CFOPBaseObjectItem : public COleDocObjectItem
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPBaseObjectItem---F O P Base Object Item, Specifies a E-XD++ CFOPBaseObjectItem object (Value).
	DECLARE_SERIAL(CFOPBaseObjectItem)
		
		// Constructors
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Base Object Item, Constructs a CFOPBaseObjectItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pContainerDoc---Container Document, A pointer to the CFOPDocumentBase or NULL if the call failed.
	CFOPBaseObjectItem(CFOPDocumentBase* pContainerDoc=NULL);
	
	// Attributes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Document, Returns the specified value.
	//		Returns a pointer to the object CFOPDocumentBase,or NULL if the call failed
	CFOPDocumentBase* GetDocument() const
	{ return (CFOPDocumentBase*)COleDocObjectItem::GetDocument(); }

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPBaseObjectItem)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCode---nCode, Specifies a OLE_NOTIFICATION nCode object(Value).  
	//		dwParam---dwParam, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void OnChange(OLE_NOTIFICATION nCode, DWORD dwParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnActivate();
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPosition---rPosition, Specifies A CRect type value.
	virtual void OnGetItemPosition(CRect& rPosition);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Deactivate U I, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bUndoable---bUndoable, Specifies A Boolean value.
	virtual void OnDeactivateUI(BOOL bUndoable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rectPos---rectPos, Specifies A CRect type value.
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	LPDISPATCH GetIDispatch();
	ULONG m_nLeakRefCount;
	IDispatch* m_pDispatch;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From Moniker, Call this function to read a specified number of bytes from the archive.
	// Parameters:
	//		pUnk---pUnk, Specifies a LPUNKNOWN pUnk object(Value).  
	//		swzName---swzName, A pointer to the OLECHAR or NULL if the call failed.
	void LoadFromMoniker(LPUNKNOWN pUnk, OLECHAR* swzName);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish Create, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sc---Specifies a SCODE sc object(Value).
	BOOL FinishCreate(SCODE sc);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process New Object, Call the Process member function to translate a caught exception.

	void ProcessNewObject();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Base Object Item, Destructor of class CFOPBaseObjectItem
	//		Returns A  value (Object).
	~CFOPBaseObjectItem();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		prectBounds---prectBounds, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.  
	//		nDrawAspect---Draw Aspect, Specifies a DVASPECT nDrawAspect = DVASPECT(-1 ) object(Value).
	BOOL Draw( CDC* pDC, LPCRECT prectBounds, DVASPECT nDrawAspect = DVASPECT(
	  -1 ) );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Back To Front, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		prectBounds---prectBounds, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	BOOL DrawBackToFront( CDC* pDC, LPCRECT prectBounds );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Front To Back, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		prectBounds---prectBounds, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
   BOOL DrawFrontToBack( CDC* pDC, LPCRECT prectBounds );
 
	// m_info Control, This member specify CONTROLINFO object.  
	CONTROLINFO m_infoControl;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Page C L S I Ds, Returns the specified property value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CLSID---L S I D, Specifies A CArray array.  
	//		aclsidPages---aclsidPages, Specifies a CLSID& >& aclsidPages object(Value).
	BOOL GetPropertyPageCLSIDs( CArray< CLSID, CLSID& >& aclsidPages );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial  Information, Call InitControlInfo after creating a new object.
	//		Returns A HRESULT value (Object).
	HRESULT InitControlInfo();

	virtual void ReadItem( CArchive& ar );

	// Obtain the object members.
	BOOL GetObjectMembers(CStringArray &properties,CStringArray &methods);

	// Obtain function params.
	BOOL GetObjectFuncParams(CString &methodName,CStringArray &params);
	
	// Obtain the events.
	void GetObjectEvents(CStringArray &events);

	// Obtain event params.
	BOOL GetEventParams(CString evntName,CStringArray &params);

	//-----------------------------------------------------------------------
	// Summary:
	// Get  Information, Returns the specified value.
	//		Returns A HRESULT value (Object).
	HRESULT GetControlInfo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPBaseObjectItem object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		clsid---Specifies a REFCLSID clsid object(Value).  
	//		pszName---pszName, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL Create( REFCLSID clsid, LPCTSTR pszName = NULL );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy To Clipboard, Create a duplicate copy of this object.
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).  
	//		pStorage---pStorage, A pointer to the IStorage or NULL if the call failed.
	void CopyToClipboard(CArchive& ar,IStorage* pStorage);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Commit Item, .
	// Parameters:
	//		bSuccess---bSuccess, Specifies A Boolean value.
	void CommitItem( BOOL bSuccess );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Clipboard, You construct a CFOPBaseObjectItem object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).  
	//		pStorage---pStorage, A pointer to the IStorage or NULL if the call failed.
	BOOL CreateFromClipboard(CArchive& ar,IStorage* pStorage);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Should Activate When Visible, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL ShouldActivateWhenVisible();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Or Load, You construct a CFOPBaseObjectItem object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		clsid---Specifies a REFCLSID clsid object(Value).  
	//		iidPersistanceMedium---Persistance Medium, Specifies a REFIID iidPersistanceMedium object(Value).  
	//		pPersistanceMedium---Persistance Medium, A pointer to the IUnknown or NULL if the call failed.
	BOOL CreateOrLoad(	REFCLSID clsid,
		REFIID iidPersistanceMedium,
		IUnknown* pPersistanceMedium);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is U I Active, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsUIActive() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inside Out, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsInsideOut() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Invisible At Runtime, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsInvisibleAtRuntime() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Acts Like Button, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL ActsLikeButton() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save To Storage, Call this function to save the specify data to a file.
	//		Returns A HRESULT value (Object).  
	// Parameters:
	//		pStorage---pStorage, A pointer to the IStorage or NULL if the call failed.
	HRESULT SaveToStorage( IStorage* pStorage );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save To Stream, Call this function to save the specify data to a file.
	//		Returns A HRESULT value (Object).  
	// Parameters:
	//		pStream---pStream, A pointer to the IStream or NULL if the call failed.
	HRESULT SaveToStream( IStream* pStream );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void Move( const CRect& rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Item, Invalidates the specify area of object. 

	void InvalidateItem();

	BOOL BeOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Message, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMessage---pMessage, A pointer to the const MSG or NULL if the call failed.
	BOOL OnWindowMessage( const MSG* pMessage );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Windowless, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsWindowless() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	DWORD HitTest( CPoint point );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Deselect, This member function is called by the framework to allow your application to handle a Windows message.

	void OnDeselect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select, This member function is called by the framework to allow your application to handle a Windows message.

	void OnSelect();
	//		BOOL QuickActivate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update From Server Extent, Call this member function to update the object.

	void UpdateFromServerExtent();

	void GetBitmap(CBitmap &bmp, int cx1, int cy1,COLORREF crBack);

	CSize szOld;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release, .
	// Parameters:
	//		dwCloseOption---Close Option, Specifies a OLECLOSE dwCloseOption object(Value).
	virtual void Release( OLECLOSE dwCloseOption = OLECLOSE_NOSAVE);
 
	CMap<DWORD , DWORD, CString ,CString&> m_infoEvents;
	CMap<CString , LPCTSTR, CString ,CString&> m_mapEventCallback;

	// View Object Ex, This member specify IViewObjectExPtr object.  
	IViewObjectExPtr m_pViewObjectEx;
 
	// View Status, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_dwViewStatus;
 
	// This member sets a CRect value.  
	CRect m_rect;
 
	// Ole , This member specify IOleControlPtr object.  
	IOleControlPtr m_pOleControl;
 
	// Event C P, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	IConnectionPointPtr m_pEventCP;
 
	// Misc Status, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_dwMiscStatus;
 
	// Aspect Pass2, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_dwAspectPass2;
 
	// Inside Out, This member sets TRUE if it is right.  
	BOOL m_tInsideOut;

	CView *m_pCurView;
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
	
 
	// Ole In Place Object Windowless, This member specify IOleInPlaceObjectWindowlessPtr object.  
	IOleInPlaceObjectWindowlessPtr m_pOleInPlaceObjectWindowless;
 
	// Windowless, This member sets TRUE if it is right.  
	BOOL m_tWindowless;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPNewOleClientItem implementation

 
//===========================================================================
// Summary:
//     The CFOPNewOleClientItem class derived from CFOPBaseObjectItem
//      F O P New Ole Client Item
//===========================================================================

class FO_EXT_CLASS CFOPNewOleClientItem : public CFOPBaseObjectItem
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewOleClientItem---F O P New Ole Client Item, Specifies a E-XD++ CFOPNewOleClientItem object (Value).
	DECLARE_SERIAL(CFOPNewOleClientItem)
	
// Constructors
public:
	void SetShape(CFODrawShape *pShape);
	
	// m_pShape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape * m_pShape;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetShape();
	
	CString strName;
	LPDISPATCH GetIDispatch();
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	// pContainer -- pointer of the document
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Ole Client Item, Constructs a CFOPNewOleClientItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pContainer---pContainer, A pointer to the CFOPDocumentBase or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFOPNewOleShape or NULL if the call failed.
	CFOPNewOleClientItem ( CFOPDocumentBase* pContainer = NULL, CFOPNewOleShape* pShape = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Ole Client Item, Destructor of class CFOPNewOleClientItem
	//		Returns A  value (Object).
	~CFOPNewOleClientItem();

// Attributes
public:
	
	// Obtain the document pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Document, Returns the specified value.
	//		Returns a pointer to the object CFOPDocumentBase,or NULL if the call failed
	CFOPDocumentBase* GetDocument()
		{ return (CFOPDocumentBase*)CFOPBaseObjectItem::GetDocument(); }

	// Get object dispatch interface.
	LPDISPATCH getIDispatch();
	
	// Get dispatch name.
	bool getDISPID(const char* name, DISPID* dispid);

	// Obtain the pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active View, Returns the specified value.
	//		Returns a pointer to the object CFODrawView,or NULL if the call failed
	CFODrawView* GetActiveView()
		{ return (CFODrawView*)CFOPBaseObjectItem::GetActiveView(); }

	// pointer of the shape.
 
	// Draw Shape, This member maintains a pointer to the object CFOPNewOleShape.  
	CFOPNewOleShape* m_pDrawShape;    // back pointer to OLE draw object

	// Update extent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Extent, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateExtent();
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPNewOleClientItem)
public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file
	virtual void Serialize(CArchive& ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file
	virtual void Serialize2(CArchive& ar);

	// Obtain the position of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPosition---rPosition, Specifies A CRect type value.
	virtual void OnGetItemPosition(CRect& rPosition);

	// Window context change method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Window Context, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ppMainFrame---Main Frame, A pointer to the CFrameWnd* or NULL if the call failed.  
	//		ppDocFrame---Document Frame, A pointer to the CFrameWnd* or NULL if the call failed.  
	//		lpFrameInfo---Frame Information, Specifies a LPOLEINPLACEFRAMEINFO lpFrameInfo object(Value).
	virtual BOOL OnGetWindowContext(CFrameWnd** ppMainFrame,
		CFrameWnd** ppDocFrame, LPOLEINPLACEFRAMEINFO lpFrameInfo);

	// Implementation
protected:
	
	DECLARE_MESSAGE_MAP()
		DECLARE_OLECREATE(CFOPNewOleClientItem)
		
		// Generated OLE dispatch map functions
		//{{AFX_DISPATCH(CFOPNewOleClientItem)
		// NOTE - the ClassWizard will add and remove member functions here.
		//}}AFX_DISPATCH
		DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
protected:

	// Do when changing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wNotification---wNotification, Specifies a OLE_NOTIFICATION wNotification object(Value).  
	//		dwParam---dwParam, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);

	// Deactivate
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Deactivate U I, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bUndoable---bUndoable, Specifies A Boolean value.
	virtual void OnDeactivateUI(BOOL bUndoable);

	// Change item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rectPos---rectPos, Specifies A CRect type value.
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);

	// Activate
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnActivate();

	// event.
	virtual void OnEvent(DISPID dispid, DISPPARAMS* pdpParams);
	
	BEGIN_INTERFACE_PART( EventHandler, IDispatch )
		STDMETHOD( GetIDsOfNames )( REFIID iid, LPOLESTR* ppszNames, UINT nNames,
		LCID lcid, DISPID* pDispIDs );
	STDMETHOD( GetTypeInfo )( UINT iTypeInfo, LCID lcid,
		ITypeInfo** ppTypeInfo );
	STDMETHOD( GetTypeInfoCount )( UINT* pnInfoCount );
	STDMETHOD( Invoke )( DISPID dispidMember, REFIID iid, LCID lcid,
		WORD wFlags, DISPPARAMS* pdpParams, VARIANT* pvarResult,
		EXCEPINFO* pExceptionInfo, UINT* piArgError );
   END_INTERFACE_PART( EventHandler )
};

/////////////////////////////////////////////////////////////////////////////
// CFOPNewOleShape implementation -- shape that can contain OCX as it's children control.
//				To use this shape, you must have COleDocument based view - doc application.
//				ID: FOP_NEW_OLE_COMP 286

 
//===========================================================================
// Summary:
//     The CFOPNewOleShape class derived from CFODrawShape
//      F O P New Ole Shape
//===========================================================================

class FO_EXT_CLASS CFOExcepInfo :
public EXCEPINFO
{
public:
	CFOExcepInfo();
	~CFOExcepInfo();
	
	void Clear();
};
class FO_EXT_CLASS CFOPNewOleShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewOleShape---F O P New Ole Shape, Specifies a E-XD++ CFOPNewOleShape object (Value).
	DECLARE_SERIAL(CFOPNewOleShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Ole Shape, Constructs a CFOPNewOleShape object.
	//		Returns A  value (Object).
	CFOPNewOleShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Ole Shape, Constructs a CFOPNewOleShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewOleShape& src object(Value).
	CFOPNewOleShape(const CFOPNewOleShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Ole Shape, Destructor of class CFOPNewOleShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewOleShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewOleShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of the shape.
	// strCaption -- caption.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewOleShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewOleShape& src object(Value).
	CFOPNewOleShape& operator=(const CFOPNewOleShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to polygon or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

public:
	
	void ClearImage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Open old object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Open, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pView---pView, A pointer to the CView or NULL if the call failed.
	virtual void	OnOpen(CView* pView);

	// Do edit properties
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CView or NULL if the call failed.
	virtual BOOL	OnEditProperties(CView* pView);

	// Get ole client item.
	CFOPNewOleClientItem* getOleClientItem();
	
	// Close ole client item.
	void closeOleClientItem();

	// Invoke dispatch.
	COleVariant onInvoke(DISPPARAMS& disp, const DISPID& nMethodID, const INVOKEKIND& nInvokeKind);

	COleVariant m_varResult;
	CFOExcepInfo m_excepInfo;
	BOOL m_tException;
public:
	// Item showing or not
 
	// Show Items, This member sets TRUE if it is right.  
	static BOOL		c_bShowItems;

	// Pointer of the client item.
 
	// Client Item, This member maintains a pointer to the object CFOPNewOleClientItem.  
	CFOPNewOleClientItem  *m_pClientItem;
	
	// current extent is tracked separate from scaled position
 
	// This member sets a CSize value.  
	CSize				m_extent;

	// Click Image, This member maintains a pointer to the object CFOBitmap.  
	CFOBitmap *m_pClickImage;		
	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};


/////////////////////////////////////////////////////////////////////////////
// CFOPOleClientItem implementation

 
//===========================================================================
// Summary:
//     The CFOPOleClientItem class derived from COleClientItem
//      F O P Ole Client Item
//===========================================================================

class FO_EXT_CLASS CFOPOleClientItem : public COleClientItem
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPOleClientItem---F O P Ole Client Item, Specifies a E-XD++ CFOPOleClientItem object (Value).
	DECLARE_SERIAL(CFOPOleClientItem)

// Constructors
public:
	
	// Constructor.
	// pContainer -- pointer of the document
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ole Client Item, Constructs a CFOPOleClientItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pContainer---pContainer, A pointer to the CFOPDocumentBase or NULL if the call failed.  
	//		pShape---pShape, A pointer to the CFOPOleShape or NULL if the call failed.
	CFOPOleClientItem ( CFOPDocumentBase* pContainer = NULL, CFOPOleShape* pShape = NULL);
	
// Attributes
public:
	
	// Obtain the document pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Document, Returns the specified value.
	//		Returns a pointer to the object CFOPDocumentBase,or NULL if the call failed
	CFOPDocumentBase* GetDocument()
		{ return (CFOPDocumentBase*)COleClientItem::GetDocument(); }

	// Obtain the pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active View, Returns the specified value.
	//		Returns a pointer to the object CFODrawView,or NULL if the call failed
	CFODrawView* GetActiveView()
		{ return (CFODrawView*)COleClientItem::GetActiveView(); }

	// pointer of the shape.
 
	// Draw Shape, This member maintains a pointer to the object CFOPOleShape.  
	CFOPOleShape* m_pDrawShape;    // back pointer to OLE draw object

	// Update extent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Extent, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateExtent();

// Implementation
public:

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Ole Client Item, Destructor of class CFOPOleClientItem
	//		Returns A  value (Object).
	~CFOPOleClientItem();

	CView *m_pCurView;
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ar---Specifies a CArchive& ar object(Value).
	// Serialize data to file
	virtual void Serialize(CArchive& ar);

	// Obtain the position of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPosition---rPosition, Specifies A CRect type value.
	virtual void OnGetItemPosition(CRect& rPosition);

	// Window context change method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Window Context, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ppMainFrame---Main Frame, A pointer to the CFrameWnd* or NULL if the call failed.  
	//		ppDocFrame---Document Frame, A pointer to the CFrameWnd* or NULL if the call failed.  
	//		lpFrameInfo---Frame Information, Specifies a LPOLEINPLACEFRAMEINFO lpFrameInfo object(Value).
	virtual BOOL OnGetWindowContext(CFrameWnd** ppMainFrame,
		CFrameWnd** ppDocFrame, LPOLEINPLACEFRAMEINFO lpFrameInfo);
protected:

	// Do when changing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wNotification---wNotification, Specifies a OLE_NOTIFICATION wNotification object(Value).  
	//		dwParam---dwParam, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);

	// Deactivate
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Deactivate U I, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bUndoable---bUndoable, Specifies A Boolean value.
	virtual void OnDeactivateUI(BOOL bUndoable);

	// Change item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Item Position, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rectPos---rectPos, Specifies A CRect type value.
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);

	// Activate
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnActivate();
};

/////////////////////////////////////////////////////////////////////////////
// CFOPOleShape implementation -- shape that can contain OCX as it's children control.
//				To use this shape, you must have COleDocument based view - doc application.
//				ID: FOP_COMP_OLE 210

 
//===========================================================================
// Summary:
//     The CFOPOleShape class derived from CFODrawShape
//      F O P Ole Shape
//===========================================================================

class FO_EXT_CLASS CFOPOleShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPOleShape---F O P Ole Shape, Specifies a E-XD++ CFOPOleShape object (Value).
	DECLARE_SERIAL(CFOPOleShape);
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ole Shape, Constructs a CFOPOleShape object.
	//		Returns A  value (Object).
	CFOPOleShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Ole Shape, Constructs a CFOPOleShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPOleShape& src object(Value).
	CFOPOleShape(const CFOPOleShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Ole Shape, Destructor of class CFOPOleShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPOleShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPOleShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of the shape.
	// strCaption -- caption.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPOleShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPOleShape& src object(Value).
	CFOPOleShape& operator=(const CFOPOleShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to polygon or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Open old object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Open, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pView---pView, A pointer to the CView or NULL if the call failed.
	virtual void	OnOpen(CView* pView);

	// Do edit properties
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pView---pView, A pointer to the CView or NULL if the call failed.
	virtual BOOL	OnEditProperties(CView* pView);

public:
	// Item showing or not
 
	// Show Items, This member sets TRUE if it is right.  
	static BOOL		c_bShowItems;

	// Pointer of the client item.
 
	// Client Item, This member maintains a pointer to the object CFOPOleClientItem.  
	CFOPOleClientItem  *m_pClientItem;
	
	// current extent is tracked separate from scaled position
 
	// This member sets a CSize value.  
	CSize				m_extent;

	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#endif // !defined(AFC_FOPOLESHAPE_H__71D38529_7630_4BD5_B1F8_1D3329CB3253__INCLUDED_)
