//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPOPUPSLIDERWND_H__C9D7B788_2F0C_11D6_A536_525400EA266C__INCLUDED_)
#define AFX_FOPOPUPSLIDERWND_H__C9D7B788_2F0C_11D6_A536_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPopupSliderWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPopupSliderWnd window

 
//===========================================================================
// Summary:
//     The CFOPopupSliderWnd class derived from CWnd
//      F O Popup Slider Window
//===========================================================================

class FO_EXT_CLASS CFOPopupSliderWnd : public CWnd
{
// Construction
public:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Popup Slider Window, Constructs a CFOPopupSliderWnd object.
	//		Returns A  value (Object).
    CFOPopupSliderWnd();

	// Construction.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Popup Slider Window, Constructs a CFOPopupSliderWnd object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pt---Specifies A CPoint type value.  
	//		nPos---nPos, Specifies A integer value.  
	//		nMin---nMin, Specifies A integer value.  
	//		nMax---nMax, Specifies A integer value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
    CFOPopupSliderWnd(CPoint pt, int nPos, int nMin, int nMax, CWnd* pParentWnd );
                 
// Operations
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPopupSliderWnd object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A CPoint type value.  
	//		nPos---nPos, Specifies A integer value.  
	//		nMin---nMin, Specifies A integer value.  
	//		nMax---nMax, Specifies A integer value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	// Create a new window.
    BOOL	Create(CPoint pt, int nPos, int nMin, int nMax, CWnd* pParentWnd );

	// Set the pos of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPopupSliderWnd
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void	SetPos(int nPos);

	// Get pos of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns a int type value.
	int		GetPos() const					{ return m_nCurrentPos; }

	// Set range of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range, Sets a specify value to current class CFOPopupSliderWnd
	// Parameters:
	//		nMin---nMin, Specifies A integer value.  
	//		nMax---nMax, Specifies A integer value.
	void	SetRange(int nMin, int nMax)	{ m_nMinValue = nMin; m_nMaxValue = nMax; }

	// Set step value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Step Value, Sets a specify value to current class CFOPopupSliderWnd
	// Parameters:
	//		nStep---nStep, Specifies A integer value.
	void	SetStepValue(int nStep)			{ m_nStepValue = nStep; }

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CFOPopupSliderWnd)
    //}}AFX_VIRTUAL

protected:

	// Do change state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change, This member function is called by the framework to allow your application to handle a Windows message.

    void	OnChange();

	// Do close state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	// Parameters:
	//		nType---nType, Specifies A integer value.
    void	OnClose(int nType);

	// Do draw.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	void	OnDraw(int nPos);

protected:
    //{{AFX_MSG(CFOPopupSliderWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Destroy, This member function is called by the framework to allow your application to handle a Windows message.

    afx_msg void OnNcDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

    afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
#if _MSC_VER > 1200 //MFC 7.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
    afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif //MFC 7.0
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
    DECLARE_MESSAGE_MAP()

protected:

	// The pointer of parent window.
 
	// Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
    CWnd*          m_pParent;
	
	// Current slider position.
 
	// Slider Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			   m_nSliderPos;

	// Current value.
 
	// Current Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			   m_nCurrentPos;

	// Min value of control.
 
	// Minimize Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			   m_nMinValue;

	// Max value of control.
 
	// Maximize Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			   m_nMaxValue;

	// Per step value.
 
	// Step Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			   m_nStepValue;

	// Black pen.
 
	// The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		   m_black;

	// Grey pen.
 
	// The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		   m_dgrey;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPOPUPSLIDERWND_H__C9D7B788_2F0C_11D6_A536_525400EA266C__INCLUDED_)
