//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBulletTypeCellObj.h: interface for the CFOBulletTypeCellObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBULLETTYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_)
#define AFX_FOBULLETTYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

 
//===========================================================================
// Summary:
//     The CFOBulletTypeCellObj class derived from CObject
//      F O Bullet Type Cell Object
//===========================================================================

class FO_EXT_CLASS CFOBulletTypeCellObj : public CObject
{
protected:

	// Delare serial class
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBulletTypeCellObj---F O Bullet Type Cell Object, Specifies a E-XD++ CFOBulletTypeCellObj object (Value).
	DECLARE_SERIAL(CFOBulletTypeCellObj);
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bullet Type Cell Object, Constructs a CFOBulletTypeCellObj object.
	//		Returns A  value (Object).
	CFOBulletTypeCellObj();

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bullet Type Cell Object, Destructor of class CFOBulletTypeCellObj
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBulletTypeCellObj();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize the data to file
	virtual void Serialize(CArchive &ar);

    // Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint point);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

    // Draw all the object 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pImage---*pImage, A pointer to the CImageList  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC,CImageList *pImage);

    // Draw the select object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Set rectangle of position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOBulletTypeCellObj
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void	SetItemRect(const CRect &rcPos)			{ m_rcPosition = rcPos; }

	// Get rectangle of position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const						{ return m_rcPosition; }
   
	// Set Arrow Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bullet Type, Sets a specify value to current class CFOBulletTypeCellObj
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void	SetBulletType(const int &nType);

	// Get Arrow Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bullet Type, Returns the specified value.
	//		Returns a int type value.
	int		GetBulletType() const				{ return m_nBulletType; }

    // Set Size of Cell Border 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOBulletTypeCellObj
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder)	{ nCellBorderSize = nBorder; }
    

protected:
	// Position of the cell.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Current cell color.
 
	// Cell, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crCell;

	// Current line type.
 
	// Bullet Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int 		m_nBulletType;
	
	// Cell border size.
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCellBorderSize;

};

   //Define type CTypedPtrList
typedef CTypedPtrList<CObList, CFOBulletTypeCellObj*> CFOBulletTypeCellObjList;

#endif // !defined(AFX_FOBULLETTYPECELLOBJ_H__5B55AAC3_C753_11D5_A489_525400EA266C__INCLUDED_)
