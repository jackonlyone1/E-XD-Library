//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOUNDOREDOLISTBOX_H__D1345A18_E845_4B12_A3F0_525C400A8682__INCLUDED_)
#define AFX_FOUNDOREDOLISTBOX_H__D1345A18_E845_4B12_A3F0_525C400A8682__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOUndoRedoListBox.h : header file
//

class CFOUndoRedoWnd;

/////////////////////////////////////////////////////////////////////////////
// CFOUndoRedoListBox window

 
//===========================================================================
// Summary:
//     The CFOUndoRedoListBox class derived from CListBox
//      F O Undo Redo List Box
//===========================================================================

class FO_EXT_CLASS CFOUndoRedoListBox : public CListBox
{
// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Undo Redo List Box, Constructs a CFOUndoRedoListBox object.
	//		Returns A  value (Object).
	CFOUndoRedoListBox();

// Attributes
protected:

	// Undo wnd.
 
	// Undo Redo Window, This member maintains a pointer to the object CFOUndoRedoWnd.  
	CFOUndoRedoWnd	*m_pUndoRedoWnd;

// Operations
public:
	
	// Set undo wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Undo Window, Sets a specify value to current class CFOUndoRedoListBox
	// Parameters:
	//		pWnd---pWnd, A pointer to the CFOUndoRedoWnd or NULL if the call failed.  
	//		bUndoMode---Undo Mode, Specifies A Boolean value.
	void SetUndoWnd(
		// Undo/Redo window.
		CFOUndoRedoWnd* pWnd,
		// Undo or Redo mode.
		BOOL bUndoMode
		);

	// TRUE - is undo mode, FALSE - is redo mode.
 
	// Undo Mode, This member sets TRUE if it is right.  
	BOOL		m_bUndoMode;

	// Do selection change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Select Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSelectChange();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOUndoRedoListBox)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Undo Redo List Box, Destructor of class CFOUndoRedoListBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOUndoRedoListBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOUndoRedoListBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOUNDOREDOLISTBOX_H__D1345A18_E845_4B12_A3F0_525C400A8682__INCLUDED_)
