//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPTOOLBAR_H__52844B29_68B5_435F_BC04_09CE6D5B6132__INCLUDED_)
#define AFX_FOPTOOLBAR_H__52844B29_68B5_435F_BC04_09CE6D5B6132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPToolBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBar window

#include "FOPControlBar.h"
#include "FOPToolBarButton.h"
#include "FOTemplateWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBar window

#define FOP_TBBS_RAISED		(MAKELONG(0, 0x0100))
#define FOP_TBBS_ENABLE		(MAKELONG(0, 0x1000))
#define FOP_TBBS_MIDDLE		(MAKELONG(0, 0x2000))

// Combo box button item data.
struct FOPComboBoxData
{
	int nComboID;       // Combo control ID
	DWORD dwComboStyle; // Style of combo control.
	int nDefaultWidth;	// Default width.
	int nMinSize;		// Min size
	int nHeight;		// Height
};

/////////////////////////////////////////////////////////////////////////////
// CFOPToolBar

 
//===========================================================================
// Summary:
//     The CFOPToolBar class derived from CFOPControlBar
//      F O P Tool Bar
//===========================================================================

class FO_EXT_CLASS CFOPToolBar : public CFOPControlBar
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPToolBar---F O P Tool Bar, Specifies a E-XD++ CFOPToolBar object (Value).
	DECLARE_DYNCREATE(CFOPToolBar)
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Tool Bar, Constructs a CFOPToolBar object.
	//		Returns A  value (Object).
	CFOPToolBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Tool Bar, Destructor of class CFOPToolBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPToolBar();

public:

	// Button wrap type
	struct FOPMyType
	{
		int  m_nNextID;	// Next id
		BOOL m_bAtSep;	// Separator.
		int  m_nSize;	// Size
		int  m_nRowHeight;	// Row height.
	};

public:

	// Create toolbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwCtrlStyle---Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpszTitle---lpszTitle, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL CreateEx(
		// Pointer of parent wnd.
		CWnd * pParentWnd, 
		// Control style.
		DWORD dwCtrlStyle = CBRS_FOP_COOLBORDER | CBRS_FOP_BTN, 
		// Style
		DWORD dwStyle = WS_VISIBLE | WS_CHILD | CBRS_TOP | CBRS_TOOLTIPS | CBRS_SIZE_DYNAMIC, 
		// Control ID
		UINT nID = AFX_IDW_TOOLBAR,
		// Label
		LPCTSTR lpszTitle = NULL
		);
	
	// Add a drop arrow button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the arrow toolbar item
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Arrow Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropArrowButton(int nID,int nID2,BOOL bSame = TRUE);

	// Add a drop menu button.
	// nID -- id value of the toolbar item
	// nMenuID -- menu resource ID.
	// nSubMenuId -- sub menu resource ID.
	// nAlign -- alignment style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Menu Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nMenuId---Menu Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nSubMenuId---Child Menu Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nAlign---nAlign, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void ChangeToDropMenuButton(int nID,UINT nMenuId,UINT nSubMenuId,
		UINT nAlign = TPM_LEFTALIGN);

	// Add a drop color picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the color picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Color Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A integer value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropColorPickerButton(int nID,int nID2,int nStyle,
		BOOL bSame = TRUE);

	// Add a drop line width picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Line Width Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A integer value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropLineWidthPickerButton(int nID,int nID2,int nStyle,
		BOOL bSame = TRUE);

	// Add a drop line type picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Line Type Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropLineTypePickerButton(int nID,int nID2,UINT nStyle,
		BOOL bSame = TRUE);

	// Add a drop undo list picker button.
	// nID -- the id of the toolbar item
	// pArray -- strings that to be listed within the drop down listbox
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.

	// bUndoMode -- it is undo mode,it will be TRUE,else it will be redo mode( showing redo list box).
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Undo List Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		*pArray---*pArray, Specifies A CString type value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bUndoMode---Undo Mode, Specifies A Boolean value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropUndoListPickerButton(int nID,int nID2,CStringArray *pArray,
		UINT nStyle,BOOL bUndoMode = TRUE,BOOL bSame = TRUE);

	// Add a drop table picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.

	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Table Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropTablePickerButton(int nID,int nID2,
		UINT nStyle,BOOL bSame = TRUE);

	// Add a drop arrow picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Arrow Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropArrowPickerButton(int nID,int nID2,UINT nStyle,
		BOOL bSame = TRUE);

	// Add a drop shadow picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Shadow Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		nID2---I D2, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropShadowPickerButton(int nID,int nID2,UINT nStyle,
		BOOL bSame = TRUE);

	// Add a drop image picker button.
	// nID -- the id of the toolbar item
	// nID2 -- the id of the drop arrow toolbar item
	// nStyle -- style of the drop picker,it should be one of the following style:
	// 	enum FOPButtonStyle
	// {	
	// 	BS_OWNERDRAWN = 1, 
	// 	BS_DROPDOWNTOOLBAR = 2,
	// 	BS_LARGESMALL = 4,
	// 	BS_SINGLE = 8,
	// 	BS_DROPARROWHORZ = 16
	// };
	// mostly,you use 16 instead.

	// nCols -- columns of the drop down image picker.
	// nImageRes -- toolbar resource ID (The full toolbar resource id,such as IDR_MAINFRAME).
	// bUseSameID -- the toolbar item and the arrow toolbar item use the same id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Drop Image Picker Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCols---nCols, Specifies A integer value.  
	//		nImageRes---Image Resource, Specifies A integer value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual void ChangeToDropImagePickerButton(UINT nID,UINT nID2,UINT nStyle,int nCols,
		int nImageRes,BOOL bSame = TRUE);

	// Add a combobox button.
	// nID -- the id of the toolbar item
	// cbData -- combox style data,such as:
	// 	FOPComboBoxData data;
	// 	data.nComboID = IDC_COMBO_ZOOMVALUE;
	// 	data.dwComboStyle = (UINT)CBS_DROPDOWN|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL;
	// 	data.nDefaultWidth = 60;
	// 	data.nMinSize = 40;
	// 	data.nHeight = 200;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Combo Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual void ChangeToComboButton(int nID,const FOPComboBoxData &cbData);

	// Add a font face combobox button.
	// nID -- the id of the toolbar item
	// cbData -- combox style data,such as:
	// 	FOPComboBoxData data;
	// 	data.nComboID = IDC_COMBO_FONTNAME;
	//	data.dwComboStyle = (UINT)CBS_DROPDOWN|WS_VSCROLL|CBS_HASSTRINGS|CBS_SORT|CBS_OWNERDRAWVARIABLE;
	//	data.nDefaultWidth = 150;
	//	data.nMinSize = 40;
	//	data.nHeight = 250;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Font Face Combo Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual void ChangeToFontFaceComboButton(int nID,const FOPComboBoxData &cbData);

	// Add a layers combobox button.
	// nID -- the id of the toolbar item
	// cbData -- combox style data,such as:
	// 	FOPComboBoxData data;
	// 	data.nComboID = IDC_COMBO_LAYER;
	//	data.dwComboStyle = (UINT)CBS_DROPDOWN|WS_VSCROLL|CBS_HASSTRINGS|CBS_SORT|CBS_OWNERDRAWVARIABLE;
	//	data.nDefaultWidth = 85;
	//	data.nMinSize = 40;
	//	data.nHeight = 250;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Layer Combo Button, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual void ChangeToLayerComboButton(int nID,const FOPComboBoxData &cbData);

	// Is toolbar locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLocked () const { return m_bLocked; }

	// Get resource id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resource I D, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetResourceID () const { return m_uiTemp1; }

	// Is toolbar vertical dock.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Vertical Dock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsVertDock() const { return m_bTempValue6; }
	
	// Load bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmap, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
	BOOL LoadBitmap(UINT nIDResource, const UINT * lpIDArray, int nIDCount);
	
	// Load bitmap resource
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmap, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResourceName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
	BOOL LoadBitmap(LPCTSTR lpszResourceName, const UINT * lpIDArray, int nIDCount);

	//-----------------------------------------------------------------------
	// Summary:
	// Other method

	void DoOtherMehod1();

public:

	// Change button style
	// nIndex -- index of the toolbar item.
	// nStyle -- new style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button Style, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetButtonStyle(int nIndex, UINT nStyle);

	// Get button style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Style, Returns the specified value.
	//		Returns a UINT type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	UINT GetButtonStyle(int nIndex) const;

	// Get images offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Images Offset, Returns the specified value.
	//		Returns a int type value.
	int GetImagesOffset () const {	return m_iImagesOffset; }

	// Hide specify button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Button, Hides the objects by removing it from the display screen. 
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		bHide---bHide, Specifies A Boolean value.
	void HideButton(int nIndex, BOOL bHide);
	
	// Remove specify button on the toolbar.
	// nIndex -- index of the toolbar item.
	// bNoUpdate -- update or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Button, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		bNoUpdate---No Update, Specifies A Boolean value.
	virtual BOOL DeleteButton(int nIndex, BOOL bNoUpdate = FALSE);

	// Do temp;
	void DoxTTMethod1(const int &nIndex, int &nAdjuster);

	// Add a standard button.
	// nIndex -- the index of the toolbar item that to be inserted to.
	// nID -- new button id value.
	// bSeparator -- separator or not.
	// bNoUpdate -- update or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Button, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nID---I D, Specifies A integer value.  
	//		bSeparator---bSeparator, Specifies A Boolean value.  
	//		bNoUpdate---No Update, Specifies A Boolean value.
	virtual void InsertButton(int nIndex, int nID, BOOL bSeparator = FALSE, BOOL bNoUpdate = FALSE);

	// Add buttons.
	// nNumButtons -- number of the buttons.
	// lpButtons -- buttons array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Buttons, Inserts a child object at the given index..
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nNumButtons---Number Buttons, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpButtons---lpButtons, Specifies a LPTBBUTTON lpButtons object(Value).
	BOOL InsertButtons(UINT nNumButtons, LPTBBUTTON lpButtons);
	
protected:

	// Create buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CFOPToolBarButton * CreateButton(UINT nID);

	// Create drop arrow button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Arrow Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropArrowToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropArrowToolBarButton * CreateDropArrowButton(UINT nID,UINT nID2,BOOL bSame);

	// Create drop down menu button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Menu Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropMenuToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nMenuId---Menu Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nSubMenuId---Child Menu Id, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nAlign---nAlign, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CFOPDropMenuToolBarButton * CreateDropMenuButton(UINT nID,UINT nMenuId,
		UINT nSubMenuId,UINT nAlign);

	// Create drop color picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Color Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropColorPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropColorPickerWellButton * CreateDropColorPickerButton(UINT nID,UINT nID2,
		UINT nStyle,BOOL bSame);

	// Create drop line width picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Line Width Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropLineWidthPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropLineWidthPickerWellButton * CreateDropLineWidthPickerButton(UINT nID,UINT nID2,
		UINT nStyle,BOOL bSame);

	// Create drop line type picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Line Type Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropLineTypePickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropLineTypePickerWellButton * CreateDropLineTypePickerButton(UINT nID,UINT nID2,
		UINT nStyle,BOOL bSame);

	// Create drop undo list picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Undo List Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropUndoListPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pArray---*pArray, Specifies A CString type value.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bUndoMode---Undo Mode, Specifies A Boolean value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropUndoListPickerWellButton * CreateDropUndoListPickerButton(UINT nID,UINT nID2,
		CStringArray *pArray,UINT nStyle,BOOL bUndoMode,BOOL bSame);

	// Create drop table picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Table Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropTablePickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropTablePickerWellButton * CreateDropTablePickerButton(UINT nID,UINT nID2,UINT nStyle,
		BOOL bSame);

	// Create drop arrow picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Arrow Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropArrowPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropArrowPickerWellButton * CreateDropArrowPickerButton(UINT nID,UINT nID2,UINT nStyle,
		BOOL bSame);

	// Create layer combobox button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Layer Combo Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPLayerComboBox ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		m_nStyle---m_nStyle, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual CFOPLayerComboBox * CreateLayerComboButton(UINT nID, int m_nStyle,const FOPComboBoxData &cbData);

	// Create drop arrow picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Shadow Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropShadowPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropShadowPickerWellButton * CreateDropShadowPickerButton(UINT nID,UINT nID2,
		UINT nStyle,BOOL bSame);

	// Create drop image picker button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Image Picker Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPDropBitmapPickerWellButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nID2---I D2, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nStyle---nStyle, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCols---nCols, Specifies A integer value.  
	//		nImageRes---Image Resource, Specifies A integer value.  
	//		bSame---User Same I D, Specifies A Boolean value.
	virtual CFOPDropBitmapPickerWellButton * CreateDropImagePickerButton(UINT nID,UINT nID2,
		UINT nStyle,int nCols,int nImageRes,BOOL bSame);

	// Create combobox button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Combo Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPComboToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		m_nStyle---m_nStyle, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual CFOPComboToolBarButton * CreateComboButton(UINT nID, int m_nStyle,
		const FOPComboBoxData &cbData);

	// Create font combobox button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font Face Combo Button, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPFontFaceComboBox ,or NULL if the call failed  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		m_nStyle---m_nStyle, Specifies A integer value.  
	//		&cbData---&cbData, Specifies a const FOPComboBoxData &cbData object(Value).
	virtual CFOPFontFaceComboBox * CreateFontFaceComboButton(UINT nID, int m_nStyle,
		const FOPComboBoxData &cbData);

public:

	// Create separator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Separator, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		pToolBar---Tool Bar, A pointer to the CFOPToolBar  or NULL if the call failed.
	virtual CFOPToolBarButton * CreateSeparator(CFOPToolBar * pToolBar = NULL);

	// Get count of buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	int DoOtherMehod2() const { return (int)m_arTempData.GetSize(); }

	// Get specify button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Object, Returns the specified value.
	//		Returns a pointer to the object CFOPToolBarButton ,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPToolBarButton * GetBtnObject(int nIndex) const;

	// Paint tile bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint Title, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void DoMethod4(CDC * pDC, CRect & rect);

	// Is config mode,convert the ID of the toolbar item to index of the toolbar.
	// nID -- id of the toolbar item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Command To Index, .
	//		Returns a int type value.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	int CommandToIndex(UINT nID) const;

	// Set gray disabled buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Gray Disabled Buttons, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		bGrayDisabledButtons---Gray Disabled Buttons, Specifies A Boolean value.
	void SetGrayDisabledButtons (BOOL bGrayDisabledButtons) { m_bTempValue2 = bGrayDisabledButtons; }

	// Get gray disable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Gray Disabled Buttons, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetGrayDisabledButtons () const { return m_bTempValue2; }


	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		pBtn---pBtn, A pointer to the CFOPToolBarButton  or NULL if the call failed.
	int DoTempMethodx2(CFOPToolBarButton * pBtn) const;

	// Get item id with a specify index.
	// nIndex -- index of the toolbar button item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item I D, Returns the specified value.
	//		Returns a UINT type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	UINT GetItemID(int nIndex) const;

	// Get current button index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Button, Returns the specified value.
	//		Returns a int type value.
	int GetCurBtn() const;

	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lphBmp---lphBmp, A pointer to the HBITMAP or NULL if the call failed.
	virtual int DoTempMethodx1(UINT nID, HBITMAP* lphBmp);
	
	// Load toolbar.
	// lpszResourceName -- resource name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Bar, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResourceName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL LoadToolBar(LPCTSTR lpszResourceName);

	// Load toolbar
	// nIDResource -- resource id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Bar, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL LoadToolBar(UINT nIDResource);

	// Allow change text labels.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Change Text Labels, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL AllowChangeTextLabels () const { return TRUE; }

	// Set tool bar info
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tool Bar Information, Sets a specify value to current class CFOPToolBar
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nImgWidth---Img Width, Specifies A integer value.  
	//		nImgHeight---Img Height, Specifies A integer value.
	virtual void SetToolBarInfo(int nImgWidth, int nImgHeight);
	
	// Ignore set text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ignore Set Text, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetIgnoreSetText () const { return m_bTempValue3; }

	// Ignore set text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ignore Set Text, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		bValue---bValue, Specifies A Boolean value.
	void SetIgnoreSetText (BOOL bValue)	{ m_bTempValue3 = bValue; }

	// Set buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Buttons, Sets a specify value to current class CFOPToolBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
	virtual BOOL SetButtons(const UINT * lpIDArray, int nIDCount);

	// Obtain the rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	void GetItemRect(int nIndex, LPRECT lpRect) const;

	// Send message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Message To Buttons, .
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pData---pData, A pointer to the void  or NULL if the call failed.  
	//		bPass---bPass, Specifies A Boolean value.
	void SendMessageToButtons(UINT nID, UINT nCode, void * pData, BOOL bPass = FALSE);
	
	// Size undockable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Undockable T B, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SizeUndockableTB();
	
	// Image manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Manager, Returns the specified value.
	//		Returns a pointer to the object CFOPItemImageManager ,or NULL if the call failed
	CFOPItemImageManager * GetImageManager() const { return m_pImageManager; }

	// Set image manager
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Manager, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		pMgr---pMgr, A pointer to the CFOPItemImageManager  or NULL if the call failed.
	void SetImageManager(CFOPItemImageManager * pMgr);

public:	

	// Button font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Font, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HFONT value (Object).
	virtual HFONT GetMenuFont() const;
	
protected:

	// Do paint.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void  DoPaint(CDC * pDC);

	// Delay show control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delay Show, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	virtual void  DelayShow(BOOL bShow);
	
	// Balance wrap.
	
	//-----------------------------------------------------------------------
	// Summary:
	virtual void  DoOtherMehod3(int nRow, FOPMyType * pWrap);

	// Parameters:
	//		rect---Specifies A CRect type value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	virtual void  DoMethod3(CRect & rect, BOOL bHorz);
	
public:

	// Draw borders.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Borders, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void DrawBorders(CDC * pDC, CRect & rect);

	// Remove all buttons
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Buttons, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllButtons();

	// Is cool look
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Cool Look, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCoolLook() const;

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTransparent() const;

	// Get image width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Item Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetImageItemWidth() const;

	// Obtain the image height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Item Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetImageItemHeight() const;

	// Get standard button width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetButtonWidth() const;

	// Obtain the button height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Button Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetButtonHeight() const;

	// Set separator width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get separator Width, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSepWidth() const;

	// Obtain the separator height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get separator Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSepHeight() const;
	
	// Lock toolbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Tool Bar, .
	// Parameters:
	//		bLock---bLock, Specifies A Boolean value.
	void LockToolBar(BOOL bLock);

	// Button draw helper data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Data, Returns the specified value.
	//		Returns A E-XD++ CFOPBtnDrawHelper & value (Object).
	CFOPBtnDrawHelper & GetDrawData();

	// Raise button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameters:
	//		bUpdate---bUpdate, Specifies A Boolean value.
	void DoOtherMehod4(BOOL bUpdate = TRUE);
	
	// Can wrap row.
	
	//-----------------------------------------------------------------------
	// Summary:
	BOOL DoOtherMehod5(int nRowToWrap, int nMaxSize, int nRows, FOPMyType * pWrap);


	//-----------------------------------------------------------------------
	// Summary:
	virtual int DoOtherMehod6(int nLength, FOPMyType * pWrap);

	// Calc size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Size, .
	//		Returns a CSize type value.  
	// Parameters:
	//		nRows---nRows, Specifies A integer value.  
	//		pWrap---pWrap, A pointer to the FOPMyType  or NULL if the call failed.
	CSize CalcSize(int nRows, FOPMyType * pWrap);

	// Size toolbar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Tool Bar, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual CSize SizeToolBar(int nLength, BOOL bVert);

	//-----------------------------------------------------------------------
	// Summary:
	void DoOtherMehod7(int nStart, int nEnd, int nRowHeight);

	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.  
	//		dwMode---dwMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual CSize CalcLayout(int nLength, DWORD dwMode);

	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Button, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void DoOtherMehod8(int nIndex);

	// Item from point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Item From Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		rect---Specifies A CRect type value.
	virtual int  ItemFromPoint(CPoint point, CRect & rect) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Update Button, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual void DoOtherMehod9(int nIndex);

	// Set mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mode, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		bVertDock---Vertical Dock, Specifies A Boolean value.
	void SetMode(BOOL bVertDock);

	// Get image list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image List, Returns the specified value.
	//		Returns a pointer to the object CImageList,or NULL if the call failed
	CImageList* GetImageList() const;

	// Get specify bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIDIdx---Id Button, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	int GetBitmap(UINT nIDIdx) const;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPToolBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fixed Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		bStretch---bStretch, Specifies A Boolean value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Dynamic Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.  
	//		dwMode---dwMode, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual CSize CalcDynamicLayout(int nLength, DWORD dwMode);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CFrameWnd  or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
	virtual void  OnUpdateCmdUI(CFrameWnd * pTarget, BOOL bDisableIfNoHndler);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Bar Style Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dwOldStyle---Old Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwNewStyle---New Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void  OnBarStyleChange(DWORD dwOldStyle, DWORD dwNewStyle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO  or NULL if the call failed.
	virtual INT_PTR   OnToolHitTest(CPoint point, TOOLINFO * pTI) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Full Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rectInside---rectInside, Specifies A CRect type value.
	virtual void GetFullRect(CRect & rectInside) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT & rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, UINT nID, DWORD dwStyle, DWORD dwExStyle, const RECT & rect, CWnd * pParentWnd = NULL, CCreateContext * pContext = NULL);	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPToolBar object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpszTitle---lpszTitle, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL Create(CWnd * pParentWnd, DWORD dwStyle = WS_VISIBLE | WS_CHILD | CBRS_TOP, UINT nID = AFX_IDW_TOOLBAR, LPCTSTR lpszTitle = NULL);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CFOPToolBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Position Changing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		lpWndPos---Window Position, Specifies a LPWINDOWPOS lpWndPos object(Value).
	afx_msg void OnWindowPosChanging(LPWINDOWPOS lpWndPos);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Show Window, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.  
	//		nStatus---nStatus, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCancelMode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Paint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnNcPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a int type value.  
	// Parameters:
	//		pDesktopWnd---Desktop Window, A pointer to the CWnd  or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg int  OnMouseActivate(CWnd * pDesktopWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On No Delay Hide, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnNoDelayHide(WPARAM nID, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size Parent, Called after the size of CWnd has changed.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnSizeParent(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Insert Buttons, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnInsertButtons(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Delete Button, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDeleteButton(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

public:
	// Value
	BOOL					m_bTempValue1;

	// Value
	BOOL					m_bTempValue2;

	// Value
	BOOL					m_bTempValue3; 

	// Value
	CFOPItemImageManager *	m_pImageManager;

	// Value
	int						m_nTempValue1;

	// Value
	int						m_nTempValue2; 

	// Value
	int						m_nTempValue3;

	// Value
	int						m_nTempValue4;

	// Value
	BOOL					m_bTempValue4; 

	// Value
	static BOOL				m_bTempValue5; 

	// Value
	CFOPBtnDrawHelper *		m_aDataValue1; 

	// Value
	BOOL					m_bTempValue6;  

	// Value
	BOOL					m_bTempValue7;

	// Value
	BOOL					m_bTempValue8;  

	// Value
	BOOL					m_bTempValue9; 

	// Value
	CSize					m_szTempValue1;  

	// Value
	CSize					m_szTempValue2;

	// Value
	CSize					m_szTempValue3;

	// Value
	DWORD					m_dwTBExStyle;

	// Value
	HFONT					m_hFont;

	// Value
	static BOOL				m_bLocked; 

	// Value
	int						m_nnTempValue1; 

	// Value
	int						m_nnTempValue2;

	// Value
	int						m_iDragIndex;

	// Value
	CRect					m_rectDrag;

	// Value
	CPen					m_penDrag;

	// Value
	CPoint					m_ptValue1;

	// Value
	BOOL					m_bIsDragCopy;

	// Value
	BOOL					m_bStretchButton;

	// Value
	CRect					m_rectTrack;

	// Value
	int						m_iImagesOffset;

	// Value
 	UINT					m_uiTemp1;

	// Value
	BOOL					m_bTracked; 

	// Value
	CPoint					m_ptLastPt;

	// Value
	BOOL					m_bMenuMode;

	// Value
	CWnd*					m_pWndTemp1;

	// Value
	HWND					m_hwndTemp1;

	// Value
	BOOL					m_bTempValue10;

	// Value
	BOOL					m_bTempValue11;

	// Value
	CRect					m_rcTempValue1;

	// Value
	CSize					m_szValue1;

	// Resource ID.
	UINT					m_nCurToolID;

	// Button array.
	CTypedPtrArray<CPtrArray,CFOPToolBarButton*> m_arTempData;

};

/////////////////////////////////////////////////////////////////////////////
AFX_INLINE CImageList* CFOPToolBar::GetImageList() const {
	ASSERT(::IsWindow(m_hWnd)); return CImageList::FromHandle((HIMAGELIST) ::SendMessage(m_hWnd, TB_GETIMAGELIST, 0, 0));
}

AFX_INLINE int CFOPToolBar::GetBitmap(UINT nIdButton) const {
	ASSERT(::IsWindow(m_hWnd)); return (int) ::SendMessage(m_hWnd, TB_GETBITMAP, nIdButton, 0L);
}

/////////////////////////////////////////////////////////////////////////////
// CFOPExtToolBar window

//===========================================================================
// Summary:
//     The CFOPExtToolBar class derived from CFOPControlBar
//      My Tool Box Bar
//===========================================================================

class FO_EXT_CLASS CFOPExtToolBar : public CFOPControlBar
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, None Description.
	//		Returns A  value.  
	// Parameters:
	//		CFOPExtToolBar---My Tool Box Bar, Specifies a CFOPExtToolBar object.
	DECLARE_DYNAMIC(CFOPExtToolBar);
	
	// Construction
	// Construction
public:
	// Load toolbar
	// nIDResource -- resource id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Bar, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL LoadToolBar(UINT nIDResource);

	BOOL AddToolBar(UINT nID, CString strTitle);
	//-----------------------------------------------------------------------
	// Summary:
	// My Tool Box Bar, Constructs a CFOPExtToolBar object.
	//		Returns A  value.
	CFOPExtToolBar();
	
	// Attributes
public:
	
	// m_wndTool, This member specify CMyToolBoxWnd object.  
	CFOPExtToolBarWnd m_wndTool;
public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtToolBar)
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Cmd U I, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pTarget---pTarget, A pointer to the CFrameWnd  or NULL if the call failed.  
	//		bDisableIfNoHndler---Disable If No Hndler, Specifies A Boolean value.
	virtual void  OnUpdateCmdUI(CFrameWnd * pTarget, BOOL bDisableIfNoHndler);
	
	//-----------------------------------------------------------------------
	// Summary:
	// C My Tool Box Bar, Destructor of class CFOPExtToolBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CFOPExtToolBar();
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtToolBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object.
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd( CDC* pDC );
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPTabBar

 
//===========================================================================
// Summary:
//     The CFOPTabBar class derived from CStatusBar
//      F O P Status Bar
//===========================================================================

class FO_EXT_CLASS CFOPTabBar : public CStatusBar
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Status Bar, Constructs a CFOPTabBar object.
	//		Returns A  value (Object).
	CFOPTabBar();

	// Change the indicators of the status bar
	// lpIDArray -- id array of the panes.
	// nIDCount -- the count of the IDs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Indicators, Sets a specify value to current class CFOPTabBar
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
    BOOL SetIndicators(const UINT* lpIDArray, int nIDCount);
	 

	void UpdatePanel();
	
	CFOPFlatComboBox *pComboBox;
protected:

	// style size box in corner
 
	// Size Box, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cxSizeBox;   
    
	// Double click on the panel
 
	// Pane Double Click, This member sets TRUE if it is right.  
	BOOL			m_bPaneDoubleClick;

	// Size of the box
 
	// Size Box, This member sets a CRect value.  
	CRect			m_rectSizeBox;

	// Image list.
	
	// List, This member is a collection of same-sized images.  
	CImageList		m_imgList;

	CRect rcHome;
	CRect rcPrev;
	CRect rcNext;
	CRect rcSub;
	CRect rcAdd;

	CRect rcState;

	BOOL bClickHome;
	BOOL bClickPrev;
	BOOL bClickNext;
	BOOL bClickSub;
	BOOL bClickAdd;

	CString strState;

protected:

	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL MethodTempx1() const { return FALSE; }

	// Obtain the panel width
	// nIndex -- index of the pane
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pane Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	int GetPaneWidth(int nIndex) const;

	// Change the width of the pane
	// nIndex -- indes of the pane.
	// cx -- new width of the pane
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pane Width, Sets a specify value to current class CFOPTabBar
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		cx---Specifies A integer value.
	void SetPaneWidth (int nIndex, int cx);

	// Draw the label of the status bar
	// pDC - Pointer of the dc.
	// rcPos - status bar pos.
	// strLabel -- label of the panel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Panel Label, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&strLabel---&strLabel, Specifies A CString type value.
	void DoDrawPanelLabel(CDC *pDC,const CRect &rcPos,const CString &strLabel);

	// Draw status bar
	// pDC - Pointer of the dc.
	// rcPos - status bar pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Bar, Do a event. 
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.
	void DoDrawBar(CDC* pDC, const CRect& rcPos);

protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Fixed Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		bStretch---bStretch, Specifies A Boolean value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	
	//{{AFX_MSG(CFOPTabBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnHome();
	afx_msg void OnPrev();
	afx_msg void OnNext();
	afx_msg void OnDel();
	afx_msg void OnAdd();
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Item, Called when a visual aspect of an owner-draw child button control, combo-box control, list-box control, or menu needs to be drawn.
	// Parameters:
	//		nIDCtl---I D Ctl, Specifies A integer value.  
	//		lpDrawItemStruct---Draw Item Struct, Specifies a LPDRAWITEMSTRUCT lpDrawItemStruct object(Value).
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPTOOLBAR_H__52844B29_68B5_435F_BC04_09CE6D5B6132__INCLUDED_)
