//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOListIterator.h: interface for the FOListIterator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOLISTITERATOR_H__0D05FF54_D1B7_11D6_A666_0050BAE30439__INCLUDED_)
#define AFX_FOLISTITERATOR_H__0D05FF54_D1B7_11D6_A666_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOTypedShapeObList.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOSmartHRes -- resource handle ID.
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//      To use a CFOSmartHRes object, just call the constructor.
//      F O Smart H Resource
//===========================================================================

class FO_EXT_CLASS CFOSmartHRes
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Set the global resource handle to hResource
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Smart H Resource, Constructs a CFOSmartHRes object.
	//		Returns A  value (Object).  
	// Parameters:
	//		hResource---hResource, Specifies a HMODULE hResource object(Value).
	CFOSmartHRes(HMODULE hResource);

	//-----------------------------------------------------------------------
	// Summary:
	// Restore the previous resource handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Smart H Resource, Destructor of class CFOSmartHRes
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOSmartHRes();

private:

	// Resource handle.
 
	// Old Resource, This member specify HMODULE object.  
	HMODULE	m_hOldResource;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOListIterator -- iterator class for list.
/////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
 
//===========================================================================
// Summary:
//      To use a FOListIterator object, just call the constructor.
//      O List Iterator
//===========================================================================

class FO_EXT_CLASS FOListIterator  
{
private:
	// Position of list.
 
	// Position, This member sets A value used to denote the position of an element in a collection; used by MFC collection classes.  
    POSITION                m_pPos;

	// Pointer of list.
 
	// List, This member maintains a pointer to the object CFOTypedShapeObList<TYPE>.  
    CFOTypedShapeObList<TYPE> *m_pList;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O List Iterator< T Y P E>, .
	//		Returns A  value (Object).
	FOListIterator<TYPE>() 
	{
		m_pPos = NULL;
		m_pList = NULL;
	};

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O List Iterator< T Y P E>, .
	//		Returns A  value (Object).  
	// Parameters:
	//		*pList---*pList, A pointer to the CFOTypedShapeObList<TYPE>  or NULL if the call failed.
	FOListIterator<TYPE>(
		// Pointer of list.
		CFOTypedShapeObList<TYPE> *pList
		) 
	{
		m_pPos = NULL;
		m_pList = NULL;
		Init(pList);
	};

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Iterator, Destructor of class FOListIterator
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOListIterator() 
	{
	};

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFOTypedShapeObList<TYPE>  or NULL if the call failed.
	// Init data from a specify list.
	virtual void Init(
		// Pointer of list.
		CFOTypedShapeObList<TYPE> *pList
		)
	{
		ASSERT(pList != NULL);
		if(pList == NULL)
		{
			TRACE0("pList -- Is empty!");
			return;
		}
		if (m_pList != pList) 
		{
			m_pList = pList;
			m_pPos = m_pList->GetHeadPosition();
		}
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Last, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Is current position the last position.
	virtual BOOL Last()
	{
		m_pPos = m_pList->GetTailPosition();
		return (m_pPos != NULL);
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// First, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		void---void
	// Is current position the first position.
	virtual BOOL First(void)
	{
		m_pPos = m_pList->GetHeadPosition();
		
		return (m_pPos != NULL);
	};

	// Change to specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class FOListIterator
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	void SetPosition(
		// Specify a new position.
		POSITION &pos
		)
	{
		m_pPos = pos;
	};

	// operator ++ 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOListIterator& value (Object).
	FOListIterator& operator++() 
	{
		GetNext();
		return (*this); 
	};

	// operator -- 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOListIterator& value (Object).
	FOListIterator& operator--()
	{
		GetPrev();
		return (*this); 
	};


	// Get current position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		void---void
	POSITION GetPosition(void)
	{
		return m_pPos;
	};

	// Return the first elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetFirst()
	{
		First();
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
			m_pList->GetNext(m_pPos);
		}
		return pReturn;
	};

	// Return the next elem.
	_FOLIB_INLINE TYPE GetNext()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetNext(m_pPos);
		}
		return NULL;
	};

	// Return the previous elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetPrev()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetPrev(m_pPos);
		}
		return NULL;
	};

	// Get the last elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetLast()
	{
		Last();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A TYPE value (Object).
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
			m_pList->GetPrev(m_pPos);
		}
		return pReturn;
	};
	
	// Get current elem.
	virtual TYPE GetAt()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	// Remove current elem.
	virtual void Remove()
	{
		if(m_pPos != NULL)
		{
			m_pList->RemoveAt(m_pPos);
		}
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A TYPE& value (Object).
	// operator *
	TYPE& operator*()
	{
		return GetAt();
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y P E, .
	//		Returns A operator value (Object).
	// operator TYPE
	operator TYPE ()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOBasicListIterator -- basic list iterator.
/////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
 
//===========================================================================
// Summary:
//      To use a FOBasicListIterator object, just call the constructor.
//      O Basic List Iterator
//===========================================================================

class FO_EXT_CLASS FOBasicListIterator  
{
private:
	// Position of list.
 
	// Position, This member sets A value used to denote the position of an element in a collection; used by MFC collection classes.  
    POSITION                m_pPos;

	// Pointer of list.
    CTypedPtrList<CObList, TYPE> *m_pList;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Basic List Iterator< T Y P E>, .
	//		Returns A  value (Object).
	FOBasicListIterator<TYPE>() 
	{
		m_pPos = NULL;
		m_pList = NULL;
	};

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Basic List Iterator< T Y P E>, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CTypedPtrList<CObList---Typed Pointer List< C Ob List, Specifies a CTypedPtrList<CObList object(Value).  
	//		*pList---*pList, A pointer to the TYPE>  or NULL if the call failed.
	FOBasicListIterator<TYPE>(
		// Pointer of list.
		CTypedPtrList<CObList, TYPE> *pList
		) 
	{
		m_pPos = NULL;
		Init(pList);
	};

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Basic List Iterator, Destructor of class FOBasicListIterator
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOBasicListIterator() 
	{
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CTypedPtrList<CObList---Typed Pointer List< C Ob List, Specifies a CTypedPtrList<CObList object(Value).  
	//		*pList---*pList, A pointer to the TYPE>  or NULL if the call failed.
	// Init data from a specify list.
	virtual void Init(
		// Pointer of list.
		CTypedPtrList<CObList, TYPE> *pList
		)
	{
		ASSERT(pList != NULL);
		if(pList == NULL)
		{
			TRACE0("pList -- Is empty!");
			return;
		}
		if (m_pList != pList) 
		{
			m_pList = pList;
			m_pPos = m_pList->GetHeadPosition();
		}
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Last, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Is current position the last position.
	virtual BOOL Last()
	{
		m_pPos = m_pList->GetTailPosition();
		return (m_pPos != NULL);
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// First, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		void---void
	// Is current position the first position.
	virtual BOOL First(void)
	{
		m_pPos = m_pList->GetHeadPosition();
		
		return (m_pPos != NULL);
	};

	// Change to specify position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class FOBasicListIterator
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	void SetPosition(
		// Specify a new position.
		POSITION &pos
		)
	{
		m_pPos = pos;
	};

	// operator ++ 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOBasicListIterator& value (Object).
	FOBasicListIterator& operator++() 
	{
		GetNext();
		return (*this); 
	};

	// operator -- 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOBasicListIterator& value (Object).
	FOBasicListIterator& operator--()
	{
		GetPrev();
		return (*this); 
	};

	// Get current position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.  
	// Parameters:
	//		void---void
	POSITION GetPosition(void)
	{
		return m_pPos;
	};

	// Return the first elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetFirst()
	{
		First();
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
			m_pList->GetNext(m_pPos);
		}
		return pReturn;
	};

	// Return the next elem.
	_FOLIB_INLINE TYPE GetNext()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetNext(m_pPos);
		}
		return NULL;
	};

	// Return the previous elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetPrev()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetPrev(m_pPos);
		}
		return NULL;
	};

	// Get the last elem.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last, Returns the specified value.
	//		Returns A _FOLIB_INLINE TYPE value (Object).
	_FOLIB_INLINE TYPE GetLast()
	{
		Last();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A TYPE value (Object).
		TYPE pReturn = GetAt();
		if(m_pPos != NULL)
		{
			m_pList->GetPrev(m_pPos);
		}
		return pReturn;
	};
	
	// Get current elem.
	virtual TYPE GetAt()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	// Remove current elem.
	virtual void Remove()
	{
		if(m_pPos != NULL)
		{
			m_pList->RemoveAt(m_pPos);
		}
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A TYPE& value (Object).
	// operator *
	TYPE& operator*()
	{
		return GetAt();
	};
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Y P E, .
	//		Returns A operator value (Object).
	// operator TYPE
	operator TYPE ()
	{
		if(m_pPos != NULL)
		{
			return m_pList->GetAt(m_pPos);
		}
		return NULL;
	};

};

#endif // !defined(AFX_FOLISTITERATOR_H__0D05FF54_D1B7_11D6_A666_0050BAE30439__INCLUDED_)
