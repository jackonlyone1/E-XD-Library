//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FONAVPANEWND_H__20F461E1_2275_4820_8E65_A6310A626369__INCLUDED_)
#define AFX_FONAVPANEWND_H__20F461E1_2275_4820_8E65_A6310A626369__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FONavPaneWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFONavPaneWnd window

#include "FOMultiPageModel.h"
#include "FOMultiPageModelManager.h"
#include "FOPreviewBitmap.h"
#include "FOPMenuWndImpl.h"

#define NAVPANEWND_CLASSNAME	_T("Nav Pane Wnd")

// include head file of a bass object

 
//===========================================================================
// Summary:
//     The CFONavPaneWnd class derived from CWnd
//      F O Nav Pane Window
//===========================================================================

class FO_EXT_CLASS CFONavPaneWnd : public CWnd, public CFOObserver
{
// Construction
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Nav Pane Window, Constructs a CFONavPaneWnd object.
	//		Returns A  value (Object).
	CFONavPaneWnd();

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Nav Pane Window, Destructor of class CFONavPaneWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFONavPaneWnd();
// Attributes

protected:

	//Current Data Model
 
	// Current Data Manager, This member maintains a pointer to the object CFOMultiPageModelManager.  
	CFOMultiPageModelManager *m_pCurDataManager;

public:

	// You must call this function in OnInitialUpdate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Page Manager, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelManager ,or NULL if the call failed
	CFOMultiPageModelManager *GetMultiPageManager() const;

	// Set Multi_Model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Page Manager, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOMultiPageModelManager  or NULL if the call failed.
	void SetMultiPageManager(CFOMultiPageModelManager *pModel);

	// Is page manager validate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Page Manager Validate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsPageManagerValidate() const;

	// Update data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( CObject * pModel,LPARAM lHint, CObject*pHint);
	
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();

	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, const RECT& rect,
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyleEx---Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, DWORD dwStyleEx, const RECT& rect, 
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
		DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	// Create extend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		hWndParent---Window Parent, Specifies a HWND hWndParent object(Value).  
	//		nIDorHMenu---I Dor H Menu, Specifies a HMENU nIDorHMenu object(Value).  
	//		lpParam---lpParam, Specifies a LPVOID lpParam = NULL object(Value).
	virtual BOOL CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
		                   int x, int y, int cx, int cy, HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

	// Creation new window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Page , Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL AttachPageCtrl( UINT uID, CWnd* pParentWnd );

public:
	// Attributes

	// Pre translate message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

public:

	// Get Model List
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model List, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelSet ,or NULL if the call failed
	CFOMultiPageModelSet *GetModelList()					{ return &m_ModelList; }

	// add a new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed
	virtual CFOMultiPageModel* AddNewItem();

	// Remove an item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveItem();

	// Remove an item.
	// pItem -- a pointer to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	virtual void RemoveItem(CFOMultiPageModel *pItem);

	// Find an item with type.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	CFOMultiPageModel *FindItem(int nType);

	// get item counts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Count, Returns the specified value.
	//		Returns a int type value.
	int GetItemCount();

	// clear all items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearAll();

	// set item size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		nx---Specifies A integer value.  
	//		ny---Specifies A integer value.
	void SetItemSize(int nx,int ny);
	
	// update controls
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void UpdateControl(BOOL bMoveScroll = FALSE);

	// Add page to cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Cache, Adds an object to the specify list.
	// Parameters:
	//		pPage---pPage, A pointer to the CFOMultiPageModel or NULL if the call failed.  
	//		rBitmap---rBitmap, Specifies a E-XD++ CFOBitmap& rBitmap object (Value).
	void		  AddToCache( CFOMultiPageModel* pPage, CFOBitmap& rBitmap);

	// Obtain current cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Cache, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOMultiPageModel or NULL if the call failed.
	CFOBitmap*    GetFromCache( CFOMultiPageModel* pPage) const;

	// Select page
	// nNumber -- page number,this is the same with GetPageItemNumber
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Page, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		&nNumber---&nNumber, Specifies A integer value.
	virtual CFOMultiPageModel *SelectedPage(const int &nNumber);

	// Do something when click on the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click On Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOMultiPageModel or NULL if the call failed.
	virtual void DoClickOnItem(CFOMultiPageModel* pPage);

protected:

	// Get scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Pos32, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		bGetTrackPos---Get Track Position, Specifies A Boolean value.
	int GetScrollPos32(int nBar, BOOL bGetTrackPos = FALSE );
	
	// Set scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Pos32, Sets a specify value to current class CFONavPaneWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		nPos---nPos, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetScrollPos32( int nBar, int nPos, BOOL bRedraw = TRUE );

public:
	
	// Obtain background color 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetBkColor() const							{ return m_crBackColor; }

	// Change the background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetBkColor(const COLORREF crColor)			{ m_crBackColor = crColor; }
	
	// Obtain the item size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetItemSize() const							{ return CSize(nItemCX,nItemCY); }

	// Change the item size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		szItem---szItem, Specifies A CSize type value.
	void			SetItemSize(CSize szItem)					{ nItemCX = szItem.cx,nItemCY = szItem.cy; }
	
	// Obtain the item space
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Space, Returns the specified value.
	//		Returns a int type value.
	int				GetItemSpace() const						{ return nItemSpace; }

	// Change the item space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Space, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		nSpace---nSpace, Specifies A integer value.
	void			SetItemSpace(const int nSpace)				{ nItemSpace = nSpace; }

	// Obtain the font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString			GetFaceName() const;

	// Change the font face name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void			SetFaceName(LPCTSTR lpszFaceName);
	
	// Obtain the size of font points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int				GetPointSize() const;

	// Change the point size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void			SetPointSize(const int nPointSize, CDC* pDC = NULL);
	
	// Obtain the font height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int				GetHeight() const;

	// Change the font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		nHeight---nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void			SetHeight(const int nHeight, CDC* pDC = NULL);
	
	// Obtain the font color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetTextColor() const;

	// Change the font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetFontColor(const COLORREF crColor);
	
	// Obtain the font weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int				GetWeight() const;

	// Change the weight of the font.
	// nWeight -- weight of the font,700 is Bold.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		nWeight---nWeight, Specifies A integer value.
	void			SetWeight(const int nWeight);
	
	// Obtain the italic style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetItalic() const;

	// Change the italic style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		bItalic---bItalic, Specifies A Boolean value.
	void			SetItalic(const BOOL bItalic);
	
	// Obtain the underline style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetUnderline() const;

	// Change the underline style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		bUnderline---bUnderline, Specifies A Boolean value.
	void			SetUnderline(const BOOL bUnderline);
	
	// Obtain the strike out style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetStrikeout() const;

	// Change the strike out style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFONavPaneWnd
	// Parameters:
	//		bStrikeout---bStrikeout, Specifies A Boolean value.
	void			SetStrikeout(const BOOL bStrikeout);

	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont*	CreateFont(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*			GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void			ReleaseFontObject();

protected:
	
	// change to logical axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int				GetLogPoint(const int nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);
	
	// change from logic axis to point axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nLog---nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int				GetPointFromLog(const int nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Make sure item visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ensure Visible, .
	// Parameters:
	//		pItem---pItem, A pointer to the CFOMultiPageModel or NULL if the call failed.
	void			EnsureVisible (CFOMultiPageModel* pItem);

protected:
	
	// create context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();
	
	// get start position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Position, Returns the specified value.
	// Parameters:
	//		&nStart---&nStart, Specifies A integer value.
	void			GetStartPos(int &nStart);
	
	// Update current scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void	UpdateScrollBar(BOOL bMoveScroll = FALSE);
	
	// get size of font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetFontSize();
	
	// draw an item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Items, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void	DrawItems(CDC *pDC,const CRect &rcView);
	
	// calculate item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Item Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcItemPosition();

	// Scroll to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOMultiPageModel or NULL if the call failed.  
	//		bUp---bUp, Specifies A Boolean value.
	virtual void ScrollItem(CFOMultiPageModel* pItem,BOOL bUp);

	// Create memory dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Temp D C, You construct a CFONavPaneWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&pMemoryDC---Memory D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	virtual BOOL CreateTempDC( CDC* pDC, CDC* &pMemoryDC, const CRect& rcPaint) const;

	// Do paint.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoPaint(CDC* pDC);

public:

	// HitTest
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hited, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOMultiPageModel *Hited(
		// Mouse hit point
		CPoint pt
		);

	// Hit test.
	// pt -- a specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOMultiPageModel *HitTest(CPoint pt);

	// Select item.
	// pt -- a specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Item, Call this function to select the given item.
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOMultiPageModel *SelectedItem(CPoint pt);

	// Get selected item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed
	CFOMultiPageModel *GetSelected();
	
protected:

	// Convert rect from doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		rect---Specifies A CRect type value.
	void DocToClient(CRect& rect);

	// Doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		point---Specifies A CPoint type value.
	void DocToClient(CPoint& point);

	// Client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void ClientToDoc(CPoint& point);

	// Client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void ClientToDoc(CRect& rect);

	// Invalidate rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rc---Specifies A CRect type value.
	void InvalRect(CRect rc);

	// Update all pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Pages, Call this member function to update the object.

	void UpdateAllPages();

	// Get nearest page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Page, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		rPos---rPos, Specifies A integer value.
	CFOMultiPageModel* GetNearestPage( const FOPPoint& rPos ) const;

// Operations
public:

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);   
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFONavPaneWnd)
	public:

		// prepare device context
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:

		// update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);

	// activate view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActivateView---Activate View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
protected:

#ifdef _DEBUG

	// performs a valid check
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// dumps the contents of your object
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFONavPaneWnd)
	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	// when left mouse button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	// when left mouse button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	// when double click on left button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);

	// message WM_SIZE
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);

	// when erasing background
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	// when right button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

	// context menu displaying
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

	// when right mouse button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	// when painting
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	// Key down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Add Newpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnAddNewpage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Add Newpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateAddNewpage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnRemovePage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRemovePage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Page Caption, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPageCaption();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Page Caption, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdatePageCaption(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
	
protected:

 
	// Model List, This member specify E-XD++ CFOMultiPageModelSet object.  
	CFOMultiPageModelSet	m_ModelList;

	// size of section
 
	// Section, This member sets a CSize value.  
	CSize					m_sizSection;	
	
	// sections number per row
 
	// Sections Per Row, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT					m_uSectionsPerRow;	

	// caption of items
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					strCaption;	

	// menu of context
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*					m_pContextMenu;		

	// width of scroll
 
	// Scroll Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_ScrollWidth;		

	// flag of modified
 
	// Modified, This member sets TRUE if it is right.  
	BOOL					bModified;			

	// item -cx
 
	// Item C X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCX;		
	
	// item -cy
 
	// Item C Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCY;			

	// item space
 
	// Item Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemSpace;			

	// current file
 
	// Current File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					strCurrentFile;		

	// background color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crBackColor;		

protected:
	
	// notify window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*					pNotifyWnd;			

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strFaceName;		
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL					m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL					m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL					m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*					m_pFont;

	// Images area
 
	// List, This member sets a CRect value.  
	CRect					m_rectList;	
	
	// Bitmap cache
 
	// Cache, This member maintains a pointer to the object CFOPBitmapCache.  
	CFOPBitmapCache*		pCache;

	// Control has focus
 
	// Focused, This member sets TRUE if it is right.  
	BOOL					m_bFocused;				

};

/////////////////////////////////////////////////////////////////////////////
_FOLIB_INLINE CString CFONavPaneWnd::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFONavPaneWnd::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFONavPaneWnd::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFONavPaneWnd::GetTextColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFONavPaneWnd::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFONavPaneWnd::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFONavPaneWnd::SetItalic(const BOOL bItalic)
{
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFONavPaneWnd::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFONavPaneWnd::SetUnderline(const BOOL bUnderline)
{
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFONavPaneWnd::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFONavPaneWnd::SetStrikeout(const BOOL bStrikeout)
{
	m_bStrikeout = bStrikeout;
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FONAVPANEWND_H__20F461E1_2275_4820_8E65_A6310A626369__INCLUDED_)
