//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCANVASSHELL_H__FFDE5A9E_D592_439C_8830_2A7C7D28FE5E__INCLUDED_)
#define AFX_FOPCANVASSHELL_H__FFDE5A9E_D592_439C_8830_2A7C7D28FE5E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPCanvasShell.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPCanvasShell -- canvas shell action.

#include "FOPMsgShell.h"

class CFOPCanvasCore;
class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOPCanvasShell class derived from CFOPMsgShell
//      F O P Canvas Shell
//===========================================================================

class FO_EXT_CLASS CFOPCanvasShell : public CFOPMsgShell
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Canvas Shell, Constructs a CFOPCanvasShell object.
	//		Returns A  value (Object).
	CFOPCanvasShell();

// Attributes
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPCanvasShell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		pCore---pCore, A pointer to the CFOPCanvasCore or NULL if the call failed.
	// Create shell.
	// pModel -- pointer of the model.
	// pCore -- pointer of the core object.
	virtual BOOL Create(CFODataModel *pModel,CFOPCanvasCore* pCore);

	// pointer of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Core, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasCore,or NULL if the call failed
	CFOPCanvasCore* GetCore() const;

	// Obtain the pointer of the data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	CFODataModel *GetCurrentModel();

protected:

	// Pointer of the view
 
	// Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore* m_pCore;

	// pointer of the model.
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *	m_pModel;

// Operations
public:

// Overrides
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SECWndPlugIn)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnWndMsg( UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO or NULL if the call failed.
	virtual BOOL OnCmdMsg( UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo );
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Canvas Shell, Destructor of class CFOPCanvasShell
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPCanvasShell();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPCanvasShell)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCANVASSHELL_H__FFDE5A9E_D592_439C_8830_2A7C7D28FE5E__INCLUDED_)
