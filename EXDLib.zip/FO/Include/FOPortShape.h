//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPORTSHAPE_H__A70F8081_C9B4_11D5_A48D_525400EA266C__INCLUDED_)
#define AFC_FOPORTSHAPE_H__A70F8081_C9B4_11D5_A48D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FODrawShape.h"

enum FOPPortSides 
{
	PSNone=1, 
    PSTop, 
    PSRight, 
    PSBottom, 
    PSLeft, 
    FOP_PortSides_Last
};

enum FOPPortCenterAtSide
{
	PortCenter = 1,
	PortTop,
	PortRight,
	PortBottom,
	PortLeft
};

////////////////////////////////////////////////////////////////////
// CFOPortShape -- port shape, each port shape contains a list of pointer to link shape
//                 Call GetParentComp can find which shape owns this port.
//                 ID: FO_COMP_PORT 90

class CFOLinkShape;
class CFOPinShape;

 
//===========================================================================
// Summary:
//     The CFOPortShape class derived from CFODrawShape
//      F O Port Shape
//===========================================================================

class FO_EXT_CLASS CFOPortShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPortShape---F O Port Shape, Specifies a E-XD++ CFOPortShape object (Value).
	DECLARE_SERIAL(CFOPortShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Port Shape, Constructs a CFOPortShape object.
	//		Returns A  value (Object).
	CFOPortShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Port Shape, Constructs a CFOPortShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPortShape& src object(Value).
	CFOPortShape(const CFOPortShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Port Shape, Destructor of class CFOPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPortShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPortShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPortShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		*pParent---*pParent, A pointer to the CFODrawShape  or NULL if the call failed.
	// Creates the port shape from a CRect object.
	// point -- port point.
	// pParent -- parent shape pointer.
	virtual void Create(CPoint point,CFODrawShape *pParent);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

public:
	
	// Get the parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Parent Component, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetParentComp()			  { return m_pParentComp; }

	// Set new parent shape.
	// pParent -- pointer of parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Component, Sets a specify value to current class CFOPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetParentComp(CFODrawShape *pParent) { m_pParentComp = pParent; }

	// Obtain port at side.
	int PortAtSide();

	// Obtain the pointer of pin shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pin Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPinShape ,or NULL if the call failed
	virtual CFOPinShape *GetPinShape();

	// Get the link port point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLinkPoint() const;

	// Get real point of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Center, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetPortCenter();

	// Break all links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Break All Links, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BreakAllLinks();

	// Set the link point.
	// ptPort -- new port point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link Point, Sets a specify value to current class CFOPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptPort---ptPort, Specifies A CPoint type value.
	virtual void SetLinkPoint(const CPoint& ptPort, const BOOL &bMoveLink = TRUE);

	// Re position link point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reposition Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void RepositionPoint(const CRect &rc);

	// Re position link point, it is only defined for tracking mode only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reposition Track Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void RepositionTrackPoint(const CRect &rc);

	// Get the link tracking point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Track Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLinkTrackPoint() const;

	// Obtain the direction of this port.
	virtual BYTE GetDirection(BYTE n);

	int GetDirMode(CPoint ptCheck);

	// Obtain the direction.
	virtual BYTE GetNewDirection(CPoint pt);

	// Get to bounding rectangle's distance.
	virtual double  GetToBoundDistance(int direction);

	// Obtain the from link point
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Link Track Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual CPoint GetFromLinkTrackPoint(CFOLinkShape *pLink);
	
	// Obtain the to link point
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Link Track Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual CPoint GetToLinkTrackPoint(CFOLinkShape *pLink);

	// Set the link point.
	// ptPort -- new port track point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link Track Point, Sets a specify value to current class CFOPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptPort---ptPort, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void SetLinkTrackPoint(const CPoint& ptPort,CPoint ptScroll);

	// Get the point of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the point of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPointSpotLocation(CFOPHandleList& lstHandle);

	// Hit test.
	// point -- point for hit testing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&point---Specifies A CPoint type value.
	virtual BOOL HitTest(const CPoint &point);
	
	// Hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		nExpand---nExpand, Specifies A integer value.
	virtual BOOL HitTest(const CPoint& point, int nExpand);

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Get position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	// Get position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPortRect();

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Build unique port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Unique Port Name, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildUniquePortName();

	// Obtain the ortho point
	// pt -- ortho point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ortho To Point, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CPoint GetOrthoToPoint(CPoint& pt);

	// returns the "From" side
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center At Side, Returns the specified value.
	//		Returns A FOPPortCenterAtSide value (Object).
	FOPPortCenterAtSide GetCenterAtSide() const;
   
	// sets the "From" side
	// nNewSide -- new side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Center At Side, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		&nNewSide---New Side, Specifies a const FOPPortCenterAtSide &nNewSide object(Value).
    void SetPortSide(const FOPPortCenterAtSide &nNewSide);
    
	// sets the "From" side
	// nNewSide -- new side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Center At Side, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		&nNewSide---New Side, Specifies a const FOPPortCenterAtSide &nNewSide object(Value).
    void SetCenterAtSide(const FOPPortCenterAtSide &nNewSide);
    
	// Obtain the nearest link point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Point From Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		ptNext---ptNext, Specifies A CPoint type value.
	virtual CPoint GetLinkPointFromPoint(CPoint ptNext);

	// Obtain the from link point
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Link Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual CPoint GetFromLinkPoint(CFOLinkShape *pLink);

	// Obtain the to link point
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Link Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual CPoint GetToLinkPoint(CFOLinkShape *pLink);

	// Obtain the from link direction
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Link Directory, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a float value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual float GetFromLinkDir(CFOLinkShape *pLink);

	// Obtain the to link direction
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Link Directory, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a float value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual float GetToLinkDir(CFOLinkShape *pLink);

	
	// Get port bound parent.
	virtual CFODrawShape *GetPortBoundParent(CFOPortShape *pPort);

	// Obtain link direction
	// nSide -- side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Directory, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nSide---nSide, Specifies A integer value.
	virtual int GetLinkDir(int nSide);

	// Is two port within the same shape
	// firstPort -- first port pointer.
	// secondPort -- second port pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is In Same Node, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*firstPort---*firstPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*secondPort---*secondPort, A pointer to the CFOPortShape  or NULL if the call failed.
	BOOL IsInSameNode(CFOPortShape *firstPort, CFOPortShape *secondPort);

	// Is two port within the same shape
	// pConsider -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is In Same Node, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pConsider---*pConsider, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL IsInSameNode(CFOPortShape *pConsider);

	// Is two port linked.
	// firstPort -- first port pointer.
	// secondPort -- second port pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Linked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*firstPort---*firstPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*secondPort---*secondPort, A pointer to the CFOPortShape  or NULL if the call failed.
	BOOL IsLinked(CFOPortShape *firstPort, CFOPortShape *secondPort);

	// Is linked with port
	// port -- pointer of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Linked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*port---A pointer to the CFOPortShape  or NULL if the call failed.
	BOOL IsLinked(CFOPortShape *port);

	// Obtain the link shape between two ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Linked Link Shape, Returns the specified value.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.
	CFOLinkShape *GetLinkedLinkShape(CFOPortShape *pFrom);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Obtain all lay on links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Lay On Links, Returns the specified value.
	// Parameters:
	//		&m_links---Specifies a E-XD++ CFODrawShapeList &m_links object (Value).  
	//		*pFromOld---From Old, A pointer to the CFOPortShape  or NULL if the call failed.
	void GetAllLayOnLinks(CFODrawShapeList &m_links, CFOPortShape *pFromOld);

	// Obtain all lay on links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All From Lay On Links, Returns the specified value.
	// Parameters:
	//		*pCurLink---Current Link, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		&m_links---Specifies a E-XD++ CFODrawShapeList &m_links object (Value).  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	void GetAllFromLayOnLinks(CFOLinkShape *pCurLink, CFODrawShapeList &m_links, CFOPortShape *pTo);

	// Obtain all lay on links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All To Lay On Links, Returns the specified value.
	// Parameters:
	//		*pCurLink---Current Link, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		&m_links---Specifies a E-XD++ CFODrawShapeList &m_links object (Value).  
	//		*pFromOld---From Old, A pointer to the CFOPortShape  or NULL if the call failed.
	void GetAllToLayOnLinks(CFOLinkShape *pCurLink, CFODrawShapeList &m_links, CFOPortShape *pFromOld);


	// generate port area.
	virtual void GenPortArea(CFOArea *pArea);

public:
	/*************************************************************************
	|*
	|* Port properties,these properties only used by class CFOPortShape.
	|*
	\************************************************************************/

	// Get port width,default is 8
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Width, Returns the specified value.
	//		Returns a int type value.
	int GetPortWidth() const;     

	// Get port height,default is 8
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Height, Returns the specified value.
	//		Returns a int type value.
    int GetPortHeight() const;

	// Change port width,it must be > 0 value.
	// nWidth -- width of the port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Port Width, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	void SetPortWidth(const int& nWidth);

	// Change the port height,it must be > 0 value.
	// nHeight -- height of the port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Port Height, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		nHeight---nHeight, Specifies A integer value.
	void SetPortHeight(const int& nHeight);

	// Port shape type,returns one of the following value:
	// enum FO_PORT_TYPE
	// {
	// 	FO_PORT_RECT = 0,
	// 	FO_PORT_ELLIPSE,
	// 	FO_PORT_DIAMOND,
	// 	FO_PORT_TRIANGLE,
	// 	FO_PORT_INVERT_TRIANGLE,
	// 	FO_PORT_CROSSLINE,
	// 	FO_PORT_CROSSLINENEW,
	// 	FO_PORT_CUSTOM
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Type, Returns the specified value.
	//		Returns a int type value.
	int GetPortType() const;

	// Change Port shape type,
	// nType -- it must be one of the following value:
	// enum FO_PORT_TYPE
	// {
	// 	FO_PORT_RECT = 0,
	// 	FO_PORT_ELLIPSE,
	// 	FO_PORT_DIAMOND,
	// 	FO_PORT_TRIANGLE,
	// 	FO_PORT_INVERT_TRIANGLE,
	// 	FO_PORT_CROSSLINE,
	// 	FO_PORT_CROSSLINENEW,
	// 	FO_PORT_CUSTOM
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Port Type, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void SetPortType(const int& nType);

	// Get port width,default is 0, 0 -- in and out, 1--in, 2-- out
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Connect Type, Returns the specified value.
	//		Returns a int type value.
	int GetPortConnectType() const;     
	
	// Change port connect type,it must be >= 0 value. 0 -- in and out, 1--in, 2-- out
	// nType --connect type of the port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Port Connect Type, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		nType---nType, Specifies A integer value.
	void SetPortConnectType(const int& nType);

	virtual CPoint PickNearest(const CPoint &dc);


	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Initial Property Value, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL DoGetInitPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		) const;
	
public:

	// Number links between two ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Number Links Between, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		*a---A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*b---A pointer to the CFOPortShape  or NULL if the call failed.
	virtual int NumLinksBetween(CFOPortShape *a, CFOPortShape *b);

	// add to list 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Links List, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList ,or NULL if the call failed
	CFODrawShapeList *GetLinksList() { return &m_LinkList; }

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Update Component, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  ExtUpdateComp();
	
	// Obtain the lay on link list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lay Links, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList ,or NULL if the call failed
	CFODrawShapeList *GetLayLinks() { return &m_LayLinkList; }

	// Get the child shape count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetLinkCount()	{ return m_LinkList.GetCount(); }

	// add a link shape to the list
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Link Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void AddLinkShape(CFOLinkShape *pLink);

	// add or remove lay on link shape
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Lay Link Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void AddLayLinkShape(CFOLinkShape *pLink);

	// Add destination link
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Destination Link, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void AddDestinationLink(CFOLinkShape *pLink);

	// Add source link
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Source Link, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void AddSourceLink(CFOLinkShape *pLink);

	// Remove a link shape
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Link Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void RemoveLinkShape(CFOLinkShape *pLink);

	// Remove lay on link shape
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Lay Link Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void RemoveLayLinkShape(CFOLinkShape *pLink);

	// Is a link shape that is contained within the link list
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Link, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	BOOL ContainsLink(CFOLinkShape *pLink);

	// Remove all link shapes from this port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Link Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllLinkShapes();

	// Get all link shapes that link with this port.
	// list -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual int GetLinkShapes(CFODrawShapeList &list);

	// Get shapes that link to this port.
	// list -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link To This Port Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual int GetLinkToThisPortShapes(CFODrawShapeList &list);

	// Get shapes that link from this port
	// list -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link From This Port Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual int GetLinkFromThisPortShapes(CFODrawShapeList &list);

	// Get all links from this port.
	// list -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All From Links, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual int GetAllFromLinks(CFODrawShapeList &list);

	// Get all links to this port.
	// list -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All To Links, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual int GetAllToLinks(CFODrawShapeList &list);

	// Gen port rectangle with the port center side.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Port Rectangle, .
	//		Returns a CRect type value.  
	// Parameters:
	//		&ptConsider---&ptConsider, Specifies A CPoint type value.
	CRect GenPortRect(const CPoint &ptConsider) const;

public:
	/*************************************************************************
	|*
	|* Defined for layout only.
	|*
	\************************************************************************/
	// Gets a list over all of the links going out of this port.
	// LinksOut
	// listLinks -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destination Links, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	void DestinationLinks(CFODrawShapeList &listLinks) { GetAllFromLinks(listLinks); }

	// Gets a list over all of the links coming into this port.
	// LinksIn
	// listLinks -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Source Links, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	void SourceLinks(CFODrawShapeList &listLinks) { GetAllToLinks(listLinks); }
	
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	
	// Node that contains this port.
	//-----------------------------------------------------------------------
	// Summary:
	// Node, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	// The node that this port is part of.
	CFODrawShape *Node() { return GetParentComp(); }

	// Destination links count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destination Links Count, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int DestinationLinksCount();

	// Source links count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Source Links Count, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int SourceLinksCount();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPortShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPortShape& src object(Value).
	CFOPortShape& operator=(const CFOPortShape& src);

	// Generate svg code.
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	// Is input port.
	BOOL IsInput();

	// Set input port mode.
	void SetInputMode();

	// Is output port.
	BOOL IsOutput();

	// Set output mode
	void SetOutputMode();

	// Is input and output port
	BOOL IsInOut();

	// Set input and output mode.
	void SetInOutMode();

	// Is already linked or not.
	BOOL IsAlreadyLinked();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSimpleValue(const double &nValue);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);


	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	virtual CFODrawShape *FindByID(const int &nID);

	
	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dY, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Get X Scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Scale, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetXScale() const { return dXScale; }

	// Draws the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Get Y Scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Y Scale, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetYScale() const { return dYScale; }

	// Set x and y scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scale, Sets a specify value to current class CFOPortShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies a double x object(Value).  
	//		y---Specifies a double y object(Value).
	virtual void SetScale(double x, double y);

	// Is center port or not, if one node has many ports, call this method to check if it is center port or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Center Port, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCenterPort();

	// Is make sure center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Make Sure Center, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMakeSureCenter() const { return m_bMakeSureCenter; }

	// Set make sure center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Make Sure Center, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		&bCenter---&bCenter, Specifies A Boolean value.
	void SetMakeSureCenter(const BOOL &bCenter) { m_bMakeSureCenter = bCenter; }

	// Change port index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Port Index, Sets a specify value to current class CFOPortShape
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetPortIndex(const int &nIndex) { m_nPortIndex = nIndex; }

	// Obtain port index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Index, Returns the specified value.
	//		Returns a int type value.
	int GetPortIndex() const { return m_nPortIndex; }

	// If the count of links is much more than the maximize links that allowed, it will return FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Add More Link, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CanAddMoreLink();


	// Generate up - right link directions.
	virtual CSize DoGenDirs(CFOLinkShape *pLink, const CPoint& ptEnd, const CRect& rcBound, CFOPortShape *pOtherPort);

	// Generate up - right link directions, this is for tacking mode only.
	virtual CSize DoGenTrackDirs(CFOLinkShape *pLink, const CPoint& ptEnd, const CRect& rcBound, CFOPortShape *pOtherPort);

	// Nearest point.
	CPoint NearestPoint(const CPoint &ptCheck, CFOLinkShape *pLinkLayon, 
		int &segment, float &nsegmentPercent);

	// Computer connection point.
	CPoint ComputeConnectionPoint( CFOLinkShape *pLinkLayon,int segment, float nsegmentPercent);

	// Nearest point.
	CPoint NearestPointTrack(const CPoint &ptCheck, CFOLinkShape *pLinkLayon, 
		int &segment, float &nsegmentPercent);
	
	// Computer connection point.
	CPoint ComputeConnectionPointTrack( CFOLinkShape *pLinkLayon,int segment, float nsegmentPercent);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Obtain correct first line segment length.
	virtual int GetCorrectLength(double &dSep, BOOL bInverse, BOOL bInverseY);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom2, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom2(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Check if it is the from port or to port. 0 - no,1- from,2 - to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Form, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CheckForm();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

public:
	// Show port or not.
	BOOL		m_bShowPort;

protected:

	// The list of links.
 
	// Link List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_LinkList;

	// The list of links that lay on this port.
 
	// Lay Link List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_LayLinkList;

	// Parent shape pointer.
 
	// Parent, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pParentComp;

	// X Scale
 
	// X Scale, This member specify double object.  
	double			dXScale;

	// Y Scale
 
	// Y Scale, This member specify double object.  
	double			dYScale;

	// Make sure it is the center.
 
	// Make Sure Center, This member sets TRUE if it is right.  
	BOOL			m_bMakeSureCenter;

	// Port type.
 
	// Port Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPortType;

	// Port index.
 
	// Port Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPortIndex;

};

  // The shapes list.
typedef CFOTypedShapeObList<CFOPortShape*> CFOPortShapeList;	

// default is 8
_FOLIB_INLINE int CFOPortShape::GetPortWidth() const
{
	FO_VALUE value;
	if (TRUE == GetPropValue(value, P_ID_PORTWIDTH))
		return value.m_nValue;
	
	return fo_DefaultPortWidth;
}

// default is 8
_FOLIB_INLINE int CFOPortShape::GetPortHeight() const
{
	FO_VALUE value;
	if (TRUE == GetPropValue(value, P_ID_PORTHEIGHT))
		return value.m_nValue;
	
	return fo_DefaultPortHeight;
}

// returns the "From" side
_FOLIB_INLINE FOPPortCenterAtSide CFOPortShape::GetCenterAtSide() const
{ 
	FO_VALUE value;
	if (TRUE == GetPropValue(value, P_ID_PORTSIDE))
		return (FOPPortCenterAtSide)value.m_nValue;
	
	return PortCenter;
}

// sets the "From" side
_FOLIB_INLINE void CFOPortShape::SetCenterAtSide(const FOPPortCenterAtSide &nNewSide) 
{ 
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nNewSide;
	PutPropValue(P_ID_PORTSIDE, value);
}

// sets the "From" side
_FOLIB_INLINE void CFOPortShape::SetPortSide(const FOPPortCenterAtSide &nNewSide) 
{ 
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nNewSide;
	PutPropValue(P_ID_PORTSIDE, value);
}

// Set width.
_FOLIB_INLINE void CFOPortShape::SetPortWidth(const int& nWidth)
{
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nWidth;
	PutPropValue(P_ID_PORTWIDTH, value);
}

// Set height
_FOLIB_INLINE void CFOPortShape::SetPortHeight(const int& nHeight)
{
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nHeight;
	PutPropValue(P_ID_PORTHEIGHT, value);
}

// Port shape type.
_FOLIB_INLINE int CFOPortShape::GetPortType() const
{
	FO_VALUE value;
	if (TRUE == GetPropValue(value, P_ID_PORTTYPE))
		return value.m_nValue;
	
	return m_nPortType;
}

// Set Port shape type.
_FOLIB_INLINE void CFOPortShape::SetPortType(const int& nType)
{
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nType;
	if (TRUE != PutPropValue(P_ID_PORTTYPE, value))
		m_nPortType = nType;
}


// Port shape type.
_FOLIB_INLINE int CFOPortShape::GetPortConnectType() const
{
	FO_VALUE value;
	if (TRUE == GetPropValue(value, P_ID_PORT_CONNECT_TYPE))
		return value.m_nValue;
	
	return 0;
}

// Set Port shape type.
_FOLIB_INLINE void CFOPortShape::SetPortConnectType(const int& nType)
{
	FO_VALUE value;
	value.m_nValueType = V_INT;
	value.m_nValue = nType;
	if (TRUE != PutPropValue(P_ID_PORT_CONNECT_TYPE, value))
		m_nPortType = nType;
}

//------------------------------------------------------
// Description
// Author: Author.
//------------------------------------------------------

class CFODotPortShape : public CFOPortShape  
{
protected:
	DECLARE_SERIAL(CFODotPortShape);
public:

	// constructor
	CFODotPortShape();

	// Copy constructor.
	CFODotPortShape(const CFODotPortShape& src);

	// Destructor.
	virtual ~CFODotPortShape();

	// Creates the port shape from a CRect object.
	virtual void Create(CPoint point,CFODrawShape *pParent);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPortShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:

	// Assignment operator.
	CFODotPortShape& operator=(const CFODotPortShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
	CPoint NearestPoint(const CPoint &ptCheck, CFOLinkShape *pLinkLayon, 
		int &segment, float &nsegmentPercent);

	CPoint ComputeConnectionPoint( CFOLinkShape *pLinkLayon,int segment, float nsegmentPercent);

	// Obtain the from link direction
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Link Directory, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a float value.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual float GetFromLinkDir(CFOLinkShape *pLink, CFOLinkShape *pLinkLayon,int segment);
public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//===========================================================================
// Summary:
//     The CFOCADPointShape class derived from CFODrawShape
//      F O CAD point Shape
//===========================================================================

class FO_EXT_CLASS CFOCADPointShape : public CFODrawShape  
{
protected:
	DECLARE_SERIAL(CFOCADPointShape);
public:

	// constructor
	CFOCADPointShape();

	// Copy constructor.
	CFOCADPointShape(const CFOCADPointShape& src);

	// Destructor.
	virtual ~CFOCADPointShape();

	// Creates the button shape from a CRect object.
	virtual void Create(const FOPPoint &ptCenter,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPortShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Assignment operator.
	CFOCADPointShape& operator=(const CFOCADPointShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Get position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the point of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);
	
	// Get the point of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPointSpotLocation(CFOPHandleList& lstHandle);

public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Hit test.
	// point -- point for hit testing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&point---Specifies A CPoint type value.
	virtual BOOL HitTest(const CPoint &point);
	
	// Hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		nExpand---nExpand, Specifies A integer value.
	virtual BOOL HitTest(const CPoint& point, int nExpand);

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#endif // !defined(AFC_FOPORTSHAPE_H__A70F8081_C9B4_11D5_A48D_525400EA266C__INCLUDED_)
