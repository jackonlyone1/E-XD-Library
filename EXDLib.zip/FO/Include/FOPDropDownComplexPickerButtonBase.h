//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNCOMPLEXPICKERBUTTONBASE_H__54888383_8F1E_420A_9184_12D018F598AE__INCLUDED_)
#define AFX_FOPDROPDOWNCOMPLEXPICKERBUTTONBASE_H__54888383_8F1E_420A_9184_12D018F598AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownComplexPickerButtonBase.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownComplexPickerButtonBase window
#include "FOPDropDownButtonBase.h"
#include "FOPComplexPickerDrawBase.h"

// Index DDX
void FO_API_DECL AFXAPI DDX_IndexedDropDown(CDataExchange *pDX, int nIDC, int& index);
class FOPPickerBaseWnd;
 
//===========================================================================
// Summary:
//     The FOPDropDownComplexPickerButtonBase class derived from FOPDropDownButtonBase
//      O P Drop Down Complex Picker Button Base
//===========================================================================

class FO_EXT_CLASS FOPDropDownComplexPickerButtonBase : public FOPDropDownButtonBase, FOPComplexPickerCallback
{

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Complex Picker Button Base, Constructs a FOPDropDownComplexPickerButtonBase object.
	//		Returns A  value (Object).  
	// Parameters:
	//		di---A pointer to the FOPComplexPickerDrawBase or NULL if the call failed.  
	//		Transparent---Transparent, Specifies A Boolean value.
								FOPDropDownComplexPickerButtonBase(FOPComplexPickerDrawBase* di, BOOL  Transparent = TRUE);
	
	// Implementation
public:

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Complex Picker Button Base, Destructor of class FOPDropDownComplexPickerButtonBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownComplexPickerButtonBase();

	// Used for sharing well control state among buttons
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownComplexPickerButtonBase& button object(Value).
	void						ShareDrawImpl(FOPDropDownComplexPickerButtonBase& button);

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	//		Returns a int type value.
	int  						GetMinimumHeight() const;

	// Get drop down wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Down Window, Returns the specified value.
	//		Returns A const FOPPickerBaseWnd& value (Object).
	const FOPPickerBaseWnd&		GetDropDownWnd() const		{	return m_DropWnd;		}

	// Get index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns a int type value.
	int 						GetIndex()	const			{	return(m_nIndex);			}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPComplexPickerDrawBase& value (Object).
	FOPComplexPickerDrawBase&	GetDrawImpl()				{	return *pDrawImpl;		}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPComplexPickerDrawBase& value (Object).
	const FOPComplexPickerDrawBase&	GetDrawImpl() const		{	return *pDrawImpl;		}

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPDropDownComplexPickerButtonBase
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void						SetTransparency(BOOL  bTransparent);

	// Is transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 						IsTransparent()	const		{	return m_bTransparent;		}

	// Set index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class FOPDropDownComplexPickerButtonBase
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void						SetIndex(int nIndex);

	// Do drop down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	// Notify when system color change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify System Color Change, .

	void						NotifySysColorChange();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		bDraw---bDraw, Specifies A Boolean value.
	// Draw state
	void						Draw(CDC& dc, const CRect& rc, BOOL bDraw);
	
	// callbacks
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.

	void						OnWellCancel();

	// Do When index change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Index Change, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void						OnWellIndexChange(int nIndex);

protected:

	// Transparent
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 						m_bTransparent;

	// Drop wnd
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Auto draw impl
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPComplexPickerDrawBase.  
	FOPComplexPickerDrawBase*	pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPComplexPickerDrawBase.  
	FOPComplexPickerDrawBase*	pDrawImpl;

	// Index
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int							m_nIndex;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNCOMPLEXPICKERBUTTONBASE_H__54888383_8F1E_420A_9184_12D018F598AE__INCLUDED_)
