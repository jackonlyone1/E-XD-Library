//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOFILLEFFECTPAGE2_H__052BC6A6_FF1A_11D5_A509_525400EA266C__INCLUDED_)
#define AFX_FOFILLEFFECTPAGE2_H__052BC6A6_FF1A_11D5_A509_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOFillEffectPage2.h : header file
//
#include "FOImageTypeWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CFOFillEffectPage2 dialog
class CFOFillEffectDlg;
 
//===========================================================================
// Summary:
//     The CFOFillEffectPage2 class derived from CPropertyPage
//      F O Fill Effect Page2
//===========================================================================

class FO_EXT_CLASS CFOFillEffectPage2 : public CPropertyPage
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFillEffectPage2---F O Fill Effect Page2, Specifies a E-XD++ CFOFillEffectPage2 object (Value).
	DECLARE_DYNCREATE(CFOFillEffectPage2)

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fill Effect Page2, Constructs a CFOFillEffectPage2 object.
	//		Returns A  value (Object).
	CFOFillEffectPage2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Fill Effect Page2, Destructor of class CFOFillEffectPage2
	//		Returns A  value (Object).
	~CFOFillEffectPage2();

 
	// Dialog, This member maintains a pointer to the object CFOFillEffectDlg.  
	CFOFillEffectDlg*	m_pDialog;
// Dialog Data
	//{{AFX_DATA(CFOFillEffectPage2)
	enum { IDD = IDD_FO_FILL_PAGE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA
	// Fill type wnd.
 
	// Image, This member specify E-XD++ CFOImageTypeWnd object.  
	CFOImageTypeWnd m_wndImage;

	//Brush Type
 
	// Image Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nImageType;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFOFillEffectPage2)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOFillEffectPage2)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillOK(WPARAM wParam, LPARAM lParam);
	//Select Day Cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillCancel(WPARAM wParam, LPARAM lParam);

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOFILLEFFECTPAGE2_H__052BC6A6_FF1A_11D5_A509_525400EA266C__INCLUDED_)
