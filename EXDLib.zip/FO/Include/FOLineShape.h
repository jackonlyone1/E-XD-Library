//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOLINESHAPE_H__DA01E300_685A_11DF_A46C_525400EA266C__INCLUDED_)
#define AFC_FOLINESHAPE_H__DA01E300_685A_11DF_A46C_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------
#include "FODrawShape.h"

////////////////////////////////////////////////////////////////////////////////
// CFOLineShape -- line shape, ID: FO_COMP_LINE 24

 
//===========================================================================
// Summary:
//     The CFOLineShape class derived from CFODrawShape
//      F O Line Shape
//===========================================================================

class FO_EXT_CLASS CFOLineShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOLineShape---F O Line Shape, Specifies a E-XD++ CFOLineShape object (Value).
	DECLARE_SERIAL(CFOLineShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Shape, Constructs a CFOLineShape object.
	//		Returns A  value (Object).
	CFOLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Shape, Constructs a CFOLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOLineShape& src object(Value).
	CFOLineShape(const CFOLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Line Shape, Destructor of class CFOLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Creates the line shape from points.
	// ptArray -- points of line.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// Create the line shape from the points.
	// pptPoints -- points of line.
	// nCount -- total points of shape.
	BOOL Create(LPPOINT pptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeCircularShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetSimpleValue(const double &dValue);
	
	
public:

	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	
	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the point of control.
	// lstHandle -- list of handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	// ptHandle -- point of handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOLineShape& src object(Value).
	CFOLineShape& operator=(const CFOLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized.
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

public:

	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject();


	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject();

		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Is or no m_UpRightMode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Up Right Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsUpRightMode() const;

	// Set m_UpRightMode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Up Right Mode, Sets a specify value to current class CFOLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bUpRightMode---Up Right Mode, Specifies A Boolean value.
	virtual void SetUpRightMode(BOOL bUpRightMode);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Is zhi line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Zhi Line, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsZhiLine();

	// Obtain the total length of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Length, Returns the specified value.
	//		Returns a int type value.
	int GetTotalLength();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Create zhi line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Up Right Mode Line, You construct a CFOLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CreateUpRightModeLine();

	// Get current point with a specify handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		nControlPoint---Point, Specifies A integer value.
	virtual CPoint GetCurrentPoint(const CRect& rcPos, FO_CONTROL_HANDLE nControlPoint);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ShapeToSVGString();

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Creates GDI objects and sets up the device context for drawing.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws custom tracker.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Draws shadow of shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Offset a spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

};

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: Line like pipe shape, ID: FO_COMP_PIPE_SHAPE 267
// Author: Author.
// Class CFOPipeShape
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPipeShape class derived from CFOLineShape
//      F O Pipe Shape
//===========================================================================

class FO_EXT_CLASS CFOPipeShape : public CFOLineShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPipeShape---F O Pipe Shape, Specifies a E-XD++ CFOPipeShape object (Value).
	DECLARE_SERIAL(CFOPipeShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pipe Shape, Constructs a CFOPipeShape object.
	//		Returns A  value (Object).
	CFOPipeShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pipe Shape, Constructs a CFOPipeShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPipeShape& src object(Value).
	CFOPipeShape(const CFOPipeShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pipe Shape, Destructor of class CFOPipeShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPipeShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPipeShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Create the bezier line shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPipeShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount);
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPipeShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPipeShape& src object(Value).
	CFOPipeShape& operator=(const CFOPipeShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pipe Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetPipeLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pipe Line Width, Sets a specify value to current class CFOPipeShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPipeLineWidth( const int &nValue );

};

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: Line like pipe shape, ID: FO_NEW_PIPE_SHAPE 293
// Author: Author.
// Class CFOPNewPipeShape
//------------------------------------------------------


 
//===========================================================================
// Summary:
//     The CFOPNewPipeShape class derived from CFOLineShape
//      F O P New Pipe Shape
//===========================================================================

class FO_EXT_CLASS CFOPNewPipeShape : public CFOLineShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewPipeShape---F O P New Pipe Shape, Specifies a E-XD++ CFOPNewPipeShape object (Value).
	DECLARE_SERIAL(CFOPNewPipeShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Pipe Shape, Constructs a CFOPNewPipeShape object.
	//		Returns A  value (Object).
	CFOPNewPipeShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P New Pipe Shape, Constructs a CFOPNewPipeShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewPipeShape& src object(Value).
	CFOPNewPipeShape(const CFOPNewPipeShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P New Pipe Shape, Destructor of class CFOPNewPipeShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPNewPipeShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewPipeShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Create the bezier line shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPNewPipeShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount);
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewPipeShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPNewPipeShape& src object(Value).
	CFOPNewPipeShape& operator=(const CFOPNewPipeShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPNewPipeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPNewPipeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// Arrow cut.
	void XGetStartArrowCutLength(LPPOINT m_lpShapePoints, int nPtCount, FOPPoint &ptStart, const int &nArrowLength);

	// Line end cut.
	void XGetEndArrowCutLength(LPPOINT m_lpShapePoints, int m_nCompPtCount,FOPPoint &ptEnd, const int &nArrowLen);

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Drawing pipe line.
	// pDC -- pointer of DC.
	// points -- points for drawing.
	// nPtCount -- count of points.
	// iSegments -- width of pipe, it should be 2 * iSegments width.
	// crStart -- start color of pipe.
	// crEnd -- end color of pipe.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Pipe Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		points---Specifies A LPPOINT Points array.  
	//		nPtCount---Point Count, Specifies A integer value.  
	//		&nLineWidth---Line Width, Specifies A integer value.  
	//		iSegments---iSegments, Specifies A integer value.  
	//		&crLine---&crLine, Specifies A 32-bit COLORREF value used as a color value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.
	virtual void DoDrawPipeLine(CDC* pDC, LPPOINT points, int nPtCount,
		const int &nLineWidth,
		int iSegments, const COLORREF &crLine, COLORREF crStart, COLORREF crEnd);

	// Obtain random colors.
	COLORREF FOPXGetRandomColorX2();
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();
	
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOPNewPipeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOPNewPipeShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);

	// Do animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pipe Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetPipeLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pipe Line Width, Sets a specify value to current class CFOPNewPipeShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPipeLineWidth( const int &nValue );

	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pipe Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetPipeLineColor();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pipe Line Color, Sets a specify value to current class CFOPNewPipeShape
	// Parameters:
	//		&crValue---&crValue, Specifies A 32-bit COLORREF value used as a color value.
	void SetPipeLineColor( const COLORREF &crValue );

 
	// Shift, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nShift;
 
	// Animate, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAnimate;
 
	// Wide, This member sets TRUE if it is right.  
	BOOL				m_bWide;
	
	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current timer speed, default is 400
 
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;

};


/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: move shape along path shape, ID: FO_COMP_MOVEPATH_SHAPE 285
// Author: Author.
// Class CFOPMovePathShape
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPMovePathShape class derived from CFOLineShape
//      F O P Move Path Shape
//===========================================================================

class FO_EXT_CLASS CFOPMovePathShape : public CFOLineShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMovePathShape---F O P Move Path Shape, Specifies a E-XD++ CFOPMovePathShape object (Value).
	DECLARE_SERIAL(CFOPMovePathShape);
public:
	
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Move Path Shape, Constructs a CFOPMovePathShape object.
	//		Returns A  value (Object).
	CFOPMovePathShape();
	
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Move Path Shape, Constructs a CFOPMovePathShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPMovePathShape& src object(Value).
	CFOPMovePathShape(const CFOPMovePathShape& src);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Move Path Shape, Destructor of class CFOPMovePathShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMovePathShape();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPMovePathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Create the bezier line shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPMovePathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount);
	
public:
	
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPMovePathShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPMovePathShape& src object(Value).
	CFOPMovePathShape& operator=(const CFOPMovePathShape& src);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOPMovePathShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);
	
	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Return link path shape's key 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Path Shape, Returns the specified value.
	//		Returns a CString type value.
	CString GetLinkPathShape();
	
	// Change link path shape's key 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link Path Shape, Sets a specify value to current class CFOPMovePathShape
	// Parameters:
	//		&strKey1---&strKey1, Specifies A CString type value.
	void SetLinkPathShape( const CString &strKey1 );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Move Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMoveShape() { return m_pCurMoveComponent; }

public:
	// Update slider state.
 
	// Slider, This member sets TRUE if it is right.  
	BOOL			m_updateSlider;
	
 
	// Current Move Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape * m_pCurMoveComponent;
};

/////////////////////////////////////////////////////////
//------------------------------------------------------
// CFOPCADEllipseShape -- Ellipse Shape type 2 ID: FO_CAD_ELLIPSE_SHAPE 346
//------------------------------------------------------


//===========================================================================
// Summary:
//     The CFOPCADEllipseShape class derived from CFODrawPortsShape
//      F O Ellipse Shape2
//===========================================================================

class FO_EXT_CLASS CFOPCADEllipseShape : public CFOLineShape  
{
protected:
	DECLARE_SERIAL(CFOPCADEllipseShape);
public:
	
	// constructor
	CFOPCADEllipseShape();
	
	// Copy constructor.
	CFOPCADEllipseShape(const CFOPCADEllipseShape& src);
	
	// Destructor.
	virtual ~CFOPCADEllipseShape();
	
	// Creates the button shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Create.
	virtual void Create(const FOPPoint& center,
		const FOPPoint& majorP,
		double ratio,
		double angle1, double angle2,
                   bool reversed);
	void CreateX(double smooth, CArray <CPoint, CPoint> &templine);

	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

public:
	
	// Assignment operator.
	CFOPCADEllipseShape& operator=(const CFOPCADEllipseShape& src);
	
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;
	
	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);
	
public:
	
	// WM_LBUTTONDOWN message.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
public:
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
	//Draw flat status.
	
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);
	
	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);
	
	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);
	
	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);
	
	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);
	
	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// get start point
	virtual FOPPoint getStartpoint() const;
    /** 
	 * @return End point of the entity. 
	 */
    virtual FOPPoint getEndpoint() const;


	// move start point.
	virtual void moveStartpoint(const FOPPoint& pos);

	// move end point
	virtual void moveEndpoint(const FOPPoint& pos);

	// calculate borders
	virtual void calculateBorders();

	// get ellipse angle
	double getEllipseAngle(const FOPPoint& pos);

	// move
	virtual void move(FOPPoint offset);

	// rotate
    virtual void rotate(FOPPoint center, double angle);

	// scale
    virtual void scale(FOPPoint center, FOPPoint factor);

	// mirror
    virtual void mirror(FOPPoint axisPoint1, FOPPoint axisPoint2);

	// move reference
	virtual void moveRef(const FOPPoint& ref, const FOPPoint& offset);

	// get nearest point on shape
	virtual FOPPoint getNearestPointOnEntity(const FOPPoint& coord,
            bool onEntity = true, double* dist = NULL);

	/**
     * @retval true if the arc is reversed (clockwise), 
     * @retval false otherwise 
     */
    BOOL isReversed() const 
	{
        return reversed;
    }
	/** sets the reversed status. */
	void setReversed(BOOL r) 
	{
		reversed = r;
	}

	/** @return The rotation angle of this ellipse */
    double getAngle() const;

    /** @return The start angle of this arc */
    double getAngle1() {
        return angle1;
    }
    /** Sets new start angle. */
	void setAngle1(double a1) {
		angle1 = a1;
	}
    /** @return The end angle of this arc */
    double getAngle2() {
        return angle2;
    }
    /** Sets new end angle. */
	void setAngle2(double a2) {
		angle2 = a2;
	}


    /** @return The center point (x) of this arc */
    FOPPoint getCenter();

    /** Sets new center. */
	void setCenter(const FOPPoint& c) {
		center = c;
	}

    /** @return The endpoint of the major axis (relative to center). */
    FOPPoint getMajorP() {
        return majorP;
    }
    /** Sets new major point (relative to center). */
	void setMajorP(const FOPPoint& p) {
		majorP = p;
	}

    /** @return The ratio of minor to major axis */
    double getRatio() {
        return ratio;
    }
    /** Sets new ratio. */
	void setRatio(double r) {
		ratio = r;
	}


    /**
     * @return Angle length in rad.
     */
    virtual double getAngleLength() const {
        if (isReversed()) {
            return angle1-angle2;
        } else {
            return angle2-angle1;
        }
    }

    /** @return The major radius of this ellipse. Same as getRadius() */
    double getMajorRadius() const ;

    /** @return The minor radius of this ellipse */
    double getMinorRadius() const;

	/** @return The major radius of this ellipse. Same as getRadius() */
    double getTrackMajorRadius() const;
	
    /** @return The minor radius of this ellipse */
    double getTrackMinorRadius() const;

	// get nearest end point
	virtual FOPPoint getNearestEndpoint(const FOPPoint& coord,
                                         double* dist = NULL);

	// get nearest center
	virtual FOPPoint getNearestCenter(const FOPPoint& coord,
		double* dist = NULL);

	// get nearest middle
    virtual FOPPoint getNearestMiddle(const FOPPoint& coord,
                                       double* dist = NULL);
public:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	//Ellipse center
    FOPPoint center;

    //Endpoint of major axis relative to center.
    FOPPoint majorP;

    //Ratio of minor axis to major axis.
    double ratio;

    //Start angle
    double angle1;

    //End angle
    double angle2;

	//Reversed (cw) flag
	BOOL reversed;
};

#endif // !defined(AFC_FOLINESHAPE_H__DA01E300_685A_11DF_A46C_525400EA266C__INCLUDED_)
