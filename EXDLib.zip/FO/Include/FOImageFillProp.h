//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOIMAGEFILLPROP_H__FEA20055_0635_11D6_A4FB_525400EA266C__INCLUDED_)
#define AFX_FOIMAGEFILLPROP_H__FEA20055_0635_11D6_A4FB_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOImageFillProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOImageFillProp dialog
#include "FOImageButton.h"


/////////////////////////////////////////////////////////////////////////////
// CFOImageFillProp dialog
#include "FOColorButton.h"
#include "FOPDropDownColorPickerButton.h"

 
//===========================================================================
// Summary:
//     The CFOImageFillProp class derived from CDialog
//      F O Image Fill Property
//===========================================================================

class FO_EXT_CLASS CFOImageFillProp : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Fill Property, Constructs a CFOImageFillProp object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOImageFillProp(CWnd* pParent = NULL);   // standard constructor

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Fill Property, Destructor of class CFOImageFillProp
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOImageFillProp();
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

// Dialog Data
	//{{AFX_DATA(CFOImageFillProp)
	enum { IDD = IDD_FO_IMAGE_FILL };
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL	m_bTransparent;
 
	// Color, This member specify CStatic object.  
	CStatic	m_staticColor;
 
	// Slider Red, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderRed;
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRed;
	//}}AFX_DATA

	//Button Text Color
 
	// Text Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnTextColor;

	// Get or set the color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOImageFillProp
	// Parameters:
	//		cr---Specifies A 32-bit COLORREF value used as a color value.
	void	 SetColor(COLORREF cr)	{ crColor = cr; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetColor()				{ return crColor; }


protected:

	// Stop mouse capture.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stop Capture, Call this function to stop
	// This member function is also a virtual function, you can Override it if you need,
	virtual void StopCapture();

protected:

	// Current color.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF	crColor;			

	// Is capture state.
 
	// Capturing, This member sets TRUE if it is right.  
	BOOL		m_bCapturing;		

	// Blank icon.
 
	// Icon Blank, This member specify HICON object.  
	HICON		m_hIconBlank;

	// Picker icon.
 
	// Icon Picker, This member specify HICON object.  
	HICON		m_hIconPicker;

	// Picker cursor.
 
	// Cursor Picker, This member specify HCURSOR object.  
	HCURSOR		m_hCursorPicker;
	
	// Previous cursor.
 
	// Cursor Previous, This member specify HCURSOR object.  
	HCURSOR		m_hCursorPrev;	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOImageFillProp)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOImageFillProp)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Transparent, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTransparent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll Slider, Called when the user clicks the horizontal scroll bar of CWnd.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnHScrollSlider(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOIMAGEFILLPROP_H__FEA20055_0635_11D6_A4FB_525400EA266C__INCLUDED_)
