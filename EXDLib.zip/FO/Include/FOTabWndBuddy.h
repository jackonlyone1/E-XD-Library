//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTABWNDBUDDY_H__38B479A6_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
#define AFX_FOTABWNDBUDDY_H__38B479A6_D0E7_11D6_A665_0050BAE30439__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTabWndBuddy.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOTabWndBuddy window

#include <afxtempl.h>

#include "fodefines.h"
#include "FOTabCtrlObject.h"
///////////////////////////////////////////////////////////////////////////////
typedef DWORD HLSCOLOR;
#define HLS(h,l,s) ((HLSCOLOR)(((BYTE)(h)|((WORD)((BYTE)(l))<<8))|(((DWORD)(BYTE)(s))<<16)))

///////////////////////////////////////////////////////////////////////////////
#define HLS_H(hls) ((BYTE)(hls))
#define HLS_L(hls) ((BYTE)(((WORD)(hls)) >> 8))
#define HLS_S(hls) ((BYTE)((hls)>>16))

///////////////////////////////////////////////////////////////////////////////
// Performs some modifications on the specified color : luminance and saturation

 
//===========================================================================
// Summary:
//     The CFOTabWndBuddy class derived from CWnd
//      F O Tab Window Buddy
//===========================================================================

class FO_EXT_CLASS CFOTabWndBuddy : public CWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabWndBuddy---F O Tab Window Buddy, Specifies a E-XD++ CFOTabWndBuddy object (Value).
	DECLARE_DYNAMIC(CFOTabWndBuddy);
// Construction
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Window Buddy, Constructs a CFOTabWndBuddy object.
	//		Returns A  value (Object).
	CFOTabWndBuddy();

// Attributes
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTabWndBuddy object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rc---Specifies a const RECT& rc object(Value).  
	//		pTabWnd---Tab Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create a tab control.
	virtual BOOL Create(DWORD dwStyle, const RECT& rc,CWnd* pTabWnd, UINT nID);

public:

	// Obtain the tab's icon size.
	BOOL	m_bWithCloseMode;

	// need change position.
	
	// Change Position, This member sets TRUE if it is right.  
	BOOL		m_bChangePos;		

	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Icon Size, Returns the specified value.
	//		Returns a int type value.
	int GetTabIconSize() { return m_nIconSize; }

	// Change the tab's icon size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon Size, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nSize---&nSize, Specifies A integer value.
	void SetTabPageIconSize(const int &nSize);

	// Obtain the tab's left start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Start, Returns the specified value.
	//		Returns a int type value.
	int GetLeftStart() { return m_nLeftStart; }

	// Change the tab's left start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Left Start, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nOffset---&nOffset, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetLeftStart(const int &nOffset,BOOL bRedraw = TRUE);

	// Obtain the tab's top start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Start, Returns the specified value.
	//		Returns a int type value.
	int GetTopStart() { return m_nTopStart; }

	// Change the tab's top start position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Top Start, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nOffset---&nOffset, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetTopStart(const int &nOffset,BOOL bRedraw = TRUE);

	// Obtain the default tab height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Tab Height, Returns the specified value.
	//		Returns a int type value.
	int GetDefaultTabHeight() { return m_nTabHeight; }

	// Change the default tab height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Tab Height, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDefaultTabHeight(const int &nHeight,BOOL bRedraw = TRUE);

	// Obtain the default tab width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Tab Width, Returns the specified value.
	//		Returns a int type value.
	int GetDefaultTabWidth() { return m_nTabWidth; }

	// Change the default tab width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Tab Width, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDefaultTabWidth(const int &nWidth,BOOL bRedraw = TRUE);

	// Obtain the active tab's font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetActiveTabFontName();

	// Change the active tab's font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Name, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetActiveTabFontName(LPCTSTR lpszFaceName,BOOL bRedraw = TRUE);

	// Obtain the active tab's font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetActiveTabFontColor();

	// Change the active tab's font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetActiveTabFontColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Obtain the active tab back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetActiveTabBkColor();

	// Change the active tab back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Background Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetActiveTabBkColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Obtain the active tab font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Height, Returns the specified value.
	//		Returns a int type value.
	int GetActiveTabFontHeight();

	// Change the active tab font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Height, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	BOOL SetActiveTabFontHeight(const int &nPointSize,BOOL bRedraw = TRUE, CDC* pDC = NULL);

	// Obtain the active tab font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Point Size, Returns the specified value.
	//		Returns a int type value.
	int GetActiveTabFontPointSize();

	// Change the active tab font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Point Size, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	BOOL SetActiveTabFontPointSize(const int &nHeight,BOOL bRedraw = TRUE, CDC* pDC = NULL);

	// Obtain the active tab font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Weight, Returns the specified value.
	//		Returns a int type value.
	int GetActiveTabFontWeight();

	// Change the active tab font wieght
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Weight, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetActiveTabFontWeight(const int &nWeight,BOOL bRedraw = TRUE);

	// Obtain active tab's font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetActiveTabFontItalic();

	// Change active tab's font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Italic, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetActiveTabFontItalic(const BOOL &bItalic,BOOL bRedraw = TRUE);

	// Obtain the active tab's font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Font Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetActiveTabFontUnderline();

	// Change the active tab's font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab Font Underline, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetActiveTabFontUnderline(const BOOL &bUnderline,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetInActiveTabFontName();

	// Change the inactive tab's font name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Name, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetInActiveTabFontName(LPCTSTR lpszFaceName,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetInActiveTabFontColor();

	// Change the inactive tab's font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetInActiveTabFontColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetInActiveTabBkColor();

	// Change the inactive tab's back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Background Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetInActiveTabBkColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Point Size, Returns the specified value.
	//		Returns a int type value.
	int GetInActiveTabFontPointSize();

	// Change the inactive tab's font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Point Size, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	BOOL SetInActiveTabFontPointSize(const int &nPointSize,BOOL bRedraw = TRUE, CDC* pDC = NULL);

	// Obtain the inactive tab's font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Height, Returns the specified value.
	//		Returns a int type value.
	int GetInActiveTabFontHeight();

	// Change the inactive tab's font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Height, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	BOOL SetInActiveTabFontHeight(const int &nPointSize,BOOL bRedraw = TRUE, CDC* pDC = NULL);

	// Obtain the inactive tab's font Weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Weight, Returns the specified value.
	//		Returns a int type value.
	int GetInActiveTabFontWeight();

	// Change the inactive tab's font weight.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Weight, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetInActiveTabFontWeight(const int &nWeight,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetInActiveTabFontItalic();

	// Change the inactive tab's font italic flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Italic, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetInActiveTabFontItalic(const BOOL &bItalic,BOOL bRedraw = TRUE);

	// Obtain the inactive tab's font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get In Active Tab Font Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetInActiveTabFontUnderline();

	// Change the inactive tab's font underline flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set In Active Tab Font Underline, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetInActiveTabFontUnderline(const BOOL &bUnderline,BOOL bRedraw = TRUE);

	// Change font to logical.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Logical, .
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int ChangeToLogical(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Chante font to point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Logical To Point, .
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int FromLogToPoint(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Obtain the tab's separator space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Separator, Returns the specified value.
	//		Returns a int type value.
	int GetTabSeparator() { return m_nTabSeparator; }

	// Change the tab's separator space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Separator, Sets a specify value to current class CFOTabWndBuddy
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nSep---&nSep, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetTabSeparator(const int &nSep,BOOL bRedraw = TRUE);

	// Obtain the tab's Cornor size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Corner Size, Returns the specified value.
	//		Returns a int type value.
	int GetTabCornerSize() { return m_nTabCornderSize; }

	// Change the tab's Cornor size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Cornder Size, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nSize---&nSize, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetTabCornderSize(const int &nSize,BOOL bRedraw = TRUE);

	// Obtain the tab's back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetTabBkColor() { return m_crTabBkColor; }

	// Change the tab's back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Background Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetTabBkColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Get the count of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	//		Returns a int type value.
    int GetTabCount() const;

	// Obtain the tab object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Safe Tab, Returns the specified value.
	//		Returns A E-XD++ CFOTabCtrlObject& value (Object).  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabCtrlObject& GetSafeTab(int nTab) const;

	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Tab, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		point---Specifies A CPoint type value.
	BOOL HitTestTab(int nTab, CPoint& point);

	// Returns the menu of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Menu, Returns the specified value.
	//		Returns A HMENU value (Object).  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	HMENU GetTabMenu(int nTab) const;

	// Returns the window of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Window, Returns the specified value.
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CWnd* GetTabWnd(int nTab) const;

	// Sets the menu of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Menu, Sets a specify value to current class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		hMenu---hMenu, Specifies a HMENU hMenu object(Value).
	virtual void SetTabMenu(int nTab, HMENU hMenu);

	// Obtain the Extra tab's data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Data, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	DWORD GetItemData(int nTab) const;

	// Change the extra tab's data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Data, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		&dData---&dData, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void SetItemData(int nTab,const DWORD &dData);

	// Do help method.
	void DoHelpMethod1(CPoint point);

	// Do help method.
	void DoHelpMethod2();

	// Obtain all tabs
	CString GetAllTabs();

	// Get tab information.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Information, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		bSelected---bSelected, Specifies A Boolean value.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		hMenu---hMenu, Specifies a HMENU& hMenu object(Value).
    BOOL GetTabInfo(int nTab, CString& strLabel, BOOL& bSelected,CWnd*& pWnd, HMENU& hMenu) const;

	// Find a special tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Tab, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nTab---nTab, Specifies A integer value.
    BOOL FindTab(CWnd* pWnd, int& nTab) const;

	// Obtain the active tab's index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active Tab Index, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    BOOL GetActiveTabIndex(int& nTab) const;
    
	// Is tab valid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Tab, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	BOOL IsValidTab(CWnd* pWnd) const;

	// Is tab valid.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Tab, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    BOOL IsValidTab(int nTab) const;

	// Prepare or release gdi objects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare G D I, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
    virtual void PrepareGDI(DWORD dwStyle);

	// Release GDI objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release G D I, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseGDI();

	// Create a new tab object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Tab, You construct a CFOTabWndBuddy object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed
	virtual CFOTabCtrlObject* CreateTab() const;

	// Returns the index of the specified tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.
	int GetTabIndex(CWnd* pWnd) const;

	// Obtain the index of the special tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		pTab---pTab, A pointer to the CFOTabCtrlObject or NULL if the call failed.
	int GetTabIndex(CFOTabCtrlObject* pTab) const;

	// Recalc layout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RecalcLayout();

	// Do activate tab action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Tab, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void OnActivateTab(int nTab);

	// Insert a new tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tab, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		hMenu---hMenu, Specifies a HMENU hMenu = NULL object(Value).
	virtual CFOTabCtrlObject* InsertTab(int nTab, CWnd *pWnd,CString strLabel, HMENU hMenu = NULL);

	// Modify tab style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Modify Style, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwRemove---dwRemove, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwAdd---dwAdd, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL ModifyStyle(DWORD dwRemove, DWORD dwAdd, UINT nFlags = 0);	

	// Add a new tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tab, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		strLabel---strLabel, Specifies A CString type value.  
	//		hMenu---hMenu, Specifies a HMENU hMenu = NULL object(Value).
    virtual CFOTabCtrlObject* AddTab(CWnd *pWnd,CString strLabel, HMENU hMenu = NULL);

	// Remove a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Tab, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void RemoveTab(int nTab);

	BOOL ShowPopupMenu(int nTab, const CPoint &ptHit);
	void GetAllFolders(CStringArray *maAll);
	BOOL IsVisiblePage(const CString &strPage);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	void ShowOrHide(int nTab, BOOL bShow);
	int FindPrevPage(int nCur);

	// Rename a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename Tab, Call this function to Changes the name of the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		strLabel---strLabel, Specifies A CString type value.
    virtual void RenameTab(int nTab, CString strLabel);
    
	// Change the tab's icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	virtual void SetTabPageIcon(int nTab, HICON hIcon);

	// Change the tab's icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		szImage---szImage, Specifies A CSize type value.  
	//		16)---Specifies a 16) object(Value).
	virtual void SetTabPageIcon(int nTab, UINT nID,CSize szImage = CSize(16,16));

	// Change the tab's icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Page Icon, Sets a specify value to current class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		szImage---szImage, Specifies A CSize type value.  
	//		16)---Specifies a 16) object(Value).
	virtual void SetTabPageIcon(int nTab, LPCTSTR lpszResName,CSize szImage = CSize(16,16));

	// Active a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Activate Tab, Activates the specified object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    virtual void ActivateTab(int nTab); 

	// Active a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active Tab, Sets a specify value to current class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
    virtual void SetActiveTab(int nTab);

	// Clear select.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Select, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void ClearSelect();

	// Invalidate a specify tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Tab, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void InvalidateTab(int nTab);

	// Enable or disable a tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Tab, Call this member function to enable or disable the specify object for this command.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		bEnable---bEnable, Specifies A Boolean value.
	virtual void EnableTab(int nTab, BOOL bEnable=TRUE);

	// Is current tab enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual BOOL IsEnabled(int nTab);

	// Reset text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Text, Called this function to empty a previously initialized CFOTabWndBuddy object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bReset---bReset, Specifies A Boolean value.
	virtual void ResetText(BOOL bReset = TRUE);

	// Draw client border 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Draw Client Border, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsDrawClientBorder() { return m_bDrawClientBorder; }

	//Set draw client border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Client Border, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&bClient---&bClient, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawClientBorder(const BOOL &bClient,BOOL bRedraw = TRUE);

	// Draw flat border 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Flat Border, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFlatBorder() { return m_bFlatMode; }

	//Set draw flat border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Flat Border, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&bFlat---&bFlat, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawFlatBorder(const BOOL &bFlat,BOOL bRedraw = TRUE);

	// Draw money mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Money Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMoneyMode() { return m_bMoneyMode; }

	//Set draw money mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Draw Money Mode, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&bMoney---&bMoney, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetDrawMoneyMode(const BOOL &bMoney,BOOL bRedraw = TRUE);

	// Correct border 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Correct, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCorrect() { return m_bCorrect; }

	//Set correct border.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Correct, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&bCorrect---&bCorrect, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetCorrect(const BOOL &bCorrect,BOOL bRedraw = TRUE);

	// Inflating or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Inflating, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsInflating() { return m_bInflating; }

	// Set inflating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Inflating, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&bInflat---&bInflat, Specifies A Boolean value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetInflating(const BOOL &bInflat,BOOL bRedraw = TRUE);

	// Flat border line color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Flat Border Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFlatBorderLineColor() { return m_crFlatBorderLine; }

	// Set flat border line color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Flat Border Line Color, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetFlatBorderLineColor(const COLORREF &crColor,BOOL bRedraw = TRUE);

	// Money mode extra offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Money Extra Offset, Returns the specified value.
	//		Returns a int type value.
	int GetMoneyExtraOffset() const { return m_nMoneyExtraOffset; }

	// Set money mode extra offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Money Extra Offset, Sets a specify value to current class CFOTabWndBuddy
	// Parameters:
	//		&nSize---&nSize, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetMoneyExtraOffset(const int &nSize,BOOL bRedraw = TRUE);

	// Rgb to hls.
	
	//-----------------------------------------------------------------------
	// Summary:
	// G B2 H L S, .
	//		Returns A HLSCOLOR value (Object).  
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.
	HLSCOLOR RGB2HLS (COLORREF rgb);
	
	//-----------------------------------------------------------------------
	// Summary:
	// L S2 R G B, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		hls---Specifies a HLSCOLOR hls object(Value).
	COLORREF HLS2RGB (HLSCOLOR hls);

	// Get hls color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Transform Hls Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.  
	//		perL---perL, Specifies A integer value.  
	//		perS---perS, Specifies A integer value.
	COLORREF TransformHlsColor (COLORREF rgb, int perL, int perS);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTabWndBuddy)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Tool Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pTI---T I, A pointer to the TOOLINFO or NULL if the call failed.
	virtual INT_PTR OnToolHitTest(CPoint point, TOOLINFO* pTI) const;
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Window Buddy, Destructor of class CFOTabWndBuddy
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabWndBuddy();

protected:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
    virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
    virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Get tab object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab, Returns the specified value.
	//		Returns A E-XD++ CFOTabCtrlObject& value (Object).  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabCtrlObject& GetTab(int nTab) const;

	// Get tab pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Extend, Returns the specified value.
	//		Returns a pointer to the object CFOTabCtrlObject,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabCtrlObject* GetTabExt(int nTab) const;

	// Do tool tip message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Tool Tip Message, Do a event. 
	// Parameters:
	//		pMsg---pMsg, A pointer to the const MSG or NULL if the call failed.
	void DoToolTipMsg(const MSG* pMsg);

	// Change tab size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Size, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nCount---nCount, Specifies A integer value.  
	//		nCur---nCur, Specifies A integer value.  
	//		nDimParam---Dimension Parameter, Specifies A integer value.
	virtual void ChangeSize(int nCount, int nCur, int nDimParam);
	
	// Calc tab label width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Width, .
	// Parameters:
	//		nTotBuff---Tot Buffer, Specifies A integer value.  
	//		nTotalIconBuff---Total Icon Buffer, Specifies A integer value.  
	//		bLong---bLong, Specifies A Boolean value.
	void CalcLabelWidth(int& nTotBuff, int& nTotalIconBuff, BOOL bLong = FALSE);

	// Get max tab length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Maximize Length, Returns the specified value.
	//		Returns a int type value.
	int GetTabMaxLength();

	// Get real tab rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		&rcRect---&rcRect, Specifies A CRect type value.
	virtual void GetTabRect(int nTab, CRect &rcRect) const;

	// Get label width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Width, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.  
	//		bFull---bFull, Specifies A Boolean value.
	int GetLabelWidth(int nTab, BOOL bFull = FALSE);

	// Draw tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tab, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nTab---nTab, Specifies A integer value.
	virtual void DoDrawTab(CDC* pDC, int nTab);

	// Draw money style face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Money Face, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pTab---pTab, A pointer to the CFOTabCtrlObject or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void DoDrawMoneyFace(CDC* pDC, CFOTabCtrlObject* pTab, DWORD dwStyle);

	// Draw tab face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Tab Face, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pTab---pTab, A pointer to the CFOTabCtrlObject or NULL if the call failed.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void DoDrawTabFace(CDC* pDC, CFOTabCtrlObject* pTab, DWORD dwStyle);

	// Draw disable of tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Disable, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		szImage---szImage, Specifies A CSize type value.
	virtual void DoDrawDisable(CDC* pDC, CSize szImage);

	// Fill a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill Rectangle, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
    virtual void DoFillRect(CDC* pDC,int x,int y,int cx,int cy, COLORREF crColor);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOTabWndBuddy)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

    afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
    afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Array of tabs.
	CArray<CFOTabCtrlObject*, CFOTabCtrlObject*> m_arTabs;

protected:

	// cool look.
 
	// Correct, This member sets TRUE if it is right.  
	BOOL		m_bCorrect;		

	// Draw Client border around.
 
	// Draw Client Border, This member sets TRUE if it is right.  
	BOOL		m_bDrawClientBorder;   

	// Is flat or not.
 
	// Flat Mode, This member sets TRUE if it is right.  
	BOOL		m_bFlatMode;	
	
	// Is money tab mode.
 
	// Money Mode, This member sets TRUE if it is right.  
	BOOL		m_bMoneyMode;		

	// Money mode extra offset.
 
	// Money Extra Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nMoneyExtraOffset;

	// Need inflating or not.
 
	// Inflating, This member sets TRUE if it is right.  
	BOOL		m_bInflating;	
	
	
	// Current select tab or not.
 
	// Select Tab, This member sets TRUE if it is right.  
	BOOL		m_bSelectTab;		

	// Cursor handle.
 
	// Cursor, This member specify HCURSOR object.  
	HCURSOR		m_hCursor;		

	// Icon size.
 
	// Icon Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nIconSize;		

	// Current active tab index.
 
	// Current Select Tab, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			maCurSelectTab;	

	// Tab height.
 
	// Tab Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTabHeight;		

	// Tab width.
 
	// Tab Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTabWidth;	
	
	// Left start size.
 
	// Left Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLeftStart;		

	// Top start size.
 
	// Top Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTopStart;		

	// Tab separator.
 
	// Tab Separator, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTabSeparator;
	
	// Tab corner size.
 
	// Tab Cornder Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTabCornderSize;	

	// Show label or not.
 
	// Show Tab Labels, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_bShowTabLabels;	
	

	// Active tab font.
 
	// Active Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		maActiveFont;	

	// Inactive tab font.
 
	// In Active Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont		maInActiveFont; 
	
	// Flat pen.
 
	// Flat, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penFlat;		
	
	// Active tab pen.
 
	// Active Tab, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penActiveTab;    

	// Inactive tab pen.
 
	// In Active Tab, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
	CPen		m_penInActiveTab;	

	// Border pen
 
	// Border1, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
    CPen		m_penBorder1;

	// Border pen.
 
	// Border2, The CPen class encapsulates a Windows graphics device interface (GDI) pen.  
    CPen		m_penBorder2;
	
	// Active tab brush.
 
	// Active Tab, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brushActiveTab;	

	// Inactive tab brush.
 
	// In Active Tab, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brushInActiveTab;	

	// Active tab text color.
 
	// Active Tab Text, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crActiveTabText;	

	// Inactive tab text color.
 
	// In Active Tab Text, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crInActiveTabText;	

	// Tab bk color.
 
	// Tab Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTabBkColor;
	
	// Active tab color.
 
	// Active Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crActiveColor;	

	// Inactive tab color.
 
	// In Active Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crInActiveColor;	

	// Flat border line color.
 
	// Flat Border Line, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crFlatBorderLine; 
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTABWNDBUDDY_H__38B479A6_D0E7_11D6_A665_0050BAE30439__INCLUDED_)
