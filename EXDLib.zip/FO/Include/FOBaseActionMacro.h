//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBaseActionMacro.h: interface for the CFOBaseActionMacro class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBASEACTIONMACRO_H__2EEABBEE_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOBASEACTIONMACRO_H__2EEABBEE_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseAction.h"

////////////////////////////////////////////////////////////////////////
// Base class of macro actions.
//
// This is the base class of macro action,

 
//===========================================================================
// Summary:
//     The CFOBaseActionMacro class derived from CFOBaseAction
//      F O Base Action Macro
//===========================================================================

class FO_EXT_CLASS CFOBaseActionMacro : public CFOBaseAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseActionMacro---F O Base Action Macro, Specifies a E-XD++ CFOBaseActionMacro object (Value).
	// DECLARE_DYNAMIC
	DECLARE_DYNAMIC(CFOBaseActionMacro);
public: 

	//-----------------------------------------------------------------------
	// Summary:
	// Get Action ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual unsigned int GetID() const;
		
	// Initialization/Destruction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Action Macro, Destructor of class CFOBaseActionMacro
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseActionMacro();
	
	// Operations
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;
	
	// Override with the name of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		const---Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const = 0;
	// Attributes

	// Returns a pointer to the list of actions. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Action List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CActionList ,or NULL if the call failed
	virtual CActionList *GetActionList();

	// Obtain maximize position, override this method to handle own update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

protected:

	// The list of action
 
	// Actions, This member specify CActionList object.  
	CActionList m_listActions;
};

// Action macro's don't need an ID as the action history will
// call OnActionExecute for each action in the macro.
_FOLIB_INLINE unsigned int CFOBaseActionMacro::GetID() const
{ 
	return (unsigned int)-1; 
}

// Returns a pointer to the list of actions. 
_FOLIB_INLINE CActionList *CFOBaseActionMacro::GetActionList()
{
	return &m_listActions;
}

#endif // !defined(AFX_FOBASEACTIONMACRO_H__2EEABBEE_F19E_11DD_A432_525400EA266C__INCLUDED_)
