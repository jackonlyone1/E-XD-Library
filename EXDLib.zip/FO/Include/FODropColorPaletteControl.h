//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODropColorPaletteControl.h: interface for the CFODropColorPaletteControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODROPCOLORPALETTECONTROL_H__526F9B93_F5BB_11D5_A4D3_525400EA266C__INCLUDED_)
#define AFX_FODROPCOLORPALETTECONTROL_H__526F9B93_F5BB_11D5_A4D3_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOColorCellObj.h"
#include "FOGlobals.h"
#define FO_TOTAL_DROP_COLOR_CELLS		48

 
//===========================================================================
// Summary:
//     The CFODropColorPaletteControl class derived from CObject
//      F O Drop Color Palette 
//===========================================================================

class FO_EXT_CLASS CFODropColorPaletteControl : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODropColorPaletteControl---F O Drop Color Palette , Specifies a E-XD++ CFODropColorPaletteControl object (Value).
	DECLARE_SERIAL(CFODropColorPaletteControl);
public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Color Palette , Constructs a CFODropColorPaletteControl object.
	//		Returns A  value (Object).
	CFODropColorPaletteControl();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Color Palette , Destructor of class CFODropColorPaletteControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropColorPaletteControl();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFODropColorPaletteControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		crDefault---crDefault, Specifies A 32-bit COLORREF value used as a color value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bPopup---bPopup, Specifies A Boolean value.
	// Creates the shape and initializes the data members.
	virtual void Create(CWnd *pWnd,COLORREF crDefault,CRect &rcPos,BOOL bPopup = FALSE);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data
	virtual void Serialize(CArchive &ar);

	// Initialize Color Palette
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Color Palette, Call InitColorPalette after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitColorPalette();

	// Adjust Cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Cells, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual void AdjustCells(CRect rcPos);

	// Compute Colors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Colors, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ComputeColors();

	// Get RectAngle From Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle From Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nX---nX, Specifies A integer value.  
	//		nY---nY, Specifies A integer value.
	int GetAngleFromPoint(int nX, int nY);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Update All
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateAll();

	// Get Current Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get R G B, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetRGB () const				{	return m_crCurColor; }

	// Set Current Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set R G B, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		ref---Specifies A 32-bit COLORREF value used as a color value.
	void		SetRGB(COLORREF ref);

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set H L S, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		hue---Specifies a double hue object(Value).  
	//		luminance---Specifies a double luminance object(Value).  
	//		saturation---Specifies a double saturation object(Value).
	void		SetHLS (double hue,double luminance, double saturation);

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H L S, Returns the specified value.
	// Parameters:
	//		*hue---A pointer to the double  or NULL if the call failed.  
	//		*luminance---A pointer to the double  or NULL if the call failed.  
	//		*saturation---A pointer to the double  or NULL if the call failed.
	void		GetHLS (double *hue,double *luminance, double *saturation);

	// Get Old Colo rRectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Color Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect		GetOldColorRect();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOColorCellObj,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	// HitTest
	virtual CFOColorCellObj* HitTest(CPoint point);

	// Is Popup Style?
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Popup Style, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPopupStyle() const		{ return m_bPopup; }

	// Set Popup Style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Popup Style, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&bPopup---&bPopup, Specifies A Boolean value.
	void		SetPopupStyle(const BOOL &bPopup)	{ m_bPopup = bPopup; }
	
	// Define for WM_TFC_SELECTOK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectOK(WPARAM wParam, LPARAM lParam);
	
	// Define for WM_TFC_SELECTCANCEL message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual void OnSelectCancel(WPARAM wParam, LPARAM lParam);
	
protected:

	// Total Cells
 
	// Cells[ F O_ T O T A L_ D R O P_ C O L O R_ C E L L S], This member specify E-XD++ CFOColorCellObj object.  
	CFOColorCellObj m_crCells[FO_TOTAL_DROP_COLOR_CELLS];

public:

	// virtual void Serialize(CArchive &ar);
	// Save Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open Document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Get File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
	// Set wnd handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetWnd(CWnd *pWnd)					{ m_pParent = pWnd; }
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// Parameters:
	//		bRedraw---bRedraw, Specifies A Boolean value.
	// Invalidates this gadget.
	void Invalidate(BOOL bRedraw = FALSE);
	
	// Update the given rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	void InvalRect(CRect rcPos);
	
	// Capture the mouse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Capture Mouse, .
	// Parameters:
	//		bCapture---bCapture, Specifies A Boolean value.
	void CaptureMouse(BOOL bCapture);
	
	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnRButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	void OnMouseMove(UINT nFlags, CPoint point);

	// WM_KEYDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

	// Get Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Panel Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetPanelRect() const						{ return m_rcPosition; }

	// Set Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Panel Rectangle, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void  SetPanelRect(const CRect &rc)				{ m_rcPosition = rc; }

	// Set Custom Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Text, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void  SetCustomText(const CString &strText )	{ strCustom = strText; }

	// Get Custom Text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Custom Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetCustomText() const				{ return strCustom; }

	// Set Custom Bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Custom Bar, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&bCustom---&bCustom, Specifies A Boolean value.
	void SetCustomBar(const BOOL &bCustom);

	// Set Main Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Border Size, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetMainBorderSize(const int &nBorder);
 
	// Get Main Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Border Size, Returns the specified value.
	//		Returns a int type value.
	int  GetMainBorderSize() const				{ return nMainBorderSize; }

	// Set Cell Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&nBorder---&nBorder, Specifies A integer value.
	void SetCellBorderSize(const int &nBorder);

	// Get Cell Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Border Size, Returns the specified value.
	//		Returns a int type value.
	int GetCellBorderSize() const				{ return nCellBorderSize; }

	// Set Border Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Border Type, Sets a specify value to current class CFODropColorPaletteControl
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetBorderType(const UINT &nType)		{ nBorderType = nType; }

	// Get Border Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetBorderType() const					{ return nBorderType; }

	// Update Custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Custom, Call this member function to update the object.

	void UpdateCustom();

public:
	
	// Draw border for the control.
	// Draw Other Border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Other Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DrawOtherBorder(CDC *pDC,CRect &rcPos,UINT nType);

	// Draw Custom
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bHasColor---Has Color, Specifies A Boolean value.
	virtual void OnCustomDraw(CDC *pDC,BOOL bHasColor);

	// Draw Custom Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnCustomDrawSelect(CDC *pDC);
	
	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).
	void DrawRect(CDC *pDC, RECT rect);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h);

	// Draw a rectangle	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies a RECT rect object(Value).  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, RECT rect, COLORREF color);

	// Draw a rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rectangle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawRect(CDC *pDC, int x, int y, int w, int h, COLORREF color);
	
	// Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.
	void DrawCircle(CDC *pDC, int x, int y, int radius);

	//Draw a circle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Circle, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		radius---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawCircle(CDC *pDC, int x, int y, int radius, COLORREF color);
	
	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end);

	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd);

	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, CPoint& start, CPoint& end, COLORREF color);

	// Draw a line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		xEnd---xEnd, Specifies A integer value.  
	//		yEnd---yEnd, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void DrawLine(CDC *pDC, int xStart, int yStart, int xEnd, int yEnd, COLORREF color);

protected:

	// Compute colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O R G Bto H S L, .
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.  
	//		*H---*H, A pointer to the double  or NULL if the call failed.  
	//		*S---*S, A pointer to the double  or NULL if the call failed.  
	//		*L---*L, A pointer to the double  or NULL if the call failed.
	void FORGBtoHSL(COLORREF rgb, double *H, double *S, double *L );
	
	//-----------------------------------------------------------------------
	// Summary:
	// O H L Sto R G B_ T W O, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		H---H, Specifies a double H object(Value).  
	//		L---L, Specifies a double L object(Value).  
	//		S---S, Specifies a double S object(Value).
	COLORREF FOHLStoRGB_TWO( double H, double L, double S );
	
	//-----------------------------------------------------------------------
	// Summary:
	// O H L Sto R G B_ O N E, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		H---H, Specifies a double H object(Value).  
	//		L---L, Specifies a double L object(Value).  
	//		S---S, Specifies a double S object(Value).
	COLORREF FOHLStoRGB_ONE( double H, double L, double S );
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Hueto R G B, .
	//		Returns An 8-bit BYTE integer that is not signed.  
	// Parameters:
	//		rm1---Specifies A float value.  
	//		rm2---Specifies A float value.  
	//		rh---Specifies A float value.
	BYTE FOHuetoRGB(float rm1, float rm2, float rh);
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Hueto R G B, .
	//		Returns A double value (Object).  
	// Parameters:
	//		m1---Specifies a double m1 object(Value).  
	//		m2---Specifies a double m2 object(Value).  
	//		h---Specifies a double h object(Value).
	double FOHuetoRGB(double m1, double m2, double h );

	// Create validate brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Validate Brush, You construct a CFODropColorPaletteControl object in two steps. First call the constructor, then call Create, which creates the object.

	void			CreateValidateBrush();

	// Do draw gipper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Gipper, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rectGripper---rectGripper, Specifies A CRect type value.
	virtual void		DoDrawGipper(CDC* pDC, CRect rectGripper);

protected:

	// The Rectangle of Cells
 
	// Cells, This member sets a CRect value.  
	CRect				rcCells;
	
	// The Rectangle of Position
 
	// Position, This member sets a CRect value.  
	CRect				m_rcPosition;

	// The Rectangle of Custom
 
	// Custom, This member sets a CRect value.  
	CRect				rcCustom;

	// the Rectangle of Custom Saved
 
	// Custom Save, This member sets a CRect value.  
	CRect				rcCustomSave;

	// Sep Rectangle
 
	// separator, This member sets a CRect value.  
	CRect				rcSep;

	// Current Color
 
	// Current Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crCurColor;

	// The pointer to parent window
 
	// Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*				m_pParent;

	// Is it popup style?
 
	// Popup, This member sets TRUE if it is right.  
	BOOL				m_bPopup;

	// Is it custom selected?
 
	// Custom Select, This member sets TRUE if it is right.  
	BOOL				m_bCustomSelect;

	// Custom string
 
	// Custom, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				strCustom;

	// Rows
 
	// Rows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nRows;

	// Columns
 
	// Cols, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCols;

	// Color Palette Shape
 
	// Shape, This member specify ColorPaletteShape object.  
	ColorPaletteShape	colorShape;

	// Has it custom bar
 
	// Has Custom Bar, This member sets TRUE if it is right.  
	BOOL				bHasCustomBar;

	// Main Border Size
 
	// Main Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nMainBorderSize;

	// Cell Border Size
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nCellBorderSize;

	// Border Type
 
	// Border Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				nBorderType;

	//
 
	// Lum, This member specify double object.  
	double				m_dblLum;

	//
 
	// Sat, This member specify double object.  
	double				m_dblSat;

	//
 
	// Hue, This member specify double object.  
	double				m_dblHue;

};

//Define type CTypedPtrList
typedef CTypedPtrList<CObList, CFODropColorPaletteControl*> CFODropColorPaletteControlList;

#endif // !defined(AFX_FODROPCOLORPALETTECONTROL_H__526F9B93_F5BB_11D5_A4D3_525400EA266C__INCLUDED_)
