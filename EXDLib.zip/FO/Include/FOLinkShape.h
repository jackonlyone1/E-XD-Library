//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOLINKSHAPE_H__A70F8083_C9B4_11D5_A48D_525400EA266C__INCLUDED_)
#define AFC_FOLINKSHAPE_H__A70F8083_C9B4_11D5_A48D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FOBaseEndObject.h"
#include "FODrawPortsShape.h"
#include "FOPortShape.h"

///////////////////////////////////////////////////////////////////////////////////
// CFOLinkShape -- the base class of link shape, link shape has two end ports
//                 one is the start port, and the other is the end port, if a link shape
//                 is linked, the end port or the start port must be not null.
//                 ID: FO_COMP_LINK 91
//
//                 Change property values: P_ID_LINK_LOCK_START, P_ID_LINK_LOCK_END
//                 P_ID_LINK_WITH_LABEL_BORDER, P_ID_LINK_WITH_BRIDGE
//

 
//===========================================================================
// Summary:
//     The CFOLinkShape class derived from CFODrawShape
//      F O Link Shape
//===========================================================================

class FO_EXT_CLASS CFOLinkShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOLinkShape---F O Link Shape, Specifies a E-XD++ CFOLinkShape object (Value).
	DECLARE_SERIAL(CFOLinkShape);

public:
	// Layout forest
	FOPRect		m_rcDraw1;

	// Rect 2.
	FOPRect		m_rcDraw2;

	// Rect 3
	FOPRect		m_rcDraw3;

	// Layout Forest, This member sets TRUE if it is right.  
	BOOL		m_bLayoutForest;
	
	// Layout from column offset
 
	// Layout From Column Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLayoutFromColOffset;
	
	// Layout from position
 
	// Layout From Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLayoutFromPos;
	
	// Layout to column offset
 
	// Layout To Column Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLayoutToColOffset;
	
	// Layout to position
 
	// Layout To Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nLayoutToPos;
	
	// Layout rev
 
	// Layout Rev, This member sets TRUE if it is right.  
	BOOL		m_bLayoutRev;
	
	// Layout valid
 
	// Layout Valid, This member sets TRUE if it is right.  
	BOOL		m_bLayoutValid;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Link Shape, Constructs a CFOLinkShape object.
	//		Returns A  value (Object).
	CFOLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Link Shape, Constructs a CFOLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOLinkShape& src object(Value).
	CFOLinkShape(const CFOLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Link Shape, Destructor of class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Creates the link shape from points.
	// ptArray -- points of link.
	// pFrom -- start link port.
	// pTo -- end link port.
	virtual BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the link shape from points.
	// pptPoints -- points of link.
	// nCount -- total points of link.
	// pFrom -- start link port.
	// pTo -- end link port.
	virtual BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

public:

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get the point of control.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Get start link point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetStartPoint();

	// Get end link point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetEndPoint();

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Obtain nearest intersect point on line.
	// p1 -- line start point.
	// p2 -- line end point.
	// result -- result point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p1---Specifies A CPoint type value.  
	//		&p2---Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	virtual BOOL GetNearestIntersectionPoint(const CPoint &p1, const CPoint &p2, 
		CPoint &result);
	
	// Obtain nearest intersect point on line, with outline support
	// ptCheck -- check point.
	// result -- result point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection Point2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		&ptCheck---&ptCheck, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	virtual BOOL GetNearestIntersectionPoint2(CFOLinkShape *pLink, const CPoint &ptCheck, 
		CPoint &result);
	
	
	// Obtain nearest intersect point on line, with outline support
	// ptCheck -- check point.
	// result -- result point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection Track Point2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptCheck---&ptCheck, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	virtual BOOL GetNearestIntersectionTrackPoint2(const CPoint &ptCheck, 
		CPoint &result);
public:

	// Get the start port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetFromPort() { return m_pFromPort; }

	// Get the End port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get To Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetToPort() { return m_pToPort; }

	// Get third port that lay on.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Third Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *GetThirdPort() { return m_pThirdPort; }

	// Set third port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Third Port, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pLay---*pLay, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual void SetThirdPort(CFOPortShape *pPort, CFOLinkShape *pLay);

	// Get the start port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	virtual CFOPortShape *ToPort() { return m_pToPort; }

	// Get the End port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
    virtual CFOPortShape *FromPort() { return m_pFromPort; }   

	// Get the link that this link is Laying on.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lay On Link, Returns the specified value.
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed
	CFOLinkShape *GetLayOnLink() { return m_pLayOnLink; }

	// Set lay on link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lay On Link, Sets a specify value to current class CFOLinkShape
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	void SetLayOnLink(CFOLinkShape *pLink);

	// Obtain the from node pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// From Node, .
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed
	CFODrawPortsShape *FromNode();
	
	// Obtain the to node pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// To Node, .
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed
	CFODrawPortsShape *ToNode();

	// Obtain the third node pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Third Node, .
	//		Returns a pointer to the object CFODrawPortsShape ,or NULL if the call failed
	CFODrawPortsShape *ThirdNode();

	// Get the start link shape,this is the link line's start point connected shape.
	// If none shape was connected,it returns NULL.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetStartShape();

	// Get the end link shape.
	// This is the link line's end point connected shape
	// If none shape was connected,it returns NULL.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetEndShape();

	// Get link with specify port,it ruturns the connected shape.
	// If pPort is the from port,it returns the start shape that connected,else it will return the connected to
	// shape
	// pPort -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFODrawShape *GetLinkShape(CFOPortShape *pPort);

	// Obtain the shape that is link to with specify port.
	// pPort -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link To Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFODrawShape *GetLinkToShape(CFOPortShape *pPort);

	// Get shape that is linking from with specify port.
	// pPort -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link From Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFODrawShape *GetLinkFromShape(CFOPortShape *pPort);

	// Is this port as from port of this link.
	// pPort -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is From Port, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL IsFromPort(CFOPortShape *pPort);

	// Is this port as to port of this link.
	// pPort -- pointer of port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is To Port, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL IsToPort(CFOPortShape *pPort);

	// Reverse link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reverse Link, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReverseLink();

	// Set label point.
	// pt -- label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Point, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	virtual void SetLabelPoint(CPoint &pt)	{ m_ptLabel = pt; }

	// Relayout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout UpRight state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Up Right, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL MakeUpRight();

	// Relayout UpRight state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Make Up Right, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL TrackMakeUpRight(const int &nIndexMoved = -1);

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Set the start port.
	// pPort -- pointer of the port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set From Port, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetFromPort(CFOPortShape *pPort);

	// Set the End port.
	// pPort -- pointer of the port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set To Port, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void SetToPort(CFOPortShape *pPort);

	// Set the new start link shape, it will relink to the center port of new shape
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Start Shape, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	virtual void SetNewStartShape(CFODrawPortsShape *pShape);

	// Set the new end link shape, it will relink to the center port of new shape
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New End Shape, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	virtual void SetNewEndShape(CFODrawPortsShape *pShape);

	// Get the distance of two point.
	// pt0 -- first point.
	// pt1 -- second point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pt0---Specifies A CPoint type value.  
	//		pt1---Specifies A CPoint type value.
	virtual int GetDistance(const CPoint pt0, const CPoint pt1);

	// Get the line total distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Distance, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetTotalDistance();

	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLabelPoint();

	// Get the label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetUMLCenterPoint(CPoint &ptStart, CPoint &ptEnd);

	// Correct normal point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Point Normal, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptNew---&ptNew, Specifies A CPoint type value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL CorrectPointNormal(int nIndex,CPoint &ptNew,CPoint ptOffset);

	// Correct track point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Point Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptNew---&ptNew, Specifies A CPoint type value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL CorrectPointTrack(int nIndex,CPoint &ptNew,CPoint ptOffset);

	// Is up - right line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Zhi Line, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsZhiLine();

	// Show or hide label back.
	// bShow -- showing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Label Back, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowLabelBack( const BOOL &bShow) { m_bLabelBack = bShow; }

	// Obtain the other node that is linked with this link line.
	// node -- node pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other Node, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		node---A pointer to the CFODrawShape or NULL if the call failed.
	CFODrawShape* GetOtherNode(CFODrawShape* node);

	// Obtain the other node that is linked with this link line.
	// link -- pointer of link shape.
	// node -- pointer of node shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other Node, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		link---A pointer to the CFOLinkShape or NULL if the call failed.  
	//		node---A pointer to the CFODrawShape or NULL if the call failed.
	CFODrawShape* GetOtherNode(CFOLinkShape* link, CFODrawShape* node);

	// Obtain the other port.
	// pPort -- pointer of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		pPort---pPort, A pointer to the CFOPortShape or NULL if the call failed.
	CFOPortShape* GetOtherPort(CFOPortShape* pPort);

	// Obtain the other port of this link.
	// link -- pointer of link shape.
	// pPort -- pointer of port shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		link---A pointer to the CFOLinkShape or NULL if the call failed.  
	//		pPort---pPort, A pointer to the CFOPortShape or NULL if the call failed.
	CFOPortShape* GetOtherPort(CFOLinkShape* link, CFOPortShape* pPort);

	// State type.
	// Get State type,it returns a value from 0 - 5,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get State Type, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetStateType() const;

	// Do sub menu change event.
	// nMenuItem -- menu item.
	// strState -- state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);


	// Break from port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Break From Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void BreakFromPort(CFOPortShape *pPort);

	// Layout all childrens.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Children, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bValidPoint---Valid Point, Specifies A Boolean value.
	virtual void LayoutChildren(const BOOL &bValidPoint = TRUE);

	// Auto layout this link.
	void AutoLayout();

	// Auto layout this link.
	void AutoLayoutTrack();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOLinkShape& src object(Value).
	CFOLinkShape& operator=(const CFOLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

public:

	// Set line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get the line start object point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }

	// Nearest point.
	CPoint NearestPoint(const CPoint &ptCheck, CFOLinkShape *pLinkLayon, 
		int &segment, float &nsegmentPercent);
	
	// Computer connection point.
	CPoint ComputeConnectionPoint( CFOLinkShape *pLinkLayon,int segment, float nsegmentPercent);
	
	// Nearest point.
	CPoint NearestPointTrack(const CPoint &ptCheck, CFOLinkShape *pLinkLayon, 
		int &segment, float &nsegmentPercent);
	
	// Computer connection point.
	CPoint ComputeConnectionPointTrack( CFOLinkShape *pLinkLayon,int segment, float nsegmentPercent);


	// Obtain first pick index
	
	//-----------------------------------------------------------------------
	// Summary:
	// First Pick Index, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int FirstPickIndex();

	// Line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

	// Obtain points by offset.
	// ptStart -- return the start point that this point lie on.
	// ptEnd -- return the end point that this point lie on.
	// nLen -- the length of this point within the full length.
	CPoint GetPointsByOffset(CPoint &ptStart, CPoint &ptEnd, const double &dLen);
		// Remove line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();

	// Remove line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Determine if the handle index is correct or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Port Point, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nHandle---nHandle, Specifies A integer value.
	virtual BOOL IsPortPoint(int nHandle) const;

	// obtain point on.
	CRect GetPointOn(const CPoint &ptCheck);

	// Draw link label box.
	void DoDrawLinkLabelBox(CDC *pDC, const FOPRect &rcTextBox);

	// Correct link box.
	void CorrectLinkBox(FOPRect &rcBox);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect		GetMaxRect();

	// Add a new spot at the end.
	// point -- point that added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Point, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL		AddPoint(const CPoint& point);

	// Add multi points.
	// lpInsertPoints -- points that inserted.
	// nInsertCount -- count of points that inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpInsertPoints---Insert Points, Specifies A LPPOINT Points array.  
	//		nInsertCount---Insert Count, Specifies A integer value.
	virtual BOOL		AddPoints(LPPOINT lpInsertPoints, const int nInsertCount);

	// Add multi points.
	// arPoint -- points that added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Points, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		arPoint---arPoint, Specifies A CPoint type value.
	virtual BOOL		AddPoints(const CArray<CPoint,CPoint>& arPoint);


	// Insert a new spot.
	// nIndex -- index that this point will be inserted.
	// point -- point for inserting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Point, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		point---Specifies A CPoint type value.
	virtual BOOL		InsertPoint(int nIndex, const CPoint& point);

	// Insert multi points.
	// nIndex -- index that these points will be inserted.
	// nInsertCount -- count of points that inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Points, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		lpInsertPoints---Insert Points, Specifies A LPPOINT Points array.  
	//		nInsertCount---Insert Count, Specifies A integer value.
	virtual BOOL		InsertPoints(int nIndex,LPPOINT lpInsertPoints, const int nInsertCount);

	// Insert multi points.
	// nIndex -- index that these points will be inserted.
	// arPoint -- points that will be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Points, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		arPoint---arPoint, Specifies A CPoint type value.
	virtual BOOL		InsertPoints(int nIndex,const CArray<CPoint,CPoint>& arPoint);

	// Delete a specify spot.
	// nIndex -- index for this point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Point, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL		DeletePoint(int nIndex);


	// Is old layout style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Old Layout Style, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsOldLayoutStyle() const { return m_bOldLayout; }

	// Enable old layout style.
	// bOld -- old layout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Old Layout Style, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bOld---&bOld, Specifies A Boolean value.
	void	EnableOldLayoutStyle(const BOOL &bOld) { m_bOldLayout = bOld; }

	// Reset old layout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Old Layout, Called this function to empty a previously initialized CFOLinkShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetOldLayout();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:
	// Offset the current point.
	// nIndex -- index of this handle.
	// ptOffset -- point offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point New1, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPointNew1(int nIndex, CPoint ptOffset);

	// Offset a spot.
	// nIndex -- index of this handle.
	// ptOffset -- point offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	// ptOffset -- point offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);


	// Move the port.
	// pPort -- port pointer.
	// ptOffset -- point offseted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pPort---pPort, A pointer to the CFOPortShape or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL MovePort(CFOPortShape* pPort, CPoint ptOffset);

	// Offset port point.
	// pPort -- port pointer.
	// ptOffset -- point offseted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL PortTrackOffsetPoint(CFOPortShape *pPort,CPoint ptOffset);

	// Offset a spot.
	// pPort -- port pointer.
	// ptOffset -- point offseted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL PortOffsetPoint(CFOPortShape *pPort,CPoint ptOffset);

	// Port local point.
	// pPort -- port pointer.
	// ptOffset -- point offseted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Local Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL PortLocalPoint(CFOPortShape *pPort,CPoint ptPoint);

	// Obtain fixed layout value.
	float GetLayValue();

public:

	// Track Port local point.
	// pPort -- port pointer.
	// ptOffset -- point offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Port Local Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL TrackPortLocalPoint(CFOPortShape *pPort,CPoint ptPoint);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point New1, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPointNew1(int nIndex, CPoint ptOffset);

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);


	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Only Link Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOnlyLinkPoints(CPoint ptOffset,CPoint ptScroll);

	// Update link point,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Other Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdateOtherPoints();

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Other Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOtherPoints(CPoint ptOffset,CPoint ptScroll);


	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Link Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackLinkOffsetPoint(int nIndex, CPoint ptOffset);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	// Offset the current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL PortTrackOffsetPoint(CFOPortShape *pPort,int nIndex, CPoint ptOffset);

	// Offset all spots.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Port Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void PortTrackOffsetAllPoints(CFOPortShape *pPort,CPoint ptOffset,CPoint ptScroll);

public:
	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Merge bridges.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Merge Near Bridges, .
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		*pLineBridge---Line Bridge, A pointer to the CFOLineBridge  or NULL if the call failed.  
	//		*line---A pointer to the CFOLineConnect  or NULL if the call failed.  
	//		&fOffset1---&fOffset1, Specifies A float value.  
	//		&fBridge2---&fBridge2, Specifies A float value.
	void FOPMergeNearBridges( int &nIndex, CFOLineBridge *pLineBridge, CFOLineConnect *line,
					  float &fOffset1, float &fBridge2 );

	// Drawing test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Test Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnTestDraw(CDC *pDC);

	// Update segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Segment Bridges, Call this member function to update the object.
	// Parameters:
	//		*segment---A pointer to the CFOLineConnect  or NULL if the call failed.  
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.
	void UpdateSegmentBridges( CFOLineConnect *segment, CFOLinkShape *pLink);

	// Drawing test route line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Test Route Line, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&pt1---Specifies A CPoint type value.  
	//		&ptCenter---&ptCenter, Specifies A CPoint type value.  
	//		&pt4---Specifies A CPoint type value.
	void DrawTestRouteLine(CDC *pDC,const CPoint &pt1,const CPoint &ptCenter,const CPoint &pt4);

	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Track Pen Object, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseTrackPenObject();

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// drawing uml link arrow.
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawUMLArrow(CDC *pDC);

	// draw arrow.
	void DoDrawUMLArrow(CDC *pDC, const CPoint &ptStart, const CPoint &ptEnd, const CPoint &ptAt);

	// draw arrow.
	void OnDrawUMLLabel(CDC *pDC);

	// Obtain UML label point1.
	CPoint GetUMLLablePt1();

	// Obtain UML label point2
	CPoint GetUMLLablePt2();

	// draw label1.
	void DrawLabel1(CDC *pDC);

	// Draw label2
	void DrawLabel2(CDC *pDC);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object, mostly it is end arrow for this link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Create up - right line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Up Right Mode Line, You construct a CFOLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CreateUpRightModeLine();

	// Create up - right tacking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Up Right Mode Track Line, You construct a CFOLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CreateUpRightModeTrackLine();

	// Obtain point with control handle index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		nControlPoint---Point, Specifies A integer value.
	virtual CPoint GetCurrentPoint(const CRect& rcPos, FO_CONTROL_HANDLE nControlPoint);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

	// Search and add new property object, override this method to add as many customize property values as you want.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

public:
	
	// Do end property change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

	// Obtain point by percent from 0-1.0
	CPoint GetLayPoint(float fPercent);

	// Obtain point's percent 0-1.0
	double GetLayPercent(const CPoint &pt);

	// Update layout percent.
	void DoUpdateLayPercent(CFOLinkShape *pLay,const CPoint &pt);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif


public:

	// Get start link port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Port Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetStartPortName() const { return m_strStartPortName; }

	// Get end link port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Port Name, Returns the specified value.
	//		Returns a CString type value.
	CString GetEndPortName() const { return m_strEndPortName; }

	// Set start link port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start Port Name, Sets a specify value to current class CFOLinkShape
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	void SetStartPortName(const CString &strName) {  m_strStartPortName = strName; }

	// Set end link port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Port Name, Sets a specify value to current class CFOLinkShape
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	void SetEndPortName(const CString &strName) { m_strEndPortName = strName; }

	// Is start link locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Start Link Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsStartLinkLocked() const;

	// Set start link locked, if it is locked, it can not be broken.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Start Link, .
	// Parameters:
	//		&bLock---&bLock, Specifies A Boolean value.
	void LockStartLink(const BOOL &bLock);

	// Is end link locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is End Link Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEndLinkLocked() const;

	// Set end link locked, if it is locked, it can not be broken
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock End Link, .
	// Parameters:
	//		&bLock---&bLock, Specifies A Boolean value.
	void LockEndLink(const BOOL &bLock);

	// Obtain link index ids.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index I D, Returns the specified value.
	// Parameters:
	//		&nStartShapeID---Start Shape I D, Specifies A integer value.  
	//		&nEndShapeID---End Shape I D, Specifies A integer value.  
	//		&nStartPortID---Start Port I D, Specifies A integer value.  
	//		&nEndPortID---End Port I D, Specifies A integer value.  
	//		&nLayOnLinkID---Lay On Link I D, Specifies A integer value.
	void GetIndexID(int &nStartShapeID,int &nEndShapeID,int &nStartPortID,int &nEndPortID,int &nLayOnLinkID);

	// Reset all the index of the link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Index, Called this function to empty a previously initialized CFOLinkShape object.

	void ResetAllIndex();

	// Is enable point edit or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Point Edit, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowPointEdit() const { return m_bEnablePointEdit; }

	// Enable point edit or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Point Edit, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnablePointEdit(const BOOL &bEnable) { m_bEnablePointEdit = bEnable; }

	// Is show label with border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Show Label Border, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShowLabelBorder() const;

	// Enable to show label with border or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Label Border, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowLabelBorder(const BOOL &bShow);

	// Is enable link bridge or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Support Bridge, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSupportBridge() const;

	// Enable show bridge or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Bridge, Call this function to show the specify object.
	// Parameters:
	//		&bShow---&bShow, Specifies A Boolean value.
	void ShowBridge(const BOOL &bShow);

public:
	// UML label 1
	CSize szUMLLabel1;

	// UML label 2
	CSize szUMLLabel2;

	// lay on link percent.
	float m_fOnPercent;

	// Link from this object...
 
	// From Port, This member maintains a pointer to the object CFOPortShape.  
    CFOPortShape*   m_pFromPort;           

	// to this object
 
	// To Port, This member maintains a pointer to the object CFOPortShape.  
    CFOPortShape*   m_pToPort;  

	// Third to port.
 
	// Third Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape *	m_pThirdPort;

	// Lay on link shape.
 
	// Lay On Link, This member maintains a pointer to the object CFOLinkShape.  
	CFOLinkShape *	m_pLayOnLink;

	// Current label point.
 
	// Label, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLabel;

	// Shape position.
 
	// Link Label, This member sets a CRect value.  
	CRect			rcLinkLabel;

	// Save start port name.
 
	// Start Port Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strStartPortName;

	// Save end port name.
 
	// End Port Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strEndPortName;

	// Distance between port and link.
 
	// Space Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSpaceValue;

	// Link label with background.
 
	// Label Back, This member sets TRUE if it is right.  
	BOOL			m_bLabelBack;
	
	// Defined for rebuild link
	// Link start port's parent shape ID
 
	// Start Shape I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nStartShapeID;

	// Link end port's parent shape ID
 
	// End Shape I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nEndShapeID;

	// Link start port's ID
 
	// Start Port I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nStartPortID;

	// Link end port's ID
 
	// End Port I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nEndPortID;

	// Link Third port's ID
 
	// Third Port I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nThirdPortID;
	
	// Link Third port's ID
 
	// Third Shape I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nThirdShapeID;

	// int Lay on link ID.
 
	// Lay On Link I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayOnLinkID;


	// Enable points editing or not.
 
	// Enable Point Edit, This member sets TRUE if it is right.  
	BOOL			m_bEnablePointEdit;

protected:

	// With old layout style.
 
	// Old Layout, This member sets TRUE if it is right.  
	BOOL			m_bOldLayout;

	// Line width = 1,label border pen.
 
	// Border Pen, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData	m_pBorderPen;

};

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOPipeLinkShape -- pipe link line shape ID: FO_COMP_PIPE_LINKSHAPE 268
// Author: Author Name. Class CFOPipeLinkShape
// Change the property value: P_ID_PIPE_LINE_WIDTH to change the pipe width.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOPipeLinkShape class derived from CFOLinkShape
//      F O Pipe Link Shape
//===========================================================================

class FO_EXT_CLASS CFOPipeLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPipeLinkShape---F O Pipe Link Shape, Specifies a E-XD++ CFOPipeLinkShape object (Value).
	DECLARE_SERIAL(CFOPipeLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pipe Link Shape, Constructs a CFOPipeLinkShape object.
	//		Returns A  value (Object).
	CFOPipeLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	/// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pipe Link Shape, Constructs a CFOPipeLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPipeLinkShape& src object(Value).
	CFOPipeLinkShape(const CFOPipeLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pipe Link Shape, Destructor of class CFOPipeLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPipeLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPipeLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the link shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPipeLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPipeLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPipeLinkShape& src object(Value).
	CFOPipeLinkShape& operator=(const CFOPipeLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re calc extend bound rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

	// Relayout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pipe Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetPipeLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pipe Line Width, Sets a specify value to current class CFOPipeLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPipeLineWidth( const int &nValue );

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOArrowFlowLinkShape -- arrow flow link line shape ID: FO_COMP_PIPE_LINKSHAPE 332
// Author: Author Name. Class CFOArrowFlowLinkShape
// Change the property value: P_ID_PIPE_LINE_WIDTH to change the pipe width.
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFOArrowFlowLinkShape class derived from CFOLinkShape
//      F O Arrow Flow Link Shape
//===========================================================================

class FO_EXT_CLASS CFOArrowFlowLinkShape : public CFOLinkShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOArrowFlowLinkShape---F O Arrow Flow Link Shape, Specifies a E-XD++ CFOArrowFlowLinkShape object (Value).
	DECLARE_SERIAL(CFOArrowFlowLinkShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Arrow Flow Link Shape, Constructs a CFOArrowFlowLinkShape object.
	//		Returns A  value (Object).
	CFOArrowFlowLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	/// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Arrow Flow Link Shape, Constructs a CFOArrowFlowLinkShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOArrowFlowLinkShape& src object(Value).
	CFOArrowFlowLinkShape(const CFOArrowFlowLinkShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Arrow Flow Link Shape, Destructor of class CFOArrowFlowLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOArrowFlowLinkShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOArrowFlowLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// Create the link shape from a CRect object.
	BOOL Create(CArray<CPoint,CPoint>* ptArray,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOArrowFlowLinkShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	// .Create
	BOOL Create(LPPOINT pptPoints, int nCount,CFOPortShape *pFrom = NULL,CFOPortShape *pTo = NULL);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOArrowFlowLinkShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOArrowFlowLinkShape& src object(Value).
	CFOArrowFlowLinkShape& operator=(const CFOArrowFlowLinkShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Re calc extend bound rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

	// Relayout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL RelayoutPoints();

	// Relayout track state points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relayout Track Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexMoved---Index Moved, Specifies A integer value.
	virtual BOOL RelayoutTrackPoints(const int &nIndexMoved = -1);

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOArrowFlowLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOArrowFlowLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Build current line end object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

	// Return nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pipe Line Width, Returns the specified value.
	//		Returns a int type value.
	int GetPipeLineWidth();
	
	// Change nNewLineWidth value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pipe Line Width, Sets a specify value to current class CFOArrowFlowLinkShape
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetPipeLineWidth( const int &nValue );

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Do draw high light like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawHighLightLine(CDC *pDC);

	// Count center of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Count Centre2, .
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nStep---nStep, Specifies A integer value.  
	//		&centerPoint---&centerPoint, Specifies A CPoint type value.  
	//		&nIndex---&nIndex, Specifies A integer value.
	void CountCentre2(LPPOINT lpPoints,int nStep,CPoint &centerPoint, int &nIndex);
	
	// Count center of the component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Count Centre, .
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nStep---nStep, Specifies A integer value.  
	//		&centerPoint---&centerPoint, Specifies A CPoint type value.  
	//		&nIndex---&nIndex, Specifies A integer value.
	void CountCentre(LPPOINT lpPoints,int nStep,CPoint &centerPoint, int &nIndex);
	
	// Reposition current component.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Count Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		centerPoint---centerPoint, Specifies A CPoint type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void CountPosition(CPoint centerPoint,CRect &rcPos);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		pt2---Specifies A CPoint type value.
	// Get distance of two point.
	virtual int Distance(CPoint pt1,CPoint pt2);
	
	// Get total distance of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Distance, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		m_nCompPtCount---Component Point Count, Specifies A integer value.
	virtual int	GetTotalDistance(LPPOINT lpPoints,int m_nCompPtCount);
	
	// Get label point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		m_nCompPtCount---Component Point Count, Specifies A integer value.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&nxxx---Specifies A integer value.  
	//		nLength---nLength, Specifies A integer value.  
	//		&nIndex---&nIndex, Specifies A integer value.
	virtual void GetXPoint(LPPOINT lpPoints,int m_nCompPtCount,CPoint &pt1,CPoint &pt2,int &nxxx,int nLength, int &nIndex);
	
	// Drawing sign mark.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Sign Mark, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&bVert---&bVert, Specifies A Boolean value.
	virtual void OnDrawSignMark(CDC *pDC, const CRect &rcPos, const CPoint &pt1, const CPoint &pt2, const BOOL &bVert = FALSE);
	
	// Draw arrow flow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Flow, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void DoDrawFlow(CDC *pDC);
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 

	void DoStartTimer();
	
	// Set wnd handle.
	// pWnd -- pointer of parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOArrowFlowLinkShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pWnd);
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOArrowFlowLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);
	
	// Do animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

public:
	// Shift value.
 
	// Shift, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nShift;
	
	// animate
 
	// Animate, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAnimate;
	
	// wide
 
	// Wide, This member sets TRUE if it is right.  
	BOOL				m_bWide;
	
	// Current timer ID
 
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;
	
	// Current timer speed, default is 400
 
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;

	// The second start value.
 
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

};

#endif // !defined(AFC_FOLINKSHAPE_H__A70F8083_C9B4_11D5_A48D_525400EA266C__INCLUDED_)
