//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPARROWPICKERDRAWPANEL_H__270798E7_6BAB_4E73_9B5F_D7AE339B45B9__INCLUDED_)
#define AFX_FOPARROWPICKERDRAWPANEL_H__270798E7_6BAB_4E73_9B5F_D7AE339B45B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPArrowPickerDrawPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPArrowPickerDrawPanel window
#include "FOPDrawControlPanel.h"

const unsigned FOP_MSG__ARROW_CHANGE	= 1;
const unsigned FOP_MSG__ARROW_CYCLE		= 2;
const unsigned FOP_MSG__ARROW_NONE		= 3;
const unsigned FOP_MSG__ARROW_CUSTOM	= 4;
const unsigned FOP_MSG__ARROW_CANCEL	= 5;
const unsigned FOP_MSG__ARROW_BUTTON2	= 6;

// Arrow table entry
struct FOPArrowTableEntry 
{
	// Arrow value.
    int			nArrow;

	// Arrow name.
    LPCTSTR		szName;
};

///////////////////////////////////////////////////////////////////////////
//

 
//===========================================================================
// Summary:
//     The FOPArrowDrawPanel class derived from FOPDrawControlPanel
//      O P Arrow Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPArrowDrawPanel : public FOPDrawControlPanel
{
public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Arrow Draw Panel, Constructs a FOPArrowDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = HeaderBarOne object(Value).  
	//		but---Specifies a HasButton but = ButtonOne object(Value).
					FOPArrowDrawPanel(HasHeaderBar ind = HeaderBarOne, 
						HasButton but = ButtonOne);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Arrow Draw Panel, Destructor of class FOPArrowDrawPanel
	//		Returns A  value (Object).
					~FOPArrowDrawPanel();
	
	// virtual functions called from FOPPickerBaseWnd

	// Get main group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetMainGroupName(int nIndex);

	// Get extra group name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extra Group Name, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const CString	GetExtraGroupName(int nIndex);

	// Draw main group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Main Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawMainGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	// Draw extra group face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Extra Group Face, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		enabled---Specifies A Boolean value.
	void			DrawExtraGroupFace(CDC& dc, CRect& rc, int nIndex, BOOL  enabled);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		DC---C, Specifies a CDC& DC object(Value).  
	//		rect---Specifies A CRect type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		transparent---Specifies A Boolean value.  
	//		focus---Specifies A Boolean value.  
	//		enabled---Specifies A Boolean value.
	// Do draw mode
	virtual void	Draw(CDC& DC, const CRect& rect, int nIndex, BOOL  transparent = FALSE, 
		BOOL  focus = FALSE, BOOL  enabled = TRUE);

	// Notify.
	// Notify cancel actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Cancel, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyCancel(BOOL  IsPopup);

	// Notify button press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Button Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyButtonPressed(int nIndex, BOOL  IsPopup);

	// Notify headerbar press action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Header Bar Pressed, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyHeaderBarPressed(int nIndex, BOOL  IsPopup);

	// Notify select main group well action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Main Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellMainGroupSelected(int nIndex, BOOL  IsPopup);

	// Notify select extra group well action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Well Extra Group Selected, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		IsPopup---Is Popup, Specifies A Boolean value.
	virtual BOOL 	NotifyWellExtraGroupSelected(int nIndex, BOOL  IsPopup);

	// Is main group enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Main Group Enabled, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL 	IsMainGroupEnabled(int nIndex);

	// Get transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparency, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL 			GetTransparency()			{	return m_bTransparent;	}

	// Set transparency
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparency, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		bTransparent---bTransparent, Specifies A Boolean value.
	void			SetTransparency(BOOL  bTransparent)	{	m_bTransparent = bTransparent;	}

	// Get pen width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Width, Returns the specified value.
	//		Returns a int type value.
	int				GetPenWidth() const 		{	return m_nPenWidth;	}	

	// Set pen width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Width, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	void			SetPenWidth(int nIndex)			{	m_nPenWidth = nIndex;		}

	// assessor functions

	// Get arrow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrows, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	const int&		GetArrows(int nIndex) const		{	return arArrows[nIndex].nArrow;	}

	// Get arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow, Returns the specified value.
	//		Returns a int type value.
	int				GetArrow();

	// Get fill back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fill Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetFillColor() const;

	// helper function
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format Arrow String, .
	//		Returns a CString type value.  
	// Parameters:
	//		msg---Specifies A CString type value.  
	//		nArrow---nArrow, Specifies A integer value.
	CString			FormatArrowStr(CString msg, int nArrow);

	// Set arrow
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		nArrow---nArrow, Specifies A integer value.
	void			SetArrow(const int& nArrow);

	// for arrows not in the standard set but user-selected, e.g. via "More..."
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Header Bar State, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind object(Value).
	void			SetHeaderBarState(HasHeaderBar ind);

	// Set sunken draw mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Sunken Mode, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		b---Specifies A Boolean value.
	void			SetSunkenMode(BOOL  b);

	// response functions
	// Do when arrow change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Arrow Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void	DoWellArrowChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCancel();

	// Do when choosing custom arrow button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Arrow, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellCustomArrow();

	// Do when choosing none arrow button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Arrow None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoWellArrowNone();
	
	// None arrow value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow None, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.
	static const int	GetArrowNone()		{	return (int) -1; }

	// Total number of arrows.
	enum { DefaultArrowPickers = 40 };

	// Change end style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Style, Sets a specify value to current class FOPArrowDrawPanel
	// Parameters:
	//		&bEnd---&bEnd, Specifies A Boolean value.
	void SetEndStyle(const BOOL &bEnd) { m_bEndStyle = bEnd; }

protected:
	// Number of arrows.
 
	// Total Arrows, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nTotalArrows;

	// Arrows
 
	// Arrows, This member maintains a pointer to the object FOPArrowTableEntry.  
	FOPArrowTableEntry*				arArrows;

	// Default arrows.
 
	// Default Arrows[ Default Arrow Pickers], This member specify FOPArrowTableEntry object.  
	static FOPArrowTableEntry		arDefaultArrows[DefaultArrowPickers];

	// Transparent or not.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL 							m_bTransparent;

	// Pen width
 
	// Pen Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								m_nPenWidth;

	// End arrow style.
 
	// End Style, This member sets TRUE if it is right.  
	BOOL							m_bEndStyle;

};

// DDX
void DDX_ArrowWell(CDataExchange* pDX, FOPArrowDrawPanel& w, int& nWidth);

struct FOPDropArrowCallback
{
	// Do when arrow type change.
	virtual void	OnWellArrowChange(const int& nWidth) = 0;

	// Do when cancel action.
	virtual void	OnWellCancel() = 0;

	// Do when custom arrow action.
	virtual void	OnWellCustomArrow() = 0;

	// Do when choosing none arrow action.
	virtual void	OnWellArrowNone() = 0;
};

 
//===========================================================================
// Summary:
//     The FOPDropArrowPickerDrawPanel class derived from FOPArrowDrawPanel
//      O P Drop Arrow Picker Draw Panel
//===========================================================================

class FO_EXT_CLASS FOPDropArrowPickerDrawPanel : public FOPArrowDrawPanel
{
public:
	// response functions
	// Do when arrow changing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Arrow Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWidth---nWidth, Specifies A integer value.
	virtual void DoWellArrowChange(const int& nWidth);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Cancel, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCancel();

	// Do when choosing custom arrow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Custom Arrow, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellCustomArrow();

	// Do when choosing none arrow action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Well Arrow None, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWellArrowNone();

	// Set call back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Button, Sets a specify value to current class FOPDropArrowPickerDrawPanel
	// Parameters:
	//		pPicker---pPicker, A pointer to the FOPDropArrowCallback or NULL if the call failed.
	void SetButton(FOPDropArrowCallback* pPicker)	{	m_pPicker = pPicker;	}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Arrow Picker Draw Panel, Constructs a FOPDropArrowPickerDrawPanel object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ind---Specifies a HasHeaderBar ind = NoHeaderBar object(Value).  
	//		but---Specifies a HasButton but = NoButton object(Value).  
	//		btn---A pointer to the FOPDropArrowCallback or NULL if the call failed.
	FOPDropArrowPickerDrawPanel(HasHeaderBar ind = NoHeaderBar,
		HasButton but = NoButton, FOPDropArrowCallback* btn = 0);

	
protected:

	// Drop arrow call back.
 
	// Picker, This member maintains a pointer to the object FOPDropArrowCallback.  
	FOPDropArrowCallback* m_pPicker;
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPARROWPICKERDRAWPANEL_H__270798E7_6BAB_4E73_9B5F_D7AE339B45B9__INCLUDED_)
