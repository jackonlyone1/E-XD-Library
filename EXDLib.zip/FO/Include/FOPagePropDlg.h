//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPAGEPROPDLG_H__19611891_DEEE_11D5_A4AD_525400EA266C__INCLUDED_)
#define AFX_FOPAGEPROPDLG_H__19611891_DEEE_11D5_A4AD_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPagePropDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////

// CFOPagePropDlg dialog
#include "FOPDropDownColorPickerButton.h"
#include "FOGlobals.h"
#include "FOFillSampleButton.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOPagePropDlg class derived from CDialog
//      F O Page Property Dialog
//===========================================================================

class FO_EXT_CLASS CFOPagePropDlg : public CDialog
{
 
	// Construction
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Page Property Dialog, Constructs a CFOPagePropDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPagePropDlg(CWnd* pParent = NULL);   // standard constructor

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Dialog Data
	//{{AFX_DATA(CFOPagePropDlg)
	enum { IDD = IDD_FO_PAGE_SETTING };
 
	// Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnColor;
 
	// Background, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_btnBackground;
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
	//}}AFX_DATA

	// Color select button.
 
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	

	// Page background color.
 
	// Page Back, This member sets A 32-bit value used as a color value.  
	COLORREF m_crPageBack;

	// Pattern color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crFG;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBK;

	//Brush Type
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;


 
	// Old Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strOldCaption;

	// Page background color.
 
	// Old Page Back, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldPageBack;

	// Pattern color.
 
	// Old F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldFG;

	// Background color.
 
	// Old B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldBK;

	//Brush Type
 
	// Old Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldBrushType;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

	//
 
	// Is Axis Up, This member sets TRUE if it is right.  
	BOOL	m_bIsAxisUp;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPagePropDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPagePropDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Fill Effect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFillEffect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Single Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSingleColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Gad Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGadColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelectColorChange();

	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPAGEPROPDLG_H__19611891_DEEE_11D5_A4AD_525400EA266C__INCLUDED_)
