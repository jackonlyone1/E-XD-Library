//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOActionStack.h: interface for the CFOActionStack class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOACTIONSTACK_H__17272EF6_8BF6_11D6_A5EA_525400EA266C__INCLUDED_)
#define AFX_FOACTIONSTACK_H__17272EF6_8BF6_11D6_A5EA_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXTEMPL_H__
#include <afxtempl.h>
#endif

#define ARRAY_MAX_SIZE 10000

template <class object, class var> 
 
//===========================================================================
// Summary:
//     The CFOActionStack class derived from CArray<object
//      F O Action Stack
//===========================================================================

class CFOActionStack : 
public CArray<object, var>
{
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOActionStack<object, value (Object).
	CFOActionStack<object, var>()
	{
		m_nIndex = -1;
		m_nElem = 0;
		m_ArraySize = -1;
	}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOActionStack<object, value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A 32-bit long signed integer.
	CFOActionStack<object, var>(long nSize)
	{
		m_nIndex = -1;
		m_nElem = 0;
		SetMaxSize(nMaxSize);
	}

	// Find index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// findIndex, .
	//		Returns a int type value.  
	// Parameters:
	//		nCurIndex---Current Index, Specifies A integer value.
	int		findIndex(const int nCurIndex)
	{
		nCurIndex;
	}

	// Get minimize index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimize Index, .
	//		Returns a int type value.
	int		getMinIndex() const { return m_MinSize; }

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A object value (Object).
	// Peek
	object	peek() const;

	// Peek at object
	
	//-----------------------------------------------------------------------
	// Summary:
	// peekAt, .
	//		Returns A object value (Object).  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	object	peekAt(const int nIndex) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A object value (Object).  
	// Parameters:
	//		elem---Specifies a object elem object(Value).
	// push
	object	push(object elem);

	// push
	
	//-----------------------------------------------------------------------
	// Summary:
	// pushNew, .
	// Parameters:
	//		elem---Specifies a object elem object(Value).
	void	pushNew(object elem);

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A object value (Object).
	// pop action
	object	pop();

	// Change size
	
	//-----------------------------------------------------------------------
	// Summary:
	// setSize, .
	// Parameters:
	//		nSize---nSize, Specifies A 32-bit long signed integer.
	void	setSize(long nSize);

	// Get size
	
	//-----------------------------------------------------------------------
	// Summary:
	// getSize, .
	//		Returns A 32-bit long signed integer.
	long	getSize() const { return m_ArraySize; }

	// Get element count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Element Count, .
	//		Returns a int type value.
	int		getElementCount() const;

	// Get total count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Total Count, .
	//		Returns a int type value.
	int     getTotalCount() const { return m_nIndex; }

protected:
 
	// This member maintains a pointer to the object object.  
	object *vect ;
 
	// Specify a A 32-bit signed integer.  
	long top;
 
	// Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nIndex;
 
	// Elem, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nElem;
 
	// Current Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nCurIndex;
 
	// Array Size, Specify a A 32-bit signed integer.  
	long m_ArraySize;
 
	// Minimize Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_MinSize;
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString strName;
};

template <class Object> 
 
//===========================================================================
// Summary:
//      To use a CFOSmartPtr object, just call the constructor.
//      F O Smart Pointer
//===========================================================================

class CFOSmartPtr
{
public:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Smart Pointer, Constructs a CFOSmartPtr object.
	//		Returns A  value (Object).
	CFOSmartPtr();

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Smart Pointer, Constructs a CFOSmartPtr object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&data---Specifies a const CFOSmartPtr &data object(Value).
	CFOSmartPtr( const CFOSmartPtr &data );

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Smart Pointer, Constructs a CFOSmartPtr object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pObj---*pObj, A pointer to the Object  or NULL if the call failed.
	CFOSmartPtr( Object *pObj );

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Smart Pointer, Destructor of class CFOSmartPtr
	//		Returns A  value (Object).  
	// Parameters:
	//		void---void
	~CFOSmartPtr(void);


	// Assign method
	
	//-----------------------------------------------------------------------
	// Summary:
	// __Assign, .
	// Parameters:
	//		pObj---pObj, A pointer to the Object or NULL if the call failed.
	void __Assign(Object* pObj);

	// operator = 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOSmartPtr& value (Object).  
	// Parameters:
	//		pObj---pObj, A pointer to the Object or NULL if the call failed.
	CFOSmartPtr& operator=(Object* pObj );

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOSmartPtr& value (Object).  
	// Parameters:
	//		&data---Specifies a const CFOSmartPtr &data object(Value).
	CFOSmartPtr& operator=(const CFOSmartPtr &data );

	// operator *
	
	//-----------------------------------------------------------------------
	// Summary:
	// Object, .
	//		Returns A operator value (Object).
	operator Object*() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A Object& value (Object).
	// operator *
	Object& operator*();

	// operator ->
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object Object,or NULL if the call failed
	Object* operator->() const;

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&data---Specifies a const CFOSmartPtr &data object(Value).
	BOOL operator==(const CFOSmartPtr &data );

	// operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pObj---*pObj, A pointer to the Object  or NULL if the call failed.
	BOOL operator==(Object *pObj );

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&data---Specifies a const CFOSmartPtr &data object(Value).
	BOOL operator!=(const CFOSmartPtr &data );

	// operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pObj---*pObj, A pointer to the Object  or NULL if the call failed.
	BOOL operator!=(Object *pObj );

private:
 
	// This member maintains a pointer to the object Object.  
	Object *__m_refcount;
};

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>::CFOSmartPtr()	
{ __m_refcount = NULL; }

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>::CFOSmartPtr( const CFOSmartPtr &data ) 
{__m_refcount = NULL;__Assign(data.__m_refcount);}

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>::CFOSmartPtr( Object *pObj ) 
{ __m_refcount = NULL; __Assign(pObj); }

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>::~CFOSmartPtr(void) 
{ 
	if( __m_refcount != 0 ){__m_refcount->Release();} 
}

//---------------------------------------------------------------//
template <class Object> 
void CFOSmartPtr<Object>::__Assign(Object* pObj)
{
	if(pObj!=NULL)
	{
		pObj->AddRef();
	}

	if(__m_refcount!=NULL)
	{
		__m_refcount->Release();
	}
	__m_refcount = pObj;
}

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>& CFOSmartPtr<Object>::operator=(Object* pObj )				
{ __Assign(pObj);	return *this; }

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>& CFOSmartPtr<Object>::operator=(const CFOSmartPtr &data )	
{	__Assign(data.__m_refcount); return *this;	}

//---------------------------------------------------------------//
template <class Object> 
CFOSmartPtr<Object>::operator Object*() const							
{ return __m_refcount; }

//---------------------------------------------------------------//
template <class Object> 
Object& CFOSmartPtr<Object>::operator*()									
{ return *__m_refcount; }

//---------------------------------------------------------------//
template <class Object> 
Object* CFOSmartPtr<Object>::operator->() const							
{ return __m_refcount; }

//---------------------------------------------------------------//
template <class Object> 
BOOL CFOSmartPtr<Object>::operator==(const CFOSmartPtr &data )			
{	return ( __m_refcount == data.__m_refcount );	}

//---------------------------------------------------------------//
template <class Object> 
BOOL CFOSmartPtr<Object>::operator==(Object *pObj )						
{ return ( __m_refcount == pObj );}

//---------------------------------------------------------------//
template <class Object> 
BOOL CFOSmartPtr<Object>::operator!=(const CFOSmartPtr &data )			
{	return ( __m_refcount != data.__m_refcount ); }

//---------------------------------------------------------------//
template <class Object> 
BOOL CFOSmartPtr<Object>::operator!=(Object *pObj )						
{ return ( __m_refcount != pObj );}


/////////////////////////////////////////////////////////////////
// Class CFOActionStack
/////////////////////////////////////////////////////////////////

template <class object, class var> 
void CFOActionStack<object, var>::setSize(long nMaxSize) 
{
	m_ArraySize = nMaxSize;
	SetSize(m_ArraySize);
}

template <class object, class var> 
int CFOActionStack<object, var>::getElementCount() const 
{
	return m_nElem;
}

template <class object, class var> 
object CFOActionStack<object, var>::push(object elem) 
{
	object oldElem;
	m_nIndex = ( (m_nIndex+1) % m_ArraySize );
	oldElem = GetAt(m_nIndex);
	SetAt(m_nIndex, elem);
	m_nElem++;
	if(m_nElem < m_ArraySize)
	{
		m_nElem = m_nElem;
	}
	else
	{
		m_nElem = m_ArraySize;
	}
	return oldElem;
}

template <class object, class var> 
object CFOActionStack<object, var>::peek() const 
{
	if(m_nIndex >= 0 && m_nIndex < m_ArraySize)
	{
		return GetAt(m_nIndex);
	}

	return NULL;
}

template <class object, class var> 
object	CFOActionStack<object, var>::peekAt(const int nIndex) const
{
	if(nIndex >= 0 && nIndex < m_ArraySize)
	{
		return GetAt(nIndex);
	}

	return NULL;
}

template <class object, class var> 
object CFOActionStack<object, var>::pop() 
{
	object elem;
	if (m_nElem > 0) 
	{
		elem = GetAt(m_nIndex);
		SetAt(m_nIndex, NULL);
		m_nIndex = ( (m_nIndex-1) % m_ArraySize );
		if (m_nIndex < 0)
		{
			m_nIndex = m_ArraySize-1;
		}

		m_nElem--;
		if(m_nElem > 0)
		{
			m_nElem = m_nElem;
		}
		else
		{
			m_nElem = 0;
		}
	}
	else
	{
		elem = NULL;
	}
	return elem;
}

template <class object, class var> 
void CFOActionStack<object, var>::pushNew(object elem) 
{
	m_nIndex = ( (m_nIndex+1) % m_ArraySize );
	SetAt(m_nIndex, elem);
	m_nElem++;
	if(m_nElem < m_ArraySize)
	{
		m_nElem = m_nElem;
	}
	else
	{
		m_nElem = m_ArraySize;
	}
}


/////////////////////////////////////////////////////////////
// CFOArray
template< class T>
 
//===========================================================================
// Summary:
//      To use a CFOArray object, just call the constructor.
//      F O Array
//===========================================================================

class CFOArray
{
public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Array, Constructs a CFOArray object.
	//		Returns A  value (Object).
    CFOArray();

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Array, Constructs a CFOArray object.
	//		Returns A explicit value (Object).  
	// Parameters:
	//		uSize---uSize, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    explicit CFOArray( UINT uSize );

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Array, Constructs a CFOArray object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&arrToCopy---To Copy, Specifies a const CFOArray<T> &arrToCopy object(Value).
    CFOArray( const CFOArray<T> &arrToCopy );

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Array, Destructor of class CFOArray
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOArray();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		&newItem---&newItem, Specifies a const T &newItem object(Value).
	// Add method.
    void Add( const T &newItem );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add, Adds an object to the specify list.
	// Parameters:
	//		*p---A pointer to the const T  or NULL if the call failed.  
	//		uCount---uCount, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Add method.
    void Add( const T *p, UINT uCount );

	// Add method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// &Add, .
	//		Returns A T value (Object).
    T &Add();
    
	// Insert at method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&newItem---&newItem, Specifies a const T &newItem object(Value).  
	//		uCount---uCount, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void InsertAt( UINT iPos, const T &newItem, UINT uCount = 1 );

	// Insert at method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&arrToCopy---To Copy, Specifies a const CFOArray<T> &arrToCopy object(Value).
    void InsertAt( UINT iPos, const CFOArray<T> &arrToCopy );
	
	// Insert at method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert At, Inserts a child object at the given index..
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*p---A pointer to the const T  or NULL if the call failed.  
	//		uCount---uCount, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void InsertAt( UINT iPos, const T *p, UINT uCount );
       
	// Obtain at.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, .
	//		Returns A T value (Object).  
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    T   &GetAt( UINT iPos) { return operator [] ( iPos ); }

	// Obtain at.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, .
	//		Returns A const T value (Object).  
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    const T &GetAt( UINT iPos) const { return operator [] ( iPos ); }
            
	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A T value (Object).  
	// Parameters:
	//		uValue---uValue, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    T   &operator[](UINT uValue);

	// operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const T value (Object).  
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    const T &operator[](UINT iPos) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOArray<T>   &operator value (Object).  
	// Parameters:
	//		&rhs---Specifies a const CFOArray<T> &rhs object(Value).
	// operator =
    CFOArray<T>   &operator = ( const CFOArray<T> &rhs );
            
	// Remove all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.

    void RemoveAll();

	// Remove at
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		iPos---iPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		uItems---uItems, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void RemoveAt( UINT iPos, UINT uItems = 1 );
            
	// Obtain the size of array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a UINT type value.
    UINT GetSize() const;

	// Change the size of array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class CFOArray
	//		Returns A Boolean value.  
	// Parameters:
	//		uSize---uSize, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    bool SetSize( UINT uSize );

	// Obtain the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns a pointer to the object const T ,or NULL if the call failed
    const T *GetData() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	//		Returns a pointer to the object T ,or NULL if the call failed
    T *GetData();
            
private:
 
	// Items, This member maintains a pointer to the object T.  
    T           *m_pItems;
    UINT    m_uGrowBy
		, m_uItemsAllocated
		,   m_uItemCount;
};

template<class T>
CFOArray<T>::CFOArray()
:   m_pItems( NULL )
,   m_uGrowBy( 1 )
,   m_uItemsAllocated( 0 )
,   m_uItemCount( 0 )
{
}

template<class T>
CFOArray<T>::CFOArray( UINT uSize )
:   m_pItems( NULL )
,   m_uGrowBy( 1 )
,   m_uItemsAllocated( 0 )
,   m_uItemCount( 0 )
{
    SetSize( uSize );
}

template<class T>
CFOArray<T>::CFOArray( const CFOArray<T> &arrToCopy )
:   m_pItems( NULL )
,   m_uGrowBy( 1 )
,   m_uItemsAllocated( 0 )
,   m_uItemCount( 0 )
{
    InsertAt( 0, arrToCopy );
}

template<class T>
CFOArray<T>::~CFOArray()
{
    RemoveAll();
}


template<class T>
bool CFOArray<T>::SetSize( UINT uSize )
{
    bool bReallocationNeeded = false;
    ASSERT( m_uItemCount <= m_uItemsAllocated );
    
    
    if( m_uItemCount < uSize )
    {
        if( m_uItemsAllocated < uSize )
        {
            UINT uAllocateExtra = m_uGrowBy = m_uGrowBy < 262144 ? m_uGrowBy << 2 : 262144;
            if( m_uItemsAllocated + uAllocateExtra < uSize )
            {
                uAllocateExtra = uSize - m_uItemsAllocated;
            }
            
            T *pItems = reinterpret_cast<T *>( new BYTE[sizeof( T ) * ( m_uItemsAllocated + uAllocateExtra )] );
            
            if( m_uItemCount )
			{
                FOPMoveItemsNoMemOverlap<T>( m_pItems, pItems, m_uItemCount );
			}

            delete[] (BYTE*)m_pItems;
            m_pItems = pItems;
            m_uItemsAllocated += uAllocateExtra;
            bReallocationNeeded = true;
        }
        if( uSize > m_uItemCount )
        {
            UINT uItemsToConstruct = uSize - m_uItemCount;
            FOPConstructItems<T>( &m_pItems[m_uItemCount], uItemsToConstruct );
            m_uItemCount = uSize;
        }
        
    }
    else
    {
        if( m_uItemCount > uSize )
        {
            RemoveAt( uSize, m_uItemCount - uSize );
        }
    }
    
    return bReallocationNeeded;
}

template<class T>
void CFOArray<T>::Add( const T &newItem )
{
    SetSize( m_uItemCount + 1 );
    m_pItems[m_uItemCount - 1] = newItem;
}

template<class T>
T &CFOArray<T>::Add()
{
    SetSize( m_uItemCount + 1 );
    return m_pItems[m_uItemCount - 1];
}

template<class T>
void CFOArray<T>::Add( const T *p, UINT uCount )
{
    InsertAt( GetSize(), p,  uCount );
}


template<class T>
void CFOArray<T>::InsertAt( UINT iPos, const T &newItem,  UINT uCount )
{
    ASSERT( uCount >= 1 );
    ASSERT( iPos <= m_uItemCount );
    UINT uItemsToMove = m_uItemCount - iPos;
    SetSize( m_uItemCount + uCount );
    MoveItemsMemOverlap( &m_pItems[iPos], &m_pItems[iPos + uCount], uItemsToMove );
    
    ConstructItems<T>( &m_pItems[iPos], uCount );
    while( uCount-- )
    {
        m_pItems[iPos++] = newItem;
    }
}

template<class T>
void CFOArray<T>::InsertAt( UINT iPos, const CFOArray<T> &arrToCopy )
{
    InsertAt( iPos, arrToCopy.m_pItems, arrToCopy.m_uItemCount );
}

template<class T>
void CFOArray<T>::InsertAt( UINT iPos, const T *p, UINT uCount )
{
    if( p )
    {
        ASSERT( m_pItems != p );
        ASSERT( !IsBadReadPtr( p, sizeof( T ) * uCount ) );
        
        if( uCount == 0 )
            return;
        
        UINT uItemsToMove = m_uItemCount - iPos;
        
        ASSERT( iPos <= m_uItemCount );
        SetSize( m_uItemCount + uCount );
        MoveItemsMemOverlap<T>( &m_pItems[iPos], &m_pItems[iPos + uCount], uItemsToMove );
        
        CopyItems<T>( p, m_pItems + iPos, uCount );
    }
}


template<class T>
void CFOArray<T>::RemoveAll()
{
    FOPDestructItems<T>( m_pItems, m_uItemCount );
    delete [] reinterpret_cast<BYTE *>( m_pItems );
    m_pItems = NULL;
    m_uGrowBy = 1;
    m_uItemsAllocated = 0;
    m_uItemCount = 0;
}

template<class T>
void CFOArray<T>::RemoveAt( UINT iPos, UINT uItems )
{
    ASSERT( iPos + uItems <= m_uItemCount );
    ASSERT( uItems > 0 );
    
    FOPDestructItems<T>( &m_pItems[iPos], uItems );

    FOPMoveItemsMemOverlap<T>( &m_pItems[iPos + uItems], &m_pItems[iPos], m_uItemCount - iPos - uItems);
    m_uItemCount -= uItems;
}


template<class T>
CFOArray<T>   & CFOArray<T>::operator = ( const CFOArray<T> &rhs )
{
    if( this != &rhs )
    {
        RemoveAll();
        InsertAt( 0, rhs );
    }
    
    return *this;
}

template<class T>
T& CFOArray<T>::operator[]( UINT iItem )
{
    ASSERT( iItem < m_uItemCount );
    return m_pItems[iItem];
}

template<class T>
const T & CFOArray<T>::operator[](UINT iItem) const
{
    ASSERT( iItem < m_uItemCount );
    return m_pItems[iItem];
}

template<class T>
UINT CFOArray<T>::GetSize() const
{
    return m_uItemCount;
}

template<class T>
const T *CFOArray<T>::GetData() const
{
    return m_pItems;
}

template<class T>
T *CFOArray<T>::GetData()
{
    return m_pItems;
}

#endif // !defined(AFX_FOACTIONSTACK_H__17272EF6_8BF6_11D6_A5EA_525400EA266C__INCLUDED_)
