//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBaseProperties.h: interface for the CFOBaseProperties class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBASEPROPERTIES_H__2EEABBF4_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOBASEPROPERTIES_H__2EEABBF4_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FODefines.h"
#include "FOActionStack.h"
#include "FOIUnknown.h"
#include "FOTypedShapeObList.h"

//************************************************************
//   CFOBaseProperties
//
// This is the base class of properties,you can assign properties object to
// DataModel or shape by call AddNewProperty(..) method.
//
// Each kind of properties object must has an unique ID.
// Each kind of property value must also has an unique ID.
//
// Override PutValue to assign value by ID.
// Override GetValue to obtain value by ID.
//
//************************************************************

//////////////////////////////////////////////////////////////////////
// FO_VALUETYPE a enum define for property value type that E-XD++ support.
// and if you want a specify value type such as CRect,I think you should use 4 int type instead.
//

enum FO_VALUETYPE
{
	V_EMPTY = -1,
	V_BOOL,			// BOOL value type.
	V_STRING,		// String value type
	V_INT,			// int value type
	V_FLOAT,		// float value type
	V_DOUBLE,		// double value type
	V_DWORD,		// DWORD value type
	V_DATETIME,		// COleDateTime value type
	V_COLOR			// COLORREF value type.
};

//////////////////////////////////////////////////////////////////////
// FO_VALUE a class define for property value that E-XD++ support.
//

 
//===========================================================================
// Summary:
//      To use a FO_VALUE object, just call the constructor.
//      O_ V A L U E
//===========================================================================

class FO_EXT_CLASS FO_VALUE
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O_ V A L U E, Constructs a FO_VALUE object.
	//		Returns A  value (Object).
	FO_VALUE();

	//-----------------------------------------------------------------------
	// Summary:
	// String Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O_ V A L U E, Constructs a FO_VALUE object.
	//		Returns A  value (Object).  
	// Parameters:
	//		str---Specifies A CString type value.
	FO_VALUE(const CString& str);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O_ V A L U E, Constructs a FO_VALUE object.
	//		Returns A  value (Object).  
	// Parameters:
	//		val---Specifies a const FO_VALUE& val object(Value).
	FO_VALUE(const FO_VALUE& val);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O_ V A L U E, Destructor of class FO_VALUE
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FO_VALUE();

	//-----------------------------------------------------------------------
	// Summary:
	// Is equal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		value---A pointer to the FO_VALUE or NULL if the call failed.
	virtual BOOL IsEqual(FO_VALUE* value) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		val---Specifies a const FO_VALUE val object(Value).
	BOOL operator==(const FO_VALUE &val) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Determines if another set of fill properties is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		val---Specifies a const FO_VALUE val object(Value).
	BOOL operator!=(const FO_VALUE &val) const;

	//-----------------------------------------------------------------------
	// Summary:
	// =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FO_VALUE& value (Object).  
	// Parameters:
	//		val---Specifies a const FO_VALUE& val object(Value).
	virtual FO_VALUE& operator=(const FO_VALUE& val);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Data, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	void SerializeData(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize New, Reads or writes this object from or to an archive.
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	void SerializeNew(CArchive &ar);

public:
	
	// BOOL value.
 
	// Value, This member sets TRUE if it is right.  
	BOOL		m_bValue;

	// String value.
 
	// Value, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strValue;

	// Int value.
 
	// Value, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nValue;

	// Float value.
 
	// Value, This member specify The float keyword designates a 32-bit floating-point number.  
	float		m_fValue;

	// Double value.
 
	// Value, This member specify double object.  
	double		m_dValue;

	// DWORD value.
 
	// Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		m_dwValue;

	// Date time value.
 
	// Value, This member specify COleDateTime object.  
	COleDateTime m_dtValue;

	// Color value.
 
	// Value, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crValue;

	// Value type.
 
	// Value Type, This member specify FO_VALUETYPE object.  
	FO_VALUETYPE m_nValueType;

	// 
	BOOL bOk;
};

//////////////////////////////////////////////////////////////////////
// CFOBaseProperties a class define for property value that E-XD++ support, this class is only
// the base class for property, you must create children class from this class and then override
// a few virtual methods to handle the detail control.
//

class CFOBaseProperties;

// Smart pointer of property object.
typedef CFOSmartPtr<CFOBaseProperties> CFOBasePropPtr;

struct FO_FIELD
{
	int		nPropID;
	CString m_description;
	FO_VALUE m_vValue;
};

typedef CArray<FO_FIELD, FO_FIELD> FOFieldList;

//===========================================================================
// Summary:
//     The CFOBaseProperties class derived from FOIUnknown
//      F O Base Properties
//===========================================================================

class FO_EXT_CLASS CFOBaseProperties : public FOIUnknown
{
protected:

	//-----------------------------------------------------------------------
	// Summary:
	// DECLARE SERIAL CLASS
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseProperties---F O Base Properties, Specifies a E-XD++ CFOBaseProperties object (Value).
	DECLARE_SERIAL(CFOBaseProperties);

protected:

	// properties ID
 
	// Property I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		nPropID;

	// Version of shape.
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nVersion;

	// Property value name.
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strName;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Get the ID of the property value, each property object must have an unique ID value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Id, Returns the specified property value.
	//		Returns a int type value.
	int GetPropId() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set the ID of the properties,
	// nID -- It must be an unique ID for each kind of property class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Property Id, Sets a specify value to current class CFOBaseProperties
	// Parameters:
	//		nID---I D, Specifies A integer value.
	void SetPropId(const int nID);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain property description name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Name, Returns the specified property value.
	//		Returns a CString type value.
	CString GetPropName() const { return m_strName; }

	//-----------------------------------------------------------------------
	// Summary:
	// Change the property description name.
	// strName -- name of this property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Property Name, Sets a specify value to current class CFOBaseProperties
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	void SetPropName(const CString &strName) { m_strName = strName; }

	//-----------------------------------------------------------------------
	// Summary:
	// Version of this property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Version, Returns the specified property value.
	//		Returns a int type value.
	int		GetPropVersion() const;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Properties, Constructs a CFOBaseProperties object.
	//		Returns A  value (Object).
	CFOBaseProperties();

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	// nID -- ID value of the property class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Properties, Constructs a CFOBaseProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nID---I D, Specifies A integer value.
	CFOBaseProperties(int nID);

	//-----------------------------------------------------------------------
	// Summary:
	// Copy Constructor.
	// prop -- property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Properties, Constructs a CFOBaseProperties object.
	//		Returns A  value (Object).  
	// Parameters:
	//		prop---Specifies a const CFOBaseProperties& prop object(Value).
	CFOBaseProperties(const CFOBaseProperties& prop);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Properties, Destructor of class CFOBaseProperties
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseProperties();


	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the backup of this properties values.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Back Up, Obtain the backup of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoBackUp(CFOBaseProperties* pProp);

	BOOL m_bIsLoad;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Put value, call this method to change the property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutValue(
		// Property ID.
		const int &nPropId,
		// Specify value of property.
		const FO_VALUE &Value
		) { nPropId;Value; return FALSE; }

	//-----------------------------------------------------------------------
	// Summary:
	// Get value, call this method to obtain the property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetValue(
		// Return value.
		FO_VALUE &Value,
		// Specify which property with ID you want to get its value.
		const int &nPropId
		) { nPropId; Value; return FALSE; }

	//-----------------------------------------------------------------------
	// Summary:
	// Take the name of the property item, override this method to handle detail property 
	// description name for each property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Name, Take the name of the property item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nValueId---Value Id, Specifies A integer value.  
	//		strItemName---Item Name, Specifies A CString type value.
	virtual void TakeItemName(int nValueId, CString& strItemName);

	//-----------------------------------------------------------------------
	// Summary:
	// Take the id value of the property item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Item Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<int---Array<int, Specifies A CArray array.  
	//		&arValues---&arValues, Specifies A integer value.
	virtual void TakeItemValue(CArray<int, int> &arValues);

public:

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed
	// Create a copy of this property value object.
	virtual CFOBaseProperties* Copy();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes this property object to file.
	virtual void Serialize(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// operator =
	// prop - copying from property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOBaseProperties& value (Object).  
	// Parameters:
	//		prop---Specifies a const CFOBaseProperties& prop object(Value).
	virtual CFOBaseProperties& operator=(const CFOBaseProperties& prop);

	//-----------------------------------------------------------------------
	// Summary:
	// Is equal or not
	// prop -- compare property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Equal, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL IsEqual(CFOBaseProperties* prop);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Save Document
	// lpszPathName -- file path name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	//-----------------------------------------------------------------------
	// Summary:
	// Open Document
	// lpszPathName -- file path name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	//-----------------------------------------------------------------------
	// Summary:
	// Get File of lpszFileName
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	//-----------------------------------------------------------------------
	// Summary:
	// Release File
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

// Implementation
public:

#ifdef _DEBUG
	// Assert Valid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// Dump
	virtual void Dump(CDumpContext& dc) const;
#endif

};

// define type CTypedPtrList, this is a list that stores all the property object.
typedef CTypedPtrList<CObList, CFOBaseProperties*> CFOBasePropertiesList;

// Get the ID of the properties.
_FOLIB_INLINE int CFOBaseProperties::GetPropId() const
{
	return nPropID;
}

// Set the ID of the properties.
_FOLIB_INLINE void CFOBaseProperties::SetPropId(const int nID)
{
	nPropID = nID;
}

// default is 8
_FOLIB_INLINE int CFOBaseProperties::GetPropVersion() const
{
	return m_nVersion;
}

#endif // !defined(AFX_FOBASEPROPERTIES_H__2EEABBF4_F19E_11DD_A432_525400EA266C__INCLUDED_)
