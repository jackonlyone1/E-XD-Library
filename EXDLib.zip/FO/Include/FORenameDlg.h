//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FORENAMEDLG_H__900D5BB9_F3E6_11DD_A438_525400EA266C__INCLUDED_)
#define AFX_FORENAMEDLG_H__900D5BB9_F3E6_11DD_A438_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FORenameDlg.h : header file
//
#include "FOImageButton.h"
#include "fodefines.h"
#include "FOTemplateWnd.h"
#include "FOTabCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CFORenameDlg dialog

 
//===========================================================================
// Summary:
//     The CFORenameDlg class derived from CDialog
//      F O Rename Dialog
//===========================================================================

class FO_EXT_CLASS CFORenameDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rename Dialog, Constructs a CFORenameDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFORenameDlg(CWnd* pParent = NULL);   // standard constructor


	// Dialog Data
	//{{AFX_DATA(CFORenameDlg)
	enum { IDD = IDD_FO_TAB_RENAME };
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
	//}}AFX_DATA
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	BOOL bDirMode;
	BOOL bFileMode;
	CString strFullPath;
	CString strSave;
	BOOL bFindMode;
	
	BOOL DirectoryExists(const CString& Path);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFORenameDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFORenameDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();

	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

class CFODataModel;

 
//===========================================================================
// Summary:
//     The CFOPLayerRenameDlg class derived from CDialog
//      F O P Layer Rename Dialog
//===========================================================================

class FO_EXT_CLASS CFOPLayerRenameDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer Rename Dialog, Constructs a CFOPLayerRenameDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPLayerRenameDlg(CFODataModel *pModel,CWnd* pParent = NULL);   // standard constructor

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	BOOL m_bPropMode;

	// Dialog Data
	//{{AFX_DATA(CFOPLayerRenameDlg)
	enum { IDD = IDD_FO_TAB_RENAME };
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
	//}}AFX_DATA
 
	// Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOld;
 
	// Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel *m_pDataModel;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPLayerRenameDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPLayerRenameDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit1, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnChangeEdit1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

///////////////////////////////////////////////////////////////////////////
// CFOFolderListBox window

class FO_EXT_CLASS CFOFolderListBox : public CListBox
{
	DECLARE_DYNAMIC(CFOFolderListBox)
		// Construction
public:
	
	//-> CFOFolderListBox constructor 
	CFOFolderListBox();
	
	//-> CFOFolderListBox destructor 
	virtual ~CFOFolderListBox();
	
	// Operations
public:
	
	//-> Adds a font to the list box. 
	
public:
	
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	virtual void DeleteItem(LPDELETEITEMSTRUCT lpDIS);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	static void DrawBmp(CDC* pDC, CBitmap* pbmp, CBitmap* pbmpMask,
		int x, int y, int cx, int cy);
	static void InitBmp(CBitmap* pbmp, CBitmap* pbmpMask);
	
	
protected:
	//{{AFX_MSG(CFOFolderListBox)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	//->cmember
	//-> TrueType bitmap (used for listbox item drawing). 
	CBitmap m_bmpTrueType;
	
	//->cmember
	//-> TrueType bitmap sprite mask. 
	CBitmap m_bmpMask;
};


//===========================================================================
// Summary:
//     The CFOPNewTemplateDlg class derived from CDialog
//      F O P Layer Rename Dialog
//===========================================================================

class FO_EXT_CLASS CFOPNewTemplateDlg : public CDialog
{
	
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer Rename Dialog, Constructs a CFOPNewTemplateDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPNewTemplateDlg(CWnd* pParent = NULL);   // standard constructor
	
	
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;
	
	// Dialog Data
	//{{AFX_DATA(CFOPNewTemplateDlg)
	enum { IDD = IDD_FO_NEW_TEMPLATE };
	
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;

	// Description, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strDescription;
	CString	m_strFolder;
	CFOFolderListBox	m_listBox;
	//}}AFX_DATA
	
	// Old, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strOld;
	
	// Data Model, This member maintains a pointer to the object CFODataModel.  
	BOOL FileExist(CString strFilePath);
	void   DeleteDirectory(CString   strDir);
	CString m_strPath;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPNewTemplateDlg)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPNewTemplateDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Change Edit1, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnChangeEdit1();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnButtonHelp();

	afx_msg void OnFoButtonAdd();
	afx_msg void OnFoButtonRemove();
	afx_msg void OnSelchangeFoDirList();
	//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

class CFOPOpenTemplateDlg;
 
//===========================================================================
// Summary:
//     The CFOPExtTemplateWnd class derived from CFOTemplateWnd
//      Extend Template Window
//===========================================================================

class FO_EXT_CLASS CFOPExtTemplateWnd : public CFOTemplateWnd
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Template Window, Constructs a CFOPExtTemplateWnd object.
	//		Returns A  value.
	CFOPExtTemplateWnd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Extend Template Window, Destructor of class CFOPExtTemplateWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CFOPExtTemplateWnd();

// Attributes
public:
	// Do something when click on the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click On Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOModelBoxItem or NULL if the call failed.
	virtual void DoClickOnItem(CFOModelBoxItem* pPage);


	// create context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();
	

	// Set Parent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Dialog, Sets a specify value to current class CFOPExtTemplateWnd
	// Parameters:
	//		*pDlg---*pDlg, A pointer to the CFOPOpenTemplateDlg  or NULL if the call failed.
	void SetParentDlg(CFOPOpenTemplateDlg *pDlg);

// Operations
private:
 
	// m_pDlg, This member maintains a pointer to the object CFOPOpenTemplateDlg.  
	CFOPOpenTemplateDlg *m_pDlg;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtTemplateWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtTemplateWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);

	// remove a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnRemovePagex();
	
	// update remove
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRemovePagex(CCmdUI* pCmdUI);


	// remove a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnRenamePagex();
	
	// remove a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnFind();
	

	// update remove
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRenamePagex(CCmdUI* pCmdUI);

	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()
};

 
//===========================================================================
// Summary:
//     The CFOPOpenTemplateDlg class derived from CDialog
//      M B Templage Dialog
//===========================================================================

class FO_EXT_CLASS CFOPOpenTemplateDlg : public CDialog
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// M B Templage Dialog, Constructs a CFOPOpenTemplateDlg object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPOpenTemplateDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPOpenTemplateDlg)
	enum { IDD = IDD_FO_OPEN_TEMPLATE };
 
	// Button Cancel, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonCancel;
 
	// Button Open, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonOpen;
	//}}AFX_DATA
 
	// m_wndTab, This member specify E-XD++ CFOTabCtrl object.  
	CFOTabCtrl m_wndTab;
 
	// Window Page, This member specify CPtrArray object.  
	CPtrArray m_arrWndPage;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Information To Tab, Adds an object to the specify list.

	void AddInfoToTab();
	virtual void InsertPage(int nTab, CString strPage);

	BOOL FOPFileExist3(CString strFilePath);

	// Temp File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strTempFile;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Templace, None Description.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL OpenTemplace();
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPOpenTemplateDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.
	virtual BOOL DestroyWindow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
protected:
	
	//Has it intialize
 
	// Has Initial, This member sets TRUE if it is right.  
	BOOL m_bHasInit;
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPOpenTemplateDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Open Document, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnOpenDocument();

	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		UINT---I N T, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT /*nType*/, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Sizing, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSide---nSide, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object.
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);

	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnButtonRemove();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPTableSplitDlg dialog

class FO_EXT_CLASS CFOPTableSplitDlg : public CDialog
{
	// Construction
public:
	CFOPTableSplitDlg(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CFOPTableSplitDlg)
	enum { IDD = IDD_FO_TABLE_SPLITDLG };
	CSpinButtonCtrl	m_spinSplit;
	int		m_nCount;
	int		m_bHorz;
	//}}AFX_DATA
	
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPTableSplitDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CFOPTableSplitDlg)
	virtual BOOL OnInitDialog();
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORENAMEDLG_H__900D5BB9_F3E6_11DD_A438_525400EA266C__INCLUDED_)
