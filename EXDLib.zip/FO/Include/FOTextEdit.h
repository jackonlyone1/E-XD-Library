//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTEXTEDIT_H__E735B983_FC1C_11D5_A4E1_525400EA266C__INCLUDED_)
#define AFX_FOTEXTEDIT_H__E735B983_FC1C_11D5_A4E1_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTextEdit.h : header file
//

#include "FODrawShape.h"
#include <afxcoll.h>

#include <afxmt.h>

/////////////////////////////////////////////////////////////////////////////
// CFOControlBase -- the base class for all editing field.

class CFOChildItem;

 
//===========================================================================
// Summary:
//      To use a CFOControlBase object, just call the constructor.
//      F O  Base
//===========================================================================

class FO_EXT_CLASS CFOControlBase
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O  Base, Constructs a CFOControlBase object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOControlBase(CFODrawShape* pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O  Base, Destructor of class CFOControlBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOControlBase();

public:
	// Mouse Press, This member sets TRUE if it is right.  
	BOOL			m_bMousePress;
	
	// Mouse down state.
	
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL			m_bMouseDown;

	// Is kind of
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Kind Of, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pClass---pClass, A pointer to the const CRuntimeClass or NULL if the call failed.
	BOOL IsKindOf(const CRuntimeClass* pClass) const;

	// Operator wnd *
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window, .
	//		Returns A operator value (Object).
	operator CWnd*();

	// Get wnd ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Obtain shape's wnd pointer.
	virtual CWnd *GetShapeWnd();

	// Obtain the grid window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Grid Window, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	virtual CWnd *ComponentWnd();

	// Set grid window handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Grid Window, Sets a specify value to current class CFOControlBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	virtual void SetComponentWnd(CWnd *pWnd) { m_pComponentWnd = pWnd; }

	// Parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	CFODrawShape* GetDrawShape();

	// Status (need to be override)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOControlBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Is validate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOControlBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();   // default: FALSE

	// Get current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOControlBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Clipboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Copy text to clipboard.
	virtual BOOL Copy();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Paste text from clipboard.
	virtual BOOL Paste();

	// Copy text to clipboard and delete the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Cut();

	// Can copy text to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Copy, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCopy();

	// Can cut text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Cut, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCut();

	// Can paste text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Paste, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanPaste();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Clear text
	virtual BOOL Clear();

	// Replace sel text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszReplaceText---Replace Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR pszReplaceText);

	// Get selected text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual BOOL GetSelectedText(CString& strResult);

	// Validate string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update String, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strEdit---strEdit, Specifies A CString type value.
	virtual BOOL UpdateControlText(const CString& strEdit);

	// Do notify msg.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Notify Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL DoNotifyMsg(WPARAM wParam, LPARAM lParam);

	// Notify message
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual void OnNotifyMsg(MSG* pMsg);

	// Hides the CWnd and Redraws the control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Refresh();

	// Mouse hit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt, UINT nState);

	// Do Left Button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt, UINT nState);
	
	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nState);
	
	// Do left button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint point);

	// Do draw state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

	// Middle Button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoMButtonDown(UINT nFlags, CPoint pt, UINT nState);
	
	// Do middle button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoMButtonUp(UINT nFlags, CPoint pt, UINT nState);
	
	// Do middle button double click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoMButtonDblClk(UINT nFlags, CPoint point);

	// Do Right Button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoRButtonDown(UINT nFlags, CPoint pt, UINT nState);
	
	// Do right button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoRButtonUp(UINT nFlags, CPoint pt, UINT nState);
	
	// Do right button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoRButtonDblClk(UINT nFlags, CPoint point);

	// Do cancel mode action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Mode, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCancelMode();

	// Do key down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Do key up action,
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Do system color change action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do System Color Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSysColorChange();

	// On simple char
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Simple Char, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnSimpleChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// On wide char
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Wide Char, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sChar---sChar, Specifies A CString type value.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnWideChar(const CString& sChar, UINT nRepCnt, UINT nFlags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	// Init control
	virtual void Init();

	// Support for several child buttons (HotSpot, Combobox, Spinnbuttons)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChild---pChild, A pointer to the CFOChildItem or NULL if the call failed.
	virtual void DoClickEvent(CFOChildItem* pChild);

	// On kill focus action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	void OnKillFocus(CWnd* pNewWnd);

	// Keyboard pressed
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Override this methode to initialize the rectangle of the children
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Returns the rectangle, e.g. the rect for the text to be drawn without buttons
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).
	virtual FOPRect GetFullControlPosition();

	// Returns pointer to active child
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Focus Child Item, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOChildItem,or NULL if the call failed
	virtual CFOChildItem* GetActiveChildControl();

	// Sets active child to retrieve mouse and keys messages
	
	//-----------------------------------------------------------------------
	// Summary:
	// Active Child Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		child---A pointer to the CFOChildItem or NULL if the call failed.
	virtual void ActiveChildControl(CFOChildItem* child);
	
	// Number of childs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCount();	

	// Adds a child
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChild---pChild, A pointer to the CFOChildItem or NULL if the call failed.
	virtual void AddNewItem(CFOChildItem* pChild);

	// Returns a child
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Child Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOChildItem,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFOChildItem* FindChildControl(int nIndex);
	
	// Without value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Without Return, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsWithoutReturn() const { return m_bWithoutReturn; }

	// Set without return
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Without Return, Sets a specify value to current class CFOControlBase
	// Parameters:
	//		&bWith---&bWith, Specifies A Boolean value.
	void SetWithoutReturn(const BOOL &bWith) { m_bWithoutReturn = bWith; }

	// Do when start editing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Editing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnStartEditing();

	// Do when item modified
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Modify Cell, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnModifyCell();

	// Do when cancel editing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Editing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnCancelEditing();

	// Do command message
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Is validate or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Validate, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnValidate();

protected:

	// Parent shape.
 
	// Text Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*		m_pTextComp;

	// support for IME/DBCS
	//  Width char.
 
	// Wild Char, This member sets TRUE if it is right.  
	BOOL				m_bWildChar;

	// Text lead
 
	// Text Lead, This member specify TCHAR object.  
	TCHAR				m_cTextLead;

	// childrens
 
	// Items, This member maintains a pointer to the object CPtrList.  
	CPtrList*			m_plstItems;

	// Focus child item.
 
	// Select Child, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem*		m_pSelectChild;

	// Button without return value.
 
	// Without Return, This member sets TRUE if it is right.  
	BOOL				m_bWithoutReturn;

	// Grid wnd.
 
	// Grid Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd *				m_pComponentWnd;
};


/////////////////////////////////////////////////////////////////////////////
// CFOChildItem -- Child classes which can be used by the base control class

 
//===========================================================================
// Summary:
//      To use a CFOChildItem object, just call the constructor.
//      F O Child Item
//===========================================================================

class FO_EXT_CLASS CFOChildItem
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Child Item, Constructs a CFOChildItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParentCtrl---Parent , A pointer to the CFOControlBase or NULL if the call failed.
	CFOChildItem(CFOControlBase* pParentCtrl);

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Child Item, Destructor of class CFOChildItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOChildItem();

public:
	// Set rectangles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CFOChildItem
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).
	virtual void SetRect(const FOPRect& rc);

	// Get rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).
	virtual FOPRect GetRect();

	// Intersects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint pt);

	// Focus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Focus, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL HasFocus();

	// Set text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text, Sets a specify value to current class CFOChildItem
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void SetText(LPCTSTR str);

	// Get text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetText();

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Refresh();

	// Do mouse move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt);

	// Do Left Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt);

	// Do left button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt);

	// Do left button double click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint point);

	// Do Middle Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMButtonDown(UINT nFlags, CPoint pt);

	// Do middle button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMButtonUp(UINT nFlags, CPoint pt);

	// Do middle button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoMButtonDblClk(UINT nFlags, CPoint point);

	// Do Right Button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoRButtonDown(UINT nFlags, CPoint pt);

	// Do right button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoRButtonUp(UINT nFlags, CPoint pt);

	// Do right button double click action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL DoRButtonDblClk(UINT nFlags, CPoint point);

	// Do mouse over action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move Over, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMouseMoveOver(UINT flags, CPoint pt);

	// Do cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Mode, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCancelMode();

	// Do key down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Do key up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Do system color change
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do System Color Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoSysColorChange();

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);
	
	// Do Keyboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Pointer to Parent wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	CWnd* GetWndPtr() { return m_pBaseControl->GetWndPtr(); }

	// Parent shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	CFODrawShape* GetDrawShape() { return m_pBaseControl->GetDrawShape(); }

	// Is transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Transparent, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsTransparent() const { return m_bTransparent; }

	// Set transparent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOChildItem
	// Parameters:
	//		&bTrans---&bTrans, Specifies A Boolean value.
	void SetTransparent(const BOOL &bTrans) { m_bTransparent = bTrans; }

protected:

	// Base control pointer
 
	// Base , This member maintains a pointer to the object CFOControlBase.  
	CFOControlBase*		m_pBaseControl;

	// Position.
 
	// This member specify FOPRect object.  
	FOPRect				m_rect;

	// Text string.
 
	// Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strText;

	//  Width char.
 
	// Wild Char, This member sets TRUE if it is right.  
	BOOL				m_bWildChar;

	// Text led
 
	// Text Lead, This member specify TCHAR object.  
	TCHAR				m_cTextLead;

	// Transparent back color.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL				m_bTransparent;

};


/////////////////////////////////////////////////////////////////////////////
// CFOButtonItem control -- button with action.

 
//===========================================================================
// Summary:
//     The CFOButtonItem class derived from CFOChildItem
//      F O Button Item
//===========================================================================

class FO_EXT_CLASS CFOButtonItem: public CFOChildItem
{
public:
	// construction, detruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Button Item, Constructs a CFOButtonItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFOButtonItem(CFOControlBase* pBase);

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);

	// Do left button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt);

	// Do mouse move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt);

	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt);

	// Do key down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyDown(UINT nChar, UINT nRepCnt, UINT flags);

	// Do key up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyUp(UINT nChar, UINT nRepCnt, UINT flags);

	// Do cancel mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Mode, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCancelMode();

protected:

	// Pressed button.
 
	// Mouse Press, This member sets TRUE if it is right.  
	BOOL			m_bMousePress;

	// Mouse down state.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL			m_bMouseDown;

	// Can press.
 
	// Enable, This member sets TRUE if it is right.  
	BOOL			m_bEnable;
};

/////////////////////////////////////////////////////////////////////////////
// CFODateTimeButtonItem control -- date time with picker.

 
//===========================================================================
// Summary:
//     The CFODateTimeButtonItem class derived from CFOChildItem
//      F O Date Time Button Item
//===========================================================================

class FO_EXT_CLASS CFODateTimeButtonItem: public CFOChildItem
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction, destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Date Time Button Item, Constructs a CFODateTimeButtonItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFODateTimeButtonItem(CFOControlBase* pBase);

	//-----------------------------------------------------------------------
	// Summary:
	// destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Date Time Button Item, Destructor of class CFODateTimeButtonItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODateTimeButtonItem();

public:
	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);

	// Do left button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt);

	// Do mouse move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt);

	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt);

	// Do key down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyDown(UINT nChar, UINT nRepCnt, UINT flags);

	// Do key up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyUp(UINT nChar, UINT nRepCnt, UINT flags);

	// Do cancel mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Mode, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoCancelMode();

protected:

	// Prssed button.
 
	// Mouse Press, This member sets TRUE if it is right.  
	BOOL			m_bMousePress;

	// Mouse down state.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL			m_bMouseDown;

	// Can press.
 
	// Enable, This member sets TRUE if it is right.  
	BOOL			m_bEnable;

	// The icon of lock
 
	// Icon Lock, This member specify HICON object.  
	HICON			m_hIconLock;

};

/////////////////////////////////////////////////////////////////////////////
// CFOComboBoxItem window -- combo box item.

 
//===========================================================================
// Summary:
//     The CFOComboBoxItem class derived from CFOButtonItem
//      F O Combo Box Item
//===========================================================================

class FO_EXT_CLASS CFOComboBoxItem: public CFOButtonItem
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction, destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Combo Box Item, Constructs a CFOComboBoxItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFOComboBoxItem(CFOControlBase* pBase);

	//-----------------------------------------------------------------------
	// Summary:
	// destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Combo Box Item, Destructor of class CFOComboBoxItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOComboBoxItem();

	//-----------------------------------------------------------------------
	// Summary:
	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);

};

/////////////////////////////////////////////////////////////////////////////
// CFOArrowBase window -- arrow button item.

 
//===========================================================================
// Summary:
//     The CFOArrowBase class derived from CFOButtonItem
//      F O Arrow Base
//===========================================================================

class FO_EXT_CLASS CFOArrowBase: public CFOButtonItem
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction, destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Arrow Base, Constructs a CFOArrowBase object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParentCtrl---Parent , A pointer to the CFOControlBase or NULL if the call failed.
	CFOArrowBase(CFOControlBase* pParentCtrl);

	// Do mouse move action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt);

	// Do left button down action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt);

	// Do left button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt);

public:

	// Delay mouse state
 
	// Delay, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		dwDelay;

	// Mouse delay
 
	// Delay Value, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD		dwDelayValue;
};

/////////////////////////////////////////////////////////////////////////////
// CFOUpArrowItem window -- up arrow item

 
//===========================================================================
// Summary:
//     The CFOUpArrowItem class derived from CFOArrowBase
//      F O Up Arrow Item
//===========================================================================

class FO_EXT_CLASS CFOUpArrowItem: public CFOArrowBase
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction, destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Up Arrow Item, Constructs a CFOUpArrowItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFOUpArrowItem(CFOControlBase* pBase);

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);
};

/////////////////////////////////////////////////////////////////////////////
// CFODownArrowItem window -- down arrow item.

 
//===========================================================================
// Summary:
//     The CFODownArrowItem class derived from CFOArrowBase
//      F O Down Arrow Item
//===========================================================================

class FO_EXT_CLASS CFODownArrowItem: public CFOArrowBase
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// construction, destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Down Arrow Item, Constructs a CFODownArrowItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFODownArrowItem(CFOControlBase* pBase);

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);
};

/////////////////////////////////////////////////////////////////////////////
// CFOBitmapButtonItem window -- button with bitmap showing.

 
//===========================================================================
// Summary:
//     The CFOBitmapButtonItem class derived from CFOButtonItem
//      F O Bitmap Button Item
//===========================================================================

class FO_EXT_CLASS CFOBitmapButtonItem : public CFOButtonItem
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Button Item, Constructs a CFOBitmapButtonItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pBase---pBase, A pointer to the CFOControlBase or NULL if the call failed.
	CFOBitmapButtonItem(CFOControlBase* pBase);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bitmap Button Item, Destructor of class CFOBitmapButtonItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBitmapButtonItem();

public:
	
	// Load bitmaps.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmaps, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszNormalBmp---Normal Bitmap, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszSelectedBmp---Selected Bitmap, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszFocusBmp---Focus Bitmap, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL LoadBitmaps(LPCTSTR lpszNormalBmp,LPCTSTR lpszSelectedBmp = NULL,LPCTSTR lpszFocusBmp = NULL);

	// Load bitmaps.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Bitmaps, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nNormalBmp---Normal Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nSelectedBmp---Selected Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFocusBmp---Focus Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL LoadBitmaps(UINT nNormalBmp,UINT nSelectedBmp = 0,UINT nFocusBmp = 0);

	// Free all bitmaps.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Free All Resource, .

	void FreeAllResource();

	// Load resource bitmap handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Resource Bitmap, Call this function to read a specified number of bytes from the archive.
	//		Returns A HANDLE value (Object).  
	// Parameters:
	//		lpString---lpString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	HANDLE LoadResourceBitmap(LPCTSTR lpString);

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bActive---bActive, Specifies A Boolean value.
	virtual void DoDraw(CDC* pDC, BOOL bActive);

	// Get bitmap size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetBmpSize();

	// Change bmp size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap Size, Returns the specified value.
	//		Returns a CSize type value.  
	// Parameters:
	//		hBmp---hBmp, Specifies a HANDLE hBmp object(Value).
	CSize GetBmpSize(HANDLE hBmp);

	// Normal bitmap handle.
 
	// Bitmap Normal, This member specify HANDLE object.  
	HANDLE		m_hBmpNormal;

	// Focus bitmap handle.
 
	// Bitmap Focus, This member specify HANDLE object.  
	HANDLE		m_hBmpFocus;

	// Selected bitmap handle.
 
	// Bitmap Selected, This member specify HANDLE object.  
	HANDLE		m_hBmpSelected;
};

/////////////////////////////////////////////////////////////////////////////
// CFOButtonControl control -- button control.

 
//===========================================================================
// Summary:
//     The CFOButtonControl class derived from CFOControlBase
//      F O Button 
//===========================================================================

class FO_EXT_CLASS CFOButtonControl: public CFOControlBase
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Button , Constructs a CFOButtonControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOButtonControl(CFODrawShape* pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Do draw state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

protected:

	// Init children
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Attributes
 
	// Button, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem* m_pButton;
};

/////////////////////////////////////////////////////////////////////////////
// CFOBmpButtonControl control -- bitmap button control

 
//===========================================================================
// Summary:
//     The CFOBmpButtonControl class derived from CFOControlBase
//      F O Bitmap Button 
//===========================================================================

class FO_EXT_CLASS CFOBmpButtonControl: public CFOControlBase
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bitmap Button , Constructs a CFOBmpButtonControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nNormalBmp---Normal Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nSelectedBmp---Selected Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFocusBmp---Focus Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOBmpButtonControl(CFODrawShape* pShape, UINT nNormalBmp, UINT nSelectedBmp = 0, UINT nFocusBmp = 0);

	//-----------------------------------------------------------------------
	// Summary:
	// Do draw state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

protected:

	// Init children position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Attributes
 
	// Button, This member maintains a pointer to the object CFOBitmapButtonItem.  
	CFOBitmapButtonItem* m_pButton;
};

/////////////////////////////////////////////////////////////////////////////
// CFOEditControl window -- edit box control.

 
//===========================================================================
// Summary:
//     The CFOEditControl class derived from CEdit
//      F O Edit 
//===========================================================================

class FO_EXT_CLASS CFOEditControl : public CEdit, public CFOControlBase
{

// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Edit , Constructs a CFOEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOEditControl(CFODrawShape* pShape = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Edit , Destructor of class CFOEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOEditControl();

public:

	// Create control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFOEditControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent,int nID,DWORD dwStyle = 0, LPRECT lpRect = NULL);

	// Send notify message.
	BOOL SendNotifyMsg();
	
	// Set active status
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Pointer of wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Is active status.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();

	// Clipboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Copy text to clipboard.
	virtual BOOL Copy();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Paste text from clipboard.
	virtual BOOL Paste();

	// Copy text to clipboard and delete the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Cut();

	// Can copy text to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Copy, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCopy();

	// Can cut text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Cut, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCut();

	// Can paste text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Paste, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanPaste();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Clear text
	virtual BOOL Clear();

	// Update clipboard text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Clipboard, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	virtual BOOL UpdateClipboard(const CString& strText);

	// Replace sel text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszReplaceText---Replace Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR pszReplaceText);

	// Adjust edit control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Edit , .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL  AdjustEditControl();

	// Called from OnChar (lets you change the nChar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Enter Text, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SaveEnterText();

	// Called from OnChar (lets you change the nChar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char Extend, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnMoreChar(UINT nChar, UINT nRepCnt, UINT flags);

	// Previous translate message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Get current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Get selected text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual BOOL GetSelectedText(CString& strResult);

	// Get select
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	// Parameters:
	//		nStartChar---Start Char, Specifies A integer value.  
	//		nEndChar---End Char, Specifies A integer value.
	void GetSel(int& nStartChar, int& nEndChar) const;

	// Get select
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetSel() const;

	// Do notify msg.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Notify Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL DoNotifyMsg(WPARAM wParam, LPARAM lParam);

	// Do left button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Obtain prompt color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Prompt Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPromptColor()	{ return m_crPromptColor; }

	// Obtain prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Prompt Text, Returns the specified value.
	//		Returns a CString type value.
	CString		GetPromptText()		{ return m_strPromptText; }

	// Obtain the window text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Text, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		lpszStringBuf---String Buffer, Specifies a LPTSTR lpszStringBuf object(Value).  
	//		nMaxCount---Maximize Count, Specifies A integer value.
	int			GetWindowText(LPTSTR lpszStringBuf, int nMaxCount) const;

	// Obtain window text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Text, Returns the specified value.
	// Parameters:
	//		rString---rString, Specifies A CString type value.
	void		GetWindowText(CString& rString) const;

	// Change prompt color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Prompt Color, Sets a specify value to current class CFOEditControl
	// Parameters:
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPromptColor(COLORREF crText);

	// Change prompt text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Prompt Text, Sets a specify value to current class CFOEditControl
	// Parameters:
	//		lpszPrompt---lpszPrompt, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetPromptText(LPCTSTR lpszPrompt);

	// Change window text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Window Text, Sets a specify value to current class CFOEditControl
	// Parameters:
	//		lpszString---lpszString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetWindowText(LPCTSTR lpszString);

	// Pre sub class window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Subclass Window, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PreSubclassWindow();

	// Window process.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Default Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);

	// Reset prompt.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Prompt, Called this function to empty a previously initialized CFOEditControl object.

	void ResetPrompt();

public:

	//{{AFX_MSG(CFOEditControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ctl Color, .
	//		Returns A afx_msg HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Show Window, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.  
	//		nStatus---nStatus, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
#if _MFC_VER >= 0x0400
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ime Start Event, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnImeStartEvent(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ime End Event, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnImeEndEvent(WPARAM wParam, LPARAM lParam);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
public:

	// Check Data Validate, This member sets TRUE if it is right.  
	BOOL				m_bCheckRight;

	// Is active.
 
	// Validate, This member sets TRUE if it is right.  
	BOOL				m_bValidate;

	// Clipboard format text.
 
	// Clipboard Format, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nClipFormat;

	// Save text string.
 
	// Save Char, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strSaveChar;

	// Empty save char.
 
	// Empty, This member sets TRUE if it is right.  
	BOOL				m_bEmpty;

	//
 
	// Adjust Edit , This member sets TRUE if it is right.  
	BOOL				m_bAdjustEditControl;
	
	// Height.
 
	// Char Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCharHeight;

	// Width.
 
	// Char Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nCharWidth;

	// TRUE = user has not yet selected this control
 
	// First Time, This member sets TRUE if it is right.  
	BOOL				m_bFirstTime;	
	
	// prompt text to display initially
 
	// Prompt Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString				m_strPromptText;	

	// color to use for prompt text
 
	// Prompt Color, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crPromptColor;	

	// background brush for WM_CTLCOLOR
 
	// The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush				m_brush;			

	// Saving position.
	FOPRect				m_rcSave;
};

/////////////////////////////////////////////////////////////////////////////
// CFOHotSpotEditControl control -- hot spot edit control.

 
//===========================================================================
// Summary:
//     The CFOHotSpotEditControl class derived from CFOEditControl
//      F O Hot Spot Edit 
//===========================================================================

class FO_EXT_CLASS CFOHotSpotEditControl: public CFOEditControl
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Hot Spot Edit , Constructs a CFOHotSpotEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOHotSpotEditControl(CFODrawShape* pShape);

protected:

	// Init children position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Pointer of hot spot
 
	// Hot Spot, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem* m_pHotSpot;

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOHotSpotEditControl)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPasswordEditControl control -- password edit control.

 
//===========================================================================
// Summary:
//     The CFOPasswordEditControl class derived from CFOEditControl
//      F O Password Edit 
//===========================================================================

class FO_EXT_CLASS CFOPasswordEditControl: public CFOEditControl
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Password Edit , Constructs a CFOPasswordEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOPasswordEditControl(CFODrawShape* pShape);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Do copy action.
	virtual BOOL Copy();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Do cut action.
	virtual BOOL Cut();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPasswordEditControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CFONumberEditControl control -- number edit control.

 
//===========================================================================
// Summary:
//     The CFONumberEditControl class derived from CFOEditControl
//      F O Number Edit 
//===========================================================================

class FO_EXT_CLASS CFONumberEditControl: public CFOEditControl
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Number Edit , Constructs a CFONumberEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFONumberEditControl(CFODrawShape* pShape);

protected:
	
	// Number of the value
 
	// Number, This member specify double object.  
	double		m_dNumber;

	// Number of the precision
 
	// Precision, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nPrecision;

	// Is neg enable or not
 
	// Neg Values, This member sets TRUE if it is right.  
	BOOL		m_bNegValues;

	// Label of the edit control
 
	// Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strText;

public:	

	// Init value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Initial, .
	// Parameters:
	//		dNumber---dNumber, Specifies a double dNumber  = 0.00 object(Value).  
	//		nPrecision---nPrecision, Specifies A integer value.  
	//		bNegValues---Neg Values, Specifies A Boolean value.
	void WhenInit(double	dNumber		= 0.00,	
				   int		nPrecision	= 2,
				   BOOL		bNegValues  = TRUE);

	// Change the state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change State, .
	// Parameters:
	//		dNumber---dNumber, Specifies a double dNumber object(Value).  
	//		nPrecision---nPrecision, Specifies A integer value.  
	//		bNegValues---Neg Values, Specifies A Boolean value.
	void ChangeState(double	dNumber,	
				   int		nPrecision,
				   BOOL		bNegValues);
public:	

	// Obtain the number text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetNumberText();

	// Obtain the number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Number, Returns the specified value.
	//		Returns A double value (Object).
	double	GetNumber();

	// Change number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Number, Sets a specify value to current class CFONumberEditControl
	// Parameters:
	//		dNumber---dNumber, Specifies a double dNumber object(Value).
	void	SetNumber(double dNumber);

protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Update, Call this member function to update the object.

	// Update
	void	Update();

	// Obtain the edit control text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Edit  Text, Returns the specified value.

	void	GetEditCtrlText();

	// Change edit control text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Edit  Text, Sets a specify value to current class CFONumberEditControl
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	void	SetEditCtrlText(CString strText);

	// Validate char
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Validate Char, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL	DoValidateChar(UINT nChar);

	// Convert text to number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Text To Number, .
	//		Returns A double value (Object).  
	// Parameters:
	//		strText---strText, Specifies A CString type value.
	double	ConvertTextToNumber(CString strText);

	// Convert number to text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Number To Text, .
	//		Returns a CString type value.  
	// Parameters:
	//		dNumber---dNumber, Specifies a double dNumber object(Value).
	CString ConvertNumberToText(double dNumber);
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFONumberEditControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Setfocus, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSetfocus();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnKillFocus();	
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPCalcEditControl control -- edit box with button, when clicking on the button
//				it will show a drop down calculator picker.

 
//===========================================================================
// Summary:
//     The CFOPCalcEditControl class derived from CFONumberEditControl
//      F O P Calculate Edit 
//===========================================================================

class FO_EXT_CLASS CFOPCalcEditControl: public CFONumberEditControl
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Calculate Edit , Constructs a CFOPCalcEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOPCalcEditControl(CFODrawShape* pShape);

protected:

	// Init children position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Parse value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Parse Value, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pcsz---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dValue---dValue, Specifies a double& dValue object(Value).  
	//		bNegative---bNegative, Specifies A Boolean value.
	BOOL DoParseValue(LPCTSTR pcsz, double& dValue,BOOL& bNegative);

	// Find digits
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Find First And Last Digits, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		p---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nFirst---nFirst, Specifies A integer value.  
	//		nLast---nLast, Specifies A integer value.
	BOOL DoFindFirstAndLastDigits(LPCTSTR p, int& nFirst, int& nLast);

	// Find separator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Find Decimal Separator, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		pcszString---pcszString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		cDecimal---cDecimal, Specifies a TCHAR cDecimal  = _T('\0') object(Value).
	int DoFindDecimalSeparator(LPCTSTR pcszString, TCHAR cDecimal  = _T('\0'));

	// Pointer of hot spot
 
	// Hot Spot, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem* m_pHotSpot;

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPCalcEditControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Calculate Set Text, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCalcSetText(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOSpinEditControl control -- edit box with spin button at right side.

 
//===========================================================================
// Summary:
//     The CFOSpinEditControl class derived from CFOEditControl
//      F O Spin Edit 
//===========================================================================

class FO_EXT_CLASS CFOSpinEditControl: public CFOEditControl
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Spin Edit , Constructs a CFOSpinEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOSpinEditControl(CFODrawShape* pShape);

public:

	// Set range of value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Range, Sets a specify value to current class CFOSpinEditControl
	// Parameters:
	//		&nMin---&nMin, Specifies A integer value.  
	//		&nMax---&nMax, Specifies A integer value.
	void SetRange(const int &nMin,const int &nMax);

protected:

	// Do left button down action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDown(UINT nFlags, CPoint pt, UINT nHitState);

	// Do left button up action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Mouse hit
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mouse Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoMouseMove(UINT nFlags, CPoint pt, UINT nState);

	// Init children position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Support for several child buttons (HotSpot, Combobox, Spinnbuttons)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChild---pChild, A pointer to the CFOChildItem or NULL if the call failed.
	virtual void DoClickEvent(CFOChildItem* pChild);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOSpinEditControl)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Leave, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnMouseLeave(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Pointer of up arrow button.
 
	// Up Arrow, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem*	m_pUpArrow;

	// Pointer of down arrow button.
 
	// Down Arrow, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem*	m_pDownArrow;

	// Minimize bound value.
 
	// Minimize Bound, Specify a A 32-bit signed integer.  
	LONG			m_nMinBound;

	// Maximize bound value.
 
	// Maximize Bound, Specify a A 32-bit signed integer.  
	LONG			m_nMaxBound;

	// With min bound
 
	// Minimize Bound, This member sets TRUE if it is right.  
	BOOL			m_bMinBound;

	// With max bound
 
	// Maximize Bound, This member sets TRUE if it is right.  
	BOOL			m_bMaxBound;

	// Start value or not
 
	// Start Value, This member sets TRUE if it is right.  
	BOOL			m_bStartValue;

	// Start value.
 
	// Start Value, Specify a A 32-bit signed integer.  
	LONG			m_nStartValue;

	// Mouse moving track
 
	// Tracked, This member sets TRUE if it is right.  
	BOOL			m_bTracked;
};

/////////////////////////////////////////////////////////////////////////////
// CFOMaskData -- mask data for editing.

 
//===========================================================================
// Summary:
//     The CFOMaskData class derived from CObject
//      F O Mask Data
//===========================================================================

class FO_EXT_CLASS CFOMaskData: public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMaskData---F O Mask Data, Specifies a E-XD++ CFOMaskData object (Value).
	DECLARE_DYNCREATE(CFOMaskData);

public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Mask Data, Constructs a CFOMaskData object.
	//		Returns A  value (Object).
	CFOMaskData();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Mask Data, Destructor of class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMaskData();

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Empty, .
	// This member function is also a virtual function, you can Override it if you need,
	// Empty data
	virtual void Empty();

	// Prepare mask
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mask, Sets a specify value to current class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strMask---strMask, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void SetMask(LPCTSTR strMask);

	// Data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Data, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strData---strData, Specifies A CString type value.  
	//		nFirstChar---First Char, Specifies A integer value.  
	//		nLastChar---Last Char, Specifies A integer value.  
	//		bTrim---bTrim, Specifies A Boolean value.
	virtual void GetData(CString& strData, int nFirstChar = 0, 
		int nLastChar = -1, BOOL bTrim = TRUE) const;

	// Set data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Data, Sets a specify value to current class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		strData---strData, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nStartPos---Start Position, Specifies A integer value.  
	//		bInsert---bInsert, Specifies A Boolean value.
	virtual int SetData(LPCTSTR strData, int nStartPos = -1, BOOL bInsert = FALSE);

	// Get display string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Display String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strDisplay---strDisplay, Specifies A CString type value.  
	//		nFirstChar---First Char, Specifies A integer value.  
	//		nLastChar---Last Char, Specifies A integer value.
	virtual void GetShowText(CString& strDisplay, int nFirstChar = 0, int nLastChar = -1) const;

	// Set display string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Display String, Sets a specify value to current class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		strDisplay---strDisplay, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nStartPos---Start Position, Specifies A integer value.  
	//		bInsert---bInsert, Specifies A Boolean value.
	virtual int SetShowText(LPCTSTR strDisplay, int nStartPos = -1, BOOL bInsert = FALSE);

	// Set prompt char
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Prompt Char, Sets a specify value to current class CFOMaskData
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strPrompt---strPrompt, Specifies A CString type value.  
	//		bUpdateDisplayString---Update Display String, Specifies A Boolean value.
	BOOL SetBackChar(const CString& strPrompt, BOOL bUpdateDisplayString = TRUE);

	// Is current char validate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Char Valid, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		sChar---sChar, Specifies A CString type value.
	virtual BOOL IsCharValid(int nPos, CString& sChar) const;

	// Get next data position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Data Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nOldPos---Old Position, Specifies A integer value.
	virtual int GetNextIndex(int nOldPos) const;

	// Get previous data position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Data Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nOldPos---Old Position, Specifies A integer value.
	virtual int GetPrevIndex(int nOldPos) const;

	// Find last fill data position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Last Filled Data Position, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nStartPos---Start Position, Specifies A integer value.
	virtual int FindNeeded(int nStartPos) const;

	// Push char
	
	//-----------------------------------------------------------------------
	// Summary:
	// Push Char, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nStartPos---Start Position, Specifies A integer value.  
	//		strChar---strChar, Specifies A CString type value.  
	//		nNextPos---Next Position, Specifies A integer value.
	virtual int PushChar(int nStartPos, const CString& strChar, int& nNextPos);
	
	// Add a char
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pull Char, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFromPos---From Position, Specifies A integer value.  
	//		nToPos---To Position, Specifies A integer value.
	virtual void PullChar(int nFromPos, int nToPos);

	// Validation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Valid Display String, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsValidText() const;

	// Is empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty Mask, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsEmptyMask() const;

	// Get text length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Length, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetTextLength() const;

	// Get edit pos
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Edit Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nCharPos---Char Position, Specifies A integer value.
	virtual int GetEditPos(int nCharPos) const;

	// Get char pos
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Char Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nEditPos---Edit Position, Specifies A integer value.
	virtual int GetCharPos(int nEditPos) const;

	// Clear data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Data, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearData();

	// Set max length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Length, Sets a specify value to current class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.
	virtual void SetMaxLength(int nLength);

	// Set max length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Length, Sets a specify value to current class CFOMaskData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int SetMaxLength() const;

	// Overridables
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mask Char, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ch---Specifies a TCHAR ch object(Value).
	virtual BOOL IsMaskChar(TCHAR ch) const;

	// Helper functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is best pos, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	virtual BOOL IsBestPos(int nPos) const;

protected:

	// Holds the mask chars
 
	// String Mask, The member supports arrays of CString objects.  
	CStringArray	m_arStrMask;     
	
	// Holds information which characters are literal
 
	// Is Literal, This member specify CByteArray object.  
	CByteArray		m_arIsBestPos;      

	// Holds the display string
 
	// String Display, The member supports arrays of CString objects.  
	CStringArray	m_arStrDisplay;    

	// The prompt character, space is default.
 
	// Prompt, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_sPrompt; 
	
	// Ignore Mask when it is empty
 
	// Ignore Empty Mask, This member sets TRUE if it is right.  
	BOOL			m_bIgnoreEmptyMask;   
    
	// Use this as maximum length when mask is empty
 
	// Maximize Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMaxLength;              
#ifdef _MBCS
 
	// D B C S Enabled, This member sets TRUE if it is right.  
	static BOOL		m_bDBCSEnabled;
#endif
};

/////////////////////////////////////////////////////////////////////////////
// CFOMaskEditControl -- edit box with mask editing.

 
//===========================================================================
// Summary:
//     The CFOMaskEditControl class derived from CEdit
//      F O Mask Edit 
//===========================================================================

class FO_EXT_CLASS CFOMaskEditControl : public CEdit, public CFOControlBase
{
	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Mask Edit , Constructs a CFOMaskEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		pDataClass---Data Class, A pointer to the CRuntimeClass or NULL if the call failed.
	CFOMaskEditControl(CFODrawShape* pShape = NULL,
		CRuntimeClass* pDataClass = RUNTIME_CLASS(CFOMaskData));
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Mask Edit , Destructor of class CFOMaskEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMaskEditControl();
	
public:
	
	// Create control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFOMaskEditControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent,int nID,DWORD dwStyle = 0, LPRECT lpRect = NULL);

	// Attach data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Data, Attaches this object.
	// Parameters:
	//		pDataClass---Data Class, A pointer to the CRuntimeClass or NULL if the call failed.
	void AttachData(CRuntimeClass* pDataClass = RUNTIME_CLASS(CFOMaskData));
	
	// Get wnd ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Send notify message.
	BOOL SendNotifyMsg();
	
	// Is active status.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();
	
	// Set active status
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOMaskEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Send event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Send Event, .
	// Parameters:
	//		nEvent---nEvent, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SendEvent(UINT nEvent);
	
	// Set modify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOMaskEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();
	
	// Init mask
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Mask, Call InitMask after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		sMask---sMask, Specifies A CString type value.  
	//		sPrompt---sPrompt, Specifies A CString type value.  
	//		nLength---nLength, Specifies A integer value.
	virtual void InitMask(CString sMask,CString sPrompt,int nLength) const;
	
	// Update display
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Display, Call this member function to update the object.
	// Parameters:
	//		lpszText---lpszText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void UpdateDisplay(LPCTSTR lpszText = NULL);
	
	// Get current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOMaskEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();
	
	// Get char sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Char Select, Returns the specified value.
	// Parameters:
	//		nPosition---nPosition, Specifies A integer value.  
	//		nEndPos---End Position, Specifies A integer value.
	void GetRangeChar(int& nPosition, int& nEndPos) const;

	// Set char sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Char Select, Sets a specify value to current class CFOMaskEditControl
	// Parameters:
	//		nPosition---nPosition, Specifies A integer value.  
	//		nEndPos---End Position, Specifies A integer value.  
	//		bNoScroll---No Scroll, Specifies A Boolean value.
	void SetRangeChar(int nPosition, int nEndPos, BOOL bNoScroll = FALSE);
	
	// Clipboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Copy text to clipboard.
	virtual BOOL Copy();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Paste text from clipboard.
	virtual BOOL Paste();
	
	// Copy text to clipboard and delete the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Cut();
	
	// Can copy text to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Copy, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCopy();
	
	// Can cut text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Cut, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCut();
	
	// Can paste text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Paste, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanPaste();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Clear text
	virtual BOOL Clear();
	
	// Replace sel text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszReplaceText---Replace Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR pszReplaceText);
	
	// Get last visible line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last Visible Line, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		lprect---Specifies a LPRECT lprect = NULL object(Value).
	int   GetLastLine(LPRECT lpRect = NULL);

	// Get selected text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual BOOL GetSelectedText(CString& strResult);
	
	// Edit control only
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Color, Sets a specify value to current class CFOMaskEditControl
	// Parameters:
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.
	void SetCellColor(COLORREF rgb);

	// Get sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	// Parameters:
	//		nStartChar---Start Char, Specifies A integer value.  
	//		nEndChar---End Char, Specifies A integer value.
	void GetSel(int& nStartChar, int& nEndChar) const;

	// Get selection
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select, Returns the specified value.
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD GetSel() const;
	
	// Pre trans message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Do notify msg.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Notify Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL DoNotifyMsg(WPARAM wParam, LPARAM lParam);

	// Override this method to initialize the rectangle of the children
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Attributes
public:

	// Mask data.
 
	// Mask, This member maintains a pointer to the object CFOMaskData.  
	CFOMaskData*    m_pMask;

protected:
	//{{AFX_MSG(CFOMaskEditControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT flags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT flags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Show Window, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.  
	//		nStatus---nStatus, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
#if _MFC_VER >= 0x0300
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:
	
	// Active
 
	// Validate, This member sets TRUE if it is right.  
	BOOL            m_bValidate;

	// Insert mode
 
	// Insert Mode, This member sets TRUE if it is right.  
	BOOL            m_bInsertMode;

	// Height
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_dyHeight;

	// Force
 
	// Force Replace Data, This member sets TRUE if it is right.  
	BOOL			m_bForce;

};

/////////////////////////////////////////////////////////////////////////////
// CFODateTimeControl control -- edit control with a button at right side, when click
//				on this button, it will shows a date time picker.

 
//===========================================================================
// Summary:
//     The CFODateTimeControl class derived from CFOMaskEditControl
//      F O Date Time 
//===========================================================================

class FO_EXT_CLASS CFODateTimeControl : public CFOMaskEditControl
{
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Date Time , Constructs a CFODateTimeControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFODateTimeControl(CFODrawShape* pShape = NULL);

public:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Date Time , Destructor of class CFODateTimeControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODateTimeControl();

	// Init children position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Pointer of hot spot
 
	// Hot Spot, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem* m_pHotSpot;

	// Generated message map functions
protected:

	//{{AFX_MSG(CFODateTimeControl)
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CFOComboListBox control -- extend list box.

 
//===========================================================================
// Summary:
//     The CFOComboListBox class derived from CListBox
//      F O Combo List Box
//===========================================================================

class FO_EXT_CLASS CFOComboListBox : public CListBox
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOComboListBox---F O Combo List Box, Specifies a E-XD++ CFOComboListBox object (Value).
	DECLARE_DYNAMIC(CFOComboListBox)

// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Combo List Box, Constructs a CFOComboListBox object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pMsgWnd---Message Window, A pointer to the CWnd or NULL if the call failed.
	CFOComboListBox(CWnd* pMsgWnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Combo List Box, Destructor of class CFOComboListBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOComboListBox();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOComboListBox object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create control.
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
protected:
	virtual void PreSubclassWindow();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
// Operations
public:
	CFODrawShape *m_pShape;
	// background color
	COLORREF m_crTrueBack;
	COLORREF m_crTrueText;
	
protected:
	// Generated message map functions
	//{{AFX_MSG(CFOComboListBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Implementation
protected:
	// Key down
 
	// Key Down, This member sets TRUE if it is right.  
	BOOL		m_bKeyDown;

	// Left button down
 
	// L Button Down, This member sets TRUE if it is right.  
	BOOL		m_bLButtonDown;

	// Pointer of msg wnd
 
	// Message Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*		m_pMsgWnd;

	// With color
 
	// Color, This member sets TRUE if it is right.  
	BOOL		m_bColor;

	// Back color
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// Old sel
 
	// Old Select, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nOldSel;

	// Number
 
	// Al Number, This member sets TRUE if it is right.  
	BOOL		m_bAlNum;

	// Rep count
 
	// Rep Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRepCnt;

};


/////////////////////////////////////////////////////////////////////////////
// CFOCtrlCombo control -- combo window.

 
//===========================================================================
// Summary:
//     The CFOCtrlCombo class derived from CWnd
//      F O  Combo
//===========================================================================

class FO_EXT_CLASS CFOCtrlCombo : public CWnd
{
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O  Combo, Constructs a CFOCtrlCombo object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pViewWnd---View Window, A pointer to the CWnd or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		rect---Specifies a const FOPRect& rect object(Value).
	CFOCtrlCombo(CWnd* pViewWnd, CWnd* pWnd, const FOPRect& rect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O  Combo, Destructor of class CFOCtrlCombo
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCtrlCombo();

public:
	
	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOCtrlCombo
	// Parameters:
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.
	void SetColor(COLORREF crText, COLORREF crBack);

	// Get list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get L Box, Returns the specified value.
	//		Returns A CListBox& value (Object).
	CListBox& GetLBox();

	// Register class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register Class, Write a specify value to registry.
	// This member function is a static function.
	static void RegisterClass();

	// Un register class
	
	//-----------------------------------------------------------------------
	// Summary:
	// Unregister Class, Unregistry a specify value.
	// This member function is a static function.
	static void UnregisterClass();

	// Set combobox drop down
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Combo Box Drop Down, Sets a specify value to current class CFOCtrlCombo
	// This member function is a static function.
	// Parameters:
	//		b---Specifies A Boolean value.
	static void SetComboBoxDropDown(BOOL b = TRUE);

	// Class name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Class Name, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.
	static CString GetClassName();

	// Attach list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach List Box, Attaches this object.
	// Parameters:
	//		pListBox---List Box, A pointer to the CWnd or NULL if the call failed.
	void AttachListBox(CWnd* pListBox);

protected:
	// overridables
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Generated message map functions
	//{{AFX_MSG(CFOCtrlCombo)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctl Color, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Command, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Pointer of list box
 
	// List Box, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*       m_pListBox;

	// Pointer of parent wnd
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*       m_pParentWindow;

	// Has color
 
	// Color, This member sets TRUE if it is right.  
	BOOL        m_bColor;

	// Brush
 
	// The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush      m_br;

	// Text color.
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF    m_crText;

	// Back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

};

/////////////////////////////////////////////////////////////////////////////
// CFOComboBoxControl control -- a combo box editing field that derived from edit control.
//				this is defined for this combo box only.

 
//===========================================================================
// Summary:
//     The CFOComboBoxControl class derived from CFOEditControl
//      F O Combo Box 
//===========================================================================

class FO_EXT_CLASS CFOComboBoxControl: public CFOEditControl
{

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Combo Box , Constructs a CFOComboBoxControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nListBoxID---List Box I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOComboBoxControl(CFODrawShape* pShape,UINT nListBoxID, UINT nFlags);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Combo Box , Destructor of class CFOComboBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOComboBoxControl();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mouse Activate, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDesktopWnd---Desktop Window, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		retval---Specifies A integer value.
	// WM_MOUSEACTIVATE message
	virtual BOOL MouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message, int& retval);

	// override this method for ownerdrawn list-boxes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Down, You construct a CFOComboBoxControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCtrlCombo,or NULL if the call failed  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual CFOCtrlCombo* CreateDropDown(CWnd* pWnd, const FOPRect& rect);

	// Create list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create List Box, You construct a CFOComboBoxControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* CreateListBox(CWnd* pParentWnd, UINT nID = 0);

	// Show drop down
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Drop Down, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	virtual void ShowDropDown(BOOL bShow);

	// Get drop state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dropped State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetDroppedState();

	// Replace sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszReplaceText---Replace Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR pszReplaceText);

	// Do draw state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

	// Status
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOComboBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Called from OnChar (lets you change the nChar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char Extend, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnMoreChar(UINT nChar, UINT nRepCnt, UINT flags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOComboBoxControl object.
	// This member function is also a virtual function, you can Override it if you need,
	// Reset data
	virtual void Reset();

	// Notify message
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual void OnNotifyMsg(MSG* pMsg);

	// Set choice list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CFOComboBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&str---Specifies A CString type value.
	virtual void SetChoiceList(const CString &str);

	// Pre trans message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	// Init children
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Do click event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChild---pChild, A pointer to the CFOChildItem or NULL if the call failed.
	virtual void DoClickEvent(CFOChildItem* pChild);

	// Override these methods if you don't want to fill the list from the coice-list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Message, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CListBox or NULL if the call failed.
	virtual void DoSaveMsg(CListBox* lbox);

	// Fill dropped list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill List Box, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CListBox or NULL if the call failed.
	virtual void DoFillListBox(CListBox* lbox);

	// Override this method for changing the defaulting listbox size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Compute List Box Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		rcCellRect---Cell Rectangle, Specifies a const FOPRect& rcCellRect object(Value).
	virtual FOPRect DoComputeListBoxPosition(const FOPRect& rcCellRect);

	// Destroy drop down wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy List Box, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDropDownWnd---Drop Down Window, A pointer to the CWnd or NULL if the call failed.
	virtual void DestroyListBox(CWnd* pDropDownWnd);

	// Attributes:
public:
	// Fill with choice lsit
 
	// Fill List Items, This member sets TRUE if it is right.  
	BOOL            m_bFillListItems;

	// Flags
 
	// Flags, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT            m_nFlags;

	// List box style
 
	// List Box Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD           m_dwListBoxStyle;

	// Drop down only
 
	// Dropdown Only, This member sets TRUE if it is right.  
	BOOL            m_bDropdownOnly;

	// Size to content
 
	// Size To Content, This member sets TRUE if it is right.  
	BOOL            m_bSizeToContent;

	// List choice
 
	// Choice List, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strChoiceList;

protected:

	// Button
 
	// Button, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem*   m_pButton;

	// List box id
 
	// List Box I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT            m_nListBoxID;

	// Drop down control wnd
 
	// Drop Down Window, This member maintains a pointer to the object CFOCtrlCombo.  
	CFOCtrlCombo*   m_pDropDownWnd;

	// Default height
 
	// Default Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nDefaultHeight;

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOComboBoxControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Select Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoEndSelectMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoCancelMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Modify Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoModifyMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Kill Focus Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoKillFocusMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOCheckBoxList window

class FO_EXT_CLASS CFOCheckBoxList : public CCheckListBox
{
	// Construction
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOComboCheckListBox---F O Combo List Box, Specifies a E-XD++ CFOComboCheckListBox object (Value).
	DECLARE_DYNAMIC(CFOCheckBoxList)

public:
	CFOCheckBoxList();
	
	// Attributes
protected:
	CArray<BOOL, BOOL>	m_arCheckData;
	
	// Operations
public:
	void EnableCheck (int nIndex, BOOL bEnable = TRUE);
	BOOL IsCheckEnabled (int nIndex) const;

	int GetTotalItems();
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOCheckBoxList)
protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	virtual ~CFOCheckBoxList();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOCheckBoxList)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	LRESULT OnLBAddString(WPARAM wParam, LPARAM lParam);
	LRESULT OnLBInsertString(WPARAM wParam, LPARAM lParam);
	LRESULT OnLBResetContent(WPARAM wParam, LPARAM lParam);
	LRESULT OnLBDeleteString(WPARAM wParam, LPARAM lParam);
	
	DECLARE_MESSAGE_MAP()
		
		void OnNewString (int iIndex);
};

/////////////////////////////////////////////////////////////////////////////
// CFOCheckListBoxControl control -- list box control.

 
//===========================================================================
// Summary:
//     The CFOCheckListBoxControl class derived from CFOCheckBoxList
//      F O List Box 
//===========================================================================

class FO_EXT_CLASS CFOCheckListBoxControl: public CFOCheckBoxList, public CFOControlBase
{
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Box , Constructs a CFOCheckListBoxControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOCheckListBoxControl(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Box , Destructor of class CFOCheckListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCheckListBoxControl();

public:
	// Wnd ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Create control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFOCheckListBoxControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent,int nID,LPRECT lpRect = NULL);

	// Set activate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOCheckListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Is active
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOCheckListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();

	// Get Current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOCheckListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Init();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Do left button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint pt);

	// Do key pressed action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Notifications
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Listbox control only
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill List Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	virtual void FillListBox(const CString &strChoice);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOCheckListBoxControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Active or not
 
	// Validate, This member sets TRUE if it is right.  
	BOOL            m_bValidate;

	// Modify flag
 
	// Is Modify, This member sets TRUE if it is right.  
	BOOL            m_bIsModify;

	// Text color
 
	// Hilight Text, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crHilightText;

	// Height
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_dyHeight;

	// Select text
 
	// Select Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strSelectText;

};


/////////////////////////////////////////////////////////////////////////////
// CFOComboCheckListBox control -- extend list box.

 
//===========================================================================
// Summary:
//     The CFOComboCheckListBox class derived from CFOCheckBoxList
//      F O Combo List Box
//===========================================================================

class FO_EXT_CLASS CFOComboCheckListBox : public CFOCheckBoxList
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOComboCheckListBox---F O Combo List Box, Specifies a E-XD++ CFOComboCheckListBox object (Value).
	DECLARE_DYNAMIC(CFOComboCheckListBox)

// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Combo List Box, Constructs a CFOComboCheckListBox object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pMsgWnd---Message Window, A pointer to the CWnd or NULL if the call failed.
	CFOComboCheckListBox(CWnd* pMsgWnd);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Combo List Box, Destructor of class CFOComboCheckListBox
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOComboCheckListBox();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOComboCheckListBox object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	// Create control.
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

// Operations
public:

	// Set back color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Back Color, Sets a specify value to current class CFOComboCheckListBox
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetBackColor(COLORREF crColor);

protected:
	// Generated message map functions
	//{{AFX_MSG(CFOComboCheckListBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Implementation
protected:
	// Key down
 
	// Key Down, This member sets TRUE if it is right.  
	BOOL		m_bKeyDown;

	// Left button down
 
	// L Button Down, This member sets TRUE if it is right.  
	BOOL		m_bLButtonDown;

	// Pointer of msg wnd
 
	// Message Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*		m_pMsgWnd;

	// With color
 
	// Color, This member sets TRUE if it is right.  
	BOOL		m_bColor;

	// Back color
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// Old sel
 
	// Old Select, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nOldSel;

	// Number
 
	// Al Number, This member sets TRUE if it is right.  
	BOOL		m_bAlNum;

	// Rep count
 
	// Rep Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nRepCnt;

};


/////////////////////////////////////////////////////////////////////////////
// CFOCtrlCheckCombo control -- combo window.

 
//===========================================================================
// Summary:
//     The CFOCtrlCheckCombo class derived from CWnd
//      F O  Combo
//===========================================================================

class FO_EXT_CLASS CFOCtrlCheckCombo : public CWnd
{
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O  Combo, Constructs a CFOCtrlCheckCombo object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pViewWnd---View Window, A pointer to the CWnd or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		rect---Specifies a const FOPRect& rect object(Value).
	CFOCtrlCheckCombo(CWnd* pViewWnd, CWnd* pWnd, const FOPRect& rect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O  Combo, Destructor of class CFOCtrlCheckCombo
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCtrlCheckCombo();

public:
	
	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOCtrlCheckCombo
	// Parameters:
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.
	void SetColor(COLORREF crText, COLORREF crBack);

	// Get list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get L Box, Returns the specified value.
	//		Returns A CFOCheckBoxList& value (Object).
	CFOCheckBoxList& GetLBox();

	// Register class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register Class, Write a specify value to registry.
	// This member function is a static function.
	static void RegisterClass();

	// Un register class
	
	//-----------------------------------------------------------------------
	// Summary:
	// Unregister Class, Unregistry a specify value.
	// This member function is a static function.
	static void UnregisterClass();

	// Set combobox drop down
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Combo Box Drop Down, Sets a specify value to current class CFOCtrlCheckCombo
	// This member function is a static function.
	// Parameters:
	//		b---Specifies A Boolean value.
	static void SetComboBoxDropDown(BOOL b = TRUE);

	// Class name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Class Name, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.
	static CString GetClassName();

	// Attach list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach List Box, Attaches this object.
	// Parameters:
	//		pListBox---List Box, A pointer to the CWnd or NULL if the call failed.
	void AttachListBox(CWnd* pListBox);

protected:
	// overridables
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Generated message map functions
	//{{AFX_MSG(CFOCtrlCheckCombo)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctl Color, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Command, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Pointer of list box
 
	// List Box, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*       m_pListBox;

	// Pointer of parent wnd
 
	// Parent Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*       m_pParentWindow;

	// Has color
 
	// Color, This member sets TRUE if it is right.  
	BOOL        m_bColor;

	// Brush
 
	// The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush      m_br;

	// Text color.
 
	// Text, This member sets A 32-bit value used as a color value.  
	COLORREF    m_crText;

	// Back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

};

/////////////////////////////////////////////////////////////////////////////
// CFOCheckComboControl control -- a combo box editing field that derived from edit control.
//				this is defined for this combo box only.

 
//===========================================================================
// Summary:
//     The CFOCheckComboControl class derived from CFOEditControl
//      F O Combo Box 
//===========================================================================

class FO_EXT_CLASS CFOCheckComboControl: public CFOEditControl
{

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Combo Box , Constructs a CFOCheckComboControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nListBoxID---List Box I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOCheckComboControl(CFODrawShape* pShape,UINT nListBoxID, UINT nFlags);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Combo Box , Destructor of class CFOCheckComboControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCheckComboControl();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mouse Activate, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDesktopWnd---Desktop Window, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		retval---Specifies A integer value.
	// WM_MOUSEACTIVATE message
	virtual BOOL MouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message, int& retval);

	// override this method for ownerdrawn list-boxes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Down, You construct a CFOCheckComboControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCtrlCheckCombo,or NULL if the call failed  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual CFOCtrlCheckCombo* CreateDropDown(CWnd* pWnd, const FOPRect& rect);

	// Create list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create List Box, You construct a CFOCheckComboControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* CreateListBox(CWnd* pParentWnd, UINT nID = 0);

	// Show drop down
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Drop Down, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	virtual void ShowDropDown(BOOL bShow);

	// Get drop state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dropped State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetDroppedState();

	// Replace sel
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszReplaceText---Replace Text, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR pszReplaceText);

	// Do draw state
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

	// Status
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOCheckComboControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Called from OnChar (lets you change the nChar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char Extend, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnMoreChar(UINT nChar, UINT nRepCnt, UINT flags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset, Called this function to empty a previously initialized CFOCheckComboControl object.
	// This member function is also a virtual function, you can Override it if you need,
	// Reset data
	virtual void Reset();

	// Notify message
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual void OnNotifyMsg(MSG* pMsg);

	// Set choice list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice List, Sets a specify value to current class CFOCheckComboControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&str---Specifies A CString type value.
	virtual void SetChoiceList(const CString &str);

	// Pre trans message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

public:
	// Init children
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void DoInit(const FOPRect& rect);

	// Do click event
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChild---pChild, A pointer to the CFOChildItem or NULL if the call failed.
	virtual void DoClickEvent(CFOChildItem* pChild);

	// Override these methods if you don't want to fill the list from the coice-list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Message, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CFOCheckBoxList or NULL if the call failed.
	virtual void DoSaveMsg(CFOCheckBoxList* lbox);

	// Fill dropped list box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill List Box, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CFOCheckBoxList or NULL if the call failed.
	virtual void DoFillListBox(CFOCheckBoxList* lbox);

	// Override this method for changing the defaulting listbox size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Compute List Box Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		rcCellRect---Cell Rectangle, Specifies a const FOPRect& rcCellRect object(Value).
	virtual FOPRect DoComputeListBoxPosition(const FOPRect& rcCellRect);

	// Destroy drop down wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy List Box, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDropDownWnd---Drop Down Window, A pointer to the CWnd or NULL if the call failed.
	virtual void DestroyListBox(CWnd* pDropDownWnd);

	// Attributes:
public:
	// Fill with choice lsit
 
	// Fill List Items, This member sets TRUE if it is right.  
	BOOL            m_bFillListItems;

	// Flags
 
	// Flags, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT            m_nFlags;

	// List box style
 
	// List Box Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD           m_dwListBoxStyle;

	// Drop down only
 
	// Dropdown Only, This member sets TRUE if it is right.  
	BOOL            m_bDropdownOnly;

	// Size to content
 
	// Size To Content, This member sets TRUE if it is right.  
	BOOL            m_bSizeToContent;

	// List choice
 
	// Choice List, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strChoiceList;

protected:

	// Button
 
	// Button, This member maintains a pointer to the object CFOChildItem.  
	CFOChildItem*   m_pButton;

	// List box id
 
	// List Box I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT            m_nListBoxID;

	// Drop down control wnd
 
	// Drop Down Window, This member maintains a pointer to the object CFOCtrlCheckCombo.  
	CFOCtrlCheckCombo*   m_pDropDownWnd;

	// Default height
 
	// Default Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nDefaultHeight;

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOCheckComboControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Select Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoEndSelectMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cancel Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoCancelMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Modify Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoModifyMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Kill Focus Message, Do a event. 
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT DoKillFocusMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOListBoxControl control -- list box control.

 
//===========================================================================
// Summary:
//     The CFOListBoxControl class derived from CListBox
//      F O List Box 
//===========================================================================

class FO_EXT_CLASS CFOListBoxControl: public CListBox, public CFOControlBase
{
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Box , Constructs a CFOListBoxControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOListBoxControl(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Box , Destructor of class CFOListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOListBoxControl();

public:
	// Wnd ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Create control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFOListBoxControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent,int nID,LPRECT lpRect = NULL);

	// Set activate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Is active
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();

	// Get Current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOListBoxControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Init();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Do left button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint pt);

	// Do key pressed action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Notifications
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Listbox control only
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill List Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	virtual void FillListBox(const CString &strChoice);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOListBoxControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Active or not
 
	// Validate, This member sets TRUE if it is right.  
	BOOL            m_bValidate;

	// Modify flag
 
	// Is Modify, This member sets TRUE if it is right.  
	BOOL            m_bIsModify;

	// Text color
 
	// Hilight Text, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crHilightText;

	// Height
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_dyHeight;

	// Select text
 
	// Select Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strSelectText;

};

// //////////////////////////////////////////////////////////////////////////
// Definition of the font attributes constants.
#define	FOX_BOLD_FONT		0
#define	FOX_ITALIC_FONT		1
#define	FOX_UNDERLINED_FONT	2
#define	FOX_STRIKED_OUT_FONT	3

// Definition of ellipses replacing	mode constants.
#define	FOX_BEGIN_ELLIPSES	4
#define	FOX_MIDDLE_ELLIPSES	5
#define	FOX_END_ELLIPSES		6
#define	FOX_NO_ELLIPSES		7

#define	FOX_ALIGNHORZ_LEFT		0
#define	FOX_ALIGNHORZ_CENTER		1
#define	FOX_ALIGNHORZ_RIGHT		2
#define	FOX_ALIGNVERT_TOP		3
#define	FOX_ALIGNVERT_CENTER		4
#define	FOX_ALIGNVERT_BOTTOM		5

// Definition of PI	constant.
#define	FOX_PI				3.1415926535

// Definition of maximum text 3D offset.
#define	FOX_MAX_3DOFFSET		100

// //////////////////////////////////////////////////////////////////////////

class FO_EXT_CLASS	CFOScrollText :	public CStatic
{
// Data	members	-------------------------------------------------------------
public:
	CBitmap	*m_BMP;

protected:
	int					m_nHorzAlignment;
	int					m_nVertAlignment;

	BOOL				m_bDottedEdge;
	BOOL				m_bAllowRefresh;
	BOOL				m_bEmbossText;
	BOOL				m_bEmbossRaised;
	COLORREF			m_clrEmbossHighLight;
	COLORREF			m_clrEmbossShadow;

	DWORD				m_dwCurrentTickDelta;
	DWORD				m_dwLastTickDelta;
	DWORD				m_dwBeginTickCount;
	DWORD				m_dwEndTickCount;
	DWORD				m_dwBkColor;
	DWORD				m_dwMinTimeOut;
	DWORD				m_dwOffset;
	DWORD				m_dwScrollSpeed;
	DWORD				m_dwScrollTimeOut;
	DWORD				m_dwTextColor;
	LOGFONT				m_LogFont;
	int					m_nEllipseMode;
	int					m_nGraphicsMode;
	int					m_nScrollAmount;
	int					m_nScrollDirection;

	double				m_nXCastDisplacement;
	double				m_nXDisplacement;
	double				m_dXDelta;
	double				m_nYCastDisplacement;
	double				m_nYDisplacement;
	double				m_dYDelta;

	CEvent*				m_pEventLoop;
	CCriticalSection*	m_pCritSecRedrawWait;

	CFont*				m_pObjFont;
	CWinThread*			m_pScrollingThread;
	CString				m_sText;
	CString				m_sTextNarrow;
	
	CSize				m_szTextSize;
	
	CSize				m_szGapSize;

	CRect				m_rectViewMargins;

private:
	// Registered message to to	prepare	bitmap for CFOScrollText object. Used in 
	// PrepareBitmap() function
	//
	static UINT	m_nPrepareBitmap;

// Member functions	---------------------------------------------------------
public:
	// --- In :			dwOffset :		Initilal text 3D offset	(0 by default).
	//					nGraphicsMode :	Initilal text graphics mode	(Compatible	by default).
	//					nHorzAlignment	:	Initial	horizontal text	alignment
	//					nVertAlignment	:	Initial	vertical text alignment
	// --- Out :
	// --- Returns :
	// --- Effect :		Constructs the CFOScrollText object.
	CFOScrollText(DWORD	dwOffset = 0, int nGraphicsMode	= GM_COMPATIBLE, 
		int	nHorzAlignment = FOX_ALIGNHORZ_CENTER, 
		int	nVertAlignment = FOX_ALIGNVERT_CENTER);

	// --- In :
	// --- Out :
	// --- Returns :
	// --- Effect :		Destroys the CFOScrollText object.
	virtual	~CFOScrollText();


	// --- In :			lpszText : Specifies the text to place in the control.
	//							   If NULL,	no text	will be	visible
	//					dwStyle	: Specifies	the	static control's window	style.
	//							  Normal Static	control	styles are not allowed 
	//					rect : Specifies the position and size of the static control.
	//						   It can be either	a RECT structure or	a CRect	object.
	//					pParentWnd : Specifies the CStatic parent window, usually a
	//								 CDialog object. It	must not be	NULL.
	//					nID	: Specifies	the	static control's control ID.
	// --- Out :
	// --- Returns : succesful or not.
	// --- Effect :		Creates	the	CFOScrollText object.
	BOOL Create(LPCTSTR	lpszText, DWORD	dwStyle, const RECT& rect, CWnd* pParentWnd,
		UINT nID = 0xffff );
	
	// --- In :			nAlignment : Text alignment	(can be	left,right and center).
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text horizontal alignment.
	BOOL SetHorzAlignment(int nAlignment, BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text alignment.
	// --- Effect :		Retrieves the text horizontal alignment.
	int	GetHorzAlignment() const;


	// --- In :			nAlignment : Text alignment	(can be	top,bottom and center).
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text vertical alignment.
	BOOL SetVertAlignment(int nAlignment, BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text alignment.
	// --- Effect :		Retrieves the text vertical	alignment.
	int	GetVertAlignment() const;


	// --- In :			dwBkColor :	Text background	color.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text background color.
	BOOL SetBkColor(COLORREF dwBkColor,	BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text background	color.
	// --- Effect :		Retrieves the text background color.
	COLORREF GetBkColor() const;


	// --- In :			dwTextColor	: Text color.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text color.
	BOOL SetTextColor(COLORREF dwTextColor,	BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text color.
	// --- Effect :		Retrieves the text color.
	COLORREF GetTextColor()	const;


	// --- In :			dwTextColor	: Text color.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text color.
	BOOL SetEmboss(BOOL	bEmboss	= TRUE,	BOOL bRaised = FALSE, BOOL bPrepareNow = FALSE,
				   COLORREF	clrHLight =	::GetSysColor(COLOR_BTNHIGHLIGHT),
				   COLORREF	clrShadow =	::GetSysColor(COLOR_BTNSHADOW));

	// --- In :
	// --- Out :
	// --- Returns :	Is the text	embossed or	not
	// --- Effect :		Retrieves the embossed mode
	BOOL GetEmboss() const;
	

	// --- In :			psText : Text string.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text string.
	BOOL SetWindowText(LPCTSTR psText, BOOL	bPrepareNow	= FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Pointer	to the text	string.
	// --- Effect :		Retrieves the text string.
	LPCTSTR	GetText() const;

	BOOL SetGraphicsMode(int nGraphicsMode,	BOOL bPrepareNow = FALSE);
	int	GetGraphicsMode() const;
	BOOL SetEllipseMode(int	nEllipseMode, BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Mode of	symbols/ellipses replacing (see	above).
	// --- Effect :		Retrieves the ellipses replacing mode.
	int	GetEllipseMode() const;

	
	// --- In :			dwOffset :	Text 3D	offset (pixels).
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the text 3D offset	(MAX = FOX_MAX_3DOFFSET).
	//					Function throws	values higher than FOX_MAX_3DOFFSET off.
	BOOL Set3Doffset(DWORD dwOffset, BOOL bPrepareNow =	FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text 3D	offset (pixels).
	// --- Effect :		Retrieves the text 3D offset.
	DWORD Get3Doffset()	const;


	// --- In :			nAttr :	Font attribute.	This parameter can be one of the following values:
	//							FOX_BOLD_FONT		- Bold font.
	//							FOX_ITALIC_FONT		- Italic font.
	//							FOX_UNDERLINED_FONT	- Underlined font.
	//							FOX_STRIKED_OUT_FONT	- Striked out font.
	//					bSet = TRUE	if the attribute is	to be set, otherwise FALSE
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the font attributes.
	BOOL SetFontAttr(int nAttr,	BOOL bSet =	TRUE, BOOL bPrepareNow = FALSE);
	

	// --- In :
	// --- Out :
	// --- Returns :	TRUE - if the font is currently	bold, FALSE	- otherwise.
	// --- Effect :		Returns	whether	the	font is	currenly bold.
	BOOL IsBold() const;

	// --- In :
	// --- Out :
	// --- Returns :	TRUE - if the font is currently	italic,	FALSE -	otherwise.
	// --- Effect :		Returns	whether	the	font is	currenly italic.
	BOOL IsItalic()	const;

	// --- In :
	// --- Out :
	// --- Returns :	TRUE - if the font is currently	underlined,	FALSE -	otherwise.
	// --- Effect :		Returns	whether	the	font is	currenly underlined.
	BOOL IsUnderlined()	const;

	// --- In :
	// --- Out :
	// --- Returns :	TRUE - if the font is currently	striked	out, FALSE - otherwise.
	// --- Effect :		Returns	whether	the	font is	currenly striked out.
	BOOL IsStrikedOut()	const;


	// --- In:		nAngle :	Specifies the angle, in	tenths of degrees, of each line
	//							of text	written	in the font	(relative to the bottom	of the page).
	//				bPrepareNow:TRUE if	internal image has to be rebuild.  If more than	one
	//							feature	of the CFOScrollText control is	set, the last
	//							set	has	to have	this parameter set to TRUE,	to have	the	image build
	// --- Out:
	// --- Returns:	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect:	Sets the text angle.
	BOOL SetStringAngle(int	nAngle,	BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Text angle.
	// --- Effect :		Retrieves the text angle.
	int	GetStringAngle() const;


	// --- In :			nAngle :	Specifies the angle, in	tenths of degrees, of each
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	//								character's	base line (relative	to the bottom of the page).
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the character's angle (works in Advanced graphics mode	only).
	BOOL SetCharAngle(int nAngle, BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Character's	angle.
	// --- Effect :		Retrieves the character's angle.
	int	GetCharAngle() const;


	// --- In :			nCharSet :	Specifies the character	set. The following values are predefined:
	//								ANSI_CHARSET, OEM_CHARSET, SYMBOL_CHARSET, UNICODE_CHARSET.
	//								The	OEM	character set is system	dependent.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the character set.
	BOOL SetCharSet(int	nCharSet, BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Character set.
	// --- Effect :		Retrieves the character	set	(see above).
	int	GetCharSet() const;
	BOOL SetFontHeight(int nHeight,	BOOL bPrepareNow = FALSE);
	BOOL SetFontWidth(int nWidth,	BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Font height.
	// --- Effect :		Retrieves the font height.
	int	GetFontHeight()	const;

	// --- In :
	// --- Out :
	// --- Returns :	Font width.
	// --- Effect :		Retrieves the font width.
	int	GetFontWidth() const;


	// --- In :			sName	- String that specifies	the	typeface name of the font.
	//							The	length of this string must not exceed LF_FACESIZE characters.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the typeface name of the font.
	BOOL SetFontName(LPCTSTR sName,	BOOL bPrepareNow = FALSE);

	// --- In :
	// --- Out :
	// --- Returns :	Typeface name of the font.
	// --- Effect :		Retrieves the typeface name	of the font.
	CString	GetFontName() const;


	// --- In :			plf	- A	pointer	to object of LOGFONT structure that	specifies 
	//							font to	be used	to draw	text.
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the font.
	BOOL SetLogFont(LOGFONT* plf, BOOL bPrepareNow = FALSE);

	// --- In :			plf	- A	pointer	to object of LOGFONT structure we use to copy 
	//							information	about the font currently used to draw text.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Retrieves the font info.
	BOOL GetLogFont(LOGFONT* plf) const;


	// --- In :			bSet - if TRUE,	thin-line border is	set, if	FALSE, it cancels.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the window	thin-line border.
	BOOL SetPlainBorder(BOOL bSet =	TRUE);

	// --- In :			bSet - if TRUE,	three-dimensional border is	set, if	FALSE, it cancels.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the window	three-dimensional border.
	BOOL SetStaticEdge(BOOL	bSet = TRUE);

	// --- In :			bSet - if TRUE,	border with	a sunken edge is set, if FALSE,	it cancels.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the border	with a sunken edge.
	BOOL SetClientEdge(BOOL	bSet = TRUE);

	// --- In :			bSet - if TRUE,	border with	a raised edge is set, if FALSE,	it cancels.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the border	with a raised edge.
	BOOL SetRaisedEdge(BOOL	bSet = TRUE);

	// --- In :			bSet - if TRUE,	border with	a dotted edge is set, if FALSE,	it cancels.
	// --- Out :
	// --- Returns :	TRUE - if the function succeeds; otherwise FALSE.
	// --- Effect :		Sets the border	with a dotted edge.	This mode cancels other	borders.
	BOOL SetDottedEdge(BOOL	bSet = TRUE);


	// --- In :			nDirection - text scrolling	directions (in degrees).
	//					bPrepareNow	= TRUE if internal image has to	be rebuild.	 If	more than one
	//								  feature of the CFOScrollText control is set, the last
	//								  set has to have this parameter set to	TRUE, to have the image	build
	// --- Out :
	// --- Returns :
	// --- Effect :		Sets the text scrolling	directions (in degrees).
	void SetScrollDirection(int	nDirection,	BOOL bPrepareNow = FALSE);


	// --- In :
	// --- Out :
	// --- Returns :	Text scrolling directions (in degrees).
	// --- Effect :		Retrieves the text scrolling directions	(in	degrees).
	int	GetScrollDirection() const;


	// --- In :			dwScrollSpeed -	text scrolling speed (pixels per second).
	// --- Out :
	// --- Returns :
	// --- Effect :		Sets the text scrolling	speed (pixels per second).
	void SetScrollSpeed(DWORD dwScrollSpeed);

	// --- In :
	// --- Out :
	// --- Returns :	Text scrolling speed (pixels per second).
	// --- Effect :		Retrieves the text scrolling speed (pixels per second).
	DWORD GetScrollSpeed() const;
	void StartScrolling(BOOL bStart	= TRUE);
	BOOL IsScrollingStarted() const;
	void SetMinTimeOut(DWORD dwMinTimeOut);
	DWORD GetMinTimeOut() const;
	void SetGapSize(CSize& szGapSize, BOOL bPrepareNow = FALSE);
	CSize GetGapSize() const;
	BOOL RestoreTextPos(BOOL bPrepareNow = TRUE);
	void SetViewMargins(CRect& rectViewMargins,	BOOL bPrepareNow = FALSE);
	CRect GetViewMargins() const;
	CSize GetTextSize()	const;
	virtual	BOOL PrepareBitmapNew(BOOL	bNow);
protected:
	virtual	BOOL PrepareBitmap(BOOL	bNow);
	
	static UINT	TextScrollingThreadFunction(LPVOID pParam);
	BOOL RefreshBitmap();
	void EmbossText(CDC* pMemDC, RECT BmpRect);
	void TextOutput(CDC* pMemDC, RECT rect);
	void EllipsesReplace(CDC* pMemDC, LPRECT lpRect);
	void SpeedCalc(DWORD dwScrollSpeed,	DWORD* pdwTimeOut, DWORD* pdwAmount);
	void ScrollAmountRecalc();
	BOOL RebuildFont();
	CSize CalcRectSizes( CDC* pDC);

	void GetInitialDisplacement(CRect& textRect);

	//{{AFX_MSG(CFOScrollText)
	afx_msg	BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg	void OnPaint();
	afx_msg	void OnNcPaint();
	afx_msg	void OnDestroy();
	afx_msg	void OnSize(UINT nType,	int	cx,	int	cy);
	afx_msg LRESULT OnDisplayChange(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	afx_msg	LRESULT	OnPrepareBitmap(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

private:

};

inline int CFOScrollText::GetHorzAlignment() const
	{
	return m_nHorzAlignment;
	}

inline int CFOScrollText::GetVertAlignment() const
	{
	return m_nVertAlignment;
	}

inline COLORREF CFOScrollText::GetBkColor() const
	{
	return m_dwBkColor;
	}

inline COLORREF CFOScrollText::GetTextColor() const
	{
	return m_dwTextColor;
	}

inline BOOL CFOScrollText::GetEmboss() const
	{
	return m_bEmbossText;
	}

inline LPCTSTR CFOScrollText::GetText() const
	{
	return (LPCTSTR)m_sText;
	}

inline int CFOScrollText::GetGraphicsMode() const
	{
	return m_nGraphicsMode;
	}

inline int CFOScrollText::GetEllipseMode() const
	{
	return  m_nEllipseMode;
	}

inline DWORD CFOScrollText::Get3Doffset() const
	{
	return m_dwOffset;
	}

inline BOOL CFOScrollText::IsItalic() const
	{
	return m_LogFont.lfItalic;
	}

inline BOOL CFOScrollText::IsUnderlined() const
	{
	return m_LogFont.lfUnderline;
	}

inline BOOL CFOScrollText::IsStrikedOut() const
	{
	return m_LogFont.lfStrikeOut;
	}

inline int CFOScrollText::GetStringAngle() const
	{
	return m_LogFont.lfEscapement;
	}

inline int CFOScrollText::GetCharAngle() const
	{
	return m_LogFont.lfOrientation;
	}

inline int CFOScrollText::GetCharSet() const
	{
	return m_LogFont.lfCharSet;
	}

inline int CFOScrollText::GetFontHeight() const
	{
	return m_LogFont.lfHeight;
	}

inline int CFOScrollText::GetFontWidth() const
	{
	return m_LogFont.lfWidth;
	}

inline CString CFOScrollText::GetFontName() const
	{
	return m_LogFont.lfFaceName;
	}

inline int CFOScrollText::GetScrollDirection() const
	{
	return m_nScrollDirection;
	}

inline DWORD CFOScrollText::GetScrollSpeed() const
	{
	return m_dwScrollSpeed;
	}

inline DWORD CFOScrollText::GetMinTimeOut() const
	{
	return m_dwMinTimeOut;
	}

inline CSize CFOScrollText::GetGapSize() const
	{
	return m_szGapSize;
	}

inline CRect CFOScrollText::GetViewMargins() const
	{
	return m_rectViewMargins;
	}

inline CSize CFOScrollText::GetTextSize() const
	{
	return m_szTextSize;
	}

/////////////////////////////////////////////////////////////////////////////
// CFOMultiColsListBoxTitleBar control -- multiple columns list box window.

 
//===========================================================================
// Summary:
//     The CFOMultiColsListBoxTitleBar class derived from CWnd
//      F O Multiple Cols List Box Title Bar
//===========================================================================

class FO_EXT_CLASS CFOMultiColsListBoxTitleBar : public CWnd
{
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Cols List Box Title Bar, Constructs a CFOMultiColsListBoxTitleBar object.
	//		Returns A  value (Object).
	CFOMultiColsListBoxTitleBar();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Cols List Box Title Bar, Destructor of class CFOMultiColsListBoxTitleBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiColsListBoxTitleBar();

	// Create header.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Header, You construct a CFOMultiColsListBoxTitleBar object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	BOOL CreateHeader(CWnd* pParent);

// Attributes
public:

	// Show all columns
 
	// Show All, This member sets TRUE if it is right.  
	BOOL		m_bShowAll;

	// Current display column.
 
	// Current Show, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurShow;

	// Total columns.
 
	// Total Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTotalCol;

	// Tab stops
 
	// Tab Stops, This member specify LPINT object.  
	LPINT		m_prTabStops;

	// Current font.
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*		m_pFont;

	// Title string.
 
	// Title Bar, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strTitleBar;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiColsListBoxTitleBar)
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOMultiColsListBoxTitleBar)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

class CFOMultiColsComboControl;
/////////////////////////////////////////////////////////////////////////////
// CFOMultiColsComboLBox control -- combo box with multiple columns supported item.

 
//===========================================================================
// Summary:
//     The CFOMultiColsComboLBox class derived from CFOComboListBox
//      F O Multiple Cols Combo L Box
//===========================================================================

class FO_EXT_CLASS CFOMultiColsComboLBox : public CFOComboListBox
{
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Cols Combo L Box, Constructs a CFOMultiColsComboLBox object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pTabbedComboBox---Tabbed Combo Box, A pointer to the CFOMultiColsComboControl or NULL if the call failed.
	CFOMultiColsComboLBox(CFOMultiColsComboControl* pTabbedComboBox);

	// Parent combo box.
 
	// Parent Box, This member maintains a pointer to the object CFOMultiColsComboControl.  
	CFOMultiColsComboControl* m_pParentBox;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiColsComboLBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpMIS---M I S, Specifies a LPMEASUREITEMSTRUCT lpMIS object(Value).
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		lpCIS---C I S, Specifies a LPCOMPAREITEMSTRUCT lpCIS object(Value).
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCIS);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOMultiColsComboLBox)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

 
	// F O Multiple Cols Combo , This member specify friend class object.  
	friend class CFOMultiColsComboControl;
};

/////////////////////////////////////////////////////////////////////////////
// CFOMultiColsComboControl control -- combo box with multiple columns supported
//				item.

 
//===========================================================================
// Summary:
//     The CFOMultiColsComboControl class derived from CFOComboBoxControl
//      F O Multiple Cols Combo 
//===========================================================================

class FO_EXT_CLASS CFOMultiColsComboControl : public CFOComboBoxControl
{
// Construction
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Cols Combo , Constructs a CFOMultiColsComboControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nListBoxID---List Box I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOMultiColsComboControl(CFODrawShape* pShape,UINT nListBoxID = 0);

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor & Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Cols Combo , Destructor of class CFOMultiColsComboControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiColsComboControl();

// Attributes
public:

	// Value col
 
	// Value Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nValueCol;     
	
	// Current show col.
 
	// Current Show, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurShow;

	// Show all or not.
 
	// Show All, This member sets TRUE if it is right.  
	BOOL		m_bShowAll;
	
	// Is title bar show
 
	// Show Title Bar, This member sets TRUE if it is right.  
	BOOL		m_bShowTitleBar;

	// Sort col
 
	// Sort Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSortCol;

	// Column text
 
	// Column, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strColumn;

	// Column line
 
	// Column Line, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crColLine;

	// Back color.
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBackColor;

	// Text color
 
	// Text Color, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crTextColor;

	// Default col height.
 
	// Default Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nDefaultHeight;

	// Current list select id.
 
	// Current List Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nCurListId;

	// Serial
 
	// Serial, Specify a A 32-bit signed integer.  
	LONG		m_nSerial;

	// Choice array.
 
	// Choice, This member specify CPtrArray object.  
	CPtrArray	m_arChoice;

	// Text array.
 
	// Text, This member specify CPtrArray object.  
	CPtrArray	m_arText;

	// Choice
 
	// List Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nListId;

public:
	
	// Change display col value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Show Column, Sets a specify value to current class CFOMultiColsComboControl
	// Parameters:
	//		&nCol---&nCol, Specifies A integer value.
	void SetShowCol(const int &nCol)		{ m_nCurShow = nCol; }

// Operations
public:

	// Set tab stops
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Tab Stops, Sets a specify value to current class CFOMultiColsComboControl
	// Parameters:
	//		nTabStops---Tab Stops, Specifies A integer value.
	void SetTabStops(int nTabStops);

	// Add new stop
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Tab Stop, Adds an object to the specify list.
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nTabStop---Tab Stop, Specifies A integer value.
	void AddTabStop(int nIndex, int nTabStop);
	
	//  Do fill list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill List Box, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoFillListBox();

	// Get value choice.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Items Value, Returns the specified value.
	//		Returns a pointer to the object CMapStringToString,or NULL if the call failed
	CMapStringToString* GetItemsValue();

	// Get text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Items Text, Returns the specified value.
	//		Returns a pointer to the object CMapStringToString,or NULL if the call failed
	CMapStringToString* GetItemsText();

	// Reset choice
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Items, Remove the specify data from the list.
	// Parameters:
	//		nItem---nItem, Specifies A integer value.
	void ClearItems(int nItem = -1);

	// Set value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Select Value, Sets a specify value to current class CFOMultiColsComboControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pszRawValue---Raw Value, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void SetSelectValue(LPCTSTR pszRawValue);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual BOOL GetSelectValue(CString& strResult);

	// Create drop down control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Down, You construct a CFOMultiColsComboControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOCtrlCombo,or NULL if the call failed  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual CFOCtrlCombo* CreateDropDown(CWnd* pWnd, const FOPRect& rect);

	// Create list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create List Box, You construct a CFOMultiColsComboControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed  
	// Parameters:
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CWnd* CreateListBox(CWnd* pParentWnd, UINT nID);

	// Get rectangle of list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Compute List Box Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).  
	// Parameters:
	//		rcCellRect---Cell Rectangle, Specifies a const FOPRect& rcCellRect object(Value).
	virtual FOPRect DoComputeListBoxPosition(const FOPRect& rcCellRect);

	// Store drop list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Message, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CListBox or NULL if the call failed.
	virtual void DoSaveMsg(CListBox* lbox);

	// Fill list box
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Fill List Box, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lbox---A pointer to the CListBox or NULL if the call failed.
	virtual void DoFillListBox(CListBox* lbox);

	// Destroy drop down wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy List Box, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDropDownWnd---Drop Down Window, A pointer to the CWnd or NULL if the call failed.
	virtual void DestroyListBox(CWnd* pDropDownWnd);

	// Show drop down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Drop Down, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bShow---bShow, Specifies A Boolean value.
	virtual void ShowDropDown(BOOL bShow);

	// Do key pressed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt, UINT flags);

	// Update string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update String, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sEdit---sEdit, Specifies A CString type value.
	virtual BOOL UpdateControlText(const CString& sEdit);

	// Generated message map functions
protected:

	//{{AFX_MSG(CFOMultiColsComboControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Width of list box.
 
	// Width L Box, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWidthLBox;

	// Total colmuns.
 
	// Total Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalCol;

	// Tab stops.
 
	// Tab Stops, This member specify LPINT object.  
	LPINT			m_prTabStops;

	// Title bar.
 
	// Window Title Bar, This member maintains a pointer to the object CFOMultiColsListBoxTitleBar.  
	CFOMultiColsListBoxTitleBar* m_pWndTitleBar;

	// Is current list have data.
 
	// Data Validate, This member sets TRUE if it is right.  
	BOOL			m_bCheckRight;

	// List box
 
	// Drop List Box, This member maintains a pointer to the object CFOMultiColsComboLBox.  
	CFOMultiColsComboLBox* m_pDropListBox;

	// Popup list box control
 
	// Drop List Box Popup, This member maintains a pointer to the object CFOCtrlCombo.  
	CFOCtrlCombo*	m_pDropListBoxPopup;

	// Recorder number
 
	// Recorder Number, Specify a A 32-bit signed integer.  
	LONG			m_nRecorderNumber;

 
	// F O Multiple Cols Combo L Box, This member specify friend class object.  
	friend class CFOMultiColsComboLBox;
};

/////////////////////////////////////////////////////////////////////////////
// CFORichEditControl control -- rich text editing control.

 
//===========================================================================
// Summary:
//     The CFORichEditControl class derived from CRichEditCtrl
//      F O Rich Edit 
//===========================================================================

class FO_EXT_CLASS CFORichEditControl: public CRichEditCtrl, public CFOControlBase
{
// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFORichEditControl---F O Rich Edit , Specifies a E-XD++ CFORichEditControl object (Value).
	DECLARE_DYNAMIC(CFORichEditControl)
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Rich Edit , Constructs a CFORichEditControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFORichEditControl(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Rich Edit , Destructor of class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFORichEditControl();

	// Attributes
public:
	// Active or not
 
	// Is Active, This member sets TRUE if it is right.  
	BOOL            m_bIsActive;

	// Is modified or not
 
	// Modified, This member sets TRUE if it is right.  
	BOOL            m_bModified;

	// my Mask, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD           m_dwMyMask;

	// Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD           m_dwExStyleNew;

	// SouSuo mode
 
	// SouSuo Mode, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nSouSuoMode;

	// SouSuo size
 
	// Minimize SouSuo Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int             m_nMinSouSuoSize;

public:

	// Obtain the pointer of the window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Create control
	// pParent -- pointer of the parent window.
	// nID -- id value.
	// dwStyle -- style of the window
	// lpRect -- rectangle for showing the window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFORichEditControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent, int nID, DWORD dwStyle, LPRECT lpRect = NULL);

	// Change the event mask.
	// dwEventmask -- event mask
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Event Mask, Sets a specify value to current class CFORichEditControl
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		dwEvent---Event Mask, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	DWORD SetEventMask(DWORD dwEvent);

	// Status (need to be overriden)
	// bValid -- validate or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bValid---bValid, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bValid);

	// Is validate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify
	// bModified -- modified or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();   // default: FALSE

	// Obtain the selected text
	// m_strNoRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_strNoRTF---No R T F, Specifies A CString type value.
	virtual BOOL GetSelectedText(CString& m_strNoRTF);
	
	// Obtain the current control text
	// m_strRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_strRTF---R T F, Specifies A CString type value.
	virtual void GetCurrentText(CString& m_strRTF);

	// Obtain the current control no RTF text
	// m_strNoRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Un Format Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_strNoRTF---No R T F, Specifies A CString type value.
	virtual void GetUnFormatText(CString& m_strNoRTF);

	// Change control text,RTF
	// m_strRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_strRTF---R T F, Specifies A CString type value.
	virtual void SetCurrentText(const CString& m_strRTF);

	// Change control text,no RTF
	// m_strNoRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set No Format Text, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_strNoRTF---No R T F, Specifies A CString type value.
	virtual void SetNoFormatText(const CString& m_strNoRTF);

	// Change value
	// m_strRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Value, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_strRTF---R T F, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void SetValue(LPCTSTR m_strRTF);

	// Do temp method.
	void DoTempM1(UINT nChar, BOOL &bDefault);

	// Obtain the value
	// m_strRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_strRTF---R T F, Specifies A CString type value.
	virtual BOOL GetValue(CString& m_strRTF);

	// Obtain the control text
	// strResultNoRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strResultNoRTF---Result No R T F, Specifies A CString type value.  
	//		pszRawValue---Raw Value, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL GetControlText(CString& strResultNoRTF,LPCTSTR pszRawValue);

	// Change control text
	// m_strNoRTF -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set  Text, Sets a specify value to current class CFORichEditControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_strNoRTF---No R T F, Specifies A CString type value.
	virtual BOOL SetControlText(const CString& m_strNoRTF);

	// Convert text to value
	// str -- result text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL ConvertToValue(CString& str);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Store, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Store
	virtual BOOL Store();

	// Obtain the control rect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOPRect value (Object).
	virtual FOPRect GetFullControlPosition();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	// Init
	virtual void Init();

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Mouse events
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Mouse events
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint pt);

	// Control notifications
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Notify Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL DoNotifyMsg(WPARAM wParam, LPARAM lParam);

	// Keyboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Keyboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Simple Char, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnSimpleChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// Keyboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Wide Char, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sChar---sChar, Specifies A CString type value.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL OnWideChar(const CString& sChar, UINT nRepCnt, UINT nFlags);

	// Update text string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Text String, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		m_strNoRTF---No R T F, Specifies A CString type value.
	virtual BOOL UpdateTextString(const CString& m_strNoRTF);

	// Clipboard
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Copy text to clipboard.
	virtual BOOL Copy();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Paste, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Paste text from clipboard.
	virtual BOOL Paste();

	// Copy text to clipboard and delete the text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cut, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Cut();

	// Can copy text to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Copy, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCopy();

	// Can cut text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Cut, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanCut();

	// Can paste text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Can Paste, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCanPaste();

	// Find and Replace
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Select, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		szNoRTF---No R T F, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void ReplaceSel(LPCTSTR szNoRTF);

	// Rich control text
	// pWnd -- pointer of the wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Asign Rich  Text, .
	// This member function is a static function.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CRichEditCtrl or NULL if the call failed.  
	//		szRTF---R T F, Specifies a LPCSTR szRTF object(Value).
	static void AFXAPI AsignRichControlText(CRichEditCtrl* pWnd, LPCSTR szRTF);

#ifdef _UNICODE
	// Rich control text
	// pWnd -- pointer of the wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Asign Rich  Text, .
	// This member function is a static function.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CRichEditCtrl or NULL if the call failed.  
	//		szRTF---R T F, Specifies a LPCWSTR szRTF object(Value).
	static void AFXAPI AsignRichControlText(CRichEditCtrl* pWnd, LPCWSTR szRTF);
#endif

	// Rich control text
	// pWnd -- pointer of the wnd
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rich  Text, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CRichEditCtrl or NULL if the call failed.  
	//		m_strRTF---R T F, Specifies A CString type value.
	static CString AFXAPI GetRichControlText(CRichEditCtrl* pWnd, CString& m_strRTF);

	// Convert to RTF
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format To R T F, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a PARAFORMAT& pf object(Value).  
	//		cf---Specifies a CHARFORMAT& cf object(Value).
	virtual void FormatToRTF(PARAFORMAT& pf, CHARFORMAT& cf);

	// Convert from RTF
	
	//-----------------------------------------------------------------------
	// Summary:
	// T F To Format, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a const PARAFORMAT& pf object(Value).  
	//		cf---Specifies a const CHARFORMAT& cf object(Value).
	virtual void RTFToFormat(const PARAFORMAT& pf, const CHARFORMAT& cf);

#if defined(_UNICODE) && (_MFC_VER >= 0x0420 && _MFC_VER < 0x0700)
  #if !defined(_RICHEDIT_VER)
	// Convert format to RTF
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format To R T F, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a PARAFORMAT& pf object(Value).  
	//		cf---Specifies a CHARFORMATA& cf object(Value).
	virtual void FormatToRTF(PARAFORMAT& pf, CHARFORMATA& cf);

	// Convert RTF to format
	
	//-----------------------------------------------------------------------
	// Summary:
	// T F To Format, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a const PARAFORMAT& pf object(Value).  
	//		cf---Specifies a const CHARFORMATA& cf object(Value).
	virtual void RTFToFormat(const PARAFORMAT& pf, const CHARFORMATA& cf);
  #else
	// Convert format to RTF
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format To R T F, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a PARAFORMAT& pf object(Value).  
	//		cf---Specifies a CHARFORMATW& cf object(Value).
	virtual void FormatToRTF(PARAFORMAT& pf, CHARFORMATW& cf);

	// Convert RTF to format
	
	//-----------------------------------------------------------------------
	// Summary:
	// T F To Format, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pf---Specifies a const PARAFORMAT& pf object(Value).  
	//		cf---Specifies a const CHARFORMATW& cf object(Value).
	virtual void RTFToFormat(const PARAFORMAT& pf, const CHARFORMATW& cf);
  #endif
#endif

	// Hides the CWnd and Redraws the control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Refresh, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Refresh();

public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFORichEditControl)
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CFORichEditCtrl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Dead Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysDeadChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Request Resize, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pNotifyStruct---Notify Struct, A pointer to the NMHDR or NULL if the call failed.  
	//		result---A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL OnRequestResize(NMHDR* pNotifyStruct, LRESULT* result);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Dead Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnDeadChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resize, Do a event. 
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		id---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pNotifyStruct---Notify Struct, A pointer to the NMHDR or NULL if the call failed.  
	//		result---A pointer to the LRESULT or NULL if the call failed.
	afx_msg BOOL DoResize(UINT id, NMHDR* pNotifyStruct, LRESULT* result);
#if _MFC_VER >= 0x0400
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ime Start Event, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnImeStartEvent(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ime End Event, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnImeEndEvent(WPARAM wParam, LPARAM lParam);
#endif
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:
	// Calc size
 
	// Enable Calculate, This member sets TRUE if it is right.  
	BOOL			m_bEnableCalc;

	// CRichEditCtrl for Store.
 
	// Store R T F, This member specify CRichEditCtrl object.  
	CRichEditCtrl   m_wndStoreRTF;

	// Store RTF text
 
	// Last Store, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strLastStore;

};

#define ID_FOPS_CALENDAR					3

/////////////////////////////////////////////////////////////////////////////
// CFOPDateTimeEditCtrlMonthCalCtrl window -- date time edit control.

 
//===========================================================================
// Summary:
//     The CFOPDateTimeEditCtrlMonthCalCtrl class derived from CMonthCalCtrl
//      F O P Date Time Edit  Month Cal 
//===========================================================================

class FO_EXT_CLASS CFOPDateTimeEditCtrlMonthCalCtrl : public CMonthCalCtrl
{
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Date Time Edit  Month Cal , Constructs a CFOPDateTimeEditCtrlMonthCalCtrl object.
	//		Returns A  value (Object).
	CFOPDateTimeEditCtrlMonthCalCtrl();
	
	// Attributes
public:
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPDateTimeEditCtrlMonthCalCtrl)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Date Time Edit  Month Cal , Destructor of class CFOPDateTimeEditCtrlMonthCalCtrl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDateTimeEditCtrlMonthCalCtrl();
	
	// Generated message map functions
protected:
	
	// Ingore message.
 
	// Ignore Next Message, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD m_nIgnoreNextMessage;
	
	//{{AFX_MSG(CFOPDateTimeEditCtrlMonthCalCtrl)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDateTimeEditCtrlCalendarWnd window -- date time edit control

 
//===========================================================================
// Summary:
//     The CFOPDateTimeEditCtrlCalendarWnd class derived from CWnd
//      F O P Date Time Edit  Calendar Window
//===========================================================================

class FO_EXT_CLASS CFOPDateTimeEditCtrlCalendarWnd : public CWnd
{
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Date Time Edit  Calendar Window, Constructs a CFOPDateTimeEditCtrlCalendarWnd object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pComboParent---Combo Parent, A pointer to the CWnd or NULL if the call failed.  
	//		dwMCStyle---M C Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	CFOPDateTimeEditCtrlCalendarWnd(CWnd* pComboParent, DWORD dwMCStyle = 0);
	
	// Attributes
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Month Cal , Returns the specified value.
	//		Returns a pointer to the object CFOPDateTimeEditCtrlMonthCalCtrl,or NULL if the call failed
	CFOPDateTimeEditCtrlMonthCalCtrl* GetMonthCalCtrl() { return m_pCalendar; }
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPDateTimeEditCtrlCalendarWnd)
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDateTimeEditCtrlCalendarWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DestroyWindow();
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Date Time Edit  Calendar Window, Destructor of class CFOPDateTimeEditCtrlCalendarWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDateTimeEditCtrlCalendarWnd();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPDateTimeEditCtrlCalendarWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
#if _MSC_VER >= 1300
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		dwThreadID---Thread I D, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
#else
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate Application, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		hTask---hTask, Specifies a HTASK hTask object(Value).
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
#endif
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
		
private:
	
	// Pointer of the calendar.
 
	// Calendar, This member maintains a pointer to the object CFOPDateTimeEditCtrlMonthCalCtrl.  
	CFOPDateTimeEditCtrlMonthCalCtrl* m_pCalendar;
	
	// Parent wnd.
 
	// Combo Parent, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*			m_pComboParent;
	
	// Style of the calendar.
 
	// M C Style, This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	DWORD			m_dwMCStyle;
};

/////////////////////////////////////////////////////////////////////////////
// CFOAnimateTextControl control -- list box control.

 
//===========================================================================
// Summary:
//     The CFOAnimateTextControl class derived from CFOScrollText
//      F O List Box 
//===========================================================================

class FO_EXT_CLASS CFOAnimateTextControl: public CFOScrollText, public CFOControlBase
{
// Construction
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O List Box , Constructs a CFOAnimateTextControl object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	CFOAnimateTextControl(CFODrawShape* pShape);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O List Box , Destructor of class CFOAnimateTextControl
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAnimateTextControl();

public:
	// Wnd ptr.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Window Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd,or NULL if the call failed
	virtual CWnd* GetWndPtr() const;

	// Create control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create , You construct a CFOAnimateTextControl object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pParent---*pParent, A pointer to the CWnd  or NULL if the call failed.  
	//		nID---I D, Specifies A integer value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect = NULL object(Value).
	virtual BOOL CreateControl(CWnd *pParent,int nID,LPRECT lpRect = NULL);

	// Set activate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Validate, Sets a specify value to current class CFOAnimateTextControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	virtual void SetControlActive(BOOL bActive);

	// Is active
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsControlActive();

	// Set modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify, Sets a specify value to current class CFOAnimateTextControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void SetModify(BOOL bModified);

	// Get modify flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetModify();

	// Get Current text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Text, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResult---strResult, Specifies A CString type value.
	virtual void GetCurrentText(CString& strResult);

	// Set current text
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Text, Sets a specify value to current class CFOAnimateTextControl
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual void SetCurrentText(const CString& str);

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial, Call Init after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void Init();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	// Hide
	virtual void Hide();

	// Do left button up action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.  
	//		nHitState---Hit State, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUp(UINT nFlags, CPoint pt, UINT nHitState);

	// Do left button double click action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pt---Specifies A CPoint type value.
	virtual BOOL DoLButtonDblClk(UINT nFlags, CPoint pt);

	// Do key pressed action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Key Pressed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoKeyPressed(UINT nMessage, UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Notifications
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	// Listbox control only
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill List Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strChoice---&strChoice, Specifies A CString type value.
	virtual void FillListBox(const CString &strChoice);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOAnimateTextControl)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

// Attributes
protected:

	// Active or not
 
	// Validate, This member sets TRUE if it is right.  
	BOOL            m_bValidate;

	// Modify flag
 
	// Is Modify, This member sets TRUE if it is right.  
	BOOL            m_bIsModify;

	// Text color
 
	// Hilight Text, This member sets A 32-bit value used as a color value.  
	COLORREF        m_crHilightText;

	// Height
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_dyHeight;

	// Select text
 
	// Select Text, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strSelectText;

};



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTEXTEDIT_H__E735B983_FC1C_11D5_A4E1_525400EA266C__INCLUDED_)
