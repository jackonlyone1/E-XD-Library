//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBaseAction.h: interface for the CFOBaseAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBASEACTION_H__2EEABBED_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOBASEACTION_H__2EEABBED_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Macro.
#include "FOCmdIterator.h"

// Delare action.
#define DECLARE_ACTION(class_name)\
	DECLARE_DYNAMIC(class_name)\
	private: static const unsigned int m_nID;\
	public: virtual unsigned int GetID() const { return m_nID; } 

// Implement action.
#define IMPLEMENT_ACTION(class_name, base_class_name, cmdID)\
	IMPLEMENT_DYNAMIC(class_name, base_class_name)\
const unsigned int class_name::m_nID = cmdID; 

// Declear action
#define DECLARE_ACTION_NOID(class_name)\
	DECLARE_DYNAMIC(class_name)
#define IMPLEMENT_ACTION_NOID(class_name, base_class_name)\
	IMPLEMENT_DYNAMIC(class_name, base_class_name)

// Declear macro action.
#define PEX_DECLARE_ACTION_MACRO(class_name)\
	DECLARE_DYNCREATE(class_name)

// Declear macro action.
#define PEX_IMPLEMENT_ACTION_MACRO(class_name, base_class_name)\
	IMPLEMENT_DYNCREATE(class_name, base_class_name)

////////////////////////////////////////////////////////////////////////
// CFOBaseAction
//
// This is the base class of the action,the following methods must be overrided,
// GetID(),GetUndoAction(),GetRedoAction(),Sprint(..),etc.
// Each type of the action must have an unique ID.
//

 
//===========================================================================
// Summary:
//     The CFOBaseAction class derived from CObject
//      F O Base Action
//===========================================================================

class FO_EXT_CLASS CFOBaseAction : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseAction---F O Base Action, Specifies a E-XD++ CFOBaseAction object (Value).
	// DECLARE_DYNAMIC
	DECLARE_DYNAMIC(CFOBaseAction)
public: 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Action, Constructs a CFOBaseAction object.
	//		Returns A  value (Object).
	CFOBaseAction();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Action, Destructor of class CFOBaseAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBaseAction();

	//-----------------------------------------------------------------------
	// Summary:
	// Get ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual unsigned int GetID() const = 0;
	
	// Operations
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual CFOBaseAction* GetUndoAction() const = 0;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed  
	// Parameters:
	//		const---Specifies a ) const = 0 object(Value).
	virtual CFOBaseAction* GetRedoAction() const = 0;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		const---Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const = 0;

	// Get undo state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo State, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetUndoState() const;

	// Obtain maximize position, override this method to handle your update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get save update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Update Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetSaveUpdateRect() const { return m_rcSaveUpdate; }
	
	// Set save update position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Update Rectangle, Sets a specify value to current class CFOBaseAction
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SetSaveUpdateRect(const CRect &rc);

// Attributes
protected:
	// Save update position.
 
	// Save Update, This member sets a CRect value.  
	CRect			m_rcSaveUpdate;

	// Undo state.
 
	// State, This member sets TRUE if it is right.  
	BOOL m_bState;

};

//Return action ID
_FOLIB_INLINE const unsigned int ACTION_ID(CFOBaseAction* pAction)
{ 
	return pAction->GetID(); 
}

// define type CList
typedef CList<CFOBaseAction*, CFOBaseAction*> CActionList;

// Actions iterator.
typedef FOCmdIterator<CFOBaseAction*, CFOBaseAction*> CFOActionIterator;

#endif // !defined(AFX_FOBASEACTION_H__2EEABBED_F19E_11DD_A432_525400EA266C__INCLUDED_)
