//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOShapeActorManager.h: interface for the CFOShapeActorManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSHAPEACTORMANAGER_H__A431E054_67A3_11DF_A46B_525400EA266C__INCLUDED_)
#define AFX_FOSHAPEACTORMANAGER_H__A431E054_67A3_11DF_A46B_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOShapeActor.h"
#include "FORectShape.h"

// Bend mode
enum FOPBendMode 
{
	FOP_BEND_ROTATE, // With rotating action when bending.
	FOP_BEND_SLANT,  // With slanting action when bending
	FOP_BEND_STRETCH // With stretch action when bending.
};

const COLORREF  fo_XtDefaultTrackLineColor		= RGB(1,127,255);
const int		fo_XtDefaultTrackLinePenStyle   = PS_DOT;
const COLORREF  fo_XtDefaultTrackFillColor		= RGB(240,242,255);
const int		fo_XtDefaultMaxShapes			= 10;

/////////////////////////////////////////////////////////////////////////////////
//
// CFOShapeActorManager
//
// This class is defined for tracking the selection shapes on the canvas,when we
// Moving,Resizing,Rotating... shapes on the canvas,it will call the method of this 
// class.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOShapeActorManager class derived from CObject
//      F O Shape Actor Manager
//===========================================================================

class FO_EXT_CLASS CFOShapeActorManager : public CObject
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOShapeActorManager---F O Shape Actor Manager, Specifies a E-XD++ CFOShapeActorManager object (Value).
	DECLARE_SERIAL(CFOShapeActorManager)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Shape Actor Manager, Constructs a CFOShapeActorManager object.
	//		Returns A  value (Object).
	CFOShapeActorManager();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Shape Actor Manager, Destructor of class CFOShapeActorManager
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOShapeActorManager();

public:
	// Add shapes to the list.
	// m_list -- list of shapes that to be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shapes, Sets a specify value to current class CFOShapeActorManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		m_list---A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nShapeAll---Shape All, Specifies A integer value.
	virtual void	SetShapes(CFODrawShapeList* m_list, int nShapeAll);
	
	// Update all the shapes,it will make the track points to be the 
	// same with the drawing points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shapes, Call this member function to update the object.

	void			UpdateShapes() const;

	// Reset all the tracking points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Track Points, Called this function to empty a previously initialized CFOShapeActorManager object.

	void			ResetTrackPoints();

	// Get the anchor point of the tracker,this main point will be used as the snap point when moving
	// or resizing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint	GetMainPoint() const;
	
	// Remove all shapes from this tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	RemoveAll();

	// Get the max bounding rectangle of all the shapes within the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect			GetTotalRect() { return m_rcFullDraw; }

	// Is all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Ports, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			IsAllPorts();

	// Get max rectangle,it will returns the tracking points max bounding position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect			GetMaxRect() const;

public:
	// Move shapes,when moving shapes on the canvas,it will call this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Move Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_MoveShapes(CDC* pDC, int nOffsetX, int nOffsetY,const CPoint &ptScroll);

	// Move shapes,when moving shapes on the canvas,it will call this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Drop Move Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_DropMoveShapes(CDC* pDC, int nOffsetX, int nOffsetY,const CPoint &ptScroll);

	// Size the shapes,when resizing shapes on the canvas,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Size Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dStartX---Start X, Specifies a double dStartX object(Value).  
	//		dStartY---Start Y, Specifies a double dStartY object(Value).  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		bConsider---bConsider, Specifies A Boolean value.  
	//		dNewX---New X, Specifies a double dNewX object(Value).  
	//		dNewY---New Y, Specifies a double dNewY object(Value).
	virtual void When_SizeShape(CDC* pDC,double dStartX,double dStartY,const CPoint &ptScroll,
		double dX, double dY,BOOL bConsider,double dNewX,double dNewY);

	// Mirror the shapes,when mirror shapes on the canvas.this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Mirror Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	virtual void When_MirrorShape(CDC* pDC,const CPoint &ptRef1,const CPoint &ptRef2);

	// Rotate the shapes,when rotating shapes on the canvas,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dOriginX---Origin X, Specifies a double dOriginX object(Value).  
	//		dOriginY---Origin Y, Specifies a double dOriginY object(Value).  
	//		nAngle---nAngle, Specifies A integer value.  
	//		&bOldMode---Old Mode, Specifies A Boolean value.
	virtual void When_RotateShape(CDC* pDC,double dOriginX, double dOriginY, int nAngle,
		const BOOL &bOldMode = FALSE);

	// Shear the shapes,when shear shapes on the canvas,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Shear Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptCenter---&ptCenter, Specifies A CPoint type value.  
	//		&aBend---&aBend, Specifies a const FOPSimpleCompositePolygon &aBend object(Value).  
	//		&aDistort---&aDistort, Specifies a const FOPSimplePolygon &aDistort object(Value).  
	//		bResize---bResize, Specifies A Boolean value.  
	//		aFact---aFact, Specifies a FOPFraction aFact object(Value).  
	//		nAngle---nAngle, Specifies A integer value.  
	//		&bHorzX---Horizontal X, Specifies A Boolean value.
	virtual void When_ShearShape(CDC* pDC, const CPoint &ptCenter,const FOPSimpleCompositePolygon &aBend,const FOPSimplePolygon &aDistort,
		BOOL bResize,FOPFraction aFact,int nAngle,const BOOL &bHorzX = TRUE);

	// Distort the shapes,when distort shapes on the canvas,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Distort Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&aBend---&aBend, Specifies a const FOPSimpleCompositePolygon &aBend object(Value).  
	//		&aDistort---&aDistort, Specifies a const FOPSimplePolygon &aDistort object(Value).  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void When_DistortShape(CDC* pDC, const FOPSimpleCompositePolygon &aBend,
		const FOPSimplePolygon &aDistort,const CRect &rcPos);


	// Bend the shapes,when Bend shapes on the canvas,this method will be called.
	// enum FOPBendMode 
	// {
	// 	FOP_BEND_ROTATE, // With rotating action when bending.
	// 	FOP_BEND_SLANT,  // With slanting action when bending
	// 	FOP_BEND_STRETCH // With stretch action when bending.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Bend Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		eMode---eMode, Specifies a FOPBendMode eMode object(Value).  
	//		&aCenter---&aCenter, Specifies A integer value.  
	//		bVertical---bVertical, Specifies A Boolean value.  
	//		bResize---bResize, Specifies A Boolean value.  
	//		aFact---aFact, Specifies a FOPFraction aFact object(Value).  
	//		&aRad---&aRad, Specifies A integer value.  
	//		&aBend---&aBend, Specifies a const FOPSimpleCompositePolygon &aBend object(Value).  
	//		&aDistort---&aDistort, Specifies a const FOPSimplePolygon &aDistort object(Value).  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void When_BendShape(CDC* pDC,FOPBendMode eMode,
										   const FOPPoint &aCenter,
										   BOOL bVertical,
										   BOOL bResize,
										   FOPFraction aFact,
										   const FOPPoint &aRad,
										   const FOPSimpleCompositePolygon &aBend,
										   const FOPSimplePolygon &aDistort,
										   const CRect &rcPos);

	// Size the shapes,when resizing shapes on the canvas,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Size Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		dStartX---Start X, Specifies a double dStartX object(Value).  
	//		dStartY---Start Y, Specifies a double dStartY object(Value).  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		bConsider---bConsider, Specifies A Boolean value.  
	//		dNewX---New X, Specifies a double dNewX object(Value).  
	//		dNewY---New Y, Specifies a double dNewY object(Value).
	virtual void When_SizeForm(CDC* pDC,double dStartX,double dStartY,const CPoint &ptScroll,
		double dX, double dY,BOOL bConsider,double dNewX,double dNewY);

	// Track The Point,when tracking one point,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackPoint(CDC* pDC, const CPoint &ptStart, int nIndex, const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The Point,when tracking one point,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackPath(CDC* pDC, CFOPMarkList &maMark, const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The first Point,when tracking the first anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The second anchor Point,when tracking the second anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Extend Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackExtAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The third anchor Point,when tracking the third anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Third Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackThirdAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The four anchor Point,when tracking the four anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Four Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackFourAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The five anchor Point,when tracking the five anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Five Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackFiveAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The Text anchor Point,when tracking the five anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Text Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackTextAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The user anchor Point,when tracking the five anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track User Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackUserAnchorPoint(CDC* pDC, const int &nPtIndex, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The center anchor Point,when tracking the five anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Center Anchor Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackCenterAnchorPoint(CDC* pDC, const CPoint &ptStart,const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The Point,when tracking the link point of the link shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Link Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackLinkPoint(CDC* pDC, const CPoint &ptStart, int nIndex, const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The Point,when tracking the link point of the link shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Link Center Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void When_TrackLinkCenterPoint(CDC* pDC, const CPoint &ptStart, int nIndex, const CPoint &ptOffset,
		const CPoint &ptScroll);

	// Track The visio style handle Point,when tracking the five anchor point of the shape,this method will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When_ Track Microsoft Visio style Handle Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void When_TrackVisioHandlePoint(CDC* pDC, const CPoint &ptOffset, int handle);

	// Do drawing rotate center change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rotate Center Track, Draws current object to the specify device.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	void DrawRotateCenterTrack(CDC *pDC, const CPoint &ptOffset);

public:

	//Define for track line pen.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Track Pen2, You construct a CFOShapeActorManager object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreateTrackPen2(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Pen2, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetTrackPen2(CDC* pDC = NULL);

	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Track Pen Object2, .

	void ReleaseTrackPenObject2();

	// Draw track line.
	// Prepare the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Track D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareTrackDC(CDC* pDC);

	// Clear the track dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Track D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearTrackDC(CDC* pDC);


public:

	// Draw point rubber line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Point Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void OnDrawPointRubberLine(CDC* pDC,const CPoint &ptStart,const CPoint &ptScroll);

	// Draw point rubber line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Microsoft Visio style Point Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void OnDrawVisioPointRubberLine(CDC* pDC,const CPoint &ptStart,const CPoint &ptScroll);

	// Draw Line Scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Scale Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void OnDrawScaleRubberLine(CDC* pDC,const CPoint &ptStart,const CPoint &ptScroll);

	// Draw Link Line Scale
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Link Scale Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptScroll---&ptScroll, Specifies A CPoint type value.
	virtual void OnDrawLinkScaleRubberLine(CDC* pDC,const CPoint &ptStart,const CPoint &ptScroll);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawRubberLine(CDC* pDC);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Moving Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawMovingRubberLine(CDC* pDC);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Drop Moving Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawDropMovingRubberLine(CDC* pDC);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Sizing Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawSizingRubberLine(CDC* pDC);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Mirror Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawMirrorRubberLine(CDC* pDC);

	// Draw track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Rotate Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawRotateRubberLine(CDC* pDC);

	// Draw shear track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shear Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawShearRubberLine(CDC* pDC);

	// Draw Distort track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Distort Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearDistortRubberLine(CDC* pDC);

	// Draw Bend track line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Bend Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearBendRubberLine(CDC* pDC);

	// Draw form track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Form Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawFormRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Microsoft Visio style Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearVisioRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Move Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearMoveRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Drop Move Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearDropMoveRubberLine(CDC* pDC);


	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Size Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearSizeRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Mirror Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearMirrorRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Rotate Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearRotateRubberLine(CDC* pDC);

	// Erase the track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Rotate Center Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearRotateCenterRubberLine(CDC* pDC);

	// Erase the shear track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Shear Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearShearRubberLine(CDC* pDC);

	// Erase the form track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Clear Form Rubber Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawClearFormRubberLine(CDC* pDC);

public:

	// Set wide shapes,adding shapes to the manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Back Up Shapes, Sets a specify value to current class CFOShapeActorManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapesList---Shapes List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void SetBackUpShapes(CFODrawShapeList* pShapesList);	
	
	// Get the point of the rectangle with the control handle:
	// rcPos -- rectangle object.
	// nControl -- it must be one of the following value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Port, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		&nControl---&nControl, Specifies a const FO_CONTROL_HANDLE &nControl object(Value).
	static CPoint GetControlPort(const CRect& rcPos, const FO_CONTROL_HANDLE &nControl);

	// Union the two rect to a single rectangle.
	// rect1 -- the first rectangle to be unioned.
	// rect2 -- the second rectangle to be unioned.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Union Rectangle, .
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		rect1---Specifies A CRect type value.  
	//		rect2---Specifies A CRect type value.
	static CRect UnionRect(CRect rect1, CRect rect2);

	// Standard position,Normalize the rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Standard Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rect---Specifies A CRect type value.
	static void StandardRect(CRect& rect);

	// Change the Distort rectangle.
	// aRect -- distort polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Distort Polygon, .
	// Parameters:
	//		&aRect---&aRect, Specifies a const FOPSimplePolygon &aRect object(Value).
	void		ChangeDistortPoly(const FOPSimplePolygon &aRect) { m_aDistortedRect = aRect; }

	// Split drag polygon.
	// aPoly -- polygon object
	// rcRect -- split rectangle.
	// nHorDiv -- horz div number.
	// nVerDiv -- vertical div number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Split Drag Polygon, .
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		nHorDiv---Hor Div, Specifies A integer value.  
	//		nVerDiv---Ver Div, Specifies A integer value.
	void		FOPSplitDragPoly(FOPSimpleCompositePolygon& aPoly, const FOPRect& rcRect, int nHorDiv, int nVerDiv);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Tracker
 
	// Actor, This member maintains a pointer to the object CFOShapeActor.  
	CFOShapeActor*		m_pActor;

	// Witch complex shape.
 
	// With Complex, This member sets TRUE if it is right.  
	BOOL				m_bWithComplex;

	// Track Wide Size
 
	// Track Dup Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					nTrackDupSize;

	// Tracking Size
 
	// All Track Shapes, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nAllTrackShapes;

	// Total tracking shape size.
 
	// Total Shapes, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTotalShapes;

	// Wide Tracker
 
	// Dup Actor, This member maintains a pointer to the object CFOShapeActor.  
	CFOShapeActor*		m_pDupActor;

	// Bounding rectangle of all the shapes.
 
	// Need Total, This member sets a CRect value.  
	CRect				m_rcNeedTotal;

	// Simple drawing rectangle.
	FOPRect				m_rcFullDraw;

	// Control handle State
 
	// Point State, This member specify FO_CONTROL_HANDLE object.  
	FO_CONTROL_HANDLE	m_PtState;

	//List of Update
 
	// Update, This member specify E-XD++ CFOShapeActorSet object.  
	CFOShapeActorSet	m_listUpdate;

	// Distort rectangle.
 
	// Distorted Rectangle, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon	m_aDistortedRect;

	// Split simple polygon.
 
	// Simple Polygon, This member specify FOPSimpleCompositePolygon object.  
	FOPSimpleCompositePolygon m_aSimplePoly;
	
	// Draw track pen 2.
 
	// Track Pen, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_pTrackPen;

	// Rectangle for simple tracking.
 
	// Simple Track, This member specify FOPRect object.  
	FOPRect				m_rcSimpleTrack;

	// The points of the control.
 
	// All Points, This member specify LPPOINT object.  
	LPPOINT					mpAllPoints;

	CArray <CPoint , CPoint> maTrackPts;

	// The total shapes within canvas.
 
	// All Shapes, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nAllShapes;

	CArray<FOPRect,FOPRect>		arRects;
};

#endif // !defined(AFX_FOSHAPEACTORMANAGER_H__A431E054_67A3_11DF_A46B_525400EA266C__INCLUDED_)
