//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPLAYERACTION_H__294B2FF5_AD19_4A7C_9A4A_15225B921475__INCLUDED_)
#define AFC_FOPLAYERACTION_H__294B2FF5_AD19_4A7C_9A4A_15225B921475__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Description
// Author: Author
///////////////////////////////////////

#include "FOAction.h"
#include "FOPLayer.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPAddLayerAction -- action that add new layer.

 
//===========================================================================
// Summary:
//     The CFOPAddLayerAction class derived from CFOAction
//      F O P Add Layer Action
//===========================================================================

class FO_EXT_CLASS CFOPAddLayerAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPAddLayerAction---F O P Add Layer Action, Specifies a E-XD++ CFOPAddLayerAction object (Value).
	DECLARE_ACTION(CFOPAddLayerAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Add Layer Action, Constructs a CFOPAddLayerAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		&aNew---&aNew, Specifies a const CFOPLayer &aNew object(Value).
	CFOPAddLayerAction(CFODataModel* pModel,const CFOPLayer &aNew);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Add Layer Action, Destructor of class CFOPAddLayerAction
	//		Returns A  value (Object).
	~CFOPAddLayerAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	//TODO:Add your code here.

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Data of layer.
 
	// New Data, This member specify E-XD++ CFOPLayer object.  
	CFOPLayer m_NewData;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPRemoveLayerAction -- action that remove layer.

 
//===========================================================================
// Summary:
//     The CFOPRemoveLayerAction class derived from CFOAction
//      F O P Remove Layer Action
//===========================================================================

class FO_EXT_CLASS CFOPRemoveLayerAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRemoveLayerAction---F O P Remove Layer Action, Specifies a E-XD++ CFOPRemoveLayerAction object (Value).
	DECLARE_ACTION(CFOPRemoveLayerAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Remove Layer Action, Constructs a CFOPRemoveLayerAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		&aNew---&aNew, Specifies a const CFOPLayer &aNew object(Value).
	CFOPRemoveLayerAction(CFODataModel* pModel,const CFOPLayer &aNew);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Remove Layer Action, Destructor of class CFOPRemoveLayerAction
	//		Returns A  value (Object).
	~CFOPRemoveLayerAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	//TODO:Add your code here.

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Data of the layer.
 
	// New Data, This member specify E-XD++ CFOPLayer object.  
	CFOPLayer m_NewData;

	//TODO:Add your code here.

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPChangeLayerAction -- action that change layer.

 
//===========================================================================
// Summary:
//     The CFOPChangeLayerAction class derived from CFOAction
//      F O P Change Layer Action
//===========================================================================

class FO_EXT_CLASS CFOPChangeLayerAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPChangeLayerAction---F O P Change Layer Action, Specifies a E-XD++ CFOPChangeLayerAction object (Value).
	DECLARE_ACTION(CFOPChangeLayerAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Change Layer Action, Constructs a CFOPChangeLayerAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nNew---nNew, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPChangeLayerAction(CFODataModel* pModel,CFODrawShape *pShape,UINT nNew);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Change Layer Action, Destructor of class CFOPChangeLayerAction
	//		Returns A  value (Object).
	~CFOPChangeLayerAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPChangeLayerAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	//TODO:Add your code here.

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// Pointer of the shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;

	//TODO:Add your code here.

	// New ID of the layer.
 
	// New I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nNewID;

	// Old ID of the layer.
 
	// Old I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nOldID;
   

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOPChangeLayerAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
_FOLIB_INLINE CFODrawShape *CFOPChangeLayerAction::GetShape()
{
	return m_pShape;
}

/////////////////////////////////////////////////////////////////////////////
// CFOPMoveLayerAction -- action that moving layer.

 
//===========================================================================
// Summary:
//     The CFOPMoveLayerAction class derived from CFOAction
//      F O P Move Layer Action
//===========================================================================

class FO_EXT_CLASS CFOPMoveLayerAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPMoveLayerAction---F O P Move Layer Action, Specifies a E-XD++ CFOPMoveLayerAction object (Value).
	DECLARE_ACTION(CFOPMoveLayerAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Move Layer Action, Constructs a CFOPMoveLayerAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nNewPos---New Position, Specifies A integer value.
	CFOPMoveLayerAction(CFODataModel* pModel,UINT nID,int nNewPos);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Move Layer Action, Destructor of class CFOPMoveLayerAction
	//		Returns A  value (Object).
	~CFOPMoveLayerAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	//TODO:Add your code here.

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:

	// ID of the layer.
 
	// Layer I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nLayerID;

	//TODO:Add your code here.

	// New pos of the layer.
 
	// New Position, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nNewPos;

	// Old pos of the layer.
 
	// Old Position, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nOldPos;
   

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPRenameLayerAction -- action that rename layer.

 
//===========================================================================
// Summary:
//     The CFOPRenameLayerAction class derived from CFOAction
//      F O P Rename Layer Action
//===========================================================================

class FO_EXT_CLASS CFOPRenameLayerAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRenameLayerAction---F O P Rename Layer Action, Specifies a E-XD++ CFOPRenameLayerAction object (Value).
	DECLARE_ACTION(CFOPRenameLayerAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Rename Layer Action, Constructs a CFOPRenameLayerAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		nLayer---nLayer, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		strName---strName, Specifies A CString type value.
	CFOPRenameLayerAction(CFODataModel* pModel,UINT nLayer,CString strName);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Rename Layer Action, Destructor of class CFOPRenameLayerAction
	//		Returns A  value (Object).
	~CFOPRenameLayerAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	//TODO:Add your code here.

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Layer I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nLayerID;

	//TODO:Add your code here.

	// New layer name
 
	// New Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strNewName;

	// Old layer name
 
	// Old Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strOldName;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};


#endif // !defined(AFC_FOPLAYERACTION_H__294B2FF5_AD19_4A7C_9A4A_15225B921475__INCLUDED_)
