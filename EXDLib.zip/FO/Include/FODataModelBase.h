//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODataModelBase.h: interface for the CFODataModelBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODATAMODELBASE_H__2EEABBF1_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FODATAMODELBASE_H__2EEABBF1_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOActionStack.h"
#include "FOBaseActionMacro.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFODataModelBase
//
// This is the base class of data model, it defines the framework of Undo/Redo.
// Call ResetHistory() method to clear all the actions in the cache.
//
// To execute an action, just call Do(..) method.
//
// If the data within the data model is changed, just call IsModified();
//
/////////////////////////////////////////////////////////////////////////////////

#define ACTION_UNDO_HISTORY_DEPTH 20
#define	ACTION_REDO_HISTORY_DEPTH 20

#include "FOIUnknown.h"

//===========================================================================
// Summary:
//      To use a CFODataModelBase object, just call the constructor.
//      F O Data Model Base
//===========================================================================

class FO_EXT_CLASS CFODataModelBase : public CFOObserver
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Data Model Base, Constructs a CFODataModelBase object.
	//		Returns A  value (Object).
	CFODataModelBase();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Data Model Base, Destructor of class CFODataModelBase
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODataModelBase();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Allow a new model, call this method should delete by yourself
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Model,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModelBase,or NULL if the call failed
	virtual CFODataModelBase* AllocModel() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Reset all the data,
	// Delete all the actions in the stack,it will clear the undo and redo's buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset History, Delete all the actions in the stack,it will clear the undo and redo's buffer.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetHistory();

	//-----------------------------------------------------------------------
	// Summary:
	// Is modified or not,override this method to handle your own modify flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsModified() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Log an action
	// pAction -- pointer of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Logical Action, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pAction---pAction, A pointer to the CFOBaseAction or NULL if the call failed.
	virtual void LogAction(
		// Specifies action.
		CFOBaseAction* pAction
		);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pAction---pAction, A pointer to the CFOBaseAction or NULL if the call failed.  
	//		bLog---bLog, Specifies A Boolean value.
	// Do action, execute action and log the action.
	virtual BOOL Do(
		// Specify pointer of action.
		CFOBaseAction* pAction,
		// Log or not.
		BOOL bLog = TRUE
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Undo macro actions, call this method to undo multiple actions one time, you can change the nTotal value to change
	// the number of actions that you want to undo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Undo Macro, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTotal---&nTotal, Specifies A integer value.
	virtual void UndoMacro(
		// Specifies the count actions to undo.
		const int &nTotal
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Redo macro actions, call this method to redo multiple actions one time, you can change the nTotal value to change
	// the number of actions that you want to redo.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Redo Macro, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTotal---&nTotal, Specifies A integer value.
	virtual void RedoMacro(
		// Specifies the count actions to redo.
		const int &nTotal
		);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Undo, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	// Undo action,this action undo one action one time.
	virtual CFOBaseAction* Undo();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Redo, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	// Redo action,this action redo one action one time.
	virtual CFOBaseAction* Redo();

	//-----------------------------------------------------------------------
	// Summary:
	// Call this method to get the next action on the undo stack.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Peek Undo, .
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	CFOBaseAction* PeekUndo();

	//-----------------------------------------------------------------------
	// Summary:
	// Undo mode by specify index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	CFOBaseAction* GetUndoAction(
		// The index of action
		const int &nIndex
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Call this method to get the next action on the redo stack
	
	//-----------------------------------------------------------------------
	// Summary:
	// Peek Redo, .
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	CFOBaseAction* PeekRedo();

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the action at a specify index, returns the pointer of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	CFOBaseAction* GetRedoAction(
		// The index of action.
		const int &nIndex
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the descriptions of the actions on the undo stack, all the descriptions will be stored within array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action Text, Returns the specified value.
	// Parameters:
	//		*array---Specifies A CString type value.
	void GetUndoActionText(
		// Undo string list.
		CStringArray *array
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain all the descriptions of the actions on the redo stack, all the descriptions will be stored within array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action Text, Returns the specified value.
	// Parameters:
	//		*array---Specifies A CString type value.
	void GetRedoActionText(
		// Redo string list.
		CStringArray *array
		);

	//-----------------------------------------------------------------------
	// Summary:
	// Is a action available to be undone, if the undo stack be empty, it will return FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Undo, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL CanUndo();

	//-----------------------------------------------------------------------
	// Summary:
	// Is a action available to be redone, if the redo stack be empty, it will return FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Can Redo, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL CanRedo();	

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the id of a specify undo action.
	// nIndex -- index of the action on the undo stack.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action Id, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	int GetUndoActionId( int nIndex ) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the id of a specify redo action.
	// nIndex -- index of the action on the redo stack.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action Id, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	int GetRedoActionId( int nIndex ) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get count of undo actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action Count, Returns the specified value.
	//		Returns a int type value.
	int GetUndoActionCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set max depth of undo actions.
	// nHistorySize -- new maximize history size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Undo Action Count, Sets a specify value to current class CFODataModelBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nHistorySize---History Size, Specifies A integer value.
	virtual void SetMaxUndoActionCount(int nHistorySize);

	//-----------------------------------------------------------------------
	// Summary:
	// Get max depth of undo actions, if the undo stack is empty, it will return 0.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Undo Action Count, Returns the specified value.
	//		Returns a int type value.
	int GetMaxUndoActionCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get count of actions on redo stack, if the redo stack is empty, it will return 0.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action Count, Returns the specified value.
	//		Returns a int type value.
	int GetRedoActionCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Set max depth of redo actions.
	// nHistorySize -- size of the max redo stack.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Maximize Redo Action Count, Sets a specify value to current class CFODataModelBase
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nHistorySize---History Size, Specifies A integer value.
	virtual void SetMaxRedoActionCount(int nHistorySize);

	//-----------------------------------------------------------------------
	// Summary:
	// Get max depth of redo actions, if the redo stack is empty, it will return 0.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Redo Action Count, Returns the specified value.
	//		Returns a int type value.
	int GetMaxRedoActionCount() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Status Change,when an action is executed, it will call this method, you can 
	// override this method to handle the change status.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Status Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnStatusChange();

	//-----------------------------------------------------------------------
	// Summary:
	// When an action be executed, this method will be called, you can override this method
	// to handle your own status.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Action Execute, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pAction---pAction, A pointer to the const CFOBaseAction or NULL if the call failed.
	virtual void OnActionExecute(const CFOBaseAction* pAction);

	//  Clean all the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Clean, Sets a specify value to current class CFODataModelBase

	void SetClean();

	// Clear undo buffer.
	void ClearUndoBuffer();

	//-----------------------------------------------------------------------
	// Summary:
	// Is Clean,if the undo stack is empty, it will return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Clean, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsClean();

	//-----------------------------------------------------------------------
	// Summary:
	// Is Dirty,if the undo stack is empty, it will return TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Dirty, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsDirty();

	//-----------------------------------------------------------------------
	// Summary:
	// Action stack.
	typedef CFOActionStack<CFOBaseAction*, CFOBaseAction*> ActionStack;

	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint)---Object*p Hint), A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( CObject * pModel,LPARAM lHint, CObject*pHint);

protected:

	// Undo stack.
 
	// Undo Stack, This member specify ActionStack object.  
	ActionStack m_UndoStack;

	// Redo stack.
 
	// Redo Stack, This member specify ActionStack object.  
	ActionStack m_RedoStack;

	// Undo stack.
 
	// Undo Back Stack, This member specify ActionStack object.  
	ActionStack m_UndoBackStack;

	// Redo stack.
 
	// Redo Back Stack, This member specify ActionStack object.  
	ActionStack m_RedoBackStack;

	// Maximize undo count.
	int		nMaxUndoCount;
};


/////////////////////////////////////////////////////////////////////////////////
//
// CFOCustomDataModel -- this is an children model of data, override two methods.
// 
/////////////////////////////////////////////////////////////////////////////////

// Below are the update flags.
#define FO_HINT_UPDATE_WINDOW      1000  // Update the full window.
#define FO_HINT_UPDATE_DRAWOBJ     1001  // Only update the shapes on the canvas.
#define FO_HINT_UPDATE_SELECTION   1002  // Only update the shapes that be selected on the canvas.
#define FO_HINT_EDIT_BACKGROUND	   1003  // Update the full window and un selection all.
#define FO_HINT_MODEL_CHANGED	   1004	 // Data model changed.

 
//===========================================================================
// Summary:
//     The CFOCustomDataModel class derived from CFODataModelBase
//      F O Custom Data Model
//===========================================================================

class FO_EXT_CLASS CFOCustomDataModel : public CFODataModelBase
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Status Change,when an action is executed,this method will be called,you can override this method to
	// do something.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Status Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnStatusChange();

	//-----------------------------------------------------------------------
	// Summary:
	// Action Execute,when an action is executed,this method will be called,you can override this method to
	// do something.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Action Execute, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pAction---pAction, A pointer to the const CFOBaseAction or NULL if the call failed.
	virtual void OnActionExecute(const CFOBaseAction* pAction);
};


/////////////////////////////////////////////////////////////////////////////////
//
// CFOWndDC -- the dc that handle default PrepareDC.
/////////////////////////////////////////////////////////////////////////////////

class CFOPCanvasCore;
 
//===========================================================================
// Summary:
//     The CFOWndDC class derived from CDC
//      F O Window D C
//===========================================================================

class FO_EXT_CLASS CFOWndDC : public CDC
{
public:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	// pWnd -- pointer of the window.
	// bNeedDC -- if it is true,the OnPrepareDC will be called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Window D C, Constructs a CFOWndDC object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pView---pView, A pointer to the CFOPCanvasCore or NULL if the call failed.  
	//		bNeedDC---Need D C, Specifies A Boolean value.
	CFOWndDC(CFOPCanvasCore* pView, BOOL bNeedDC = TRUE);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Window D C, Destructor of class CFOWndDC
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOWndDC();
	
protected:

	// Wnd handle.
 
	// Window, This member specify HWND object.  
	HWND m_hWnd;

	// Double buffer.
 
	// Double Buffer, This member sets TRUE if it is right.  
	BOOL m_bDoubleBuffer;
};

#endif // !defined(AFX_FODATAMODELBASE_H__2EEABBF1_F19E_11DD_A432_525400EA266C__INCLUDED_)
