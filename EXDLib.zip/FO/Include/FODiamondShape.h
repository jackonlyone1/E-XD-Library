//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FODIAMONDSHAPE_H__629B4400_0D67_11D6_A50A_525400EA266C__INCLUDED_)
#define AFC_FODIAMONDSHAPE_H__629B4400_0D67_11D6_A50A_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// New control.
///////////////////////////////////////

#define FO_COMP_DIAMOND FO_COMP_SYSTEM+1

#include "FODrawPortsShape.h"

//////////////////////////////////////////////////////
// CFODiamondShape -- diamond style shape, ID:FO_COMP_DIAMOND 51

 
//===========================================================================
// Summary:
//     The CFODiamondShape class derived from CFODrawPortsShape
//      F O Diamond Shape
//===========================================================================

class FO_EXT_CLASS CFODiamondShape : public CFODrawPortsShape  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODiamondShape---F O Diamond Shape, Specifies a E-XD++ CFODiamondShape object (Value).
	DECLARE_SERIAL(CFODiamondShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Diamond Shape, Constructs a CFODiamondShape object.
	//		Returns A  value (Object).
	CFODiamondShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Diamond Shape, Constructs a CFODiamondShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFODiamondShape& src object(Value).
	CFODiamondShape(const CFODiamondShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Diamond Shape, Destructor of class CFODiamondShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODiamondShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFODiamondShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the diamond shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODiamondShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFODiamondShape& src object(Value).
	CFODiamondShape& operator=(const CFODiamondShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// Update shape's area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#define PT_ARCTO           0x08

// Path point index.
struct FOPathPointIndex
{
	// First index, it is used for index of sub path.
	int first;

	// Second index, it is used for index of point.
	int second;
};

///////////////////////////////////////////////////////////
// FOPathPoint

class CFOPNewPathShape;
class CFOPathPointGroup;
class FO_EXT_CLASS FOPathPoint: public CObject
{
protected:
	
	DECLARE_SERIAL(FOPathPoint);
	
public:
    // property enum
    enum FO_POINT_STYLE
    {
        Normal = 0,			// no control points
        StartSubpath = 1,	// starts a new subpath by a moveTo command
        StopSubpath = 2,	// stops a subpath (last point of subpath)
        CloseSubpath = 8,	// closes a subpath (only applicable on StartSubpath and StopSubpath)
        IsSmooth = 16,		// smooth, both control points on a line through the point
        IsSymmetric = 32	// symmetric, like smooth but control points have same distance to point
    };

    // the type for identifying part of a FOPathPoint
    enum FO_POINT_TYPE 
	{
        Node = 1,          // the node point
        ControlPoint1 = 2, // the first control point
        ControlPoint2 = 4,  // the second control point
        All = 7
    };

public:
    // Default constructor
    FOPathPoint();

    // Constructor
    FOPathPoint(const CPoint &pt, UINT nStyle = Normal );

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
    // Copy Constructor
    FOPathPoint( const FOPathPoint & pathPoint );

    // Assignment operator.
    FOPathPoint& operator=( const FOPathPoint &src );

    // Compare operator
    BOOL operator == ( const FOPathPoint &src ) const;

	// Creates a copy of this Shape.
	virtual FOPathPoint* Copy() const;

    // Destructor
   virtual ~FOPathPoint();

public:
    // return the position relative to the shape origin
    CPoint GetPoint() const;

    // get the control point 1
    CPoint GetControlPoint1() const;

    // get the second control point
    CPoint GetControlPoint2() const;

    // alter the point
    void SetPoint( const CPoint &pt );

    // Set the control point 1
    void SetControlPoint1( const CPoint &pt );

	// Set arc control point
	void SetArcPoint(const CPoint &pt);

    // Set the control point 2
    void SetControlPoint2( const CPoint &pt );

    // Removes the first control point
    void RemoveControlPoint1();

    // Removes the second control point
    void RemoveControlPoint2();

    // Get the properties of a point
    UINT properties() const;

    // Set the properties of a point
    void SetProperties( UINT nStyle );

    // Sets a single property of a point.
    void SetProperty( UINT nStyle );

    // Removes a property from the point.
    void UnSetProperty( UINT nStyle );

    // Checks if there is a GetControlPoint1
    BOOL GetActiveControlState1() const;

    // Checks if there is a GetControlPoint2
    BOOL GetActiveControlState2() const;

	// Get arc state.
	BOOL GetArcState() const;

	// Change arc state.
	void SetArcState(const BOOL &bState) { m_bArc = bState; }

	// Obtain group.
	CFOPathPointGroup   *GetGroup() { return pointGroup; }

public:
   
    // Get the bounding rect of the point.
    CRect GetBoundRect( BOOL active = TRUE ) const;

    // Reverses the path point.
    void Reverse();

    // Returns if this point is a smooth join of adjacent path segments.
    BOOL GetSmooth( FOPathPoint * prev, FOPathPoint * next ) const;

	void RemoveFromGroup();
    void AddToGroup(CFOPathPointGroup *pointGroup);

	// point in shape points.
	int		m_nCompIndex;

	// point in shape points.
	int		m_nCompCtrl1;

	// point in shape points.
	int		m_nCompCtrl2;

protected:
	// First point.
    CPoint			m_ptFirst;

	// first control point.
    CPoint			m_ptControl1;

	// Second control point
    CPoint			m_ptControl2;

	// Property value
    UINT			m_nStyle;

	// With arc segment.
	BOOL			m_bArc;

	// active control point 1
    BOOL			m_bActivePt1;

	// active control point 2
    BOOL			m_bActivePt2;

	CFOPathPointGroup   *pointGroup;	
	
};

typedef CTypedPtrList<CObList, FOPathPoint*> CFOGroupPointList;

class FO_EXT_CLASS CFOPathPointGroup
{
public:
    CFOPathPointGroup() {}
    ~CFOPathPointGroup() {}
    void add(FOPathPoint *point);
    void remove(FOPathPoint *point);

private:
    // Group
	CFOGroupPointList m_points;
};

///////////////////////////////////////////////////////////
// CFOSubPath
 
class FO_EXT_CLASS CFOSubPath : public CObject  
{
protected:

	DECLARE_SERIAL(CFOSubPath);
public:
	
	// constructor
	CFOSubPath();
	
	// Constructor
	CFOSubPath( const CFOSubPath & pathPoint );

	// Destructor.
	virtual ~CFOSubPath();

	// Creates a copy of this Shape.
	virtual CFOSubPath* Copy() const;

	// Assignment operator.
    CFOSubPath& operator=( const CFOSubPath &src );

public:
	
	// Obtain the count of points.
	int GetPointCount() { return maPoints.Count(); }

	// Obtain point at.
	FOPathPoint *GetPointAt(const int &nIndex);

	// Insert a new point.
	void Insert(FOPathPoint *pPoint);

	// Remove point at.
	void RemoveAt(const int &nIndex);

	// Obtain last point.
	FOPathPoint *GetLast();

	// Obtain first point.
	FOPathPoint *GetFirst();
	
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
public:

	// Points
	FOPContainer	maPoints;
};

// A FOPathSegment consist of two neighboring FOPathPoints
class FO_EXT_CLASS FOPathSegment
{
public:
    // Creates a new segment from the given path points
    explicit FOPathSegment( FOPathPoint * pFirst = 0, 
		FOPathPoint * pSecond = 0);

    // Constructs segment by copying another segment
    FOPathSegment( const FOPathSegment & src );

    // Creates a new line segment
    FOPathSegment( const CPoint &p0, const CPoint &p1 );

    // Creates a new quadratic segment
    FOPathSegment( const CPoint &p0, const CPoint &p1, const CPoint &p2 );

    // Creates a new cubic segment
    FOPathSegment( const CPoint &p0, const CPoint &p1, const CPoint &p2, const CPoint &p3 );

    // Assigns segment
    FOPathSegment& operator=( const FOPathSegment &src );

    // Destroys the path segment
    virtual ~FOPathSegment();

public:

    // Returns the m_pFirst point of the segment
    FOPathPoint * GetFirst() const;

    // Sets the m_pFirst segment point
    void SetFirst( FOPathPoint * m_pFirst );

    // Returns the m_pSecond point of the segment
    FOPathPoint * GetSecond() const;

    // Sets the m_pSecond segment point
    void SetSecond( FOPathPoint * m_pSecond );

    // Returns if segment is valid, e.g. has two valid points
    BOOL IsValid() const;

	// Convert segment to cubic.
	FOPathSegment ConvertToCubic() const;

    // Compare operator
    BOOL operator == ( const FOPathSegment &src ) const;

    // Returns the degree of the segment: 1 = line, 2 = quadratic, 3 = cubic, -1 = invalid
    int Degree() const;

    // Returns point at given t
    CPoint GetPointAt( double t ) const;

    // Returns the control point bounding rect
    CRect GetControlPointRect() const;

    // Returns the length of the path segment
    double GetLength( double dValue = 0.005 ) const;

    // Returns segment length at given parameter
    double LengthAt( double t, double dValue = 0.005 ) const;

    // Returns the curve parameter at the given length of the segment
    double ParamAtLength( double length, double dTotal = 0.001 ) const;

	// Returns ordered list of control points
    void GetControlPoints(CArray <CPoint, CPoint> &maPoints) const;

	int GetControlCount() const;

	// Obtain center point.
	CPoint GetCenterPoint() const;

	// Obtain the area of segment.
	void GetArea(CFOArea &area);

	// Splits segment at given position returning the two resulting segments 
    void SplitAt( double t, FOPathSegment &segFirst, FOPathSegment &segSecond) const;

	// Obtain path shape.
	CFOPNewPathShape *GetPath() { return m_pPath; }

	// Set path shape.
	void SetPath(CFOPNewPathShape *pPath) { m_pPath = pPath; }

	
protected:
    // calculates signed distance of given point from segment chord
    double DistanceFromChord( const CPoint &pt ) const;

    // Returns the chord length, i.e. the distance between m_pFirst and last control point
    double ChordLength() const;

    // Compute length.
    void ComputeLength( double t, CPoint *p1, CPoint *p2, 
		CPoint *p3, CPoint *p4, CPoint *p5 ) const;

protected:
	// First path point
    FOPathPoint * m_pFirst;

	// second path point
    FOPathPoint * m_pSecond;

	// pointer of path shape
	CFOPNewPathShape *m_pPath;
};

////////////////////////////////////////////////////////////
// CFOPNewPathShape

class FO_EXT_CLASS CFOPNewPathShape : public CFODrawShape  
{
protected:
	DECLARE_SERIAL(CFOPNewPathShape);
public:

	// constructor
	CFOPNewPathShape();

	// Copy constructor.
	CFOPNewPathShape(const CFOPNewPathShape& src);

	// Destructor.
	virtual ~CFOPNewPathShape();

	// Creates the button Shape from a CRect object.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Creates the button Shape from a CRect object.
	virtual void Create(CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount, 
		const BOOL &bClose, CString strCaption = _T(""));

	// Creates the button Shape from a CRect object.
	virtual void Create(CONST LPPOINT lppt, int cCount, const BOOL &bClose,
		CString strCaption = _T(""));

	// Creates the button Shape from a CRect object.
	virtual void Create(const CArray<CPoint, CPoint> &mpPoints, const BOOL &bClose, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Creates the path shape from points.
	// aPathPoly -- points polygons of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create2, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nShapeType---Shape Type, Specifies a FOPShapeKind nShapeType object(Value).  
	//		aPathPoly---Path Polygon, Specifies a const FOPSimplePolygon& aPathPoly object(Value).
	BOOL Create(FOPSimplePolygon& aPathPoly);

	//-----------------------------------------------------------------------
	// Summary:
	// Create the path shape and initializes the data members.
	// strSVG -- SVG Text.
	// strCaption -- caption of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create With S V G, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strSVG---S V G, Specifies A CString type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual void CreateWithSVG(const CString &strSVG,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPathShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPt1---ptPt1, Specifies A integer value.  
	//		ptPt2---ptPt2, Specifies A integer value.
	// Creates the path shape from points.
	// ptPt1 -- start point of the line.
	// ptPt2 -- end point of the line.
	BOOL Create(const FOPPoint& ptPt1, const FOPPoint& ptPt2);

	// Assignment operator.
	CFOPNewPathShape& operator=(const CFOPNewPathShape& src);
	
	// Creates a copy of this Shape.
	virtual CFODrawShape* Copy() const;
	
	// Update shape's area.
	virtual void GeometryUpdated(CFOArea* pRgn);
	
	// Update shape's area.
	virtual void UpdateShapePoints();
	
	// Reverse update shape's points.
	virtual void ReverseUpdatePoints();

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Update poly.
	BOOL UpdatePoly(FOPSimplePolygon& aPathPoly);

	// Update all points.
	void UpdateAllPts(CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount, 
		const BOOL &bClose);

	// Update all points.
	void UpdateAllPts(CArray <CPoint, CPoint> &mpts, CArray <UINT, UINT> &mFlags, 
		const BOOL &bClose);

	void AddPolyAtHead(CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount);
	void AddPolyAtTail(CONST LPPOINT lppt, CONST LPBYTE lpbTypes, int cCount);

	FOPathPoint * splitSegment(FOPathPoint *p1, FOPathPoint *p2, double splitPosition);
	// Connect lines.
	// pptPoints -- points
	// nCount -- count of line points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	BOOL ConnectLines(LPPOINT pptPoints, int nCount);
	
	// Connect lines.
	// ptArray -- points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	//BOOL ConnectLines(CArray<CPoint,CPoint>* ptArray);
	
	// Connect the bezier line shape from points.
	// ptArray -- points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Bezier Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	//BOOL ConnectBezierLine(CArray<CPoint,CPoint>* ptArray);
public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 
	
	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	
	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	
	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();
	
	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeCircularShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetSimpleValue(const double &dValue);
	

public:

	// Obtain last point.
	CFOSubPath *GetLast();

	// Check if this is the correct point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Be Can Connect, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPnt---&ptPnt, Specifies A integer value.
	BOOL CheckBeCanConnect(const FOPPoint &ptPnt);

	// Obtain the connecting polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Connect Polygon, Returns the specified value.
	//		Returns a pointer to the object FOPSimplePolygon ,or NULL if the call failed
	FOPSimplePolygon *GetConnectPoly();

	// add a arc.
    int ConvertArcToCurve( double rx, double ry, double startAngle, 
		double sweepAngle, const CPoint & offset, CPoint * curvePoints ) const;

	// Update last point
	void UpdateLast( FOPathPoint ** pPtLast );
	
    // closes specified subpath
    void ClostSubPath( CFOSubPath *subPath );

    // close-merges specified subpath
    void ClostMergeSubPath( CFOSubPath *subPath );
	
public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	// Removes all subpaths and their points from the path
    void clear();
	
	// Start a new Subpath
    FOPathPoint * moveTo( const CPoint &p );
	
    // add a line
    FOPathPoint * lineTo( const CPoint &p );
	
    // add a cubic Bezier curve.
    FOPathPoint * curveTo( const CPoint &c1, const CPoint &c2, const CPoint &p );
	
    // add a quadratic Bezier curve.
    FOPathPoint * curveTo( const CPoint &c, const CPoint &p );
	
	// add a quadratic Bezier curve.
    FOPathPoint * arcTo( const CPoint &c, const CPoint &p );

	// add a quadratic Bezier curve.
    FOPathPoint * arcTo( const CPoint &ptTo, const double &nBulge );

    // add a arc.
    FOPathPoint * arcTo( double rx, double ry, double startAngle, double sweepAngle );
	
	FOPPoint GetArcCenter(const FOPPoint &m_Point, const CSize &m_Radius, 
		const BOOL &m_bIsLargeArc, const BOOL &m_bIsClockwise,
		const FOPPoint& ptFrom,
		BOOL& bIsLargeArc, double& rX, double& rY) const;
	
	// Get rotate handle location.
	// ptHandle -- result point value of the control point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

    // close the current subpath
    void close();
	
    // close the current subpath
    void closeMerge();
	
    // Normalizes the path data.
    virtual CPoint Normalize();

	// Inserts a new point into the given subpath at the specified position
    BOOL InsertPointNew2( FOPathPoint* pt, const FOPathPointIndex &aIndex );
	
    // Removes point from the path.
    FOPathPoint * RemovePointNew2( const FOPathPointIndex &aIndex );

	// Breaks the path after the point index
    BOOL BreakAfter( const FOPathPointIndex &aIndex );
	
    // Joins the given subpath with the following one
    BOOL Connect( int nIndexPath );
	
    // Move the position of a subpath within a path
    BOOL MoveSubPath( int nOldPathIndex, int nNewPathIndex );

	int DopPrevDraw(
		LPPOINT lppt,
		LPPOINT &pptOut,
		LPBYTE &byteOut, BOOL &bLine) const;

    // Open a closed subpath
    FOPathPointIndex OpenSubPath( const FOPathPointIndex &aIndex );
	
    // Close a open subpath
    void ClostSubPath( const FOPathPointIndex &aIndex );
	
	// Obtain all segments.
	virtual void GetAllSegments(CArray <FOPathSegment *, FOPathSegment *> &m_segments);

	// Obtain all points.
	void GetAllPathPoints(CArray <FOPathPoint *, FOPathPoint *> &maPts);
	void removeDuplicates();

	// Obtain all segments.
	virtual void GetAllSegmentCenters(CFOPHandleList& lstHandle);

	// Get the sport point of control by edit point,override this method to calc your own new control handle.
	// mpSpot -- control handles list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPointSpotLocation(CFOPHandleList& lstHandle);

	// Obtain the composite of the shape.
	// aPoly -- simple composite polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& aPoly) const;

	// Obtain segment.
	virtual FOPathSegment *GetCenterSegment(const int &nIndex);

	// Obtain segment.
	virtual FOPathSegment *HitTestSegment(const CPoint &ptHit);

public:

	// Get the path point index of a point
    FOPathPointIndex GetPathPointIndex( const FOPathPoint *pt ) const;
	
	// Get the point defined by a path point index
    FOPathPoint * GetPointByIndex( const FOPathPointIndex &aIndex ) const;

	// Check if subpath is closed
    BOOL IsSubPathClosed( int subpathIndex );

	// Is all the path closed.
	BOOL	IsAllSame();

	// Is all the path closed.
	BOOL	IsAllClosed();
	
	// Get the number of points in the path
    int PointCount() const;
	
    // Get the number of subpaths in the path
    int SubPathCount() const;
	
	// Get subpath at subpathIndex
    CFOSubPath * SubPath( int subpathIndex ) const;
	
	// Change sub path.
	virtual void SetSubPath(CFOSubPath *pSubPath, const int &nIndex);
	
	// Obtain point by index.
	virtual FOPathPoint *GetPointByIndex(const int &nIndex, int &nType);

	// Obtain segment by index.
	virtual FOPathSegment *GetSegmentByIndex(const int &nIndex);
	
    // Get the number of points in a subpath
    int PointCountSubpath( int subpathIndex ) const;

	// Get the segment defined by a path point index
    FOPathSegment *GetSegmentByIndex( const FOPathPointIndex &aIndex );

	// Offset control point.
	virtual void OffsetControlPoint(FOPathPoint * axPoint, const UINT &nPointType, const CPoint &ptOffset);

public:

    // Reverse subpath 
    BOOL ReverseSubPath( int subpathIndex );
	
    // Remove subpath from path
    CFOSubPath * ReMoveSubPath( int subpathIndex );
	
	// Add a Subpath at the given index to the path
    BOOL AddSubPath( CFOSubPath * subpath, int subpathIndex );
	
    // Combines two path.
	// path -- pointer of path.
    BOOL Combine( CFOPNewPathShape *path );

	// Is current shape to be closed or not.
	BOOL IsClosed() const { return m_bClose; }

	// Set current shape to be closed mode.
	void SetClosed(const BOOL &bClose) { m_bClose = bClose; }

	// Is line or not.
	virtual BOOL IsLine();

	// Is closed sub path.
	BOOL IsClosedSubpath(int subpathIndex);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

public:

	//Draw flat status.
	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the Shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of Shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the Shape.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	
	// Set line start object.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);
	
	// Get the line start object point.
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }
	
	
	// Line end object.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);
	
	// Get line end object.
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }
	
	// Remove line end object.
	virtual void RemoveLineEndObject();
	
	// Remove line start object.
	virtual void RemoveLineStartObject();
	
	// Build current line end object.
	virtual void BuildLineEndObject(int &nType);
	
	// Build current line start object.
	virtual void BuildLineStartObject(int &nType);

public:
	// Do end prop change.
	virtual void DoEndPropChange();
	
	// Set the properties of the shape.
	virtual void OnLineEditProperties();
	
	// Set the fill properties.
	virtual void OnFillEditProperties();

protected:
	// List of sub paths
	FOPContainer		m_subpaths;

	// Drawing flags.
	CArray <UINT, UINT> m_Flags;

	// Close or not
	BOOL				m_bClose;

	// Line start object.
	CFOBaseEndObject *	m_pLineStartObject;
	
	// Line end object.
	CFOBaseEndObject *	m_pLineEndObject;

};

#endif // !defined(AFC_FODIAMONDSHAPE_H__629B4400_0D67_11D6_A50A_525400EA266C__INCLUDED_)
