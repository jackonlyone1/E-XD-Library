//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/

#ifndef _UCC_TARGET_VER
#define _UCC_TARGET_VER

#pragma once

// You can include this file to your stdafx.h PRIOR to "#include <afxwin.h>" statement.

#ifndef WINVER
#if _MSC_VER < 1300
#elif _MSC_VER < 1400
	#define WINVER 0x0400		// Change this to the appropriate value to target Windows 98 and Windows 2000 or later.
#elif _MSC_VER < 1500
	#define WINVER 0x0501		// Change this to the appropriate value to target other 
#elif _MSC_VER == 1500
	#define WINVER 0x0600       // Change this to the appropriate value to target other versions of Windows.
#else
	#include <SDKDDKVer.h>
#endif
#endif

#endif // _UCC_TARGET_VER
