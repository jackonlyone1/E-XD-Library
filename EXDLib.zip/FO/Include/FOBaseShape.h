//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBaseShape.h: interface for the CFOBaseShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBASESHAPE_H__2EEABBF0_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOBASESHAPE_H__2EEABBF0_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOIUnknown.h"
#include "FOArea.h"
#include "FOPVisualProxy.h"

/////////////////////////////////////////////////////////////////////////////
// CFOBaseShape
//
// This is the base class of the shape,it defines a area of the shape.
// Override the GeometryUpdated(..) method to generate the area of the shape.
// 

 
//===========================================================================
// Summary:
//     The CFOBaseShape class derived from FOIUnknown
//      F O Base Shape
//===========================================================================

class FO_EXT_CLASS CFOBaseShape :public FOIUnknown, public CFOObserver
{
protected:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBaseShape---F O Base Shape, Specifies a E-XD++ CFOBaseShape object (Value).
	DECLARE_SERIAL(CFOBaseShape)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Construction/Destruction
	// Construction
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Shape, Constructs a CFOBaseShape object.
	//		Returns A  value (Object).
	CFOBaseShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	// point -- start location.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Shape, Constructs a CFOBaseShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		point---Specifies A CPoint type value.
    CFOBaseShape(CPoint point);

	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	// location -- start location.
	// size -- size of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Shape, Constructs a CFOBaseShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		location---Specifies A CPoint type value.  
	//		size---Specifies A CSize type value.
    CFOBaseShape(CPoint location, CSize size);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Construction
	// lpSrcRect -- rectangle of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Base Shape, Constructs a CFOBaseShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpSrcRect---Source Rectangle, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
    CFOBaseShape( LPCRECT lpSrcRect );

	//-----------------------------------------------------------------------
	// Summary:
	// Destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Base Shape, Destructor of class CFOBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOBaseShape();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBaseShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Create shape
	// rcPos -- position of shape.
	// strCaption -- the caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get the position of the shape,it will include the bounding of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Get the position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetDrawRect() const;

	// Set rectangle of label Dirty.
	// bDirty -- dirty or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label Dirty, Sets a specify value to current class CFOBaseShape
	// Parameters:
	//		&bDirty---&bDirty, Specifies A Boolean value.
	void SetLabelDirty(const BOOL &bDirty);

	// Re calculate extend bound rectangle.
	// rcBound -- bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

	// Get the width and height of this shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetSize() const;
	
	// Get the width of this shape by MM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width By M M, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetWidthByMM() const;

	// Get the height of this shape by MM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height By M M, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetHeightByMM() const;

	// Get the  previous rect width of this shape by MM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Width By M M, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetPrevWidthByMM() const;

	// Get the previous rect height of this shape by MM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Height By M M, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double GetPrevHeightByMM() const;

	// Obtain the ports max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Maximize Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPortsMaxBoundRect() const;

	// Reset center for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Rotate Center, Called this function to empty a previously initialized CFOBaseShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetRotateCenter();


	// Get center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetCenterPoint() const;

	// Get the origin of this shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Left, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetTopLeft() const;

	// Get the upper,right point of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Right, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetTopRight() const;

	// Get the lower,left point of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Left, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetBottomLeft() const;

	// Get the lower, right point of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Right, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetBottomRight() const;

	// Get the width of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Width, Returns the specified value.
	//		Returns a int type value.
	int GetWidth()	const				{ return  abs(m_rectPosition.right - m_rectPosition.left); }

	// Get the height of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
    int GetHeight()	 const				{ return abs(m_rectPosition.bottom - m_rectPosition.top); }

	// Get the previous position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect		  GetPrevRect()	const	{ return m_rectPrevPosition; }

	// Sets the previous position of the shape
	// lpSrcRect -- previous rectangle of saving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Previous Rectangle, Sets a specify value to current class CFOBaseShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpSrcRect---Source Rectangle, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	virtual void  SetPrevRect(LPCRECT lpSrcRect)	{ m_rectPrevPosition = lpSrcRect; }

	// Get current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Area, .
	//		Returns A const CFOArea value (Object).
	const CFOArea &GetShapeArea() const;

	// Get current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Extend Area, .
	//		Returns A const CFOArea value (Object).
	const CFOArea &GetShapeExtArea() const;

	// Get current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Label Area, .
	//		Returns A const CFOArea value (Object).
	const CFOArea &GetLabelArea() const;

	// Get snap position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetSnapRect() const;

	// Get snap position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Visible Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetVisibleSnapRect();


	// One rectangle contains other rectangle.
	// aRect -- rectangle for containing.
	// bRect -- rectangle for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contains Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&aRect---&aRect, Specifies a const FOPRect &aRect object(Value).  
	//		&bRect---&bRect, Specifies a const FOPRect &bRect object(Value).
	BOOL ContainsRect(const FOPRect &aRect, const FOPRect &bRect);

	// Contained by rectangle, is current shape to be contained by a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Contained By Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rRect---&rRect, Specifies a const FOPRect &rRect object(Value).
	BOOL ContainedByRectangle(const FOPRect &rRect)
	{
		return ContainsRect(rRect, GetSnapRect());
    }

	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint)---Object*p Hint), A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( CObject * pModel,LPARAM lHint, CObject*pHint);


public:

	// Normalize the bounding rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Normalize Bounds, .

	void	NormalizeBounds();
	
	// Size the shape.
	// rcNew -- new position
	// dXScale -- x scale value.
	// dYScale -- y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNew---&rcNew, Specifies A CRect type value.  
	//		dXScale---X Scale, Specifies a double dXScale object(Value).  
	//		dYScale---Y Scale, Specifies a double dYScale object(Value).
	virtual void SizeShape(CRect &rcNew,double dXScale,double dYScale);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  GeometryUpdated(CFOArea* pArea);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Compute label area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Label Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateLabelComp();

	// Generate Shape Area
	// pArea -- area of this label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryLabel(CFOArea* pArea);

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Update Component, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  ExtUpdateComp();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

	// Build unique port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Unique Port Name, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildUniquePortName();


	// Set rectangle of bounding dirty.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rects Dirty, Sets a specify value to current class CFOBaseShape
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetRectsDirty();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Be within the view or not.
 
	// With In View, This member sets TRUE if it is right.  
	BOOL		m_bWithInView;

protected:

	// Position of the shape.
 
	// Position for update, This member sets a CRect value.  
    FOPRect		m_rectPosition;

	// Snap rectangle of shape.
 
	// Snap rectangle, This member sets a CRect value.  
	FOPRect		m_rcSnap;

	// For snap moving simple rectangle, it is small than the snap rectangle.
	FOPRect		m_rcSimpleDraw;

	// Extend Snap rectangle of shape.
	
	// Snap rectangle for extend, This member sets a CRect value.  
	FOPRect		m_rcExtSnap;

	// Position of the label need to be recalculate
 
	// Label Dirty, This member sets TRUE if it is right.  
	BOOL		m_bLabelDirty;

	// Backup the position of the shape.
 
	// Previous Position, This member sets a CRect value.  
	FOPRect		m_rectPrevPosition;

	// Compute area.
 
	// Shape Area, This member specify E-XD++ CFOArea object.  
	CFOArea		m_ShapeArea;

	// Compute area.
 
	// Extend Shape Area, This member specify E-XD++ CFOArea object.  
	CFOArea		m_ExtShapeArea;

	// Compute area.
 
	// Label Area, This member specify E-XD++ CFOArea object.  
	CFOArea		m_LabelArea;

	// Be rectangle dirty
 
	// Rectangle Dirty, This member sets TRUE if it is right.  
	BOOL		m_bRectsDirty;

	// Load it at first	
 
	// Loaded, This member sets TRUE if it is right.  
	BOOL		m_bLoaded;

	// Update ports.
	BOOL		m_bUpdatePorts;

	// Point of rotate point.
 
	// Rotate Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint	m_ptRotateHandle;
	
	// Saving out length.
 
	// Save Out Length, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSaveOutLength;

	// Be rotate handle dirty.
 
	// Rotate Handle Dirty, This member sets TRUE if it is right.  
	BOOL		m_bRotateHandleDirty;

	// Is support rotate.
 
	// Support Rotate, This member sets TRUE if it is right.  
	BOOL		m_bSupportRotate;
};

// Get the origin of this shape
_FOLIB_INLINE CPoint CFOBaseShape::GetTopLeft() const
{
	return m_rectPosition.TopLeft();
}

// Get the upper, right edge of the shape
_FOLIB_INLINE CPoint CFOBaseShape::GetTopRight() const
{
	CPoint pt = GetTopLeft();
	pt.Offset(GetSize().cx, 0);
	return pt;
}

// Get the lower, left edge of the shape
_FOLIB_INLINE CPoint CFOBaseShape::GetBottomLeft() const
{
	CPoint pt = GetTopLeft();
	pt.Offset(0, GetSize().cy);
	return pt;
}

// Get the lower, right edge of the shape
_FOLIB_INLINE CPoint CFOBaseShape::GetBottomRight() const
{
	CPoint pt = GetTopLeft();
	pt.Offset(GetSize());
	return pt;
}

// Normalize the bounding rectangle
_FOLIB_INLINE void CFOBaseShape::NormalizeBounds()
{
	m_rectPosition.NormalizeRect();
}

// Get the width and height of this shape
_FOLIB_INLINE CSize CFOBaseShape::GetSize() const
{
	return m_rectPosition.Size();
}

/////////////////////////////////////////////////////////////////////////////
// Constant declarations

class CFOPHitTreeNode;

class FO_EXT_CLASS CFOPHitHelper
{
	// Node.
	struct XNode
    {
        enum Type { None = 0, VPlane = 1, HPlane = 2, All = 3 };
        inline XNode() : pos(0), type(None) {}
        int pos;
        Type type;
    };
    typedef XNode::Type NodeType;

	// Data
	struct XData
    {
        XData(void *p) : ptr(p) {}
        XData(int n) : i(n) {}
        union {
            void *ptr;
            int i;
        };
    };
    typedef CFOPHitHelper::XData XTreeData;

public:
	// Constructor.
	CFOPHitHelper();
	
	// Destructor
	virtual ~CFOPHitHelper();
	
public:
	void SetUserData(DWORD_PTR dwUserData)
	{
		m_dwUserData = dwUserData;
	}
	
	DWORD_PTR GetUserData() const
	{
		return m_dwUserData;
	}

	XNode GetLayoutType() const
	{
		return m_LayoutType;
	}
	
	void SetLayoutType(XNode layoutType)
	{
		m_LayoutType = layoutType;
	}


	// Create helper
	BOOL Create(const FOPRect &rcArea, CFODrawShapeSet* pShapeSet);

	int  m_nMaxRight;

	int m_nMaxBottom;

	// Init
	void DoInit(CFODrawShapeSet* pShapeSet);

	// Destroy.
	void Destroy();

	// Leaf count
	int leafCount() const;

	// Add new leaf.
	void insertLeaf(CFOBaseShape *pShape);

	// Add new leafs.
	void insertLeafs(CFODrawShapeSet* pShapeSet);

	// Remove leaf.
	void removeLeaf(CFOBaseShape* pShape);

	// Remove leafs.
	void removeLeafs(CFODrawShapeSet* pShapeSet);
	
	// Add new group.
	void AddGroup();

	// Remove all group.
	void RemoveAll();

	// Drawing.
	virtual void OnDraw(CDC* pDC, const FOPRect& rectClip);

	//  Mouse down.
	virtual BOOL OnMouseDown(int nButton, const FOPPoint& pt);

	// Mouse up.
	virtual void OnMouseUp(int nButton, const FOPPoint& pt);

	// Mouse leave.
	virtual void OnMouseLeave();

	// Cancel mode.
	virtual void OnCancelMode();

	// Get tool tip
	virtual BOOL OnGetToolTip(const FOPPoint& pt, CString& strToolTip, CString& strDescr);
public:
	// Point items
	void PointItems(CFODrawShapeSet* pList, const FOPPoint &ptCheck, int nExp = 0);
	
	// In rectangle
	void InRectItems(CFODrawShapeSet* pList, const FOPRect &rcCheck);
	
	// Intersecting.
	void OutRectItems(CFODrawShapeSet* pList, const FOPRect &rcCheck);

	FOPRect m_rcSave;
protected:
	// Node type.
	XNode		m_LayoutType;

	// Node.
	CFOPHitTreeNode* m_pRtNode;

	// Expand.
	int			m_nSplitValue;

	//  DWORD pointer
	DWORD_PTR	 m_dwUserData;

	// Size.
	CSize		m_sizeMargin;
};

#endif // !defined(AFX_FOBASESHAPE_H__2EEABBF0_F19E_11DD_A432_525400EA266C__INCLUDED_)
