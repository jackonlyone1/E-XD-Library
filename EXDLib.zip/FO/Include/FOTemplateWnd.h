//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTemplateWnd_H__1374EBF4_B7C8_11D5_A475_525400EA266C__INCLUDED_)
#define AFX_FOTemplateWnd_H__1374EBF4_B7C8_11D5_A475_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOTemplateWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOTemplateWnd window

// include head file of a bass object
#include "FOModelBoxItem.h"
#include "FOPMenuWndImpl.h"

#define TEMPLATEWND_CLASSNAME	_T("TemplateWnd")

// include head file of a bass object
#include "FODropSource.h"

 
//===========================================================================
// Summary:
//     The CFOTemplateWnd class derived from CWnd
//      F O Template Window
//===========================================================================

class FO_EXT_CLASS CFOTemplateWnd : public CWnd
{
// Construction
public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Template Window, Constructs a CFOTemplateWnd object.
	//		Returns A  value (Object).
	CFOTemplateWnd();

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Template Window, Destructor of class CFOTemplateWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTemplateWnd();
// Attributes
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, const RECT& rect,
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyleEx---Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( DWORD dwStyle, DWORD dwStyleEx, const RECT& rect, 
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	virtual BOOL Create( LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
		DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	// Create extend.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		hWndParent---Window Parent, Specifies a HWND hWndParent object(Value).  
	//		nIDorHMenu---I Dor H Menu, Specifies a HMENU nIDorHMenu object(Value).  
	//		lpParam---lpParam, Specifies a LPVOID lpParam = NULL object(Value).
	virtual BOOL CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
		                   int x, int y, int cx, int cy, HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

	// Creation new window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Page , Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL AttachPageCtrl( UINT uID, CWnd* pParentWnd );
	
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();

	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
	// Attributes

	// Pre translate message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// When drag and drop object call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// When Drag And Drop, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOModelBoxItem  or NULL if the call failed.
	virtual void WhenDragAndDrop(CFOModelBoxItem *pItem);

	BOOL  m_bDisableTab;
public:

	// get list of item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item List, Returns the specified value.
	//		Returns a pointer to the object CFOModelBoxItemList ,or NULL if the call failed
	CFOModelBoxItemList *GetItemList()		{ return &m_ItemList; }

	// first time after construct
	// strResFile -- resource file name ("").
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Data, Call InitData after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strResFile---Resource File, Specifies A CString type value.
	virtual void InitData(CString strResFile = _T(""));
	
	// add a new item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOModelBoxItem,or NULL if the call failed
	virtual CFOModelBoxItem* AddNewItem();

	// Add a new item.
	// nIconID -- Resource Icon ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOModelBoxItem,or NULL if the call failed  
	// Parameters:
	//		nIconID---Icon I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CFOModelBoxItem* AddNewItem(UINT nIconID);

	// add a new item.
	// strIconFile -- a specify icon file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Item, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOModelBoxItem,or NULL if the call failed  
	// Parameters:
	//		strIconFile---Icon File, Specifies A CString type value.
	virtual CFOModelBoxItem* AddNewItem(CString strIconFile);

	// Remove an item.
	// pItem -- a pointer to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pItem---*pItem, A pointer to the CFOModelBoxItem  or NULL if the call failed.
	virtual void RemoveItem(CFOModelBoxItem *pItem);

	// Remove an item.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Item, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	virtual void RemoveItem(int nType);

	// Find an item with type.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOModelBoxItem ,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	CFOModelBoxItem *FindItem(int nType);

	// Find an item with type.
	// nType -- the type id of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Item, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOModelBoxItem ,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies A integer value.
	CFOModelBoxItem *FindItem(CString &strTitle);

	// Select new item.
	void SelectNewItem(CFOModelBoxItem *pSelect);

	// get item counts
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Count, Returns the specified value.
	//		Returns a int type value.
	int GetItemCount();

	// clear all items
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearAll();

	// set item size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		nx---Specifies A integer value.  
	//		ny---Specifies A integer value.
	void SetItemSize(int nx,int ny);
	
	// update controls
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void UpdateControl(BOOL bMoveScroll = FALSE);
	
	// load res file
	// strFile -- a specify file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Resource File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL LoadResFile(CString strFile);

	// Save res file.
	// strFile -- a specify resource file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Resource File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL SaveResFile(CString strFile);

	// Do something when click on the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click On Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOModelBoxItem or NULL if the call failed.
	virtual void DoClickOnItem(CFOModelBoxItem* pPage);

protected:
	
	// Create memory dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Temp D C, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&pMemoryDC---Memory D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	virtual BOOL CreateTempDC( CDC* pDC, CDC* &pMemoryDC, const CRect& rcPaint) const;

	// Do paint.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Paint, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoPaint(CDC* pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// serialize
	virtual void Serialize(CArchive &ar);
	
	// save an document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// open an document
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// get a file pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

protected:

	// Get scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Pos32, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		bGetTrackPos---Get Track Position, Specifies A Boolean value.
	int GetScrollPos32(int nBar, BOOL bGetTrackPos = FALSE );
	
	// Set scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Pos32, Sets a specify value to current class CFOTemplateWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		nPos---nPos, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetScrollPos32( int nBar, int nPos, BOOL bRedraw = TRUE );

	// Make sure item visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ensure Visible, .
	// Parameters:
	//		pItem---pItem, A pointer to the CFOModelBoxItem or NULL if the call failed.
	void		EnsureVisible (CFOModelBoxItem* pItem);

public:

	// Obtain background color 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetBkColor() const							{ return m_crBackColor; }

	// Change the background color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetBkColor(const COLORREF crColor)			{ m_crBackColor = crColor; }
	
	// Obtain the item size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetItemSize() const							{ return CSize(nItemCX,nItemCY); }

	// Change the item size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		szItem---szItem, Specifies A CSize type value.
	void			SetItemSize(CSize szItem)					{ nItemCX = szItem.cx,nItemCY = szItem.cy; }
	
	// Obtain the item space
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Space, Returns the specified value.
	//		Returns a int type value.
	int				GetItemSpace() const						{ return nItemSpace; }

	// Change the item space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Space, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		nSpace---nSpace, Specifies A integer value.
	void			SetItemSpace(const int nSpace)				{ nItemSpace = nSpace; }

	// Obtain the font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString			GetFaceName() const;

	// Change the font face name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void			SetFaceName(LPCTSTR lpszFaceName);
	
	// Obtain the size of font points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int				GetPointSize() const;

	// Change the point size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void			SetPointSize(const int nPointSize, CDC* pDC = NULL);
	
	// Obtain the font height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int				GetHeight() const;

	// Change the font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		nHeight---nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void			SetHeight(const int nHeight, CDC* pDC = NULL);
	
	// Obtain the font color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetTextColor() const;

	// Change the font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetFontColor(const COLORREF crColor);
	
	// Obtain the font weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int				GetWeight() const;

	// Change the weight of the font.
	// nWeight -- weight of the font,700 is Bold.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		nWeight---nWeight, Specifies A integer value.
	void			SetWeight(const int nWeight);
	
	// Obtain the italic style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetItalic() const;

	// Change the italic style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		bItalic---bItalic, Specifies A Boolean value.
	void			SetItalic(const BOOL bItalic);
	
	// Obtain the underline style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetUnderline() const;

	// Change the underline style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		bUnderline---bUnderline, Specifies A Boolean value.
	void			SetUnderline(const BOOL bUnderline);
	
	// Obtain the strike out style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL			GetStrikeout() const;

	// Change the strike out style of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOTemplateWnd
	// Parameters:
	//		bStrikeout---bStrikeout, Specifies A Boolean value.
	void			SetStrikeout(const BOOL bStrikeout);

	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont*	CreateFont(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cool Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*			GetCoolFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void			ReleaseFontObject();

protected:
	
	// change to logical axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int				GetLogPoint(const int nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);
	
	// change from logic axis to point axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nLog---nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	int				GetPointFromLog(const int nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

protected:
	
	// create context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();
	
	// get start position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Position, Returns the specified value.
	// Parameters:
	//		&nStart---&nStart, Specifies A integer value.
	void			GetStartPos(int &nStart);
	
	// Hit test.
	// pt -- a specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOModelBoxItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOModelBoxItem *HitTest(CPoint pt);

	// Select item.
	// pt -- a specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Item, Call this function to select the given item.
	//		Returns a pointer to the object CFOModelBoxItem ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	CFOModelBoxItem *SelectedItem(CPoint pt);

	// Get selected item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	//		Returns a pointer to the object CFOModelBoxItem ,or NULL if the call failed
	CFOModelBoxItem *GetSelected();
	
	// Update current scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bMoveScroll---Move Scroll, Specifies A Boolean value.
	virtual void	UpdateScrollBar(BOOL bMoveScroll = FALSE);
	
	// get size of font
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetFontSize();
	
	// Draw Items
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Items, Called when a visual aspect of an owner-draw child button control, combo-box control, list-box control, or menu needs to be drawn.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void	OnDrawItems(CDC *pDC,const CRect &rcView);

	// calculate item position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Item Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcItemPosition();

	// Scroll to item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scroll Item, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOModelBoxItem or NULL if the call failed.  
	//		bUp---bUp, Specifies A Boolean value.
	virtual void ScrollItem(CFOModelBoxItem* pItem,BOOL bUp);

	// Do mouse over drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Do Before Over Page, Returns the specified value.
	//		Returns a pointer to the object CFOModelBoxItem,or NULL if the call failed
	CFOModelBoxItem* GetPreOverPage();

protected:

	// Convert rect from doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		rect---Specifies A CRect type value.
	void DocToClient(CRect& rect);

	// Doc to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		point---Specifies A CPoint type value.
	void DocToClient(CPoint& point);

	// Client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void ClientToDoc(CPoint& point);

	// Client to doc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void ClientToDoc(CRect& rect);

	// Invalidate rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// Parameters:
	//		rc---Specifies A CRect type value.
	void InvalRect(CRect rc);

public:
	// The clipboard format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	static CLIPFORMAT GetClipboardFormat ();

	// custom clipboard format.
 
	// Draw, This member specify CLIPFORMAT object.  
	static CLIPFORMAT m_cfDraw;

	// Save data to clipboard.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Data To Clipboard, Call this function to save the specify data to a file.
	// Parameters:
	//		pItem---pItem, A pointer to the CFOModelBoxItem or NULL if the call failed.
	void SaveDataToClipboard(CFOModelBoxItem* pItem);

	// Is ole support.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ole Support, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOleSupport();

	// Do ole drag and drop action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Ole Drag And Drop, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOModelBoxItem or NULL if the call failed.
	virtual void DoOleDragAndDrop(CFOModelBoxItem* pItem);

	// Create from ole data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From Ole Data, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pItem---pItem, A pointer to the CFOModelBoxItem or NULL if the call failed.  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.
	static BOOL CreateFromOleData(CFOModelBoxItem* pItem,COleDataObject* pDataObject);

	// Create ole drop source.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Source, You construct a CFOTemplateWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODropSource,or NULL if the call failed
	virtual CFODropSource* CreateDropSource();

	// Is paste enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Paste Enable, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPasteEnable() const					{ return m_bPasteItemByUser; }

	// Enable paste item by user.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Paste By User, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void		EnablePasteByUser(const BOOL bEnable)	{ m_bPasteItemByUser = bEnable; }

	// Customize Context menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Customize Context Menu, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&menu---Specifies a CMenu &menu object(Value).
	virtual void CustomizeContextMenu(CMenu &menu);

	// Is double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Edit Property, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsEnableEditProp() const				{ return m_bEnableEditProp; }

	// Set double click enable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Edit Property, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void		EnableEditProp(const BOOL bEnable)		{ m_bEnableEditProp = bEnable; }


	// Add page to cache
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Cache, Adds an object to the specify list.
	// Parameters:
	//		pPage---pPage, A pointer to the CFOModelBoxItem or NULL if the call failed.  
	//		rBitmap---rBitmap, Specifies a E-XD++ CFOBitmap& rBitmap object (Value).
	void		  AddToCache( CFOModelBoxItem* pPage, CFOBitmap& rBitmap);

	// Obtain current cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Cache, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOModelBoxItem or NULL if the call failed.
	CFOBitmap*    GetFromCache( CFOModelBoxItem* pPage) const;

	// Update all pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Pages, Call this member function to update the object.

	void UpdateAllPages();

// Operations
public:

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);   
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOTemplateWnd)
	public:

		// prepare device context
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:

		// update
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);

	// activate view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActivateView---Activate View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
protected:

#ifdef _DEBUG

	// performs a valid check
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// dumps the contents of your object
	virtual void Dump(CDumpContext& dc) const;

#endif

	// Generated message map functions
	//{{AFX_MSG(CFOTemplateWnd)
	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	// when left mouse button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	// when left mouse button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	// when double click on left button
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);

	// message WM_SIZE
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);

	// when erasing background
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	// when right button down
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

	// context menu displaying
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

	// when right mouse button up
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);

	// when painting
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();

	// adding a new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Add Newpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnAddNewpage();

	// update a new page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Add Newpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateAddNewpage(CCmdUI* pCmdUI);

	// remove a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnRemovePage();

	// update remove
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRemovePage(CCmdUI* pCmdUI);

	// set page caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Page Caption, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPageCaption();

	// update page caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Page Caption, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdatePageCaption(CCmdUI* pCmdUI);

	// change icon of a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Changeicon, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemChangeicon();

	// update icon changing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Changeicon, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemChangeicon(CCmdUI* pCmdUI);

	// copy a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Copy, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemCopy();

	// update item copying
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Copy, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemCopy(CCmdUI* pCmdUI);

	// create an empty item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Createempty, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemCreateempty();

	// update creating
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Createempty, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemCreateempty(CCmdUI* pCmdUI);

	// edit a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Edit, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemEdit();

	// update editing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Edit, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemEdit(CCmdUI* pCmdUI);

	// load file of a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Loadfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemLoadfile();

	// update loading
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Loadfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemLoadfile(CCmdUI* pCmdUI);

	// paste a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Paste, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemPaste();

	// update pasting
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Paste, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemPaste(CCmdUI* pCmdUI);

	// remove a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Remove, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemRemove();

	// update removing
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Remove, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemRemove(CCmdUI* pCmdUI);

	// change type of a toolbox item
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Item Changetype, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxItemChangetype();

	// update changing type
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Item Changetype, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxItemChangetype(CCmdUI* pCmdUI);

	// create new file of toolbox
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Newfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxNewfile();

	// update creating new file of toolbox
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Newfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxNewfile(CCmdUI* pCmdUI);

	// load file of toolbox
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Loadfile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxLoadfile();

	// update loading file of tool box
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Loadfile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxLoadfile(CCmdUI* pCmdUI);

	// save file of toolbox
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Toolbox Savefile, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoToolboxSavefile();

	// update saving file of toolbox
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Toolbox Savefile, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoToolboxSavefile(CCmdUI* pCmdUI);

	// System color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);

	// Key down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Leave, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnMouseLeave(WPARAM,LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
	
protected:

	// toolbox item list
 
	// Item List, This member specify E-XD++ CFOModelBoxItemList object.  
	CFOModelBoxItemList		m_ItemList;			

	// size of section
 
	// Section, This member sets a CSize value.  
	CSize					m_sizSection;		

	// sections number per row
 
	// Sections Per Row, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT					m_uSectionsPerRow;	

	// caption of items
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					strCaption;	

	// menu of context
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*					m_pContextMenu;		

	// width of scroll
 
	// Scroll Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_ScrollWidth;		

	// flag of modified
 
	// Modified, This member sets TRUE if it is right.  
	BOOL					bModified;			

	// item -cx
 
	// Item C X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCX;		
	
	// item -cy
 
	// Item C Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCY;			

	// item space
 
	// Item Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemSpace;		
	
	// current file
 
	// Current File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					strCurrentFile;		

	// background color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crBackColor;		

protected:
	
	// notify window
 
	// Notify Window, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd*					pNotifyWnd;			

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strFaceName;		
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL					m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL					m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL					m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*					m_pFont;

	// Paste new item by user.
 
	// Paste Item By User, This member sets TRUE if it is right.  
	BOOL					m_bPasteItemByUser;	

	// Enable or disable the double click to edit the label.
 
	// Enable Edit Property, This member sets TRUE if it is right.  
	BOOL					m_bEnableEditProp;

	// Images area
 
	// List, This member sets a CRect value.  
	CRect					m_rectList;

	// Is track or not.
 
	// Tracked, This member sets TRUE if it is right.  
	BOOL					m_bTracked;

	// Bitmap cache
 
	// Cache, This member maintains a pointer to the object CFOPTemplateBitmapCache.  
	CFOPTemplateBitmapCache* pCache;

	// Control has focus
 
	// Focused, This member sets TRUE if it is right.  
	BOOL					m_bFocused;				

};

/////////////////////////////////////////////////////////////////////////////
_FOLIB_INLINE CString CFOTemplateWnd::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOTemplateWnd::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOTemplateWnd::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOTemplateWnd::GetTextColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOTemplateWnd::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOTemplateWnd::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOTemplateWnd::SetItalic(const BOOL bItalic)
{
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOTemplateWnd::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOTemplateWnd::SetUnderline(const BOOL bUnderline)
{
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOTemplateWnd::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOTemplateWnd::SetStrikeout(const BOOL bStrikeout)
{
	m_bStrikeout = bStrikeout;
}


/////////////////////////////////////////////////////////////////////////////
// CFOPExtToolBarItem window

class FO_EXT_CLASS CFOPExtToolBarItem : public CObject
{ 
protected:
	DECLARE_SERIAL(CFOPExtToolBarItem);
public:
	CFOPExtToolBarItem();
	CFOPExtToolBarItem(CString strIFile,UINT nType,COLORREF crTrans= RGB(255,255,255));
	virtual ~CFOPExtToolBarItem();
	virtual void Serialize(CArchive &ar);
public:
	CString m_strCaption;
	int m_nNumber;
	
	CString m_strIconFile;
	CString m_strScript;
public:
	CString m_strControlStyle;
	CString m_strClassName;
	CString m_strEnglishName;
	BOOL m_bBorder;
	BOOL m_bClientEdge;
	int m_nDefaultWidth;
	int m_nDefaultHeight;

	BOOL m_bDisable;
	BOOL m_bSep;
	BOOL m_bCustom3;
	BOOL m_bCustom4;
	BOOL m_bCustom5;
	BOOL m_bCustom6;
	BOOL m_bCustom7;
	BOOL m_bCustom8;
	BOOL m_bCustom9;
	BOOL m_bCustom10;
	BOOL m_bCustom11;
	BOOL m_bCustom12;
	BOOL m_bCustom13;
	BOOL m_bCustom14;
	BOOL m_bCustom15;

	CString m_strCustom1;
	CString m_strCustom2;
	CString m_strCustom3;
	CString m_strCustom4;
	CString m_strCustom5;
	CString m_strCustom6;
	CString m_strCustom7;
	CString m_strCustom8;
	CString m_strCustom9;
	CString m_strCustom10;

	COLORREF m_crCustom1;
	COLORREF m_crCustom2;
	COLORREF m_crCustom3;
	COLORREF m_crCustom4;
	COLORREF m_crCustom5;
	COLORREF m_crCustom6;
	COLORREF m_crCustom7;
	COLORREF m_crCustom8;
	COLORREF m_crCustom9;
	COLORREF m_crCustom10;

	UINT m_nCustom1;
	UINT m_nCustom2;
	UINT m_nCustom3;
	UINT m_nCustom4;
	UINT m_nCustom5;
	UINT m_nCustom6;
	UINT m_nCustom7;
	UINT m_nCustom8;
	UINT m_nCustom9;
	UINT m_nCustom10;

	int m_intCustom1;
	int m_intCustom2;
	int m_intCustom3;
	int m_intCustom4;
	int m_intCustom5;
	int m_intCustom6;
	int m_intCustom7;
	int m_intCustom8;
	int m_intCustom9;
	int m_intCustom10;
private:	
	COLORREF crTransparent; 
	CRect m_rectPosition;
public:
	BOOL m_bSelected;
	BOOL m_bHitLast;
	UINT    m_nObjType;
	CFOImageIcon m_Dib; 
	inline CString GetToolCaption();
	inline COLORREF GetTransparentColor();
	inline CString GetIconFile();
	inline CString GetObjFile();
	inline int GetToolNumber();
	inline CRect GetPosition();
	inline void SetToolCaption(CString str);
	inline void SetTransColor(COLORREF cr);
	inline void SetNumber(int num);
	inline void SetPosition(CRect cr);
	BOOL LoadDib(CString strFile,COLORREF cr);
	BOOL LoadIcon(UINT nID,COLORREF cr);
	BOOL LoadObj(CString strFile);
	CString GetToolTips(UINT nType);
 
	void UpdateAll();
public:
	void DrawIconWithName(CDC *pDC);
	void DrawIconOnly(CDC *pDC);
	void DrawName(CDC *pDC);

	void DrawIconWithNameSelect(CDC *pDC);
	void DrawLastHit(CDC *pDC);
	void DrawIconOnlySelect(CDC *pDC);
	void DrawNameSelect(CDC *pDC);

	void DrawIconWithNameNormal(CDC *pDC);
	void DrawIconOnlyNormal(CDC *pDC);
	void DrawNameNormal(CDC *pDC);
 
	static void _DrawMaskedBitmap(CDC* pDC, CBitmap* pbmp, CBitmap* pbmpMask,
	                              int x, int y, int cx, int cy);
 
	static void _InitMaskFromBitmap(CBitmap* pbmp, CBitmap* pbmpMask);

	virtual void EditToolBitmap(CDC *pDC);
public:
	//virtual void Serialize(CArchive &ar);
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,
	CFileException* pError);
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

};
typedef CTypedPtrList<CObList, CFOPExtToolBarItem*> CFOPExtToolBarItemList;

///////////////////////////////////////////////////////
inline CString CFOPExtToolBarItem::GetToolCaption()
{
	return m_strCaption;
}

inline COLORREF CFOPExtToolBarItem::GetTransparentColor()
{
	return crTransparent;
}

inline CString CFOPExtToolBarItem::GetIconFile()
{
	return m_strIconFile;
}

inline CString CFOPExtToolBarItem::GetObjFile()
{
	return m_strScript;
}

inline int CFOPExtToolBarItem::GetToolNumber()
{
	return m_nNumber;
}
	
inline void CFOPExtToolBarItem::SetToolCaption(CString str)
{
	m_strCaption = str;
}

inline void CFOPExtToolBarItem::SetTransColor(COLORREF cr)
{
	crTransparent = cr;
//	m_Dib.LoadIcon(strIconFile,cr);
}

inline void CFOPExtToolBarItem::SetNumber(int num)
{
	m_nNumber = num;
}

inline CRect CFOPExtToolBarItem::GetPosition()
{
	return m_rectPosition;
}

inline void CFOPExtToolBarItem::SetPosition(CRect cr)
{
	m_rectPosition = cr;
}

#define TITLETIP_CLASSNAME _T("ZTitleTip")

/////////////////////////////////////////////////////////////////////////////
// CFOPExtToolTip window

class FO_EXT_CLASS CFOPExtToolTip : public CWnd
{
	// Construction
public:
	CFOPExtToolTip();
	virtual ~CFOPExtToolTip();
	virtual BOOL Create( CWnd *pParentWnd);
	
	// Attributes
public:
    void SetParentWnd(CWnd* pParentWnd)  { m_pParentWnd = pParentWnd; }
    CWnd* GetParentWnd()                 { return m_pParentWnd;       }
	
	// Operations
public:
	void Show(CRect rectTitle, LPCTSTR lpszTitleText, 
		int xoffset = 0, LPRECT lpHoverRect = NULL, 
		const LOGFONT* lpLogFont = NULL,
		COLORREF crTextClr = CLR_DEFAULT, COLORREF crBackClr = CLR_DEFAULT);
    void Hide();
	CFont newFont;
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtToolTip)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	CWnd  *m_pParentWnd;
	CRect  m_rectTitle;
    CRect  m_rectHover;
    DWORD  m_dwLastLButtonDown;
    DWORD  m_dwDblClickMsecs;
    BOOL   m_bCreated;
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtToolTip)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#define TPW_SIZE_DEFAULT_SPACING 0
#define TPW_NUM_LINESTEXT			1
#define TOOLWND_CLASSNAME	_T("ODToolWnd")

/////////////////////////////////////////////////////////////////////////////
// CFOPExtToolBarWnd window

class FO_EXT_CLASS CFOPExtToolBarWnd : public CWnd
{
// Construction
public:
	CFOPExtToolBarWnd();

	CFOPExtToolTip   m_TitleTip;
// Attributes
public:
	CFOPExtToolBarItemList m_Objects;
	CString m_strCaption;
	COLORREF m_crBackColor;
	int m_nItemCX;
	int m_nItemCY;
	int m_nItemSpace;
	UINT m_uSectionsPerRow;
	CSize m_sizSection;
	CFont m_fntSmall;
	BOOL m_bModified;
	CString m_strCurrentFile;
	int m_nCurScrollPos;
	int m_nScrollStart;
	int m_nScrollEnd;
	BOOL m_bAtStart;
	BOOL m_bAtEnd;
	CRect m_rcUp;
	CRect m_rcDown;
	CRect m_rcUpButton;
	CRect m_rcDownButton;
	BOOL m_bHitUpButton;
	BOOL m_bHitDownButton;
	void DrawUp(CDC *pDC);
	void DrawDown(CDC *pDC);
	void DrawUpSelect(CDC *pDC);
	void DrawDownSelect(CDC *pDC);
public:

	// Load toolbar.
	// lpszResourceName -- resource name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Bar, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResourceName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	BOOL LoadToolBar(LPCTSTR lpszResourceName);
	
	// Load toolbar
	// nIDResource -- resource id
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Bar, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL LoadToolBar(UINT nIDResource);

	BOOL AddToolBar(UINT nID, CString strTitle);

	// Set buttons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Buttons, Sets a specify value to current class CFOPToolBar
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
	virtual BOOL SetButtons(const UINT * lpIDArray, int nIDCount);
	
	//-----------------------------------------------------------------------
	// Summary:
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lphBmp---lphBmp, A pointer to the HBITMAP or NULL if the call failed.
	virtual int DoTempMethodx1(UINT nID, HBITMAP* lphBmp);
	
	// Image manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Manager, Returns the specified value.
	//		Returns a pointer to the object CFOPItemImageManager ,or NULL if the call failed
	CFOPItemImageManager * GetImageManager() const { return m_pImageManager; }
	
	// Set image manager
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Image Manager, Sets a specify value to current class CFOPToolBar
	// Parameters:
	//		pMgr---pMgr, A pointer to the CFOPItemImageManager  or NULL if the call failed.
	void SetImageManager(CFOPItemImageManager * pMgr);

	// Value
	CFOPItemImageManager *	m_pImageManager;

	void AddObj(CFOPExtToolBarItem *pObj);
	void RemoveObj(CFOPExtToolBarItem *pObj);
	void CalculateBestFit(int &nStart);

	CFOPExtToolBarItem *GetCurHit();
	void ClearAll();

	void Clear();
	void AdjuestSize();
	CFOPExtToolBarItem *HitTest(CPoint pt);
	CFOPExtToolBarItem *Hited(CPoint pt);
	CFOPExtToolBarItem *HitedLast(CPoint pt);
	CFOPExtToolBarItem *GetSelected();
	CFOPExtToolBarItem *GetLatHit();
	CFont newFont;
	HICON m_hIconLock;
	CFOPExtToolBarItem *SelectedObj();
	void InvalRect(CRect rc);
	void InvalItem(CFOPExtToolBarItem *pItem);
	
	CFOPExtToolBarItem *GetFirstNode();

	void ResetToSelectMode();
	void ResetView();
	void DoDrawAction(int nType);
	CFOPExtToolBarItem * GetItemAt(const int &nIndex);
	int GetSize();
	CSize GetFontSize();
	void SetupScrollBars();
	void SetItemSize(int nx,int ny);
	void Draw(CDC *pDC);

	BOOL m_bCoolMode;

	// Is track or not.
	
	// Tracked, This member sets TRUE if it is right.  
	BOOL					m_bTracked;

	// Change the indicators of the status bar
	// lpIDArray -- id array of the panes.
	// nIDCount -- the count of the IDs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Indicators, Sets a specify value to current class CFOPStatusBar
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpIDArray---I D Array, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nIDCount---I D Count, Specifies A integer value.
    BOOL SetIndicators(const UINT* lpIDArray, int nIDCount);
	
// Operations
public:
	virtual void Serialize(CArchive &ar);
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,
	CFileException* pError);
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
public:
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual INT_PTR OnToolHitTest(CPoint point, TOOLINFO* pTI) const;
	void InitUpdate();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPExtToolBarWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFOPExtToolBarWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPExtToolBarWnd)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnClose();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Leave, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnMouseLeave(WPARAM,LPARAM);
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTemplateWnd_H__1374EBF4_B7C8_11D5_A475_525400EA266C__INCLUDED_)
