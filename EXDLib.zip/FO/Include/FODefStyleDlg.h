//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODEFSTYLEDLG_H__C82A88F8_F408_4A7E_8126_A38A4B6A1BA0__INCLUDED_)
#define AFX_FODEFSTYLEDLG_H__C82A88F8_F408_4A7E_8126_A38A4B6A1BA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODefStyleDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFODefStyleDlg dialog

#include "FOPDropDownColorPickerButton.h"
#include "FOFontNameCombo.h"
#include "FOPDropDownLineWidthButton.h"
#include "FODiamondShape.h"
#include "FOLineShape.h"
#include "FOImageButton.h"

///////////////////////////////////////////////////////////
// CFOPDefStyleSample control

 
//===========================================================================
// Summary:
//     The CFOPDefStyleSample class derived from CWnd
//      F O P Default Style Sample
//===========================================================================

class FO_EXT_CLASS CFOPDefStyleSample : public CWnd
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Default Style Sample, Constructs a CFOPDefStyleSample object.
	//		Returns A  value (Object).
	CFOPDefStyleSample();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDefStyleSample object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	//Create Arrow Type Window
	BOOL Create(DWORD dwStyle,
		CRect rcPos, 
		CWnd* pParent,
		UINT nID);

	// Line shape
 
	// Line Shape, This member specify E-XD++ CFOLineShape object.  
	CFOLineShape		m_LineShape;

	// Diamond shape
 
	// Dia Shape, This member specify E-XD++ CFODiamondShape object.  
	CFODiamondShape		m_DiaShape;

	
	// Canvas color.
 
	// Canvas, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crCanvas;

	// Update shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shapes, Call this member function to update the object.
	// Parameters:
	//		&m_CurStyle---Current Style, Specifies a const CFOPShapeDefaultStyle &m_CurStyle object(Value).
	void UpdateShapes(const CFOPShapeDefaultStyle &m_CurStyle);

	// Be first or not.
 
	// First, This member sets TRUE if it is right.  
	BOOL				bFirst;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPDefStyleSample)
	//}}AFX_VIRTUAL

#if _MFC_VER < 0x0300
	// for deriving from a standard control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Super Window Process Function Address, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object WNDPROC,or NULL if the call failed
	virtual WNDPROC* GetSuperWndProcAddr();
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CFOPDefStyleSample)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

#include "FODefStyleCloseDlg.h"
#include "FODefStyleLineDlg.h"
#include "FOTabCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CFODefStyleDlg dialog

 
//===========================================================================
// Summary:
//     The CFODefStyleDlg class derived from CDialog
//      F O Default Style Dialog
//===========================================================================

class FO_EXT_CLASS CFODefStyleDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Default Style Dialog, Constructs a CFODefStyleDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFODefStyleDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFODefStyleDlg)
	enum { IDD = IDD_FO_DEF_STYLE_DLG };
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_strCaption;
	//}}AFX_DATA

	//Button Text Color
 
	// Canvas Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndCanvasColor;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Sample window.
 
	// Sample, This member specify E-XD++ CFOPDefStyleSample object.  
	CFOPDefStyleSample m_wndSample;
	CStringArray msaveOld;

	// Canvas color.
 
	// Canvas, This member sets A 32-bit value used as a color value.  
	COLORREF			m_crCanvas;

	// Modified or not
 
	// Modified, This member sets TRUE if it is right.  
	BOOL				m_bModified;

	// Create or not.
 
	// Created, This member sets TRUE if it is right.  
	BOOL				m_bCreated;

	// Window handle of tab control
 
	// Tab, This member specify E-XD++ CFOTabCtrl object.  
	CFOTabCtrl			m_wndTab;

	// first page.
 
	// This member specify E-XD++ CFODefStyleCloseDlg object.  
	CFODefStyleCloseDlg dlg1;

	// second page.
 
	// This member specify E-XD++ CFODefStyleLineDlg object.  
	CFODefStyleLineDlg	dlg2;

	// Init layers combobox.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Style Combo Box, Call InitStyleComboBox after creating a new object.

	void InitStyleComboBox();

	// Select style item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Style, Call this function to select the given item.
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	void SelectStyle(const CString &strName);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODefStyleDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFODefStyleDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Add, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Select change List Style, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSelchangeListStyle();
	afx_msg void OnDblclkFoListStyle();
	afx_msg void OnKillfocusFoEditNew();
	afx_msg void OnFoCompDelete();
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();

	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Canvas Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnCanvasColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODEFSTYLEDLG_H__C82A88F8_F408_4A7E_8126_A38A4B6A1BA0__INCLUDED_)
