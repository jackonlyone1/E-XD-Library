//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOBezierLineShape.h: interface for the CFOBezierLineShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOBEZIERLINESHAPE_H__958CDCD4_C5C6_11D5_A487_525400EA266C__INCLUDED_)
#define AFX_FOBEZIERLINESHAPE_H__958CDCD4_C5C6_11D5_A487_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseEndObject.h"
#include "FODrawShape.h"

/////////////////////////////////////////////////////////////////////////////
// CFOBezierLineShape -- bezier line shape -- id value FO_COMP_ROUND FO_SHAPE_BASE+28
//
// 

 
//===========================================================================
// Summary:
//     The CFOBezierLineShape class derived from CFODrawShape
//      F O Bezier Line Shape
//===========================================================================

class FO_EXT_CLASS CFOBezierLineShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOBezierLineShape---F O Bezier Line Shape, Specifies a E-XD++ CFOBezierLineShape object (Value).
	DECLARE_SERIAL(CFOBezierLineShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bezier Line Shape, Constructs a CFOBezierLineShape object.
	//		Returns A  value (Object).
	CFOBezierLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Bezier Line Shape, Constructs a CFOBezierLineShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBezierLineShape& src object(Value).
	CFOBezierLineShape(const CFOBezierLineShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Bezier Line Shape, Destructor of class CFOBezierLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOBezierLineShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBezierLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	// Create the bezier line shape from points.
	// ptArray -- points of shape border.
	BOOL Create(CArray<CPoint,CPoint>* ptArray);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBezierLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		mptPoints---mptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	// .Create the bezier line shape from points.
	// pptPoints -- points of shape border.
	// nCount -- total of points.
	BOOL Create(LPPOINT mptPoints, int nCount);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOBezierLineShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Get the sport point of control by drag handle, calculate the normal 8 control handles.
	// mpSpot -- result control handle list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetVisioNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the point of control.
	// parSpot -- spots of drag handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location.
	// ptHandle -- handle point that returned.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOBezierLineShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOBezierLineShape& src object(Value).
	CFOBezierLineShape& operator=(const CFOBezierLineShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area.
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Get border area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Area, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A E-XD++ CFOArea value (Object).
	virtual CFOArea GetBorderArea();

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& aPoly) const;

	// Gen bezier poly.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bezier Polygon, Returns the specified value.
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		&n---Specifies A integer value.
	FOPSimplePolygon GetBezierPoly(const int &n) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Is current shape closed or open.
	// return TRUE,it means it is closed.
	// return FALSE,it means it is opened.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Closed, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShapeClosed() const;

	// Pick nearest point by snap to control handle of the shape
	// ptPick -- output new snap point.
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap To  Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL SnapToControlHandle(CPoint &ptPick,const CPoint &ptHit);

	// Hit test any segment of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment Near Point, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		&pnt---Specifies A CPoint type value.
	int GetSegmentNearPoint(const CPoint &pnt);

	// Obtain nearest intersect point on line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection Point, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p1---Specifies A CPoint type value.  
	//		&p2---Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	BOOL GetNearestIntersectionPoint(const CPoint &p1, const CPoint &p2, CPoint &result);

public:

	// Line end object.
	// Set Line End Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line End Object, Sets a specify value to current class CFOBezierLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineEndObject(CFOBaseEndObject *pObject);

	// Get Line End Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line End Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineEndObject()	{ return m_pLineEndObject; }

	// Set Line Start Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Start Object, Sets a specify value to current class CFOBezierLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pObject---*pObject, A pointer to the CFOBaseEndObject  or NULL if the call failed.
	virtual void SetLineStartObject(CFOBaseEndObject *pObject);

	// Get Line Start Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Start Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseEndObject ,or NULL if the call failed
	virtual CFOBaseEndObject *GetLineStartObject()	{ return m_pLineStartObject; }

	// Remove Line End Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line End Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineEndObject();
	
	// Remove Line Start Object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Start Object, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveLineStartObject();

	// Build current line end object.
	// nType -- type of the arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line End Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineEndObject(int &nType);

	// Build current line start object.
	// nType -- type of the arrow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Line Start Object, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	virtual void BuildLineStartObject(int &nType);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.
	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Shadow D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareShadowDC(CDC* pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Draw Dot track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Dot Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DrawDotBorder(CDC* pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Microsoft Visio style Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

public:

#ifdef _DEBUG

	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	// AssertValid
	virtual void AssertValid() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	// Dump
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Do end prop change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Property Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndPropChange();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

};
#endif // !defined(AFX_FOBEZIERLINESHAPE_H__958CDCD4_C5C6_11D5_A487_525400EA266C__INCLUDED_)
