//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOFILLSAMPLEBUTTON_H__6028D3A1_00D9_11D6_A4EA_525400EA266C__INCLUDED_)
#define AFX_FOFILLSAMPLEBUTTON_H__6028D3A1_00D9_11D6_A4EA_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOFillSampleButton.h : header file
//

#include <FOPUtil.h>

/////////////////////////////////////////////////////////////////////////////
// CFOFillSampleButton window

 
//===========================================================================
// Summary:
//     The CFOFillSampleButton class derived from CButton
//      F O Fill Sample Button
//===========================================================================

class FO_EXT_CLASS CFOFillSampleButton : public CButton
{
	// DECLARE SERIAL CLASS
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N A M I C, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFillSampleButton---F O Fill Sample Button, Specifies a E-XD++ CFOFillSampleButton object (Value).
	DECLARE_DYNAMIC(CFOFillSampleButton);
public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fill Sample Button, Constructs a CFOFillSampleButton object.
	//		Returns A  value (Object).
	CFOFillSampleButton();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Fill Sample Button, Destructor of class CFOFillSampleButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFillSampleButton();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach, Attaches this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	// Attach
	// nID -- resource id.
	// pParent -- the pointer of parent window.
	BOOL Attach(const UINT nID,CWnd* pParent);
protected:

	// Draw Item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);

public:
	// Draw Frame
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Frame, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*DC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		R---R, Specifies A CRect type value.  
	//		Inset---Inset, Specifies A integer value.
	virtual void DrawFrame(CDC *DC, CRect R, int Inset);

	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file 
	virtual void Serialize(CArchive &ar);
 
	// Hit Test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint point);

	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOFillSampleButton object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draw select 
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawSelect(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Set Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CFOFillSampleButton
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void	SetRect(const CRect &rcPos)			{ m_rcPosition = rcPos; }

	// Get Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetRect() const						{ return m_rcPosition; }

	// Set Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOFillSampleButton
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void	SetBrushType(const int &nType);

	// Get Brush Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int		GetBrushType() const				{ return m_nBrushType; }

	// Set Cell Border Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Cell Border Size, Sets a specify value to current class CFOFillSampleButton
	// Parameters:
	//		nBorder---nBorder, Specifies A integer value.
	void SetCellBorderSize(const int nBorder)	{ nCellBorderSize = nBorder; }

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set F G Color, Sets a specify value to current class CFOFillSampleButton
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetFGColor(const COLORREF &cr);

	// get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get F G Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFGColor() const				{ return m_crFG; }

	// Set Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set B K Color, Sets a specify value to current class CFOFillSampleButton
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetBKColor(const COLORREF &cr);

	// Get Cell Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get B K Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetBKColor() const				{ return m_crBack; }

	// Get pattern bitmap by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

	// System colors.
 
	// System Colors, This member specify CDWordArray object.  
	CDWordArray m_arSysColors;

	// Draw pattern bitmap with given color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Pattern Bitmap, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void DrawPatternBitmap(CDC* pDC,const CRect& rect, COLORREF crColor);

	// Draw pattern bitmap with given color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Pattern Bitmap, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		dx---Specifies A integer value.  
	//		dy---Specifies A integer value.  
	//		rcColor---rcColor, Specifies A 32-bit COLORREF value used as a color value.
	void DrawPatternBitmap(CDC* pDC,int x,int y,int dx,int dy, COLORREF rcColor);

	// Get color by index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		n1---Specifies A integer value.  
	//		n2---Specifies A integer value.
	COLORREF XGetColor(int n1, int n2);

	// Get color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	COLORREF XGetColor(COLORREF crColor);

	// Get system color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get System Color, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	COLORREF XGetSysColor(int nIndex);

	FOPGradient *aGradient;
public:

	// Position of the cell.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Current cell FG color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crFG;

	// Current cell back color.
 
	// Back, This member sets A 32-bit value used as a color value.  
	COLORREF	m_crBack;

	// Current line type.
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int 		m_nBrushType;
	
	// Brush.
 
	// Brush Cell, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*		m_pBrushCell;

	// Cell border size.
 
	// Cell Border Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			nCellBorderSize;

	// None fill title text.
 
	// None, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_strNone;

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOFILLSAMPLEBUTTON_H__6028D3A1_00D9_11D6_A4EA_525400EA266C__INCLUDED_)
