//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPROPFILLDLG_H__C97B0174_E2CF_11D5_A4B4_525400EA266C__INCLUDED_)
#define AFX_FOPROPFILLDLG_H__C97B0174_E2CF_11D5_A4B4_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPropFillDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPropFillDlg dialog
#include "FOPDropDownColorPickerButton.h"
#include "FODropBrushTypeButton.h"
#include "FOFillSampleButton.h"
#include "FOImageButton.h"

 
//===========================================================================
// Summary:
//     The CFOPropFillDlg class derived from CDialog
//      F O Property Fill Dialog
//===========================================================================

class FO_EXT_CLASS CFOPropFillDlg : public CDialog
{

	// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Property Fill Dialog, Constructs a CFOPropFillDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOPropFillDlg(CWnd* pParent = NULL);   // standard constructor


	// Dialog Data
	//{{AFX_DATA(CFOPropFillDlg)
	enum { IDD = IDD_FO_PROP_FILL };
 
	// F G Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndFGColor;
 
	// B K Color, This member specify FOPDropDownColorPickerButton object.  
	FOPDropDownColorPickerButton	m_wndBKColor;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// Color select button.
 
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	

	// Fill type wnd.
 
	// Pattern, This member specify E-XD++ CFOBrushTypeWnd object.  
	CFOBrushTypeWnd m_wndPattern;

	// Pattern color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crFG;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBK;

	//Brush Type
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPropFillDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPropFillDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Start Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnStartColourChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Colour Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEndColourChange();

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill O K, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillOK(WPARAM wParam, LPARAM lParam);
	//Select Day Cancel
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lParam---lParam, Specifies A 32-bit LONG signed integer.
	afx_msg LRESULT OnFillCancel(WPARAM wParam, LPARAM lParam);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPROPFILLDLG_H__C97B0174_E2CF_11D5_A4B4_525400EA266C__INCLUDED_)
