//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-201? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOXNEWTABLESHAPE_H__FF56DBBC_09AE_4577_AAD8_FD1832DA43A0__INCLUDED_)
#define AFX_FOXNEWTABLESHAPE_H__FF56DBBC_09AE_4577_AAD8_FD1832DA43A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOXNewTableShape.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOXNewTableShape window

#include "FOPUtil.h"
#include "FORectShape.h"
#include "Table\FOPTableCellBorder.h"
#include "Table\FOPTableHelper.h"

class FOPCell;
class FOXTableModel;
class FOXTableRow;
class FOXTableColumn;
class FOXTableRows;
class FOXTableColumns;
class FOXNewTableShape;
#define FOP_TABLE_MERGE_CELLS                   2001
#define FOP_TABLE_SPLIT_CELLS                   2002
#define FOP_TABLE_VERT_BOTTOM                   2004
#define FOP_TABLE_VERT_CENTER                   2005
#define FOP_TABLE_VERT_NONE                     2006
#define FOP_TABLE_INSERT_ROW                    2007
#define FOP_TABLE_INSERT_COL                    2008
#define FOP_TABLE_DELETE_ROW                    2009
#define FOP_TABLE_DELETE_COL                    2010
#define FOP_TABLE_SELECT_ALL                    2011
#define FOP_TABLE_SELECT_COL                    2012
#define FOP_TABLE_SELECT_ROW                    2013
#define FOP_TABLE_AUTOSUM                       2015
#define FOP_TABLE_SORT_DIALOG                   2016

const int FOX_ACTIONNONE =					0;
const int FOX_ACTIONGOTO_FIRST_FOPCELL =	1;
const int FOX_ACTIONGOTO_FIRST_COLUMN =		2;
const int FOX_ACTIONGOTO_FIRST_ROW =		3;
const int FOX_ACTIONGOTO_LEFT_FOPCELL =		4;
const int FOX_ACTIONGOTO_UP_FOPCELL =		5;
const int FOX_ACTIONGOTO_RIGHT_FOPCELL =	6;
const int FOX_ACTIONGOTO_DOWN_FOPCELL =		7;
const int FOX_ACTIONGOTO_LAST_FOPCELL =		8;
const int FOX_ACTIONGOTO_LAST_COLUMN =		9;
const int FOX_ACTIONGOTO_LAST_ROW =			10;
const int FOX_ACTIONEDIT_FOPCELL =			11;
const int FOX_ACTIONSTOP_TEXT_EDIT =		12;
const int FOX_ACTIONREMOVE_SELECTION =		13;
const int FOX_ACTIONSTART_SELECTION =		14;
const int FOX_ACTIONHANDLED_BY_VIEW =		15;
const int FOX_ACTIONTAB =					18;

//===========================================================================
// Summary:
//     The CFOPNewTableCell class derived from CObject
//      F O P Table Cell
//===========================================================================

class FO_EXT_CLASS CFOPNewTableCell : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewTableCell---F O P Table Cell, Specifies a E-XD++ CFOPNewTableCell object (Value).
	DECLARE_SERIAL(CFOPNewTableCell);

protected:
    
	// With label editing or not.
 
	// With Label Editing, This member sets TRUE if it is right.  
	BOOL			m_bWithLabelEditing;

public:
    //-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPNewTableCell object.
	//		Returns A  value (Object).
    CFOPNewTableCell();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPNewTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPNewTableCell& source object(Value).
	CFOPNewTableCell(const CFOPNewTableCell& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewTableCell& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPNewTableCell& source object(Value).
	CFOPNewTableCell& operator=(const CFOPNewTableCell& source);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPNewTableCell,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPNewTableCell* Copy() const;

    //-----------------------------------------------------------------------
	// Summary:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Cell, Destructor of class CFOPNewTableCell
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~CFOPNewTableCell();

public:
	
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	// Obtain the text drawing alignment format type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Format Type, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetDrawFormatType();

	// Obtain the rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCellRect() { return maFOPCellRect; }
    
	// Get bitmap point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Bitmap, Returns the specified value.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CBitmap* GetPatternBitmap(int nIndex);

   
    // set the visibility of the rects.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOPNewTableCell
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVisible---bVisible, Specifies A Boolean value.
    virtual void SetVisible( BOOL bVisible ) { bVisible; }
    
    // Called once the frameset has been completely loaded or constructed.
    // The default implementation calls UpdateRects(). Call the parent :)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finalize, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void Finalize() {}
    
    // Drawing the cell
	// Draw borders of the table cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Borders, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		painter---Specifies A integer value.  
	//		&crect---Specifies A CRect type value.
    void OnDrawBorders( CDC* pDC, const FOPRect &crect);

	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.  
    void OnDraw( CDC *pDC,int nBrushType, BOOL bEditing, BOOL bDesign);

	// Draw the object with normal state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.  
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void DrawNormal(CDC *pDC,BOOL bEditing, int nBrushType, CFODataModel *pModel);
	
	// Draw the object with select state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Select, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bEditing---bEditing, Specifies A Boolean value.
	virtual void DrawSelect(CDC *pDC,int nBrushType, BOOL bEditing);

	// Draw text specify,it do not draw the bullets of the text.
	// pDC -- pointer of the DC
	// str -- drawing text caption.
	// lpRect -- drawing text within position.
	// crText -- font color.
	// nFormat -- text alignment format.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Text Extend, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		str---Specifies A CString type value.  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		&crText---&crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoDrawTextExt(CDC *pDC,const CString& str, LPRECT lpRect,
		const COLORREF &crText, UINT nFormat, int nArtType);

	// Calculate text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOPNewTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,CRect rcBox,CStringArray& arLines);

	// do flash timer.
	virtual void OnFlashTimer(UINT_PTR nTimerID);
	
	// start flash timer.
	void StartFlashCell();

	// Flash timer ID.
	int		m_nFlashTimerID;

	// List of frames
	
	// Frame Rectangle, This member specify E-XD++ CFOPCellRect object.  
    CFOPCellRect m_FrameRect;

public:
	// Define for text.
	// Get Object Caption,this is also the label of some shapes,such as CFOTextShape,CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const { return m_strCaption;}

	// Set Object Caption,you can also call this method to change the label of shapes,such as label of CFOTextShape
	// CFOLinkShape etc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(
		// Specify the new caption.
		const CString &str
		) { m_strCaption = str; }

	// Return With Label Editing value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get With Label Editing, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetWithLabelEditing() const { return m_bWithLabelEditing;}

	// frame management
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*_frame---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		recalc---Specifies A Boolean value.
    virtual void AddRect( CFOPCellRect *_frame, BOOL recalc = TRUE );
    
    // Delete a rectangle from the set of rects this list has.
    //  rc The rect that should be deleted
    //  remove passing TRUE means that there can not be an undo of the action.
    //  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		*rc---A pointer to the CFOPCellRect  or NULL if the call failed.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    void RemoveRect( CFOPCellRect *rc, BOOL remove = TRUE, BOOL recalc = TRUE ); // calls the virtual one

    // get a frame by number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Frame, Returns the specified value.
	//		Returns a pointer to the object CFOPCellRect ,or NULL if the call failed  
	// Parameters:
	//		_num---Specifies A integer value.
    CFOPCellRect *GetFrame( unsigned int _num );

	// Delete a rectangle from the set of rects this list has.
	//  num The rect Number to be removed.
	//  remove passing TRUE means that there can not be an undo of the action.
	//  recalc do an UpdateRects()
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Rectangle, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		num---Specifies A integer value.  
	//		remove---Specifies A Boolean value.  
	//		recalc---Specifies A Boolean value.
    virtual void RemoveRect( unsigned int num, BOOL remove = TRUE, BOOL recalc = TRUE );

	// Change With Label Editing value,if you want the text to be edited by double click on it,
	// this param must be TRUE,else it is FALSE.
	// bEdit -- editable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set With Label Editing, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bEdit---&bEdit, Specifies A Boolean value.
	void SetWithLabelEditing( const BOOL &bEdit ) {m_bWithLabelEditing = bEdit; }

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD GenEditingLabelAlign();

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GenLabelAlign();

	// Obtain type of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type Of , Returns the specified value.
	//		Returns a int type value.
	int GetTypeOfControl() const { return m_nTypeControl; }

	// Change the type of control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type Of , Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void SetTypeOfControl(const int &nType) { m_nTypeControl = nType; }

	// Obtain the choice text of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Choice Text, Returns the specified value.
	//		Returns a CString type value.
	CString GetChoiceText() const { return m_strChoice; }

	// Change the choice text of cell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Choice Text, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void SetChoiceText(const CString &strText ) { m_strChoice = strText; }
	
	
public:

	// Export data to svg file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export To S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strOut---strOut, Specifies A CString type value.
	virtual void ExportToSVG(CString* strOut);
	virtual void ExportToSVG(CStdioFile*);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Bezier(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Poly(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Line(const CPoint &ptStart, const CPoint &ptEnd);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Polyline(LPPOINT lpPoints, int nCount);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Rect(const FOPRect &rect);

	// Convert shape to svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString SVG_Ellipse(const FOPRect &rect);

	double PixXToPoint(double px);
	double PixYToPoint(double px);

	virtual void SVG_Gen(CString &strIn, int nBrushType);
	virtual void SVG_GenFill(CString &strIn, const CString &strMark1, const CString &strMark2);

	//-----------------------------------------------------------------------
	// Summary:
	// Shape To S V G String, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ShapeToSVGString();

	// Generate fill svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Fill S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		nGrayScale---Gray Scale, Specifies A integer value.
	virtual CString SVG_Fill(COLORREF crColor, int nGrayScale);

	// Generate SVG gradient string.
	CString	SVG_Gradient(CString* sSVGdefs);

	// Generate SVG hatch string.
	CString	SVG_Hatch(CString* sSVGdefs);

	// Generate SVG arrow string.
	CString	SVG_Arrow(int position, UINT Arrow, int ArrowSize, CString* sSVGdefs);
	// Generate hatch svg string

	//-----------------------------------------------------------------------
	// Summary:
	// Generate SVG Text, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		str---Specifies A CString type value.  
	//		&rcText---&rcText, Specifies A CRect type value.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&crText---&crText, Specifies A 32-bit COLORREF value used as a color value.  
	//		&bFullSize---Full Size, Specifies A Boolean value.  
	//		&bRealDraw---Real Draw, Specifies A Boolean value.
	virtual CString SVGGenDrawText(CDC *pDC,const CString& str,const CRect &rcText, UINT nFormat,
		const COLORREF &crText,
		const BOOL &bFullSize = TRUE,const BOOL &bRealDraw = TRUE);
	
	CString       SVG_HtmlFilter(CString sInput);
	CString       SVG_NameStrFilter(CString sInput);
	CString       SVG_AddTextHeader();
	
	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Obtain the svg drawing text position.
	virtual FOPRect GetSVGTextPosition(CDC *pDC, BOOL &bFullSize);

	//-----------------------------------------------------------------------
	// Summary:
	// Generate Hatch S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		sDefault---sDefault, Specifies A CString type value.
	virtual CString GenHatchSVG(CString* sDefault);

	// Generate arrow svg string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Arrow S V G, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		nArrow---nArrow, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nArrowSize---Arrow Size, Specifies A integer value.  
	//		sDefault---sDefault, Specifies A CString type value.
	virtual CString GenArrowSVG(int nIndex, UINT nArrow, int nArrowSize, CString* sDefault);

public:
	// Is Select
 
	// Select, This member sets TRUE if it is right.  
	BOOL			bSelect;
    
	// Version of shape.
 
	// Version, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nVersion;

	// Is lock or not.
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// Is expression support.
 
	// Is Expression, This member sets TRUE if it is right.  
	BOOL			m_bIsExpression;

	// Font Art type.
	int				m_nArtType;


public:
	// Load image from file.
	BOOL LoadImageFile(const CString &strImage);
	
protected:
	
	// Load picture file
	void LoadPictureFile();
	
public:
	LPPICTURE	m_pPicture;
	int m_nImageWidth;
	int m_nImageHeight;
	CString m_strFileName;
public:

	/*************************************************************************
	|*
	|* Fill brush properties
	|*
	\************************************************************************/

	// Define for brush.
	// Get Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change the back color,this is used by fill brush,the brush type must be 1,
	// if the brush type is within 3 - 41,it is used for fill hatch back color.
	// crBkColor -- new back color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Is It Transparent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTransparent() const;

	// Change to transparent fill mode.
	// bTransparent -- transparent or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void		SetTransparent(const BOOL &bTransparent);

	// Get BrushStyle
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Change fill brush type.
	// 0 -- Null brush.
	// 1 -- fill with back color.
	// 2 -- fill with pattern color.
	// 3-41 -- fill with hatch pattern.
	// 42 - 61 Fill with gradient mode.
	// 62- 91 Fill with pattern bitmap.
	// 92 Fill with custom pattern bitmap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void		SetBrushType(const int &nType);

	// Get Brush Hatch
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushHatch() const;

	// Change Brush Hatch type,must be (nHatch < HS_HORIZONTAL || nHatch > HS_DIAGCROSS)
	// nHatch -- hatch style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Hatch, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetBrushHatch(const int &nHatch);

	// get brush pattern Color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern Color,if the brush type is 2,shape use this color to fill.
	// If it is 3 - 41,this is the hatch pattern color.
	// cr -- new pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Define for brush.
	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOPNewTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CBrush* CreateBrush(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

// Attributes
public:
	// FODO:Add your properties items below.
	// Get Text Horizon Alignment
	// The alignment of text is one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Horizontal Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextHorzAlignment() const;

	// Set Text Horizon Alignment.
	// nT -- It must be one of the following value:
	// enum TextHorzAlign 
	//{
	//	TextLeft=0,					// Left
	//    TextMiddle,					// Center
	//    TextRight					// Right
	//};
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextHorzAlignment(const UINT &nT);

	// Get Text Vertical Alignment
	// The text vert alignment returns one of the following value:
	//	enum TextVertAlign 
	//{
	//	  TextTop = 0,				// Top 
	//    TextCenter,					// Center
	//    TextBottom					// Bottom
	//}; 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Vertical Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextVertAlignment() const;

	// Set Text Vertical Alignment,for how to change text vert alignment,please see Text Properties Dialog.
	// nT -- It must be one of the following value:
	//	enum TextVertAlign 
	//{
	//	  TextTop = 0,				// Top 
	//    TextCenter,					// Center
	//    TextBottom					// Bottom
	//}; 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Vertical Alignment, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextVertAlignment(const UINT &nT);

	// Is It MultiLine,if the text is multiple lines,return TRUE,else returns FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsMultiLine() const;

	// Set MultiLine,you can call this method to change the text of CFOTextShape's label to multiple lines.
	// bMulti -- multiple lines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Line, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void		SetMultiLine(const BOOL &bMulti);

public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	// nPointSize -- font point size.
	// pDC -- pointer of the dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	// nHeight -- height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	// Change the Font Color
	// crColor -- font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	// bItalic -- italic or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	// bUnderline -- underline or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	// bStrikeout -- strikeout or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOPNewTableCell
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);


public:
	// Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOPNewTableCell object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont* CreateFont(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void ReleaseFontObject();

protected:

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// From Logical To Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
    
	// Saving text.
 
	// Save, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_strSave;

	// Current flash frame.
	int			m_nCurFlash;

	// Visible.
	BOOL		m_bVisible;

	// Cell rectangle.
	FOPRect		maFOPCellRect;

	// pointer of table object.
	FOXNewTableShape* mpTableObj;

	// Second expression
	CString			m_strSecondValue;

public:
	// Caption value.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString         m_strCaption;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The transparent brush.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// The brush hatch type.
 
	// Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHatch;

	// Cached GDI brush. 
 
	// Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData		m_pBrush;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, This member specify E-XD++ CFOFontObjectData object.  
	CFOFontObjectData	m_pFont;

	// Define for win9x only.
 
	// New Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			*m_pNewFont;

	// Text alignment.
 
	// Text Horizontal Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextHorzAlignment;

	// Vert text alignment.
 
	// Text Vertical Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextVertAlignment;

	// Multi lines
 
	// Multiple Line, This member sets TRUE if it is right.  
	BOOL			m_bMultiLine;

	// Type of control in this table cell.
 
	// Type , This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTypeControl;

	// Options value.
 
	// Choice, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strChoice;

	// Formula.
	CString			msFormula;

	// value.
	double			mfValue;

	// error code.
	int				mnError;

	// merged.
	BOOL			mbMerged;

	// row span.
	int				mnRowSpan;

	// Column span.
	int				mnColSpan;
	
	// Draw slant line.
	BOOL			mbSlantLine;
};

typedef CTypedPtrList<CObList, CFOPNewTableCell*> CFOPNewTableCellList;

_FOLIB_INLINE int CFOPNewTableCell::GetBrushHatch() const
{
	return m_nHatch;
}

_FOLIB_INLINE int CFOPNewTableCell::GetBrushType() const
{
	return m_nBrushType;
}

_FOLIB_INLINE BOOL CFOPNewTableCell::GetTransparent() const
{
	return m_bTransparent;
}

_FOLIB_INLINE void CFOPNewTableCell::SetTransparent(const BOOL &bTransparent)
{
	ReleaseBrushObject();
	m_bTransparent = bTransparent;
}

_FOLIB_INLINE	COLORREF CFOPNewTableCell::GetBkColor() const					
{ 
	return m_crBkColor; 
}

_FOLIB_INLINE	void CFOPNewTableCell::SetBkColor(const COLORREF &crBkColor)	
{	
	ReleaseBrushObject();
	m_crBkColor = crBkColor;
}

_FOLIB_INLINE	void CFOPNewTableCell::SetPatternColor(const COLORREF &cr)	
{	
	ReleaseBrushObject();
	m_crHatch = cr;
}

_FOLIB_INLINE COLORREF CFOPNewTableCell::GetPatternColor() const
{
	return m_crHatch;
}

_FOLIB_INLINE	UINT CFOPNewTableCell::GetTextHorzAlignment()	const
{ 
	return m_nTextHorzAlignment;
}

_FOLIB_INLINE void CFOPNewTableCell::SetTextHorzAlignment(const UINT &nT)	
{ 
	m_nTextHorzAlignment = nT;
}

_FOLIB_INLINE	BOOL CFOPNewTableCell::IsMultiLine() const
{
	return m_bMultiLine;
}

_FOLIB_INLINE	void CFOPNewTableCell::SetMultiLine(const BOOL &bMulti)
{
	m_bMultiLine = bMulti;
}

_FOLIB_INLINE	UINT CFOPNewTableCell::GetTextVertAlignment()	const
{ 
	return m_nTextVertAlignment;
}

_FOLIB_INLINE void CFOPNewTableCell::SetTextVertAlignment(const UINT &nT)	
{ 
	m_nTextVertAlignment = nT;
}

_FOLIB_INLINE CString CFOPNewTableCell::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOPNewTableCell::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOPNewTableCell::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOPNewTableCell::GetFontColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOPNewTableCell::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOPNewTableCell::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOPNewTableCell::SetItalic(const BOOL &bItalic)
{
	ReleaseFontObject();
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOPNewTableCell::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOPNewTableCell::SetUnderline(const BOOL &bUnderline)
{
	ReleaseFontObject();
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOPNewTableCell::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOPNewTableCell::SetStrikeout(const BOOL &bStrikeout)
{
	ReleaseFontObject();
	m_bStrikeout = bStrikeout;
}

// -----------------------------------------------------------------------------
// FOXRangeIterator
// -----------------------------------------------------------------------------

template< typename T >
class FOXRangeIterator
{
public:
	FOXRangeIterator( const T& rStart, const T& rEnd, BOOL bForeward = true )
	{
		if( bForeward )
		{
			maIter = rStart;
			maEnd = rEnd;
		}
		else
		{
			maIter = rEnd-1;
			maEnd = rStart-1;
		}
	}

	BOOL hasNext() const
	{
		return maIter != maEnd;
	}
	
	BOOL next( T& rValue )
	{
		if( maIter == maEnd )
			return false;
		
		rValue = maIter;
		if( maIter < maEnd )
			maIter++;
		else
			maIter--;
		return true;
	}
	
private:
	T maEnd;
	T maIter;
};

// -----------------------------------------------------------------------------
// IFOPRef
// -----------------------------------------------------------------------------

class IFOPRef
{
public:
	virtual int  AddRef() = 0;
	virtual int  Release() = 0;
};


// -----------------------------------------------------------------------------
// FOPRef
// -----------------------------------------------------------------------------

template <class fopref_type>
class FO_EXT_CLASS FOPRef
{
	fopref_type * m_pBody;


public:

	inline FOPRef()
		: m_pBody (0)
	{}


	inline FOPRef (fopref_type * pBody)
		: m_pBody (pBody)
	{
// 		if (m_pBody)
// 			m_pBody->AddRef();
	}
	

	inline FOPRef (const FOPRef<fopref_type> & handle)
		: m_pBody (handle.m_pBody)
	{
// 		if (m_pBody)
// 			m_pBody->AddRef();
	}


	inline ~FOPRef()
	{
// 		if (m_pBody)
// 			m_pBody->Release();
	}


	inline FOPRef<fopref_type> &
	 set (fopref_type * pBody)
	{
// 		if (pBody)
// 			pBody->AddRef();
        fopref_type * const pOld = m_pBody;
		m_pBody = pBody;
// 		if (pOld)
// 			pOld->Release();
		return *this;
	}

	inline FOPRef<fopref_type> &
	 operator= (const FOPRef<fopref_type> & handle)
	{
        return set( handle.m_pBody );
	}

	inline FOPRef<fopref_type> &
	 operator= (fopref_type * pBody)
	{
        return set( pBody );
	}

	inline FOPRef<fopref_type> &  clear()
	{
		if (m_pBody)
		{
            fopref_type * const pOld = m_pBody;
			m_pBody = 0;
		}
		return *this;
	}

	inline fopref_type *  get() const
	{
		return m_pBody;
	}


	inline fopref_type *  operator->() const
	{
		return m_pBody;
	}


	inline fopref_type &  operator*() const
	{
		return *m_pBody;
	}


	inline BOOL  is() const
	{
		return (m_pBody != 0);
	}


	inline BOOL  operator== (const fopref_type * pBody) const
	{
		return (m_pBody == pBody);
	}

	inline BOOL
	 operator== (const FOPRef<fopref_type> & handle) const
	{
		return (m_pBody == handle.m_pBody);
	}

	inline BOOL
	 operator!= (const FOPRef<fopref_type> & handle) const
	{
		return (m_pBody != handle.m_pBody);
	}


	inline BOOL
	 operator< (const FOPRef<fopref_type> & handle) const
	{
		return (m_pBody < handle.m_pBody);
	}


	inline BOOL
	 operator> (const FOPRef<fopref_type> & handle) const
	{
		return (m_pBody > handle.m_pBody);
	}
};

template <typename T>
inline T * get_pointer( FOPRef<T> const& r )
{
    return r.get();
}
typedef FOPRef< FOPCell > FOPCellRef;
typedef FOPRef< FOXTableModel > FOXTableModelRef;
typedef FOPRef< FOXTableRow > FOXTableRowRef;
typedef FOPRef< FOXTableColumn > FOXTableColumnRef;
typedef FOPRef< FOXTableRows > FOXTableRowsRef;
typedef FOPRef< FOXTableColumns > FOXTableColumnsRef;
typedef std::vector< FOPCellRef > FOPCellVector;
typedef std::vector< FOXTableRowRef > FOXRowVector;
typedef std::vector< FOXTableColumnRef > FOXColumnVector;

/////////////////////////////////////////////////////////////////////////////
// FOXNewTableShape window

class FO_EXT_CLASS FOPCell : public CFOPNewTableCell
{
    friend class FOPCellUndo;
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPNewTableCell---F O P Table Cell, Specifies a E-XD++ CFOPNewTableCell object (Value).
	DECLARE_SERIAL(FOPCell);
	
public:
	static FOPRef< FOPCell > create( FOXNewTableShape& rTableObj);
	
    // private
	void dispose();
	
    // CObjectShape proxy
    BOOL IsTextEditActive();

	// Has text or not.
	BOOL hasText() const;

	// Obtain current bounding rectangle.
	const FOPRect& GetCurrentBoundRect() const;

	// Take text anchor rectangle.
	void TakeTextAnchorRect(FOPRect& rAnchorRect) const;

	// Clone from
	void cloneFrom( const FOPCellRef& rFOPCell );
	
	// Set cell rectangle.
	void setCellRect( FOPRect& rFOPCellRect ) { maFOPCellRect = rFOPCellRect; }

	// Obtain cell rectangle.
	const FOPRect& getCellRect() const { return maFOPCellRect; }

	// get cell rectangle.
	FOPRect& getCellRect() { return maFOPCellRect; }

	// Add reference.
	virtual int  AddRef() { return 0; };

	// Release a reference.
	virtual int  Release() { return 0; };

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPNewTableCell& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPNewTableCell& source object(Value).
	FOPCell& operator=(const FOPCell& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPNewTableCell,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPNewTableCell* Copy() const;

	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

	// obtain minimum width.
	int getMinimumWidth();

	// obtain minimum height.
	int getMinimumHeight();
	

	// Obtain text left space.
	long GetTextLeftDistance() const;

	// Obtain text right space.
	long GetTextRightDistance() const;

	// Obtain text upper space.
	long GetTextUpperDistance() const;

	// Obtain text bottom space.
	long GetTextLowerDistance() const;

	// Add undo.
	void AddUndo();

	// Merge
	void merge( int nColumnSpan, int nRowSpan );

	// Merge content
	void mergeContent( const FOPCellRef& xSourceFOPCell );

	// Replace content and formating it.
	void replaceContentAndFormating( const FOPCellRef& xSourceFOPCell );
	
	// Set merged mark.
	void setMerged();

	// Obtain minimize size.
	virtual FOPSize  getMinimumSize(  );

	// Obtain preferred size.
	virtual FOPSize  getPreferredSize(  );
	virtual FOPSize  calcAdjustedSize( const FOPSize& aNewSize );
	
	// Obtain row span
	virtual int  getRowSpan();

	// Obtain column span.
	virtual int  getColumnSpan();

	// Is merged or not.
	virtual BOOL  isMerged();

	// Obtain formula.
	virtual CString  getFormula();

	// set formula
	virtual void  setFormula( const CString& aFormula );

	// get value.
	virtual double  getValue();

	// obtain value.
	virtual void  setValue( double nValue );

	// get error.
	virtual int  getError() { return 0; };
	
	// Obtain string.
	virtual CString  getString(  );

	// change string.
	virtual void  setString( const CString& aString );
	
	// disposing.
	virtual void  disposing();

	// Notify modified.
	void notifyModified();
	

	// Obtain name.
    CString getName();
	
public:
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPNewTableCell object.
	//		Returns A  value (Object).
    FOPCell();
	FOPCell( FOXNewTableShape& rTableObj) ;
	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Cell, Constructs a CFOPNewTableCell object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPNewTableCell& source object(Value).
	FOPCell(const FOPCell& source);
	
	// Destructor.
	virtual ~FOPCell() ;


	// table model pointer.
	FOPRef< FOXTableModel > mxTable;
	
};

class FOXNewTableShape;
class FOPCellRange;
class FOPCellCursor;

// -----------------------------------------------------------------------------
// IFOPCellRange
// -----------------------------------------------------------------------------

class IFOPCellRange
{
public:
	virtual int getLeft() = 0;
	virtual int getTop() = 0;
	virtual int getRight() = 0;
	virtual int getBottom() = 0;
	
};

typedef CTypedPtrList<CObList, FOXTableColumn*> FOXTableColumnList;
typedef CTypedPtrList<CObList, FOXTableRow*> FOXTableRowList;

// -----------------------------------------------------------------------------
// FOXTableModel
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableModel : public CObject,
				   public IFOPCellRange
{
	friend class FOXTableColumn;
	friend class FOXTableRow;
	friend class FOXTableRows;
	friend class FOXTableColumns;

public:

	// Constructor.
	FOXTableModel( FOXNewTableShape* pTableObj );

	// Constructor.
	FOXTableModel( FOXNewTableShape* pTableObj, const FOXTableModelRef& xSourceTable );

	// Destructor
	virtual ~FOXTableModel();

	// Initial
	void init( int nColumns, int nRows );

	// table shape pointer.
	FOXNewTableShape* getFOXNewTableShape() const { return mpTableObj; }

	// Create from
	void CreateFrom(FOXTableModel *pSrc );

	// optimize.
	void optimize();

	// merge.
    void merge( int nCol, int nRow, int nColSpan, int nRowSpan );

	virtual int getLeft();
	virtual int getTop();
	virtual int getRight();
	virtual int getBottom();

    virtual FOPCellCursor*  createCursor(  ) ;
    virtual FOPCellCursor*  createCursorByRange();
	virtual FOPCellCursor*  createCursorByRangeNew(int nLeft, int nTop, int nRight, int nBottom);

	// obtain row count.
    virtual int  getRowCount() ;

	// obtain column count.
    virtual int  getColumnCount() ;
	virtual BOOL getFOPCellPos( const FOPCellRef& xFOPCell, int& rnCol, int& rnRow ) const;
	virtual int  AddRef() { return 0; };

	virtual int  Release() { return 0; };
    virtual void  dispose(  ) ;
   
    virtual BOOL  isModified(  ) ;
    virtual void  setModified( BOOL bModified );

	// obtain columns.
 	virtual FOPRef<FOXTableColumns>  getColumns() ;

	// obtain rows.
    virtual FOPRef< FOXTableRows >  getRows() ;

 	virtual FOPCell *  getFOPCellByPosition( int nColumn, int nRow );
 	virtual FOPRef< FOPCellRange>  getFOPCellRangeByPosition( int nLeft, int nTop, int nRight, int nBottom );
 
	virtual void  lockBroadcasts() ;
	virtual void  unlockBroadcasts() ;

	virtual void Serialize(CArchive &ar);
	FOPRect	maLogicRect;
	CFOPNewTableCellList maCellsList;
	FOXTableRowList maRowList;
	FOXTableColumnList maColList;
public:

	// Notify modification.
	void notifyModification();

	// insert columns.
	void insertColumns( int nIndex, int nCount );

	// remove columns.
	void removeColumns( int nIndex, int nCount );

	// insert rows.
	void insertRows( int nIndex, int nCount );

	// remove rows.
	void removeRows( int nIndex, int nCount );

	int getRowCountImpl() const;
	int getColumnCountImpl() const;

	FOPCellRef createFOPCell();
	FOPCellRef getFOPCell( int nCol, int nRow ) const;

	void UndoInsertRows( int nIndex, int nCount );
	void UndoRemoveRows( int nIndex, FOXRowVector& aNewRows );

	void UndoInsertColumns( int nIndex, int nCount );
	void UndoRemoveColumns( int nIndex, FOXColumnVector& aNewCols, FOPCellVector& aFOPCells );

public:

    virtual void  disposing();

	FOXTableRowRef getRow( int nRow ) const;
	FOXTableColumnRef getColumn( int nColumn ) const;

    void updateRows();
    void updateColumns();

	FOXRowVector		maRows;
	FOXColumnVector	maColumns;

	FOXTableColumnsRef mxFOXTableColumns;
	FOXTableRowsRef mxFOXTableRows;

	FOXNewTableShape* mpTableObj;

	BOOL mbModified;
	BOOL mbNotifyPending;

	int mnNotifyLock;
};

typedef CTypedPtrList<CObList, FOXTableModel*> FOXTableModelList;

// -----------------------------------------------------------------------------
// FOXTableColumn
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableColumn : public CObject
{
	friend class FOXTableColumnUndo;
    friend class FOXTableModel;
public:

	// Constructor.
	FOXTableColumn( const FOXTableModelRef& xFOXTableModel, int nColumn );

	// Destructor.
	virtual ~FOXTableColumn();
	
	// Dispose.
	void dispose();
	void throwIfDisposed() const;
	
	FOXTableColumn& operator=( const FOXTableColumn& );

     virtual FOPCell*  getFOPCellByPosition( int nColumn, int nRow );
     virtual FOPRef< FOPCellRange >  getFOPCellRangeByPosition( int nLeft, int nTop, int nRight, int nBottom ) ;

	 // Obtain name.
	virtual CString  getName() ;

	// Change name.
	virtual void  setName( const CString& aName ) ;

	// Add reference.
	virtual int  AddRef() { return 0; };


	// Release.
	virtual int  Release() { return 0; };

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

public:
	
	FOXTableModelRef mxFOXTableModel;
	int		mnColumn;
	int		mnWidth;
	BOOL	mbOptimalWidth;
	BOOL	mbIsVisible;
	BOOL	mbIsStartOfNewPage;
	CString	maName;
};

// -----------------------------------------------------------------------------
// FOXTableRow
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableRow : public CObject
{
	friend class FOXTableModel;
	friend class FOXTableRowUndo;
public:
	FOXTableRow( const FOXTableModelRef& xFOXTableModel, int nRow, int nColumns );
	virtual ~FOXTableRow();
	
	void dispose();
	void throwIfDisposed() const ;
	
	FOXTableRow& operator=( const FOXTableRow& );
	
	// Insert columns.
	void insertColumns( int nIndex, int nCount, FOPCellVector::iterator* pIter = 0 );

	// remove columns
	void removeColumns( int nIndex, int nCount );
	

	// Obtain cell position.
     virtual FOPCell*  getFOPCellByPosition( int nColumn, int nRow );
     virtual FOPRef< FOPCellRange >  getFOPCellRangeByPosition( int nLeft, int nTop, int nRight, int nBottom );

	 // Store the data to the file.
	 virtual int  AddRef() { return 0; };

	virtual int  Release() { return 0; };
	 //-----------------------------------------------------------------------
	 // Summary:
	 // Serialize, Reads or writes this object from or to an archive.
	 // This member function is also a virtual function, you can Override it if you need,  
	 // Parameters:
	 //		&ar---Specifies a CArchive &ar object(Value).
	 virtual void Serialize(CArchive &ar);

	 // Obtain name.
	virtual CString  getName() ;

	// Change name.
	virtual void  setName( const CString& aName ) ;

public:
	
	FOXTableModelRef mxFOXTableModel;
	FOPCellVector	maFOPCells;
	int			mnRow;
	int			mnHeight;
	BOOL		mbOptimalHeight;
	BOOL		mbIsVisible;
	BOOL		mbIsStartOfNewPage;
	CString		maName;
};

// -----------------------------------------------------------------------------
// FOXTableColumns
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableColumns : public CObject
{
public:
	// Constructor
	FOXTableColumns( const FOXTableModelRef& xFOXTableModel );

	// Destructor.
	virtual ~FOXTableColumns();
	
	// Dispose.
	void dispose();
	void throwIfDisposed() const ;
	
	// insert by index.
	virtual void  insertByIndex( int nIndex, int nCount );

	// Remove by index.
    virtual void  removeByIndex( int nIndex, int nCount );
	
	// Obtain count.
    virtual int  getCount();

	// obtain row by index.
    virtual FOPRef< FOXTableColumn >  getByIndex( int Index ) ;

	// Add reference.
	virtual int  AddRef() { return 0; };

	// Release
	virtual int  Release() { return 0; };

	// Has elements or not.
    virtual BOOL  hasElements();
	
private:
	FOXTableModelRef	mxFOXTableModel;
};

// -----------------------------------------------------------------------------
// FOXTableRows
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableRows : public CObject
{
public:
	// Constructor
	FOXTableRows( const FOXTableModelRef& xFOXTableModel );

	// Destructor.
	virtual ~FOXTableRows();
	
	// Dispose.
	void dispose();
	void throwIfDisposed() const ;

	// insert by index.
	virtual void  insertByIndex( int nIndex, int nCount ) ;

	// remove by index.
    virtual void  removeByIndex( int nIndex, int nCount ) ;

	// obtain count.
    virtual int  getCount(  ) ;

	// Obtain row by index.
    virtual FOPRef< FOXTableRow >  getByIndex( int Index );

	// Add reference.
	virtual int  AddRef() { return 0; };

	// Release
	virtual int  Release() { return 0; };
  
	// Has elements or not.
    virtual BOOL  hasElements() ;
	
private:
	FOXTableModelRef	mxFOXTableModel;
};

// -----------------------------------------------------------------------------
// FOPCellRange
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOPCellRange : public CObject, public IFOPCellRange
{
public:

	// Constructor
	FOPCellRange( const FOXTableModelRef & xTable, int nLeft, int nTop, int nRight, int nBottom );

	// Destructor.
	virtual ~FOPCellRange();
	
	// Get left
	virtual int getLeft();
	virtual int getTop();
	virtual int getRight();
	virtual int getBottom();
	virtual int  AddRef() { return 0; };

	// Release
	virtual int  Release() { return 0; };
 	virtual FOPCell*  getFOPCellByPosition( int nColumn, int nRow );
    virtual FOPRef< FOPCellRange >  getFOPCellRangeByPosition( int nLeft, int nTop, int nRight, int nBottom );
	virtual FOPRef< FOXTableModel > getTable();
protected:
	FOXTableModelRef mxTable;
	int			mnLeft;
	int			mnTop;
	int			mnRight;
	int			mnBottom;
};


class FOXTableLayouter;

enum FOXTableHitKind
{
	FOXTABLEHIT_NONE,
		FOXTABLEHIT_FOPCELL,
		FOXTABLEHIT_FOPCELLTEXTAREA,
		FOXTABLEHIT_HORIZONTAL_BORDER,
		FOXTABLEHIT_VERTICAL_BORDER
};

//------------------------------------------------------------------------

struct FOPCellPos
{
	int mnCol;
	int mnRow;
	CPoint GetPoint() { return CPoint(mnRow, mnCol); }
	FOPCellPos() : mnCol( 0 ), mnRow( 0 ) {}
	FOPCellPos( int nCol, int nRow ) { mnCol = nCol; mnRow = nRow; }
	
	BOOL operator==( const FOPCellPos& r ) const { return (r.mnCol == mnCol) && (r.mnRow == mnRow); }
	BOOL operator!=( const FOPCellPos& r ) const { return (r.mnCol != mnCol) || (r.mnRow != mnRow); }
};

// -----------------------------------------------------------------------------
// FOPCellCursor
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOPCellCursor : public FOPCellRange
{
public:

	// Constructor.
	FOPCellCursor( const FOXTableModelRef& xFOXTableModel, int nLeft, int nTop, int nRight, int nBottom );

	// Destructor.
	virtual ~FOPCellCursor();
	
	// Obtain cell position.
	virtual FOPCell*  getFOPCellByPosition( int nColumn, int nRow );
    virtual FOPRef< FOPCellRange >  getFOPCellRangeByPosition( int nLeft, int nTop, int nRight, int nBottom );

	// Cell cursor.
    virtual void  gotoStart(  );
    virtual void  gotoEnd(  );
    virtual void  gotoNext(  );
    virtual void  gotoPrevious(  );
    virtual void  gotoOffset( int nColumnOffset, int nRowOffset );
	virtual int  AddRef() { return 0; };

	// Release
	virtual int  Release() { return 0; };
    virtual void  merge(  );
    virtual void  split( int Columns, int Rows );
    virtual BOOL  isMergeable(  );
    virtual BOOL  isUnmergeable(  );
	
protected:
	BOOL GetMergedSelection( FOPCellPos& rStart, FOPCellPos& rEnd );
	
	void split_column( int nCol, int nColumns, std::vector< int >& rLeftOvers );
	void split_horizontal( int nColumns );
	void split_row( int nRow, int nRows, std::vector< int >& rLeftOvers );
	void split_vertical( int nRows );
};

BOOL foxFindMergeOriginx( const FOXTableModelRef& xTable, int nMergedCol, int nMergedRow, int& rOriginCol, int& rOriginRow );

// -----------------------------------------------------------------------------
// FOXBorderLine
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXBorderLine
{
protected:
	COLORREF  aColor;
	int nOutWidth;
	int nInWidth;
	int nDistance;
	
public:
	FOXBorderLine( const COLORREF *pCol = 0, int nOut = 0, int nIn = 0, int nDist = 0 );
	FOXBorderLine( const FOXBorderLine& r );
	
	FOXBorderLine& operator=( const FOXBorderLine& r );
	
	const COLORREF&	GetColor() const { return aColor; }
	int 			GetOutWidth() const { return nOutWidth; }
	int 			GetInWidth() const { return nInWidth; }
	int 			GetDistance() const { return nDistance; }
	
	void 			SetColor( const COLORREF &rColor ) { aColor = rColor; }
	void			SetOutWidth( int nNew ) { nOutWidth = nNew; }
	void			SetInWidth( int nNew ) { nInWidth = nNew;  }
	void			SetDistance( int nNew ) { nDistance = nNew; }
	void			ScaleMetrics( long nMult, long nDiv );
	
	BOOL			operator==( const FOXBorderLine &rCmp ) const;

	BOOL			HasPriority( const FOXBorderLine& rOtherLine ) const;
	
	BOOL isEmpty() const { return (0 == nOutWidth && 0 == nInWidth && 0 == nDistance); }
	BOOL isDouble() const { return (0 != nOutWidth && 0 != nInWidth); }
	int getWidth() const { return nOutWidth + nInWidth + nDistance; }
};

typedef std::vector< FOXBorderLine* > FOXBorderLineVector;
typedef std::vector< FOXBorderLineVector > FOXBorderLineMap;

// -----------------------------------------------------------------------------
// FOXTableLayouter
// -----------------------------------------------------------------------------

class FO_EXT_CLASS FOXTableLayouter
{
public:
	// Constructor.
	FOXTableLayouter( const FOXTableModelRef& xFOXTableModel );

	// Destructor
	virtual ~FOXTableLayouter();

	// Layout table.
	void LayoutTable( FOPRect& rRectangle, BOOL bFitWidth, BOOL bFitHeight );

	// Update table border layout.
	void UpdateBorderLayout();

	// Obtain cell size.
	CSize getFOPCellSize( const FOPCellPos& rPos ) const;
	BOOL getFOPCellArea( const FOPCellRef& xFOPCell, FOPRect& rArea ) const;
	BOOL getFOPCellArea( const FOPCellPos& rPos, FOPRect& rArea ) const;


	// Obtain row count.
	int getRowCount() const { return static_cast< int >( maRows.size() ); }

	// Obtain column count.
	int getColumnCount() const { return static_cast< int >( maColumns.size() ); }

	// Obtain row height.
	int getRowHeight( int nRow );

	// Change row height.
	void setRowHeight( int nRow, int nHeight );

	// Obtain column width.
	int getColumnWidth( int nColumn );

	// Change column width.
	void setColumnWidth( int nColumn, int nWidth );

	// Obtain minimize column width.
	int getMinimumColumnWidth( int nColumn );

	// Obtain column start.
	int getColumnStart( int nColumn ) const;
	int getRowStart( int nRow ) const;

	BOOL isEdgeVisible( int nEdgeX, int nEdgeY, BOOL bHorizontal ) const;

	FOXBorderLine* getBorderLine( int nEdgeX, int nEdgeY, BOOL bHorizontal )const;

	void updateFOPCells( FOPRect& rRectangle );

	int getHorizontalEdge( int nEdgeY, int* pnMin = 0, int* pnMax = 0 );
	int getVerticalEdge( int nEdgeX , int* pnMin = 0, int* pnMax = 0);

	// Distribute columns.
	void DistributeColumns( FOPRect& rArea, int nFirstCol, int nLastCol );

	// Distribute rows.
	void DistributeRows( FOPRect& rArea, int nFirstRow, int nLastRow );

	// Clone range of cells.
	FOXNewTableShape* CloneRange( const FOPCellPos& rStartPos, const FOPCellPos& rEndPos );

public:

	// Obtain cell reference.
	FOPCellRef getFOPCell( const FOPCellPos& rPos ) const;

	// Layout table width.
	void LayoutTableWidth( FOPRect& rArea, BOOL bFit );

	// Layout table height.
	void LayoutTableHeight( FOPRect& rArea, BOOL bFit );

	inline BOOL isValidColumn( int nColumn ) const { return (nColumn >= 0) && (nColumn < static_cast<int>( maColumns.size())); }
	inline BOOL isValidRow( int nRow ) const { return (nRow >= 0) && (nRow < static_cast<int>( maRows.size())); }
	inline BOOL isValid( const FOPCellPos& rPos ) const { return isValidColumn( rPos.mnCol ) && isValidRow( rPos.mnRow ); }

	// Clear border layout.
	void ClearBorderLayout();

	// Clear border layout.
	void ClearBorderLayout(FOXBorderLineMap& rMap);

	// Resize border layout.
	void ResizeBorderLayout();

	// Resize border layout.
	void ResizeBorderLayout( FOXBorderLineMap& rMap );

	// Set border.
	void SetBorder( int nCol, int nRow, BOOL bHorizontal, const FOXBorderLine* pLine );

	// Has priority or not.
	static BOOL HasPriority( const FOXBorderLine* pThis, const FOXBorderLine* pOther );

	struct Layout
	{
		int mnPos;
		int mnSize;
		int mnMinSize;

		Layout() : mnPos( 0 ), mnSize( 0 ), mnMinSize( 0 ) {}
		void clear() { mnPos = 0; mnSize = 0; mnMinSize = 0; } 
	};
	typedef std::vector< Layout > LayoutVector;

	// Distribute this table.
	int distribute( LayoutVector& rLayouts, int nDistribute );

	FOXTableModelRef mxTable;
	LayoutVector	maRows;
	LayoutVector	maColumns;

	FOXBorderLineMap maHorizontalBorders;
	FOXBorderLineMap maVerticalBorders;
	const CString	msSize;
};

/////////////////////////////////////////////////////////////
// Property IDs define.

#define ID_PROP_USEFIRSTROW                        7000
#define ID_PROP_USELASTROW                         7001
#define ID_PROP_USEFIRSTCOLUMN                     7002
#define ID_PROP_USELASTCOLUMN                      7003
#define ID_PROP_USEROWBANDING                      7004
#define ID_PROP_USECOLUMNBANDING                   7005
#define ID_PROP_FIRSTROW                           7006
#define ID_PROP_LASTROW                            7007
#define ID_PROP_FIRSTCOLUMN                        7008
#define ID_PROP_LASTCOLUMN                         7009
#define ID_PROP_ROWBANDING                         7010
#define ID_PROP_COLUMNBANDING                      7011
#define ID_PROP_ROWBANDING2                         7012
#define ID_PROP_COLUMNBANDING2                      7013
#define ID_PROP_TABLEBODY							7014

class FO_EXT_CLASS FOXTableTemplate : public CObject
{
	DECLARE_SERIAL(FOXTableTemplate)

// Construction/Destruction
public:

	// Constructor with ID.
	FOXTableTemplate(int nCurID = FO_CUSTOM_PROP_ID);
	
	// Copy constructor. 
	FOXTableTemplate(const FOXTableTemplate& propShape);
	
	// Destructor. 
	virtual ~FOXTableTemplate();

	// Put value.
	virtual BOOL PutValue(const int &nPropId,const FO_VALUE &Value);
	
	// Obtain the backup of this properties values.
	virtual void DoBackUp(CObject* pProp);
	
	// Get value.
	virtual BOOL GetValue(FO_VALUE &Value,const int &nPropId);

	// Create a copy of current object.
	virtual CObject* Copy();

public:
	
	// Return UseFirstRow value.
	BOOL GetUseFirstRow() const { return m_bUseFirstRow;}

	// Change UseFirstRow value.
	void SetUseFirstRow( const BOOL &bValue ) {m_bUseFirstRow = bValue; }

	// Return UseLastRow value.
	BOOL GetUseLastRow() const { return m_bUseLastRow;}

	// Change UseLastRow value.
	void SetUseLastRow( const BOOL &bValue ) {m_bUseLastRow = bValue; }

	// Return UseFirstColumn value.
	BOOL GetUseFirstColumn() const { return m_bUseFirstColumn;}

	// Change UseFirstColumn value.
	void SetUseFirstColumn( const BOOL &bValue ) {m_bUseFirstColumn = bValue; }

	// Return UseLastColumn value.
	BOOL GetUseLastColumn() const { return m_bUseLastColumn;}

	// Change UseLastColumn value.
	void SetUseLastColumn( const BOOL &bValue ) {m_bUseLastColumn = bValue; }

	// Return UseRowBanding value.
	BOOL GetUseRowBanding() const { return m_bUseRowBanding;}

	// Change UseRowBanding value.
	void SetUseRowBanding( const BOOL &bValue ) {m_bUseRowBanding = bValue; }

	// Return UseColumnBanding value.
	BOOL GetUseColumnBanding() const { return m_bUseColumnBanding;}

	// Change UseColumnBanding value.
	void SetUseColumnBanding( const BOOL &bValue ) {m_bUseColumnBanding = bValue; }

	// Return FirstRow value.
	COLORREF GetFirstRow() const { return m_crFirstRow;}

	// Change FirstRow value.
	void SetFirstRow( const COLORREF &crValue ) {m_crFirstRow = crValue; }

	// Return LastRow value.
	COLORREF GetLastRow() const { return m_crLastRow;}

	// Change LastRow value.
	void SetLastRow( const COLORREF &crValue ) {m_crLastRow = crValue; }

	// Return FirstColumn value.
	COLORREF GetFirstColumn() const { return m_crFirstColumn;}

	// Change FirstColumn value.
	void SetFirstColumn( const COLORREF &crValue ) {m_crFirstColumn = crValue; }

	// Return LastColumn value.
	COLORREF GetLastColumn() const { return m_crLastColumn;}

	// Change LastColumn value.
	void SetLastColumn( const COLORREF &crValue ) {m_crLastColumn = crValue; }

	// Return RowBanding value.
	COLORREF GetRowBanding() const { return m_crRowBanding;}

	// Change RowBanding value.
	void SetRowBanding( const COLORREF &crValue ) {m_crRowBanding = crValue; }

	// Return ColumnBanding value.
	COLORREF GetColumnBanding() const { return m_crColumnBanding;}

	// Change ColumnBanding value.
	void SetColumnBanding( const COLORREF &crValue ) {m_crColumnBanding = crValue; }

// Attributes
public:
	// FODO:Add your properties items below.
	// UseFirstRow value.
	BOOL                              m_bUseFirstRow;

	// UseLastRow value.
	BOOL                              m_bUseLastRow;

	// UseFirstColumn value.
	BOOL                              m_bUseFirstColumn;

	// UseLastColumn value.
	BOOL                              m_bUseLastColumn;

	// UseRowBanding value.
	BOOL                              m_bUseRowBanding;

	// UseColumnBanding value.
	BOOL                              m_bUseColumnBanding;

	// FirstRow value.
	COLORREF                          m_crFirstRow;

	// LastRow value.
	COLORREF                          m_crLastRow;

	// FirstColumn value.
	COLORREF                          m_crFirstColumn;

	// LastColumn value.
	COLORREF                          m_crLastColumn;

	// RowBanding value.
	COLORREF                          m_crRowBanding;

	// ColumnBanding value.
	COLORREF                          m_crColumnBanding;


	// RowBanding value.
	COLORREF                          m_crRowBanding2;
	
	// ColumnBanding value.
	COLORREF                          m_crColumnBanding2;

	COLORREF						  m_crBodyStyle;
public:
	
	// Sets this set of font properties equal to another. 
	FOXTableTemplate& operator=(const FOXTableTemplate& propEdit);

	// Is equal.
	virtual BOOL IsEqual(CObject* prop);

	// Determines if another set of fill properties is equal to this one. 
	BOOL operator==(const FOXTableTemplate propEdit) const;

	// Serialize data to file. 
	virtual void Serialize(CArchive& ar);

// Implementation
public:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

inline CObject* FOXTableTemplate::Copy()
{
	return new FOXTableTemplate(*this);
}

// -----------------------------------------------------------------------------
// FOXNewTableShape
// -----------------------------------------------------------------------------

class FOXNewTableShapeImpl;
class FO_EXT_CLASS FOXNewTableShape : public CFORectShape  
{
	friend class FOPCell;
	friend class FOXNewTableShapeImpl;
protected:
	DECLARE_SERIAL(FOXNewTableShape);
public:

	// constructor
	FOXNewTableShape();

	// Copy constructor.
	FOXNewTableShape(const FOXNewTableShape& src);

	// Destructor.
	virtual ~FOXNewTableShape();

	// Creates the shape and initializes the data members.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPTableShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nRow---&nRow, Specifies A integer value.  
	//		&nCol---&nCol, Specifies A integer value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the shape and initializes the data members.
	// rcPos -- position of this shape.
	// nRow -- rows of table.
	// nCol -- columns of table.
	// strCaption -- caption
	virtual void Create(CRect &rcPos,const int &nRow, const int &nCol,CString strCaption = _T(""));
	
public:
	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// For checking the editing label.
	virtual BOOL DoHitEditLabel(const CPoint &ptHit);

	// For checking the editing label.
	virtual BOOL DoAutoEditLabel(CFOPNewTableCell *pCell);

	// Do auto text editing.
	BOOL DoAutoTextEdit();
	
	// Select cells within rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Within, Call this function to select the given item.
	// Parameters:
	//		&rc---Specifies A CRect type value.
	void SelectWithin(const CRect &rc);

	// Update shape caption.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shape Caption, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual BOOL UpdateShapeCaption(const CString &strNew);
	
	// Generate the editing label text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GenEditingLabel();

	// Current Edit Cell, This member maintains a pointer to the object FOPGridCell.  
	CFOPNewTableCell *		m_pCurEditCell;
 
	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

	// set changed.
	virtual void SetChanged();

	// Assignment operator.
	FOXNewTableShape& operator=(const FOXNewTableShape& src);

	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//Generate Shape Area
	virtual void GeometryUpdated(CFOArea* pRgn);

	// Obtain the composite of the shape.
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Re calc extend bound rectangle,override this method to calc the extend bound rectangle of the shape
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

	// Get normal spot count.
	virtual int GetNormalSpotCount() const;

	// Get plus spot count.
	virtual int GetPlusSpotCount() const;
	
	// Get the sport point of control by drag handle,calc the normal 8 control handles.
	// mpSpot -- result control handle list
	virtual void GetNormalSpotLocation(CFOPHandleList& lstHandle);

	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// mpSpot -- result of the spot.
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Get rotate handle location,override this method to calc the new rotating control handle.
	// ptHandle -- result rotating control handle.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Get the rotating angle,override this method to drawing new rotating angle text.
	virtual int	GetRotateAngle() const;

	// Calc the label start position.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Offset all points,call this method to moving the shape.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);
	
	
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Draw borders of the table cells
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Borders, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		painter---Specifies A integer value.  
	//		&crect---Specifies A CRect type value.
    void OnDrawBorders( CDC* pDC, const FOPRect &crect);

	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Editing Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual DWORD GenEditingLabelAlign();
	
	// Generate the editing label text align.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Label Alignment, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GenLabelAlign();
	
	// Return With Label Editing value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get With Label Editing, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL GetWithLabelEditing();

	// Apply table style.
	virtual BOOL ApplyCellStyles(FOXTableTemplate *pStyle);

	//-----------------------------------------------------------------------
	// Summary:
	// Update Saving, Call this member function to update the object.
	
	void UpdateSaving();
	
	// Restore saving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Saving, .
	
	void RestoreSaving();
	
	// Update value with variable.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Variable, Call this member function to update the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL UpdateVar();
	
	// Update value with variable.
	void UpdateVar(const CString &strVar, const CString &strValue);

	// do flash timer.
	virtual void OnFlashTimer(UINT_PTR nTimerID);
	
	// Update the whole shape, this method will call the InvalidateShape within the
	// CFOPCanvasCore to update this shape within the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update , Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateFlashCell(CFOPNewTableCell *pCell);
	
	// start flash timer.
	void StartFlashCell(CFOPNewTableCell *pCell);

	public:
		// Update saving with all the labels of cells.
		// Add svg text
		virtual void		  SVG_AddText(CString &outputStringL);
		
	public:
	// Export to SVG
	virtual void ExportToSVG(CStdioFile*);

	// Obtain virtual font object.
	virtual CFont *GetVirFont();

	// Scale shape.
	// dX -- x scale of shape.
	// dY -- y scale of shape.
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scales the shape about its center to the size specified. 
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);

public:

	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Do draw visio like bounding selection line.
	// pDC -- pointer of the DC.
	virtual void DoDrawVisioOrderLine(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:
	const FOXTableLayouter& getFOXTableLayouter() const;
	FOXNewTableShape* CloneRange( const FOPCellPos& rStartPos, const FOPCellPos& rEndPos );
	void DistributeColumns( int nFirstColumn, int nLastColumn );
	void DistributeRows( int nFirstRow, int nLastRow );
	FOPRef< FOXTableModel > getTable() const;
	BOOL isValid( const FOPCellPos& rPos ) const;

	// Obtain cell position.
	FOPCellPos getFirstFOPCell() const;
	FOPCellPos getLastFOPCell() const;
	FOPCellPos getLeftFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getRightFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel  ) const;
	FOPCellPos getUpFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getDownFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getPreviousFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getNextFOPCell( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getPreviousRow( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	FOPCellPos getNextRow( const FOPCellPos& rPos, BOOL bEdgeTravel ) const;
	
	// Obtain selected cells.
	void getSelectedFOPCells( FOPCellPos& rFirstPos, FOPCellPos& rLastPos, BOOL bSelect = FALSE);
	void setSelectedFOPCells( const FOPCellPos& rFirstPos, const FOPCellPos& rLastPos );
	void setSelectedFOPCells2( const FOPCellPos& rFirstPos, const FOPCellPos& rLastPos );
	void checkFOPCell( FOPCellPos& rPos );

	// Create cells.
	void createFOPCell( FOPCellRef& xFOPCell );
	virtual FOXTableModel* GetTableKeyData();
	virtual void SetTableKeyData(FOXTableModel* aTable);

	// Check table hit.
	FOXTableHitKind CheckTableHit( const FOPPoint& rPos, int& rnX, int& rnY, int nTol );

	void GetSelPos(int &nRow, int &nCol);

	// lock
	void uno_lock();

	// Unlock
	void uno_unlock();
	// Select cells within rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Maximize Select Rectangle, .
	//		Returns a CRect type value.  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	CRect MaxSelectRect(const CRect &rc);

	// Obtain maximize select rectangle.
	CRect GetMaxSelectRect();

	// Obtain maximize cells rectangle.
	CRect GetMaxCellsRect();

	// Update row and column
	void UpdateRowCol();

	// obtain the pointer of cell.
	FOPCell* getActiveFOPCell() const;
	
	// set active cell.
	void setActiveFOPCell( const FOPCellPos& rPos );

	// get active cell.
	void getActiveFOPCellPos( FOPCellPos& rPos ) const;
	
	// get row count.
	int getRowCount() const;

	// get column count.
	int getColumnCount() const;
	
	// Obtain cell bounding rectangle.
	void getFOPCellBounds( const FOPCellPos& rPos, FOPRect& rFOPCellRect );
	virtual BOOL AdjustTextFrameWidthAndHeight(FOPRect& rR, BOOL bHgt=TRUE, BOOL bWdt=TRUE) const;
	virtual BOOL AdjustTextFrameWidthAndHeight(BOOL bHgt=TRUE, BOOL bWdt=TRUE);
	virtual void NbcSetLogicRect(const FOPRect& rRect);
	virtual void AdjustToMaxRect( const FOPRect& rMaxRect, BOOL bShrinkOnly = false );

	// Insert rows.
	void InsertRows( int nIndex, int nCount = 1 );

	// Insert columns.
	void InsertColumns( int nIndex, int nCount = 1 );

	// Delete rows.
	void DeleteRows( int nIndex, int nCount = 1 );

	// Delete columns.
	void DeleteColumns( int nIndex, int nCount = 1 );

	// get text count.
	virtual int getTextCount() const;
	
	// Set active text.
	virtual void setActiveText( int nIndex );
	
	// Check text hit.
	virtual int CheckTextHit(const FOPPoint& rPnt);

	// Do drag row edge.
	virtual void DragRowEdge(int nEdge, int nOffsetY);

	// Do drag column edge.
	virtual void DragColEdge(int nEdge, int nOffsetX);

	// Has text or not
    virtual BOOL HasText() const;

	// Update edit box font.
	virtual void UpdateEditBoxFont(CFOPCanvasCore* pView, CFont *pFont);

	// Update selections.
	void UpdateSels();

	// Paste object.
	BOOL PasteObject( FOXNewTableShape* pPasteTableObj );
	virtual BOOL IsAutoGrowHeight() const;
	long GetMinTextFrameHeight() const;
	long GetMaxTextFrameHeight() const;
	virtual BOOL IsAutoGrowWidth() const;
	long GetMinTextFrameWidth() const;
	long GetMaxTextFrameWidth() const;
	virtual void onSelectionHasChanged();
	BOOL hasSelectedCells();

	// Insert.
	void onInsert(int nSId, BOOL bAfter, int nCount);
	void StartSelection( const FOPCellPos& rPos );
	void UpdateSelection( const FOPCellPos& rPos );
	void UpdateSelection2( const FOPCellPos& rPos );

	// Remove selection.
     void RemoveSelection();

	 // Clear selection.
	 void clearSelection();

	 // Select all.
	void selectAll();

	// Do same height.
	void DoSaveRowHeight(const int &nHeight);
	
	// On delete
	void onDelete( int nSId );

	// On select.
     void onSelect( int nSId );

	 // Merge marked cells.
	void MergeMarkedCells();

	// Split marked cells.
	void SplitMarkedCells(BOOL bHorz, int nTotalSplit = 2);

	// Merge table cells.
	void MergeRange( int nFirstCol, int nFirstRow, int nLastCol, int nLastRow );

	// Insert row column
	void InsertRowCol(const int &nCol, const int &nRow, const int &nNumber, 
		const BOOL &bInsertRow = TRUE);

	// Delete row column.
	void DeleteRowCol(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const BOOL &bDelRow = TRUE);

	// Change cells back color.
	void ChangeCellBackColor(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const COLORREF &crBack);

	// Change cells pattern color.
	void ChangeCellPatternColor(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const COLORREF &crPattern);

	// Change cells back color.
	void ChangeCellFillType(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const int &nFill);

	// Change cells back color.
	void ChangeCellFontSize(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const int &nFontSize);

	// Change cells back color.
	void ChangeCellTextHAlign(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const int &nAlign);

	// Change cells back color.
	void ChangeCellTextVAlign(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const int &nAlign);

	// Change cells back color.
	void ChangeCellTextEditing(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const BOOL &bAllow);

	// Change cells back color.
	void ChangeCellFontColor(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const COLORREF &crFont);

	// Change cells back color.
	void ChangeCellFontFaceName(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const CString &strFont);

	// Change cells back color.
	void ChangeCellFontBold(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const BOOL &bBold);

	// Change cells back color.
	void ChangeCellFontItalic(int nFirstCol, int nFirstRow, int nLastCol, int nLastRow,
		const BOOL &bItalic);

	CString GetCellText(int nCol, int nRow);

	void SetCellText(int nCol, int nRow, const CString &strText);
	void SetCellBkColor(int nCol, int nRow, COLORREF crBack);
	void SetCellFontColor(int nCol, int nRow, COLORREF crText);
	COLORREF GetCellBkColor(int nCol, int nRow);

	CString GetChoiceText(int nCol, int nRow);
	void SetChoiceText(int nCol, int nRow, const CString &strText);

	void SetCellImage(int nCol, int nRow, const CString &strImage);

	// Distribute columns.
	void DistributeColumns();

	// Distribute rows.
	void DistributeRows();

	// goto cell.
	 void gotoFOPCell( const FOPCellPos& rCell, BOOL bSelect, int xvs);

	 // Delete marked cells.
	virtual BOOL DeleteMarked();
	BOOL checkTableObject();

	// Update table object.
     BOOL updateTableObject();

	 // Execute action.
	 BOOL executeAction( UINT nAction, BOOL bSelect);

	 // Obtain selection end position.
	 const FOPCellPos& getSelectionEnd();

	 // Obtain selection start position.
	 const FOPCellPos& getSelectionStart();

	 // Set selection start position.
	 void setSelectionStart( const FOPCellPos& rPos );

	 // Obtain selection cursor.
	 FOPRef< FOPCellCursor > getSelectionCursor();

	 // find merged origin
	 void findMergeOrigin( FOPCellPos& rPos );

	 // Reset all section.
	 void ResetAllSelection();

	 // select row.
	 BOOL selectRow( int row );

	 // select column
	 BOOL selectColumn( int column );

	 // deselect row.
	 BOOL deselectRow( int row );

	 // Deselect column
	 BOOL deselectColumn( int column );

	 // Is row selected or not.
	 BOOL isRowSelected( int nRow );

	 // Is column selected or not.
	 BOOL isColumnSelected( int nColumn );

	 // Is row header
	 BOOL isRowHeader();

	 // Is column header
	BOOL isColumnHeader();

	// Justify rectangle.
	void ImpJustifyRect(FOPRect& rRect) const;

	// Obtain logic rectangle.
	virtual const FOPRect& GetLogicRect() const;

	// Adjust text frame width and height.
	virtual BOOL NbcAdjustTextFrameWidthAndHeight(BOOL bHgt=TRUE, BOOL bWdt=TRUE);

	// First cell cursor.
	FOPCellPos maCursorFirstPos;

	// Last cell position cursor.
	FOPCellPos maCursorLastPos;

	// Cell select mode
	BOOL mbCellSelectionMode;

	// Mouse down position
	FOPCellPos maMouseDownPos;

	// Left button down
	BOOL mbLeftButtonDown;

	//
	BOOL m_bHorzGrid;

	BOOL m_bVertGrid;

	// returns the number of rows
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rows, Returns the specified value.
	//		Returns a int type value.
    int GetRows() const;
	
    // returns the number of columns
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Columns, Returns the specified value.
	//		Returns a int type value.
    int GetColumns() const;

	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		row---Specifies A integer value.  
	//		column---Specifies A integer value.
	// Cell at a specify row and column
    CFOPNewTableCell *cell( unsigned int row, unsigned int column ) const;

    // Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);
	
protected:
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

public:
	// Hit test Row header to select on row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Row Header, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestRowHeader(const CPoint &ptHit, int &nHitIndex);
    
	// Hit test Row.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Row, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestRow(const CPoint &ptHit, int &nHitIndex);

	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
    virtual CFOPNewTableCell *HitTestGridSmall(CPoint pt);
    
	// Hit text grid
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Grid, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
    virtual CFOPNewTableCell *HitTestGrid(CPoint pt);

	// Obtain current cell's pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Cell, Returns the specified value.
	//		Returns a pointer to the object CFOPTableCell ,or NULL if the call failed
	CFOPNewTableCell *GetCurrentCell();

	// Get all the selected cells within the table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Cells, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pSelectList---Select List, A pointer to the CFOPTableCellList  or NULL if the call failed.
	virtual void GetSelectCells(CFOPNewTableCellList *pSelectList);


    // Calculate the absolute size of the complete table.
    //  From the first cell to the last, including page breaks et.
    //  return CRect which outlines the whole of the table.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Inside Rectangle, Returns the specified value.
	//		Returns a CRect type value.
    CRect GetInsideRect();
    
	// Hit test column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Column, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestColumn(const CPoint &ptHit, int &nHitIndex);
	
	// Hit test column to select one column.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Column Header, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitIndex---Hit Index, Specifies A integer value.
	BOOL HitTestColumnHeader(const CPoint &ptHit, int &nHitIndex);

	// Current Hit, This member maintains a pointer to the object CFOPTableCell.  
	CFOPNewTableCell *	m_pCurHit;

	// Obtain cell by position.
	FOPCellRef getFOPCell( const FOPCellPos& rPos ) const;

public:
	void init( int nColumns, int nRows );

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Obtain logic rectangle.
	FOPRect				maLogicRect;

	// Table data model implement.
	FOXNewTableShapeImpl*	mpImpl;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOXNEWTABLESHAPE_H__FF56DBBC_09AE_4577_AAD8_FD1832DA43A0__INCLUDED_)
