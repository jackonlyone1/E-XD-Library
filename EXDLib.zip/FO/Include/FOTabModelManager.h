//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOTABMODELMANAGER_H__1E4323A4_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
#define AFC_FOTABMODELMANAGER_H__1E4323A4_F9E3_11D5_A4DE_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOTabPageModel.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOTabModelManager
//
// This class is defined for VisioApp sample style application,it is the manager of
// all the data models.
// 
// call InsertTab(..) method to add a new data model.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOTabModelManager class derived from CObject
//      F O Tab Model Manager
//===========================================================================

class FO_EXT_CLASS CFOTabModelManager : public CObject
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOTabModelManager---F O Tab Model Manager, Specifies a E-XD++ CFOTabModelManager object (Value).
	DECLARE_SERIAL(CFOTabModelManager);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tab Model Manager, Constructs a CFOTabModelManager object.
	//		Returns A  value (Object).
	CFOTabModelManager();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tab Model Manager, Destructor of class CFOTabModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOTabModelManager();

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Attach observer wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Observer, Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*---A pointer to the CFOObserver  or NULL if the call failed.
	virtual void AttachObserver( CFOObserver * );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach observer wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*---A pointer to the CFOObserver  or NULL if the call failed.
	virtual void DetachObserver( CFOObserver * );

	//-----------------------------------------------------------------------
	// Summary:
	// Notify observer wnd.
	// lHint -- notify hint.
	// pHint -- pointer of the notify object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Notify Observer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual void NotifyObserver(LPARAM lHint, CObject*pHint = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Remove all observer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Observer, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllObserver();

public:

	// Array of tabs.
 
	// Tabs, This member specify CObArray object.  
	CObArray    m_arTabs;

public:

	// Only serialize tabs.
	void SerializeTabs(CArchive &ar);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Save data to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document from a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// get pointer of file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);

	// release file form memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Clear all data of memory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Content, Reset the content and clear all the data of this data model.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetContent();

public:

	// set modified flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modified Flag, Sets a specify value to current class CFOTabModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModified---bModified, Specifies A Boolean value.
	virtual void		SetModifiedFlag(BOOL bModified = TRUE);

	// Is Modified.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		IsModified();

	// Count of tabs.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetTabCount() const { return m_nTabs; }

	// Current tab index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Tab, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetCurrentTab() const { return m_nCurrent; }

	// Set current tab index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Tab, Sets a specify value to current class CFOTabModelManager
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	virtual void		SetCurrentTab(const int &nIndex) { m_nCurrent = nIndex; }

	// Clear all data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		ClearAll();

	// Get count of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int			GetShapesCount();

	// Delete a tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Tab, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void		DeleteTab(int nTab);

	// Delete a tab.
	
	//-----------------------------------------------------------------------
	// Summary: For right context menu delete.
	// Delete Tab, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void		DeleteTabNew(const CString &strTab);
	// Delete a tab.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Tab2, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	virtual void		DeleteTab2(int nTab);

	// Rebuild all the property index of all tab pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild All Property Index, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void		RebuildAllPropIndex();

	

	// Insert a new tab.
	// szLabel -- label of tab sheet.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tab, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		szLabel---szLabel, Specifies A CString type value.
	virtual CFOTabPageModel* InsertTab(CString szLabel = _T(""));

	// Insert a new tab.
	// pModel -- a pointer to a new tab page model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Tab, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		CFOTabPageModel*pModel---F O Tab Page Model*p Model, A pointer to the CFOTabPageModel or NULL if the call failed.
	virtual CFOTabPageModel* InsertTab(CFOTabPageModel*pModel);

	// Get tab info.
	// nTab -- a specify tab index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab, Returns the specified value.
	//		Returns A E-XD++ CFOTabPageModel& value (Object).  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabPageModel&	GetTab(int nTab);

	// Get tab info.
	// nTab -- a specify tab index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Tab Pointer, Returns the specified value.
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		nTab---nTab, Specifies A integer value.
	CFOTabPageModel*	GetTabPtr(int nTab);

	// find the caption of a model
	// strCap -- the caption of page model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual BOOL		FindModelCaption(CString strCap);

	// find the caption of a model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model With Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual CFOTabPageModel*	FindModelWithCaption(CString strCap);

	// find a model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual CFOTabPageModel* FindModel(CString strCap);

	// find a model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel,or NULL if the call failed  
	// Parameters:
	//		strCap---strCap, Specifies A CString type value.
	virtual int FindModelWith(CString strCap);

	// get unique caption of a page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Unique Page Caption, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString		GetUniquePageCaption();

	// Alloc model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Model,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOTabPageModel ,or NULL if the call failed
	virtual CFOTabPageModel *AllocModel() const;

	// Obtain the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Print Pages, Returns the specified value.
	//		Returns a int type value.
	int GetTotalPrintPages() const { return m_nTotalPrintPages; }

	// Change total print pages,this is only defined for creating the output string on the Header or the Footer
	// of the print page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Total Print Pages, Sets a specify value to current class CFOTabModelManager
	// Parameters:
	//		&nTotal---&nTotal, Specifies A integer value.
	void	SetTotalPrintPages( const int &nTotal)	{ m_nTotalPrintPages = nTotal; }

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// The list pointer of parent wnd.
 
	// Observer List, This member specify CPtrList object.  
	CPtrList	m_ObserverList;	
	
	// Modified flag.
 
	// Modified, This member sets TRUE if it is right.  
	BOOL		m_bModified;			
	
	// count of tabs
 
	// Tabs, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nTabs;                
	
	// current tab index.
 
	// Current, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nCurrent;             
	
	// First Visible Tab
 
	// First Tab, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int         m_nFirstTab;            

	// Total print pages.
 
	// Total Print Pages, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nTotalPrintPages;

};


#endif // !defined(AFC_FOTABMODELMANAGER_H__1E4323A4_F9E3_11D5_A4DE_525400EA266C__INCLUDED_)
