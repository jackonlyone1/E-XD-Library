//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FODRAWPORTSSHAPE_H__0B388BF0_DD8A_11D5_A4AB_525400EA266C__INCLUDED_)
#define AFC_FODRAWPORTSSHAPE_H__0B388BF0_DD8A_11D5_A4AB_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "FOPortShape.h"


class CFOLinkShape;
class CFOBaseEndObject;

// Map for shape
typedef CMap<CFODrawShape*,CFODrawShape*,BOOL,BOOL> CFODrawShapeMap;

/////////////////////////////////////////////////////////////////////////
// CFODrawPortsShape
//
// This is the base class for shapes that can be connected,
// all the ports are stored within a list,you can call CreateDefaultPort(..)
// multiple times to create as many ports as you want.
//
//------------------------------------------------------

 
//===========================================================================
// Summary:
//     The CFODrawPortsShape class derived from CFODrawShape
//      F O Draw Ports Shape
//===========================================================================

class FO_EXT_CLASS CFODrawPortsShape : public CFODrawShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFODrawPortsShape---F O Draw Ports Shape, Specifies a E-XD++ CFODrawPortsShape object (Value).
	DECLARE_SERIAL(CFODrawPortsShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Ports Shape, Constructs a CFODrawPortsShape object.
	//		Returns A  value (Object).
	CFODrawPortsShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Ports Shape, Constructs a CFODrawPortsShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFODrawPortsShape& src object(Value).
	CFODrawPortsShape(const CFODrawPortsShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Ports Shape, Destructor of class CFODrawPortsShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawPortsShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Create ports shape.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFODrawPortsShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFODrawPortsShape& src object(Value).
	CFODrawPortsShape& operator=(const CFODrawPortsShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

public:


	// Obtain all ports' centers.
	virtual BOOL GetAllPortsCenters(CArray <CPoint, CPoint> &aryPts);
	
	// Is all ports linked.
	BOOL IsAllPortsLinked();

	// Obtain the input port from index.
	virtual CFOPortShape* InPort(const int& nIndex);

	// Obtain the output port by index.
	virtual CFOPortShape* OutPort(const int& nIndex);

	// Obtain the input port.
	virtual CFOPortShape *GetIn();

	// Obtain the output.
	virtual CFOPortShape *GetOut();

	// Obtain the total of input ports.
	virtual int GetTotalIn();
	
	// Obtain the total of output ports
	virtual int GetTotalOut();

	// Obtain input value.
	virtual double InValue(const int &nIndex);

	// Change input value.
	virtual void SetInVal(const double &dValue);

	// Change input value by index.
	virtual void SetInVal2(const int &nIndex, const double &dValue);

	// Change Output value.
	virtual void SetOutVal(const double &dValue);
	
	// Change output value by index
	virtual void SetOutVal2(const int &nIndex, const double &dValue);
	
	// Generate Shape Area
	// pArea -- point of the area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Check if it is the from port or to port. 0 - no,1- from,2 - to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Form, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CheckForm();

	// Update all port position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reposition Ports, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RepositionPorts();

	// Update all port to new position.
	// rcOld -- the exist old position that contains the ports.
	// rcNewPos -- the new position that will contain the ports
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reposition Ports New, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcOld---&rcOld, Specifies A CRect type value.  
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void RepositionPortsNew(const CRect &rcOld,const CRect &rcNewPos);

	// Re calculate extend bound rectangle.
	// rcBound -- bounding rectangle that is generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Extend Bound Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcBound---&rcBound, Specifies A CRect type value.
	virtual void CalcExtendBoundRect(CRect &rcBound) const;

	// Obtain the ports max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Maximize Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPortsMaxBoundRect() const;

	// Generate all ports indexs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Ports Indexs, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void GenPortsIndexs();

	// Obtain the port pointer by index.
	// nIndex -- index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port By Index, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	CFOPortShape *GetPortByIndex(const int &nIndex);

	// build Index for properties
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Index For Property, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildIndexForProp();

	// Hide all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide All Ports, Hides the objects by removing it from the display screen. 

	void HideAllPorts();

	// Update property cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cache Properties, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CacheProperties();

	// pCanvas -- pointer of canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFODrawPortsShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCanvas---*pCanvas, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pCanvas);


	// Obtain port at side.
	int PortAtSide(CFOPortShape *pPort);

protected:
	// Build all the default ports,these default ports is defined within method GenerateDefaultPorts (class CFOPVisualProxy),
	// You can change it's value,by override method GenerateDefaultPorts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build All Default Ports, .

	void BuildAllDefaultPorts();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Is shape linked.
	// pShape -- pointer of shape for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Linked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	BOOL IsShapeLinked(CFODrawPortsShape *pShape);

	// Change the pointer of the data model
	// pNewModel -- pointer of data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFODrawPortsShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFODataModel or NULL if the call failed.
	virtual void SetModel(CFODataModel* pNewModel);

	// Layout all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Ports, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void LayoutPorts();

public:

	//Draw flat status.

	// Draws custom tracker.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the flat status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Draws all connect ports.
	// pDC -- pointer of DC.
	// bDraw -- drawing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Ports, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bDraw---bDraw, Specifies A Boolean value.
	virtual void OnDrawPorts(CDC *pDC, BOOL bDraw);

	// Draws prts.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Ports, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackPorts(CDC *pDC);

	// Draws the truely shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);
	
public:

	// Obtain the center port of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetCenterPort();

	// Obtain port at any side of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Left Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetLeftCenterPort();

	// Obtain port at any side of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Top Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetTopCenterPort();

	// Obtain port at any side of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Right Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetRightCenterPort();

	// Obtain port at any side of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bottom Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetBottomCenterPort();

	// Create center port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Center Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *CreateCenterPort();	

	// Create center port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Left Center Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *CreateLeftCenterPort();	

	// Create center port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Top Center Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *CreateTopCenterPort();	

	// Create center port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Right Center Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *CreateRightCenterPort();	

	// Create center port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Bottom Center Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *CreateBottomCenterPort();	

	// Reset update flags.
	virtual void UpdateHardWay();

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

public:

	// Scale shape.
	// dX -- x scale of shape.
	// dY -- y scale of shape.
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale track shape.
	// Define for track line.
	// dX -- x track scale of shape.
	// dY -- y track scale of shape.
	// dOX -- x track origin of shape.
	// dOY -- y track origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dX, double dY, double dOX, double dOY);

	// Scales the shape about its center to the size specified. 
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioShape(const FOPRect &rcSave,CFOMatrix* pMat,  const CPoint &ptOffset, int handle);
	
	
	// Scale shape.
	// Define for track line.
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioTrackShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);

	// Rotate shape.
	// nAngle -- rotate angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate tack shape.
	// Define for track line.
	// nAngle -- rotate angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Implementation
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Position shape to a specify rectangle.
	// rcNewPos -- new position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Op.
	// Offset a specify point.
	// nIndex -- the spot index.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all points,call this method to moving the shape.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	// rRef1 -- mirror reference line's start point.
	// rRef2 -- mirror reference line's end point.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror tack with point ref1 and ref2.
	// rRef1 -- mirror reference line's start point.
	// rRef2 -- mirror reference line's end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// skewing shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewXShape(int nAngle, double dOX, double dOY);

	// skewing shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewYShape(int nAngle, double dOX, double dOY);

	// skewing track shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackXShape(int nAngle, double dOX, double dOY);

	// skewing track shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackYShape(int nAngle, double dOX, double dOY);

	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

public:

	// Offset current track points.
	// nOffsetX -- x offset value.
	// nOffsetY -- y offset value.
	// ptScroll -- currently not used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetPoints(int nOffsetX, int nOffsetY,CPoint ptScroll);

	// Offset the current track point.
	// nIndex -- index of the track point.
	// ptOffset -- offset point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all track points.
	// ptOffset -- offset point value.
	// ptScroll -- currently not used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

public:

	// Obtain the list of the ports within the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports List, Returns the specified value.
	//		Returns a pointer to the object CFOPortShapeList ,or NULL if the call failed
	CFOPortShapeList *GetPortsList()	{ return &m_PortList; }

	// Get the Count of connect ports within the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetPortsCount()			{ return m_PortList.GetCount(); }

	// Add a new connect Port to the shape.
	// pShape -- validate port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Port, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void AddNewPort(CFOPortShape *pShape);

	// Export to SVG
	virtual void ExportToSVG(CStdioFile*);

	// Add a new connect Port to the shape.
	// pShape -- validate port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert New Port, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void InsertNewPort(CFOPortShape *pShape);

	// Add a list of connect Ports on the shape.
	// m_list -- list of ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ports, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a const CFOPortShapeList &m_list object(Value).
	virtual void AddPorts(const CFOPortShapeList &m_list);

	// Remove a specify port from the shape.
	// pShape -- connect port to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Port, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void RemovePort(CFOPortShape *pShape);

	// Remove a list of connect ports from the shape.
	// m_list -- connect ports to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Ports, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a const CFOPortShapeList &m_list object(Value).
	virtual void RemovePorts(const CFOPortShapeList &m_list);

	// Remove all connect ports on the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Ports, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllPorts();

	// Get port count,the same with GetPortsCount() method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetPortCount();

	// Remove all links that connect to this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Links, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllLinks();

	// Hit test connect point, if it is hitted, return the hit connect port,else return NULL.
	// point -- log point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&bUseExt---Use Extend, Specifies A Boolean value.
	virtual CFOPortShape* HitTest(const CPoint& point,const BOOL &bUseExt = TRUE);

	// Hit test connect point,if it is hitted, return the hit connect port, else return NULL.
	// ptHit -- log point.
	// nExpand -- expand value of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nExpand---nExpand, Specifies A integer value.
	virtual CFOPortShape* HitTestPort(const CPoint& ptHit, int nExpand = 0) const;

	// Hit test port extend, it will use a extend point size for checking.
	virtual CFOPortShape *HitTestPortExt(CPoint point,const BOOL &bUseExt);

	// Get specify connect port by scale x and scale y.
	// dXScale -- x scale value.
	// dYScale -- y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		dXScale---X Scale, Specifies a double dXScale object(Value).  
	//		dYScale---Y Scale, Specifies a double dYScale object(Value).
	virtual CFOPortShape* FindPort(double dXScale,double dYScale);


	// Get specify connect port by name.
	// strName -- name of this port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port By Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	virtual CFOPortShape* FindPortByName(const CString &strName);

	// Get specify connect port by key 1 value.
	// strKey -- key 1 of this port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port By Key1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	virtual CFOPortShape* FindPortByKey1(const CString &strKey);

	// Get specify connect port by shape ID.
	// nId -- id value of this port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port By I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		&nId---&nId, Specifies A integer value.
	virtual CFOPortShape* FindPortByID(const int &nId);

	// Get specify connect port by index.
	// nIndex -- index of port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port At, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	virtual CFOPortShape* GetPortAt(const int &nIndex);

	// Find by id.
	virtual CFODrawShape *FindByID(const int &nID);

public:
	/*************************************************************************
	|*
	|* Node shapes
	|*
	\************************************************************************/

	// Get all shapes that links with this shape.
	// Return the node shapes's count.
	// ---->this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Link Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetAllLinkShapes(CFODrawShapeList &listShapes);

	// Get all shapes that links that to this shape.
	// Return node shapes.
	// ---->this
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Link To Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetAllLinkToShapes(CFODrawShapeList &listShapes);

	// Get all shapes that links that from this shape.
	// Return node shapes
	// this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Link From Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetAllLinkFromShapes(CFODrawShapeList &listShapes);

public:
	/*************************************************************************
	|*
	|* Link lines
	|*
	\************************************************************************/

	// Return if it has any link that linked with this shape
	// ---->this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	//		Returns a int type value.  
	// Parameters: None
	virtual BOOL HasLink();

	// Return a list of links that links with this shape
	// Return the link lines
	// ---->this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Links, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual int GetAllLinks(CFODrawShapeList &listLinks);

	// Return a list of links that from this shape
	// Return the link lines
	// this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All From Links, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual int GetAllFromLinks(CFODrawShapeList &listLinks);

	// Return a list of links that to this shape
	// Return the link lines
	// ---->this
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All To Links, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual int GetAllToLinks(CFODrawShapeList &listLinks);

	// Determines if this shape owns the from port of the given link. 
	// Check if this link line is from here.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Link From, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pLink---pLink, A pointer to the CFOLinkShape or NULL if the call failed.
	virtual BOOL IsLinkFrom(CFOLinkShape* pLink);


	// Returns a list of links that between this shape and another shape. 
	// Returns all link lines.
	// ----->this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Links With Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawPortsShape or NULL if the call failed.  
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual void GetLinksWithShape(CFODrawPortsShape* pShape, CFODrawShapeList &listLinks);

	// Returns a list of links from this shape to another shape. 
	// Returns link lines.
	// ---->this
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Links To Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pToShape---To Shape, A pointer to the CFODrawPortsShape or NULL if the call failed.  
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual void GetLinksToShape(CFODrawPortsShape* pToShape, CFODrawShapeList &listLinks);

	// Returns a list of links from another shape to this shape. 
	// Return link lines. 
	// this---->
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Links From Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFromShape---From Shape, A pointer to the CFODrawPortsShape or NULL if the call failed.  
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual void GetLinksFromShape(CFODrawPortsShape* pFromShape, CFODrawShapeList &listLinks);

public:
	/*************************************************************************
	|*
	|* Port shape
	|*
	\************************************************************************/


	// Returns the port at the other end of a given link. 
	// It returns port shape.
	// The link line's one port must connected to this node shape.
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other End Port On Link, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		pLink---pLink, A pointer to the CFOLinkShape or NULL if the call failed.
	virtual CFOPortShape* GetOtherEndPortOnLink(CFOLinkShape* pLink);

	// Returns the port which the shape owns on a given link. 
	// The port that returns must be within the port list of this node shape.
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Port On Link, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		pLink---pLink, A pointer to the CFOLinkShape or NULL if the call failed.
	virtual CFOPortShape* GetPortOnLink(CFOLinkShape* pLink);

	// Returns a list of all link lines on a given port.
	// It returns link lines.
	// pPort -- pointer of Port shape.
	// listLinks -- list of links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Links On Port, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPort---pPort, A pointer to the CFOPortShape or NULL if the call failed.  
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	virtual void GetLinksOnPort(CFOPortShape* pPort, CFODrawShapeList &listLinks);

public:
	/*************************************************************************
	|*
	|* Nodes
	|*
	\************************************************************************/

	// Retrieve the shape linked to this shape on a given link. 
	// At first, this link is linked with this node.
	// Second, the from port or the end port of this link is one of the port of this node.
	// Third, it returns the other end node shape that connected with this link line.
	// Return node ----Link---> this or this---link---> Return node.
	// pLink -- pointer of link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Other End Shape On Link, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pLink---pLink, A pointer to the CFOLinkShape or NULL if the call failed.
	virtual CFODrawShape* GetOtherEndShapeOnLink(CFOLinkShape* pLink);


	// Returns a list of all node shapes that links together 1---->2----->this----->1--->2
	// Returns all node shapes that linked from or to here.
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Linked, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetShapesLinked(CFODrawShapeList &listShapes);
	
	// Retrieve node shapes that are linked from this shape.  this----->1--->2
	// Return the nodes that linked from here
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Linked From, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetShapesLinkedFrom(CFODrawShapeList &listShapes);
	
	// Retrieve node shapes that are linked to this shape. 1---->2----->this
	// Return the nodes that linked to here.
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Linked To, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual int GetShapesLinkedTo(CFODrawShapeList &listShapes);


	// Build unique port name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Unique Port Name, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildUniquePortName();

	// Add all shapes to the prepare shapes list.
	// m_LinkList -- list of links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Links, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_LinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &m_LinkList object (Value).
	virtual void AddToLinks(CFODrawShapeSet &m_LinkList);

	// Get all ports.
	// listPorts -- list of ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Ports, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&listPorts---&listPorts, Specifies a E-XD++ CFODrawShapeList &listPorts object (Value).
	virtual void GetAllPorts(CFODrawShapeList &listPorts);

	// Hide or show all ports.
	void ShowAlPorts(const BOOL &bShow = TRUE);

public:
	/*************************************************************************
	|*
	|* Defined for layout only.
	|*
	\************************************************************************/
	// Gets a list over all of the links going out of this node.
	// LinksOut
	// listLinks -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destination Links, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	void DestinationLinks(CFODrawShapeList &listLinks) { GetAllFromLinks(listLinks); }

	// Gets a list over all of the nodes that have links going out of this node.
	// NodesOut
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destinations, .
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	void Destinations(CFODrawShapeList &listShapes) { GetAllLinkFromShapes(listShapes); }

	// Gets a list over all of the nodes that have links going out of this node.
	// NodesOut
	// listShapes -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destination Links Unique, .
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	void DestinationLinksUnique(CFODrawShapeList &listShapes);

	// Destinations count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destination Count, .
	//		Returns a int type value.
	int DestinationCount() { CFODrawShapeList listShapes; Destinations(listShapes); return listShapes.GetCount();  }

	
	// Obtain all the links that are linked.
	//-----------------------------------------------------------------------
	// Summary:
	// Links, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	// Gets a list over all of the links connected to this node.
	// LinksOut and LinksIn
	// listLinks -- list of link shapes
	void Links(CFODrawShapeList &listLinks) { GetAllLinks(listLinks); }

	
	// Obtain all the linked nodes.
	//-----------------------------------------------------------------------
	// Summary:
	// Nodes, .
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	// Gets a list over all of the nodes that are connected to this node.
	// NodesOut and NodesIn
	// listShapes -- list of shapes
	void Nodes(CFODrawShapeList &listShapes) { GetAllLinkToShapes(listShapes); }

	
	//-----------------------------------------------------------------------
	// Summary:
	// Ports, .
	//		Returns a pointer to the object CFOPortShapeList ,or NULL if the call failed
	// Gets a list over all of the ports that are part of this node.
	CFOPortShapeList *Ports() { return &m_PortList;  }

	// Gets a list over all of the links coming into this node.
	// LinksIn
	// listLinks -- list of link shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Source Links, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	void SourceLinks(CFODrawShapeList &listLinks) { GetAllToLinks(listLinks); }

	// Gets a list over all of the links coming into this node.
	// LinksIn
	// listLinks -- list of link shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Source Links Unique, .
	// Parameters:
	//		&listLinks---&listLinks, Specifies a E-XD++ CFODrawShapeList &listLinks object (Value).
	void SourceLinksUnique(CFODrawShapeList &listLinks);

	// Gets a list over all of the nodes that have links coming into this node.
	// NodesIn
	// listShapes -- list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sources, .
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	void Sources(CFODrawShapeList &listShapes) { GetAllLinkToShapes(listShapes); }

	// Source nodes count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Source Count, .
	//		Returns a int type value.
	int SourceCount() { CFODrawShapeList listShapes; Sources(listShapes); return listShapes.GetCount(); }

	
	// Collapse this shape.
	//-----------------------------------------------------------------------
	// Summary:
	// Collapse, .
	// This member function is also a virtual function, you can Override it if you need,
	// Collapse all children.
	virtual void Collapse();

	// Is expanded or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Expanded, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsExpanded() {return myExpanded; };

	// Expand this shape.
	//-----------------------------------------------------------------------
	// Summary:
	// Expand, .
	// This member function is also a virtual function, you can Override it if you need,
	// Expand children.
	virtual void Expand();

	// Expand all children.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Expand All, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ExpandAll();

	// Add reachable
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Reachable, Adds an object to the specify list.
	// Parameters:
	//		&coll---Specifies a E-XD++ CFODrawShapeList &coll object (Value).  
	//		*inode---A pointer to the CFODrawPortsShape  or NULL if the call failed.
	void AddReachable(CFODrawShapeList &coll, CFODrawPortsShape *inode);

	// Add sub trees to this ports shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Subtrees, Adds an object to the specify list.
	// Parameters:
	//		&sel---Specifies a E-XD++ CFODrawShapeList &sel object (Value).
	void AddSubtrees(CFODrawShapeList &sel);

	// Has children node or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Children, .
	//		Returns A Boolean value.
	bool HasChildren();
	
	// Is node n2 the boss of node n1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Boss Of, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*n1---A pointer to the CFODrawPortsShape  or NULL if the call failed.  
	//		*n2---A pointer to the CFODrawPortsShape  or NULL if the call failed.
	BOOL IsBossOf(CFODrawPortsShape *n1, CFODrawPortsShape *n2);

public:
	
	// Default port position.
	enum PortPositon 
	{       
        ptCenter = 0,     
		ptTopLeft,        
		ptTopCenter,      
		ptTopRight,
		ptRightCenter,    
		ptBottomRight,
		ptBottomCenter,
		ptBottomLeft,
		ptLeftCenter 
	};

	// Generate Default Port without update comp
	// xScale -- x scale from top left of shape(from 0.0 -- 1.0).
	// yScale -- y scale from top left of shape(from 0.0 -- 1.0).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		xScale---xScale, Specifies a double xScale object(Value).  
	//		yScale---yScale, Specifies a double yScale object(Value).
	virtual CFOPortShape* GenDefaultPort(double xScale,double yScale);


	// Create Default Port
	// xScale -- x scale from top left of shape(from 0.0 -- 1.0).
	// yScale -- y scale from top left of shape(from 0.0 -- 1.0).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		xScale---xScale, Specifies a double xScale object(Value).  
	//		yScale---yScale, Specifies a double yScale object(Value).
	virtual CFOPortShape* CreateDefaultPort(double xScale,double yScale);

	// Create Default Port
	// xScale -- x scale from top left of shape(from 0.0 -- 1.0).
	// yScale -- y scale from top left of shape(from 0.0 -- 1.0).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		xScale---xScale, Specifies a double xScale object(Value).  
	//		yScale---yScale, Specifies a double yScale object(Value).
	virtual CFOPortShape* CreateDefaultPortWithLock(double xScale,double yScale);

	// Create Default Port with port class and location scale value.
	// xScale -- x scale from top left of shape(from 0.0 -- 1.0).
	// yScale -- y scale from top left of shape(from 0.0 -- 1.0).
	// pPort -- port class,it must be a valid pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Port With Class, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		xScale---xScale, Specifies a double xScale object(Value).  
	//		yScale---yScale, Specifies a double yScale object(Value).
	virtual CFOPortShape* CreatePortWithClass(CFOPortShape *pPort,double xScale,double yScale);

	// Create Port from local point.
	// pt -- port position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Port, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	virtual CFOPortShape* CreatePort(const CPoint &pt);

	//Create Port with the port object and local point.
	// pt -- port position.
	// pShape -- port class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Port With Class And Point, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		&pt---Specifies A CPoint type value.
	virtual CFOPortShape* CreatePortWithClassAndPoint(CFOPortShape *pPort,const CPoint &pt);


	// Create Default Port, it is created from thr port position.
	// 	enum PortPositon 
	// 	{       
	//         ptCenter = 0,     
	// 			ptTopLeft,        
	// 			ptTopCenter,      
	// 			ptTopRight,
	// 			ptRightCenter,    
	// 			ptBottomRight,
	// 			ptBottomCenter,
	// 			ptBottomLeft,
	// 			ptLeftCenter 
	// 	};
	// nPort -- port position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Default Port Extend, You construct a CFODrawPortsShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		nPort---nPort, Specifies a PortPositon nPort object(Value).
	virtual CFOPortShape* CreateDefaultPortExt(PortPositon nPort);	
	
public:

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Combine Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Combine Rectangle, .
	//		Returns a CRect type value.  
	// Parameters:
	//		rect1---Specifies A CRect type value.  
	//		rect2---Specifies A CRect type value.
	CRect	CombineRect(CRect rect1, CRect rect2);

    // Size the shape, scale shape to new position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Size Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNew---&rcNew, Specifies A CRect type value.  
	//		fXScale---X Scale, Specifies a double fXScale object(Value).  
	//		fYScale---Y Scale, Specifies a double fYScale object(Value).
	virtual void SizeShape(CRect &rcNew,double fXScale,double fYScale);

	// Get plus spots
	// lstHandle -- list of the handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Layout index
 
	// Layout Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayoutIndex;
	
	// Layout column number
 
	// Layout Column, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayoutColumn;
	
	// Layout Shape
 
	// Layout Component, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayoutComp;
	
	// Layout discover
 
	// Layout Discover, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayoutDiscover;
	
	// Layout finish.
 
	// Layout Finish, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayoutFinish;
	
	// Layout layer
 
	// Layer, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLayer;
	
	// Layout valid or not.
 
	// Layout Valid, This member sets TRUE if it is right.  
	BOOL			m_bLayoutValid;

	// NewLayout index.
	int				m_nNewLayoutIndex;

	// NewLayout level.
	int				m_nNewLayoutLevel;

	// NewLayout component
	int				m_nNewLayoutComponent;

public:
	
	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();
	
protected:

	//Port List
 
	// Port List, This member specify E-XD++ CFOPortShapeList object.  
	CFOPortShapeList m_PortList;

	// Expanded.
 
	// Expanded, This member sets TRUE if it is right.  
	BOOL myExpanded;

	// Collapeible
 
	// Collapsible, This member sets TRUE if it is right.  
    BOOL myCollapsible;
};


//------------------------------------------------------
// Description
// Author: Author Name.
//------------------------------------------------------

///////////////////////////////////////////////////////////////////
// CFOPinShape -- a multisim symbol editor like pin shape, ID: FO_COMP_PIN 73

#include "FODrawPortsShape.h"

 
//===========================================================================
// Summary:
//     The CFOPinShape class derived from CFODrawPortsShape
//      F O Pin Shape
//===========================================================================

class FO_EXT_CLASS CFOPinShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPinShape---F O Pin Shape, Specifies a E-XD++ CFOPinShape object (Value).
	DECLARE_SERIAL(CFOPinShape);

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pin Shape, Constructs a CFOPinShape object.
	//		Returns A  value (Object).
	CFOPinShape();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Pin Shape, Constructs a CFOPinShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPinShape& src object(Value).
	CFOPinShape(const CFOPinShape& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Pin Shape, Destructor of class CFOPinShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPinShape();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPinShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the parallelogram shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPinShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPinShape& src object(Value).
	CFOPinShape& operator=(const CFOPinShape& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	// called as object moved/resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Get plus spots
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Do event when sub menu item change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Do draw mark shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Mark, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawMark(CDC *pDC);

	// Obtain port, mostly it is the first port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed
	CFOPortShape *GetCurPort();

	// Change label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Label, Sets a specify value to current class CFOPinShape
	// Parameters:
	//		&strNew---&strNew, Specifies A CString type value.
	void SetLabel(const CString &strNew);

	// Add a new connect Port to the shape.
	// pShape -- validate port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Port to the list, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void AddNewPort(CFOPortShape *pShape);

	// Remove a specify port from the shape.
	// pShape -- connect port to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Port from ports list, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void RemovePort(CFOPortShape *pShape);
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

#endif // !defined(AFC_FODRAWPORTSSHAPE_H__0B388BF0_DD8A_11D5_A4AB_525400EA266C__INCLUDED_)
