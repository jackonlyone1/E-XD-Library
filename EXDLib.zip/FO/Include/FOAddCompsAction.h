//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOAddCompsAction.h: interface for the CFOAddCompsAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOADDCOMPSACTION_H__2EEABBFE_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOADDCOMPSACTION_H__2EEABBFE_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

/////////////////////////////////////////////////////////////////////////////////////
// CFOAddCompsAction -- action that add multiple shapes to canvas one time.
// Added action class

 
//===========================================================================
// Summary:
//     The CFOAddCompsAction class derived from CFOAction
//      F O Add Components Action
//===========================================================================

class FO_EXT_CLASS CFOAddCompsAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddCompsAction---F O Add Components Action, Specifies a E-XD++ CFOAddCompsAction object (Value).
	DECLARE_ACTION(CFOAddCompsAction)

public:
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Components Action, Constructs a CFOAddCompsAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFOAddCompsAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Components Action, Destructor of class CFOAddCompsAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAddCompsAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Returns a pointer to the list of actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add a new component to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add a new component to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add a new component to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove a component from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Clear all index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Index, Remove the specify data from the list.

	void ClearAllIndex();
	
	// Obtain index of a shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	BOOL GetIndex(CFODrawShape* pComp, int& nIndex) const;
	
	// Change the index of a shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFOAddCompsAction
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	void SetIndex(CFODrawShape* pComp, int nIndex);

// Attributes
protected:

	// Shapes list
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

	// Shape index.
	CMap<CFODrawShape*,CFODrawShape*,int,int> m_shapeIndices;

    //Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

// Returns a pointer to the list of actions.
_FOLIB_INLINE CFODrawShapeList* CFOAddCompsAction::GetShapeList()
{
	return &m_listShapes;
}


/////////////////////////////////////////////////////////////////////////////
// CFOAddShapesToBackAction -- action that add multiple shapes to background one time

// Added action class
 
//===========================================================================
// Summary:
//     The CFOAddShapesToBackAction class derived from CFOAction
//      F O Add Shapes To Back Action
//===========================================================================

class FO_EXT_CLASS CFOAddShapesToBackAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddShapesToBackAction---F O Add Shapes To Back Action, Specifies a E-XD++ CFOAddShapesToBackAction object (Value).
	DECLARE_ACTION(CFOAddShapesToBackAction)

public:
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Shapes To Back Action, Constructs a CFOAddShapesToBackAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFOAddShapesToBackAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Shapes To Back Action, Destructor of class CFOAddShapesToBackAction
	//		Returns A  value (Object).
	~CFOAddShapesToBackAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Returns a pointer to the list of actions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add a new componet to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add a new componets to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add a new componets to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove a componet from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();


// Attributes
protected:

	// Shapes list
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

    //Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

// Returns a pointer to the list of actions.
_FOLIB_INLINE CFODrawShapeList* CFOAddShapesToBackAction::GetShapeList()
{
	return &m_listShapes;
}

class CFOCompositeShape;

/////////////////////////////////////////////////////////////////////////////
// CFOAddShapesToCompositeAction -- action that add multiple shapes to composite shape.
// Added action class

 
//===========================================================================
// Summary:
//     The CFOAddShapesToCompositeAction class derived from CFOAction
//      F O Add Shapes To Composite Action
//===========================================================================

class FO_EXT_CLASS CFOAddShapesToCompositeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddShapesToCompositeAction---F O Add Shapes To Composite Action, Specifies a E-XD++ CFOAddShapesToCompositeAction object (Value).
	DECLARE_ACTION(CFOAddShapesToCompositeAction)

public:
	// Constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Shapes To Composite Action, Constructs a CFOAddShapesToCompositeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).
	CFOAddShapesToCompositeAction(CFODataModel* pModel, const CFODrawShapeList& list);

	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Shapes To Composite Action, Destructor of class CFOAddShapesToCompositeAction
	//		Returns A  value (Object).
	~CFOAddShapesToCompositeAction();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Executes the action. 
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action, generate the scription of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Returns a pointer to the list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add a new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add a list of shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add a list of shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove a shape from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Remove all shapes from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Get maximize position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Obtain the composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Shape, Returns the specified value.
	//		Returns a pointer to the object CFOCompositeShape ,or NULL if the call failed
	CFOCompositeShape *GetCompShape() { return m_pComposite; }

	// Set composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Component Shape, Sets a specify value to current class CFOAddShapesToCompositeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pComp---*pComp, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void SetCompShape(CFOCompositeShape *pComp) { m_pComposite = pComp; }

	// Clear all index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Index, Remove the specify data from the list.

	void ClearAllIndex();
	
	// Obtain index of a shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Index, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	BOOL GetIndex(CFODrawShape* pComp, int& nIndex) const;
	
	// Change the index of a shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index, Sets a specify value to current class CFOAddShapesToCompositeAction
	// Parameters:
	//		pComp---pComp, A pointer to the CFODrawShape or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	void SetIndex(CFODrawShape* pComp, int nIndex);
	
// Attributes
protected:

	// member variable,a pointer to the composite shape.
 
	// Composite, This member maintains a pointer to the object CFOCompositeShape.  
	CFOCompositeShape *m_pComposite;
    
	// Shapes list
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

	// Shapes index.
	CMap<CFODrawShape*,CFODrawShape*,int,int> m_shapeIndices;

    //Declare friend class CFOPCanvasCore
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

// Returns a pointer to the list of actions.
_FOLIB_INLINE CFODrawShapeList* CFOAddShapesToCompositeAction::GetShapeList()
{
	return &m_listShapes;
}

#endif // !defined(AFX_FOADDCOMPSACTION_H__2EEABBFE_F19E_11DD_A432_525400EA266C__INCLUDED_)
