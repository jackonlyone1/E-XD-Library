//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FODrawHelper.h: interface for the CFODrawHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FODRAWHELPER_H__2F9FA184_C1F8_11D5_A482_525400EA266C__INCLUDED_)
#define AFX_FODRAWHELPER_H__2F9FA184_C1F8_11D5_A482_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOPPolygon.h"
#include "FOPFraction.h"
#include "FOPSimplePolygon.h"
#include "FODefines.h"
#include "FOPLineInfo.h"
#include "FOPLine.h"

typedef USHORT FOPPaper;

#define PAPER_USER					((FOPPaper)8)
#define FOP_SPLIST_POINT_COUNT		10

#define FOMoveRight(pt, a)		pt.x = pt.x + a
#define FOMoveLeft(pt, a)		pt.x = pt.x - a
#define FOMoveUp(pt, a)			pt.y = pt.y - a
#define FOMoveDown(pt, a)		pt.y = pt.y + a

class FOPLineParam;
class CFOBitmap;
/////////////////////////////////////////////////////////////////////////////////
//
// CFODrawHelper
// 	Function of this module:
// 		This module contains some useful global methods that do not
// 		belong to any particular class but are useful to keep in one
// 		place, all these methods can be call with:
//		CFODrawHelper::RoundValue(...);
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFODrawHelper class derived from CObject
//      F O Draw Helper
//===========================================================================

class FO_EXT_CLASS CFODrawHelper : public CObject
{
public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Draw Helper, Constructs a CFODrawHelper object.
	//		Returns A  value (Object).
	CFODrawHelper();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Draw Helper, Destructor of class CFODrawHelper
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODrawHelper();

	/*************************************************************************
	|*
	|* Drawing
	|*
	\************************************************************************/

	// Get bitmap dc.
	// pDC -- pointer of the DC.
	// bmpSource -- bitmap handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Bitmap D C, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDC,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bmpSource---bmpSource, Specifies a CBitmap& bmpSource object(Value).
	static CDC* CreateBitmapDC(CDC *pDC, CBitmap& bmpSource );

	// Create bitmap dc.
	// pDC -- pointer of the DC.
	// nResourceID -- bitmap resource ID
	// pSize -- size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Bitmap D C, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDC,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		uResourceID---Resource I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pSize---pSize, A pointer to the CSize or NULL if the call failed.
	static CDC* CreateBitmapDC(CDC *pDC, UINT uResourceID, CSize* pSize=NULL );

	// Draw Shadow
	// pDC -- pointer of DC.
	// rect -- rectangle for drawing.
	// nDepth -- shadow depth.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Shadow, Draws current object to the specify device.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		nDepth---nDepth, Specifies A integer value.  
	//		iMin---iMin, Specifies A integer value.  
	//		iMax---iMax, Specifies A integer value.  
	//		pBmpSave---Bitmap Save, A pointer to the CBitmap or NULL if the call failed.  
	//		pBmpSaveX---Bitmap Save X, A pointer to the CBitmap or NULL if the call failed.
	BOOL DrawShadow (CDC *pDC,CRect rect,int nDepth,	int iMin = 100,int iMax = 50,
		CBitmap* pBmpSave = NULL,CBitmap* pBmpSaveX = NULL);
	
	// Set Alpha Pixel.
	// pBits -- pixel for converting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Alpha Pixel, Sets a specify value to current class CFODrawHelper
	// This member function is a static function.
	// Parameters:
	//		pBits---pBits, A pointer to the COLORREF or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		percent---Specifies A integer value.  
	//		iShadowSize---Shadow Size, Specifies A integer value.
	static void SetAlphaPixel(COLORREF* pBits, const CRect &rect, int x, int y, int percent, int iShadowSize);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	static void FillAngleGradient(CDC *pDC,const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd, int nAngle);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient2, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	static void FillAngleGradient2(CDC *pDC,const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd, int nAngle);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient Extend, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	static void FillAngleGradientExt(CDC *pDC,const CRect &rcPos, COLORREF crStart, 
		COLORREF crEnd, int nAngle);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nAngle -- angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Angle Gradient Ext2, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	static void FillAngleGradientExt2(CDC *pDC,const CRect &rcPos, COLORREF crStart, 
		COLORREF crEnd, int nAngle);

	// Fill with new angle gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill New Angle Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&crStart---&crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crEnd---&crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nAngle---nAngle, Specifies A integer value.
	static void FillNewAngleGradient(CDC *pDC, const CRect &rect, const COLORREF &crStart, 
		const COLORREF &crEnd, 
					int nAngle);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// bHorz -- horizontal or vertical drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	static void FillGradient(CDC *pDC,const CRect &rcPos, COLORREF crStart, 
		COLORREF crEnd, BOOL bHorz = TRUE);

	// Fill with second gradient
	// pDC -- pointer of DC.
	// rect -- rectangle.
	// crFirst -- start color.
	// crEnd -- end color.
	// bHorz -- horizontal or vertical drawing.
	// nStartPercent -- start percent.
	// nEndPercent -- end percent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient2, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		&crFirst---&crFirst, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crEnd---&crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.  
	//		nStartPercent---Start Percent, Specifies A integer value.  
	//		nEndPercent---End Percent, Specifies A integer value.
	static void FillGradient2(CDC *pDC, CRect rect, 
		const COLORREF &crFirst, const COLORREF &crEnd,
		BOOL bHorz = TRUE,
		int nStartPercent = 0,
		int nEndPercent = 0);

	// Fill with second gradient
	// pDC -- pointer of DC.
	// rect -- rectangle.
	// crFirst -- start color.
	// crEnd -- end color.
	// bHorz -- horizontal or vertical drawing.
	// nStartPercent -- start percent.
	// nEndPercent -- end percent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient Extend, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&crFirst---&crFirst, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crEnd---&crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	static void FillGradientExt(CDC *pDC, const CRect &rect, 
		const COLORREF &crFirst, const COLORREF &crEnd,
		BOOL bHorz = TRUE);

	// Fill with four colors.
	// pDC -- pointer of DC.
	// rect -- rectangle.
	// bHorz -- horizontal or not
	// nPercentage -- it must be a value between 0 - 100.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Two Segment Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		&crStart1---&crStart1, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd1---crEnd1, Specifies A 32-bit COLORREF value used as a color value.  
	//		&crStart2---&crStart2, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd2---crEnd2, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.  
	//		nPercentage---nPercentage, Specifies A integer value.
	static void FillTwoSegmentGradient(CDC *pDC, const CRect &rect, 
		const COLORREF &crStart1, const COLORREF crEnd1, 
		const COLORREF &crStart2, const COLORREF crEnd2,
		BOOL bHorz = TRUE, int nPercentage = 50);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// bHorz -- horizontal or vertical drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Center Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		bHorz---bHorz, Specifies A Boolean value.
	static void FillCenterGradient(CDC *pDC,const CRect &rcPos, COLORREF crStart, 
		COLORREF crEnd, BOOL bHorz = TRUE);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nType -- type of the vector gradient
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Vercor Gradient Extend, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static void FillVercorGradientExt(CDC *pDC,const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd, UINT nType);

	// Fill gradient.
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing.
	// crStart -- start color for gradient drawing.
	// crEnd -- end color for gradient drawing.
	// nType -- type of the vector gradient
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Vercor Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static void FillVercorGradient(CDC *pDC,const CRect &rcPos, COLORREF crStart,
		COLORREF crEnd, UINT nType);

	// Fill gradient extension.
	// pDC -- pointer of DC.
	// pRect -- rectangle for drawing.
	// nStep -- steps for drawing.
	// crStart -- start color.
	// crEnd -- end color of gradient
	
	//-----------------------------------------------------------------------
	// Summary:
	// Gradient Caption, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pRect---pRect, A pointer to the CRect or NULL if the call failed.  
	//		nStep---nStep, Specifies A integer value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.
	static void GradientCaption(CDC* pDC, CRect* pRect, int nStep,COLORREF crStart,
		COLORREF crEnd);


	// Create gray scale icon.
	static HICON CreateGrayscaleIcon( HICON hIcon);

	// Paint rect.
	// pDC -- pointer of DC.
	// x -- x start position of rectangle.
	// y -- y start position of rectangle.
	// w -- width of rectangle.
	// h -- height of rectangle.
	// color -- color for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paint Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void	PaintRect(CDC* pDC, int x, int y, int w, int h, COLORREF color);

	// Paint rect.
	// pDC -- pointer of DC.
	// rc -- rectangle for drawing.
	// color -- color for filling
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paint Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rc---Specifies A CRect type value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void	PaintRect(CDC* pDC, const CRect &rc, const COLORREF& color);

	// Paint Ellipse.
	// pDC -- pointer of DC.
	// x -- x start position of ellipse.
	// y -- y start position of ellipse.
	// w -- width of ellipse.
	// h -- height of ellipse.
	// color -- color for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paint Ellipse, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void	PaintEllipse(CDC* pDC, int x, int y, int w, int h, COLORREF color);

	// Paint Triangle.
	// pDC -- pointer of DC.
	// ppts -- points for drawing.
	// nCount -- count of points.
	// color -- color for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Paint Polygon, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void	PaintPolygon(CDC* pDC, LPPOINT ppts, int nCount, COLORREF color);

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	static int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);
	
	// From Logical To Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	static int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Draw line.
	// pDC -- pointer of DC.
	// From -- from point of line.
	// To -- to point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Line, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		From---From, Specifies A CPoint type value.  
	//		To---To, Specifies A CPoint type value.
	static void DrawLine(CDC *pDC, CPoint From, CPoint To );

	// Dither bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dither Bitblt, .
	// This member function is a static function.
	// Parameters:
	//		hdcDest---hdcDest, Specifies a HDC hdcDest object(Value).  
	//		nXDest---X Dest, Specifies A integer value.  
	//		nYDest---Y Dest, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		hbm---Specifies a HBITMAP hbm object(Value).  
	//		nXSrc---X Source, Specifies A integer value.  
	//		nYSrc---Y Source, Specifies A integer value.  
	//		bgcolor---Specifies A 32-bit COLORREF value used as a color value.
	static void DitherBlt(HDC hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, HBITMAP hbm,
		int nXSrc, int nYSrc,COLORREF bgcolor);

	// Dither bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dither Blt2, .
	// This member function is a static function.
	// Parameters:
	//		*drawdc---A pointer to the CDC  or NULL if the call failed.  
	//		nXDest---X Dest, Specifies A integer value.  
	//		nYDest---Y Dest, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		&bmp---Specifies a CBitmap &bmp object(Value).  
	//		nXSrc---X Source, Specifies A integer value.  
	//		nYSrc---Y Source, Specifies A integer value.  
	//		bgcolor---Specifies A 32-bit COLORREF value used as a color value.
	static void DitherBlt2(CDC *drawdc, int nXDest, int nYDest, int nWidth, int nHeight, CBitmap &bmp, 
		int nXSrc, int nYSrc,COLORREF bgcolor);

	// Draw check mark,draw a mark with specify color.
	// pDC -- pointer of DC.
	// x -- x position.
	// y -- y position.
	// color -- color of check
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Check Mark, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void DrawCheckMark(CDC *pDC,int x,int y,COLORREF color);

	// Draw radio dot.
	// pDC -- pointer of DC.
	// x -- x position.
	// y -- y position.
	// color -- color of radio button
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Radio Dot, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	static void DrawRadioDot(CDC *pDC,int x,int y,COLORREF color);

	// Get light color.
	// color -- color.
	// factor -- factor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lighten Color, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.  
	//		factor---Specifies a double factor object(Value).
	static COLORREF LightenColor(COLORREF color,double factor);

	// Is color dark
	static BOOL IsDarkColor(COLORREF crColor);

	// Is color light
	static BOOL IsLightColor(COLORREF crColor);

	// Make color lighter.
	static COLORREF MakeColorLighter(COLORREF crColor, double dblRatio = .1, BOOL bSat = FALSE);

	// Make color darker.
	static COLORREF MakeColorDarker(COLORREF crColor, double dblRatio = .1, BOOL bSat = FALSE);

	// Get bitmap from image list.
	// pDC -- pointer of DC.
	// szBmp -- size of bitmap.
	// imglist -- image list
	// nIndex -- index of image within image list.
	// bmp -- bitmap that obtained.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bitmap From Image List, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		szBmp---szBmp, Specifies A CSize type value.  
	//		*imglist---A pointer to the CImageList  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&bmp---Specifies a CBitmap &bmp object(Value).
	static BOOL GetBitmapFromImageList(CDC* pDC,CSize szBmp,
		CImageList *imglist,int nIndex,CBitmap &bmp);

	// Draw 3d check box
	// dc -- pointer of DC.
	// rc -- rectangle.
	// bSelected -- with selected state.
	// hbmCheck -- check bitmap handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw3 D Checkmark, Draws current object to the specify device.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*dc---A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		bSelected---bSelected, Specifies A Boolean value.  
	//		hbmCheck---hbmCheck, Specifies a HBITMAP hbmCheck object(Value).
	static BOOL Draw3DCheckmark(CDC *dc, const CRect& rc,BOOL bSelected,HBITMAP hbmCheck);

	// Draw xp check box.
	// dc -- pointer of DC.
	// rc -- rectangle.
	// hbmCheck -- check bitmap handle.
	// colorout -- color for out.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw X P Checkmark, Draws current object to the specify device.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*dc---A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		hbmCheck---hbmCheck, Specifies a HBITMAP hbmCheck object(Value).  
	//		&colorout---Specifies A 32-bit COLORREF value used as a color value.
	static BOOL DrawXPCheckmark(CDC *dc, const CRect& rc, HBITMAP hbmCheck,COLORREF &colorout);
	
	// Create bitmap mask.
	// hSourceBitmap -- source bitmap.
	// dwWidth -- width of bitmap.
	// dwHeight -- height of bitmap.
	// crTransColor -- transparent bitmap color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Bitmap Mask, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		hSourceBitmap---Source Bitmap, Specifies a HBITMAP hSourceBitmap object(Value).  
	//		dwWidth---dwWidth, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwHeight---dwHeight, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		crTransColor---Transparent Color, Specifies A 32-bit COLORREF value used as a color value.
	static HBITMAP CreateBitmapMask(HBITMAP hSourceBitmap, DWORD dwWidth, DWORD dwHeight,
		COLORREF crTransColor);

	// Convert rect corner to bezier.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Corner To Bezier, .
	// This member function is a static function.
	// Parameters:
	//		r---Specifies A CRect type value.  
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.  
	//		nType---nType, Specifies A integer value.
	static void RectCornerToBezier(const FOPRect& r, LPPOINT cCtlPt,int nType);

	// Convert rect simple rect to bezier.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Sim To Bezier, .
	// This member function is a static function.
	// Parameters:
	//		r---Specifies A CRect type value.  
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.  
	//		bTop---bTop, Specifies A Boolean value.
	static void RectSimToBezier(const FOPRect& r, LPPOINT cCtlPt,BOOL bTop = TRUE);

	// Convert ellipse to bezier.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ellipse To Bezier, .
	// This member function is a static function.
	// Parameters:
	//		r---Specifies A CRect type value.  
	//		ppts---Specifies A LPPOINT Points array.
	static void EllipseToBezier(const FOPRect& r, LPPOINT ppts);

	// Make bezier line.
	// gPp -- points that converted.
	// int x0, int y0, int x1, int y1, int x2 int y2-- point 0, 1, 2
	// 	int x3, int y3 -- point 3.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bezier Line, .
	// This member function is a static function.
	// Parameters:
	//		**gPp---**gPp, A pointer to the CPoint * or NULL if the call failed.  
	//		x0---Specifies A integer value.  
	//		y0---Specifies A integer value.  
	//		x1---Specifies A integer value.  
	//		y1---Specifies A integer value.  
	//		x2---Specifies A integer value.  
	//		y2---Specifies A integer value.  
	//		x3---Specifies A integer value.  
	//		y3---Specifies A integer value.
	static void BezierLine(CPoint **gPp, int x0, int y0, int x1, int y1, int x2, 
		int y2, int x3, int y3);

	// Draw transparent bitmap.
	// pDC -- pointer of DC.
	// pBitmap -- pointer of bitmap.
	// xStart -- x start.
	// yStart -- y start.
	// crTrans -- transparent color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Transparent Bitmap, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pBitmap---pBitmap, A pointer to the CBitmap or NULL if the call failed.  
	//		xStart---xStart, Specifies A integer value.  
	//		yStart---yStart, Specifies A integer value.  
	//		crTrans---crTrans, Specifies A 32-bit COLORREF value used as a color value.
	static void DrawTransparentBitmap(CDC* pDC, CBitmap* pBitmap, int xStart,int yStart, COLORREF crTrans);

	// Make spline line.
	// pts -- points that converted.
	// p -- points
	// n -- count of points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Spline, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		*pts---A pointer to the CPoint  or NULL if the call failed.  
	//		*p---A pointer to the CPoint  or NULL if the call failed.  
	//		n---Specifies A integer value.
	static int MakeSpline(CPoint *pts, CPoint *p, int n);

	// Do draw spline.
	static void DoGenSpline(LPPOINT points,int nCount, CArray<CPoint, CPoint> &m_Points, const BOOL &bClose = TRUE);

	// Calculate angle between two line.
	// p1, p2 --  line first points.
	// p3, p4 --  line second points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Angle Between Tow Line, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		p1---Specifies A CPoint type value.  
	//		p2---Specifies A CPoint type value.  
	//		p3---Specifies A CPoint type value.  
	//		p4---Specifies A CPoint type value.
	static double CalcAngleBetweenTowLine(CPoint p1, CPoint p2, CPoint p3, CPoint p4);

	// Obtain distance from point to line, it will considering the outline state.
	// ptCheck -- point for checking.
	// ptEnd -- end point of line.
	// ptStart -- start point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance From Point To Line, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptCheck---ptCheck, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.
	static double GetDistanceFromPointToLine(const FOPPoint& ptCheck, const FOPPoint& ptEnd, const FOPPoint& ptStart);

	// Obtain distance from point to a line segment, it will not considering the outline state.
	// ptCheck -- point for checking.
	// ptEnd -- end point of line.
	// ptStart -- start point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance From Point To Segment, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptCheck---ptCheck, Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	static double GetDistanceFromPointToSegment(const FOPPoint& ptCheck, const FOPPoint& ptStart, const FOPPoint& ptEnd);

	// Obtain angle within 3 points.
	// Uses the dot-product rule to find the angle (radians) between ab and bc
	// a -- first point.
	// b -- second point
	// c -- the third point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle From3 Point, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		a---Specifies A integer value.  
	//		b---Specifies A integer value.  
	//		c---Specifies A integer value.
	static double GetAngleFrom3Pt(const FOPPoint& a, const FOPPoint& b, const FOPPoint& c);

	// Draw XOR rect.
	// pDC -- pointer of DC.
	// r -- rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Xor Rectangle, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		cr---Specifies A CRect type value.
	static void DrawXorRect(CDC *pDC,CRect& cr);

	// Convert degrees to radians.
	// x -- degree
	
	//-----------------------------------------------------------------------
	// Summary:
	// Degrees To Radians, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		x---Specifies a double x object(Value).
	static double DegreesToRadians(double x);

	
	// Calculate the point on line by a ratio value
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Calculate Point On Line, .
	// This member function is a static function.
	//		Returns A POINT value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies a POINT ptStart object(Value).  
	//		ptEnd---ptEnd, Specifies a POINT ptEnd object(Value).  
	//		ratio---Specifies a double ratio object(Value).
	static POINT FOPCalcPointOnLine(POINT ptStart, POINT ptEnd, double ratio);

	// Convert radians to degree.
	// a -- angle value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Radians To Degrees, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		a---Specifies a double a object(Value).
	static double RadiansToDegrees(double a);

	// Get max bounding rectangle.
	// rect1 -- first rectangle for checking.
	// rect2 -- second rectangle for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle Extend, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		rect1---Specifies A CRect type value.  
	//		rect2---Specifies A CRect type value.
	static CRect GetMaxRectExt(CRect rect1, CRect rect2);

	static FOPRect GetMultiRects(FOPRect *pRects, int nCount);
	static void MergeDuplicateLineSegmentsF(FOPointsArray &pts, float mergeThreshold);
	static void RemoveDupPoints(FOPointsArray &pts);
	// Merge same line points.
	// mpSpot -- spot points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Merge Same Line Points, .
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		mpSpot---mpSpot, A pointer to the CPoint> or NULL if the call failed.
	static void MergeSameLinePoints(FOPointsArray& mpSpot);

	// Get the icon handle from an exe or dll file.
	// strFile -- icon file name.
	// nIconIndex -- icon index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Icon From File, Call this function to read a specified number of bytes from the archive.
	// This member function is a static function.
	//		Returns A HICON value (Object).  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.  
	//		nIconIndex---Icon Index, Specifies A integer value.
	static HICON LoadIconFromFile(CString strFile,int nIconIndex);

	// Round value.
	// dValue -- value for round
	
	//-----------------------------------------------------------------------
	// Summary:
	// Round Value, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).
	static int RoundValue(double dValue);

	// Round value.
	// dValue -- value for round
	
	//-----------------------------------------------------------------------
	// Summary:
	// Round Value, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		dValue---dValue, Specifies a double dValue object(Value).
	static double XRoundValue(double dValue);


	// Convert rectangle to points.
	// rc -- rectangle for converting.
	// arPts -- points that converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Rectangle To Pts, .
	// This member function is a static function.
	// Parameters:
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		CPoint>&arPts---Point>&ar Pts, Specifies A CPoint type value.
	static void ConvertRectToPts(const FOPRect &rc, CArray<CPoint, CPoint>&arPts);

	// Convert rectangle to points.
	// rc -- rectangle for converting.
	// pts -- points that converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Rectangle To Pts2, .
	// This member function is a static function.
	// Parameters:
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		*pts---A pointer to the CPoint  or NULL if the call failed.
	static void ConvertRectToPts2(const FOPRect &rc, CPoint *pts);

	// Convert radius to degree.
	// angle -- angle for converting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert_rad2deg, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		angle---Specifies a double angle object(Value).
	static double Convert_rad2deg(double angle);

	// Convert degree to radius.
	// degree -- degree for convert
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert_deg2rad, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		degree---Specifies a double degree object(Value).
    static double Convert_deg2rad(double degree);

	// Convert radius to gradient.
	// radius -- radius
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert_rad2gra, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		radius---Specifies a double radius object(Value).
    static double Convert_rad2gra(double radius);

	// Finds greatest common divider using Euclid's algorithm.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find G C D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		a---Specifies A integer value.  
	//		b---Specifies A integer value.
	static int FindGCD(int a, int b);

	// Tests if angle a is between a1 and a2. a, a1 and a2 must be in the 
	//range between 0 and 2*PI.
	// All angles in rad.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Angle Between, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		angle---Specifies a double angle object(Value).  
	//		angle1---Specifies a double angle1 object(Value).  
	//		angle2---Specifies a double angle2 object(Value).  
	//		reversed---Specifies A Boolean value.
    static bool IsAngleBetween(double angle,
                               double angle1, double angle2,
                               bool reversed);

	// Corrects the given angle to the range of 0-2*Pi.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Angle, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		angle---Specifies a double angle object(Value).
	static double CorrectAngle(double angle);


	// return The angle that needs to be added to a1 to reach a2.
	//        Always positive and less than 2*pi.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle Difference, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		angle1---Specifies a double angle1 object(Value).  
	//		angle2---Specifies a double angle2 object(Value).
	static double GetAngleDifference(double angle1, double angle2);


	// Makes a text constructed with the given angle readable. Used
	// for dimension texts and for mirroring texts.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Angle Readable, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		angle---Specifies a double angle object(Value).  
	//		readable---Specifies A Boolean value.  
	//		corrected---A pointer to the bool or NULL if the call failed.
	static double MakeAngleReadable(double angle, bool readable=true,
                                    bool* corrected=NULL);

	// return true: if the given angle is in a range that is readable 
	// for texts created with that angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Angle Readable, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		angle---Specifies a double angle object(Value).
    static bool IsAngleReadable(double angle);


	// retval true The two angles point in the same direction.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Same Direction, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		dir1---Specifies a double dir1 object(Value).  
	//		dir2---Specifies a double dir2 object(Value).  
	//		tol---Specifies a double tol object(Value).
	static bool IsSameDirection(double dir1, double dir2, double tol);


	// Compares two double values with a tolerance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cmp Double, .
	// This member function is a static function.
	//		Returns A Boolean value.  
	// Parameters:
	//		v1---Specifies a double v1 object(Value).  
	//		v2---Specifies a double v2 object(Value).  
	//		tol---Specifies a double tol = 0.001 object(Value).
	static bool CmpDouble(double v1, double v2, double tol = 0.001);

	// Fill gradient
	// pDC -- pointer of the DC.
	// rcPos -- position for drawing
	// crStart -- gradient start color.
	// crEnd -- gradient end color.
	// nType -- type of the gradient,it must be one of the following value:
	// enum FO_GRADIENT_TYPE
	// {
	// 	GRADIENT_HORZ_TOP_BOTTOM = 0,
	// 	GRADIENT_HORZ_BOTTOM_TOP,	
	// 	GRADIENT_VERT_LEFT_RIGHT,
	// 	GRADIENT_VERT_RIGHT_LEFT,
	// 	GRADIENT_HORZ_CENTER_OUT,
	// 	GRADIENT_HORZ_CENTER_IN,
	// 	GRADIENT_VERT_MIDDLE_OUT,
	// 	GRADIENT_VERT_MIDDLE_IN,
	// 	GRADIENT_CORNER_TOP_LEFT,
	// 	GRADIENT_CORNER_RIGHT_TOP,
	// 	GRADIENT_CORNER_RIGHT_BOTTOM,
	// 	GRADIENT_CORNER_BOTTOM_LEFT,
	// 	GRADIENT_TITLE_OUT,
	// 	GRADIENT_TITLE_IN,
	// 	GRADIENT_ELLIPSE_OUT,
	// 	GRADIENT_ELLIPSE_IN,
	// 	GRADIENT_ANGLE_45,
	// 	GRADIENT_ANGLE_135,
	// 	GRADIENT_ANGLE_225,
	// 	GRADIENT_ANGLE_315
	// };
	// pRgn -- region pointer for clip
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Gradient With Type, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		crStart---crStart, Specifies A 32-bit COLORREF value used as a color value.  
	//		crEnd---crEnd, Specifies A 32-bit COLORREF value used as a color value.  
	//		nType---nType, Specifies A integer value.  
	//		*pRgn---*pRgn, A pointer to the CRgn  or NULL if the call failed.
	static void FillGradientWithType(CDC *pDC,CRect rcPos, COLORREF crStart, COLORREF crEnd, 
		int nType,CRgn *pRgn = NULL);

	// Calculate bound rect.
	// points -- points for checking.
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static CRect GetBoundRect(LPPOINT points,int nCount);

	// Calculate bound rect.
	// points -- points for checking.
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static CRect GetBoundRectExt(CPoint *points,int nCount);

	// Calculate bound rect.
	// points -- points for checking.
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static CRect GetBoundRect(LPFOFLOAT points,int nCount);

	// Calculate bound rect.
	// points -- points for checking.
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static CRect XGetBoundRect(FOPFloat* points,int nCount);

	// Calculate bound rect.
	// m_arPoints -- points array
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*m_arPoints---*m_arPoints, A pointer to the CPoint>  or NULL if the call failed.
	static CRect GetBoundRect(CArray<CPoint,CPoint> *m_arPoints);

	// Get text extend.
	static CSize FGetTextExtent(CDC* pDC, const CString& text, const int &nLen = 0);

	// Select object
	static HGDIOBJ FSelectObject(CDC* pDC, HGDIOBJ hObj);

	// Select clip region
	static int FSelectClipRgn(CDC* pDC, HRGN hRgn, int nMode);

	// Convert close bezier point to polygon point.
	// arPoints -- converted points.
	// ppts -- bezier points.
	// nCount -- count of bezier points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Bezier Polygon, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&arPoints---&arPoints, Specifies A CPoint type value.  
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static void ConvertBezierPolygon(CArray<CPoint,CPoint> &arPoints,LPPOINT ppts, int nCount);

	// Create curve points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Split Curve Points, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&arPoints---&arPoints, Specifies A CPoint type value.  
	//		x0---Specifies a double x0 object(Value).  
	//		y0---Specifies a double y0 object(Value).  
	//		x1---Specifies a double x1 object(Value).  
	//		y1---Specifies a double y1 object(Value).  
	//		x2---Specifies a double x2 object(Value).  
	//		y2---Specifies a double y2 object(Value).  
	//		x3---Specifies a double x3 object(Value).  
	//		y3---Specifies a double y3 object(Value).
	static void SplitCurvePoints(CArray<CPoint,CPoint> &arPoints,double x0, double y0, double x1, 
		double y1, double x2, double y2, double x3, double y3);

	// Draw radio button
	// pDC -- pointer of DC
	// rect -- rectangle
	// bSelect -- selected state
	// b3D -- with 3d look or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Radio, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bSelect---bSelect, Specifies A Boolean value.  
	//		b3D---b3D, Specifies A Boolean value.
	static void DrawRadio(CDC* pDC, CRect rect, BOOL bSelect, BOOL b3D);

	// Get wheel mouse scroll lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Wheel Mouse Scroll Lines, Returns the specified value.
	// This member function is a static function.
	//		Returns a UINT type value.
	static UINT GetWheelMouseScrollLines();

	// nType:   0 -> all symbols allowed
	//          1 -> alphanumeric
	//          2 -> alpha
	//          3 -> numeric
	
	//-----------------------------------------------------------------------
	// Summary:
	// Random String, .
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		nLength---nLength, Specifies A integer value.  
	//		nType---nType, Specifies A integer value.
	static CString RandomString( int nLength, int nType );

	// Change point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Change Point, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		point0---Specifies A integer value.  
	//		point1---Specifies A integer value.  
	//		point2---Specifies A integer value.
	static int FOChangePoint(POINT point0, POINT point1, POINT point2);
	
	// Draw focus rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Focus Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.  
	//		bShow---bShow, Specifies A Boolean value.  
	//		rgbFocus---rgbFocus, Specifies A 32-bit COLORREF value used as a color value.  
	//		nPenStyle---Pen Style, Specifies A integer value.  
	//		nPenWidth---Pen Width, Specifies A integer value.  
	//		bDrawEdge---Draw Edge, Specifies A Boolean value.
	static BOOL FocusRect(CDC*     pDC,
               CRect    rect,
               BOOL     bShow,
               COLORREF rgbFocus,
               int      nPenStyle,
               int      nPenWidth,
               BOOL     bDrawEdge);

	// Calculate area of rectangle.
	// rect -- rectangle for Calculate
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Area Of, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		rect---Specifies A CRect type value.
	static int	CalcAreaOf(CRect rect);
	
	// Create points to simulate ellipse using beziers
	// r -- rectangle.
	// p -- corner point.
	// cCtrlPt -- points that converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Round Rectangle To Bezier, .
	// This member function is a static function.
	// Parameters:
	//		r---Specifies A CRect type value.  
	//		p---Specifies A CPoint type value.  
	//		cCtlPt---Ctl Point, A pointer to the CPoint or NULL if the call failed.
	static void RoundRectToBezier(CRect& r,CPoint& p, CPoint* cCtlPt);

	// Generate color icon.
	// clrIcon -- color of icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Color Icon, .
	// This member function is a static function.
	//		Returns A HICON value (Object).  
	// Parameters:
	//		clrIcon---clrIcon, Specifies A 32-bit COLORREF value used as a color value.
	static HICON GenerateColorIcon(COLORREF clrIcon);

	// Generate DIB;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate L B D I B, .
	// This member function is a static function.
	//		Returns A HBITMAP value (Object).
	static HBITMAP GenLBDIB();

	// Replace string.
	// strTarget -- result target string.
	// strFind -- the replaced string.
	// strReplace -- replace string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace String, .
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		strTarget---strTarget, Specifies A CString type value.  
	//		strFind---strFind, Specifies A CString type value.  
	//		strReplace---strReplace, Specifies A CString type value.
	static CString ReplaceString(CString& strTarget, CString strFind, CString strReplace);

	// MessageBox.
	// strMsg -- message string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Message Box Extend, .
	// This member function is a static function.
	// Parameters:
	//		strMsg---strMsg, Specifies A CString type value.  
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static void MessageBoxExt(CString strMsg,UINT nType);

	// Convert float to cstring.
	static CString FloatToCStr(double a, int digit);

	// Get text by shorten the length.
	static CString GetTextWithLength(const TCHAR *s, int MaxLen);

	// Draw rotate text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rotate Text, Draws current object to the specify device.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strString---strString, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nCount---nCount, Specifies A integer value.  
	//		rect---Specifies A CRect type value.  
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lAngle---lAngle, Specifies A 32-bit LONG signed integer.  
	//		lpRectClip---Rectangle Clipboard, Specifies a LPRECT lpRectClip = NULL object(Value).
	static int DrawRotateText(CDC* pDC, LPCTSTR strString, int nCount, CRect rect, UINT nFormat, 
		LONG lAngle, LPRECT lpRectClip = NULL);

	// Checking if two points are near.
	// p1 -- first point for checking.
	// p2 -- second point for checking.
	// dNearRange -- range for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Two Points Near, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&p1---Specifies A integer value.  
	//		&p2---Specifies A integer value.  
	//		dNearRange---Near Range, Specifies a double dNearRange object(Value).
	static BOOL IsTwoPointsNear(const FOPPoint &p1, const FOPPoint &p2, double dNearRange);

	////////////////////////////////
	// Line and points.
	////////////////////////////////

	// Get angle,it will return 1/100 degree,value range -18000..17999
	// ptPnt -- point of angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.
	static long GetAngle(const CPoint& ptPnt);

	// Get angle,it will return 1/100 degree,value range -18000..17999
	// ptPnt -- point of angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.
	static long XGetAngle(const FOPFloat& ptPnt);

	// Get angle sector.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle Sector, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.
	static int GetAngleSector(long nAngle);

	// Norm angle 0.00..35999,it is 1/100 degree.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Norm Angle360, .
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		a---Specifies A 32-bit long signed integer.
	static long NormAngle360(long a);
	static double dogetSweep(double startAngle, double endAngle, BOOL reversed);
	// Norm angle -18000..17999,it is 1/100 degree.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Norm Angle180, .
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		a---Specifies A 32-bit long signed integer.
	static long NormAngle180(long a);

	// If two lines intersect return TRUE.
	// ptLine0Start, ptLine0End -- first line point.
	// ptLine1Start, ptLine1End -- second line point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lines Intersect, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptLine0Start---Line0 Start, Specifies a POINT ptLine0Start object(Value).  
	//		ptLine0End---Line0 End, Specifies a POINT ptLine0End object(Value).  
	//		ptLine1Start---Line1 Start, Specifies a POINT ptLine1Start object(Value).  
	//		ptLine1End---Line1 End, Specifies a POINT ptLine1End object(Value).
	static BOOL LinesIntersect(POINT ptLine0Start, POINT ptLine0End, 
		POINT ptLine1Start, POINT ptLine1End);

	// Get the nearest point on line, it will considering the outline state
	// rPoint -- point to be found.
	// ptLineStart -- start point of the line.
	// ptLineEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Nearest Point On Line, .
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		rPoint---rPoint, Specifies A CPoint type value.  
	//		ptLineStart---Line Start, Specifies A CPoint type value.  
	//		ptLineEnd---Line End, Specifies A CPoint type value.
	static CPoint NearestPointOnLine( const CPoint& rPoint,CPoint ptLineStart,CPoint ptLineEnd);

	// Is points rectangle.
	static BOOL IsRect(LPPOINT pts, int nCount);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		pt2---Specifies A CPoint type value.
	// Distance of two points.
	// pt1 -- first point for Calculate.
	// pt2 -- second point for Calculate.
	static double Distance(CPoint pt1,CPoint pt2);

	//-----------------------------------------------------------------------
	// Summary:
	// Distance, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		pt2---Specifies A CPoint type value.
	// Distance of two points.
	// pt1 -- first point for Calculate.
	// pt2 -- second point for Calculate.
	static double XDistance(FOPFloat pt1,FOPFloat pt2);

	// Obtain the distance of the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon Length, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		rPolygon---rPolygon, Specifies a const FOPPolygon& rPolygon object(Value).
	static double GetPolygonLength( const FOPPolygon& rPolygon );

	// Obtain the length of many points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Line Length, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static double CalcLineLength(LPPOINT pts,int nCount);

	// Obtain point at a polyline, and dist is the short distance.
	// points -- points.
	// pointCount -- point count.
	// dist -- distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		pointCount---pointCount, Specifies A integer value.  
	//		dist---Specifies a double dist object(Value).
	static FOPPoint XGetPosition(LPPOINT points, int pointCount, double dist);

	// Create virtual device bitmap.
	static HBITMAP CreateVirDevBitmap(CDC *pDC, long nDX, long nDY,
									   int nBitCount = 24);

	// Obtain the length of many points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Line Length2, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	static double CalcLineLength2(CArray<CPoint,CPoint> *arPoints);

	// Is all points orthogonal lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Orthogonal Points, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static BOOL IsOrthogonalPoints(LPPOINT pts,int nCount);

	// Is all points orthogonal lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Orthogonal Points2, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*arPoints---*arPoints, A pointer to the CPoint>  or NULL if the call failed.
	static BOOL IsOrthogonalPoints2(CArray<CPoint,CPoint> *arPoints);

	// Check if a point lies on a line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Orthogonal Line, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		&ptTest---&ptTest, Specifies A integer value.
	static BOOL CheckOrthogonalLine( const FOPPoint &ptStart, const FOPPoint &ptEnd, const FOPPoint &ptTest );

	// Create bitmap with 32 bits
	// szImage -- size of image.
	// pBits -- bits of bitmap images.
	static HBITMAP Create32Bitmap(const CSize& szImage, void** pBits);


	// Create bitmap with 24 bits
	// szImage -- size of image.
	// pBits -- bits of bitmap images.
	static HBITMAP Create24Bitmap(const CSize& szImage, void** pBits);

	// Draw button with glass feature mode.
	static void DrawButtonGlassMode(CDC& dc, CRect rect, UINT uState);

	// Generate screen shot
	static BOOL DoGenScreenshot(CBitmap& bmpOut, CWnd* pWnd = NULL);

	//-----------------------------------------------------------------------
	// Summary:
	// Slope, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		pt2---Specifies A CPoint type value.
	// Slope of two points.
	// pt1 -- first point for Calculate.
	// pt2 -- second point for Calculate.
	static double Slope(CPoint pt1,CPoint pt2);

	// Get point on line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point On Line, .
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		pt1---Specifies A CPoint type value.  
	//		p2---Specifies A CPoint type value.  
	//		len---Specifies A integer value.  
	//		maxlen---Specifies A integer value.
	static CPoint PointOnLine(CPoint pt1, CPoint p2, double len, double maxlen);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		desc1---Specifies a FOP_LineDesc desc1 object(Value).  
	//		desc2---Specifies a FOP_LineDesc desc2 object(Value).
	// Get intersection of two line.
	static CPoint Intersection(FOP_LineDesc desc1,FOP_LineDesc desc2);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rc1---Specifies A CRect type value.  
	//		rc2---Specifies A CRect type value.
	// Is two rectangles intersection.
	static BOOL Intersection(CRect rc1, CRect rc2);
	
	// Get intersection point of two line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection Point, .
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		ptLine0Start---Line0 Start, Specifies a POINT ptLine0Start object(Value).  
	//		ptLine0End---Line0 End, Specifies a POINT ptLine0End object(Value).  
	//		ptLine1Start---Line1 Start, Specifies a POINT ptLine1Start object(Value).  
	//		ptLine1End---Line1 End, Specifies a POINT ptLine1End object(Value).
	static CPoint IntersectionPoint(POINT ptLine0Start, POINT ptLine0End, POINT ptLine1Start, POINT ptLine1End);

	// If two lines intersection, return the intersection point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection Line, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptLine0Start---Line0 Start, Specifies a POINT ptLine0Start object(Value).  
	//		ptLine0End---Line0 End, Specifies a POINT ptLine0End object(Value).  
	//		ptLine1Start---Line1 Start, Specifies a POINT ptLine1Start object(Value).  
	//		ptLine1End---Line1 End, Specifies a POINT ptLine1End object(Value).  
	//		rIntersectionX---Intersection X, Specifies a double& rIntersectionX object(Value).  
	//		rIntersectionY---Intersection Y, Specifies a double& rIntersectionY object(Value).
	static BOOL IntersectionLine( POINT ptLine0Start, POINT ptLine0End, POINT ptLine1Start,
		POINT ptLine1End, double& rIntersectionX, double& rIntersectionY );

	// If two lines intersection, return the intersection point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection Line, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptLine0Start---Line0 Start, Specifies a POINT ptLine0Start object(Value).  
	//		ptLine0End---Line0 End, Specifies a POINT ptLine0End object(Value).  
	//		ptLine1Start---Line1 Start, Specifies a POINT ptLine1Start object(Value).  
	//		ptLine1End---Line1 End, Specifies a POINT ptLine1End object(Value).  
	//		rIntersection---rIntersection, Specifies A CPoint type value.
	static BOOL IntersectionLine( POINT ptLine0Start, POINT ptLine0End, POINT ptLine1Start,
		POINT ptLine1End, CPoint& rIntersection );

	// Intersection rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcRect---rcRect, Specifies A CRect type value.  
	//		ptLineStart---Line Start, Specifies A CPoint type value.  
	//		ptLineEnd---Line End, Specifies A CPoint type value.  
	//		ptIntersectionLineStart---Intersection Line Start, Specifies A CPoint type value.  
	//		ptIntersectionLineEnd---Intersection Line End, Specifies A CPoint type value.
	static BOOL IntersectionRect( const CRect& rcRect, CPoint ptLineStart, CPoint ptLineEnd,
		CPoint& ptIntersectionLineStart,CPoint& ptIntersectionLineEnd);

	// Angle of two point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Angle From Point, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt0---Specifies A CPoint type value.  
	//		pt1---Specifies A CPoint type value.
	static double AngleFromPoint(CPoint pt0,CPoint pt1);

	// Angle of two point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Angle From Point, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt0---Specifies A CPoint type value.  
	//		pt1---Specifies A CPoint type value.
	static double XAngleFromPoint(FOPFloat pt0,FOPFloat pt1);

	// Line angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line Angle, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&pt1---Specifies A integer value.  
	//		&pt2---Specifies A integer value.
	static double FOPLineAngle(const FOPPoint &pt1, const FOPPoint &pt2);

	// Obtain the index point of point in a polygon.
	// pts -- points of polygon.
	// ptCheck -- point for checking.
	// bOutLine -- out line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point On Polygon, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		*pts---A pointer to the CPoint>  or NULL if the call failed.  
	//		&ptCheck---&ptCheck, Specifies A CPoint type value.  
	//		&bOutLine---Out Line, Specifies A Boolean value.
	static int GetPointOnPoly(CArray<CPoint,CPoint> *pts, const CPoint &ptCheck, const BOOL &bOutLine = FALSE);

	// Obtain the index point of point in a polygon.
	// pts -- points of polygon.
	// nCount -- count of points
	// ptCheck -- point for checking.
	// bOutLine -- out line or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point On Poly2, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&ptCheck---&ptCheck, Specifies A CPoint type value.  
	//		&bOutLine---Out Line, Specifies A Boolean value.
	static int GetPointOnPoly2(LPPOINT pts,int nCount, const CPoint &ptCheck, const BOOL &bOutLine = FALSE);

	// Obtain the center point of polygon.
	// dPercent -- from 0 -- 100
	static CPoint GetPolyPointByPercent(LPPOINT pts,int nCount, int &nPtIndex, double dPercent = 50.0);

	// Obtain the percent of point.
	static double GetPolyPointPercent(LPPOINT pts,int nCount, int nPtIndex, const CPoint &ptCheck);

	// Obtain chui zhi line point.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line.
	// ptFirst -- first point of chui zhi line.
	// nWidth -- default offset width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chui Zhi Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptFirst---&ptFirst, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.
	static CPoint GetChuiZhiPoint(const CPoint &ptLineStart, const CPoint &ptLineEnd, const CPoint &ptFirst, const int &nWidth = 20);

	// Obtain chui zhi line point.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line.
	// ptFirst -- first point of chui zhi line.
	// nWidth -- default offset width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Chui Zhi Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptFirst---&ptFirst, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.
	static FOPFloat XGetChuiZhiPoint(const FOPFloat &ptLineStart, const FOPFloat &ptLineEnd, const FOPFloat &ptFirst, const int &nWidth = 20);

	// Obtain Ping Xing line point.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line.
	// ptPXFirst -- first point of ping xing line.
	// ptPXEnd -- end point of ping xing ling.
	// nWidth -- default offset width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ping Xing Point, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptPXFirst---P X First, Specifies A CPoint type value.  
	//		&ptPXEnd---P X End, Specifies A CPoint type value.  
	//		&nWidth---&nWidth, Specifies A integer value.
	static void GetPingXingPoint(const CPoint &ptLineStart, const CPoint &ptLineEnd, CPoint &ptPXFirst,
		CPoint &ptPXEnd, const int &nWidth = 20);

	// Obtain the ping xing line segment.
	// ptStart -- start point of line for checking.
	// ptEnd -- end point of line for checking.
	// ptResultStart -- the output line start point.
	// ptResultEnd -- the output line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ping Xing Line Segment, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		&ptResultStart---Result Start, Specifies A CPoint type value.  
	//		&ptResultEnd---Result End, Specifies A CPoint type value.  
	//		&dDistance---&dDistance, Specifies a const double &dDistance object(Value).  
	//		&bUp---&bUp, Specifies A Boolean value.
	static void GetPingXingLineSegment(const CPoint &ptStart, const CPoint &ptEnd,
		CPoint &ptResultStart, CPoint &ptResultEnd,
		const double &dDistance, const BOOL &bUp = TRUE);

	// Find dui ying point across the line.
	// start -- first point of the line.
	// end -- end point of the line
	// pt -- point to find
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Dui Ying Point, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		start---Specifies A CPoint type value.  
	//		end---Specifies A CPoint type value.  
	//		pt---Specifies A CPoint type value.
	static CPoint FindDuiYingPoint(CPoint start, CPoint end, CPoint pt);

	// Obtain the point offset from end point.
	// ptStart -- start point of line.
	// ptEnd -- end point of line
	// fOffsetFromEnd -- offset distance from end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point By Offset, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		fOffsetFromEnd---Offset From End, Specifies A float value.
	static FOPPoint GetPointByOffset( const FOPPoint &ptStart, const FOPPoint &ptEnd, float fOffsetFromEnd );

	// Obtain the point offset from end point.
	// ptStart -- start point of line.
	// ptEnd -- end point of line
	// fOffsetFromEnd -- offset distance from end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point By Offset, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		fOffsetFromEnd---Offset From End, Specifies A float value.
	static FOPFloat XGetPointByOffset( const FOPFloat &ptStart, const FOPFloat &ptEnd, float fOffsetFromEnd );

	// Calculate point at a line, and it has the distance to ptEnd.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line
	// nDisToPt1 -- distance to start point of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Point On Line, .
	// This member function is a static function.
	//		Returns A POINT value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies a POINT ptStart object(Value).  
	//		ptEnd---ptEnd, Specifies a POINT ptEnd object(Value).  
	//		nDisToPt1---Distance To Pt1, Specifies A integer value.
	static POINT CalcPointOnLine(POINT ptStart, POINT ptEnd, int nDisToPt1);

	// Obtain the nearest point on line, it will not considering the outline state
	// ptLineStart -- first point of the line.
	// ptLineEnd -- end point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point On Line, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetNearestPointOnLine(const CPoint &ptLineStart, const CPoint &ptLineEnd, 
		const CPoint &ptHit, CPoint &result);

	// Obtain the nearest point on line, it will not considering the outline state
	// ptLineStart -- first point of the line.
	// ptLineEnd -- end point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point On Line, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL XGetNearestPointOnLine(const FOPFloat &ptLineStart, const FOPFloat &ptLineEnd, 
		const FOPFloat &ptHit, FOPFloat &result);

	// is point inside 2d polygon.
	// p -- point to hit test.
	// numpoints -- number of the points.
	// data -- points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Polygon, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		p---Specifies A CPoint type value.  
	//		numpoints---Specifies A integer value.  
	//		*data---A pointer to the CPoint  or NULL if the call failed.
	static int PointInPolygon(CPoint p, int numpoints, CPoint *data);

	// Compute angle of the line
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Line Angle, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A CPoint type value.  
	//		ptEnd---ptEnd, Specifies A CPoint type value.
	static double ComputeLineAngle(CPoint ptStart,CPoint ptEnd);

	// Return:  0->Right
	//			1->Bottom
	//			2->Left
	//			3->Top
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direction, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	static int GetDirection(const CPoint &ptStart,const CPoint &ptEnd);

	// Limit point within rectangle.
	// rPt -- point to limit
	// rcArea -- limit area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit To Work Area, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPt---rPt, Specifies A CPoint type value.  
	//		&rcArea---&rcArea, Specifies A CRect type value.
	static BOOL LimitToWorkArea(CPoint& rPt, const CRect &rcArea);

	// Get point.
	// aRect -- position of the rectangle.
	// eRP -- it is one of the following value:
	// RP_LT, RP_MT, RP_RT, RP_LM, RP_MM, RP_RM, RP_LB, RP_MB, RP_RB
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		&aRect---&aRect, Specifies A CRect type value.  
	//		eRP---R P, Specifies a FO_RECT_POINT eRP object(Value).
	static CPoint GetPoint(const CRect &aRect, FO_RECT_POINT eRP);

	// Calc bitmap fill sizes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Calculate Bitmap Fill Sizes, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		rStartOffset---Start Offset, Specifies a FOPSize& rStartOffset object(Value).  
	//		rBmpOutputSize---Bitmap Output Size, Specifies a FOPSize&    rBmpOutputSize object(Value).  
	//		rOutputRect---Output Rectangle, Specifies a const FOPRect&  rOutputRect object(Value).  
	//		pFillBitmap---Fill Bitmap, A pointer to the CFOBitmap or NULL if the call failed.  
	//		rBmpSize---Bitmap Size, Specifies a const FOPSize&  rBmpSize object(Value).  
	//		rBmpPerCent---Bitmap Per Cent, Specifies a const FOPSize&  rBmpPerCent object(Value).  
	//		rBmpOffPerCent---Bitmap Off Per Cent, Specifies a const FOPSize&  rBmpOffPerCent object(Value).  
	//		bBmpLogSize---Bitmap Logical Size, Specifies A Boolean value.  
	//		bBmpTile---Bitmap Tile, Specifies A Boolean value.  
	//		bBmpStretch---Bitmap Stretch, Specifies A Boolean value.  
	//		eBmpRectPoint---Bitmap Rectangle Point, Specifies A integer value.
	static void DoCalcBmpFillSizes( FOPSize&	rStartOffset,
                          FOPSize&				rBmpOutputSize,
                          const FOPRect&		rOutputRect,
						  CFOBitmap*			pFillBitmap,
                          const FOPSize&		rBmpSize,
                          const FOPSize&		rBmpPerCent,
                          const FOPSize&		rBmpOffPerCent,
                          BOOL					bBmpLogSize,
                          BOOL					bBmpTile,
                          BOOL					bBmpStretch,
                          FO_RECT_POINT			eBmpRectPoint );

	
	// Draw select gray rect
	// pDC-- pointer of the DC.
	// rect -- rectangle for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Shade Rectangle, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	static void DrawShadeRect(CDC *pDC, CRect& rect);

	// Convert UTF8 to string.
	static int UTF8ToString (LPCSTR lpSrc, LPTSTR& lpTag, int nLength = -1);

	// Convert String to UTF8
	static int StringToUTF8 (LPCTSTR lpSrc, LPSTR& lpTag, int nLength = -1);

	// Draw tab combobox item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcItem---rcItem, Specifies A CRect type value.  
	//		strEntry---strEntry, Specifies A CString type value.  
	//		bDisplayCol---Display Column, Specifies A Boolean value.  
	//		nDisplayCol---Display Column, Specifies A integer value.  
	//		nTabCount---Tab Count, Specifies A integer value.  
	//		parTabStops---Tab Stops, Specifies a LPINT parTabStops object(Value).  
	//		crGridLine---Grid Line, Specifies A 32-bit COLORREF value used as a color value.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.  
	//		crText---crText, Specifies A 32-bit COLORREF value used as a color value.
	static void DrawItem(CDC* pDC,const CRect& rcItem,const CString& strEntry,BOOL bDisplayCol,
		int nDisplayCol,int nTabCount,LPINT parTabStops,COLORREF crGridLine,COLORREF crBack,COLORREF crText);

	// Measure height of item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Measure Height, .
	// This member function is a static function.
	// Parameters:
	//		strEntry---strEntry, Specifies A CString type value.  
	//		nItemHeight---Item Height, Specifies A integer value.  
	//		bDisplayCol---Display Column, Specifies A Boolean value.  
	//		nDisplayCol---Display Column, Specifies A integer value.  
	//		nTabCount---Tab Count, Specifies A integer value.
	static void MeasureHeight(const CString& strEntry,unsigned int& nItemHeight,BOOL bDisplayCol,
		int nDisplayCol,int nTabCount);

		// Pre Multipled alpha
	static	BOOL PreAlpha(HBITMAP hbmp, BOOL bAutoCheckPremlt);


	// Get max col width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Column Width, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pszCol---pszCol, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nColCount---Column Count, Specifies A integer value.  
	//		anMaxColWidth---Maximize Column Width, Specifies a LPINT anMaxColWidth object(Value).
	static void GetMaxColWidth(CDC* pDC, LPCTSTR pszCol, int nColCount, LPINT anMaxColWidth);

	// Get distance of point to a specify line.
	// maStart -- start point of the line.
	// maEnd -- end point of the line.
	// rPtX -- point's x value.
	// rPtY -- point's y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point To Line Distance, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&maStart---&maStart, Specifies A CPoint type value.  
	//		&maEnd---&maEnd, Specifies A CPoint type value.  
	//		rPtX---Point X, Specifies a const double& rPtX object(Value).  
	//		rPtY---Point Y, Specifies a const double& rPtY object(Value).
	static double GetPointToLineDistance( const CPoint &maStart,const CPoint &maEnd,const double& rPtX,
		const double& rPtY );

	// Intersect two lines.
	// pt1Start -- start point of the first segment.
	// pt2Start -- the second point of the second segment.
	// pt1End -- end point of the first segment.
	// pt2End -- end point of the second segment.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Intersect, .
	// This member function is a static function.
	//		Returns A POINT value (Object).  
	// Parameters:
	//		pt1Start1---pt1Start1, Specifies a POINT pt1Start1 object(Value).  
	//		pt2Start1---pt2Start1, Specifies a POINT pt2Start1 object(Value).  
	//		pt1End2---pt1End2, Specifies a POINT pt1End2 object(Value).  
	//		pt2End2---pt2End2, Specifies a POINT pt2End2 object(Value).
	static POINT LineIntersect(POINT pt1Start1, POINT pt2Start1, POINT pt1End2, POINT pt2End2);

	// Segment intersect.
	// pt1Start -- start point of the first segment.
	// pt2Start -- the second point of the second segment.
	// pt1End -- end point of the first segment.
	// pt2End -- end point of the second segment.
	// pt -- result intersect point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Segment Intersect, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt1Start---pt1Start, Specifies a POINT pt1Start object(Value).  
	//		pt2Start---pt2Start, Specifies a POINT pt2Start object(Value).  
	//		pt1End---pt1End, Specifies a POINT pt1End object(Value).  
	//		pt2End---pt2End, Specifies a POINT pt2End object(Value).  
	//		pt---Specifies a POINT& pt object(Value).
	static BOOL SegmentIntersect(POINT pt1Start, POINT pt2Start, POINT pt1End, POINT pt2End, POINT& pt);

	// Check point position on line. 
	// == 0.0 - p lies on the line defined by s1 and s2 
	// > 0.0  - p lies "above" the line
    // < 0.0  - p lies "below" the line
	// ptCheck -- point for checking.
	// pt1Start -- start point of line.
	// pt1End -- end point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point Position On Line, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptCheck---ptCheck, Specifies a const POINT& ptCheck object(Value).  
	//		pt1Start---pt1Start, Specifies a const POINT& pt1Start object(Value).  
	//		pt1End---pt1End, Specifies a const POINT& pt1End object(Value).
	static double PointPosOnLine( const POINT& ptCheck, const POINT& pt1Start, const POINT& pt1End );

	// Polygon drawing.
	// pDC -- pointer of DC.
	// lppPoints -- points for drawing.
	// lyTypes -- polygon type
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Polygon Draw, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppPoints---lppPoints, Specifies A LPPOINT Points array.  
	//		lpTypes---lpTypes, Specifies An 8-bit BYTE integer that is not signed.  
	//		cCount---cCount, Specifies A integer value.
	static void PolyDraw(CDC *pDC, CONST LPPOINT lppPoints, CONST LPBYTE lpTypes, int cCount);

	// Poly drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Polygon Draw2, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lppPoints---lppPoints, Specifies A LPPOINT Points array.  
	//		lpTypes---lpTypes, Specifies An 8-bit BYTE integer that is not signed.  
	//		cCount---cCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	static void PolyDraw2(CDC *pDC, CONST LPPOINT lppPoints, CONST LPBYTE lpTypes, int cCount, const BOOL &bClose = TRUE);

	// Re position points to a new rectangle.
	// rc -- position
	// points -- limit points.
	// count -- count of the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Limit Position Points, .
	// This member function is a static function.
	// Parameters:
	//		rc---Specifies a const RECT& rc object(Value).  
	//		points---A pointer to the POINT or NULL if the call failed.  
	//		count---Specifies A integer value.
	static void ReLimitPositionPoints(const RECT& rc, POINT* points, int count);

	// Draw transparent image.
	// pDC -- pointer of the DC
	// imgList -- image list.
	// nIndex -- index of image
	// point -- point
	// bUse -- use
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Embossed, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		imgList---imgList, Specifies a CImageList& imgList object(Value).  
	//		nIndex---nIndex, Specifies A integer value.  
	//		point---Specifies A CPoint type value.  
	//		bUse---bUse, Specifies A Boolean value.
	static void DrawEmbossed(CDC* pDC, CImageList& imgList, int nIndex, CPoint point, BOOL bUse);

	// Polygon draw path
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Polygon Draw Path, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	static void PolyDrawPath(CDC *pDC);

	// Compute arc center and radius value.
	// ptCenter -- the result center of the arc shape.
	// ptFirst -- first point of the arc
	// ptSecond -- second point of the arc.
	// ptThird -- third point of the arc
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Arc Center, .
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		&ptCenter---&ptCenter, Specifies A CPoint type value.  
	//		&ptFirst---&ptFirst, Specifies A CPoint type value.  
	//		&ptSecond---&ptSecond, Specifies A CPoint type value.  
	//		&ptThird---&ptThird, Specifies A CPoint type value.
	static CRect GenArcCenter(CPoint &ptCenter,const CPoint &ptFirst,const CPoint &ptSecond,const CPoint &ptThird);

	// Normalize angle.
	static long T_FONormalizeAngle(long lAngle);

	// Do draw arrow.
	static void DoDrawArrow(CDC *dc, const FOPRect &rect, const BOOL &bPressed);

	// Radius to angle.
	static double T_FORadToDeg(double dAngle);

	// Obtain angle.
	static long T_FOGetAngle(const POINT& ptOri, const POINT& ptEnd);

	static BOOL CheckTwoPoints(const FOPPoint &pt1, const FOPPoint &pt2);

	// Create auto size font.
	// hdc -- dc handle.
	// rcText -- position of text.
	// string -- text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Automatic Size Font, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns A HFONT value (Object).  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		&rcText---&rcText, Specifies A CRect type value.  
	//		string---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	static HFONT CreateAutoSizeFont(HDC hdc,const CRect &rcText,LPCTSTR string);

	// Do draw line.
	// pDC-- DC's pointer.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Line, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	static void DoDrawLine(CDC *pDC,const CPoint &ptStart,const CPoint &ptEnd);

	/*************************************************************************
	|*
	|* Printing and text
	|*
	\************************************************************************/

	// Create text array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		strText---strText, Specifies A CString type value.  
	//		aaLines---aaLines, Specifies A CString type value.
	static int CreateTextArray(CString strText,CStringArray& aaLines);

	// Return the Pinter paper size.
	// eUnit -- Currently eUnit must be:FOP_UINT_100s_MM or FOP_UINT_TWIP,it must be one of the following value:
	// 	enum FOP_UNIT
	// {
	// 	FOP_UINT_100S_MM,
	// 	FOP_UINT_10S_MM,
	// 	FOP_UINT_MM,
	// 	FOP_UINT_CM,
	// 	FOP_UINT_1000S_INCH,
	// 	FOP_UINT_100S_INCH,
	// 	FOP_UINT_10S_INCH,
	// 	FOP_UINT_INCH,
	// 	FOP_UINT_POINT,
	// 	FOP_UINT_TWIP,
	// 	FOP_UINT_PIXEL
	// };
	// nPaper -- paper type,it must be one of the following value:
	// 	enum FO_PAPER
	// {
	// 	FOP_PAPER_A0,
	// 	FOP_PAPER_A1,
	// 	FOP_PAPER_A2,
	// 	FOP_PAPER_A3,
	// 	FOP_PAPER_A4,
	// 	FOP_PAPER_A5,
	// 	FOP_PAPER_B4,
	// 	FOP_PAPER_B5,
	// 	FOP_PAPER_LETTER,
	// 	FOP_PAPER_LEGAL,
	// 	FOP_PAPER_TABLOID,
	// 	FOP_PAPER_USER,
	// 	FOP_PAPER_B6,
	// 	FOP_PAPER_C4,
	// 	FOP_PAPER_C5,
	// 	FOP_PAPER_C6,
	// 	FOP_PAPER_C65,
	// 	FOP_PAPER_DL,
	// 	FOP_PAPER_DIA,
	// 	FOP_PAPER_SCREEN,
	// 	FOP_PAPER_A,
	// 	FOP_PAPER_B,
	// 	FOP_PAPER_C,
	// 	FOP_PAPER_D,
	// 	FOP_PAPER_E,
	// 	FOP_PAPER_EXECUTIVE,
	// 	FOP_PAPER_LEGAL2,
	// 	FOP_PAPER_MONARCH,
	// 	FOP_PAPER_COM675,
	// 	FOP_PAPER_COM9,
	// 	FOP_PAPER_COM10,
	// 	FOP_PAPER_COM11,
	// 	FOP_PAPER_COM12,
	// 	FOP_PAPER_KAI16,
	// 	FOP_PAPER_KAI32,
	// 	FOP_PAPER_KAI32BIG,
	// 	FOP_PAPER_B4_JIS,
	// 	FOP_PAPER_B5_JIS,
	// 	FOP_PAPER_B6_JIS
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Size, Returns the specified value.
	// This member function is a static function.
	//		Returns a CSize type value.  
	// Parameters:
	//		nPaper---nPaper, Specifies a FO_PAPER nPaper object(Value).  
	//		eUnit---eUnit, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static CSize GetPaperSize( FO_PAPER nPaper,FOP_UNIT eUnit = FOP_UINT_TWIP );

	// Get paper name.
	// nPaper -- Paper type
	// return paper name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Name, Returns the specified value.
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		nPaper---nPaper, Specifies a FO_PAPER nPaper object(Value).
	static CString	GetPaperName( FO_PAPER nPaper );

	// Swap the size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// &Swap, .
	// This member function is a static function.
	//		Returns a CSize type value.  
	// Parameters:
	//		&rSize---&rSize, Specifies A CSize type value.
	static CSize &Swap(CSize &rSize);
	
	// Change landscape.
	// szSize -- input size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Landscape Swap, .
	// This member function is a static function.
	//		Returns a CSize type value.  
	// Parameters:
	//		&szSize---&szSize, Specifies A CSize type value.
	static CSize &LandscapeSwap(CSize &szSize);

	// Do draw text.
	static BOOL DoDrawText(CDC* pDC, CString strText, CRect rect, UINT uiDrawTextFlags, LPRECT lpRectClip = NULL, BOOL bNoCalcExtent = FALSE);

	// Check a point within a specify area,limit point within a specify rectangle.
	// rPos -- point to be snapped.
	// rSize -- expand size.
	// rWorkArea -- area to be limited.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Snap Insert Position, .
	// This member function is a static function.
	// Parameters:
	//		rPos---rPos, Specifies A CPoint type value.  
	//		rSize---rSize, Specifies A CSize type value.  
	//		rWorkArea---Work Area, Specifies A CRect type value.
	static void SnapInsertPos(CPoint& rPos, const CSize& rSize, const CRect& rWorkArea);

	// Get text rotate position.
	// nOriginX -- rotating origin x position.
	// nOriginY -- rotating origin y position.
	// nOrientation -- rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Rotate Position, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		nOriginX---Origin X, Specifies A 32-bit long signed integer.  
	//		nOriginY---Origin Y, Specifies A 32-bit long signed integer.  
	//		rX---rX, Specifies A 32-bit long signed integer.  
	//		rY---rY, Specifies A 32-bit long signed integer.  
	//		nOrientation---nOrientation, Specifies A integer value.
	static void GetTextRotatePos( long nOriginX, long nOriginY, long& rX, long& rY,
                           int nOrientation );

	/*************************************************************************
	|*
	|* Hit test
	|*
	\************************************************************************/

	// Rectangle touches line of polygon.
	// Is rectangle touches polygon.
	// aPoly -- a FOPPolygon object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Polygon, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPolygon(const FOPPolygon& aPoly, const FOPRect& rcHit);

	// Is rectangle touches polypolygon
	// aLine -- a FOPPolyPolygon object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Polygon, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolyPolygon& aPoly object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPolygon(const FOPPolyPolygon& aPoly, const FOPRect& rcHit);

	// Is rectangle touches line.
	// rPt1 -- start point of the line object to be hit.
	// rPt2 -- end point of the line object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Points, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPt1---rPt1, Specifies A integer value.  
	//		rPt2---rPt2, Specifies A integer value.  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPoints(const FOPPoint& rPt1, const FOPPoint& rPt2, const FOPRect& rcHit);

	// Is rectangle touches line.
	// aLine -- a FOPPolygon line object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Points, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aLine---aLine, Specifies a const FOPPolygon& aLine object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPoints(const FOPPolygon& aLine, const FOPRect& rcHit);

	// Create arc shape.
	// Convert arc to points.
	static void CreateArc(CArray<CPoint, CPoint>& aPoints,
		const FOPPoint& ptCenter, double radius,double angle1, double angle2, bool reversed);

	// Is rectangle touches line
	// aLine -- a FOPPolyPolygon line object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Points, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aLine---aLine, Specifies a const FOPPolyPolygon& aLine object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPoints(const FOPPolyPolygon& aLine, const FOPRect& rcHit);

	// Obtain the points of path.
	static long GetPathPoints(CDC * pDC, POINT** ppPts, BYTE** ppType);

public:
	// Is path exist or not.
	static BOOL FODirectoryExists(const CString& strPath);

	// Make directory
	static BOOL FOMakeDirectory(const CString& strDir);

	// Make full path.
	static BOOL FOMakePath(const CString& strPath);

	// Encrypt string.
	static CString Encrypt(const CString strText, WORD Key);

	// Decrypt string
	static CString Decrypt(const CString strText, WORD Key);

public:
	// Is point inside polygon.
	// aPoly -- a FOPPolygon object to be hit.
	// ptHit -- Hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Polygon, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).  
	//		ptHit---ptHit, Specifies A integer value.
	static BOOL HitTestPolygon(const FOPPolygon& aPoly, const FOPPoint& ptHit);

	// Is point inside polypolygon
	// aPoly -- a FOPSimplePolygon object to be hit.
	// ptHit -- Hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Polygon Ex, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolyPolygon& aPoly object(Value).  
	//		ptHit---ptHit, Specifies A integer value.
	static BOOL HitTestPolygonEx(const FOPPolyPolygon& aPoly, const FOPPoint& ptHit);

	// Is point inside currently extend polygon.
	// aPoly -- a FOPSimplePolygon object to be hit.
	// ptHit -- Hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Simple Polygon, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPSimplePolygon& aPoly object(Value).  
	//		ptHit---ptHit, Specifies A integer value.
	static BOOL HitTestSimplePolygon(const FOPSimplePolygon& aPoly, const FOPPoint& ptHit);

	// Is point inside currently extend polygon.
	// aPoly -- a FOPSimpleCompositePolygon object to be hit.
	// ptHit -- Hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Simple Polygon, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptHit---ptHit, Specifies A integer value.
	static BOOL HitTestSimplePolygon(const FOPSimpleCompositePolygon& aPoly, const FOPPoint& ptHit);
	
	// Is rect touches extend polygon.
	// aPoly -- a FOPSimplePolygon object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Simple Polygon, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPSimplePolygon& aPoly object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitSimplePolygon(const FOPSimplePolygon& aPoly, const FOPRect& rcHit);
	static void TrimMnemonics(CString& strText);

	///////////////////////////////////////////////////////////////
	// Function name	: Execute
	// Description	    : This function spawns a new process, and executes it
	// Return type		: DWORD 
	// Argument         : const CString & strCmd
	// Argument         : const CString & strArgs
	// Argument         : const CString & strDir
	// Argument         : BOOL bWait
	///////////////////////////////////////////////////////////////
	static DWORD Execute(const CString & strCmd, const CString & strArgs, const CString & strDir, BOOL bWait);

	// Sort string array
	static void SortStringArray (CStringArray& csa, BOOL bDescending);

	// Obtain all file folders.
	static void GetFileFolders(const CString &strRoot, CStringArray *pFOlders, BOOL bFile = FALSE);
	
	// Include this line before your code where you call 
	// this function !
	static BOOL EmptyDirectory(CString &sPath);
	
	// Is rect touches extend polygon.
	// aPoly -- a FOPSimpleCompositePolygon object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Simple Polygon, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPSimpleCompositePolygon& aPoly object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitSimplePolygon(const FOPSimpleCompositePolygon& aPoly, const FOPRect& rcHit);
	
	// Is rect touches extend polygon.
	// aPoly -- a FOPSimpleCompositePolygon object to be hit.
	// rcHit -- Hit test rectangle.
	// m_arLines -- hit lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Simple Polygon New, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPSimpleCompositePolygon& aPoly object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).  
	//		CArray<FOP_LineObject---Array< F O P_ Line Object, Specifies A CArray array.  
	//		&m_arLines---&m_arLines, Specifies a FOP_LineObject> &m_arLines object(Value).
	static BOOL RectHitSimplePolygonNew(const FOPSimpleCompositePolygon& aPoly, const FOPRect& rcHit,
		CArray<FOP_LineObject,FOP_LineObject> &m_arLines);
	
	// Is rectangle touches line.
	// aLine -- a FOPSimplePolygon line object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Points, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aLine---aLine, Specifies a const FOPSimplePolygon& aLine object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPoints(const FOPSimplePolygon& aLine, const FOPRect& rcHit);

	// Is rectangle touches line.
	// aLine -- a FOPSimpleCompositePolygon line object to be hit.
	// rcHit -- Hit test rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Hit Points, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aLine---aLine, Specifies a const FOPSimpleCompositePolygon& aLine object(Value).  
	//		rcHit---rcHit, Specifies a const FOPRect& rcHit object(Value).
	static BOOL RectHitPoints(const FOPSimpleCompositePolygon& aLine, const FOPRect& rcHit);

	/*************************************************************************
	|*
	|* Moving
	|*
	\************************************************************************/

	// Move rect
	// rcRect -- rectangle that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rcRect---rcRect, Specifies a FOPRect& rcRect object(Value).  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MoveRect(FOPRect& rcRect, const FOPSize& szOffset);

	// Move point
	// ptPnt -- point that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Point, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MovePoint(FOPPoint& ptPnt, const FOPSize& szOffset);

	// Move polygon
	// aPoly -- FOPPolygon object that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MovePolygon(FOPPolygon& aPoly, const FOPSize& szOffset);

	// Move polygon
	// aPoly -- FOPPolyPolygon object that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolyPolygon& aPoly object(Value).  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MovePolygon(FOPPolyPolygon& aPoly, const FOPSize& szOffset);

	// Move extend polygon.
	// aPoly -- FOPSimplePolygon object that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MoveSimplePolygon(FOPSimplePolygon& aPoly, const FOPSize& szOffset);

	// Move extend polygon.
	// aPoly -- FOPSimpleCompositePolygon object that to be moved.
	// szOffset -- moving size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		szOffset---szOffset, Specifies a const FOPSize& szOffset object(Value).
	static void MoveSimplePolygon(FOPSimpleCompositePolygon& aPoly, const FOPSize& szOffset);

	/*************************************************************************
	|*
	|* Resize
	|*
	\************************************************************************/

	// Resize rect.
	// rcRect -- rcRect object that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rcRect---rcRect, Specifies a FOPRect& rcRect object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a const FOPFraction& nxVal object(Value).  
	//		nyVal---nyVal, Specifies a const FOPFraction& nyVal object(Value).  
	//		bNoJustify---No Justify, Specifies A Boolean value.
	static void ResizeRect(FOPRect& rcRect, const FOPPoint& ptRotateCenter, const FOPFraction& nxVal, 
		const FOPFraction& nyVal, BOOL bNoJustify = FALSE);

	// Resize point.
	// ptPnt -- point that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Point, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a FOPFraction nxVal object(Value).  
	//		nyVal---nyVal, Specifies a FOPFraction nyVal object(Value).
	static void ResizePoint(FOPPoint& ptPnt, const FOPPoint& ptRotateCenter, FOPFraction nxVal, FOPFraction nyVal);

	// Resize polygon.
	// aPoly -- FOPPolygon object that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a const FOPFraction& nxVal object(Value).  
	//		nyVal---nyVal, Specifies a const FOPFraction& nyVal object(Value).
	static void ResizePolygon(FOPPolygon& aPoly, const FOPPoint& ptRotateCenter, const FOPFraction& nxVal, 
		const FOPFraction& nyVal);

	// Resize polygon.
	// aPoly -- FOPPolyPolygon object that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolyPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a const FOPFraction& nxVal object(Value).  
	//		nyVal---nyVal, Specifies a const FOPFraction& nyVal object(Value).
	static void ResizePolygon(FOPPolyPolygon& aPoly, const FOPPoint& ptRotateCenter, 
		const FOPFraction& nxVal, const FOPFraction& nyVal);

	// Resize extend polygon.
	// aPoly -- FOPSimplePolygon object that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a const FOPFraction& nxVal object(Value).  
	//		nyVal---nyVal, Specifies a const FOPFraction& nyVal object(Value).
	static void ResizeSimplePolygon(FOPSimplePolygon& aPoly, const FOPPoint& ptRotateCenter, 
		const FOPFraction& nxVal, const FOPFraction& nyVal);

	// Resize extend polygon.
	// aPoly -- FOPSimpleCompositePolygon object that to be resized.
	// ptRef -- resizing reference point.
	// nxVal -- x direction scale value.
	// nyVal -- y direction scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		nxVal---nxVal, Specifies a const FOPFraction& nxVal object(Value).  
	//		nyVal---nyVal, Specifies a const FOPFraction& nyVal object(Value).
	static void ResizeSimplePolygon(FOPSimpleCompositePolygon& aPoly, const FOPPoint& ptRotateCenter, 
		const FOPFraction& nxVal, const FOPFraction& nyVal);

	/*************************************************************************
	|*
	|* Rotating
	|*
	\************************************************************************/

	// Rotate point
	// ptPnt -- point that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Point, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePoint(FOPPoint& ptPnt, const FOPPoint& ptRotateCenter, double sinValue,double cosValue);

	// Rotate polygon.
	// aPoly -- FOPPolygon object that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePolygon(FOPPolygon& aPoly, const FOPPoint& ptRotateCenter, double sinValue,double cosValue);

	// Rotate polygon.
	// aPoly -- FOPPolyPolygon object that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolyPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePolygon(FOPPolyPolygon& aPoly, const FOPPoint& ptRotateCenter, 
		double sinValue,double cosValue);

	// Rotate points.
	// ptPnt -- point that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Point X, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		ptRef---ptRef, Specifies A CPoint type value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePointX(CPoint& ptPnt, const CPoint& ptRef, double sinValue,double cosValue);

	// Rotate polygon.
	// points -- points that to be rotated.
	// nCount -- count of the points.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Polygon, .
	// This member function is a static function.
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		ptRef---ptRef, Specifies A CPoint type value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePolygon(LPPOINT points,int nCount, const CPoint& ptRef, double sinValue,double cosValue);

	// Rotate polygon.
	// arPoints -- points that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Polygon, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&arPoints---&arPoints, Specifies A CPoint type value.  
	//		ptRef---ptRef, Specifies A CPoint type value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotatePolygon(CArray<CPoint,CPoint> &arPoints, const CPoint& ptRef, 
		double sinValue,double cosValue);

	// Rotate extend polygon.
	// aPoly -- FOPSimplePolygon object that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotateSimplePolygon(FOPSimplePolygon& aPoly, const FOPPoint& ptRotateCenter, 
		double sinValue,double cosValue);

	// Rotate extend polygon.
	// aPoly -- FOPSimpleCompositePolygon object that to be rotated.
	// ptRef -- rotating around point.
	// sinValue -- sin(rotating angle).
	// cosValue -- cos(rotating angle).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		sinValue---sinValue, Specifies a double sinValue object(Value).  
	//		cosValue---cosValue, Specifies a double cosValue object(Value).
	static void RotateSimplePolygon(FOPSimpleCompositePolygon& aPoly, const FOPPoint& ptRotateCenter,
		double sinValue,double cosValue);

	/*************************************************************************
	|*
	|* Mirror
	|*
	\************************************************************************/

	// Mirror rect.
	// rcRect -- rect object that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rcRect---rcRect, Specifies a FOPRect& rcRect object(Value).  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.  
	//		bNoJustify---No Justify, Specifies A Boolean value.
	static void MirrorRect(FOPRect& rcRect, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd, BOOL bNoJustify);

	// Mirror point.
	// ptPnt -- point that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Point, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.
	static void MirrorPoint(FOPPoint& ptPnt, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd);

	
	// Obtain the rectangle of monitor.
	static void LoadList(CListBox &list, CString FileName, int MaxItems, int ItemLen);

	// Compare two var name.
	static int CompareVars(CString strName1, CString strName2);
	
	// Save list.
	static void SaveList(CListBox &ListToFill, CString FileName, int MaxItems, int MaxItemLen);

	// Mirror polygon.
	// aPoly -- FOPPolygon object that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.
	static void MirrorPolygon(FOPPolygon& aPoly, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd);

	// Mirror polygon.
	// aPoly -- FOPPolyPolygon object that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolyPolygon& aPoly object(Value).  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.
	static void MirrorPolygon(FOPPolyPolygon& aPoly, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd);

	// Mirror points.
	// Get mirror point.
	// ptPnt -- point that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Point X, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		ptRef1---ptRef1, Specifies A CPoint type value.  
	//		ptRef2---ptRef2, Specifies A CPoint type value.
	static void MirrorPointX(CPoint& ptPnt, const CPoint& ptRef1, const CPoint& ptRef2);

	// Mirror polygon.
	// points -- points that to be mirrored.
	// nCount -- count of point.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Polygon, .
	// This member function is a static function.
	// Parameters:
	//		points---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		ptRef1---ptRef1, Specifies A CPoint type value.  
	//		ptRef2---ptRef2, Specifies A CPoint type value.
	static void MirrorPolygon(LPPOINT points,int nCount, const CPoint& ptRef1, const CPoint& ptRef2);

	// Mirror polygon.
	// arPoints -- points that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Polygon, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&arPoints---&arPoints, Specifies A CPoint type value.  
	//		ptRef1---ptRef1, Specifies A CPoint type value.  
	//		ptRef2---ptRef2, Specifies A CPoint type value.
	static void MirrorPolygon(CArray<CPoint,CPoint> &arPoints,const CPoint& ptRef1, const CPoint& ptRef2);
	
	// Mirror extend polygon.
	// aPoly -- FOPSimplePolygon object that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.
	static void MirrorSimplePolygon(FOPSimplePolygon& aPoly, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd);

	// Mirror extend polygon.
	// aPoly -- FOPSimpleCompositePolygon object that to be mirrored.
	// ptLineEnd -- Reference line start point.
	// ptLineEnd -- Reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptLineStart---Line Start, Specifies A integer value.  
	//		ptLineEnd---Line End, Specifies A integer value.
	static void MirrorSimplePolygon(FOPSimpleCompositePolygon& aPoly, const FOPPoint& ptLineStart, const FOPPoint& ptLineEnd);

	/*************************************************************************
	|*
	|* Shear
	|*
	\************************************************************************/

	// Shear point.
	// ptPnt -- point that to be sheared.
	// ptRotateCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Point, .
	// This member function is a static function.
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		tanValue---tanValue, Specifies a double tanValue object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	static void ShearPoint(FOPPoint& ptPnt, const FOPPoint& ptRotateCenter, 
		double tanValue, BOOL bVShear = FALSE);

	// Shear polygon.
	// aPoly -- FOPPolygon object.
	// ptRotateCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		tanValue---tanValue, Specifies a double tanValue object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	static void ShearPolygon(FOPPolygon& aPoly, const FOPPoint& ptRotateCenter, 
		double tanValue, BOOL bVShear = FALSE);

	// Shear polygon.
	// aPoly -- FOPPolyPolygon object.
	// ptRotateCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPPolyPolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		tanValue---tanValue, Specifies a double tanValue object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	static void ShearPolygon(FOPPolyPolygon& aPoly, const FOPPoint& ptRotateCenter,
		double tanValue, BOOL bVShear = FALSE);

	// Shear extend polygon.
	// aPoly -- FOPSimplePolygon object.
	// ptRotateCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		tanValue---tanValue, Specifies a double tanValue object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	static void ShearSimplePolygon(FOPSimplePolygon& aPoly, const FOPPoint& ptRotateCenter, 
		double tanValue, BOOL bVShear = FALSE);

	// Shear extend polypolygon.
	// aPoly -- FOPSimpleCompositePolygon object.
	// ptRotateCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Simple Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptRotateCenter---Rotate Center, Specifies A integer value.  
	//		tanValue---tanValue, Specifies a double tanValue object(Value).  
	//		bVShear---V Shear, Specifies A Boolean value.
	static void ShearSimplePolygon(FOPSimpleCompositePolygon& aPoly, 
		const FOPPoint& ptRotateCenter, double tanValue, BOOL bVShear = FALSE);

	// Get Bend angle,return the angle of the Bend.
	// ptPnt -- output point.
	// ptCenter -- Reference point.
	// tanValue -- tan value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bend Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		ptRad---ptRad, Specifies A integer value.  
	//		bVertical---bVertical, Specifies A Boolean value.
	static double GetBendAngle(FOPPoint& ptPnt, const FOPPoint& ptCenter,
		const FOPPoint& ptRad, BOOL bVertical);


	// Bend Stretch point
	// rPnt -- point of the reference.
	// ptFirst -- first compare point.
	// ptSecond -- second compare point
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Stretch X Point, Do a event. 
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		ptFirst---ptFirst, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptSecond---ptSecond, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		rSin---rSin, Specifies a double& rSin object(Value).  
	//		rCos---rCos, Specifies a double& rCos object(Value).  
	//		bVert---bVert, Specifies A Boolean value.  
	//		rcRect---rcRect, Specifies a const FOPRect rcRect object(Value).
	static double DoBendStretchXPoint(FOPPoint& rPnt, FOPPoint* ptFirst, FOPPoint* ptSecond, 
		const FOPPoint& ptCenterPoint,
						  const FOPPoint& ptRadiusPoint, double& rSin, double& rCos, BOOL bVert,
						  const FOPRect rcRect);

	// Bend rotate point.
	// rPnt -- point of the reference.
	// ptFirst -- first compare point.
	// ptSecond -- second compare point
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Rotate X Point, Do a event. 
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		ptFirst---ptFirst, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptSecond---ptSecond, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		rSin---rSin, Specifies a double& rSin object(Value).  
	//		rCos---rCos, Specifies a double& rCos object(Value).  
	//		bVert---bVert, Specifies A Boolean value.
	static double DoBendRotateXPoint(FOPPoint& rPnt, FOPPoint* ptFirst, FOPPoint* ptSecond, 
		const FOPPoint& ptCenterPoint,
						 const FOPPoint& ptRadiusPoint, double& rSin, double& rCos, BOOL bVert);

	// Draw radio ellipse.
	static void DrawRadioEllipse(CDC* pDC, const FOPRect &rc, COLORREF clrBorder, COLORREF clrFace);

	// Draw radio button.
	static void DrawRadioButton(CDC* pDC, const FOPRect & rcPos, BOOL bPressed, BOOL bSelected, BOOL bEnabled, BOOL bChecked);

	// Create gauge shape.
	// center -- center point.
	// radius -- radius.
	static void CreateGaugeShape(const FOPPoint& center, double radius,
	FOPComplexGeometry& shape, BOOL bInternal, double			m_dblStartAngle, 
	double			m_dblFinishAngle);

	// Create gauge shape.
	// center -- center point.
	// radius -- radius.
	static void CreateGaugeShape2(const FOPPoint& center, double radius,
		FOPComplexGeometry& shape, BOOL bInternal, double			m_dblStartAngle, 
		double			m_dblFinishAngle);

	// Obtain random colors.
	static COLORREF GetRandomColor();

	// Slant point
	// rPnt -- point of the reference.
	// ptFirst -- first compare point.
	// ptSecond -- second compare point
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Slant X Point, Do a event. 
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		ptCenter1---ptCenter1, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptCenter2---ptCenter2, A pointer to the FOPPoint or NULL if the call failed.  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		ptRad---ptRad, Specifies A integer value.  
	//		rSin---rSin, Specifies a double& rSin object(Value).  
	//		rCos---rCos, Specifies a double& rCos object(Value).  
	//		bVert---bVert, Specifies A Boolean value.
	static double DoBendSlantXPoint(FOPPoint& ptPnt, FOPPoint* ptCenter1, FOPPoint* ptCenter2, 
		const FOPPoint& ptCenter,
						const FOPPoint& ptRad, double& rSin, double& rCos, BOOL bVert);

	// Do Bend rotate poly.
	// aPoly -- polygon that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Rotate Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.
	static void DoBendRotatePoly(FOPSimplePolygon& aPoly, const FOPPoint& ptCenterPoint, 
		const FOPPoint& ptRadiusPoint, BOOL bVert);


	// Stretch poly.
	// aPoly -- polygon that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Stretch Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimplePolygon& rPoly object(Value).  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.  
	//		rRefRect---Reference Rectangle, Specifies a const FOPRect rRefRect object(Value).
	static void DoBendStretchPoly(FOPSimplePolygon& rPoly, const FOPPoint& ptCenterPoint, 
		const FOPPoint& ptRadiusPoint, 
		BOOL bVert, const FOPRect rRefRect);

	// Remove right digital
	static void RemoveRightNumber(CString& strText);
	
	// Slant polygon.
	// aPoly -- polygon that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Slant Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimplePolygon& aPoly object(Value).  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		ptRad---ptRad, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.
	static void DoBendSlantPoly(FOPSimplePolygon& aPoly, const FOPPoint& ptCenter, 
		const FOPPoint& ptRad, BOOL bVert);

	// Slant polygon
	// aPoly -- polygons that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Slant Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		ptRad---ptRad, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.
	static void DoBendSlantPoly(FOPSimpleCompositePolygon& aPoly, const FOPPoint& ptCenter, 
		const FOPPoint& ptRad, BOOL bVert);

	// Bend rotate poly
	// aPoly -- polygons that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Rotate Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.
	static void DoBendRotatePoly(FOPSimpleCompositePolygon& rPoly, const FOPPoint& ptCenterPoint,
		const FOPPoint& ptRadiusPoint,
		BOOL bVert);

	// Bend rotate poly
	// aPoly -- polygons that to be bended.
	// ptCenterPoint -- center point.
	// ptRadiusPoint -- radius
	// bVert -- vertical or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Bend Stretch Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).  
	//		ptCenterPoint---Center Point, Specifies A integer value.  
	//		ptRadiusPoint---Radius Point, Specifies A integer value.  
	//		bVert---bVert, Specifies A Boolean value.  
	//		rRefRect---Reference Rectangle, Specifies a const FOPRect rRefRect object(Value).
	static void DoBendStretchPoly(FOPSimpleCompositePolygon& rPoly, const FOPPoint& ptCenterPoint, 
		const FOPPoint& ptRadiusPoint,
		BOOL bVert, const FOPRect rRefRect);

	// Other methods.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mul Div Large Value, .
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nVal---nVal, Specifies A 32-bit long signed integer.  
	//		nMul---nMul, Specifies A 32-bit long signed integer.  
	//		nDiv---nDiv, Specifies A 32-bit long signed integer.
	static long MulDivLargeValue(long nVal, long nMul, long nDiv);

	// Cacl the point that attached the ellipse,it is used to calc the control handle of the pie or arc shape.
	// rc -- Rectangle of ellipse.
	// nAngle -- angle value(from 0 - 36000).
	// ptPnt -- Touch point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Touch Point, .
	// This member function is a static function.
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).  
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.  
	//		ptPnt---ptPnt, Specifies A integer value.
	static void CalcTouchPoint(const FOPRect& rc, long nAngle, FOPPoint& ptPnt);

	// Cacl the point that attached the ellipse,it is used to calc the control handle of the pie or arc shape.
	// rc -- Rectangle of ellipse.
	// nAngle -- angle value(from 0 - 36000).
	// ptPnt -- Touch point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Touch Point, .
	// This member function is a static function.
	// Parameters:
	//		rc---Specifies a const FOPRect& rc object(Value).  
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.  
	//		ptPnt---ptPnt, Specifies A integer value.
	static void XCalcTouchPoint(const FOPRect& rc, long nAngle, FOPFloat& ptPnt);

	// Ortho points, calculate the big ortho distance.
	// Used for 8 directions.
	// ptPt0 -- input point.
	// ptPt -- output point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Large Up Right, .
	// This member function is a static function.
	// Parameters:
	//		ptPt0---ptPt0, Specifies A integer value.  
	//		ptPt---ptPt, Specifies A integer value.  
	//		bBigOrtho---Big Ortho, Specifies A Boolean value.
	static void MakeLargeUpRight(const FOPPoint& ptPt0, FOPPoint& ptPt, BOOL bBigOrtho);

	// Ortho points, calculate the small ortho distance.
	// Used for 4 directions.
	// ptPt0 -- input point
	// ptPt -- output point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Small Up Right, .
	// This member function is a static function.
	// Parameters:
	//		ptPt0---ptPt0, Specifies A integer value.  
	//		ptPt---ptPt, Specifies A integer value.  
	//		bBigOrtho---Big Ortho, Specifies A Boolean value.
	static void MakeSmallUpRight(const FOPPoint& ptPt0, FOPPoint& ptPt, BOOL bBigOrtho);

	// Get control point of position.
	// rcPos -- position that use to calculate the control handle.
	// nControl -- should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nHandleControl---Handle , Specifies A integer value.
	static CPoint GetControlPoint(const CRect &rcPos,const int &nHandleControl);


	// Obtain the Origin point of the Shear action.
	// rcPos -- selection shapes bounding rectangle.
	// nHnadleControl -- control handle of the Shear.
	// ptNext -- next moving point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shear Origin Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&nHandleControl---Handle , Specifies A integer value.  
	//		&ptNext---&ptNext, Specifies A CPoint type value.
	static CPoint GetShearOriginPoint(const CRect &rcPos,const int &nHandleControl,const CPoint &ptNext);

	// Obtain the direction of the Shear,if it is Shear x return 1,else return 0,return -1 by default.
	// nHnadleControl -- control handle of the Shear.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Shear Directory, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&nHandleControl---Handle , Specifies A integer value.
	static int BeShearDir(const int &nHandleControl);

	static BOOL ShortestLine(const FOPPoint &ptHit, CArray<CPoint, CPoint> &arPoints, CArray<CPoint, CPoint> *pLayLink);

	//-----------------------------------------------------------------------
	// Summary:
	// Union, .
	// This member function is a static function.
	// Parameters:
	//		rR---rR, Specifies a FOPRect& rR object(Value).  
	//		rP---rP, Specifies A integer value.
	// Union point and rectangle.
	// rR -- first union rectangle.
	// rP -- second union rectangle.
	static void Union(FOPRect& rR, const FOPPoint& rP);

	// Find extension of the file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Extension, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		name---Specifies A CString type value.
	static CString FindExtension(const CString& name);

	// Find the type of the image file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Type, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns A FO_IMAGETYPE value (Object).  
	// Parameters:
	//		ext---Specifies A CString type value.
	static FO_IMAGETYPE FindType(const CString& ext);


	// Light color.
	static COLORREF LightColor(COLORREF crColor);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A FOPPaper value (Object).  
	// Parameters:
	//		nWidth100thMM---Width100th M M, Specifies A 32-bit long signed integer.  
	//		nHeight100thMM---Height100th M M, Specifies A 32-bit long signed integer.
	// Obtain the printer paper's format,such as GetPaperFormat(29700,42000); will return PAPER_A3
	// nWidth100thMM -- 100 * mm value.
	// nHeight100thMM -- 100 * mm value.
	static FOPPaper GetPaperFormat( long nWidth100thMM, long nHeight100thMM );

	// Calculate the unique ID,returns an unique id.
	// strName -- base unique name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Unique Id, .
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	static CString CalcUniqueId(CString &strName);

	// Load the ole actual bitmap data in a buffer.
	// variable -- ole data bitmap.
	// bWithHeader -- with header or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Ole Bitmap, Call this function to read a specified number of bytes from the archive.
	// This member function is a static function.
	//		Returns A HANDLE value (Object).  
	// Parameters:
	//		variable---Specifies a const COleVariant& variable object(Value).  
	//		bWithHeader---With Header, Specifies A Boolean value.
	static HANDLE LoadOleBitmap(const COleVariant& variable, BOOL bWithHeader = FALSE);


	// Drawing bitmap with handle.
	// pDC -- pointer of the DC.
	// handle -- bitmap handle.
	// lpRect -- position of the bitmap for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Ole Bitmap, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		handle---Specifies a HANDLE handle object(Value).  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		nStretchFlags---Stretch Flags, Specifies A integer value.  
	//		ntAlign---ntAlign, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpSrc---lpSrc, Specifies a LPRECT lpSrc = NULL object(Value).
	static void DrawOleBitmap(CDC* pDC, HANDLE handle, LPRECT lpRect, 
		int nStretchFlags, UINT ntAlign = DT_TOP|DT_LEFT, LPRECT lpSrc = NULL);


	// Mix colors
	static COLORREF foMixColors(COLORREF crColor1, COLORREF crColor2, double dblRatio);

	// Set pixel with.
	static void FBSetPixel(COLORREF* pBits, int cx, int cy, int x, int y, COLORREF crColor);

	// Pixel transparent
	static COLORREF FBPixelAlpha(COLORREF crPixel, int nPercent);

	// Pixel alpha
	static COLORREF FBPixelAlpha(COLORREF crPixel, double dPercentR, double dPercentG, double dPercentB);

	// Pixel alpha
	static COLORREF FBPixelAlpha(COLORREF crPixel, COLORREF crPixel1, int nPercent);

	// Set alpha pixel
	static void FBSetAlphaPixel(COLORREF* pBits, CRect rcRect, int x, int y, int nPercent, int nShadowSize,
		COLORREF crBase = (COLORREF)-1, BOOL bIsRight = TRUE);

	// Draw rect.
	static void FBDrawRect (CDC *pDC, const CRect& rcRect, COLORREF crFill, COLORREF crLine);

	// Draw ellipse
	static void FBDrawEllipse(CDC *pDC,const CRect& rcRect, COLORREF crFill, COLORREF crLine, 
		int nPenStyle = PS_SOLID);

	// Fill gradient color
	static void FBFill4ColorsGradient(CDC *pDC,CRect rcRect, 
		COLORREF colorStart1, COLORREF colorFinish1, 
		COLORREF colorStart2, COLORREF colorFinish2,
		BOOL bHorz = TRUE, int nPercentage = 50);

	// Draw gray rectangle.
	static BOOL FBGrayRect(CDC *pDC, CRect rcRect,	
		int nPercentage = -1,
		COLORREF crTransparent =(COLORREF)-1,
		COLORREF crDisabled =(COLORREF)-1);

	// Draw high ligh rectangle.
	static BOOL FBHighlightRect(CDC *pDC, CRect rcRect,	
		int nPercentage = -1,	
		COLORREF crTransparent = (COLORREF)-1,
		int nTolerance = 0,	COLORREF crBlend = (COLORREF)-1);

	// Create rgn with geometry.
	static HRGN CreateGeometry(FOPComplexGeometry& geometry);

	// Create bezier points.
	static void fopCreateBezierPoints(const FOPFloat& ptFrom, 
		const FOPBezierSegment& segment, CArray<FOPFloat, FOPFloat>& arPoints);
	
public:
	// Add image.
	static void SVG_Image(CString &str, CString imagename, FOPRect rcPos);

	// SVG for poly.
	static void SVG_Poly(CString &str, LPPOINT m_lpShapePoints, int m_nCompPtCount, COLORREF crLine, COLORREF crFill, int nLineWidth, const BOOL &bTransparent = FALSE);
	
	// SVG for poly.
	static void XSVG_Poly(CString &str, FOPFloat* m_lpShapePoints, int m_nCompPtCount, COLORREF crLine, COLORREF crFill, int nLineWidth, const BOOL &bTransparent = FALSE);
	

	// SVG for rectangle
	static void SVG_Rect(CString &str, const CRect &rc, COLORREF crLine, COLORREF crFill, int nLineWidth, const BOOL &bTransparent = FALSE);
	
	// SVG for round rectangle.
	static void SVG_RoundRect(CString &str, const CRect &rc, const CPoint &ptCorner, COLORREF crLine, COLORREF crFill, int nLineWidth, const BOOL &bTransparent = FALSE);
	
	// SVG for ellipse
	static void SVG_Ellipse(CString &str, const CRect &rc, COLORREF crLine, COLORREF crFill, int nLineWidth, const BOOL &bTransparent = FALSE);

	// SVG for line
	static void SVG_Line(CString &str, const CPoint &ptStart, const CPoint &ptEnd, COLORREF crLine,int nLineWidth);

	// Add svg text 0 -- middle, 1 -- start, 2 -- end
	static void		  SVG_AddText(CString &outputStringL,int x, int y, COLORREF crFont, int nFontSize, CString strTitle, int nPos = 0);

protected:
	
	// SVG generate polygon.
	static CString SVG_PolyGen(LPPOINT m_lpShapePoints, int m_nCompPtCount);

	// SVG generate polygon.
	static CString XSVG_PolyGen(FOPFloat* m_lpShapePoints, int m_nCompPtCount);


	// SVG generate rectangle
	static CString SVG_GenRect(const FOPRect &rect);

	// SVG for generating round rectangle.
	static CString SVG_GenRoundRect(const FOPRect &rect, const CPoint &ptCorner);
	
	
	// SVG for generating ellipse.
	static CString SVG_GenEllipse(const FOPRect &rect);

	// SVG_Fill
	static CString SVG_Fill(COLORREF color, int GrayScale, const BOOL &bTransparent);

	// SVG pen.
	static CString SVG_Pen(COLORREF color, int nLineWidth);

	// SVG simple text.
	static	CString	  SVG_SimpleText(const CString &strText, int x, int y, BOOL bUnderline, BOOL bStrike);

	// SVG html filter.
	static  CString     SVG_HtmlFilter(CString sInput);

	// SVG for add text header.
	static   CString    SVG_AddTextHeader(COLORREF crFont, int nFontSize, CString strTitle, int nPos);
	
public:
	// Generate fat line style.
	// nPenWidth -- width of pen.
	// nPenStyle -- style of pen.
	// output -- output array data.
	// nSize -- size of array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Line Style, .
	// This member function is a static function.
	// Parameters:
	//		nPenWidth---Pen Width, Specifies A integer value.  
	//		nPenStyle---Pen Style, Specifies A integer value.  
	//		*output---A pointer to the DWORD  or NULL if the call failed.  
	//		&nSize---&nSize, Specifies A integer value.
	static void GenerateLineStyle(int nPenWidth,int nPenStyle,DWORD *output, int &nSize);

	// Make sure it is outside current application or not.
	// point -- Current mouse point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Outside Application, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	static BOOL IsOutsideApplication(const CPoint& point);

	// Wait for some time, at the same time, handle the messages in the queue
	// nMS -- milli sceonds that delayed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delay Minimize Seconds, .
	// This member function is a static function.
	// Parameters:
	//		nMS---M S, Specifies a double nMS object(Value).
	static void DelayMinSeconds(double nMS);

	// Draw logo text string.
	// pDC-- Drawing dc.
	// rcLogo -- logo position.
	// strTitle -- title string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Logo, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rcLogo---&rcLogo, Specifies A CRect type value.  
	//		&strTitle---&strTitle, Specifies A CString type value.
	static void DrawLogo(CDC* pDC,const CRect &rcLogo,const CString &strTitle);

	// Combine a simple composite polygon to a single polygon.
	// aSimplePoly -- poly to combine.
	// nJoinLen -- join length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Combine To Polygon, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		aSimplePoly---Simple Polygon, Specifies a FOPSimpleCompositePolygon& aSimplePoly object(Value).  
	//		nJoinLen---Join Len, Specifies A 32-bit long signed integer.
	static void DoCombineToPoly(FOPSimpleCompositePolygon& aSimplePoly, long nJoinLen);

	// Merge two polygons to a single composite polygon.
	// aFirst -- merge first composite polygon.
	// aSecond -- merge second composite polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Merge Composite Polygon, .
	// This member function is a static function.
	// Parameters:
	//		aFirst---aFirst, Specifies a FOPSimpleCompositePolygon& aFirst object(Value).  
	//		aSecond---aSecond, Specifies a const FOPSimpleCompositePolygon& aSecond object(Value).
	static void MergeCompositePoly(FOPSimpleCompositePolygon& aFirst, const FOPSimpleCompositePolygon& aSecond);

	// Get glyph outline.
	// hDC -- handle of the DC
	// nIndex -- index.
	// aCompPoly -- composite polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Glyph Outline, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.  
	//		aCompPoly---Component Polygon, Specifies a FOPPolyPolygon& aCompPoly object(Value).
	static BOOL GetGlyphOutline(CDC *pDC,long nIndex, FOPPolyPolygon& aCompPoly );

	// Get outline of the text string.
	// pDC -- pointer of the DC.
	// nFontHeight -- Height of the font by pixel
	// strText -- label of the text.
	// aPoly -- the outline polygons.
	// strFaceName -- font's face name
	static BOOL GetOutline(CDC *pDC,const CString& strText, FOPSimpleCompositePolygon& aPoly,
		const int &nFontHeight = 144,const CString &strFaceName = _T("Verdana"),
		const BOOL &bBold = FALSE,const BOOL &bItalic = FALSE);

	// Obtain the bound rectangle of the glyph
	// hDC -- handle of the DC.
	// nIndex -- index
	// rcPos -- position of the glyph.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Glyph Bound Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		nIndex---nIndex, Specifies A 32-bit long signed integer.  
	//		rcPos---rcPos, Specifies a FOPRect& rcPos object(Value).
	static BOOL GetGlyphBoundRect(HDC hDC, long nIndex, FOPRect& rcPos);

	// Obtain the index of a CObject within the list.
	// list -- list of objects.
	// pObj -- pointer of CObject to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Index, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&lstObj---&lstObj, Specifies a const CObList &lstObj object(Value).  
	//		pObj---pObj, A pointer to the CObject or NULL if the call failed.
	static int	GetObjectIndex(const CObList &lstObj,CObject* pObj);

	// Check pt in rectangle or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Point In Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		rect---Specifies A CRect type value.
	static BOOL FOPtInRect(CPoint point, CRect rect);

	// Line intersect.
	// ptStart1 -- start point of line 1
	// ptEnd1 -- end point of line 1
	// ptStart2 -- start point of line 2
	// ptEnd2 -- end point of line 2
	// fBridgeSize -- bridge size
	// ptIntersect -- intersect point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Line Segment Intersect, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart1---&ptStart1, Specifies A integer value.  
	//		&ptEnd1---&ptEnd1, Specifies A integer value.  
	//		&ptStart2---&ptStart2, Specifies A integer value.  
	//		&ptEnd2---&ptEnd2, Specifies A integer value.  
	//		&fBridgeSize---Bridge Size, Specifies A float value.  
	//		&ptIntersect---&ptIntersect, Specifies A integer value.
	static BOOL CheckLineSegmentIntersect( const FOPPoint &ptStart1, const FOPPoint &ptEnd1, 
			const FOPPoint &ptStart2, const FOPPoint &ptEnd2, const float &fBridgeSize, FOPPoint &ptIntersect );

	// Check min moving.
	static BOOL CheckMinMoved(const FOPPoint& rPnt,const FOPPoint &ptPrev,const int &nW = 30);

	// Generate the font handle.
	// strFontName -- name of the font.
	// nSize -- height of the font.
	// nStyle -- style of the font
	// nRotation -- rotating angle of the font.
	// hDC -- handle of the DC.
	// pLogFont -- logical font structure
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Font Handle, .
	// This member function is a static function.
	//		Returns A HFONT value (Object).  
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		*pLogFont---Logical Font, A pointer to the LOGFONT  or NULL if the call failed.  
	//		strFontName---Font Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nSize---nSize, Specifies A integer value.  
	//		nStyle---nStyle, Specifies A integer value.  
	//		nRotation---nRotation, Specifies A integer value.
	static HFONT GenFontHandle(HDC hDC,LOGFONT *pLogFont,LPCTSTR strFontName, 
		int nSize, int nStyle,int nRotation);

	// Obtain the text string dimension,it can be multiple lines or single line
	// pDC -- pointer of the DC.
	// strText -- text for calculate
	// bWrap -- wrap or not
	// nWrapWidth -- width of the wrap
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Dimension, Returns the specified value.
	// This member function is a static function.
	//		Returns a CSize type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		strText---strText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bWrap---bWrap, Specifies A Boolean value.  
	//		nWrapWidth---Wrap Width, Specifies A integer value.
	static CSize GetTextDimension(CDC *pDC,LPCTSTR strText, BOOL bWrap,
		int nWrapWidth);

	// get device device cap
	// rDPIX -- x DPI
	// rDPIY -- y DPI
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct Device Cap, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		mhDC---D C, Specifies a HDC mhDC object(Value).  
	//		rDPIX---D P I X, Specifies A 32-bit long signed integer.  
	//		rDPIY---D P I Y, Specifies A 32-bit long signed integer.
    static void	GetCorrectDeviceCap(HDC mhDC, long& rDPIX, long& rDPIY );
	
	// Calc the area of the monitor.
	// bIgnoreTaskbar -- ignore the task bar or not.
	// pRect -- the returning rectangle.
	// pParentRect -- if pParentRect is set, the workarea of the monitor that contains 
	//				  pParentRect is returned
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Monitor Work Area, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		bIgnoreTaskbar---Ignore Taskbar, Specifies A Boolean value.  
	//		*pRect---*pRect, A pointer to the RECT  or NULL if the call failed.  
	//		*pParentRect---Parent Rectangle, A pointer to the const RECT  or NULL if the call failed.
	static void GetMonitorWorkArea( const BOOL& bIgnoreTaskbar, RECT *pRect, const RECT *pParentRect );

	//-----------------------------------------------------------------------
	// Summary:
	// Get Monitor Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.
	static CRect GetMonitorRectangle();

	// Obtain the monitor work area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Monitor Work Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	static CRect GetMonitorWorkRect(CPoint point);

	// Obtain the desktop rectangle of window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Desktop Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		m_hWnd---m_hWnd, Specifies a HWND m_hWnd object(Value).
	static CRect GetDesktopRect(HWND m_hWnd);

	// Obtain the screen resolution.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resolution, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rDPIX---D P I X, Specifies A 32-bit long signed integer.  
	//		rDPIY---D P I Y, Specifies A 32-bit long signed integer.
	static void GetResolution(CDC *pDC, long& rDPIX, long& rDPIY );

	// Is point within an ellipse.
	// rcEllipse -- position of the ellipse.
	// ptHit -- point for checking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Ellipse, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcEllipse---rcEllipse, Specifies A CRect type value.  
	//		ptHit---ptHit, Specifies A CPoint type value.
	static BOOL		PtInEllipse(const CRect& rcEllipse, const CPoint& ptHit);

	// Is current rectangle within an ellipse
	// rcEllipse -- position of the ellipse
	// rcPos -- rectangle for checking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle In Ellipse, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		rcEllipse---rcEllipse, Specifies A CRect type value.
	static BOOL		RectInEllipse(const CRect& rcPos, const CRect& rcEllipse);

	// Scale rectangle to current UI
	// aRect -- rectangle for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		aRect---aRect, Specifies a FOPRect& aRect object(Value).  
	//		aUIScale---U I Scale, Specifies a FOPFraction aUIScale object(Value).
	static void		ScaleRect( FOPRect& aRect, FOPFraction aUIScale );

	static FOPPoint FO_ArcCenter1(FOPPoint P1, FOPPoint P2, double Radius, int Direction);


	// Scale size to current UI
	// aSize -- size value for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Size, .
	// This member function is a static function.
	// Parameters:
	//		aSize---aSize, Specifies a FOPSize& aSize object(Value).  
	//		aUIScale---U I Scale, Specifies a FOPFraction aUIScale object(Value).
	static void		ScaleSize( FOPSize& aSize, FOPFraction aUIScale );

	// Scale point to current UI
	// aPoint -- point value for scaling.
	// aUIScale -- scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Point, .
	// This member function is a static function.
	// Parameters:
	//		aPoint---aPoint, Specifies A integer value.  
	//		aUIScale---U I Scale, Specifies a FOPFraction aUIScale object(Value).
	static void		ScalePoint( FOPPoint& aPoint, FOPFraction aUIScale );
	
	// Check insert position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Check Insert Position, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		rPos---rPos, Specifies A integer value.  
	//		rSize---rSize, Specifies a const FOPSize& rSize object(Value).  
	//		rcLimit---rcLimit, Specifies a const FOPRect& rcLimit object(Value).
	static void		DoCheckInsertPos(FOPPoint& rPos, const FOPSize& rSize, const FOPRect& rcLimit);

	//	The intersection between an open polygon and a rectangle is calculated and the resulting lines are placed into the poly-polygon aResult.
	//	aPolygon --	The polygon is required to be open, ie. it's start and end point have different coordinates and that it is continuous, ie. has no holes.
	//	rcRect -- The clipping area.
	//	aResult -- The resulting lines that are the parts of the given polygon lying inside
	//		the clipping area are stored into aResult whose prior content is deleted first.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersect Polygon With Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		aPolygon---aPolygon, Specifies a const FOPSimplePolygon& aPolygon object(Value).  
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		aResult---aResult, Specifies a FOPSimpleCompositePolygon& aResult object(Value).
	static void IntersectPolygonWithRectangle(const FOPSimplePolygon& aPolygon, const FOPRect& rcRect,FOPSimpleCompositePolygon& aResult );

	// Calculates the intersection between a set of open polygons and a
    //           rectangle.  This function iterates over all polygons contained in
    //           rPolyPolygon and calls IntersectPolygonWithRectangle() for it.
    //           The resulting XPolyPolygons are then put together into aResult.
    //    rPolyPolygon -- A set of polygons that must be open.
    //    rRectangle -- The clipping region
    //    rOutResult -- The resulting lines representing rPolyPolygon clipped
    //                         at rRectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersect Polygon Polygon With Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rPolyPolygon---Polygon Polygon, Specifies a const FOPSimpleCompositePolygon & rPolyPolygon object(Value).  
	//		rRectangle---rRectangle, Specifies a const FOPRect & rRectangle object(Value).  
	//		rOutResult---Out Result, Specifies a FOPSimpleCompositePolygon & rOutResult object(Value).
    static void IntersectPolyPolygonWithRectangle( const FOPSimpleCompositePolygon & rPolyPolygon,
                                                   const FOPRect & rRectangle,
                                                   FOPSimpleCompositePolygon & rOutResult );

	//		 The line is clipped at the rectangle.  If the line lies completely or partly
	//		 inside the clipping area then TRUE is returned and the line is modified accordingly.
	//		 If the line lies completely outside the clipping area then FALSE is returned and the
	//		 line remains unmodified.
	//		 The line may be degenerate in that both of it's end points have the same 
	//		 coordinates.
	//	aLine -- The line to be clipped.  It is modified to a part that lies completely
	//		inside the clipping area if such a part exists.
	//	rRectangle --The clipping area.
	//  return	TRUE is returned if the line lies completely or partly inside the clipping area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clipboard Line At Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aLine---aLine, Specifies a FOPLine& aLine object(Value).  
	//		rRectangle---rRectangle, Specifies a const FOPRect& rRectangle object(Value).
	static BOOL ClipLineAtRectangle(FOPLine& aLine, const FOPRect& rRectangle );

	// Bitmap print.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Bitmap Print, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		hbm---Specifies a HBITMAP hbm object(Value).  
	//		bits---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		log_left---Specifies A integer value.  
	//		log_top---Specifies A integer value.  
	//		log_width---Specifies A integer value.  
	//		log_height---Specifies A integer value.
	static void FOBitmapPrint(CDC *pDC,HBITMAP hbm, UINT bits, int log_left, int log_top, 
		int log_width, int log_height);
	
	// Generate percent string.
	// aVal -- fraction value.
	// rStr -- string
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Fraction String, .
	// This member function is a static function.
	// Parameters:
	//		aVal---aVal, Specifies a const FOPFraction& aVal object(Value).  
	//		rStr---rStr, Specifies A CString type value.  
	//		bNoPercentChar---No Percent Char, Specifies A Boolean value.
	static void TakeFractionStr(const FOPFraction& aVal, CString& rStr, 
		BOOL bNoPercentChar = FALSE);

	// Load system color bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load System Color Bitmap, Call this function to read a specified number of bytes from the archive.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bitmap---Specifies a CBitmap& bitmap object(Value).  
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	static BOOL LoadSysColorBitmap(CBitmap& bitmap, LPCTSTR lpszFileName);

	// Is line segment contains point.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line.
	// ptTest -- point of hit testing.
	// aDelta -- delta value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Line, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptTest---&ptTest, Specifies A CPoint type value.  
	//		aDelta---aDelta, Specifies A float value.
	static BOOL HitTestLine(const CPoint &ptLineStart, const CPoint &ptLineEnd, 
		const CPoint &ptTest, float aDelta);

	// Obtain the nearest point on line
	// ptLineStart -- first point of the line.
	// ptLineEnd -- end point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection On Line, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptCheck1---&ptCheck1, Specifies A CPoint type value.  
	//		&ptCheck2---&ptCheck2, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetNearestIntersectionOnLine(const CPoint &ptLineStart, const CPoint &ptLineEnd, 
		const CPoint &ptCheck1, const CPoint &ptCheck2, CPoint &result);

	// Obtain the nearest point on line
	// ptLineStart -- first point of the line.
	// ptLineEnd -- end point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection On Line, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptCheck1---&ptCheck1, Specifies A CPoint type value.  
	//		&ptCheck2---&ptCheck2, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL XGetNearestIntersectionOnLine(const FOPFloat &ptLineStart, const FOPFloat &ptLineEnd, 
		const FOPFloat &ptCheck1, const FOPFloat &ptCheck2, FOPFloat &result);

	// Obtain the angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns a float value.  
	// Parameters:
	//		x---Specifies A float value.  
	//		y---Specifies A float value.
	static float GetAngle(float x, float y);

	// Obtain the bounding rectangle of the bezier segment.
	// pt0 -- first point of the beizer segment.
	// pt1 -- second point of the bezier segment
	// pt2 -- third point of the bezier segment.
	// pt3 -- four point of the bezier segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bezier Boundrect, Returns the specified value.
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		&pt0---Specifies A CPoint type value.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&pt3---Specifies A CPoint type value.
	static CRect GetBezierBoundrect(const CPoint &pt0, const CPoint &pt1, const CPoint &pt2, const CPoint &pt3);

	// Does current bezier segment contains the point.
	// pt0 -- first point of the beizer segment.
	// pt1 -- second point of the bezier segment
	// pt2 -- third point of the bezier segment.
	// pt3 -- four point of the bezier segment
	// aDelta -- delta value for testing
	// pt -- point for hit testing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Beizer, Hit test on this object.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&pt0---Specifies A CPoint type value.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&pt3---Specifies A CPoint type value.  
	//		aDelta---aDelta, Specifies A float value.  
	//		pt---Specifies A CPoint type value.
	static BOOL HitTestBeizer(const CPoint &pt0, const CPoint &pt1, const CPoint &pt2, const CPoint &pt3,
										float aDelta, const CPoint& pt);

	// Obtain the bitmap of a specify window
	static BOOL GetWndBitmap(CBitmap& bmpGot, CWnd* pWnd);

	// Bezier nearest intersect line
	// pt0 -- first point of the beizer segment.
	// pt1 -- second point of the bezier segment
	// pt2 -- third point of the bezier segment.
	// pt3 -- four point of the bezier segment
	// ptFirst -- first point of the line.
	// ptSecond -- second point of the line
	// result -- result point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bezier Nearest Intersection Line, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&pt0---Specifies A CPoint type value.  
	//		&pt1---Specifies A CPoint type value.  
	//		&pt2---Specifies A CPoint type value.  
	//		&pt3---Specifies A CPoint type value.  
	//		ptFirst---ptFirst, Specifies A CPoint type value.  
	//		ptSecond---ptSecond, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetBezierNearestIntersectionLine(const CPoint &pt0, const CPoint &pt1, 
		const CPoint &pt2, const CPoint &pt3,
		const CPoint& ptFirst, const CPoint& ptSecond, CPoint &result);

	// Obtain the nearest intersection point.
	// rcPos -- rectangle for hit testing.
	// ptFirst -- first point of the line.
	// ptSecond -- second point of the line
	// result -- result point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection Point, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		ptFirst---ptFirst, Specifies A CPoint type value.  
	//		ptSecond---ptSecond, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetNearestIntersectionPoint(const CRect &rcPos, const CPoint& ptFirst,
		const CPoint& ptSecond, CPoint &result);

	// Is two rectangles intersect.
	// rcFirst -- first rectangle for checking
	// rcSecond -- the second rectangle for checking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersects Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcFirst---rcFirst, Specifies A CRect type value.  
	//		rcSecond---rcSecond, Specifies A CRect type value.
	static BOOL IntersectsRect(const CRect& rcFirst, const CRect& rcSecond);

	// Obtain the nearest intersection on arc.
	// rcPos -- rectangle for hit testing.
	// ptFirst -- first point of the line.
	// ptSecond -- second point of the line
	// result -- result point, it is also the point for checking.
	// beginAngle -- start angle
	// endAngle -- end angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection On Arc, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		ptFirst---ptFirst, Specifies A CPoint type value.  
	//		ptSecond---ptSecond, Specifies A CPoint type value.  
	//		result---Specifies A CPoint type value.  
	//		beginAngle---beginAngle, Specifies A float value.  
	//		endAngle---endAngle, Specifies A float value.
	static BOOL GetNearestIntersectionOnArc(const CRect &rcPos, const CPoint& ptFirst, const CPoint& ptSecond, CPoint& result,
		float beginAngle, float endAngle);

	// Obtain the intersection on ellipse
	// rcPos -- rectangle for hit testing.
	// ptFirst -- first point of the line.
	// ptSecond -- second point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection On Ellipse, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		ptFirst---ptFirst, Specifies A CPoint type value.  
	//		ptSecond---ptSecond, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetNearestIntersectionOnEllipse(const CRect &rcPos, const CPoint& ptFirst, const CPoint& ptSecond, CPoint &result);

	// Obtain the intersection on ellipse
	// rcPos -- rectangle for hit testing.
	// ptFirst -- first point of the line.
	// ptSecond -- second point of the line
	// result -- result point, it is also the point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Intersection On Ellipse, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		ptFirst---ptFirst, Specifies A CPoint type value.  
	//		ptSecond---ptSecond, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL XGetNearestIntersectionOnEllipse(const CRect &rcPos, const FOPFloat& ptFirst, const FOPFloat& ptSecond, FOPFloat &result);

	//-----------------------------------------------------------------------
	// Summary:
	// Fillet, .
	// This member function is a static function.
	// Parameters:
	//		*p1---A pointer to the CPoint  or NULL if the call failed.  
	//		*p2---A pointer to the CPoint  or NULL if the call failed.  
	//		*p3---A pointer to the CPoint  or NULL if the call failed.  
	//		*p4---A pointer to the CPoint  or NULL if the call failed.  
	//		r---Specifies a double r object(Value).  
	//		*center---A pointer to the CPoint  or NULL if the call failed.  
	//		*startAngle---*startAngle, A pointer to the double  or NULL if the call failed.  
	//		*endAngle---*endAngle, A pointer to the double  or NULL if the call failed.
	//   Compute a circular arc fillet between lines L1 (p1 to p2)
	//   and L2 (p3 to p4) with radius r.
	//   The circle center is center.
	//   The start angle is startAngle
	//   The end angle is endAngle,
	//   The points p1-p4 will be modified as necessary
	static void Fillet(CPoint *p1, CPoint *p2, CPoint *p3, CPoint *p4,
		double r, CPoint *center, double *startAngle, double *endAngle);

	// Point on line, mostly.
	// **do not use this method.**
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point At Line, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		p---Specifies A CPoint type value.  
	//		p1---Specifies A CPoint type value.  
	//		p2---Specifies A CPoint type value.  
	//		HandleSize---Handle Size, Specifies A integer value.  
	//		pensize---Specifies A integer value.
	static BOOL PointAtLine(CPoint p,CPoint p1, CPoint p2,int HandleSize,int pensize);

	// Obtain the distance to ellipse
	// center -- center point of ellipse.
	// width -- width of ellipse.
	// height -- height of ellipse.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance To Ellipse, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		*center---A pointer to the const CPoint  or NULL if the call failed.  
	//		width---Specifies a double width object(Value).  
	//		height---Specifies a double height object(Value).  
	//		line_width---Specifies a double line_width object(Value).  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static double DistanceToEllipse(const CPoint *center, double width, double height,
		       double line_width, const CPoint *point);

	// This function estimates the distance from a point to a line segment
	// specified by two endpoints.
	// If the point is on the line segment, 0.0 is returned. Otherwise the
	// distance in the R^2 metric from the point to the nearest point
	// on the line segment is returned. Does one sqrt per call.
	// Philosophical bug: line_width is ignored if point is beyond
	// end of line segment.
	// line_start -- start point of line.
	// line_end -- end point of line.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance To Line, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		*line_start---A pointer to the const CPoint  or NULL if the call failed.  
	//		*line_end---A pointer to the const CPoint  or NULL if the call failed.  
	//		line_width---Specifies a double line_width object(Value).  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static double DistanceToLine(const CPoint *line_start, const CPoint *line_end,
		    double line_width, const CPoint *point);

	// Obtain the distance to polygon
	// poly -- points of polygon.
	// npoints -- count of points.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance To Polygon, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		*poly---A pointer to the const CPoint  or NULL if the call failed.  
	//		npoints---Specifies A integer value.  
	//		line_width---Specifies a double line_width object(Value).  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static double DistanceToPolygon(const CPoint *poly, int npoints, double line_width,const CPoint *point);

	// Obtain the point that near to polyline path
	// poly -- points of polygon.
	// npoints -- count of points.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Near To Polygon Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		poly---Specifies A LPPOINT Points array.  
	//		npoints---Specifies A integer value.  
	//		&bOutLine---Out Line, Specifies A Boolean value.  
	//		line_width---Specifies a double line_width object(Value).  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static CPoint GetNearToPolygonPoint(LPPOINT poly, int npoints, const BOOL &bOutLine, double line_width, 
		const CPoint *point);

	// Obtain the point that near to polyline path
	// poly -- points of polygon.
	// npoints -- count of points.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Near To Polygon Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		poly---Specifies A LPPOINT Points array.  
	//		npoints---Specifies A integer value.  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static void GetDirectionToPolygonPoint(LPPOINT poly, int npoints, const CPoint *point, int &nStart, int &nEnd);


	// Obtain the distance to bezier line segment.
	// b1 - b2 - b3 - b4 --- are four points of this bezier line segment.
	// line_width -- line width.
	// point -- pointer of point that for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distance To Bezier Seg, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		*b1---A pointer to the const CPoint  or NULL if the call failed.  
	//		*b2---A pointer to the const CPoint  or NULL if the call failed.  
	//		*b3---A pointer to the const CPoint  or NULL if the call failed.  
	//		*b4---A pointer to the const CPoint  or NULL if the call failed.  
	//		line_width---Specifies A integer value.  
	//		*point---A pointer to the const CPoint  or NULL if the call failed.
	static double DistanceToBezierSeg(const CPoint *b1, 
                                    const CPoint *b2, const CPoint *b3, 
                                    const CPoint *b4,
								int line_width, const CPoint *point);

	// Find center point. Given three points, find the center of the circle they describe.
	// Returns FALSE if the center could not be determined (i.e. the points
	// all lie really close together).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Center Point, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*center---A pointer to the CPoint  or NULL if the call failed.  
	//		*p1---A pointer to the CPoint  or NULL if the call failed.  
	//		*p2---A pointer to the CPoint  or NULL if the call failed.  
	//		*p3---A pointer to the CPoint  or NULL if the call failed.
	static BOOL FindCenterPoint(CPoint *center, CPoint *p1, CPoint *p2, CPoint *p3);

	// Is right hand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Right Hand, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*a---A pointer to the const CPoint  or NULL if the call failed.  
	//		*b---A pointer to the const CPoint  or NULL if the call failed.  
	//		*c---A pointer to the const CPoint  or NULL if the call failed.
	static BOOL IsRightHand(const CPoint *a, const CPoint *b, const CPoint *c);

	// Create rhomb rectangle points.
	// cCtlPt -- points that generated.
	// ptCenter -- center point of rhomb.
	// szRect -- rectangle of rhomb
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Rhomb, .
	// This member function is a static function.
	// Parameters:
	//		cCtlPt---Ctl Point, Specifies A LPPOINT Points array.  
	//		&ptCenter---&ptCenter, Specifies A integer value.  
	//		&szRect---&szRect, Specifies a const FOPSize &szRect object(Value).
	static void GenRhomb(LPPOINT cCtlPt, const FOPPoint &ptCenter, const FOPSize &szRect );

	// Obtain point on circle by a specify angle.
	// rect -- rectangle of circle.
	// angle -- angle for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point On Circle, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).  
	//		angle---Specifies a double angle object(Value).
	static FOPPoint GetPointOnCircle( const FOPRect& rect, double angle );

	// Make arc
	// points -- arc points that madon.
	// rect -- arc's bounding rectangle.
	// startAngle -- start angle of the arc.
	// angles -- arc angles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Arc, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&points---Specifies A CPoint type value.  
	//		rect---Specifies a const FOPRect& rect object(Value).  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		angles---Specifies a double angles object(Value).
	static void MakeArc( CArray<CPoint,CPoint> &points,const FOPRect& rect,double startAngle, 
		double angles );

	// Draw radial gradient with start and end color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Radial Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		sColor---sColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		eColor---eColor, Specifies A 32-bit COLORREF value used as a color value.  
	//		bCircle---bCircle, Specifies A Boolean value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void RadialGradient(HDC hDC, LPRECT lpRect, COLORREF sColor, COLORREF eColor, BOOL bCircle, BOOL bGamma=FALSE, double gamma=0.4);

	// Multiple colors horizontal gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multicolor Horizontal Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		colors[]---Specifies A 32-bit COLORREF value used as a color value.  
	//		numColors---numColors, Specifies A integer value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void MulticolorHorizontalGradient(HDC hDC, LPRECT lpRect, COLORREF colors[], int numColors, BOOL bGamma=FALSE, double gamma=0.4);

	// Multiple colors horizontal gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multicolor Horizontal Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		hRgn---hRgn, Specifies a HRGN hRgn object(Value).  
	//		colors[]---Specifies A 32-bit COLORREF value used as a color value.  
	//		numColors---numColors, Specifies A integer value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void MulticolorHorizontalGradient(HDC hDC, HRGN hRgn, COLORREF colors[], int numColors, BOOL bGamma=FALSE, double gamma=0.4);

	// Multiple colors vertical gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multicolor Vertical Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		colors[]---Specifies A 32-bit COLORREF value used as a color value.  
	//		numColors---numColors, Specifies A integer value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void MulticolorVerticalGradient(HDC hDC, LPRECT lpRect, COLORREF colors[], int numColors, BOOL bGamma=FALSE, double gamma=0.4);

	// Multiple colors vertical gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multicolor Vertical Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		hRgn---hRgn, Specifies a HRGN hRgn object(Value).  
	//		colors[]---Specifies A 32-bit COLORREF value used as a color value.  
	//		numColors---numColors, Specifies A integer value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void MulticolorVerticalGradient(HDC hDC, HRGN hRgn, COLORREF colors[], int numColors, BOOL bGamma=FALSE, double gamma=0.4);

	// Multiple colors radial gradient drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multicolor Radial Gradient, .
	// This member function is a static function.
	// Parameters:
	//		hDC---D C, Specifies a HDC hDC object(Value).  
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		colors[]---Specifies A 32-bit COLORREF value used as a color value.  
	//		numColors---numColors, Specifies A integer value.  
	//		bCircle---bCircle, Specifies A Boolean value.  
	//		bGamma---bGamma, Specifies A Boolean value.  
	//		gamma---Specifies a double gamma=0.4 object(Value).
	static void MulticolorRadialGradient(HDC hDC, LPRECT lpRect, COLORREF colors[], int numColors, BOOL bCircle, BOOL bGamma=FALSE, double gamma=0.4);

	// Is approx.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Approx, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		x---Specifies A float value.  
	//		y---Specifies A float value.
	static BOOL IsApprox(float x, float y);

	// Get ortho segment of two lines.
	// A -- first point of line 1.
	// B -- second point of line 1.
	// C -- first point of line 2.
	// D -- second point of line 2.
	// result -- result point that intersection.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ortho Segment Intersection, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&A---&A, Specifies A CPoint type value.  
	//		&B---&B, Specifies A CPoint type value.  
	//		&C---&C, Specifies A CPoint type value.  
	//		&D---&D, Specifies A CPoint type value.  
	//		&result---Specifies A CPoint type value.
	static BOOL GetOrthoSegmentIntersection(const CPoint &A, const CPoint &B,
		const CPoint &C, const CPoint &D, CPoint &result);

	// Are all points orthogonal lines.
	// pts -- points for checking.
	// nPtCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Orthogonal Line, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		&nPtCount---Point Count, Specifies A integer value.
	static BOOL IsOrthogonalLine(LPPOINT pts, const int &nPtCount);

	// Creates an arc given two points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc From Points, .
	// This member function is a static function.
	// Parameters:
	//		&pt1---Specifies A integer value.  
	//		&pt2---Specifies A integer value.  
	//		&rcBounds---&rcBounds, Specifies a FOPRect &rcBounds object(Value).  
	//		&startAngle---&startAngle, Specifies A float value.  
	//		&sweepAngle---&sweepAngle, Specifies A float value.
	static void ArcFromPoints(const FOPPoint &pt1, const FOPPoint &pt2, FOPRect &rcBounds,
			float &startAngle, float &sweepAngle);

	// Compute arc middle point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Arc Middle Point, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&ptEnd0---&ptEnd0, Specifies A integer value.  
	//		&ptEnd1---&ptEnd1, Specifies A integer value.  
	//		&center---Specifies A integer value.  
	//		&ptMid---&ptMid, Specifies A integer value.  
	//		ep0---A pointer to the const FOPPoint  or NULL if the call failed.  
	//		ep1---A pointer to the const FOPPoint  or NULL if the call failed.  
	//		midpoint---A pointer to the FOPPoint  or NULL if the call failed.
	static int ComputeArcMiddlePoint(const FOPPoint &ptEnd0, const FOPPoint &ptEnd1,
		const FOPPoint &center,
						 FOPPoint &ptMid, const FOPPoint * ep0, const FOPPoint * ep1 ,
						 FOPPoint * midpoint);

	// Get arc center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Get Arc Center, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		m_Point---m_Point, Specifies A integer value.  
	//		&m_Radius---&m_Radius, Specifies a const FOPSize &m_Radius object(Value).  
	//		&m_bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		&m_bIsClockwise---Is Clockwise, Specifies A Boolean value.  
	//		ptFrom---ptFrom, Specifies A integer value.  
	//		bIsLargeArc---Is Large Arc, Specifies A Boolean value.  
	//		rX---rX, Specifies a double& rX object(Value).  
	//		rY---rY, Specifies a double& rY object(Value).
	static FOPPoint FOP_GetArcCenter(const FOPPoint& m_Point, const FOPSize &m_Radius, const BOOL	&m_bIsLargeArc, 
						  const BOOL &m_bIsClockwise, const FOPPoint& ptFrom,
						  BOOL& bIsLargeArc, double& rX, double& rY);

	// Find point with specify angle.
	// For example, to find the point at angle of arc:
	//		FOPPoint pt;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Point With Angle, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is a static function.
	// Parameters:
	//		&r---Specifies a const FOPRect &r object(Value).  
	//		angle---Specifies A integer value.  
	//		angleLen---angleLen, Specifies A integer value.  
	//		*startPoint---*startPoint, A pointer to the FOPPoint  or NULL if the call failed.  
	//		*endPoint---*endPoint, A pointer to the FOPPoint  or NULL if the call failed.
    //		FindPointWithAngle(rect, angle, 0, &pt, 0);
	// r -- bounding rectangle of arc.
	// angle -- start angle for generate.
	// angleLen -- sweep angle.
	// startPoint -- start point of ARC.
	// endPoint -- end point of ARC.
	static void FindPointWithAngle(const FOPRect &r, int angle, int angleLen,
                            FOPPoint *startPoint, FOPPoint *endPoint);

	// Generate curves for arc, returns the start point of ARC.
	// rc -- bounding rectangle of arc.
	// startAngle -- start angle for generate.
	// sweepLength -- sweep angle.
	// ptsArc -- points that generated.
	// ptCount -- count of points that generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Curves Of Arc, .
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&rc---Specifies a const FOPRect &rc object(Value).  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		sweepLength---sweepLength, Specifies a double sweepLength object(Value).  
	//		*ptsArc---*ptsArc, A pointer to the FOPPoint  or NULL if the call failed.  
	//		*ptCount---*ptCount, A pointer to the int  or NULL if the call failed.
	static FOPPoint GenCurvesOfArc(const FOPRect &rc, double startAngle, double sweepLength,
                       FOPPoint *ptsArc, int *ptCount);

	// Calculate the shortest distance from point to line.
	// ptStart -- start point of line.
	// ptEnd -- end point of line.
	// ptCheck -- point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shortest Distance, .
	// This member function is a static function.
	//		Returns a float value.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		&ptCheck---&ptCheck, Specifies A integer value.
	static float ShortestDistance( const FOPPoint &ptStart, const FOPPoint &ptEnd,
		const FOPPoint &ptCheck );

	//  compute Arc distance.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Arc Distance, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&start---Specifies A integer value.  
	//		&end---Specifies A integer value.  
	//		&mid---Specifies A integer value.
	static double ComputeArcDistance(const FOPPoint &start, const FOPPoint &end, 
		const FOPPoint &mid);

	// Get center point of two points.
	// Obtain the center point of two points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&start---Specifies A integer value.  
	//		&end---Specifies A integer value.
	static FOPPoint GetCenterPoint(const FOPPoint &start, const FOPPoint &end);

	// Get percent point of two points.
	// Obtain the percent point of two points.
	// dPercent -- from 0.0 to 1.0.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Percent Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&start---Specifies A integer value.  
	//		&end---Specifies A integer value.  
	//		&dPercent---&dPercent, Specifies a const double &dPercent = 0.5 object(Value).
	static FOPPoint GetPercentPoint(const FOPPoint &start, const FOPPoint &end, const double &dPercent = 0.5);

	// generate arc or pie with given 3 points.
	// startpoint -- start point.
	// endpoint -- end point
	// midpoint -- midpoint
	// poly -- pointer of polygon that generated.
	// ptC -- center point of arc or pie.
	// bPie -- if you need to generate pie shape, it is TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Polygon Arc With3 Points, .
	// This member function is a static function.
	// Parameters:
	//		*startpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*endpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*midpoint---A pointer to the FOPPoint  or NULL if the call failed.  
	//		*poly---A pointer to the FOPSimplePolygon  or NULL if the call failed.  
	//		&ptC---&ptC, Specifies A integer value.  
	//		&bPie---&bPie, Specifies A Boolean value.
	static void GenPolyArcWith3Points(FOPPoint *startpoint, 
                      FOPPoint *endpoint,
                      FOPPoint *midpoint, 
					  FOPSimplePolygon *poly, FOPPoint &ptC,
					  const BOOL &bPie = FALSE);

	// 
	// Generates a color bitmap from the monochrome "custom fill" bitmap.
	// pDC-- pointer of DC.
	// pbmMono-- monochrome bitmap handle.
	// crColor -- color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Monochrome Bitmap, .
	// This member function is a static function.
	//		Returns a pointer to the object CBitmap,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pbmMono---*pbmMono, A pointer to the CBitmap  or NULL if the call failed.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	static CBitmap* GenMonochromeBitmap(CDC *pDC, CBitmap *pbmMono, const COLORREF & crColor);

	// Make text with ellipsis mode
	// dc -- dc.
	// str -- text for making
	// cx -- width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Text With Ellipsis, .
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&str---Specifies A CString type value.  
	//		width---Specifies A integer value.
	static CString MakeTextWithEllipsis(CDC *pDC, const CString &str, int width);

	// Generator angle value from giving values.
	// phyVal -- current physical value for calculating, it is a value between minimize value and maximize value.
	// minPhy -- minimize value.
	// maxPhy -- maximize value.
	// minAngle -- minimize angle value (Between 0 - 359), the 0 degree is at the top of the shape.
	// maxAngle -- maximize angle value (Between 0 - 359), the 0 degree is at the top of the shape.
	// return value -- the angle value (From min - max), to use this value just use: (float)alpha * 180 / F_PI;
	// Example:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Value To Angle, .
	// This member function is a static function.
	//		Returns a float value.  
	// Parameters:
	//		phyVal---phyVal, Specifies A float value.  
	//		minPhy---minPhy, Specifies A float value.  
	//		maxPhy---maxPhy, Specifies A float value.  
	//		minAngle---minAngle, Specifies A float value.  
	//		maxAngle---maxAngle, Specifies A float value.
	//  double dValue = CFODrawHelper::ConvertValueToAngle(airSpeed, 0, 800, 180, 468);
	//  double dValue = CFODrawHelper::ConvertValueToAngle(airSpeed, 0, 800, 0, 359);
	static float ConvertValueToAngle(float phyVal, float minPhy, float maxPhy, float minAngle, float maxAngle);

	// Convert value to position.
	// nCurValue -- current value.
	// minValue -- minimize value.
	// maxValue -- maximize value.
	// rcBound -- bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Horizontal Value To Position, .
	// This member function is a static function.
	//		Returns a float value.  
	// Parameters:
	//		nCurValue---Current Value, Specifies A float value.  
	//		minValue---minValue, Specifies A float value.  
	//		maxValue---maxValue, Specifies A float value.  
	//		&rcBound---&rcBound, Specifies A CRect type value.
	static float ConvertHorzValueToPosition(float nCurValue, float minValue, float maxValue, const CRect &rcBound);

	// Convert value to position.
	// nCurValue -- current value.
	// minValue -- minimize value.
	// maxValue -- maximize value.
	// rcBound -- bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Vertical Value To Position, .
	// This member function is a static function.
	//		Returns a float value.  
	// Parameters:
	//		nCurValue---Current Value, Specifies A float value.  
	//		minValue---minValue, Specifies A float value.  
	//		maxValue---maxValue, Specifies A float value.  
	//		&rcBound---&rcBound, Specifies A CRect type value.
	static float ConvertVertValueToPosition(float nCurValue, float minValue, float maxValue, const CRect &rcBound);

	// Mix color with another color with ratio value.
	// crColor1 -- color that will be mixed.
	// crColor2 -- color that will be used to mix.
	// dRatio -- ratio value from 0.0 to 1.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mix With Color, .
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		crColor1---crColor1, Specifies A 32-bit COLORREF value used as a color value.  
	//		crColor2---crColor2, Specifies A 32-bit COLORREF value used as a color value.  
	//		dRatio---dRatio, Specifies a double dRatio object(Value).
	static COLORREF MixWithColor(COLORREF crColor1, COLORREF crColor2, double dRatio);

	// Obtain the quick distance.
	// p1 -- first point of line segment.
	// p2 -- second point of line segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Quick Distance, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		&p1---Specifies A integer value.  
	//		&p2---Specifies A integer value.
	static double GetQuickDistance(const FOPPoint &p1, const FOPPoint &p2);

	// Get string after seperator.
	static CString GetStringAfterSeperator(CString strValue, CString strSeperator);

	// Split path to folder and file.
	static void SplitPath(CString strFilePath, CString& strFolder, CString& strFileName);

	// Replace one string to another.
	static CString foReplaceString(CString& strTarget, CString strFind, CString strReplace);

	// Obtain the intersect point of two orghogonal lines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Orthogonal Intersect, Returns the specified value.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&pt1---Specifies A integer value.  
	//		&pt2---Specifies A integer value.  
	//		&pt3---Specifies A integer value.  
	//		&pt4---Specifies A integer value.  
	//		&ptOutIntersect---Out Intersect, Specifies A integer value.
	static BOOL GetOrthogonalIntersect(const FOPPoint &pt1, const FOPPoint &pt2, 
			const FOPPoint &pt3, const FOPPoint &pt4, FOPPoint &ptOutIntersect);

	// Check if Rectangle intersect with line segment.
	// rect -- rectangle.
	// ptLineStart -- line start point.
	// ptLineEnd -- line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rectangle Intersects With Line Segment, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rect---Specifies a FOPRect rect object(Value).  
	//		&ptLineStart---Line Start, Specifies A integer value.  
	//		&ptLineEnd---Line End, Specifies A integer value.
	static BOOL RectIntersectsWithLineSegment(FOPRect rect, const FOPPoint &ptLineStart,
		const FOPPoint &ptLineEnd);

	// Gets angle between three points.
	// ptA -- first point.
	// pt0 -- second point.
	// ptB -- third point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptA---ptA, Specifies A integer value.  
	//		ptO---ptO, Specifies A integer value.  
	//		ptB---ptB, Specifies A integer value.
	static double GetLineAngle(FOPPoint ptA, 
		FOPPoint ptO, 
			FOPPoint ptB);

	// Obtain projection point that lies on the line
	// ptPoint -- point of checking.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Projection Point, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		&ptPoint---&ptPoint, Specifies A integer value.  
	//		&ptLineStart---Line Start, Specifies A integer value.  
	//		&ptLineEnd---Line End, Specifies A integer value.
	static FOPPoint GetLineProjectionPoint(const FOPPoint &ptPoint, const FOPPoint &ptLineStart, 
		const FOPPoint &ptLineEnd);

	// Offset all points.
	// pts -- points array for converting.
	// nCount -- count of points.
	// ptOffset -- offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is a static function.
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A integer value.
	static void OffsetAllPoints( LPPOINT pts,int nCount, const FOPPoint &ptOffset );

	// Offset all points.
	// pts -- points array for converting.
	// nCount -- count of points.
	// ptOffset -- offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is a static function.
	// Parameters:
	//		pts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		&ptOffset---&ptOffset, Specifies A integer value.
	static void XOffsetAllPoints( FOPFloat* pts,int nCount, const FOPFloat &ptOffset );

	// File all the file names in the current fold, which has the reqired file type
	// lstFiles -- a string list collects the file names
	// fileExt A string of the file types, such as "C:\Temp\*.doc", or ".txt"
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Files By Type, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		lstFiles---lstFiles, Specifies A CString type value.  
	//		fileExt---fileExt, Specifies A CString type value.
	static void GetFilesByType(CStringList& lstFiles, CString fileExt);

	// Create Parallel line -- ping xing line
	// lpPoints -- points of line.
	// nCount -- point count.
	// lpOutLinePts -- output line points, should call delete lpOutLinePts after calling.
	// nOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Parallel Line, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		lpOutLinePts---Out Line Pts, Specifies A LPPOINT Points array.  
	//		nOffset---nOffset, Specifies A integer value.
	static void CreateParallelLine(LPPOINT lpPoints, int nCount, LPPOINT& lpOutLinePts, int nOffset);

	// Create spline parallel spline line -- ping xing spline line.
	// lpPoints -- points of line.
	// nCount -- point count.
	// lpOutLinePts -- output line points, should call delete lpOutLinePts after calling.
	// nOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Parallel Spline, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		lpOutLinePts---Out Line Pts, Specifies A LPPOINT Points array.  
	//		nOffset---nOffset, Specifies A integer value.
	static void CreateParallelSpline(LPPOINT lpPoints, int nCount, LPPOINT& lpOutLinePts, int nOffset);

	// calculate the area of giving points.
	// lpPoints -- points for calculate.
	// nCount -- point count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Area, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	static double CalculateArea(LPPOINT lpPoints, int nCount);

	// Calculate the angle between three points.
	// ptFirst -- first point.
	// ptSecond -- second point.
	// ptIntersect -- intersect point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Angle, .
	// This member function is a static function.
	//		Returns a CString type value.  
	// Parameters:
	//		&ptFirst---&ptFirst, Specifies A integer value.  
	//		&ptSecond---&ptSecond, Specifies A integer value.  
	//		&ptIntersect---&ptIntersect, Specifies A integer value.
	static CString CalculateAngle(const FOPPoint &ptFirst, const FOPPoint &ptSecond, const FOPPoint &ptIntersect);

	// Calculate arc's points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Create Arc, .
	// This member function is a static function.
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.  
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dRadius---dRadius, Specifies a double dRadius object(Value).  
	//		angle1---Specifies a double angle1 object(Value).  
	//		angle2---Specifies a double angle2 object(Value).  
	//		reversed---Specifies A Boolean value.
	static void FOPCreateArc(CArray<CPoint,CPoint>* ptArray,
		const FOPPoint& ptCenter, double dRadius, double angle1, double angle2, bool reversed) ;

	// Convert from array to points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Array, .
	// This member function is a static function.
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.  
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	static void ConvertToArray(LPPOINT lpPoints, int nCount, CArray<CPoint,CPoint>* ptArray);

	// Get point on a line segment.
	// from -- line from point.
	// to -- line to point.
	// value -- ratio value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point On Segment, Returns the specified value.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		from---Specifies A integer value.  
	//		to---Specifies A integer value.  
	//		value---Specifies a double value object(Value).
	static FOPPoint GetPointOnSegment(FOPPoint from, FOPPoint to, double value);

	// Obtain the point with value.
	// val -- currently value.
	// rcA -- bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get C Pointor Value, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		val---Specifies a double val object(Value).  
	//		&rcA---&rcA, Specifies a const FOPRect &rcA object(Value).
	static CPoint GetCPointorValue(double val, const FOPRect &rcA);

	// Compare two strings.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Two String Eq, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&str1---Specifies A CString type value.  
	//		&str2---Specifies A CString type value.
	static BOOL IsTwoStringEq(const CString &str1, const CString &str2);

	// Obtain point at specify angle, ellipse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point At Angle, Returns the specified value.
	// This member function is a static function.
	//		Returns a CPoint type value.  
	// Parameters:
	//		ang---Specifies a double ang object(Value).  
	//		&rcA---&rcA, Specifies a const FOPRect &rcA object(Value).
	static FOPFloat GetPointAtAngle(double ang, const FOPRect &rcA);

	// Display number
	static void DisplayNumber(CDC *pDC, float number, const FOPRect &drect, const COLORREF &crFill);

	// loading text file
	static BOOL LoadTextFile( LPCTSTR pcszFilename, LPTSTR &pszBuffer , UINT &uLength);


	// Obtain point in ellipse.
	// rc -- rectangle of ellipse.
	// angle -- angle from 0 - 360.
	static FOPPoint GetPointOnEllipse(FOPRect rc, double angle);

public:
	// Drawing shape with complex polygons
	// pDC -- pointer of the CDC.
	// pPoints -- points for drawing.
	// pPtAry -- points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Polygon Polygon New, Draws current object to the specify device.
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		nPoly---nPoly, Specifies A 32-bit LONG signed integer.  
	//		pPoints---pPoints, A pointer to the const ULONG or NULL if the call failed.  
	//		pPtAry---Point Array, A pointer to the FOPCONSTPOINT or NULL if the call failed.
	static void DrawPolyPolygonNew(CDC *pDC,ULONG nPoly, const ULONG* pPoints, FOPCONSTPOINT* pPtAry);

	// Extend polypolygon drawing.
	// pDC -- pointer of the dc.
	// aPathPoly -- path polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Draw Polygon Polygon New, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aPathPoly---Path Polygon, Specifies a const FOPPolyPolygon& aPathPoly object(Value).
	static void FODrawPolyPolygonNew(CDC *pDC,const FOPPolyPolygon& aPathPoly);

	// Generate spline points
	// lpShapePoints -- basic shape points that need to be converted.
	// nPointCount -- total points that need to be converted.
	// lpSplinePoints -- points that converted.
	// nSpPtCount -- points count that converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Spline Points, .
	// This member function is a static function.
	// Parameters:
	//		lpShapePoints---Shape Points, Specifies A LPPOINT Points array.  
	//		nPointCount---Point Count, Specifies A integer value.  
	//		lpSplinePoints---Spline Points, Specifies A LPPOINT Points array.  
	//		nSpPtCount---Sp Point Count, Specifies A integer value.
	static void GenSplinePoints(LPPOINT lpShapePoints, int nPointCount, 
		LPPOINT& lpSplinePoints, int& nSpPtCount);

	// Generate spline points
	// lpShapePoints -- basic shape points that need to be converted.
	// nPointCount -- total points that need to be converted.
	// lpSplinePoints -- points that converted.
	// nSpPtCount -- points count that converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Spline Points, .
	// This member function is a static function.
	// Parameters:
	//		lpShapePoints---Shape Points, Specifies A LPPOINT Points array.  
	//		nPointCount---Point Count, Specifies A integer value.  
	//		lpSplinePoints---Spline Points, Specifies A LPPOINT Points array.  
	//		nSpPtCount---Sp Point Count, Specifies A integer value.
	static void GenSplinePointsCAD(LPPOINT lpShapePoints, int nPointCount, 
		LPPOINT& lpSplinePoints, int& nSpPtCount);

	// Convert basic GDI flags to simple flags.
	// pFromFlags -- flags that need to be converted.
	// pToFlags -- flags that convert to.
	// nCount -- count of flags that need to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To Basic Flags, .
	// This member function is a static function.
	// Parameters:
	//		*pFromFlags---From Flags, A pointer to the const BYTE  or NULL if the call failed.  
	//		*pToFlags---To Flags, A pointer to the BYTE  or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.
	static void ConvertToBasicFlags(const BYTE *pFromFlags,BYTE *pToFlags,int nCount);

	// Create automatic size font.
	// Determines the size of the font required to draw the text with. The font is then created and returned.
	// hdc -- handle of dc.
	// rect -- pointer of rectangle.
	// string -- string for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Automatic Size Font, .
	// This member function is a static function.
	//		Returns A HFONT value (Object).  
	// Parameters:
	//		hdc---Specifies a HDC hdc object(Value).  
	//		*rect---A pointer to the RECT  or NULL if the call failed.  
	//		string---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	static HFONT GenAutoSizeFont(HDC hdc, RECT *rect,LPCTSTR string);

	static void FOPCubicSpline (FOPSimplePolygon &pKnownPoints,
		int      n,
		int      splineSize,
				  FOPSimplePolygon &pSplines);

	// Create control's meta file
	// pWnd -- pointer of window
	// size -- size of meta file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Meta File With , You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns A HENHMETAFILE value (Object).  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		&size---Specifies A CSize type value.
	static HENHMETAFILE CreateMetaFileWithControl(CWnd *pWnd, const CSize &size );

	// Reposition a point to a new rectangle.
	// pt -- pt for reposition.
	// rcOld -- old rectangle.
	// rcNewPos -- new rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reposition Point, .
	// This member function is a static function.
	// Parameters:
	//		&pt---Specifies A CPoint type value.  
	//		&rcOld---&rcOld, Specifies A CRect type value.  
	//		&rcNewPos---New Position, Specifies A CRect type value.
	static void RepositionPoint(CPoint &pt, const CRect &rcOld,const CRect &rcNewPos);

	//  Creates a tangent between a given point and a ellipse or circle.
	// Out of the 2 possible tangents, the one closest to
	// the given coordinate is returned.
	// ptNear -- the tangent line near to this point.
	// point -- point for checking
	// ptC -- center of ellipse
	// ptMajor -- major point of ellipse.
	// radius1 -- radius of ellipse
	// radius2 -- radius of ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Tangent From Point To Circle, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object FOPLine,or NULL if the call failed  
	// Parameters:
	//		ptNear---ptNear, Specifies A integer value.  
	//		point---Specifies A integer value.  
	//		ptC---ptC, Specifies A integer value.  
	//		&ptMajor---&ptMajor, Specifies A integer value.  
	//		&radius1---Specifies a const double &radius1 object(Value).  
	//		&radius2---Specifies a const double &radius2 object(Value).
	static FOPLine* CreateTangentFromPointToCircle(const FOPPoint& ptNear,
		const FOPPoint& point,
		const FOPPoint& ptC, const FOPPoint &ptMajor, const double &radius1, const double &radius2);

	// Create tangent line from two circle.
	// ptNear -- the tangent line near to this point.
	// ptC1 -- center of circle 1
	// r1 -- radius of circle 1
	// ptC2 -- center of circle 2
	// r2 -- radius of circle 2
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Tangent From Two Circle, You construct a CFODrawHelper object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object FOPLine,or NULL if the call failed  
	// Parameters:
	//		ptNear---ptNear, Specifies A integer value.  
	//		ptC1---ptC1, Specifies A integer value.  
	//		&r1---Specifies a const double &r1 object(Value).  
	//		ptC2---ptC2, Specifies A integer value.  
	//		&r2---Specifies a const double &r2 object(Value).
	static FOPLine* CreateTangentFromTwoCircle(const FOPPoint& ptNear,
                                     const FOPPoint& ptC1, const double &r1, 
                                     const FOPPoint& ptC2, const double &r2);

	// Draw multiple line text with ellipse support.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Multiple Line Text With Ellipse, Draws current object to the specify device.
	// This member function is a static function.
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nTextCount---Text Count, Specifies A integer value.  
	//		&rcBound---&rcBound, Specifies A CRect type value.  
	//		nTextFormat---Text Format, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpClipRect---Clipboard Rectangle, Specifies a LPRECT lpClipRect object(Value).
	static int DrawMultiLineTextWithEllipse(CDC* pDC, LPCTSTR strText, int nTextCount,
		const CRect &rcBound, UINT nTextFormat, LPRECT lpClipRect);

	// FIX device mode.
	// This function must be called anytime the DEVMODE structure is modified in any way;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fix Device Mode, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hModDev---Mod Device, Specifies a HGLOBAL hModDev object(Value).
	static BOOL FixDevMode(HGLOBAL hModDev);
	
	//  Axis up
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Axis Invert, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dc---Specifies a const CDC& dc object(Value).
	static BOOL IsAxisInvert(const CDC& dc);

	
public:

	// Draw cool background.
	static void FOP_DrawCoolBack(CDC* pDC, const CPoint &ptCorner, const CSize szBack,
		int nOutsideRadius = 8, int nInnerRadius = 3,
	
	//-----------------------------------------------------------------------
	// Summary:
	// G B, .
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		255---Specifies a 255 object(Value).  
	//		206---Specifies a 206 object(Value).  
	//		160)---Specifies a 160) object(Value).  
	//		fThetta---fThetta, Specifies A float value.  
	//		fPhi---fPhi, Specifies A float value.  
	//		fLightIntensity---Light Intensity, Specifies A float value.  
	//		nPhong---nPhong, Specifies A integer value.  
	//		fMirror---fMirror, Specifies A float value.  
	//		fDiffuse---fDiffuse, Specifies A float value.  
	//		fAmbient---fAmbient, Specifies A float value.  
	//		pPalette---pPalette, A pointer to the CPalette or NULL if the call failed.  
	//		crBack---crBack, Specifies A 32-bit COLORREF value used as a color value.
		COLORREF crFace = RGB(255,137,87),
		COLORREF crLight = RGB(255,206,160),
		float fThetta=60, float fPhi=-45,
		float fLightIntensity = 1.3f,	int nPhong = 15, float fMirror = 0.6f,
		float fDiffuse = 0.5f, float fAmbient = 0.9f,
		CPalette* pPalette = NULL,
		COLORREF crBack = CLR_NONE);

	// Draw complex gradient.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P_ Draw Complex Gradient, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		rGradient---rGradient, Specifies a const FOPGradient& rGradient object(Value).
	static void FOP_DrawComplexGradient(CDC *pDC, const FOPRect& rRect, const FOPGradient& rGradient);

	// Compare two double values
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compare Double, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dFirst---dFirst, Specifies a double dFirst object(Value).  
	//		dSecond---dSecond, Specifies a double dSecond object(Value).
	static BOOL CompareDouble(double dFirst, double dSecond);

	// Obtain the product string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Product String1, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		&str1---Specifies A CString type value.
	static void GetProductString1(CString &str1);

	// Obtain the product string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Product String2, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		&str1---Specifies A CString type value.
	static void GetProductString2(CString &str1);

	// Obtain the product string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Product String3, Returns the specified value.
	// This member function is a static function.
	// Parameters:
	//		&str1---Specifies A CString type value.
	static void GetProductString3(CString &str1);

public:
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path, None Description.
	//		Returns a CString type value.  
	// Parameters:
	//		PathAndFileName---Path And File Name, Specifies A CString type value.  
	//		bIncludeFileSystem---Include File System, Specifies A Boolean value.
	static CString XGetPath(const CString& PathAndFileName, const BOOL bIncludeFileSystem /* = TRUE */);
	
	// Obtain the base file name.
	static CString XGetBaseFileName(const CString& strFileName);

	// Rename file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rename File, Call this function to Changes the name of the object.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strOld---strOld, Specifies A CString type value.  
	//		strNew---strNew, Specifies A CString type value.
	static BOOL RenameFile(const CString& strOld, const CString& strNew);

	// Copy the full directory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy Directory And Files, Create a duplicate copy of this object.
	//		Returns A Boolean value.  
	// Parameters:
	//		csSource---csSource, Specifies A CString type value.  
	//		csDest---csDest, Specifies A CString type value.
	static bool CopyDirAndFiles(CString csSource, CString csDest);

	// Obtain the file name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File Name, None Description.
	//		Returns a CString type value.  
	// Parameters:
	//		PathAndFileName---Path And File Name, Specifies A CString type value.
	static CString XGetFileName(const CString& PathAndFileName);

	// Delete file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete File, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		FileName---File Name, Specifies A CString type value.
	static BOOL XDeleteFile(const CString& FileName);

	// Is directory exist or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Directory Exists, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		Path---Path, Specifies A CString type value.
	static BOOL DirectoryExists(const CString& Path);
	
	// Make a new directory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Directory, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pcszDirectory---pcszDirectory, Specifies A CString type value.
	static BOOL MakeDirectory(const CString& pcszDirectory);
	
	// Is file exist or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// File Exists, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFilePath---File Path, Specifies A CString type value.
	static BOOL XFileExists(CString strFilePath);
	
	// Obtain the file extension.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extension, None Description.
	//		Returns a CString type value.  
	// Parameters:
	//		PathAndFileName---Path And File Name, Specifies A CString type value.
	static CString XGetExtension(const CString& PathAndFileName);
	
	// Make new directory.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Make Directory, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		NewDirectory---New Directory, Specifies A CString type value.
	static BOOL XFOPMakeDirectory(const CString& NewDirectory);

public:
	// Obtain the average color between two colors.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Average Color, Returns the specified value.
	// This member function is a static function.
	//		Returns A 32-bit COLORREF value used as a color value.  
	// Parameters:
	//		&c1---Specifies A 32-bit COLORREF value used as a color value.  
	//		&c2---Specifies A 32-bit COLORREF value used as a color value.
	static COLORREF GetAverageColor(const COLORREF &c1, const COLORREF &c2);
 
	// Drawing fast fill rectangle.
	// pDC -- pointer of DC.
	// rcFill -- rectangle for filling.
	// crColor -- color for filling.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Rectangle Fast, .
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcFill---&rcFill, Specifies a const FOPRect &rcFill object(Value).  
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	static void FillRectFast(CDC *pDC, const FOPRect &rcFill, const COLORREF &crColor);

	// Drawing fast fill rectangle.
	// pDC -- pointer of DC.
	// rcFill -- rectangle for filling.
	// crColor -- color for filling.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fill Rectangle Fast2, .
	// This member function is a static function.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		dx---Specifies A integer value.  
	//		dy---Specifies A integer value.  
	//		rgb---Specifies A 32-bit COLORREF value used as a color value.
	static void FillRectFast2(CDC* pDC,int x,int y,int dx,int dy, COLORREF rgb);

	// Is three points clock wise or not.
	// pt1 -- first point.
	// pt2 -- second point.
	// pt3 -- third point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Three Points Clockwise, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.
	static BOOL IsThreePointsClockwise(const FOPPoint & pt1, const FOPPoint & pt2, const FOPPoint & pt3);

	// Obtain distance from point to polyline
	// pt -- point for checking.
	// pts -- points of polygon.
	// nPtCount -- point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance From Point To Polygon, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		pts---A pointer to the FOPPoint or NULL if the call failed.  
	//		nPtCount---Point Count, Specifies A integer value.
	static double GetDistanceFromPointToPolygon( const FOPPoint& pt, FOPPoint* pts, int nPtCount);

	// is point in polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Point In Polygon, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		polygon---A pointer to the FOPPoint or NULL if the call failed.  
	//		nCount---nCount, Specifies A integer value.
	static BOOL IsPointInPolygon( const FOPPoint& pt, FOPPoint* polygon, int nCount); 

	// Is point on line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Point On Line, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	static BOOL IsPointOnLine( const FOPPoint& pt, const FOPPoint& ptStart, const FOPPoint& ptEnd );
	
	// Is point on segment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Point On Segment, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	static BOOL IsPointOnSegment( const FOPPoint& pt, const FOPPoint& ptStart, const FOPPoint& ptEnd ); 						
	
	// Is two segments intersected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Segments Intersect, Do a event. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		r1---Specifies A integer value.  
	//		r2---Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	static BOOL DoSegmentsIntersect( const FOPPoint& r1, const FOPPoint& r2, const FOPPoint& ptStart, const FOPPoint& ptEnd ); 	 
	
	// Delta from line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delta From Line, .
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	static double DeltaFromLine( const FOPPoint& pt, const FOPPoint& ptStart, const FOPPoint& ptEnd ); 

	// Obtain the distance between point to rectangle.
	// pt -- point for checking.
	// rc -- rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance Between Point And Rectangle, Returns the specified value.
	// This member function is a static function.
	//		Returns A double value (Object).  
	// Parameters:
	//		pt---Specifies A integer value.  
	//		rc---Specifies a const FOPRect& rc object(Value).
	static double GetDistanceBetweenPointAndRect( const FOPPoint& pt, const FOPRect& rc);

	// Register Window class
	//     hInstance - Handle of the instance.
	//     lpszClassName - class name
	//     style - style.
	//     hIcon - Handle of the icon
	//     hbrBackground - Handle of the background brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Registry Window Class, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		hInstance---hInstance, Specifies a HINSTANCE hInstance object(Value).  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		style---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		hIcon---hIcon, Specifies a HICON hIcon = 0 object(Value).  
	//		hbrBackground---hbrBackground, Specifies a HBRUSH hbrBackground = 0 object(Value).
	static BOOL RegWndClass(HINSTANCE hInstance, LPCTSTR lpszClassName,
		UINT style, HICON hIcon = 0, HBRUSH hbrBackground = 0);

	// Generate bitmap from binary data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Bitmap From Binary Data, .
	// This member function is a static function.
	//		Returns A HBITMAP value (Object).  
	// Parameters:
	//		pBuff---pBuff, Specifies An 8-bit BYTE integer that is not signed.
	static HBITMAP GenBitmapFromBinaryData(LPBYTE pBuff);

	// Convert to string.
	static CString SVG_NumToString(const int &num);

	// Convert arc to svg text.
	static CString SVG_Arc2SvgPath(float x, float y, float width, float height, float startAngle,
                                             float sweepAngle, bool pie);

public:
	// Do color changing.
	// Make lighter
	static COLORREF MakeLighter(COLORREF rgb, double dblRatio);
	
	// Make lower
	static COLORREF MakeDarker(COLORREF rgb, double dblRatio);

	// Make pale
	static COLORREF MakePale(COLORREF rgb, double dblLum);

public:

	// Math methods.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	//		Returns a pointer to the object char,or NULL if the call failed  
	// Parameters:
	//		val---Specifies a double val object(Value).  
	//		count---Specifies A integer value.  
	//		dec---A pointer to the int  or NULL if the call failed.  
	//		sign---A pointer to the int  or NULL if the call failed.
	static char* fcvt(double val, int count, int * dec, int * sign);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the char  or NULL if the call failed.  
	//		size---Specifies a size_t size object(Value).  
	//		src---A pointer to the const char  or NULL if the call failed.  
	//		count---Specifies a size_t count object(Value).
	static void strncpy(char * dest, size_t size, const char * src, size_t count);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the char  or NULL if the call failed.  
	//		size---Specifies a size_t size object(Value).  
	//		src---A pointer to the const char  or NULL if the call failed.  
	//		...---Specifies a ... object(Value).
	static void sprintf(char * dest, size_t size, const char * src, ...);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the TCHAR  or NULL if the call failed.  
	//		size---Specifies a size_t size object(Value).  
	//		src---A pointer to the const TCHAR  or NULL if the call failed.  
	//		...---Specifies a ... object(Value).
	static void stprintf(TCHAR * dest, size_t size, const TCHAR * src, ...);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the TCHAR  or NULL if the call failed.  
	//		length---Specifies a SIZE_T length object(Value).  
	//		src---A pointer to the const TCHAR or NULL if the call failed.
	static void tcscat(TCHAR * dest, SIZE_T length, const TCHAR* src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the TCHAR  or NULL if the call failed.  
	//		size---Specifies a size_t size object(Value).  
	//		src---A pointer to the const TCHAR  or NULL if the call failed.  
	//		count---Specifies a size_t count object(Value).
	static void tcsncat(TCHAR * dest, size_t size, const TCHAR * src, size_t count);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the TCHAR  or NULL if the call failed.  
	//		length---Specifies a SIZE_T length object(Value).  
	//		src---A pointer to the const TCHAR or NULL if the call failed.
	static void tcscpy(TCHAR * dest, SIZE_T length, const TCHAR* src);
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// This member function is a static function.
	// Parameters:
	//		dest---A pointer to the TCHAR  or NULL if the call failed.  
	//		dstSize---dstSize, Specifies a size_t dstSize object(Value).  
	//		src---A pointer to the const TCHAR  or NULL if the call failed.  
	//		maxCount---maxCount, Specifies a size_t maxCount object(Value).
	static void tcsncpy(TCHAR * dest, size_t dstSize, const TCHAR * src, size_t maxCount);
	
protected:
	
	// Twips to 1/100 mm.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Twips To100s M M, .
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nIn---nIn, Specifies A 32-bit long signed integer.
	static long TwipsTo100sMM( long nIn );

	// Convert to 1/100 mm.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert To100s M M, .
	// This member function is a static function.
	//		Returns a CSize type value.  
	// Parameters:
	//		szSize---szSize, Specifies A CSize type value.
	static CSize ConvertTo100sMM( CSize& szSize );

	// Do draw linear gradient.
	// pDC -- pointer of DC.
	// aRect -- rectangle for drawing.
	// aGradient -- gradient type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Linear Gradient, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aRect---aRect, Specifies a const FOPRect& aRect object(Value).  
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	static void DoDrawLinearGradient(CDC *pDC,const FOPRect& aRect, const FOPGradient& aGradient);

	// Do draw complex gradient.
	// pDC -- pointer of DC.
	// aRect -- rectangle for drawing.
	// aGradient -- gradient type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Complex Gradient, Do a event. 
	// This member function is a static function.
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		aRect---aRect, Specifies a const FOPRect& aRect object(Value).  
	//		aGradient---aGradient, Specifies a const FOPGradient& aGradient object(Value).
	static void DoDrawComplexGradient(CDC *pDC,const FOPRect& aRect, const FOPGradient& aGradient);

	// Source.
	// aUnitSource -- source unit to be converted,it must be one of the following value:
	// 	enum FOP_UNIT
	// {
	// 	FOP_UINT_100S_MM,
	// 	FOP_UINT_10S_MM,
	// 	FOP_UINT_MM,
	// 	FOP_UINT_CM,
	// 	FOP_UINT_1000S_INCH,
	// 	FOP_UINT_100S_INCH,
	// 	FOP_UINT_10S_INCH,
	// 	FOP_UINT_INCH,
	// 	FOP_UINT_POINT,
	// 	FOP_UINT_TWIP,
	// 	FOP_UINT_PIXEL
	// };
	// aUnitDest -- dest unit,it must be one of the following value:
	// 	enum FOP_UNIT
	// {
	// 	FOP_UINT_100S_MM,
	// 	FOP_UINT_10S_MM,
	// 	FOP_UINT_MM,
	// 	FOP_UINT_CM,
	// 	FOP_UINT_1000S_INCH,
	// 	FOP_UINT_100S_INCH,
	// 	FOP_UINT_10S_INCH,
	// 	FOP_UINT_INCH,
	// 	FOP_UINT_POINT,
	// 	FOP_UINT_TWIP,
	// 	FOP_UINT_PIXEL
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Logic To Logic, .
	// This member function is a static function.
	//		Returns A 32-bit long signed integer.  
	// Parameters:
	//		nLongSource---Long Source, Specifies A 32-bit long signed integer.  
	//		aUnitSource---Unit Source, Specifies a FOP_UNIT aUnitSource object(Value).  
	//		aUnitDest---Unit Dest, Specifies a FOP_UNIT aUnitDest object(Value).
	static long LogicToLogic(long nLongSource, FOP_UNIT aUnitSource, FOP_UNIT aUnitDest);

	// Convert bitmap to dib
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Bitmap2 Dib, .
	// This member function is a static function.
	//		Returns A HANDLE value (Object).  
	// Parameters:
	//		hbitmap---Specifies a HBITMAP hbitmap object(Value).  
	//		bits---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	static HANDLE  FOBitmap2Dib( HBITMAP hbitmap, UINT bits );

	// Clip 2d
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clip2d, Do a event. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rP0---rP0, Specifies A integer value.  
	//		rP1---rP1, Specifies A integer value.  
	//		rRectangle---rRectangle, Specifies a const FOPRect& rRectangle object(Value).
	static	BOOL DoClip2d(FOPPoint & rP0, FOPPoint & rP1, const FOPRect& rRectangle);

	// Clip point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clipboard Point, Do a event. 
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		fDenom---fDenom, Specifies a double fDenom object(Value).  
	//		fNum---fNum, Specifies a double fNum object(Value).  
	//		fTE---T E, Specifies a double & fTE object(Value).  
	//		fTL---T L, Specifies a double & fTL object(Value).
	static	BOOL DoClipPt(double fDenom, double fNum, double & fTE, double & fTL);

};

class FO_EXT_CLASS FOXXSpline
{
	
public:
	int  NP;
	float*  Mat[3];
	float*  k;
	float* Px;
	float* Py;
	CArray<float,float>Ax;
	CArray<float,float>Ay;
	CArray<float,float>Bx;
	CArray<float,float>By;
	CArray<float,float>Cx;
	CArray<float,float>Cy;
	CArray<POINT,POINT> m_CtrlPtArray;
	CArray<POINT,POINT> m_FitPtArray;
public:
	// constructor
	FOXXSpline();
	//	FOXXSpline(POINT pt[], int np);
	//	FOXXSpline(float px[] , float py[] , int np) ;
	
	~FOXXSpline();
	void Generate() ;
	void Draw(CDC * pDC);
	int GetFitPointCount();
	void GetFitPoint(POINT points[], int& PointCount);
	void FreeMemory();
	//////////// closed cubic FOXXSpline ////////////////////
	void GenerateClosed() ;
	void drawClosed(HDC hdc) ;
	
	///// tridiagonal matrix + elements of [0][0], [N-1][N-1] //// 
	void MatrixSolveEX(float B[]) ;
	void MatrixSolve(float B[]) ;
	int  IsInsideControlPoint(POINT point);
	double Distance(const POINT p1, const POINT p2);
	
	bool FindObject(CPoint p);
	bool FindObject(CRect rec);
	void SelectDraw(CDC *pDC);
	
};


/////////////////////////////////////////////////////////////////////////////////
//
// FOPPen
// 

class FO_EXT_CLASS FOPPen
{
public:
	// Constructor.
    FOPPen(CDC *pDC, CPen* pPen);
    FOPPen(CDC *pDC, DWORD dwStyle, UINT nWidth, COLORREF color);

	// Destructor.
    ~FOPPen();
	
protected:
    CDC *m_pDC;
    CPen*	m_pOldPen;
	CPen	m_pen;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPBrush
// 

class FO_EXT_CLASS FOPBrush
{
public:
	// Constructor.
    FOPBrush(CDC *pDC, CBrush* pBrush);
    FOPBrush(CDC *pDC, COLORREF color);
	FOPBrush(CDC *pDC, int nBrushType, COLORREF color);

	// Destructor.
    ~FOPBrush();
	
protected:
    CDC *m_pDC;
    CBrush* m_pOldBrush;
	CBrush	m_brush;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPFont
// 

class FO_EXT_CLASS FOPFont
{
public:
	// Constructor.
    FOPFont(CDC *pDC, CFont* pFont);
    FOPFont(CDC *pDC, int nPointSize, LPCTSTR lpszFaceName);
    FOPFont(CDC *pDC, const LOGFONT* pLogFont);

	// Destructor.
    ~FOPFont();
	
protected:
    CDC *m_pDC;
    CFont*	m_pOldFont;
	CFont	m_font;
};

/////////////////////////////////////////////////////////////////////////////////
//
// FOPTransDC
// 

class FO_EXT_CLASS FOPTransDC : public CDC
{
public:

	// Constructor.
    FOPTransDC(CDC& dc, double dblOpacity = 1.0f);
    FOPTransDC(CDC& dc, const CRect& area, double dblOpacity = 1.0f);
	void NotTrans();
	
	// Destructor.
    ~FOPTransDC();
	
protected:

	// Initital update
	void DoInit();
	
protected:
    HDC     m_hdc;
    CRect   m_rcClip;
	COLORREF* m_pBits;
    HBITMAP m_hBufferBitmap;
    HBITMAP m_hTempBitmap;
    BYTE    m_nOpacity;
	BOOL	m_bNotTrans;
};

#endif // !defined(AFX_FODRAWHELPER_H__2F9FA184_C1F8_11D5_A482_525400EA266C__INCLUDED_)
