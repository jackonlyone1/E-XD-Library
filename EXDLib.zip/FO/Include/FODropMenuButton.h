//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODROPMENUBUTTON_H__94576BB5_E22A_11D5_A4B3_525400EA266C__INCLUDED_)
#define AFX_FODROPMENUBUTTON_H__94576BB5_E22A_11D5_A4B3_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODropMenuButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFODropMenuButton window
#include "FOPMenuWndImpl.h"

 
//===========================================================================
// Summary:
//     The CFODropMenuButton class derived from CButton
//      F O Drop Menu Button
//===========================================================================

class FO_EXT_CLASS CFODropMenuButton : public CButton
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Drop Menu Button, Constructs a CFODropMenuButton object.
	//		Returns A  value (Object).
	CFODropMenuButton();

// Attributes
public:
	enum ArrowType
	{
		XDown,
		XRight
	};

	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach, Attaches this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.  
	//		nMenuID---Menu I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		*pAttach---*pAttach, A pointer to the CWnd  or NULL if the call failed.  
	//		nSubMenu---Child Menu, Specifies A integer value.  
	//		nType---nType, Specifies a ArrowType nType = XRight object(Value).
	// Attach the button to a specify ID.
	// nID -- the ID value.
	// pParent -- the pointer to parent window.
	// nMenuID -- the menu resource id.
	// pAttach -- the atach window.
	// bSubMenu -- sub menu index.
	BOOL Attach(const UINT nID,CWnd* pParent,UINT nMenuID,
		CWnd *pAttach,int nSubMenu = 0,ArrowType nType = XRight);

	// Set arrow type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Arrow Type, Sets a specify value to current class CFODropMenuButton
	// Parameters:
	//		nType---nType, Specifies a ArrowType nType object(Value).
	void SetArrowType(ArrowType nType);

	// Get arrow type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow Type, Returns the specified value.
	//		Returns A ArrowType value (Object).
	ArrowType GetArrowType() const;

// Operations
public:

	// On click button message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Click Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnClickButton();

	// Draw button state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Item, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void  DrawItem(LPDRAWITEMSTRUCT lpDIS);

	// Draw button face.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		lpDIS---D I S, Specifies a LPDRAWITEMSTRUCT lpDIS object(Value).
	virtual void  OnDrawButton(CDC* pDC, LPDRAWITEMSTRUCT lpDIS );

	// Draw button disabled state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Disabled, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		nWidth---nWidth, Specifies A integer value.  
	//		nHeight---nHeight, Specifies A integer value.
	virtual void  OnDrawDisabled(CDC* pDC, int nWidth, int nHeight);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODropMenuButton)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Post Nc Destroy, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Drop Menu Button, Destructor of class CFODropMenuButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFODropMenuButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFODropMenuButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu, Sets a specify value to current class CFODropMenuButton
	// Parameters:
	//		hMenu---hMenu, Specifies a HMENU hMenu object(Value).
	void SetMenu(HMENU hMenu);

protected:

 
	// This member specify CMenu object.  
	CMenu		m_menu;			// Drop menu.
 
	// Arrow Type, This member specify ArrowType object.  
	ArrowType	m_nArrowType;   // Arrow type.

 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush		m_brBrush;		// Fill brush.
 
	// Menu I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nMenuID;		// Menu ID.

 
	// Child Menu, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nSubMenu;		// Sub menu id.

 
	// Attach Edit, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd		*m_pAttachEdit; // Attach edit control point.
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODROPMENUBUTTON_H__94576BB5_E22A_11D5_A4B3_525400EA266C__INCLUDED_)
