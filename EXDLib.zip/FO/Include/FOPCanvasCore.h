//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPCANVASCORE_H__F1E8AEB4_98C3_4DFC_B40C_B758EBAF632A__INCLUDED_)
#define AFX_FOPCANVASCORE_H__F1E8AEB4_98C3_4DFC_B40C_B758EBAF632A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPCanvasCore.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPCanvasCore window

#include "FOShapeActorManager.h"
#include "FOAddCompAction.h"
#include "FORemoveCompAction.h"
#include "FORemoveCompsAction.h"
#include "FOAddCompsAction.h"
#include "FOAlignAction.h"
#include "FOMoveCompAction.h"
#include "FOFormSizeAndNameAction.h"
#include "FOFormSizeAction.h"
#include "FOMoveCompsAction.h"
#include "FOOrderAction.h"
#include "FOOrderSingleAction.h"
#include "FOScaleAction.h"
#include "FOSizeAction.h"
#include "FOSpacingAction.h"
#include "FODropTarget.h"
#include "FOBitmap.h"
#include "FOSizeSpotAction.h"
#include "FORotateAction.h"
#include "FOGroupAction.h"
#include "FOUnGroupAction.h"
#include "FOGroupShape.h"
#include "FOLinkShape.h"
#include "FOStaticShape.h"
#include "FOAddSpotAction.h"
#include "FORemoveSpotAction.h"
#include "FOCompsPropAction.h"
#include "FOMultiCompsPropAction.h"
#include "FOCompositeShape.h"
#include "FODataModel.h"
#include "FOWndControlShape.h"
#include "FOMoveAnchorAction.h"
#include "FOEditBoxShape.h"
#include "FOInsideBaseShape.h"
#include "FOPLineHandle.h"
#include "FOMirrorShapesAction.h"
#include "FOSkewAction.h"
#include "FOToolBoxPageWnd.h"
#include "FOPLayerAction.h"
#include "FOGeoAction.h"
#include "FOToolTipsWnd.h"
#include "FOPMsgShell.h"
#include "FOPanWnd.h"
#include "FODiamondShape.h"

#ifdef _FOP_E_SOLUTION
#include "E_Form\FOPNewGridShape.h"
#endif

#include "FOPRulerBar.h"
#include "FOSizePortAction.h"

#ifdef _FOP_TABLE_SOLUTION
#include "Table\FOPTableShape.h"
#include "Table\FOTableCellsAction.h"
#endif

class CFOPFindReplaceDlg;
class CFOPFindRepData;
class CFOPRegExp;
class FOXNewTableShape;
///////////////////////////////////////////////////////////////////
// Color.
///////////////////////////////////////////////////////////////////

#define FOP_EXT_MOVESHAPES_BACK			  4018

#define FOP_EXT_ACTIONTYPE_CONVERTPATH    4000
#define FOP_EXT_ACTIONTYPE_CONVERTPOLY    4001
#define FOP_EXT_ACTIONTYPE_COMBINE		  4002
#define FOP_EXT_ACTIONTYPE_MERGE		  4004
#define FOP_EXT_ACTIONTYPE_DISMANTLE	  4005
#define FOP_EXT_ACTIONTYPE_CLOSESHAPE	  4006
#define FOP_EXT_BEHINDSHAPE				  4007
#define FOP_EXT_INFRONTSHAPE			  4008
#define FOP_EXT_SHEARSHAPE				  4009
#define FOP_EXT_DISTORTSHAPE			  4010
#define FOP_EXT_PUTBEHINDSHAPE			  4011
#define FOP_EXT_PUTINFRONTSHAPE			  4012
#define FOP_EXT_PUTBOTTOM				  4013
#define FOP_EXT_MOVEBOTTOM				  4014
#define FOP_EXT_PUTTOP					  4015
#define FOP_EXT_MOVETOP					  4016
#define FOP_EXT_REVERSEORDER			  4017
#define FOP_EXT_RIPUPPOINT				  4019
#define FOP_EXT_DISTRIBUTION			  4020
#define FOP_EXT_ALIGNMACRO				  4021
#define FOP_EXT_MOVETO_CLOSESHAPE		  4022
#define FOP_EXT_BENDSHAPE				  4023

#define FOP_CANVAS						1

// Default zoom scale min value
const double fop_nDefaultZoomMin		= 0.1;

// Default zoom maximum value
const double fop_nDefaultZoomMax		= 20000.0;

// Default zoom increment value
const double fop_nDefaultZoomIncrement = 1.250;

// Default group component rect.
const CRect fo_DefaultGroupPosition = CRect(100,100,200,200);

// Auto scroll timer id
#define nDeafultAnimateTimerID		9433

class CFOPZoomList;
/////////////////////////////////////////////////////////////////////////////////
//
// CFOPCanvasCore -- the core class of canvas, over 90% of features on the canvas are defined 
//                   in this class, to handle drawing of canvas, the Draw() method must be called.
//					 To change the size of canvas, call SetCanvasSize(..) method.
//					 The CFOPCanvasCore class contains various
//					 other helper methods that draw different aspects of the view, such as the
//					 grid, selection handles, page boundaries, and background.
//					
//					 There are many virtual methods within this class, to handle these methods, you 
//					 can customize almost all the features of this class.
//					 To change the map mode of the canvas, just call ChangeMapMode(..) method.
//
//					 
/////////////////////////////////////////////////////////////////////////////////

class CFOPSubGraphShape;
class CFOPTableShape;
 
//===========================================================================
// Summary:
//     The CFOPCanvasCore class derived from CFOObserver
//      F O P Canvas Core
//===========================================================================

class FO_EXT_CLASS CFOPCanvasCore : public CFOObserver
{
	DECLARE_DYNAMIC(CFOPCanvasCore)
protected: 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor       
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Canvas Core, Constructs a CFOPCanvasCore object.
	//		Returns A  value (Object).
	CFOPCanvasCore();       
    
	//-----------------------------------------------------------------------
	// Summary:
	//Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Canvas Core, Destructor of class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPCanvasCore();

public:
	// Drag and drop support.
 
	// Drop Target, This member specify E-XD++ CFODropTarget object.  
	CFODropTarget	m_DropTarget;

protected:

	// Pointer of the window that contain the canvas.
 
	// Window Canvas, The CWnd class provides the base functionality of all window classes in the Microsoft Foundation Class Library.  
	CWnd		*	m_pWndCanvas;

protected:

	// Memory bitmap dc.
 
	// Memory D C, This member maintains a pointer to the object CDC.  
	CDC*			m_pMemoryDC;

	// Current draw shape type.
 
	// This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_drawshape;

	// Bitmap memory.
 
	// Memory Bitmap, The CBitmap class encapsulates a Windows graphics device interface (GDI) bitmap and provides member functions to manipulate the bitmap.   
	CBitmap*		m_pMemoryBitmap;

	CBitmap *bmpCache;
	FOPRect m_saveRect;
	
	CBitmap *GetCacheImage();
	void BegDrag();
	void EndDrag();

	// Memory palette.
 
	// Memory Palette, This member maintains a pointer to the object CPalette.  
	CPalette*		m_pMemoryPalette;

	// Tab order.
 
	// Tab Order, This member sets TRUE if it is right.  
	BOOL			m_bTabOrder;

	// Current tab order.
 
	// Current Tab Order, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurTabOrder;

	// Current selected shapes list.
 
	// Select Component, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listSelectComp;

	// Previous selected shapes list.
 
	// Previous Select Component, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listPrevSelectComp;

	// Current drag and drop image.
 
	// Current Image File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCurImageFile;

	// Current update position.
 
	// Update, This member sets a CRect value.  
	CRect			m_rcUpdate;

	// Previous point of mouse click down.
 
	// Previous, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPrev;

	// Focus hit control border line pen.
 
	// Focus, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penFocus;

	// Drawing focus link line pen.
 
	// Link, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penLink;

	// Dot line pen.
 
	// Dot Line, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penDotLine;

	// Border line pen.
 
	// Border, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penBorder;

	// Track line pen.
 
	// Track Line, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penTrackLine;

	// Pen for corner of the ruler.
 
	// Ruler Corner, This member specify E-XD++ CFOPenObjData object.  
	CFOPenObjData		m_penRulerCorner;

	// Margin of the canvas
 
	// Ruler Border, This member sets a CRect value.  
	CRect			m_rcRulerBorder;

	// Paste offset point.
 
	// Paste Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPasteOffset;

	// Insert position point.
 
	// To Insert, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptToInsert;

	// Init shape ports.
	CArray<FOPORTVALUE,FOPORTVALUE> m_arInitPorts;

	// list of mark points.
 
	public:
	// Mark, This member specify E-XD++ CFOPMarkList object.  
	CFOPMarkList		m_lstMark;

	// ruler need update or not
 
	// Ruler Update, This member sets TRUE if it is right.  
	BOOL			m_bRulerUpdate;

protected:

	// handle of current hit form.
 
	// Form Hit Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nFormHitHandle;

	// handle of current hit shape.
 
	// Current Hit Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurHitHandle;

	// Start moving shape width.
 
	// Start Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nStartWidth;

	// Start moving shape height.
 
	// Start Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nStartHeight;

	// End scale point.
 
	// End Scale, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptEndScale;

	// Index of current hit shape handle.
 
	// Current Hit Handle Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentHitHandleIndex;

	// Index of current hit form handle.
 
	// Current Hit Form Handle Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentHitFormHandleIndex;

	// Save memory bitmap.
 
	// Previous Buffer Bitmap, This member specify HBITMAP object.  
	HBITMAP			m_hPrevBufferBmp;

	// Save memory palette
 
	// Previous Buffer Pal, This member specify HPALETTE object.  
	HPALETTE		m_hPrevBufferPal;

	// Bitmap buffer padding value.
 
	// Bufer Add, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nBuferAdd;

	///////////////////////////////////////////////
	// Pointer of start link port.
 
	// Start Link Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pStartLinkPort;

	// Pointer of end link port.
 
	// End Link Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pEndLinkPort;

	// Pointer of end link port.
 
	// Last Link Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pLastLinkPort;

	// Hot port pointer,when link mode,it will should hi light.
 
	// Hot Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pHotPort;

	// Control handle.
 
	// Last Center, This member specify FO_CONTROL_HANDLE object.  
	FO_CONTROL_HANDLE m_nLastCenter;

	// Current mouse move point.
 
	// Mouse Down, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptMouseDown;

	// Multi select actor manager.
 
	// Multiple Selection, This member specify E-XD++ CFOShapeActorManager object.  
	CFOShapeActorManager m_MultiSelection;

	// Select shape list.
 
	// Current Select Shape, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listCurrentSelectShape;

	// Last move point.
 
	// Last Move, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLastMove;

	// Current action state.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_action_state;

	// Current device point.
 
	// Current Device, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptCurrentDevice;

	// Current log point.
 
	// Current Logical, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptCurrentLog;

	// Mouse move end point.
 
	// Mouse Move End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptMouseMoveEnd;

	// Current hit shape.
 
	// Current Hit Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pCurHitShape;

	// Current focus shape.
	CFODrawShape*	m_pInFocusShape;

	// Current hit shape with run mode.
 
	// Current Run Model Hit Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pCurRunModelHitShape;

	// Current hit shape with run mode.
 
	// Current Run Model Move In Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pCurRunModelMoveInShape;

	// Current move port.
 
	// Current Move Port, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape*	m_pCurrentMovePort;

	// Current drop shape list.
 
	// Current Drop Shapes List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_pCurDropShapesList;

	// Current link shape.
 
	// Current Link Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pCurLinkShape;

	// Prepare drag state.
 
	// Prepare Drag, This member sets TRUE if it is right.  
	BOOL			m_bPrepareDrag;

	// Is active or not.
 
	// Active, This member sets TRUE if it is right.  
	BOOL			m_bActive;

	// Print rectangle.
 
	// Print, This member sets a CRect value.  
	CRect			m_rectPrint;

	// List of current track shapes.
 
	// Track Shape, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listTrackShape;

	// List of current track shapes's backup.
 
	// Back Track Shape, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listBackTrackShape;

	// Reset select.
 
	// Reset Select, This member sets TRUE if it is right.  
	BOOL			m_bResetSelect;

	// Brush selected,be used to draw select shapes.
 
	// Select Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData		m_brSelectBrush;

	// Brush locked,be used to draw lock shapes.
 
	// Lock Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData			m_brLockBrush;

	// Brush unselected.
 
	// Un Select Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData			m_brUnSelectBrush;

	// Brush red.
 
	// Red Brush, This member specify E-XD++ CFOBrushObjectData object.  
	CFOBrushObjectData			m_brRedBrush;

	// Current handle size.
 
	// Current Handle, This member sets a CSize value.  
	CSize			m_szCurrentHandle;

	// Current polygon's points.
	CArray<CPoint,CPoint> m_arPointsPolygon;

	// Save track rectangle.
 
	// Last Tracking Rectangle, This member sets a CRect value.  
	CRect			m_rcLastTrackingRect;

	// Selection Handles.
	CArray<CPoint,CPoint> arSelectionSpots;

	// Already mirrored or not.
 
	// Mirrored, This member sets TRUE if it is right.  
	BOOL			m_bMirrored;

	// Distort rectangle.
 
	// Distorted Rectangle, This member specify FOPSimplePolygon object.  
	FOPSimplePolygon m_aDistortedRect;

	// Drag polygons.
 
	// Drag Polys, This member specify FOPSimpleCompositePolygon object.  
	FOPSimpleCompositePolygon m_aDragPolys;

	// Event handles tools.
 
	// List, This member specify CObList object.  
	CObList			m_pluginList;

	// Zoom list.
 
	// Zoom List, This member maintains a pointer to the object CFOPZoomList.  
	CFOPZoomList*	mpZoomList;

	// Current moving shape.
 
	// Current Moving Object, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape	*m_pCurMovingObj;

protected:

	// The x scale value
 
	// X Scale, This member specify double object.  
	double			m_dXScale;

	// The y scale value
 
	// Y Scale, This member specify double object.  
	double			m_dYScale;

	// Update scrollbars
 
	// Update Scroll Bars, This member sets TRUE if it is right.  
	BOOL			m_bUpdateScrollBars;
	
	// Minimum zoom percentage 
 
	// Zoom Minimize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double				m_nZoomMin;
	
	// Maximum zoom percentage 
 
	// Zoom Maximize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double				m_nZoomMax;

	// Percentage to zoom in or out. 
 
	// Zoom Add, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	double				m_nZoomAdd;

	// The log Origin of the view.
 
	// Logical Origin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptLogOrigin;

	// Logical extents size of the view
 
	// Logical, This member sets a CSize value.  
	CSize			m_szLogical;
	
	// Bounds container size of the physical view
 
	// View Extend, This member sets a CSize value.  
	CSize			m_szViewExtend;

	// Map mode of current view.
 
	// Current Map Mode, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurMapMode;

	// Pointer of the horz ruler
 
	// Horizontal Ruler, This member maintains a pointer to the object CFOPRulerBar.  
	CFOPRulerBar*	m_pHorzRuler;

	// Pointer of the vertical ruler
 
	// Vertical Ruler, This member maintains a pointer to the object CFOPRulerBar.  
	CFOPRulerBar*	m_pVertRuler;

	// Enable draw ruler tracking
 
	// Enable Ruler Track, This member sets TRUE if it is right.  
	BOOL			m_bEnableRulerTrack;

	// Previous ruler tracking point.
 
	// Previous Track, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPrevTrack;

	// show rulers.
 
	// With Rulers, This member sets TRUE if it is right.  
	BOOL			m_bWithRulers;

protected:
	// Margin of the canvas
 
	// Margins, This member sets a CRect value.  
	CRect			m_rcMargins;

	// Ruler margins
 
	// Ruler Margins, This member sets a CRect value.  
	CRect			m_rcRulerMargins;

	// Canvas axis direction
 
	// Axis, This member specify FOCanvasAxisDirection object.  
	FOCanvasAxisDirection m_nAxis;

	// Canvas bounding rectangle.
 
	// Container, This member sets a CRect value.  
	CRect			m_rcContainer;

	// Size of part bitmap size.
 
	// Default Part Image Size, This member specify FOPSize object.  
	FOPSize			m_szDefaultPartImageSize;

	// Current part bitmap index.
 
	// Current Part Image Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurPartImageIndex;

	// With advance update mode.
 
	// Advance Update, This member sets TRUE if it is right.  
	BOOL			m_bAdvanceUpdate;

	// Showing rotate link line.
 
	// Rotate Line, This member sets TRUE if it is right.  
	BOOL			m_bRotateLine;

protected:

	// Resource ID of current composite shape.
 
	// Current Shape Resource I D, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nCurShapeResID;

	// Resource file name of current composite shape.
 
	// Current Shape Resource File, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCurShapeResFile;

	// Current data model,use GetCurrentModel for instead.
 
	// Current Data Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel*	m_pCurDataModel;

	// Current cursor handle.
 
	// Cursor, This member specify HCURSOR object.  
	HCURSOR			m_hCursor;

	// Upright link mode.
 
	// Up Right Mode, This member sets TRUE if it is right.  
	BOOL			m_bUpRightMode;

	// Scale value x
 
	// Current Scale X, This member specify double object.  
	double			m_dCurrentScaleX;
	
	// Scale value y.
 
	// Current Scale Y, This member specify double object.  
	double			m_dCurrentScaleY;

	// Mouse pressed.
 
	// Pressed, This member sets TRUE if it is right.  
	BOOL			m_bPressed;

	// Mouse left button down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL			m_bMouseDown;

	// Undo command name.
 
	// Undo Cmd Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strUndoCmdName;

	// Redo command name.
 
	// Redo Cmd Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strRedoCmdName;

protected:

	// Current context menu pointer.
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*			m_pContextMenu;

	// Current edit static shape.
 
	// Current Edit Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*   m_pCurrentEditShape;

	// Current port parent shape.
 
	// Parent Box, This member maintains a pointer to the object CFODrawPortsShape.  
	CFODrawPortsShape *m_pParentBox;

	// Current edit combo box shape.
 
	// Current Inside Box Shape, This member maintains a pointer to the object CFOPEFormBaseShape.  
	CFOPEFormBaseShape* m_pCurInsideBoxShape;

	// Current hi light selection shape.
 
	// Current Hilight Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pCurHilightShape;

	// double buffer on/off switch
 
	// Enable Memory, This member sets TRUE if it is right.  
	BOOL            m_bEnableMemory;                

	// Link shape arrows.
 
	// Number Arrow, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNumberArrow;

	// Previous hit shape
 
	// Previous Hit Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *		m_pPrevHitShape;

	// Current move in shape.
	CFODrawPortsShape  *m_pCurMoveInShape;

	// Is double clicked.
 
	// Double Clicked, This member sets TRUE if it is right.  
	BOOL			m_bDoubleClicked;

protected:

	// Be edit spot.
 
	// Edit Spot, This member sets TRUE if it is right.  
	BOOL			m_bEditSpot;

	// Saving angle.
 
	// Save Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSaveAngle;
	
	// Current rotate angle.
 
	// Current Rotate Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentRotateAngle;
	
	// Current saving point.
 
	// Current Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptCurrentPoint;

	// Color palette
 
	// Palette, This member specify CPalette object.  
	CPalette		m_aPalette;

	// Showing all the db name.
 
	// Show All, This member sets TRUE if it is right.  
	BOOL			m_bShowAll;

protected:
	// Is select with in.
 
	// Select With In, This member sets TRUE if it is right.  
	BOOL			m_bSelectWithIn;

	// Is select handle show.
 
	// Show Select Handle, This member sets TRUE if it is right.  
	BOOL			m_bShowSelectHandle;

	// Is multiple selection mode.
 
	// Multiple Select, This member sets TRUE if it is right.  
	BOOL			m_bMultiSelect;

	// Previous rectangle.
 
	// Previous, This member sets a CRect value.  
	CRect			m_rcPrevious;

	// Tooltip,if you want tooltip to be supported by your own application,
	// please add the following line code before #include "FO.H"
 
	// Tips, This member specify E-XD++ CFOToolTipsWnd object.  
	CFOToolTipsWnd	m_wndTips;

	// Handles list.
 
	// Handle, This member specify E-XD++ CFOPHandleList object.  
	CFOPHandleList		m_aHdl;

	// pathSegment.
	FOPathSegment *m_pathSeg;

	// Handles list
 
	// Normal Handle, This member specify E-XD++ CFOPHandleList object.  
	CFOPHandleList		m_aNormalHdl;

	// Handles list
 
	// Plus Handle, This member specify E-XD++ CFOPHandleList object.  
	CFOPHandleList		m_aPlusHdl;

	// Handles list
 
	// Points Handle, This member specify E-XD++ CFOPHandleList object.  
	CFOPHandleList		m_aPointsHdl;

	// Handles list
 
	// Center Handle, This member specify E-XD++ CFOPHandleList object.  
	CFOPHandleList		m_aCenterHdl;

protected:

	// Zoom mode,it must be one of the following value:
	// enum 
	// {
	// 	FOP_ZOOMMODE_PANOVER, 
	// 	FOP_ZOOMMODE_NORMAL,
	// 	FOP_ZOOMMODE_FIT
	// };
 
	// Current Zoom Mode, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nCurrentZoomMode;

	// Save update rect.
 
	// Save Update, This member sets a CRect value.  
	CRect			m_crSaveUpdate;

	// Enable hide handles when moving shapes.
 
	// Enable Hide Handle, This member sets TRUE if it is right.  
	BOOL			m_bEnableHideHandle;

	// Enable snap nearest point.
 
	// Enable Nearest, This member sets TRUE if it is right.  
	BOOL			m_bEnableNearest;

	// snap angle.
 
	// Snap Angle, Specify a A 32-bit signed integer.  
	long			m_nSnapAngle;

	// Angle snap enabled.
 
	// Angle Snap Enable, This member sets TRUE if it is right.  
	BOOL			m_bAngleSnapEnable;

	// The list of default properties,using GetDefaultPropList() for instead.
 
	// Default List, This member specify E-XD++ CFOBasePropertiesList object.  
	CFOBasePropertiesList	m_propDefaultList;

	// Current drawing cursor resource ID.
 
	// Current Cursor, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentCursor;

	// Drag help line.
 
	// Drag Help Line, This member maintains a pointer to the object CFOPHelpLine.  
	CFOPHelpLine*	m_pDragHelpLine;

	// Selected help line.
 
	// Selected Help Line, This member maintains a pointer to the object CFOPHelpLine.  
	CFOPHelpLine *  m_pSelectedHelpLine;

	// Rotating handle position.
 
	// Rotating, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptRotating;

	// Saving rotating point.
 
	// Save Rotating, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptSaveRotating;

	// Rotate free allowed.
 
	// Rotate Free Allowed, This member sets TRUE if it is right.  
	BOOL			m_bRotateFreeAllowed;

	// With old rotate mode.
 
	// Old Rotate Mode, This member sets TRUE if it is right.  
	BOOL			m_bOldRotateMode;

	// With mirror free shapes mode.
 
	// Mirror Free Mode, This member sets TRUE if it is right.  
	BOOL			m_bMirrorFreeMode;

	// With Shear free shapes mode.
 
	// Shear Free Mode, This member sets TRUE if it is right.  
	BOOL			m_bShearFreeMode;

	// Save microsoft visio state.
 
	// Save Microsoft Visio style, This member sets TRUE if it is right.  
	BOOL			m_bSaveVisio;

	// With Bend free shapes mode.
 
	// Bend Free Mode, This member sets TRUE if it is right.  
	BOOL			m_bBendFreeMode;

	// Current side of mirror.
 
	// Side, This member sets TRUE if it is right.  
	BOOL			m_bSide;

	// Save rotating free mode.
 
	// Save Rotate Mode, This member sets TRUE if it is right.  
	BOOL			m_bSaveRotateMode;

	// Mouse move position string that shows on the item of status bar.
 
	// Ind Mouse Position String, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_IndMousePosString;

	// Shapes left top position string that shows on the item of status bar.
 
	// Ind Shapes Left Top String, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_IndShapesLeftTopString;

	// Shapes width and height string that shows on the item of status bar.
 
	// Ind Shapes Size String, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_IndShapesSizeString;

	// Allow drag and drop selection shapes to toolbox window.
 
	// Allow Drag Drop Tool Box, This member sets TRUE if it is right.  
	BOOL			m_bAllowDragDropToolBox;

	// Is glue to shape or not.
 
	// Glue To Shape, This member sets TRUE if it is right.  
	BOOL			m_bGlueToShape;

	// Save glue point.
 
	// Save Glue, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptSaveGlue;

	// Is allow the first point as the center point when drawing.
 
	// Point As Center, This member sets TRUE if it is right.  
	BOOL			m_b1stPointAsCenter;

	// With ellipse selection.
 
	// With Ellipse Select, This member sets TRUE if it is right.  
	BOOL			m_bWithEllipseSelect;

	// Erase ruler tracking point
 
	// Erase Ruler Tracking Point, This member sets TRUE if it is right.  
	BOOL			m_bRedrawTrackPoint;

	// Erase ruler tracking rectangle
 
	// Erase Ruler Tracking Rectangle, This member sets TRUE if it is right.  
	BOOL			m_bRedrawTrackRect;

	// Current select path shape.
	CFOPathShape *	mpCurSelectPath;

	// Additional selection handle.
 
	// Select Items, This member specify E-XD++ CFOPSelectHandleList object.  
	CFOPSelectHandleList m_SelectItems;

	// Additional selection index type.
 
	// Current Hit Additional Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nCurHitAddiType;

	// Enable showing selection always.
 
	// Always Show Select, This member sets TRUE if it is right.  
	BOOL			m_bAlwaysShowSelect;

	// Update selection.
 
	// Selection Update, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listSelectionUpdate;

	// Lock update or not.
 
	// Update Locked, This member sets TRUE if it is right.  
	BOOL			 m_bUpdateLocked;
public:

	// Pan view drag start point.
 
	// Zoom Drag Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint			m_ptZoomDragStart;

	// Drag help line.
 
	// Mirror Line, This member maintains a pointer to the object CFOPLineHandle.  
	CFOPLineHandle * m_pMirrorLine;

	// Current printer measure object.
 
	// Measure Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMeasureType;

	// Direct macro action.
 
	// Macro Undo Action, This member maintains a pointer to the object CFODirectActionMacro.  
	CFODirectActionMacro*   m_pMacroUndoAction;

	
	// Minimize moving for shapes.
 
	// Minimize Mov, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nMinMov;

	// Scroll bar line pixel
 
	// Scroll Line, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nScrollLine;

	// Group Undo levels
 
	// Undo Level, This member specify USHORT object.  
	USHORT          m_nUndoLevel;

	// Need anchor shape when align shapes.
 
	// Use Anchor Shape, This member sets TRUE if it is right.  
	BOOL			m_bUseAnchorShape;

	// Allow free form drawing or not.
 
	// Allow Free Form, This member sets TRUE if it is right.  
	BOOL			m_bAllowFreeForm;

	// Defined for timer:
	CMap<UINT, UINT, CFODrawShape*, CFODrawShape*> m_mapTimerEvents;

	// ID of next timer.
 
	// Next Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNextTimerID;

	// Bend shape center.
 
	// Cook Center, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_aCookCenter;

	// Bend radius
 
	// Bend Radius, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_aBendRadius;

	// Current cursor ID;
 
	// Cursor Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCursorId;

	// Saving current print page.
 
	// Save Print Page, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSavePrintPage;

	// Bend mode.
	// enum FOPBendMode 
	// {
	// 	FOP_BEND_ROTATE, // With rotating action when bending.
	// 	FOP_BEND_SLANT,  // With slanting action when bending
	// 	FOP_BEND_STRETCH // With stretch action when bending.
	// };
 
	// Bend Mode, This member specify FOPBendMode object.  
	FOPBendMode	m_aBendMode;

	// Bend vertical mode.
 
	// Bend Vertical, This member sets TRUE if it is right.  
	BOOL			m_bBendVertical;

	// Bend resized.
 
	// Bend Resize, This member sets TRUE if it is right.  
	BOOL			m_bBendResize;

	// Bend Scale value.
 
	// Bend Scale, This member specify FOPFraction object.  
	FOPFraction		m_dBendScale;

	// Is debug mode and drawing debug line.
 
	// Debug Draw, This member sets TRUE if it is right.  
	BOOL			m_bDebugDraw;

	// With text editing mode.
 
	// Text Editing, This member sets TRUE if it is right.  
	BOOL			m_bTextEditing;

	// Is printing now.
 
	// Printing, This member sets TRUE if it is right.  
	BOOL			m_bPrinting;

	// when resizing a row or column
 
	// Column Resized, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_rowColResized; 

	//previous column or row size before resizing it
 
	// Table Size, This member specify double object.  
	double			m_previousTableSize; 

	// With rotate center moved.
 
	// With Rotate Center Moved, This member sets TRUE if it is right.  
	BOOL			m_bWithRotateCenterMoved;

	// With lock of 25% for zooming.
 
	// Enable25 Percent Zooming, This member sets TRUE if it is right.  
	BOOL			m_bEnable25PercentZooming;

	// With split drag composite shapes.
 
	// Split Composite, This member sets TRUE if it is right.  
	BOOL			m_bSplitComposite;

	// With export selection area mode.
 
	// With Export Select, This member sets TRUE if it is right.  
	BOOL			m_bWithExportSelect;

	// The canvas resource had been changed.
 
	// With Canvas Reloaded, This member sets TRUE if it is right.  
	BOOL			m_bWithCanvasReloaded;

	// Glue start or not.
 
	// Glue Start, This member sets TRUE if it is right.  
	BOOL			fo_GlueStart;

	// Contain glue start or not
 
	// Contain Glue Start, This member sets TRUE if it is right.  
	BOOL			fo_ContainGlueStart;

	// Saving glue rectangle.
 
	// Save Glue Rectangle, This member sets a CRect value.  
	CRect			fo_SaveGlueRect;

	// Saving Horizontal
 
	// Horizontal, This member sets TRUE if it is right.  
	BOOL			fo_saveHorz;

	// Saving vertical.
 
	// Vertical, This member sets TRUE if it is right.  
	BOOL			fo_saveVert;

	// Obtian saving height point.
 
	// Get H, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			fo_saveGetH;

	// Obtain saving vertical point
 
	// Get V, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			fo_saveGetV;

	// With fixed page resize.
	BOOL			m_bFixPageResize;
	
	// Ruler extend value.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				fo_ruler_extend;
	
	// Ruler map changed size.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				fo_ruler_change_map_size;
	
	// default map change dim line
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				fo_caption_change_map_size;
	
	// Default map change dimension line extend.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				fo_dim_change_size_extend;

	// Need draw image now.
 
	// Need Draw Image Now, This member sets TRUE if it is right.  
	BOOL			fo_NeedDrawImageNow;

	// Need to extend update bounding now.
 
	// Need Extend, This member sets TRUE if it is right.  
	BOOL			m_bNeedExtend;

	// With rotating
 
	// Need Rotate, This member sets TRUE if it is right.  
	BOOL			m_bNeedRotate;

	// Timer already started and need update.
 
	// Need Draw With Timer, This member sets TRUE if it is right.  
	BOOL			m_bNeedDrawWithTimer;

	// Pointer of pan wnd.
 
	// Pan Window, This member maintains a pointer to the object CFOPanWnd.  
    CFOPanWnd *		m_pPanWnd;

	// With advance rotating and resizing.
 
	// With Advance Opt, This member sets TRUE if it is right.  
	BOOL			m_bWithAdvanceOpt;

	// Rectangle of saving position.
 
	// Current View, This member sets a CRect value.  
	CRect			m_rcCurView;

	// Zoom changed.
 
	// Zoom Changed, This member sets TRUE if it is right.  
	BOOL			m_bZoomChanged;

	// Load xdg with printer update.
	BOOL			m_bXdgWithPrinterUpdate;

	// Previous hit shape.
	CFODrawShape *	m_pSavePrevHitShape;

	// Previous moving shape.
	CFODrawShape*	m_pSaveMoveShape;

	// Previous moving link shape.
	CFODrawShape*	m_pSaveMoveLink;

	// Previous moving port shape.
	CFOPortShape *  m_pSaveMovePort;

	// Previous moving port shape.
	CFOPortShape *  m_pSaveNewMovePort;

	// Previous tool tips shape.
	CFODrawShape * m_pSaveTipsShape;

	// Previous sub - graph shape.
	CFOPSubGraphShape *m_pSavePreSubGraph;

	// Bounding shapes.
	CFODrawShapeList m_BoundShapes;

	// Draw for first time.
	BOOL			m_bAtFirstTime;

	// Saving first point.
	CPoint			m_ptSaveFirst;

	// Mouse state
	BOOL			m_foMoveState;

	// Track pen.
	CFOPenObjData			m_NewTrackPen;

	// With panning mode when running - mode.
	
	// With Panning Run Time, This member sets TRUE if it is right.  
	BOOL			m_bWithPanningRunTime;

	// With continue panning mode.
	
	// With Continue Pan, This member sets TRUE if it is right.  
	BOOL		m_bWithContinuePan;

	// With auto expand view.
	BOOL		m_bWithCanvasExp;

	// Auto expand size.
	int			m_nDefExpSize;

	// Auto timer running.
	BOOL		m_bAutoTimerIn;

	// be on panning.
	BOOL		m_bOnPaning;

protected:
	// Logic center moving.
	// m_ptAnimateStart = GetLogCenter();
	// m_pAnimateEnd = m_pObj->GetSnapRect().CenterPoint();
	// SetTimer(200,20,NULL);
	// Current value.
 
	// Animate Step, This member specify The float keyword designates a 32-bit floating-point number.  
	float			myAnimateStep;
	
	// Animate start point.
 
	// Animate Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptAnimateStart;

	// Animate end point
 
	// Animate End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_pAnimateEnd;

	// Animate step value.
 
	// Animate Step Value, This member specify double object.  
	double			m_dAnimateStepValue;

	// Is timer running.
 
	// Animate Running, This member sets TRUE if it is right.  
	BOOL			m_bAnimateRunning;

	// Zooming start.
 
	// Zoom Start X, This member specify double object.  
	double			m_dZoomStartX;

	// Zooming step value.
 
	// Zoom Step X, This member specify double object.  
	double			m_dZoomStepX;

	// Zooming start.
 
	// Zoom Start Y, This member specify double object.  
	double			m_dZoomStartY;
	
	// Zooming step value.
 
	// Zoom Step Y, This member specify double object.  
	double			m_dZoomStepY;

	// With scale supporting.
 
	// With Scale, This member sets TRUE if it is right.  
	BOOL			m_bWithScale;

	// Current high light shape.
 
	// Highlit, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape	*myHighlit;

	// Current high light port shape.
 
	// Port Highlit, This member maintains a pointer to the object CFOPortShape.  
	CFOPortShape	*myPortHighlit;

	// Saving highlight pt.
	FOPPoint		mptHitSpot;

	// Current high light link shape.
 
	// Highlit Link, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape	*myHighlitLink;

	// Current steps.
 
	// Current Step, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCurrentStep;

	// Total steps.
 
	// Total Step, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTotalStep;


	// Track drawing.
	CFOCompositeShape *m_pXTrackDraw;


	// Is port tacking mode.
	BOOL			m_bPortSelect;


	// Previous selected cell position.
	int				m_nPreCellRow;

	// Previous selected cell col.
	int				m_nPreCellCol;
	
public:

	/*************************************************************************
	|*
	|* Window pointer of the canvas.
	|*
	\************************************************************************/
	
	// Obtain the canvas's window pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Canvas Window, .
	//		Returns a pointer to the object CWnd ,or NULL if the call failed
	CWnd *CanvasWnd() const;

	// Change the canvas's window pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Window, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.
	void SetCanvasWnd(CWnd *pWnd) { m_pWndCanvas= pWnd; }

	// Is current pan window shown.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Pan Window Shown, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsPanWndShown();
    
    // Show pan window.
	// xPos -- x start location.
	// yPos -- y start location.
	// nWidth -- window's width.
	// nHeight -- window's height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Pan Window, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&xPos---&xPos, Specifies A integer value.  
	//		&yPos---&yPos, Specifies A integer value.  
	//		&nWidth---&nWidth, Specifies A integer value.  
	//		&nHeight---&nHeight, Specifies A integer value.
    virtual BOOL ShowPanWnd(const int &xPos,
		const int &yPos,
		const int &nWidth = 240,
		const int &nHeight = 250);
	
	// Hide pan window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Pan Window, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    virtual BOOL HidePanWnd();

	// Disable rotate link line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Rotate Line, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableRotateLine(const BOOL &bEnable);

	// Update bounding.
	void DoListBoundShape(CFODrawShape *pCur);

	// Is edit spot mode.
	BOOL IsEditSpotMode() const { return m_bEditSpot; }

	// Obtain hitted shape.
	CFODrawShape *GetHittedShape() { return m_pCurRunModelHitShape; }

public:

	/*************************************************************************
	|*
	|* Timer define for animation event.
	|*
	\************************************************************************/

	// Register the timer
	// pShape -- pointer of the shape.
	// nInterval -- time interval value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Register Timer Event, Write a specify value to registry.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nInterval---nInterval, Specifies A integer value.
	virtual int RegisterTimerEvent( CFODrawShape *pShape, int nInterval );

	// Unregister the timer.
	// nTimerEventID -- timer ID value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Unregister Timer Event, Unregistry a specify value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerEventID---Timer Event I D, Specifies A integer value.
	virtual void UnregisterTimerEvent( const int nTimerEventID );

	// Do timer event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Timer Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nTimerEventID---Timer Event I D, Specifies A integer value.
	virtual void DoTimerEvent(const int &nTimerEventID);

	// Do animate moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate Move, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNew---&rcNew, Specifies A CRect type value.  
	//		&bWithScale---With Scale, Specifies A Boolean value.  
	//		&nTotalStep---Total Step, Specifies A integer value.  
	//		&nTime---&nTime, Specifies A integer value.
	virtual void DoAnimateMove(const CRect &rcNew, const BOOL &bWithScale = TRUE, const int &nTotalStep = 10, const int &nTime = 20);

	// Hight light this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Highlit, High light this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*myvalue---A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void Highlit(CFODrawShape *myvalue);

	// Hight light this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Highlit Port, High light this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*myvalue---A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void HighlitPort(CFOPortShape *myvalue);

	// Hight light this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Highlit Port, High light this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		myvalue---A to the point  or NULL if the call failed.
	virtual void HighlitHit(FOPPoint myvalue);

	// Hight light this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Highlit Link, High light this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*myvalue---A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptTrack---&ptTrack, Specifies A CPoint type value.
	virtual void HighlitLink(CFODrawShape *myvalue, const CPoint &ptTrack);

public:

	/*************************************************************************
	|*
	|* Creating, changing, setting the ruler.
	|*
	\************************************************************************/

	// Create horizontal ruler bar
	// nType -- unit type value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Horizontal Ruler, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPRulerBar,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies a const FieldUnit & nType object(Value).
	virtual CFOPRulerBar* CreateHorzRuler(const FieldUnit & nType);

	// Create vertical ruler bar.
	// nType -- unit type value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Vertical Ruler, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPRulerBar,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies a const FieldUnit & nType object(Value).
	virtual CFOPRulerBar* CreateVertRuler(const FieldUnit & nType);

	// Obtain the horizontal ruler pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Horizontal Ruler, Returns the specified value.
	//		Returns a pointer to the object CFOPRulerBar,or NULL if the call failed
	CFOPRulerBar* GetHorzRuler();

	// Obtain the vertical ruler pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Vertical Ruler, Returns the specified value.
	//		Returns a pointer to the object CFOPRulerBar,or NULL if the call failed
	CFOPRulerBar* GetVertRuler();

	// Obtain the height of the horizontal ruler,it is also the width of the vertical ruler
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetRulerSize();

	// Do draw ruler
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Rulers, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawRulers(CDC* pDC, const FOPRect &rcClip);

	// Change cursor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Cursor With I D, .
	// Parameters:
	//		&nId---&nId, Specifies A integer value.
	void ChangeCursorWithID(const int &nId);

	// Do prepare dc with ruler support.
	// pDC -- pointer of the DC.
	// nRulerType -- type of the ruler,it must be one of the following value:
	//enum FOPRulerType
	// {
	//	FOP_HORZ_RULER,  Horz ruler
	//	FOP_VERT_RULER  // Vert ruler
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Ruler D C, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&nRulerType---Ruler Type, Specifies a const FOPRulerType &nRulerType object(Value).
	virtual void OnPrepareRulerDC(CDC* pDC, const FOPRulerType &nRulerType);

	// Gen logic point to device point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate L Pto D P, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		lpSize---lpSize, Specifies a LPSIZE lpSize object(Value).
	void XGenLPtoDP(CDC *pDC, LPSIZE lpSize);

	// Change ruler unit
	// unit -- unit of the ruler mark,it must be one of the following value.
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Ruler Unit, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&unit---Specifies a const FieldUnit &unit object(Value).
	virtual void ChangeRulerUnit(const FieldUnit &unit);

	// Drawing ruler tracking point
	// pDC -- pointer of the DC.
	// pt -- current mouse point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Ruler Mouse Position, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pt---Specifies A CPoint type value.
	virtual void DrawRulerMousePos(CDC* pDC, const CPoint& pt);

	// Drawing ruler tracking rectangle
	// pDC -- pointer of the DC.
	// rect -- rectangle of the tracking shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Ruler Shape Rectangle, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void DrawRulerShapeRect(CDC* pDC, const CRect& rect);

	// Show or hide ruler bar
	// bVisible -- visible or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Rulers, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bVisible---&bVisible, Specifies A Boolean value.
	virtual void ShowRulers(const BOOL &bVisible);

	// Change the ruler unit.
	// unit -- unit of the ruler mark,it must be one of the following value.
	// enum FieldUnit 
	// { 
	// 	FUNIT_NONE = -1,
	// 	FUNIT_INCHES,		//0
	// 	FUNIT_FEET,			//1
	// 	FUNIT_MM,			//2
	// 	FUNIT_CM,			//3
	// 	FUNIT_METERS,		//4
	// 	FUNIT_KM,			//5
	// 	FUNIT_YARDS,		//6
	// 	FUNIT_MILES,		//7
	// 	FUNIT_POINTS,		//8
	// 	FUNIT_TWIPS,		//9
	// 	FUNIT_LOGPOINT		//10
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Unit, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		&unit---Specifies a const FieldUnit &unit object(Value).
	void SetRulerUnit(const FieldUnit &unit);

	// Is ruler bar visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ruler Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsRulerVisible() const;

	// Update ruler font map
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Ruler Map, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateRulerMap();

	// Calculate the ruler border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Ruler Border, .
	//		Returns a CRect type value.
	CRect CalcRulerBorder();

	// Obtain the ruler border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Border, Returns the specified value.
	// Parameters:
	//		&rcBorder---&rcBorder, Specifies A CRect type value.
	void GetRulerBorder(CRect &rcBorder);

	// Change the ruler border
	// rcBorder -- new ruler border
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Border, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcBorder---rcBorder, Specifies A CRect type value.
	virtual void SetRulerBorder(const CRect& rcBorder);

	// Obtain the size of the device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Device Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetDevSize() const;

	// Obtain the size of the device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Device Size2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetDevSize2() const;

	// Obtain the size of the scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get F O P Scroll Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetFOPScrollPosition();

	// Obtain if the view be center mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Center Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCenterMode() const;

	// Obtain the center point of the shape.
	// pMainShape -- pointer of the main shape, the center port of this shape will be returned.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Center Port, Returns the specified value.
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		*pMainShape---Main Shape, A pointer to the CFODrawPortsShape  or NULL if the call failed.
	CFOPortShape *GetCenterPort(CFODrawPortsShape *pMainShape);

	// Connect the select shapes with center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Connect Select Shapes, Do a event. 

	void DoConnectSelectShapes();

	// Connect the select shapes with center.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Connect Select Shapes, Do a event. 
	
	void DoConnectShapesMainChild();

	// Is it possible center link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Center Link, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsAllowCenterLink();

	// Obtain the document pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Document Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDocument ,or NULL if the call failed
	virtual CDocument *GetDocumentPt();

	// Add OLE menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ole To Menu, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		hmenu---Specifies a HMENU hmenu object(Value).
	virtual void AddOleToMenu(HMENU hmenu);

	// Do sort selected shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Sort Selected, Do a event. 
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	void DoSortSelected(CFODrawShapeList *pList);

protected:

	// Obtain additional canvas offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Additional Canvas Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetAddiCanvasSize();

	// handle the selection change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Selection Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bWithAction---With Action, Specifies A Boolean value.
	virtual void	CheckSelectionChange(const BOOL &bWithAction = FALSE);

public:

	//Clear All default Properties
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Default All Property, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearDefaultAllProp();
	
	// Get the list of all default properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Property List, Returns the specified value.
	//		Returns a pointer to the object CFOBasePropertiesList ,or NULL if the call failed
	CFOBasePropertiesList *GetDefaultPropList() { return &m_propDefaultList; }

	// Add a new default property
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Default Property, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---Specifies a E-XD++ CFOBaseProperties& prop object (Value).
	virtual BOOL AddNewDefaultProperty(
		// Property
		CFOBaseProperties& prop
		);

	// Add a new default property with a pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Default Property Pointer, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pProp---pProp, A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual BOOL AddNewDefaultPropertyPtr(
		// Pointer of property.
		CFOBaseProperties* pProp
		);

	// Find a property with a specify id.
	// nId -- the property id value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Default Property, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseProperties,or NULL if the call failed  
	// Parameters:
	//		nId---nId, Specifies A integer value.
	virtual CFOBaseProperties* FindDefaultProperty(
		// ID of property
		int nId
		) const;

	// Do init shape's properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Shape Properties, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoInitShapeProperties(
		// Pointer of shape.
		CFODrawShape *pShape
		);

	// Do init shape's properties for a list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Shapes Properties, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	virtual void DoInitShapesProperties(
		// List of shapes.
		CFODrawShapeList *pList
		);

	// Put value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Default Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual BOOL PutDefaultPropValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetDefaultPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	// Prepare Primary brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Primary Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetPrimaryBrush();

	// Prepare Lock brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Lock Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetLockBrush();

	// Prepare Secondary brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Secondary Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetSecondaryBrush();

	// Prepare red brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Red Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush ,or NULL if the call failed
	CBrush *GetRedBrush();

	// Prepare dot pen line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dot Line Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetDotLinePen();

	// Prepare border pen
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Border Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetBorderPen();

	// Prepare track line pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Line Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetTrackLinePen();

	// Obtain 
	CPen *GetNewTrackPen();

	// Prepare focus pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Focus Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetFocusPen();

	// Prepare link pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetLinkPen();

	// Prepare ruler corner pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Corner Pen, Returns the specified value.
	//		Returns a pointer to the object CPen ,or NULL if the call failed
	CPen *GetRulerCornerPen();

public:
	/*************************************************************************
	|*
	|* Selection
	|*
	\************************************************************************/

	// Get the pointer of list of select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Shapes, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList ,or NULL if the call failed
	CFODrawShapeList *GetSelectShapes()		{ return &m_listSelectComp; }

	// Obtain all selected shapes with it's children.
	virtual void GetAllChildSelectedShapes(CFODrawShapeList *pList);

	// Get the pointer of list of select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Table Shape, Returns the specified value.
	//		Returns a pointer to the object CFOPTableShape ,or NULL if the call failed
	CFOPTableShape *GetSelectTableShape();

	// Get the pointer of list of select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Table Shape, Returns the specified value.
	//		Returns a pointer to the object CFOPTableShape ,or NULL if the call failed
	FOXNewTableShape *GetSelectNewTableShape();

	// Get the max position of selected shapes,this is the bounding rectangle for all the shapes
	// it is used for update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Selection Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect	GetMaxSelectionRect();

	// Select Shape action
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Shape, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void	SelectShape(CFODrawShape *pShape);

	// Get the Count of select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Link Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int		GetSelectLinkCount() const;

	// Get the start position of selection list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Selected Position, Returns the specified value.
	//		Returns A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	POSITION GetFirstSelectedPos();

	// Get next shape with selection list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Selected, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	CFODrawShape* GetNextSelected(POSITION& pos);

	// Get all the count of the shapes that can be selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selectable Shape Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetSelectableShapeCount() const;

	// Select action.
	// Clear Selection within the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Selection, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ClearSelection();

	// Delete selection shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Select Shapes, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DeleteSelectShapes();

	// Select All shapes on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select All, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	SelectAll();

	// Select All shapes on the canvas.
	// pShapeSet -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Multiple Shpaes, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShapeSet---Shape Set, A pointer to the CFODrawShapeSet  or NULL if the call failed.
	virtual void	SelectMultiShpaes(CFODrawShapeSet *pShapeSet);

	// Select All shapes on the canvas.
	// pShapeList -- list of shapes.
	// bRedraw -- redraw or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Multiple Shpaes2, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShapeList---Shape List, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&bRedaraw---&bRedaraw, Specifies A Boolean value.
	virtual void	SelectMultiShpaes2(CFODrawShapeList *pShapeList, const BOOL &bRedaraw = TRUE);


	// Select All shapes on the canvas.
	// pShapeList -- list of shapes.
	// bRedraw -- redraw or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Select Multiple Shpaes2, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShapeList---Shape List, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&bRedaraw---&bRedaraw, Specifies A Boolean value.
	virtual void	SelectMultiShpaes3(CFODrawShapeList *pShapeList, const BOOL &bRedaraw = TRUE);

	// Update All selection shapes on the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Selection, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	UpdateAllSelection();


	virtual BOOL HasSelection() const;
	virtual int GetFocusIndex();

	// Printing or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Printing, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		bPrint---bPrint, Specifies A Boolean value.
	void SetPrinting(BOOL bPrint);

	// Obtain the printing mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printing, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetPrinting() const;

	// Obtain canvas rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Window Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCanvasWndRect();

	// Is all shapes selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Selected, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsAllSelected() const;

	// Is current link support with multiple points drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Link End Draw, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsLinkEndDraw();

	// Is select possible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Select Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelectPossible() const;

	// Clear handles for drag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Selection Handles, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ClearSelectionHandles();

	// Restore handles after drag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Selection Handles, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	RestoreSelectionHandles();   
    
	// Override this method to handle the selection change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Selection Changed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bWithAction---With Action, Specifies A Boolean value.
	virtual void	DoSelectionChanged(const BOOL &bWithAction = FALSE);

	// Get current select shapes position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalSelectBoundRect();

	// Zoom list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom List, Returns the specified value.
	//		Returns a pointer to the object CFOPZoomList,or NULL if the call failed  
	// Parameters:
	//		void---void
	CFOPZoomList* GetZoomList (void);

	//
	// Get current select shapes position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalSelectSnapRect();

	//
	// Get current total shapes position,all the shapes can be resized freely.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Resize Shapes Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalResizeShapesSnapRect();

	// Get total selection update rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Select Update Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect	GetTotalSelectUpdateRect();

	// Get current select shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Select Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetCurrentSelectShape();

	// Get second select shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Select Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetSecondSelectShape();

	// Is select with in,this is the selection state,if be within,all the shapes must be within the rectangle
	// that can be selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Select With In, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		  IsSelectWithIn() const			{ return m_bSelectWithIn; }

	// Set select with in mode,this is the selection state,if be within,all the shapes must be within the rectangle
	// that can be selected.
	// bIn -- be within or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Select With In, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		bIn---bIn, Specifies A Boolean value.
	void		  SetSelectWithIn(const BOOL bIn)	{ m_bSelectWithIn = bIn; }

	// Reset select mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset To Select Mode, Called this function to empty a previously initialized CFOPCanvasCore object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetToSelectMode();

	// Restore action state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore Action State, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bRedrawSelect---Redraw Select, Specifies A Boolean value.
	virtual void RestoreActionState(const BOOL &bRedrawSelect = FALSE);

	// Is multi selection mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Selection Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsMultiSelectionMode();

	// Set primary selection color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Primary Selection Color, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void SetPrimarySelectionColor(
		// Primary selection color.
		COLORREF color
		);

	// Sets the color for unprimary selection
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Secondary Selection Color, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void SetSecondarySelectionColor(
		// Secondary selection color.
		COLORREF color
		);

	// Add shape to selection list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Selection, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddToSelection(
		// Pointer of shape.
		CFODrawShape *pShape
		);

	// Add shapes to selection list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Selection, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&bRemoveTheOld---Remove The Old, Specifies A Boolean value.
	virtual void AddToSelection(
		// Pointer of shapes.
		CFODrawShapeList* pShapeList, 
		// Remove all the exist shapes.
		const BOOL &bRemoveTheOld
		);

	// Add shapes to selection list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Selection, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&bRemoveTheOld---Remove The Old, Specifies A Boolean value.
	virtual void AddToSelection(
		// Pointer of shapes.
		CFODrawShapeSet* pShapeList, 
		// Remove all the exist shapes.
		const BOOL &bRemoveTheOld
		);

	// Remove shape to selection list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove From Selection, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void RemoveFromSelection(
		// Pointer of shape.
		CFODrawShape *pShape
		);

	// Remove all shapes from the selection list.
	// bRemovePoint -- remove point or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All From Selection, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bRedraw---&bRedraw, Specifies A Boolean value.  
	//		bRemovePoint---Remove Point, Specifies A Boolean value.  
	//		&bResetTable---Reset Table, Specifies A Boolean value.
	virtual void RemoveAllFromSelection(const BOOL &bRedraw = FALSE,BOOL bRemovePoint = TRUE, const BOOL &bResetTable = TRUE);

	// Update Canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Canvas Bars, Do a event. 

	void DoUpdateCanvasBars();

	// Do draw cad move sport.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Spot Moving, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADSpotMoving(const CPoint &point, UINT nFlags);

	// Do draw cad move sport.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Spot Moving, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADPathMoving(const CPoint &point, UINT nFlags);

	// Do moving spot center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Move Center Point, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADMoveCenterPoint(const CPoint &point, UINT nFlags);
	
	// Do moving anchor 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Anchor1 Moving, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADAnchor1Moving(const CPoint &point, UINT nFlags);

	// Do moving anchor 1.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Anchor2 Moving, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADAnchor2Moving(const CPoint &point, UINT nFlags);

	// Do shape CAD moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Moving, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADMoving(const CPoint &point, UINT nFlags);

	// Do moving link port end.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Move Link Port End, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADMoveLinkPortEnd(const CPoint &point, UINT nFlags);

	// Do sizing shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do C A D Sizing, Do a event. 
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoCADSizing(const CPoint &point, UINT nFlags);


public:

	// Is current shape within a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be With In, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&rect---Specifies a const FOPRect &rect object(Value).
	BOOL BeWithIn(
		// Pointer of shape
		CFODrawShape *pShape,
		// A specify rectangle.
		const FOPRect &rect
		) const;

	// Get true border position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get True Border Position, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTrueBorderPosition();

	// Enable or not show the selection handle of shapes when moving shape.
	// bEnable -- enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Disappear Handle, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableDisappearHandle(const BOOL &bEnable) {m_bEnableHideHandle = bEnable; }


	// Is drawing first point as center point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Create1st Point As Center, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCreate1stPointAsCenter() const	{ return m_b1stPointAsCenter; }

	// Allow the first point as center point.
	// bOn -- allow or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Create1st Point As Center, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bAllow---bAllow, Specifies A Boolean value.
	void EnableCreate1stPointAsCenter(BOOL bAllow)	{	m_b1stPointAsCenter = bAllow;	}


	// Get snap to nearest pt.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Pick Nearest, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEnablePickNearest() const { return m_bEnableNearest; }

	// Enable or not to pick the nearest point..
	// bEnable -- enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Pick Nearest, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnablePickNearest(const BOOL &bEnable) {m_bEnableNearest = bEnable; }



	// Set angle snap enable or not.
	// bEnable -- enable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Angle Snap, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableAngleSnap(const BOOL &bEnable)	{ m_bAngleSnapEnable = bEnable; }

	// Is angle snap enable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Angle Snap Enabled, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAngleSnapEnabled() const { return m_bAngleSnapEnable; }


	// Set showing selection always state.
	// Only defined for running time mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Show Selection Always, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableShowSelectionAlways(const BOOL &bEnable) { m_bAlwaysShowSelect = bEnable; }

	// Is showing selection always state or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Show Selection Always, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShowSelectionAlways() const { return m_bAlwaysShowSelect; }


	// Is rotate free allowed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rotate Free Allowed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsRotateFreeAllowed() const { return m_bRotateFreeAllowed; }

	// Set rotate free.
	// bEnable -- enable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Rotate Free, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void EnableRotateFree(const BOOL& bEnable) { m_bRotateFreeAllowed = bEnable; }


	// Is mirror free mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mirror Free Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMirrorFreeMode() const { return m_bMirrorFreeMode; }

	// Set mirror free mode.
	// bEnable -- enable or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Mirror Free Mode, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void EnableMirrorFreeMode(const BOOL& bEnable) { m_bMirrorFreeMode = bEnable; }


	// Is Shear free mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shear Free Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsShearFreeMode() const { return m_bShearFreeMode; }

	// Set Shear free mode
	// bEnable -- enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Shear Free Mode, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableShearFreeMode(const BOOL &bEnable) { m_bShearFreeMode = bEnable; }


	// Is Bend free mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Bend Free Mode, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsBendFreeMode() const { return m_bBendFreeMode; }

	// Change to Bend free mode
	// bEnable -- enable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Bend Free Mode, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableBendFreeMode(const BOOL &bEnable) { m_bBendFreeMode = bEnable; }


	// Set snap angle value.
	// nAngle -- new angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Snap Angle, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.
	void SetSnapAngle(long nAngle) { m_nSnapAngle = nAngle; }

	// Get snap angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Snap Angle, Returns the specified value.
	//		Returns A 32-bit long signed integer.
	long GetSnapAngle() const { return m_nSnapAngle; }


	// Change view zooming feature to 25% change mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set25 Percent Zoom Mode, Sets a specify value to current class CFOPCanvasCore

	void Set25PercentZoomMode();

	// Enable main anchor shape when align.
	// bMain -- main anchor or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Main Anchor, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bMain---&bMain, Specifies A Boolean value.
	void EnableMainAnchor(const BOOL &bMain) { m_bUseAnchorShape = bMain; }

	// Is Enable Main anchor or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Anchor, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsEnableAnchor() const { return m_bUseAnchorShape; }

	// Enable free form drawing or not.
	// Turn on free draw, use free form draw tool to create new, unique shapes or complex lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Free Form Drawing, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bAllow---&bAllow, Specifies A Boolean value.
	void EnableFreeFormDrawing(const BOOL &bAllow) { m_bAllowFreeForm = bAllow; }

	// Is allow free form drawing or not
	// Turn on free draw, use free form draw tool to create new, unique shapes or complex lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Free Form Drawing, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFreeFormDrawing() const { return m_bAllowFreeForm; }

	// If current shape can be inserted a point return TRUE,else return FALSE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ins Object Point Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	BOOL IsInsObjPointPossible(
		// Pointer of shape.
		CFODrawShape *pShape
		) const;

	// Is all select shapes are lines.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Lines, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllLines();

	// Is all select shapes are path shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Path Shape, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllPathShape();

	// Is current shape selected.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	BOOL IsShapeSelected(CFODrawShape *pShape) const;

	// Get Extend drawing size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extend Draw Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetExtendDrawSize();

	// Obtain shape within a list by the index of shape.
	// pShapeList -- list of shapes to find.
	// nIndex -- index of the shapes within the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Get Shape, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A integer value.
	CFODrawShape *FOGetShape(CFODrawShapeList* pShapeList,int nIndex);

	// Do toolbox window click event.
	// pItemHit -- current click item.
	virtual void DoToolBoxClickEvent(CFOToolBoxItem *pItemHit); 

	// Change to map style canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change To Map Style Canvas, .

	void ChangeToMapStyleCanvas();

	// Called when a shape's position is changed.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Shape Position Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void OnShapePositionChange(CFODrawShape *pShape);

	// Called when a property is changed.
	// pShape -- pointer of shape.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Shape Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnShapePropertyChange(CFODrawShape *pShape, const int &nPropId, CFOBaseProperties* prop);

public:
	// Add new event plug in event.
	// pPlugin -- pointer of the new msg handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Plugin, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pPlugin---pPlugin, A pointer to the FOPMsgHandleTool or NULL if the call failed.
	virtual void AddPlugin(FOPMsgHandleTool* pPlugin);

	// Detach the event plug in.
	// nEventID -- event ID to detach.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Detach Plugin, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nEventID---Event I D, Specifies A integer value.
	virtual void DetachPlugin(int nEventID);

	// Get fix ruler size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Fix Ruler Size, Returns the specified value.
	//		Returns a int type value.
	virtual int GetFixRulerSize() const;

	// Defined for extend toolbar window.
	virtual void DoDrawAction(int nType);

	// Defined for extend toolbar window.
	virtual void SwitchToSelect();

	// Defined for extend toolbar window.
	virtual BOOL InitToolBarItemState(const UINT &nItemType);

public:
	/*************************************************************************
	|*
	|* Doing macro actions.
	|*
	\************************************************************************/

	// Starting action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Action, .
	// Parameters:
	//		&nActionType---Action Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&bUpdateAll---Update All, Specifies A Boolean value.  
	//		&bRemoveAllSelection---Remove All Selection, Specifies A Boolean value.  
	//		&bEnablePrepare---Enable Prepare, Specifies A Boolean value.
	void BegAction(const UINT &nActionType = 0,const BOOL &bUpdateAll = FALSE,
		const BOOL &bRemoveAllSelection = TRUE,const BOOL &bEnablePrepare = FALSE);

	// Starting action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Action, .
	// Parameters:
	//		strComment---strComment, Specifies A CString type value.  
	//		&nActionType---Action Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&bUpdateAll---Update All, Specifies A Boolean value.  
	//		&bRemoveAllSelection---Remove All Selection, Specifies A Boolean value.  
	//		&bEnablePrepare---Enable Prepare, Specifies A Boolean value.
	void BegAction(const CString& strComment,const UINT &nActionType = 0,const BOOL &bUpdateAll = FALSE,
		const BOOL &bRemoveAllSelection = TRUE,const BOOL &bEnablePrepare = FALSE);

	// Starting action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Action Extend, .
	// Parameters:
	//		nIDComment---I D Comment, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nActionType---Action Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&bUpdateAll---Update All, Specifies A Boolean value.  
	//		&bRemoveAllSelection---Remove All Selection, Specifies A Boolean value.  
	//		&bEnablePrepare---Enable Prepare, Specifies A Boolean value.
	void BegActionExt(const UINT& nIDComment,const UINT &nActionType = 0,const BOOL &bUpdateAll = FALSE,
		const BOOL &bRemoveAllSelection = TRUE,const BOOL &bEnablePrepare = FALSE);

	// Prepare and starting the group action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Action Extend, .
	// Parameters:
	//		pUndoGrp---Undo Grp, A pointer to the CFODirectActionMacro or NULL if the call failed.
	void BegActionExt(CFODirectActionMacro* pUndoGrp);

	// Change action's comment
	// strComment -- comment string of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Undo Comment, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		strComment---strComment, Specifies A CString type value.
	void SetUndoComment(const CString& strComment);

	// Change action's comment
	// nIDComment -- string id for the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Undo Comment, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nIDComment---I D Comment, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetUndoComment(const UINT& nIDComment);

	// Add action.
	// pAction -- pointer of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOAction  or NULL if the call failed.
	virtual void AddAction(CFOAction *pAction);

	// Add action.
	// pAction -- pointer of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Macro Action, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFOActionMacro  or NULL if the call failed.
	virtual void AddMacroAction(CFOActionMacro *pAction);

	// Add action.
	// pList -- list of the actions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Multiple Actions, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CActionList  or NULL if the call failed.
	virtual void AddMultiActions(CActionList *pList);

	// End current macro action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Action, .

	void EndAction();

	// Override this method to do something,this method will be executing after the action is executed.
	// pAction -- pointer of the action.
	// nType -- action type ID
	// lstUpdate -- list of the shapes for updating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pAction---*pAction, A pointer to the CFODirectActionMacro  or NULL if the call failed.  
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&lstUpdate---&lstUpdate, Specifies a E-XD++ CFODrawShapeList &lstUpdate object (Value).
	virtual void DoAfterAction(CFODirectActionMacro *pAction,const UINT &nType,CFODrawShapeList &lstUpdate);
	
	// Obtain the group undo break levels. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Break Level, Returns the specified value.
	//		Returns a int type value.
	int GetUndoBreakLevel() const	{ return m_nUndoLevel; }

	// Enable ole data paste or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Ole Data Paste, Call this member function to enable or disable the specify object for this command.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&dataObject---&dataObject, Specifies a COleDataObject &dataObject object(Value).
	BOOL EnableOleDataPaste(COleDataObject &dataObject);
	
	// Obtain ole data string text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ole Data String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		&dataObject---&dataObject, Specifies a COleDataObject &dataObject object(Value).
	CString GetOleDataString(COleDataObject &dataObject);

	// Create from text.
	virtual CFODrawShape *DoCreateFromText(CString strText);

public:
	/*************************************************************************
	|*
	|* Help lines.
	|*
	\************************************************************************/
	
	// Hit Test help line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Help Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInHelpLine(
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Get help line top to bottom value.
	// szHorz -- size of horizontal line.
	// szVert -- size of vertical line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Maximize Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&szHorz---&szHorz, Specifies A CSize type value.  
	//		&szVert---&szVert, Specifies A CSize type value.
	virtual void GetMinMaxValue(CSize &szHorz,CSize &szVert);

	//Get Help Line Cursor
	// nFlags -- flag.
	// point -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Help Line Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickHelpLineCursor(UINT nFlags, CPoint point);

public:
	/*************************************************************************
	|*
	|* Layers.
	|*
	\************************************************************************/
	
	// Add new layer.
	// strLayer -- string of the layer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add New Layer, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		&strLayer---&strLayer, Specifies A CString type value.
	virtual CString DoAddNewLayer(const CString &strLayer);

	// Remove layer.
	// strLayer -- string of the layer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove Layer, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLayer---&strLayer, Specifies A CString type value.
	virtual void DoRemoveLayer(const CString &strLayer);

	// Rename layer.
	// nID -- id of the layer for rename.
	// strName -- new name of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rename Layer, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void DoRenameLayer(const UINT &nID,const CString &strName);

	// Change the list of the shapes to a new layer.
	// pList -- list of the shapes to change.
	// strName -- name of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Layer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&strName---&strName, Specifies A CString type value.
	virtual void ChangeShapesLayer(CFODrawShapeList *pList,const CString &strName);

	// Do moving layer.
	// nID -- id of the layer for moving.
	// nNewPos -- new pos of the layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Layer, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nNewPos---New Position, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoMoveLayer(const UINT &nID,const UINT &nNewPos);

	// Update one layer.
	// nID -- id of the layer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update One Layer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void UpdateOneLayer(const UINT &nID);

public:
	/*************************************************************************
	|*
	|* Mirror move lines.
	|*
	\************************************************************************/
	
	// Hit Test mirror line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Mirror Line, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInMirrorLine(
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Check current mirror side.
	// ptPnt -- point for checking
	// ptRef1 -- reference point for mirroring.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Mirror Side, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A CPoint type value.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.
	BOOL CheckMirrorSide(const CPoint& ptPnt,const CPoint &ptRef1) const;

	// Get Mirror Line Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Mirror Line Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickMirrorLineCursor(UINT nFlags, CPoint point);

	// Show mirror line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Mirror Line, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&pt1---Specifies A integer value.  
	//		&pt2---Specifies A integer value.
	virtual void ShowMirrorLine(const FOPPoint &pt1,const FOPPoint &pt2);
	
	// Hide mirror line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Mirror Line, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void HideMirrorLine();

	// Do draw mirror line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Mirror Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawMirrorLine(CDC *pDC);

	// Draw Move Track Mirror Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Mirror Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void DoMoveMirrorLine(CPoint point);

	// Draw Move Track Mirror Line point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Mirror Point, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void DoMoveMirrorPoint(CPoint point);

	// Draw mouse move focus shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Focus Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoDrawFocusShape(CFODrawShape *pShape);

	// Get reference points.
	// ptRef1 -- first point of the mirror line
	// ptRef2 -- the second point for the mirror line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Reference Points, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	BOOL GetRefPoints(CPoint &ptRef1,CPoint &ptRef2);

	// Update line handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Mirror Line, Call this member function to update the object.

	void UpdateMirrorLine();

	// Reset it to null.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Null Pan Window, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void NullPanWnd();

protected:

	// Sets the flag that determines whether double buffering will be used.
    // E-XD++ by default uses double buffering in drawing to the screen.  
	// This makes updates to the screen very smooth and avoids flashing common to many graphics applications. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Memory, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	void EnableMemory(
		// FALSE to disable double buffering
		BOOL bEnable
		);
    
	// Returns the setting of the flag that determines whether double buffering will be used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Enable Memory, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
    BOOL IsEnableMemory();
    
	// Clear drop comps list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Drop Shapes List, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  ClearDropShapesList();

	// Get max save rect of a list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Save Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	CRect GetShapesSaveRect(
		// List of shapes.
		CFODrawShapeList *pList
		);

	// Is current window has capture.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Has Capture, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL HasCapture();

	// Start tracking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Mouse Capture, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL PrepareMouseCapture();

	// Stop tracking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stop Mouse Capture, Call this function to stop
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL StopMouseCapture();
	
public:

	//Get Clipboard Format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardFormat() const;

	//Get Clipboard Format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardTable() const;

	//Get Clipboard Format
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get X D Clipboard Format, Returns the specified value.
	// This member function is a static function.
	//		Returns A CLIPFORMAT value (Object).
	virtual CLIPFORMAT GetXDClipboardSdrTable() const;

	// Is current model null.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Model Valid, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsModelValid() const;

	// Zoom previous.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom Previous, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomPrev();

	// Zoom next.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom Next, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomNext();

	// Do save template file.
	virtual void DoSaveNewTemplateFile();

	// Do save template file.
	virtual void DoOpenTemplateFile();

protected:

	// Is all shapes visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shape Visible, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsAllSelectShapeVisible();

	// Is all shapes that have tab order protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shape Tab Order Protect, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsAllSelectShapeTabOrderProtect();

	// Is all shapes flat.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shape Flat, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL	IsAllSelectShapeFlat();

	// Format menu text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Format Menu Name, .
	//		Returns a CString type value.  
	// Parameters:
	//		strMenu---strMenu, Specifies A CString type value.  
	//		strCommand---strCommand, Specifies A CString type value.
	CString FormatMenuName(
		// Menu string.
		CString& strMenu, 
		// Command string
		CString& strCommand
		);

	// Get need update rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Need Update Rectangle, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).  
	//		bErase---bErase, Specifies A Boolean value.
	BOOL GetNeedUpdateRect(
		// Update rectangle.
		LPRECT lpRect, 
		// Erase
		BOOL bErase
		);
public:
	/*************************************************************************
	|*
	|* Ole drag and drop.
	|*
	\************************************************************************/

	// check flag of Ole support
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Ole Support, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOleSupport();

	// Get drop source.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drop Source, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOViewDropSource,or NULL if the call failed
	virtual CFOViewDropSource* CreateDropSource();

	// Do drag and drop action,this method serialize the drag drop data.
	// pShapeList -- list of the shapes for serialize.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drag Drop, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void DoDragDrop(CFODrawShapeSet* pShapeList);

	// Obtain the drop target pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Target Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object COleDropTarget,or NULL if the call failed
	virtual COleDropTarget* GetDropTargetPointer() const;

public:
	/*************************************************************************
	|*
	|* Text that shows on the status bar.
	|*
	\************************************************************************/

	// Obtain the mouse position string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mouse Position String, Returns the specified value.
	//		Returns a CString type value.
	CString GetMousePosString() const { return m_IndMousePosString; }

	// Change the mouse position string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Mouse Position String, .
	// Parameters:
	//		&xPos---&xPos, Specifies A integer value.  
	//		&yPos---&yPos, Specifies A integer value.
	void ChangeMousePosString(const int &xPos,const int &yPos);

	// Obtain the shapes top left position string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Top Left String, Returns the specified value.
	//		Returns a CString type value.
	CString GetShapesTopLeftString() const { return m_IndShapesLeftTopString; }

	// Change the shapes top left position string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Top Left String, .
	// Parameters:
	//		&left---Specifies A integer value.  
	//		&top---Specifies A integer value.
	void ChangeShapesTopLeftString(const int &left,const int &top);

	// Obtain the shapes size string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Size String, Returns the specified value.
	//		Returns a CString type value.
	CString GetShapesSizeString() const { return m_IndShapesSizeString; }

	// Change the shapes size string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Shapes Size String, .
	// Parameters:
	//		&width---Specifies A integer value.  
	//		&height---Specifies A integer value.  
	//		&bRotate---&bRotate, Specifies A Boolean value.
	void ChangeShapesSizeString(const int &width,const int &height,const BOOL &bRotate = FALSE);

	// Generate pos string,override this method to update the status bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Position String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.  
	//		left---Specifies A integer value.  
	//		top---Specifies A integer value.
	virtual void GeneratePosString(
		// Text string.
		CString &strText,
		// Left position.
		int left,
		// Top position.
		int top);

	// Generate size string,override this method to update the size item of status bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Size String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.  
	//		width---Specifies A integer value.  
	//		height---Specifies A integer value.
	virtual void GenerateSizeString(
		// Text string.
		CString &strText,
		// Width.
		int width,
		// Height.
		int height);

	// Generate mouse position string,override this method to update the mouse position item of statusbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Mouse Position String, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.  
	//		xPos---xPos, Specifies A integer value.  
	//		yPos---yPos, Specifies A integer value.
	virtual void GenerateMousePosString(
		// Text string.
		CString &strText,
		// xPos.
		int xPos,
		// Height.
		int yPos);


	void GetAllSelectLinks(CFODrawShapeList *pLinks);

protected:

	// Build double buffer with a specify palette.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Buffer Palette, .
	// Parameters:
	//		*pPalette---*pPalette, A pointer to the CPalette  or NULL if the call failed.
	void RebuildBufferPalette(
		// Pointer of palette.
		CPalette *pPalette);

	// Alloc double buffer bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Memory, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL CreateMemory();

	// De Alloc double buffer bitmap.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Memory, Call this function to destroy an existing object.

	void DestroyMemory();

	// Need to be resized
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Out Buffer, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsOutBuffer();

	// Change buffer padding
	// nBufAdd -- adding value for double buffer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Buffer Add, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		&nBufAdd---Buffer Add, Specifies A integer value.
	void SetBufferAdd(const int &nBufAdd);

public:

	// Update current scroll bar position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateScrollBarPos();

	// Obtain scroll range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Range Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		lpMinPos---Minimize Position, Specifies a LPINT lpMinPos object(Value).  
	//		lpMaxPos---Maximize Position, Specifies a LPINT lpMaxPos object(Value).
	virtual void GetScrollRangeExt(int nBar, LPINT lpMinPos, LPINT lpMaxPos);

	// Get max rect of a list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Components Maximize Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	CRect GetCompsMaxRect(
		// List of shapes.
		CFODrawShapeList *pList
		);

	// Get max rect of a list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Visible Components Maximize Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.
	CRect GetVisibleCompsMaxRect(
		// List of shapes.
		CFODrawShapeList *pList
		);


	// Gen the tool tip.
	// ptHit -- point for hit testing.
	// info -- FOP_TIP_INFO object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Tool Tip, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&info---Specifies a FOP_TIP_INFO &info object(Value).
	virtual BOOL GenToolTip(const CPoint &ptHit,FOP_TIP_INFO &info);

public:

	// End text edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Finish, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnTextEditFinish(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// End edit box edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Edit Box, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnFinishEditBox(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// End combo box edit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Finish Combo Box, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnFinishComboBox(
		// Keyboard state flag.
		UINT nFlags, 
		// Hit point.
		CPoint point
		);

	// Do something before edit text.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Editing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL DoBeforeEditing(CFODrawShape *pShape);

	// Do something after text enter finished.
	// pShape -- pointer of shape.
	// strText -- text for entering.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Text Enter, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strText---&strText, Specifies A CString type value.
	virtual void DoAfterTextEnter(CFODrawShape *pShape, CString &strText);

	// Scale current page size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale To Device Resource, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		szNew---szNew, Specifies A CSize type value.
	BOOL ScaleToDeviceRes(
		// Current device dc.
		CDC* pDC, 
		// Size of new scale.
		CSize& szNew
		);

	// Update text editing box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Edit Text, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateEditText();

	// allow auto timer start.
	virtual BOOL DoHitAutoScroll(const CPoint &ptHitDev);

	// Stop auto timer.
	virtual BOOL StopAutoTimer();

	// Start auto timer.
	virtual BOOL StartAutoTimer();

	// Finish all edit box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Finish All Box, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		ptDev---ptDev, Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void FinishAllBox(UINT nFlags = 0, CPoint ptDev = CPoint(0,0));

	// Get focus shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Focus Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetFocusShape();

	// Release all edit box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release All Box, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseAllBox();

	// Draw all edit box's focus rect.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw All Box Focus, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DrawAllBoxFocus(CDC *pDC);

	// Draw printer paper margins.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Printer Paper Margins, Draws current object to the specify device.
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void DrawPrinterPaperMargins(CDC* pDC);

	// Custom the margin border or the start printing point by override this method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Custom Print Start Point, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	virtual void DoCustomPrintStartPoint(CPoint &ptOffset);

protected:
	
	// Validate current point.
	// point -- the point to check.
	// pShape -- the pointer of shape to check.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point Validate, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL	PointValidate(CPoint& point,CFODrawShape* pShape);

	
	// Get handle point.
	// rcPos -- position of shape.
	// nControlPoint -- A specify control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Hit Cursor Point, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		nControlPoint---Point, Specifies A integer value.
	CPoint			GetHitCursorPoint(CRect& rcPos, FO_CONTROL_HANDLE nControlPoint);

	// Judge Where point in Shape
	// point -- hit test point.
	// rect -- position of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Point In Specify Rectangle, .
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		rect---Specifies A CRect type value.
	static BOOL		PtInSpecifyRect(CPoint point, CRect rect);

	// Create handle rectangle.
	// point -- current mouse point.
	// bBig -- if be big mode,it return two bigger than normal.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Drag Rectangle, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		bBig---bBig, Specifies A Boolean value.
	virtual CRect	CreateDragRect(CPoint point,BOOL bBig = FALSE);

	// Find nearest grid line point.
	// point -- current point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Close Grid Point, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a CPoint type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	CPoint			FindCloseGridPoint(CPoint point);

	// Get select shape's count without the link.
	// listShapes -- the list of components.
	// list -- the list of shape to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Without Link, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).  
	//		list---Specifies a E-XD++ CFODrawShapeList& list object (Value).
	virtual int		GetShapesWithoutLink(const CFODrawShapeList& listShapes, CFODrawShapeList& list);

public:
	// Get the printer margin position.
	// return the margin of printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Margin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPrinterMargin();

	// Get current print page's position.
	// nPgIndex -- index of the print page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Print Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		&nPgIndex---Pg Index, Specifies A integer value.
	virtual CRect GetCurrentPrintPosition(const int &nPgIndex);

	// Make sure page is blank.
	// nPgIndex -- index of the page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Print Page Blank, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPgIndex---Pg Index, Specifies A integer value.
	virtual BOOL IsPrintPageBlank(const int &nPgIndex);

	// Obtain total truly print pages
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Print Pages, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetTotalPrintPages();

	// Create printer dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Printer D C, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CDC,or NULL if the call failed
	CDC* CreatePrinterDC();

public:
	//////////////////////////////////////////////////////////////////////////////////
	// Generate part of image.
	
	// Get current print page's position.
	// nPgIndex -- index of the print page
	// szPage -- size of part image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Part Bitmap Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		&nPgIndex---Pg Index, Specifies A integer value.  
	//		&szPage---&szPage, Specifies a const FOPSize &szPage object(Value).
	virtual CRect GetCurrentPartBitmapPosition(const int &nPgIndex, const FOPSize &szPage);

	// Make sure page is blank.
	// nPageNum -- page number.
	// szPage -- size of part image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Part Bitmap Page Blank, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nPageNum---Page Number, Specifies A integer value.  
	//		&szPage---&szPage, Specifies a const FOPSize &szPage object(Value).
	virtual BOOL IsPartBitmapPageBlank(const int &nPageNum, const FOPSize &szPage);

	// Do draw part bitmap page.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Draw Part Bitmap, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnFOPDrawPartBitmap(CDC* pDC);

	// Do draw part bitmap page.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Draw Part Bitmap, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rcPageCanvas---Page Canvas, Specifies a const FOPRect &rcPageCanvas object(Value).
	virtual void OnNewDrawPartBitmap(CDC* pDC, const FOPRect &rcPageCanvas);

	// Do generate part of bitmap.
	// pImage -- pointer of image.
	// pDC -- pointer of DC.
	// nPageNum -- page number.
	// szPage -- size of part image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Part Image, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pImage---pImage, A pointer to the CFOBitmap or NULL if the call failed.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&nPageNum---Page Number, Specifies A integer value.  
	//		&szPage---&szPage, Specifies a const FOPSize &szPage object(Value).
	virtual BOOL DoDrawPartImage(CFOBitmap* pImage, CDC* pDC, const int &nPageNum, const FOPSize &szPage);

	// Export form as bitmap file.
	// lpszFileName -- jpeg file name.
	// nPageNum -- page number.
	// szPage -- size of part image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export Part As Bmpfile, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&nPageNum---Page Number, Specifies A integer value.  
	//		&szPage---&szPage, Specifies A CSize type value.  
	//		500)---Specifies a 500) object(Value).
	virtual BOOL  ExportPartAsBmpfile(LPCTSTR lpszFileName, const int &nPageNum = 0, 
		const FOPSize &szPage = CSize(500,500));

	// Export form as jpeg file.
	// lpszFileName -- jpeg file name.
	// nPageNum -- page number.
	// szPage -- size of part image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export Part As Jpegfile, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&nPageNum---Page Number, Specifies A integer value.  
	//		&szPage---&szPage, Specifies A CSize type value.  
	//		500)---Specifies a 500) object(Value).
	virtual BOOL  ExportPartAsJpegfile(LPCTSTR lpszFileName, const int &nPageNum = 0, 
		const FOPSize &szPage = CSize(500,500));

	// Generate the total pages of canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Part Bitmap, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetTotalPartBitmap();

	// Do generate part of bitmap.
	// pImage -- pointer of image.
	// pDC -- pointer of DC.
	// rcPageCanvas -- position of canvas that will be exported.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Part Of Canvas, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pImage---pImage, A pointer to the CFOBitmap or NULL if the call failed.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rcPageCanvas---Page Canvas, Specifies a const FOPRect &rcPageCanvas object(Value).
	virtual BOOL DoDrawPartOfCanvas(CFOBitmap* pImage, CDC* pDC, const FOPRect &rcPageCanvas);

	// Export form as bitmap file.
	// lpszFileName -- jpeg file name.
	// rcPageCanvas -- position of canvas that will be exported.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export Part As Bmpfile New, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&rcPageCanvas---Page Canvas, Specifies a const FOPRect &rcPageCanvas object(Value).
	virtual BOOL  ExportPartAsBmpfileNew(LPCTSTR lpszFileName, const FOPRect &rcPageCanvas);
	
	// Export form as jpeg file.
	// lpszFileName -- jpeg file name.
	// rcPageCanvas -- position of canvas that will be exported.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export Part As Jpegfile New, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&rcPageCanvas---Page Canvas, Specifies a const FOPRect &rcPageCanvas object(Value).
	virtual BOOL  ExportPartAsJpegfileNew(LPCTSTR lpszFileName, const FOPRect &rcPageCanvas);


	// File export.
	// rcPageCanvas -- position of canvas that will be exported.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Part Canvas Export File, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPageCanvas---Page Canvas, Specifies a const FOPRect &rcPageCanvas object(Value).
	virtual void  DoPartCanvasExportFile(const FOPRect &rcPageCanvas);

protected:

	// Get shapes for moving.
	// pShapeList -- Result list of shapes that can be moved.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Moving Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void GetMovingShapes(CFODrawShapeList* pShapeList);

	// Get shapes for resizing.
	// pShapeList -- Result list of shapes that can be resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Resizing Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void GetResizingShapes(CFODrawShapeList* pShapeList);

	// Get shapes for rotating.
	// pShapeList -- Result list of shapes that can be rotated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotating Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void GetRotatingShapes(CFODrawShapeList* pShapeList);

	// Get shapes for copying.
	// pShapeList -- Result list of shapes that can be copied.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Copying Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void GetCopyingShapes(CFODrawShapeSet* pShapeList);

	// Get shapes for deleting.
	// pShapeList -- Result list of shapes that can be deleted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Deleting Shapes, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void GetDeletingShapes(CFODrawShapeList* pShapeList);

public:

	// Align Actions.
	// Align Left
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Left Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignLeftAction();

	// Align Right
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Right Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignRightAction();

	// Align Top 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Top Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignTopAction();

	// Align Bottom 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Bottom Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignBottomAction();

	// Size actions.
	// Size Horizon Action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Hor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSizeHorAction();

	// Size Vertical Action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Ver Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSizeVerAction();

	// Size All Action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size All Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSizeAllAction();

	// Space change action.
	// Space horizon action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Hor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSpaceHorAction();

	// Space vertical action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Space Ver Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoSpaceVerAction();

	// Align in form action.
	// Align Vertical center action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Vertcenter Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignVertcenterAction();

	// Align Horizon center action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Alignment Horcenter Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	DoAlignHorcenterAction();

	// Align shapes with bounding or snap,it will align shapes but it do not need the main shape.
	// eHor -- horizontal type,it must be one of the following value:
	// 	enum FOPHorzAlign  
	// {
	// 	FOPHALIGN_NONE,
	// 	FOPHALIGN_LEFT,
	// 	FOPHALIGN_RIGHT,
	// 	FOPHALIGN_CENTER
	// };
	// eVert -- vertical type.
	// 	enum FOPVertAlign 
	// {
	// 	FOPVALIGN_NONE,
	// 	FOPVALIGN_TOP,
	// 	FOPVALIGN_BOTTOM,
	// 	FOPVALIGN_CENTER
	// };
	// bBoundRects -- use bounding rectangle or snap rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alignment Marked Objects Without Main, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		eHor---eHor, Specifies a FOPHorzAlign eHor object(Value).  
	//		eVert---eVert, Specifies a FOPVertAlign eVert object(Value).  
	//		bBoundRects---Bound Rects, Specifies A Boolean value.
	virtual void AlignMarkedObjectsWithoutMain(FOPHorzAlign eHor, FOPVertAlign eVert, BOOL bBoundRects=FALSE);

	// for distribution dialog function
	// eHor -- horizontal type.
	// enum FOPDistributeHorizontal
	// {
	// 	FOPDistributeHorizontalNone = 0,
	// 	FOPDistributeHorizontalLeft,
	// 	FOPDistributeHorizontalCenter,
	// 	FOPDistributeHorizontalDistance,
	// 	FOPDistributeHorizontalRight
	// };
	// eVert -- vertical type
	// 	enum FOPDistributeVertical
	// {
	// 	FOPDistributeVerticalNone = 0,
	// 	FOPDistributeVerticalTop,
	// 	FOPDistributeVerticalCenter,
	// 	FOPDistributeVerticalDistance,
	// 	FOPDistributeVerticalBottom
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distribute Marked Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		eHor---eHor, Specifies a FOPDistributeHorizontal eHor object(Value).  
	//		eVert---eVert, Specifies a FOPDistributeVertical eVert object(Value).
	virtual void DistributeMarkedShape(FOPDistributeHorizontal eHor, FOPDistributeVertical eVert);

	// Create tracking shape from file.
	CFOCompositeShape* CreateXTrackShapeFile(const CString &strType);


	// Do load template file.
	virtual void DoLoadTemplateFile();

public:

	// Obtain only moved shapes.
	virtual void GetOnlyMoved(CFODrawShapeList &m_list, CFODrawShapeList *pShapeAll);

	// Move and size action.
	// Move a list of shapes.
	// pShapeList -- the list of shapes.
	// nOffsetX -- x offset size.
	// nOffsetY -- y offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveCompsAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nOffsetX---Offset X, Specifies A integer value.  
	//		nOffsetY---Offset Y, Specifies A integer value.
	virtual CFOMoveCompsAction*	DoMoveAction(CFODrawShapeList* pShapeList, int nOffsetX, int nOffsetY);

	// Do Group a list of shape action.
	// pShapeList -- the list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Group Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOGroupAction*		DoGroupAction(CFODrawShapeList* pShapeList);

	// Do Composite a list of shape action.
	// pShapeList -- the list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Composite Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOGroupAction*		DoCompositeAction(CFODrawShapeList* pShapeList);

	// Do Ungroup a shape action.
	// pShape -- the pointer of group shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Un Group Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOUnGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShape---pShape, A pointer to the CFOCompositeShape or NULL if the call failed.
	virtual CFOUnGroupAction*		DoUnGroupAction(CFOCompositeShape* pShape);

	// Do Ungroup multi shapes action.
	// pShapeList -- the pointer of group shape list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Multiple Un Group Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiUnGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOMultiUnGroupAction*	DoMultiUnGroupAction(CFODrawShapeList* pShapeList);


	// Do Size Spot Action
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizeSpotAction,or NULL if the call failed  
	// Parameters:
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOSizeSpotAction*		DoSizeSpotAction(int nSpotIndex,CPoint ptNew);

	// Do Size Spot Action
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizeSpotAction,or NULL if the call failed  
	// Parameters:
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOSizeSpotAction*		DoSizePathAction(CPoint ptOffset);

	// Do Size port Action
	// pPortHit -- pointer of the port that hitted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Port Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizePortAction,or NULL if the call failed  
	// Parameters:
	//		*pPortHit---Port Hit, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual CFOSizePortAction*		DoSizePortAction(CFOPortShape *pPortHit);

	// Do Size Spot Action
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Center Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOSizeCenterSpotAction,or NULL if the call failed  
	// Parameters:
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOSizeCenterSpotAction*		DoSizeCenterSpotAction(int nSpotIndex,CPoint ptNew);

	// Do Size anchor point Action
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveAnchorAction*	DoSizeAnchorAction(CPoint ptNew);

	// Do Size extend anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Extend Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveExtAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveExtAnchorAction*	DoSizeExtAnchorAction(CPoint ptNew);

	// Do Size third anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Third Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveThirdAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveThirdAnchorAction*	DoSizeThirdAnchorAction(CPoint ptNew);

	// Do Size four anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Four Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveFourAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveFourAnchorAction*	DoSizeFourAnchorAction(CPoint ptNew);

	// Do Size five anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Five Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveFiveAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveFiveAnchorAction*	DoSizeFiveAnchorAction(CPoint ptNew);

	// Do Size text anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Text Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveTextAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveTextAnchorAction*	DoSizeTextAnchorAction(CPoint ptNew);

	// Do Size user anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size User Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveUserAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveUserAnchorAction*	DoSizeUserAnchorAction(const int &nPtIndex, CPoint ptNew);

	// Do Size visio handle point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Microsoft Visio style Handle Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveVisioHandleAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveVisioHandleAction*	DoSizeVisioHandleAction(CPoint ptNew);

	// Do Size third anchor point Action.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Size Center Anchor Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMoveCenterAnchorAction,or NULL if the call failed  
	// Parameters:
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOMoveCenterAnchorAction*	DoSizeCenterAnchorAction(CPoint ptNew);

	// Do Add new Spot to a specify shape Action
	// pShape -- A specify shape that can be added spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOAddSpotAction,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nSpotIndex---Spot Index, Specifies A integer value.  
	//		ptNew---ptNew, Specifies A CPoint type value.
	virtual CFOAddSpotAction*		DoAddSpotAction(CFODrawShape *pShape,int nSpotIndex,CPoint ptNew);

	// Do Remove a Spot from a specify shape Action
	// pShape -- A specify shape that can be removed spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Remove Spot Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORemoveSpotAction,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nSpotIndex---Spot Index, Specifies A integer value.
	virtual CFORemoveSpotAction*	DoRemoveSpotAction(CFODrawShape *pShape,int nSpotIndex);

	// Do Change form width and height Action
	// nEndX -- the last x position.
	// nEndY -- the last y position.
	// nControlPoint -- drag handle,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Form Scale Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOFormSizeAction,or NULL if the call failed  
	// Parameters:
	//		nEndX---End X, Specifies A integer value.  
	//		nEndY---End Y, Specifies A integer value.  
	//		nControlPoint---Point, Specifies A integer value.
	virtual CFOFormSizeAction*		DoFormScaleAction(int nEndX,int nEndY,FO_CONTROL_HANDLE nControlPoint);
  
	// Do Remove a list of Shapes.
	// pShapeList -- the list of shapes for removing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Delete Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORemoveCompsAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFORemoveCompsAction*	DoDeleteAction(CFODrawShapeList* pShapeList);

	// Do Add new Shape Action
	// pShape -- the pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Insert Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOAddCompAction,or NULL if the call failed  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual CFOAddCompAction*		DoInsertAction(CFODrawShape* pShape);

	// Do Order shape Action
	// pShapeList -- the list of shapes.
	// nOrderType -- the order type.
	// enum OrderFlag
	// {
	// 	OrderNone,			Order none.
	// 	OrderFront,			Order front.
	// 	OrderBack,			Order back.
	// 	OrderForward,		Order forward.
	// 	OrderBackward		Order backward.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Order Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOOrderAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nOrderType---Order Type, Specifies a OrderFlag nOrderType object(Value).
	virtual CFOOrderAction*		DoOrderAction(CFODrawShapeList* pShapeList, OrderFlag nOrderType);

	// Do Resize a specify shapes Action,resize shapes with its own CONTROL_HANDLE.
	// the list of shapes.
	// dX -- x scale.
	// dY -- y scale.
	// nPoint -- the control handle,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resize Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOScaleAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nPoint---nPoint, Specifies A integer value.
	virtual CFOScaleAction*		DoResizeShapesAction(CFODrawShapeList* pShapeList,double dX,double dY,FO_CONTROL_HANDLE nPoint);

	// Do Resize a specify shape Action,resize shapes with the total selection rectangle's CONTROL_HANDLE.
	// the list of shapes.
	// dX -- x scale.
	// dY -- y scale.
	// nPoint -- the control handle,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resize Shapes Action Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFONewScaleAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nPoint---nPoint, Specifies A integer value.
	virtual CFONewScaleAction*	DoResizeShapesActionEx(CFODrawShapeList* pShapeList,double dX,double dY,FO_CONTROL_HANDLE nPoint);

	// Do Rotate a specify shapes Action,rotate the shapes around each shape's center.
	// pShapeList -- the list of shapes.
	// nAngle -- the angle to rotate(from 0 to 360)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFORotateAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFORotateAction*	DoRotateShapesAction(CFODrawShapeList* pShapeList,int nAngle);

	// Do Resize a specify shapes Action,rotate the shapes around the total selection rectangle's center.
	// pShapeList -- the list of shapes.
	// nAngle -- rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Rotate Shapes Action Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFONewRotateAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFONewRotateAction*	DoRotateShapesActionEx(CFODrawShapeList* pShapeList,int nAngle);

	// Do Skew x a specify shapes Action.
	// pShapeList -- the list of shapes.
	// ptOrigin -- origin point
	// nAngle -- rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Skew X Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSkewXAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptOrigin---&ptOrigin, Specifies A CPoint type value.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFOPSkewXAction* DoSkewXShapesAction(CFODrawShapeList* pShapeList,const CPoint &ptOrigin,int nAngle);

	// Do Skew y a specify shapes Action.
	// the list of shapes.
	// nAngle -- rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Skew Y Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSkewYAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptOrigin---&ptOrigin, Specifies A CPoint type value.  
	//		nAngle---nAngle, Specifies A integer value.
	virtual CFOPSkewYAction* DoSkewYShapesAction(CFODrawShapeList* pShapeList,const CPoint &ptOrigin,int nAngle);

	// Do Mirror a specify shapes Action.
	// the list of shapes.
	// ptRef1 -- Mirror reference start point.
	// ptRef2 -- Mirror reference end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Mirror Shapes Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMirrorShapesAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	virtual CFOMirrorShapesAction*	DoMirrorShapesAction(CFODrawShapeList* pShapeList,const CPoint &ptRef1,
		const CPoint &ptRef2);

	// Do Resize current hit shape Action
	// fX -- x scale.
	// fY -- y scale.
	// nPoint -- the control handle,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *		9			  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			10		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	BeCenter					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Resize Current Shape Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOScaleExtendAction,or NULL if the call failed  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		nPoint---nPoint, Specifies A integer value.
	virtual CFOScaleExtendAction*	DoResizeCurrentShapeAction(double dX,double dY,FO_CONTROL_HANDLE nPoint);


	// Do move shapes within horizontal view action
	// clientRect -- area of client rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do In View Horiz Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&clientRect---&clientRect, Specifies A CRect type value.
	virtual void	DoInViewHorizAction(CRect &clientRect);

	// Update tracking.
	void UpdateTrackState();

	// Update tracking.
	void DrawTrackState();

	// Do move shapes within View Vertical Action
	// clientRect -- area of client rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do In View Vertical Action, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&clientRect---&clientRect, Specifies A CRect type value.
	virtual void	DoInViewVertAction(CRect &clientRect);

	// Do move scroll.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Scroll Move, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptNew---&ptNew, Specifies A CPoint type value.  
	//		&szOffset---&szOffset, Specifies A CSize type value.
	BOOL DoScrollMove(
		// New point
		CPoint &ptNew, 
		// Offset size.
		CSize &szOffset
		);

	// Is custom dragging support format, override this method and DoCreateCustomDragShape method to handle your own 
	// new format drag/drop support.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Custom Drag Format, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCustomDragFormat() const;

	// Do Create your own drag shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Create Custom Drag Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	virtual void DoCreateCustomDragShape(COleDataObject* pDataObject,CPoint point);

	// Change printer Orientation.
	// mode -- The new orientation flag. DMORIENT_PORTRAIT (1) or DMORIENT_LANDSCAPE (2)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Printer Orientation, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		mode---Specifies a short mode object(Value).
	virtual void ChangePrinterOrientation(short mode);


	// Do something after single click to create link.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do After Single Click Create, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptLog---&ptLog, Specifies A integer value.
	virtual void DoAfterSingleClickCreate(const FOPPoint &ptLog);
	
public:

	// Select change action
	// Selection Change action
	// pChangedList -- list of shapes to update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shapes, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChangedList---Changed List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptRotate---&ptRotate, Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void	UpdateShapes(CFODrawShapeList* pChangedList,const CPoint &ptRotate = CPoint(0,0));

	// Select change action
	// Selection Change action
	// pChangedList -- list of shapes to update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shapes, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChangedList---Changed List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptRotate---&ptRotate, Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void	UpdateShapes2(CFODrawShapeList* pChangedList,const CPoint &ptRotate = CPoint(0,0));

	// Select change action
	// Selection Change action
	// pChangedList -- list of shapes to update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shapes, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChangedList---Changed List, A pointer to the CFODrawShapeSet or NULL if the call failed.  
	//		&ptRotate---&ptRotate, Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void	UpdateShapes(CFODrawShapeSet* pChangedList,const CPoint &ptRotate = CPoint(0,0));

	// Select change action
	// Visible Change action
	// pChangedList -- list of shapes to update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Visible Shapes, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pChangedList---Changed List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&ptRotate---&ptRotate, Specifies A CPoint type value.  
	//		0)---Specifies a 0) object(Value).
	virtual void	UpdateVisibleShapes(CFODrawShapeList* pChangedList,const CPoint &ptRotate = CPoint(0,0));

	// Update shape with links.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Shape With Link, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void UpdateShapeWithLink(CFODrawShape *pShape);


	// Update data.
	virtual void UpdateAllData();

	// Delete Shape action
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Shape, Deletes the given object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void	DeleteShape(CFODrawShape *pShape);

	// Is current shape has over 4 points.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Spots, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	IsMultiSpots(CFODrawShape *pShape);

	// Is current shape has can be with editing points feature.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Point Edit Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BePointEditShape(CFODrawShape *pShape);

	// Pick nearest point with it's previous point
	// ptPrev -- the previous point for glue.
	// ptPick -- nearest glue point, this is a return point.
	// ptHit -- HitTest logical point.
	// bWithSelection -- if it is true, itself will be used for glue.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point New, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPrev---&ptPrev, Specifies A CPoint type value.  
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL			PickNearestPointNew(const CPoint &ptPrev,
		// Nearest point.
		CPoint &ptPick,
		// Mouse hit point.
		const CPoint &ptHit);

	// Pick nearest point with it's previous point
	// ptPrev -- the previous point for glue.
	// ptPick -- nearest glue point, this is a return point.
	// ptHit -- HitTest logical point.
	// bWithSelection -- if it is true,itself will be used for glue.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point New2, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptPrev---&ptPrev, Specifies A CPoint type value.  
	//		&ptPrev2---&ptPrev2, Specifies A CPoint type value.  
	//		&ptPick---&ptPick, Specifies A CPoint type value.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL			PickNearestPointNew2(const CPoint &ptPrev,
		const CPoint &ptPrev2,
		// Nearest point.
		CPoint &ptPick,
		// Mouse hit point.
		const CPoint &ptHit);
public:

	// Is current shape has can be with Dim line style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Dimension Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeDimShape(CFODrawShape *pShape);

	// Is current shape has can be with caption style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Cap Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeCapShape(CFODrawShape *pShape);

	// Is current shape has can be with arc style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Arc Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeArcShape(CFODrawShape *pShape);

	// Is current shape has can be with extend arc style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Arc2 Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeArc2Shape(CFODrawShape *pShape);

	// Is current shape has can be with Polygon style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Polygon Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BePolygonShape(CFODrawShape *pShape);

	// Is current shape has can be with Line style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Line Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeLineShape(CFODrawShape *pShape);

	// Is current shape has can be with Bezier Line style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Bezier Line Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeBezierLineShape(CFODrawShape *pShape);

	// Is current shape has can be with Close Bezier style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Close Bezier Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeCloseBezierShape(CFODrawShape *pShape);

	// Is current shape has can be with free Line style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Free Line Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BeFreeLineShape(CFODrawShape *pShape);

	// Is current shape has can be with path style shape.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Path Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL	BePathShape(CFODrawShape *pShape);

public:

	//
	// Get currently track shapes position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Track Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalTrackSnapRect();

	// Do update font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// Parameters:
	//		&nSize---&nSize, Specifies a double &nSize object(Value).
	void DoUpdateFont(double &nSize);

	// Do something before paste shapes to canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Paste, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pListCopy---List Copy, A pointer to the CFODrawShapeList  or NULL if the call failed.
	virtual void DoBeforePaste(CFODrawShapeList *pListCopy);

	// Do something when mouse moving to expand canvas.
	// ptLog -- current logic point of mouse.
	// rcLog -- logic area of client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Expand Canvas, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptLog---&ptLog, Specifies A integer value.  
	//		&rcLog---&rcLog, Specifies a const FOPRect &rcLog object(Value).
	virtual void DoExpandCanvas(const FOPPoint &ptLog, const FOPRect &rcLog);


public:
	////////////////////////////////////////////////////////////////
	// Feedback from current focus control.
	// 
	//////////////////////////////////////////////////////////////// 

	// Update form mode border.
	virtual void UpdateFormBorders();
	
	// Do Ctrl key down mode.
	// pSender -- pointer of the sender window.
	// nMessage -- message
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Process  Keys, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pSender---pSender, A pointer to the CWnd or NULL if the call failed.  
	//		nMessage---nMessage, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		flags---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoProcessCtrlKeys(CWnd* pSender, UINT nMessage,
		UINT nChar, UINT nRepCnt = 1, UINT flags = 0);

	// Focus on a specify shape.
	// pObj -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Focus New Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pObj---*pObj, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL DoFocusNewShape(CFODrawShape *pObj, UINT nChar = -1);

	// Focus on a specify shape.
	// pObj -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Focus New Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pObj---*pObj, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL DoEditTableShape(CFODrawShape *pObj, UINT nChar);

	// Do click event from button, check button, check box, etc.
	// pShape -- pointer of shape.
	// nSel -- item index that selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Button Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pnSelShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nSel---&, Specifies A integer value.
	virtual void DoClickEventOn(CFODrawShape *pShape,const int &nSel);

	// Do click event from button, check button, check box, etc.
	// pShape -- pointer of shape.
	// nSel -- item index that selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Button Click Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nSel---&nSel, Specifies A integer value.
	virtual void DoButtonClickEvent(CFODrawShape *pShape,const int &nSel);

	// Do when the enter text changed, for edit box shape, rich edit box, etc.
	// pShape -- pointer of shape.
	// strChange -- string that changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Edit Text Change Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strChange---&strChange, Specifies A CString type value.
	virtual void DoEditTextChangeEvent(CFODrawShape *pShape,const CString &strChange);

	// Do when the menu item changed, for image button or menu button, etc.
	// pShape -- pointer of shape.
	// strChange -- string that changed, it is the menu text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Button Menu Change Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strChange---&strChange, Specifies A CString type value.
	virtual void DoButtonMenuChangeEvent(CFODrawShape *pShape,const CString &strChange);

	// Do drag slider bar event for all kind of shapes, etc.
	// pShape -- pointer of shape.
	// nCurValue -- current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Drag Slider, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nCurValue---Current Value, Specifies a const double &nCurValue object(Value).
	virtual void DoEventDragSlider(CFODrawShape *pShape,const double &nCurValue);

	// Do drag slider bar event for all kind of shapes, etc.
	// pShape -- pointer of shape.
	// nCurValue -- current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Drag Slider, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nCurValue---Current Value, Specifies a const double &nCurValue object(Value).
	virtual void DoEventSecondValue(CFODrawShape *pShape,const double &nCurValue, const double &dValueSecond);

	// Do sel text clicked, list box, combo box, etc.
	// pShape -- pointer of shape.
	// strValue -- current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Click On Text Item, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strValue---&strValue, Specifies A CString type value.
	virtual void DoClickOnTextItem(CFODrawShape *pShape,const CString &strValue);

	// Do click event for all kind of shapes, etc.
	// pShape -- pointer of shape.
	// nEventType -- event type.
	// strEvent -- event string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event At All Geometry Down, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nEventType---Event Type, Specifies A integer value.  
	//		&strEventText---Event Text, Specifies A CString type value.
	virtual void DoEventAtAllGeometryDown(CFODrawShape *pShape,const int &nEventType, const CString &strEventText);

	// Do click event for all kind of shapes, etc.
	// pShape -- pointer of shape.
	// nEventType -- event type.
	// strEvent -- event string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event At All Geometry Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nEventType---Event Type, Specifies A integer value.  
	//		&strEventText---Event Text, Specifies A CString type value.
	virtual void DoEventAtAllGeometryUp(CFODrawShape *pShape,const int &nEventType, const CString &strEventText);

	// Do click right click menu event for all kind of shapes, etc.
	// pShape -- pointer of shape.
	// nEventType -- event type.
	// strEvent -- event string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event At All Geometry Up, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nEventType---Event Type, Specifies A integer value.  
	//		&strEventText---Event Text, Specifies A CString type value.
	virtual void DoEventAtRightClickUpMenu(CFODrawShape *pShape,const int &nEventType, const CString &strEventText);

	// Do double click on shape, etc.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Double Click On Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoEventDoubleClickOnShape(CFODrawShape *pShape);

	// Do double click on shape, etc.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event R Button Click On Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoEventRButtonClickOnShape(CFODrawShape *pShape);

	// Do double click on shape, etc.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event R Button Up On Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoEventRButtonUpOnShape(CFODrawShape *pShape);

	// Do double click on shape, etc.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Mouse Move On Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoEventMouseMoveOnShape(CFODrawShape *pShape);

	// Do init the list choice text of any shape, this virtual method will be called before the drop list box dropped.
	// pShape -- pointer of shape.
	// strChoice -- choice string text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Drop List, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strChoice---&strChoice, Specifies A CString type value.
	virtual void DoInitDropList(CFODrawShape *pShape, CString &strChoice);

	// When the value of property is changed, this event will be called. etc.
	// pShape -- pointer of shape.
	// nPropId -- ID value of property that changed.
	// prop -- pointer of property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Property Change Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void DoPropertyChangeEvent(CFODrawShape *pShape,const int &nPropId, CFOBaseProperties* prop);

	// Reset all select mode of select.
	virtual void ResetAllShapeSelectMode(const BOOL &bSelect);

public:
	// event for shape.
	// Do event before relink shape.
	// pLink -- link  shape.
	// pPort -- port that moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Before Relink, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL DoEventBeforeRelink(CFOLinkShape *pLink, CFOPortShape *pPort);

	// Do event after relink shape.
	// pLink -- link  shape.
	// pPort -- port that moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event End Relink, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void DoEventEndRelink(CFOLinkShape *pLink, CFOPortShape *pPort);

	// Do event when dragging.
	// pDataObject -- data object.
	// dwKeyState -- key state.
	// point -- device point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Drag, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual void DoEventDrag(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);

	// Do event when drop.
	// pDataObject -- data object.
	// dropEffect -- drop effect.
	// point -- device point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Drop, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).  
	//		point---Specifies A CPoint type value.
	virtual void DoEventDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);

	// Do event when single click on shape.
	// pShape -- object that clicked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Event Single Click, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoEventSingleClick(CFODrawShape *pShape);

	// Double click at design mode.
	// pShape -- object that clicked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Double Hit Test With Design Mode, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL DoubleHitTestWithDesignMode(CFODrawShape *pShape);

	// Do cancel mouse move action.
	virtual void DoCancelMouseAction();

protected:

	// Tab order change.
	// Get MainShape 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Anchor Shape, Do a event. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *DoGetAnchorShape();

	// Correct Tab Order
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Correct Tab Order, Do a event. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *DoCorrectTabOrder();

	// Action Start Tab Order
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Tab Order, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void	DoChangeTabOrder(CPoint point);

	// Hit Test Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInShape(
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

#ifdef _FOP_E_SOLUTION
	// Hit Test Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In New Grid, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pGrid---*pGrid, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInNewGrid(
		// pointer of the grid
		CFOPNewGridShape *pGrid,
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		const CPoint &ptHit, UINT nButton = VK_LBUTTON);

	// Hit Test Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In New Grid, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pGrid---*pGrid, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual FOPGridCell*	PickInNewGrid2(
		// pointer of the grid
		CFOPNewGridShape *pGrid,
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		const CPoint &ptHit, UINT nButton = VK_LBUTTON);

	// Hit Test Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dblck Pick In New Grid, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pGrid---*pGrid, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	DblckPickInNewGrid(
		// pointer of the grid
		CFOPNewGridShape *pGrid,
		// Mouse key flags.
		UINT nFlags,
		// Mouse hit point.
		const CPoint &ptHit, UINT nButton = VK_LBUTTON);

	// Hit Test new grid shape Handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Grid Shape Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pGrid---*pGrid, A pointer to the CFOPNewGridShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInGridShapeCursor(
		// Pointer of the grid shape
		CFOPNewGridShape *pGrid,
		// Mouse key flags.
		UINT nFlags, 
		// Mouse hit point.
		const CPoint &ptHit, UINT nButton = VK_LBUTTON);

	// Do layout scroll bars.
	virtual void DoLayoutScrolls();

#endif

	// Hit Test Shape spot.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Pick Shape Spot, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pHitShape---Hit Shape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	DoPickShapeSpot(CFODrawShape *pHitShape,
		// Mouse key flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Hit Test Shape Handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Shape Spots, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInShapeSpots(
		// Mouse key flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Hit Test Shape Handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Single Shape Spots, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pHitShape---Hit Shape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInSingleShapeSpots(CFODrawShape *pHitShape,
		// Mouse key flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);


	// Hit Test Shape Handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Multiple Shape Spots, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInMultiShapeSpots(
		// Mouse key flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Hit Test Form Handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick In Form Shape Spots, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	PickInFormShapeSpots(
		// Mouse hit point
		CPoint point, UINT nButton = VK_LBUTTON);

	// Hit Test Control Handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pCurHit---Current Hit, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFODrawShape* PickShapeHandle(CFODrawShape *pCurHit,
		// Mouse hit point
		CPoint ptHit, 
		// Control handle index.
		int& nIndex
		);

	// Hit Test Control Handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Center Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pCurHit---Current Hit, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFODrawShape* PickShapeCenterHandle(CFODrawShape *pCurHit,
		// Mouse hit point
		CPoint ptHit, 
		// Control handle index.
		int& nIndex
		);

	// Hit Test Control Handle
	virtual CFODrawShape* PickShapeCenterNewHandle(
		// Mouse hit point
		CPoint ptHit, 
		// Control handle index.
		int& nIndex
		);
	
	// Do Add new Spot to a specify shape Action
	// pShape -- A specify shape that can be added spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	virtual void		DoAddPathShapeSpotAction(CFOPNewPathShape *pShape,int nSpotIndex, const BOOL &bCtrl = FALSE);
	
	// Do Remove a Spot from a specify shape Action
	// pShape -- A specify shape that can be removed spot.
	// nSpotIndex -- the index of spot to size.
	// ptNew -- the new point.
	virtual void	DoRemovePathShapeSpotAction(CFOPNewPathShape *pShape,int nSpotIndex);

	// Is all select shapes are lines.
	BOOL IsAllLinesNew();

	// Is approx;
	BOOL IsApprox(double x, double y);
	
	// Calc other middle two points.
	void CalcOtherTwoPoints(const CPoint &ptStart,const CPoint &ptEnd, CPoint &ptMiddle1,CPoint &ptMiddle2);
	
	// Hit Test Control Handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Multiple Shapes Resize Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.
	virtual BOOL PickMultiShapesResizeHandle(
		// Mouse hit point
		CPoint ptHit, 
		// Control handle index.
		int& nIndex);

	// Hit Test Control Handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Rotate Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pCurHit---Current Hit, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual CFODrawShape* PickShapeRotateHandle(CFODrawShape *pCurHit,
		// Mouse hit point
		CPoint ptHit);

	// Hit Test Control Handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Multiple Shapes Rotate Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual BOOL PickMultiShapesRotateHandle(
		// Mouse hit point
		CPoint ptHit);

	// Hit test plus handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Plus Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pCurHit---Current Hit, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&nCurID---Current I D, Specifies A integer value.
	virtual CFODrawShape* PickShapePlusHandle(CFODrawShape *pCurHit,
		// Mouse hit point
		CPoint ptHit,
		// Control handle index.
		int& nIndex,
		// Cursor id.
		int &nCurID
		);

	virtual BOOL DoPrevPlusAction(CFODrawShape *pHitShape, UINT nFlags,CPoint ptLog, UINT nButton);

	// Hit test plus handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Plus Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pCurHit---Current Hit, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.  
	//		&nCurID---Current I D, Specifies A integer value.
	virtual CFODrawShape* PickShapePrevPlusHandle(CFODrawShape *pCurHit,
		// Mouse hit point
		CPoint ptHit,
		// Control handle index.
		int& nIndex,
		// Cursor id.
		int &nCurID
		);

	// Hit Test Control Handle Extend
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Handle Extend, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nIndex---nIndex, Specifies A integer value.
	virtual CFODrawShape* PickShapeHandleExtend(
		// Mouse hit point.
		CPoint ptHit, 
		// control  handle index.
		int& nIndex
		);

	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Pick Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void	DoPickShape(
		// Mouse hit flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);

	// Hit test port shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Pick Port Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.  
	//		nButton---nButton, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL	DoPickPortShape(
		// Mouse hit flags.
		UINT nFlags, 
		// Mouse hit point.
		CPoint point, UINT nButton = VK_LBUTTON);
public:
	// Do change running - time mode hit shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Hit Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoChangeHitShape(CFODrawShape *pShape);

protected:
	
	// Change select shape size.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Sizing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoShapeSizing(const CPoint &point,UINT nFlags);

	// Change select shape size.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Sizing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoXFormSizing(const CPoint &point,UINT nFlags);

	// Change select shapes mirror.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Mirror, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoShapeMirror(const CPoint &point,UINT nFlags);

	// Change select shapes Shear.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Shear, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoShapeShear(const CPoint &point,UINT nFlags);

	// Change select shapes distort.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Distort, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoShapeDistort(const CPoint &point,UINT nFlags);

	// Change select shapes Bend.
	// point -- point for bending
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Bend, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void DoShapeBend(const CPoint &point,UINT nFlags);

	// Create control shape window.
	// pCtlComp -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create  Window, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pCtlComp---Ctl Component, A pointer to the CFOWndControlShape or NULL if the call failed.
	virtual BOOL CreateCtrlWnd(CFOWndControlShape* pCtlComp);
	
	// Obtain the unused window control id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Free  I D, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nStartID---Start I D, Specifies A integer value.
	int GetFreeControlID(int nStartID = 100);

	// Destroy control shape window.
	// pCtlComp -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy  Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pCtlComp---Ctl Component, A pointer to the CFOWndControlShape or NULL if the call failed.
	virtual BOOL DestroyCtrlWnd(CFOWndControlShape* pCtlComp);

	// Create composite ctrl window.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Composite  Window, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void CreateCompositeCtrlWnd(CFODrawShape *pShape);

	// Destroy composite ctrl window.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destroy Composite  Window, Call this function to destroy an existing object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DestroyCompositeCtrlWnd(CFODrawShape *pShape);

	virtual void DoGenNameOfGroup(CFODrawShape *pShape);

public:

	// Tracking line.
	// listComp -- shapes for tracking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Tracking Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listComp---listComp, Specifies a const CFODrawShapeList& listComp object(Value).
	virtual void DoTrackingShapes(const CFODrawShapeList& listComp);

	// Shear a list of shapes
	// pShapeList -- list of shapes.
	// ptRef -- reference point to shear.
	// nAngle -- shear angle.
	// bVShear -- vertical shear or horizontal shear.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Shear Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		ptRef---ptRef, Specifies A integer value.  
	//		nAngle---nAngle, Specifies A 32-bit long signed integer.  
	//		bVShear---V Shear, Specifies A Boolean value.
	virtual void ShearShapes(CFODrawShapeList* pShapeList,const FOPPoint& ptRef, long nAngle, BOOL bVShear = FALSE);

	// Bend a list of shapes.
	// pShapeList -- list of shapes.
	// rRef -- reference point to Bend.
	// rRad -- radius of for Bending.
	// enum FOPBendMode 
	// {
	// 	FOP_BEND_ROTATE, // With rotating action when bending.
	// 	FOP_BEND_SLANT,  // With slanting action when bending
	// 	FOP_BEND_STRETCH // With stretch action when bending.
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bend Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		rRef---rRef, Specifies A integer value.  
	//		rRad---rRad, Specifies A integer value.  
	//		eMode---eMode, Specifies a FOPBendMode eMode object(Value).  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void BendShapes(CFODrawShapeList* pShapeList,const FOPPoint& rRef, const FOPPoint& rRad, 
		FOPBendMode eMode,BOOL bVertical);

	// Distort a list of shapes.
	// pShapeList -- list of shapes.
	// rcRef -- reference rectangle to shear.
	// aDistortedRect -- distort rectangle.
	// bNoContortion -- no contortion or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Distort Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		rcRef---rcRef, Specifies a const FOPRect& rcRef object(Value).  
	//		aDistortedRect---Distorted Rectangle, Specifies a const FOPSimplePolygon& aDistortedRect object(Value).  
	//		bNoContortion---No Contortion, Specifies A Boolean value.
	virtual void DistortShapes(CFODrawShapeList* pShapeList,const FOPRect& rcRef, 
		const FOPSimplePolygon& aDistortedRect, BOOL bNoContortion = FALSE);

	// Reverse the order of a list of shapes.
	// pShapeList -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reverse Order Of Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void ReverseOrderOfShapes(CFODrawShapeList* pShapeList);

	// Put the order of a list of shapes to bottom.
	// pShapeList -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes To Bottom, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void PutShapesToBottom(CFODrawShapeList* pShapeList);

	// Put the order of a list of shapes to top.
	// pShapeList -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes To Top, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void PutShapesToTop(CFODrawShapeList* pShapeList);

	// Move shape to top of one shape.
	// pShapeList -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shapes To Top, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void MoveShapesToTop(CFODrawShapeList* pShapeList);

	// Move the order of a list of shapes to bottom of one shape.
	// pShapeList -- list of shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Shapes To Bottom, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void MoveShapesToBottom(CFODrawShapeList* pShapeList);

	// Stop shear mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Stop Shear Mode, Call this function to stop

	void StopShearMode();

	// Does it sharing scrollbar with parent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Share Scroll, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShareScroll() const;

	// Find nearest grid point
	// p -- point to find
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Nearest Grid Point, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		&p---Specifies A CPoint type value.
	virtual CPoint FindNearestGridPoint(const CPoint &p);

public:

	// Moving select shapes.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeMoving(UINT nFlags, CPoint point);

	// Do starting text editing.
	void DoEditingText(const CPoint &pt, CFODrawShape *pShape);
	
protected:
	
	// Drop moving select shape.
	// point -- point for sizing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Drop Moving, Do something before any shape is dropped on the canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void DoShapeDropMoving(CPoint point);

	// Do something before drop shape.
	virtual CFODrawShape* DoBeforeDrop(const CPoint &pt, CFODrawShape *pShape);
	
	// Do something after drop shape.
	virtual void DoAfterDrop(const CPoint &pt, CFODrawShape *pShape);
	

protected:

	// Moving select shape's Anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's extend anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Extend Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeExtAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's third anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Third Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeThirdAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's four anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Four Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeFourAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's five anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Five Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeFiveAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's text anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Text Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeTextAnchorMoving(UINT nFlags, CPoint point);

protected:
	
	// Moving select shape's User Anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape User Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeUserAnchorMoving(UINT nFlags, CPoint point);

protected:
	
	// Moving visio like shape handle point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Microsoft Visio style Handle Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeVisioHandleMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's third anchor point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Center Anchor Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeCenterAnchorMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Handle Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeHandleMoving(UINT nFlags, CPoint point);

	// Moving select shape's point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Handle Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapePathMoving(UINT nFlags, CPoint point);

protected:

	// Moving select shape's point.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Center Handle Moving, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeCenterHandleMoving(UINT nFlags, CPoint point);

protected:

	// Rotating select shape.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Rotating, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoShapeRotating(UINT nFlags, CPoint point);

protected:

	// Form position changing.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Form Sizing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoFormSizing(UINT nFlags, CPoint point);

	// Do draw port.
	virtual BOOL DoTrackPort(CFOPortShape *pPortHit);

public:

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearTracking(CDC *pDC);


	// Do draw tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Microsoft Visio style Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearVisioTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Size Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearSizeTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Mirror Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearMirrorTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Rotate Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearRotateTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Moving Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearMovingTracking(CDC *pDC);

	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Drop Moving Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearDropMovingTracking(CDC *pDC);


	// Do clear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Center Rotate Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearCenterRotateTracking(CDC *pDC);

protected:

	// Do clear shear tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Shear Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearShearTracking(CDC *pDC);

	BOOL m_bOnPaste;
protected:

	// Do clear distort tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Distort Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearDistortTracking(CDC *pDC);

protected:

	// Do clear Bend tracking line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clear Bend Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoClearBendTracking(CDC *pDC);

protected:
	
	// Draw link line.
	// point -- point for sizing
	// nFlags -- mouse key flags
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Link Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoLinkShape(UINT nFlags, CPoint point);

	// Do something before link is created, call GetParentComp of CFOPortShape class to obtain the parent shape of port.
	// pFrom -- start link port shape pointer.
	// pTo -- end link port shape pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Link Created, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL DoBeforeLinkCreated(CFOPortShape *pFrom,CFOPortShape *pTo);

	//End link line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Link Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndLinkShape();


	// Start link shape, override this method to do something before creating link
	// pPort -- starting link port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Link Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL DoStartLinkEvent(CFOPortShape *pPort);

	// End link shape,override this method to do something after creating link.
	// pLink -- pointer of the link shape.
	// pPort -- ending link port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Link Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLink---*pLink, A pointer to the CFOLinkShape  or NULL if the call failed.  
	//		*pPort---*pPort, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual void DoEndLinkEvent(CFOLinkShape *pLink,CFOPortShape *pPort);


	// Generate the default hole link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Hole Link Shape, Do a event. 
	//		Returns a pointer to the object CFOLinkShape ,or NULL if the call failed
	CFOLinkShape *DoGenHoleLinkShape();

	// Init link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Link Shape, Call InitLinkShape after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void InitLinkShape();

	// Relayout points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Simple Layout, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&m_Points---&m_Points, Specifies A CPoint type value.
	virtual BOOL TrackSimpleLayout(CArray<CPoint,CPoint> &m_Points);

	// Relayout UpRight state points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Make Up Right, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&m_Points---&m_Points, Specifies A CPoint type value.
	virtual BOOL TrackMakeUpRight(CArray<CPoint,CPoint> &m_Points);

	// Start move shapes event,override this method to do something before moving shapes
	// pShapeList -- list of the shapes for moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Move Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoStartMoveEvent(CFODrawShapeList* pShapeList);

	// End move shapes event,override this method to do something after moving shapes
	// pShapeList -- list of the shapes for moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Move Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoEndMoveEvent(CFODrawShapeList* pShapeList);


	// Start size shapes event,override this method to do something before resizing shapes.
	// pShapeList -- list of the shapes for sizing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Size Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoStartSizeEvent(CFODrawShapeList* pShapeList);

	// End size shapes event,override this method to do something after resizing shapes.
	// pShapeList -- list of the shapes for resizing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Size Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoEndSizeEvent(CFODrawShapeList* pShapeList);


	// Start  size form event,this method only working for form mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Form Size Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoStartFormSizeEvent(CFODrawShapeList* pShapeList);


	// End  size form event,this method only working for form mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Form Size Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoEndFormSizeEvent(CFODrawShapeList* pShapeList);

	// Do show cursor.
	BOOL DoShowCursor(const CPoint &ptLog, UINT nFlags);


	// Start Rotate shapes event,override this method to do something before rotating shapes.
	// pShapeList -- list of the shapes for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Rotate Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoStartRotateEvent(CFODrawShapeList* pShapeList);

	// End Rotate shapes event,override this method to do something after rotating shapes.
	// pShapeList -- list of the shapes for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Rotate Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual void DoEndRotateEvent(CFODrawShapeList* pShapeList);

	// Do close screen event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Close Screen Event, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pHitShape---Hit Shape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoCloseScreenEvent(CFODrawShape *pHitShape);


protected:
	/*************************************************************************
	|*
	|* Control the label of the composite shape.
	|*
	\************************************************************************/

	// When you double click on the composite shape,it will add a label on the composite shape.
	// With this method,you can do something before showing this label.
	// pLabel -- pointer of the label.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Show Label, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLabel---*pLabel, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoInitShowLabel(CFODrawShape *pLabel);

	// Init the label position,override this method to re calculate the label position within the composite shape.
	// rcPos -- result position.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		*pShape---*pShape, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void CalcLabelPosition(CRect &rcPos,CFOCompositeShape *pShape);

public:

	// Show page setting dialog.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Page Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoShowPagePropDlg();

	// Show shape bullet setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Bullet Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowBulletPropDlg(CFODrawShape *pShape);

	// Show shape line setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Line Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowLinePropDlg(CFODrawShape *pShape);

	// Show shape Text setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Text Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowTextPropDlg(CFODrawShape *pShape);

	// Show shape Fill setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Fill Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowFillPropDlg(CFODrawShape *pShape);

	// Show shape Event setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Event Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowEventPropDlg(CFODrawShape *pShape);

	// Show shape protect setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Protect Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowProtectPropDlg(CFODrawShape *pShape);

	// Show shape Shadow setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Shadow Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowShadowPropDlg(CFODrawShape *pShape);

	// Show shape Custom setting dialog.
	// pShape -- pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Custom Property Dialog, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoShowCustomPropDlg(CFODrawShape *pShape);

	// Do show children screen window.
	// strXdgFile -- xdg file for showing.
	// strCaption -- caption of this window.
	// szWindow -- size of window
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Child Screen Window, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strXdgFile---Xdg File File, Specifies A CString type value.  
	//		&strCaption---&strCaption, Specifies A CString type value.  
	//		&szWindow---&szWindow, Specifies A CSize type value.
	virtual void DoShowChildScreenWindow(const CString &strXdgFile, const CString &strCaption, const CSize &szWindow);

public:
	/*************************************************************************
	|*
	|* Advanced operators for controling shapes.
	|*
	\************************************************************************/
	
	// Do convert shape to path or polygon.
	// bPath -- if you want to convert shapes to path shape,it is true,else if you want to convert it to
	//          polygon,it is false.
	// m_listNew -- shapes that converted to.
	// m_listConvert -- shapes that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Shapes To, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bPath---bPath, Specifies A Boolean value.  
	//		&m_listNew---&m_listNew, Specifies a E-XD++ CFODrawShapeList &m_listNew object (Value).  
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).
	virtual void DoConvertShapesTo(BOOL bPath,CFODrawShapeList &m_listNew,const CFODrawShapeList &m_listConvert);

	// Do convert shape to path or polygon,this is defined for free form drawing only
	// m_listNew -- shapes that converted to.
	// m_listConvert -- shapes that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert Shapes For Connect, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listNew---&m_listNew, Specifies a E-XD++ CFODrawShapeList &m_listNew object (Value).  
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).
	virtual void DoConvertShapesForConnect(CFODrawShapeList &m_listNew,const CFODrawShapeList &m_listConvert);

	// Convert select shapes to path shape.
	// m_listConvert -- shapes that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Shapes To Path Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).
	virtual void ConvertShapesToPathShape(const CFODrawShapeList &m_listConvert);

	// Convert select shapes to path shape,this path shape will be used to connect a new line,arc line,etc.
	// m_listConvert -- shapes that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Shapes For Connect, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).
	virtual void ConvertShapesForConnect(const CFODrawShapeList &m_listConvert);

	// Convert select shapes to polygon shape.
	// m_listConvert -- shapes that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Shapes To Polygon Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).
	virtual void ConvertShapesToPolyShape(const CFODrawShapeList &m_listConvert);

	// Combine shapes to a single path shape.
	// m_listConvert -- shapes that to be converted.
	// bNoPoly -- ? COMBINE_ONEPOLY : COMBINE_POLYPOLY
	
	//-----------------------------------------------------------------------
	// Summary:
	// Combine Shapes To, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).  
	//		bNoPoly---No Polygon, Specifies A Boolean value.
	virtual BOOL CombineShapesTo(const CFODrawShapeList &m_listConvert,BOOL bNoPoly = FALSE);

	// Merge shapes to a single path or polygon shape.
	// m_listConvert -- shapes that to be converted,it must be one of the following value:
	// enum FOP_MERGE_MODE
	// {
	// 	FOP_MERGE,
	// 	FOP_SUBSTRACT,
	// 	FOP_INTERSECT
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Merge Shapes To, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).  
	//		nMode---nMode, Specifies a FOP_MERGE_MODE nMode object(Value).
	virtual void MergeShapesTo(const CFODrawShapeList &m_listConvert,FOP_MERGE_MODE nMode);

	// Be a specify shape can be dismantle or not.
	// aCompositePoly -- polygons that to be dismantle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Shape Can Dismantle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCompositePoly---Composite Polygon, Specifies a const FOPSimpleCompositePolygon& aCompositePoly object(Value).  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual BOOL BeShapeCanDismantle(const FOPSimpleCompositePolygon& aCompositePoly, BOOL bCreateLines) const;

	// Be a specify shape can be dismantle or not.
	// pObj-- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Be Shape Can Dismantle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pObj---pObj, A pointer to the const CFODrawShape or NULL if the call failed.  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual BOOL BeShapeCanDismantle(const CFODrawShape* pObj, BOOL bCreateLines) const;

	// Dismantle one shape to multiple shapes.
	// pObj-- pointer of the shape.
	// lstNew -- the list of shapes that be dismantled.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dismantle One Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pObj---pObj, A pointer to the const CFODrawShape or NULL if the call failed.  
	//		lstNew---lstNew, Specifies a E-XD++ CFODrawShapeList& lstNew object (Value).  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual void DismantleOneShape(const CFODrawShape* pObj, CFODrawShapeList& lstNew, BOOL bCreateLines);

	// Dismantle a group of shapes.
	// m_listConvert -- shapes that to be dismantled.
	// bCreateLines -- create lines or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dismantle Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_listConvert---&m_listConvert, Specifies a const CFODrawShapeList &m_listConvert object(Value).  
	//		bCreateLines---Create Lines, Specifies A Boolean value.
	virtual void DismantleShapes(const CFODrawShapeList &m_listConvert,BOOL bCreateLines = FALSE);

	// Is current shape can be connected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Current Shape Can Be Connect, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL IsCurrentShapeCanBeConnect(CFODrawShape *pShape);

	// Close selection shape.
	// pShape -- pointer of the path shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL CloseShape(CFODrawShape *pShape);

	// Do insert point to the path shape.
	// pShape -- pointer of the path shape.
	// nIdx -- index of the handle to insert after.
	// ptPnt -- point to be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Ins Object Point, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIdx---nIdx, Specifies A integer value.  
	//		ptPnt---ptPnt, Specifies A integer value.
	BOOL BegInsObjPoint(CFODrawShape *pShape,int nIdx, const FOPPoint& ptPnt);

	// Do Delete point to the path shape.
	// pShape -- pointer of the path shape.
	// nIdx -- index of the handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Beg Delete Object Point, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nIdx---nIdx, Specifies A integer value.
	BOOL BegDeleteObjPoint(CFODrawShape *pShape,int nIdx);

	// Change marked points to smooth flag.
	// pShape -- path shape pointer.
	// arySaveLine -- control handle.
	// eFlag -- smooth flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Marked Points Smooth, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		<int---Specifies A CArray array.  
	//		&arySaveLine---Save Line, Specifies A integer value.  
	//		&eFlag---&eFlag, Specifies a const FOPSimplePolyFlags &eFlag object(Value).
	virtual void ChangeMarkedPointsSmooth(CFODrawShape *pShape,const CArray <int, int> &arySaveLine,const FOPSimplePolyFlags &eFlag);

	// Change marked segments kind.
	// nCtrlHandle -- segments index.
	// nType -- segment kind,it should be one of the following value:
	// 	enum fopPathType
	// {
	// 	FOP_PATH_NONE,
	// 	FOP_PATH_LINE,
	// 	FOP_PATH_CURVE
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Marked Segments Kind, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nCtrlHandle---Handle, Specifies A integer value.  
	//		&nType---&nType, Specifies a const fopPathType &nType object(Value).
	virtual void ChangeMarkedSegmentsKind(const int &nCtrlHandle,const fopPathType &nType);

	// Rip up point
	// nCtrlHandle -- handle of the point that to be ripuped.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rip Up At Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nCtrlHandle---Handle, Specifies A integer value.
	virtual void RipUpAtPoints(const int &nCtrlHandle);

	// Change marked point's smooth.
	// nFlag -- flags that should be changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Smooth Flag, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nFlag---&nFlag, Specifies a const fopPathSmoothType &nFlag object(Value).
	virtual void SetSmoothFlag(const fopPathSmoothType &nFlag);

	// Obtain the smooth flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Smooth Flag, Returns the specified value.
	//		Returns A fopPathSmoothType value (Object).
	fopPathSmoothType GetSmoothFlag() const;

protected:

	// Move port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move Shape Port, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void DoMoveShapePort(UINT nFlags, CPoint point);

protected:

	// Do zoom with rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Zoom Rectangle, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rectZoom---rectZoom, Specifies A CRect type value.
	virtual void DoZoomRect(CRect rectZoom);

	// Obtain end zooming value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Zoom Value, Returns the specified value.
	// Parameters:
	//		&rectZoom---&rectZoom, Specifies A CRect type value.  
	//		&dX---&dX, Specifies a double &dX object(Value).  
	//		&dY---&dY, Specifies a double &dY object(Value).
	void GetEndZoomValue(const CRect &rectZoom, double &dX, double &dY);

protected:

	// Do zoom with rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle L Button Down, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void HandleLButtonDown(CFODrawShape *pShape,UINT nFlags, CPoint point);

	// Hit inside edit box..
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Correct Shape, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&point---Specifies A CPoint type value.
	virtual CFODrawShape* HitCorrectShape(CFODrawShape *pShape, UINT nFlags, const CPoint &point);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Event With Click, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void HitEventWithClick(CFODrawShape *pShape, const CPoint &ptHit, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down Hit Design, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDownHitDesign(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk Hit Design, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDblClkHitDesign(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Down Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDownHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Up Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonUpHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do L Button Double click Clk Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoLButtonDblClkHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Down Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoRButtonDownHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);


	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Up Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoRButtonUpHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);


	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do R Button Double click Clk Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoRButtonDblClkHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);


	// Doing something with hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do M Button Down Hit Run Time, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&ptHitLog---Hit Logical, Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL DoMButtonDownHitRunTime(CFODrawShape *pShape, const CPoint &ptHitLog, UINT nFlags);

protected:

	// Drawing.
	// Draw Track Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackLine(CPoint point);

	// Draw Track Dimension Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Dimension Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackDimLine(CPoint point);

	// Draw Track Caption Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Cap Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackCapLine(CPoint point);

	// Draw Track Arc Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Arc Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackArcLine(CPoint point);

	// Draw Track Pie
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Arc2, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackArc2(CPoint point);

	// Draw Track Pie
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Pie, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackPie(CPoint point);

	// Draw Track Chord
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Chord, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackChord(CPoint point);

	// Draw Bezier Track Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Bezier Track Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawBezierTrackLine(CPoint point);

	// Draw Track PolyLine
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Polygon Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackPolyLine(CPoint point);

	// Draw Track PolyLine
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Polygon Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackPolyLineExt(CPoint point);

	// Draw Track Hot spot
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Link Hotspot, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnDrawTrackLinkHotspot(CFOPortShape *pCurPort, CPoint point,const UINT &nShapeType);

	// Draw Track Hot spot
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Link Hotspot, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnDrawTrackHotspot(CPoint point,const UINT &nShapeType);

	// Draw Track Hot spot
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Link Hotspot, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnDrawLinkHotspot(CFODrawShape *pShape,const UINT &nShapeType);

	// Draw Track Glue spot
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Gluespot, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.
	virtual void OnDrawTrackGluespot(const CPoint &point);

	// Draw Track Glue spot
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Glue Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies a const FOPRect &rc object(Value).
	virtual void OnDrawTrackGlueRect(const FOPRect &rc);

	// Draw Track LinkLine
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Link Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&nShapeType---Shape Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnDrawTrackLinkLine(CPoint point,const UINT &nShapeType);

	// Draw Track Polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Polygon, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackPolygon(CPoint point);

	// Draw Track Polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Polygon, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackPolygonExt(CPoint point);

	// Draw Track Bezier
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackBezier(CPoint point);

	// Draw Track Close Bezier
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Close Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackCloseBezier(CPoint point);

	// Draw Track Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackRect(CPoint point);

	// Draw Track Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Only Drop, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackOnlyDrop(CPoint point);

	// Draw Track Round Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Round Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackRoundRect(CPoint point);

	// Draw Track Ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Ellipse, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackEllipse(CPoint point);

	// Draw Track Form
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Form, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackForm(CPoint point);

	// Draw Track Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Select, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackSelect(CPoint point);

	// Draw Track Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Table, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackTable(CPoint point);

	// Draw Drag Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Drag Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		rc---Specifies A CRect type value.  
	//		width---Specifies A integer value.  
	//		size---Specifies A CSize type value.
	virtual void OnDrawDragRectangle(CDC *pDC,CRect rc,int width,CSize size);

	// Draw Track Help Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Horizontal Help Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackHorzHelpLine(CPoint point);

	// Draw Track Table Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Horizontal Table Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackHorzTableLine(CPoint point);

	// Draw Track Help Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Vertical Help Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackVertHelpLine(CPoint point);

	// Draw Track Table Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Vertical table Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawTrackVertTableLine(CPoint point);

	// Draw Move Track Help Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Move Horizontal Track Help Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawMoveHorzTrackHelpLine(CPoint point);

	// Draw Move Track Help Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Move Vertical Track Help Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawMoveVertTrackHelpLine(CPoint point);

	// Draw Move Track snap point
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Move Snap Point, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void OnDrawMoveSnapPoint(CPoint point);

	// Do draw tracking polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Simple Polygon Trackline, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPolygons---aPolygons, Specifies a FOPSimpleCompositePolygon aPolygons object(Value).
	virtual void OnDrawSimplePolygonTrackline(FOPSimpleCompositePolygon aPolygons);

	// End Tracking
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do End Tracking, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoEndTracking();

	// Obtain the drag polygons.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Take Drag Polygons, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&aPolygons---&aPolygons, Specifies a FOPSimpleCompositePolygon &aPolygons object(Value).
	virtual void TakeDragPolygons(FOPSimpleCompositePolygon &aPolygons);

public:
	// Draw from total.
	// Draw shapes to double buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Buffer Objects, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoDrawBufferObjects();

	// Draw shapes to double buffer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Buffer Objects Only For Invalid, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcUpdate---&rcUpdate, Specifies a FOPRect &rcUpdate object(Value).
	virtual void DoDrawBufferObjectsOnlyForInvalid(FOPRect &rcUpdate);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	// Draw full view.
	virtual void Draw(CDC* pDC);

	// Draw  Shapes Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Select Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void DoDrawSelectShapes(CDC *pDC,const CRect &rcView);

	// Draw  Shapes high light Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw High Light Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void DoDrawHighLightShapes(CDC *pDC,const CRect &rcView);

	// Draw  multiple Shapes Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Single Select Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.  
	//		*pObjTemp---Object Temp, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoDrawSingleSelectShapes(CDC *pDC,const CRect &rcView, CFODrawShape *pObjTemp);

	// Draw path mark,
	virtual void DoDrawPathMark(CDC* pDC);

	// Do check hit on path mark.
	virtual BOOL DoHitPathMark(const CPoint &ptHit, int &nHitHandle);

	// Draw  multiple Shapes Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Multiple Select Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void DoDrawMultiSelectShapes(CDC *pDC,const CRect &rcView);

	// Draw  multiple Shapes bounding order line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Multiple Shapes Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void DoDrawMultiShapesOrderLine(CDC *pDC, CFODrawShapeList *pList, const CRect &rcView);

	// Do Draw Shape bounding order line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Shape Order Line, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pObjTemp---Object Temp, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoDrawShapeOrderLine(CDC *pDC,CFODrawShape *pObjTemp);

	// Draw page back.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Page Back, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rc---Specifies A CRect type value.
	virtual void DoDrawPageBack(CDC *pDC,const CRect &rc);

	// Draw BackGround
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Back Ground, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.
	virtual void DoDrawBackGround(CDC *pDC,CRect &rect);

	// Draw Shapes To Image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Shapes To Image, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void DoDrawShapesToImage(CDC *pDC);

	// Draw Image
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Image, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pImage---pImage, A pointer to the CFOBitmap or NULL if the call failed.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual BOOL DoDrawImage(CFOBitmap* pImage, CDC* pDC = NULL);

	// Draw shapes to a device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw View Objects, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDrawViewObjects(CDC* pDC);

	// Draw shapes to a device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw View Objects For Invalid, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&rcUpdate---&rcUpdate, Specifies A CRect type value.
	virtual void DoDrawViewObjectsForInvalid(CDC* pDC,const CRect &rcUpdate);

	// Draw shapes to printer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Print Objects, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPrintPage---Print Page, Specifies A CRect type value.
	virtual void DoDrawPrintObjects(CDC *pDC,const CRect &rcPrintPage);

	// Prepare print header and footer dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Print Header Footer D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void PreparePrintHeaderFooterDC(CDC *pDC);

	// Draw print header and footer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Print Header And Footer, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void DoDrawPrintHeaderAndFooter(CDC* pDC, CPrintInfo* pInfo);

	// Clear print header and footer dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Print Header Footer D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void ClearPrintHeaderFooterDC(CDC *pDC);

	// Create group shape,override this method to do something before drop toolbox shape to the canvas.
	// pShape -- pointer of the composite shape.
	// nType -- type of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Composite Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		nType---nType, Specifies A integer value.
	virtual void DoInitCompositeShape(CFOCompositeShape *pShape,int nType);

	// Do split composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Split Composite Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOCompositeShape  or NULL if the call failed.
	virtual void DoSplitCompositeShape(CFODrawShapeList *pList,CFODrawShapeList *pPortsList, CFOCompositeShape *pShape);

	// Prepare track line dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Track Line D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void PrepareTrackLineDC(CDC *pDC);

	// Clear track line dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Track Line D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void ClearTrackLineDC(CDC *pDC);

	// Prepare track line dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Track Table D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void PrepareTrackTableDC(CDC *pDC);

	// Clear track line dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Track Table D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void ClearTrackTableDC(CDC *pDC);

	// Do draw ruler mouse pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ruler Mouse Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&point---Specifies A CPoint type value.
	virtual void DoDrawRulerMousePos(const CPoint &point);

	// Do draw ruler tracking rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Ruler Tracking Rectangle, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rect---Specifies A CRect type value.
	virtual void DoDrawRulerTrackingRect(const CRect &rect);

	// Do update ruler.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Ruler, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoUpdateRuler();

	// run ole item script.
	virtual void RunOleScript(CFODrawShape *pShape, const CString &strCode);


public:

	// Obtain find replace state.
	virtual CFOPFindRepData* GetFindDlgData() const;
	
	// Check if it needs find for replace or not
	virtual BOOL NeedFindForReplace(CFOPFindRepData* pState);
	
	// Show modal find mode.
	BOOL m_bModalDlg;

	// Current search index.
	int m_nCurSearchIndex;
	
	// Get single line selection
	virtual CString GetSelText(int nPropID);
	
	// Find text
	virtual int FindText(int nCurIndex,CFODrawShapeList *pFindList,
		LPCTSTR lpszText,
		int nPropID,
		BOOL bDown,
		BOOL bWrapFind,
		BOOL bMatchCase,
		BOOL bMatchFull,
		BOOL bRegExp);

	// Find in shape
	virtual BOOL xfoFindInShape(CFODrawShape *pCurrent, CFOPRegExp *regexp, CFODrawShapeList *pFindList, 
					CFOPFindRepData* pState);

	// Find in shape
	virtual BOOL xfoFindInShape2(CFODrawShape *pCurrent, CFOPRegExp *regexp, CFODrawShapeList *pFindList,
		LPCTSTR lpszText,
		int nPropID,
		BOOL bDown,
		BOOL bWrapFind,
		BOOL bMatchCase,
		BOOL bMatchFull,
			BOOL bRegExp);
	
	// Find next word
	void FindNextFull();
	
	
	// Find next
	void FindNext();
	
	// Find previous word
	void FindPrevFull();
	
	// Find previous
	void FindPrev();
	
	// find next
	virtual BOOL OnFindNext(CFOPFindRepData* pState);
	
	// mark all
	virtual BOOL OnFindAll(CFOPFindRepData* pState);
	
	// Replace all
	virtual BOOL OnReplaceAll(CFOPFindRepData* pState);
	
	// Replace current.
	virtual BOOL OnReplaceOne(CFOPFindRepData* pState);
	
	// Replace notify
	virtual BOOL FindReplaceEvent(CFOPFindReplaceDlg* pDlg);
	
	// Show find replace dlg.
	virtual void DoFindReplace(BOOL bFindOnly);

public:
	
	// Cursor.
	//Get Shape Handle Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Handle Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickShapeHandleCursor(UINT nFlags, CPoint point);

	// Cursor.
	//Get Shape Handle Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Single Shape Handle Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickSingleShapeHandleCursor(CFODrawShape *pShape, UINT nFlags, CPoint point);

	//Get Shape Handle Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Multiple Shape Handle Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickMultiShapeHandleCursor(UINT nFlags, CPoint point);

	// Get Form Handle Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Form Handle Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickFormHandleCursor(UINT nFlags, CPoint point);

	// Get component Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickShapeCursor(UINT nFlags, CPoint point);

	// Get component Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Shape Spot Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickShapeSpotCursor(CFODrawShape *pShape, UINT nFlags, CPoint point);

	// Get Cursor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void PickCursor(UINT nFlags, CPoint point);
	
	// Set cursor with ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID)---I D), Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void FOSetCursor(UINT nID) = 0;

	// Set current drawing cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Drawing Cursor, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetCurrentDrawingCursor(const UINT& nID);

	// Set system cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set System Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszCursor)---lpszCursor), Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void FOSetSystemCursor(LPCTSTR lpszCursor) = 0;

	// Do showing cursor with shape dropping.
	// ptHit -- hit testing point, logic point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Show Cursor With Drop, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual void DoShowCursorWithDrop(const CPoint &ptHit);

public:

	// Obtain the true client rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get True Client Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void GetTrueClientRectangle(CRect &rc);

	// Invalidate a specify shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Shape, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pObj---pObj, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void InvalidateShape(CFODrawShape* pObj);

	// Invalidate a specify rectangle.
	// rc -- logic rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle Extend, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rc---Specifies A CRect type logic value.
	virtual void InvalidateRectExtend(CRect rc);

	// Invalidate rectangle with handle.
	// rcOld -- logic rectangle.
	// rcNew -- logic rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle With Handle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcOld---&rcOld, Specifies A CRect type value.  
	//		&rcNew---&rcNew, Specifies A CRect type value.
	virtual void InvalRectWithHandle(CRect &rcOld,CRect &rcNew);
	
	// Invalidate total window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Invalidate, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bErase---bErase, Specifies A Boolean value.  
	//		bRedrawNow---Redraw Now, Specifies A Boolean value.  
	//		&bUpdateInview---Update Inview, Specifies A Boolean value.
	virtual void FOPInvalidate(BOOL bErase = TRUE, BOOL bRedrawNow = FALSE, const BOOL &bUpdateInview = TRUE);

	// Invalidate a specify rectangle.
	// You must call DocToClient to convert rcPos at first.
	// rcPos -- DP value of rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Invalidate Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		bErase---bErase, Specifies A Boolean value.  
	//		bRedrawNow---Redraw Now, Specifies A Boolean value.
	virtual void FOPInvalidateRect(const CRect& rcPos, BOOL bErase = TRUE, BOOL bRedrawNow = FALSE);

	// Correct rect position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Standard Rectangle, .
	// This member function is a static function.
	// Parameters:
	//		rect---Specifies A CRect type value.
	static void	 StandardRect(CRect& rect);

	// Combine rect1 and rect2 to a single rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Combine Rectangle, .
	// This member function is a static function.
	//		Returns a CRect type value.  
	// Parameters:
	//		rect1---Specifies A CRect type value.  
	//		rect2---Specifies A CRect type value.
	static CRect CombineRect(CRect rect1, CRect rect2);

	// Is point validate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Point Validate, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		listShapes---listShapes, Specifies a E-XD++ CFODrawShapeList& listShapes object (Value).  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL IsPointValidate(CFODrawShapeList& listShapes, CPoint ptOffset);

	// Adjust clip rectangle of print preview.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Clipboard Rectangle Of Print Preview, .
	// Parameters:
	//		rDC---D C, Specifies a CDC & rDC object(Value).  
	//		&rcClip---&rcClip, Specifies A CRect type value.
	void AdjustClipRectOfPrintPreview(CDC & rDC,CRect &rcClip);

protected:

	// Get require points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Draw Shape Track Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptStartPoints---Start Points, Specifies A LPPOINT Points array.  
	//		pptEndPoints---End Points, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual BOOL LimitDrawShapeTrackPoint(LPPOINT pptStartPoints, LPPOINT pptEndPoints, int nCount);

	// Get require points for scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Shape Resize Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptStartPoints---Start Points, Specifies A LPPOINT Points array.  
	//		pptEndPoints---End Points, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual BOOL LimitShapeResizePoint(LPPOINT pptStartPoints, LPPOINT pptEndPoints, int nCount);

	// Get require points for move.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Shape Move Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptStartPoints---Start Points, Specifies A LPPOINT Points array.  
	//		pptEndPoints---End Points, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual BOOL LimitShapeMovePoint(LPPOINT pptStartPoints, LPPOINT pptEndPoints, int nCount);

	// Get require points for form.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit Form Size Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptStartPoints---Start Points, Specifies A LPPOINT Points array.  
	//		pptEndPoints---End Points, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual BOOL LimitFormSizePoint(LPPOINT pptStartPoints, LPPOINT pptEndPoints, int nCount);

	// Offset points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Same Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ppts---Specifies A LPPOINT Points array.
	virtual void OffsetSamePoint(LPPOINT ppts);

	// Is rect include another rect?.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rectangle Within, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcSmall---rcSmall, Specifies A CRect type value.  
	//		rcLarge---rcLarge, Specifies A CRect type value.
	static BOOL  IsRectWithin(CRect rcSmall, CRect rcLarge);
	
	// Convert point to Inches
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Point To Inche, .
	//		Returns A double value (Object).  
	// Parameters:
	//		nPoint---nPoint, Specifies A integer value.  
	//		bHeight---bHeight, Specifies A Boolean value.
	double ConvertPointToInche(int nPoint, BOOL bHeight);

	// Convert inches to point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Convert Inches To Point, .
	//		Returns a int type value.  
	// Parameters:
	//		dInche---dInche, Specifies a double dInche object(Value).  
	//		bHeight---bHeight, Specifies A Boolean value.
	int ConvertInchesToPoint(double dInche, BOOL bHeight);

public:

	// Lock update
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Update, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bLock---bLock, Specifies A Boolean value.
	BOOL LockUpdate(BOOL bLock = TRUE);

	// Is lock update or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock Update, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsLockUpdate();

	// Flash a list of shapes with times.
	// lstShapes -- list of shapes to be flashed.
	// nTimes -- flash times.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flash Shapes, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstShapes---lstShapes, Specifies a const CFODrawShapeList& lstShapes object(Value).  
	//		nTimes---nTimes, Specifies A integer value.
	virtual void FlashShapes(const CFODrawShapeList& lstShapes, int nTimes);

	// Flash a list of shapes with times and color.
	// lstShapes -- list of shapes to be flashed.
	// nTimes -- flash times.
	// crColor -- flash color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flash Shapes With Color, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&lstShapes---&lstShapes, Specifies a const CFODrawShapeList &lstShapes object(Value).  
	//		nTimes---nTimes, Specifies A integer value.  
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual void FlashShapesWithColor(const CFODrawShapeList &lstShapes, int nTimes, COLORREF crColor);

	// End action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Finish Action, Do a event. 

	void DoFinishAction();

	// Create context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu* CreateContextMenu();

	// Create polygon editing context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Polygon Context Menu, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu* CreatePolyContextMenu();

	// Create ruler context menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ruler Menu, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu* CreateRulerMenu();

	// Do expand or collect shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Expand Or Collect Shape, Do a event. 
	// Parameters:
	//		*pSub---*pSub, A pointer to the CFOPSubGraphShape  or NULL if the call failed.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void DoExpandOrCollectShape(CFOPSubGraphShape *pSub,UINT nFlags);

	// New graph shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make New Child Graph, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	virtual CFOPSubGraphShape *MakeNewSubGraph();

public:
	// Add new handle item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add New Additional Handle, Adds an object to the specify list.
	// Parameters:
	//		*pNew---*pNew, A pointer to the CFOPSelectHandleItem  or NULL if the call failed.
	void AddNewAdditionalHandle(CFOPSelectHandleItem *pNew);

	// Clear all additional handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Additional Handle, Remove the specify data from the list.

	void ClearAllAdditionalHandle();

	// Do drawing the additional items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Additional Items, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.
	virtual void DoDrawAdditionalItems(CDC *pDC,const CPoint &ptStart);

	// Do drawing the additional items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw D B Name, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&strDBName---D B Name, Specifies A CString type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.
	virtual void DoDrawDBName(CDC *pDC,const CString &strDBName, const CPoint &ptStart);

	// Pick additional items cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Additional Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickAddiCursor(UINT nFlags, CPoint point);

	// Pick additional events.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Additional Event, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual BOOL PickAddiEvent(UINT nFlags, CPoint point);

	// Do something when click on the items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do When Click Additional, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWhenClickAddi();

	// Do generate the init additional items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Generate Initial Items, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void DoGenInitItems(CFODrawShape *pShape);

	// Show other popup menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Component Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual void ShowCompPopup( CPoint point, CFOPCanvasCore* parent );

	// Obtain the pointer of menu parent window.
	// parent -- pointer of window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Parent Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd ,or NULL if the call failed  
	// Parameters:
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual CWnd * GetMenuParentWnd(CFOPCanvasCore* parent);

public:

	// Start create custom shape with specify resource ID action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Custom Shape I D, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nResID---Resource I D, Specifies A integer value.
	virtual void StartCustomShapeID(
		// Specifies resource ID.
		int nResID
		);

	// Start create custom shape with specify resource file name action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Custom Shape File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual void StartCustomShapeFile(
		// Specifies resource file name
		CString strFile
		);

	// Add port.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Port, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dScaleX---Scale X, Specifies a double dScaleX object(Value).  
	//		dScaleY---Scale Y, Specifies a double dScaleY object(Value).
	virtual void AddShapePort(
		// Specifies x scale value range from 0.0 to 1.0
		double dScaleX,
		// Specifies y scale value range from 0.0 to 1.0
		double dScaleY
		);

public:

	// Get ole data object
	// pData -- pointer of the ole data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ole Data Object, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		pData---pData, A pointer to the COleDataObject or NULL if the call failed.
	virtual CFODrawShape *GetOleDataObject(COleDataObject* pData);

	// Save data to clipboard.
	// pShapeList -- list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Serialize Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void DoSerializeData(CFODrawShapeSet* pShapeList);

	// Do load data.
	virtual void DoSerializeLoadData(COleDataObject &dataObject, CFODrawShapeList* pShapeList, CFODataModelList *pModelList);

	// Rebuild all data model's property indexes
	virtual void RebuildAllPropIndex(CFODataModelList *pModelList);

	// Do something with models.
	virtual void DoWithModels(CFODataModelList *pModelList);

	// Add paste shapes to canvas.
	virtual void AddPasteToModel(CFODrawShapeList* pShapeList, CFODataModelList *pModelList);

	// Save data to clipboard.
	// pShapeList -- list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Serialize Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void DoSerializeComplexData(CFODrawShapeSet* pShapeList, CFODataModelList *pModelList, CLIPFORMAT &foFormat);

	// For loading data.
	virtual void DoLoadComplexData(CFODrawShapeList *pList, CFODataModelList *pModelList, CLIPFORMAT &foFormat);

	// For specify data.
	virtual void DoSerializeSpecData(CFODrawShape *pCopyShape, CFODataModel *pCopyModel, CLIPFORMAT &foFormat);

	// For loading data.
	virtual CFODataModel *DoLoadSpecData(CFODrawShapeList *pList, CFODataModel *pInModel, CLIPFORMAT &foFormat);

	// Save data to clipboard.
	// pShapeList -- list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Serialize Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void DoSerializeTableData(CFOPTableCellList* pCellsList);

	// Save data to clipboard.
	// pShapeList -- list of shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Serialize Data, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeSet or NULL if the call failed.
	virtual void DoSerializeTableDataNew(CFOPNewTableCellList* pCellsList, FOXNewTableShape* pTable);

	// Do serialize data to clipboard's bitmap buffer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clipboard Board Bitmap, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a E-XD++ CFODrawShapeList & list object (Value).  
	//		inflateX---inflateX, Specifies A integer value.  
	//		inflateY---inflateY, Specifies A integer value.
	virtual void DoClipBoardBitmap(CFODrawShapeList & list, int inflateX = 2, int inflateY = 2);

	// Is exchange format supported.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Exchange Format Supported, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFormat---nFormat, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL  IsExchangeFormatSupported(UINT nFormat) const;

public:

	// Load or save select shapes.
	// Save selected shapes to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Select Shapes, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&listSave---&listSave, Specifies a E-XD++ CFODrawShapeSet &listSave object (Value).
	virtual BOOL DoSaveSelectShapes(
		// Specify file name.
		const CString &strFile,
		// List of shapes.
		CFODrawShapeSet &listSave);

	// Load or save select shapes.
	// Save selected shapes to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Xdg File Data, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&listSave---&listSave, Specifies a E-XD++ CFODrawShapeSet &listSave object (Value).
	virtual BOOL DoSaveXdgData(
		// Specify file name.
		const CString &strFile,
		// List of shapes.
		CFODrawShapeSet &listSave);

	// Load comp from file.
	// lpszResName -- resource name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Xdg File From File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	virtual BOOL LoadXdgFromFile(LPCTSTR lpszResName,BOOL bAdd = FALSE);

	// Load comp from resource.
	// nID -- Resource id.
	// lpszType -- resource type name,must the same as the resource ID's resource type name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Xdg File From Resource, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	virtual BOOL LoadXdgFromResource(UINT nID, LPCTSTR lpszType = _T("XdgRes"),BOOL bAdd = FALSE);

	// Load shapes from file add insert it to current model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Load Xdg File Data, Loads the specify data from a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&listLoad---&listLoad, Specifies a E-XD++ CFODrawShapeSet &listLoad object (Value).  
	//		&bRuler---&bRuler, Specifies A Boolean value.
	virtual BOOL DoLoadXdgData(
		// Specify file name.
		const CString &strFile,
		// List of shapes.
		CFODrawShapeSet &listLoad, BOOL &bRuler);

	// Save xdg resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Xdg File File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SaveXdgFile();

	// Load or save select shapes.
	// Save selected shapes to a specify file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Save Select Shapes, Saves the specify data to a file..
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&listSave---&listSave, Specifies a E-XD++ CFODrawShapeList &listSave object (Value).
	virtual BOOL DoSaveSelectShapes(
		// Specify file name.
		const CString &strFile,
		// List of shapes.
		CFODrawShapeList &listSave);

	// Load shapes from file add insert it to current model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Load Shapes, Loads the specify data from a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&strFile---&strFile, Specifies A CString type value.  
	//		&listLoad---&listLoad, Specifies a E-XD++ CFODrawShapeSet &listLoad object (Value).
	virtual BOOL DoLoadShapes(
		// Specify file name.
		const CString &strFile,
		// List of shapes.
		CFODrawShapeSet &listLoad);

	// Insert shapes with specify point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Shapes, Inserts a child object at the given index..
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptInsert---&ptInsert, Specifies A CPoint type value.  
	//		&listShapes---&listShapes, Specifies a const CFODrawShapeSet &listShapes object(Value).
	virtual void InsertShapes(
		// Insert point.
		const CPoint &ptInsert,
		// List of shapes.
		const CFODrawShapeSet &listShapes);

	// Get all the shapes by clone the selection shapes.
	// listShapes -- Result clone shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone The Selection, Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&listShapes---&listShapes, Specifies a E-XD++ CFODrawShapeList &listShapes object (Value).
	virtual void CloneTheSelection(CFODrawShapeList &listShapes);

	// Clone the selection shapes at first,then moving ptOffset.
	// ptOffset -- Moving offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clone Move Shapes List, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.
	virtual void DoCloneMoveShapesList(const CPoint &ptOffset);

	// Clone the selection shapes at first,then mirror all of them by using line (start ptRef1,end ptRef2).
	// ptRef1 -- Mirror reference line start point.
	// ptRef2 -- Mirror reference line end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clone Mirror Shapes List, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	virtual void DoCloneMirrorShapesList(const CPoint &ptRef1,const CPoint &ptRef2);

	// Clone the selection shapes at first,then rotate all of them by angle,the rotating center is the center of all
	// the shapes.
	// nAngle -- Rotating angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Clone Rotate Shapes List, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.
	virtual void DoCloneRotateShapesList(const int& nAngle);

	// Position a list of shapes within a specify rectangle.
	// lipstShapes -- list of shapes that to be positioned.
	// rRect -- New position area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Position Shapes, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*listShapes---*listShapes, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		rRect---rRect, Specifies A CRect type value.
	virtual void DoPositionShapes(CFODrawShapeList *listShapes,const CRect& rRect);

	// Position a list of shapes within a specify rectangle,this method is the same with DoPositionShapes(..),but it
	// use some different codes.
	// lipstShapes -- list of shapes that to be positioned.
	// rRect -- New position area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Position Shapes2, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*listShapes---*listShapes, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		rRect---rRect, Specifies A CRect type value.
	virtual void DoPositionShapes2(CFODrawShapeList *listShapes,const CRect& rRect);

	// Do initial when form is created.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Form Create, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoInitFormCreate();

	// Do limit port link feature.
	// pFrom -- from port.
	// pTo -- to port
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Only One Link, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFrom---*pFrom, A pointer to the CFOPortShape  or NULL if the call failed.  
	//		*pTo---*pTo, A pointer to the CFOPortShape  or NULL if the call failed.
	virtual BOOL IsOnlyOneLink(CFOPortShape *pFrom, CFOPortShape *pTo);

protected:

	// Create form resource.
	// lpszResName -- resource name.
	// lpszType -- resource type.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Xdg File Object By Resource, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		&listCopy---&listCopy, Specifies a E-XD++ CFODrawShapeSet &listCopy object (Value).  
	//		&bRuler---&bRuler, Specifies A Boolean value.
	virtual BOOL MakeXdgObjectByResource(LPCTSTR lpszResName, LPCTSTR lpszType,CFODrawShapeSet &listCopy, BOOL &bRuler);

	// Obtain the pointer to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File Pointer, Returns the specified value.
	//		Returns a pointer to the object CFile,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile*		 GetFilePtr(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File Pointer, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFilePtr(CFile* pFile, BOOL bAbort);

public:

	// File export.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Export File, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  DoExportFile();

	// Create meta file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Metafile, You construct a CFOPCanvasCore object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		File---File, Specifies a CFile& File object(Value).  
	//		str---Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL  CreateMetafile(CFile& File, LPCTSTR str = _T(""));
	
	// Export form as bitmap file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As Bmpfile, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL  ExportAsBmpfile(LPCTSTR lpszFileName);

	// Export form as meta file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As Metafile, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL  ExportAsMetafile(LPCTSTR lpszFileName);

	// Export form as jpeg file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export As Jpegfile, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL  ExportAsJpegfile(LPCTSTR lpszFileName);

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Bound Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		&m_list---Specifies a const CFODrawShapeList &m_list object(Value).
	CRect GetShapesBoundRect(const CFODrawShapeList &m_list);

public:

	// Is current shapes has link shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Link In Shapes, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).  
	//		*pShape---*pShape, A pointer to the CFOLinkShape  or NULL if the call failed.
	virtual BOOL IsLinkInShapes(
		// List of shapes.
		const CFODrawShapeList& listShapes,
		// Pointer of link shape.
		CFOLinkShape *pShape
		);
	
	// Get rotating handle pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotating Handle Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotatingHandlePos();

	// Get rotating handle pos.
	// ptHandle -- position of the handle.
	// nAngle -- angle value of rotating.
	// dOX -- rotating Origin's x value.
	// dOY -- rotating Origin's y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Rotating Handle Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.  
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void GetTrackRotatingHandlePos(CPoint &ptHandle,int nAngle,double dOX, double dOY);

	// Obtain handle at a specify index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nHandle---nHandle, Specifies A integer value.
	virtual CFOPHandle* GetHandle(int nHandle);

	// Get the sport point of control by drag handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Normal Handles Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetNormalHandlesLocation(CFOPHandleList& lstHandle);

public:

	// Get current data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel,or NULL if the call failed
	CFODataModel*	GetCurrentModel() const;

	// Set current data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Model, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	void			SetCurrentModel(
		// Specifies the validate model.
		CFODataModel *pModel
		);

	void			SetOnlyModel(
		// Specifies the validate model.
		CFODataModel *pModel
		);


	// Put a list of shapes behind one shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes Behind Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listShapes---listShapes, Specifies a E-XD++ CFODrawShapeList& listShapes object (Value).  
	//		pRefShape---Reference Shape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void PutShapesBehindShape(
		// List of shapes.
		CFODrawShapeList& listShapes,
		// Shape for reference.
		CFODrawShape* pRefShape);

	// Put a list of shapes Infront one shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes Infront Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listShapes---listShapes, Specifies a E-XD++ CFODrawShapeList& listShapes object (Value).  
	//		pRefShape---Reference Shape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void PutShapesInfrontShape(
		// List of shapes.
		CFODrawShapeList& listShapes,
		// Shape for reference.
		CFODrawShape* pRefShape);

	// Put a list of shapes to the background of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes To Background, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).
	virtual BOOL PutShapesToBackground(
		// List of shapes.
		const CFODrawShapeList& listShapes);

	// Clear all the shapes within the background of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All Shapes Of Background, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL ClearAllShapesOfBackground();

	void FOX_ZOrderSort2(CFODrawShapeSet* pList, int nLower, int nUpper);
	void FOX_ZOrderSort2(CFODrawShapeSet* pList);

	// Put a list of shapes to the background of the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Shapes To Child Graph, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).
	virtual BOOL PutShapesToSubGraph(
		// List of shapes.
		const CFODrawShapeList& listShapes);

	// Un group the sub-graph shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ungroup Child Graph, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFOCompositeShape or NULL if the call failed.
	virtual BOOL UngroupSubGraph(CFOCompositeShape* pShape);

	// Do Ungroup multi shapes action.
	// pShapeList -- the pointer of group shape list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Multiple Child Graph Un Group Action, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiUnGroupAction,or NULL if the call failed  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.
	virtual CFOMultiUnGroupAction*	MultiSubGraphUnGroupAction(CFODrawShapeList* pShapeList);

	// Do model change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Model, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void	DoChangeModel(
		// Pointer of model.
		CFODataModel *pModel);

	// Get color and position at cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color And Position At Cursor, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&back---Specifies A 32-bit COLORREF value used as a color value.  
	//		&front---Specifies A 32-bit COLORREF value used as a color value.  
	//		&text---Specifies A 32-bit COLORREF value used as a color value.
	virtual BOOL	GetColorAndPositionAtCursor(COLORREF &back,COLORREF &front,COLORREF &text);

	// Get ruler margin and size,this method is defined for ruler bars only.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Paper Data, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&szOrgOffset---Org Offset, Specifies A CSize type value.  
	//		margins---Specifies A CRect type value.  
	//		paperrectpix---Specifies A CRect type value.  
	//		papersizepix---Specifies A CSize type value.  
	//		papersizelog---Specifies A CSize type value.
	virtual void	GetPaperData(CSize &szOrgOffset,CRect& margins, CRect& paperrectpix, 
		CSize& papersizepix, CSize& papersizelog); 

	// Set handle size.
	// szHandle -- new handle size value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Handle Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&szHandle---&szHandle, Specifies A CSize type value.
	virtual void	SetHandleSize(const CSize &szHandle);

	// Get maximize position of current select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect	GetMaxPosition();

	// Get form position and type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Form Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect			GetFormRect();

	// Get form type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Form Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT			GetFormType();

	// change rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		rc---Specifies A CRect type value.
	virtual CRect	ChangeRect(CRect rc);

	// Start enter text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Start Enter Text, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&local---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual BOOL StartEnterText(const CPoint &local,UINT nFlags);

	// End text box showing and without update.
	
	//-----------------------------------------------------------------------
	// Summary:
	// End Text Box Without Update, .
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void EndTextBoxWithoutUpdate(const CPoint &pt);

public:

	// Change the map mode of the view
	// nMapMode -- new map mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Map Mode, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMapMode---Map Mode, Specifies A integer value.
	virtual void ChangeMapMode(const int &nMapMode);

	// Change canvas.
	// szCanvas -- size of the canvas
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&szCanvas---&szCanvas, Specifies A CSize type value.
	virtual void SetCanvasSize(const CSize &szCanvas);

	// Set page size.
	void SetCanvasSizeW(const fopPageSize &szType);


	// Change canvas's size with whole number printer paper size,by sometime,we want the size of the canvas just to be whole number of printer
	// paper size,this method is defined for this case,you can define a canvas that has width of whole number the
	// printer paper width and has height of whole number the printer paper height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Size With Pages, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nHorzPages---Horizontal Pages, Specifies A integer value.  
	//		&nVertPages---Vertical Pages, Specifies A integer value.
	virtual void SetCanvasSizeWithPages(
		// Specifies the horizontal number of pages
		const int &nHorzPages,
		// Specifies the vertical number of pages.
		const int &nVertPages);

	// Obtain the canvas size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetCanvasSize() const;

	// Cal print page size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Print Position, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	ComputePrintPosition();

	// When zoom scale changed to call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Ruler Position, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoUpdateRulerPosition();

	// Drawing PanWnd window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Pan Window Objects, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDrawPanWndObjects(CDC* pDC);

public:
	
	// Retrieves the margins around the perimeter of the canvas
	// rcMargins -- margins position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Margins, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargins---rcMargins, Specifies A CRect type value.
	virtual void	GetMargins(CRect& rcMargins);

	// Sets the margins around the perimeter of the component
	// rcMargins -- new margins position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Margins, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargins---rcMargins, Specifies A CRect type value.
	virtual void	SetMargins(const CRect& rcMargins);

	// Ruler margins
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ruler Margins, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargins---rcMargins, Specifies A CRect type value.
	virtual void GetRulerMargins(CRect& rcMargins);

	// Change ruler margins.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Ruler Margins, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcMargins---rcMargins, Specifies A CRect type value.
	virtual void SetRulerMargins(const CRect& rcMargins);

	// Returns bounding rectangle in MM_HIMETRIC units.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Hi Metric Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetHiMetricRect() const;

	// Changes the viewport size to match the size of the model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale To Canvas, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL ScaleToCanvas();

	// Calculate the margins bounding rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Additional Margins, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect CalcAddiMargins();

protected:

	// Generate paste offset point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Paste Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GenPasteOffsetPoint();

	// Mouse wheel data
#if _MFC_VER > 0x0420
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		fwKeys---fwKeys, Specifies A integer value.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		xPos---xPos, Specifies a short xPos object(Value).  
	//		yPos---yPos, Specifies a short yPos object(Value).
	virtual BOOL OnMouseWheel(int fwKeys,short zDelta,short xPos,short yPos);
#endif
	
	// Update ruler width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Ruler Width, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateRulerWidth();

public:
	/*************************************************************************
	|*
	|* Canvas bounding rectangle of the container
	|*
	\************************************************************************/

	// Change size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Container Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetContainerSize() const;

	// Set the width and height of an object. 
	// cx -- cx container value
	// cy -- cy container value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Container Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual CSize SetContainerSize(int cx, int cy);

	// Get the bounding rectangle of an object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Container Bounds, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetContainerBounds() const;

	// Get the origin of an object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Container Origin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetContainerOrigin() const;

	// Set the origin of an object.
	// x -- new x origin value
	// y -- new y origin value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Container Origin, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual CPoint SetContainerOrigin(int x, int y);

	// Move the origin of an object by a given X,Y offset.
	// xOff -- x offset value
	// yOff -- y offset value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Container Origin, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		xOff---xOff, Specifies A integer value.  
	//		yOff---yOff, Specifies A integer value.
	virtual CPoint MoveContainerOrigin(int xOff,int yOff);

	// Return the width of the object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Container Width, Returns the specified value.
	//		Returns a int type value.
	int GetContainerWidth() const;

	// Return the height of the object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Container Height, Returns the specified value.
	//		Returns a int type value.
	int GetContainerHeight() const;

	// Change size
	// size -- new container size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Container Size, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		size---Specifies A CSize type value.
	CSize SetContainerSize(CSize size) { return SetContainerSize(size.cx,size.cy); }

public:

	// Obtain the default virtual origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Origin Offset, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetCanvasOriginOffset() const;

	// Determine if it is horizontal or vertical mode.
	// 0 -- not change.
	// 1 -- horizontal.
	// 2 -- vertical.
	virtual int DoDetermineHoiz(const FOPPoint &ptStart, const FOPPoint &ptMove);

	// Do action after shape is added to the canvas.
	virtual void DoAfterAddShape(CFODrawShape *pShape);


	// Saving tracking mode.
	int m_nSaveTrackDir;

public:

	/*************************************************************************
	|*
	|* Scrolling and moving
	|*
	\************************************************************************/

	// Do scroll viewport.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Move View, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptScrollPos---Scroll Position, Specifies A CPoint type value.
	virtual void DoMoveView(CPoint ptScrollPos);

	// Update scroll size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar Size, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateScrollBarSize();

	// Set new scroll bar pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Scroll Bar Position, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		ptScrollPos---Scroll Position, Specifies A CPoint type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void SetNewScrollBarPos(
		// Specifies the new scroll bar position.
		CPoint ptScrollPos,BOOL bRedraw = FALSE);

	// Is cursor in current view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Cusor In View, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCusorInView();

	// Obtain the printer measure type.
	// return value:
	// 0 -- for inches
	// 1 -- for MM
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Printer Measure, Returns the specified value.
	//		Returns a int type value.
	int GetPrinterMeasure() const { return m_nMeasureType; }
	
	// Set the unit change per scrollbar line scroll
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Line, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nLinePixelScroll---Line Pixel Scroll, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetScrollLine(UINT nLinePixelScroll) { m_nScrollLine = nLinePixelScroll; }
	
	// Get the unit change per scrollbar line scroll
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Line, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetScrollLine() { return m_nScrollLine; }

	// Change printer measure type.
	// nType -- 0 for inches,1 for MM.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Printer Measure, .
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void ChangePrinterMeasure(const int &nType);

	// Update printer's measure.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Printer Measure, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePrinterMeasure();

	// Set min move size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Minimize Move, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nDist---nDist, Specifies A integer value.
	void       SetMinMove(int nDist)      {  m_nMinMov  = nDist; if (m_nMinMov<1) m_nMinMov=1; }

	// Obtain the min move size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimize Move, Returns the specified value.
	//		Returns a int type value.
	int       GetMinMove() const          { return m_nMinMov; }

public: 

	// Clear all mouse tracking.
	void ClearMouseTracking();

	/*************************************************************************
	|*
	|* Zooming and panning
	|*
	\************************************************************************/

	// X scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom X Scale, Returns the specified value.
	//		Returns A double value (Object).
	double GetZoomXScale() const { return m_dXScale; }

	// Y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Y Scale, Returns the specified value.
	//		Returns A double value (Object).
	double GetZoomYScale() const { return m_dYScale; }

	// Get minimum and maximum zoom percentages 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Range, Returns the specified value.
	// Parameters:
	//		nZoomMin---Zoom Minimize, Specifies A double value.  
	//		nZoomMax---Zoom Maximize, Specifies A double value.
	void GetZoomRange(double& nZoomMin, double& nZoomMax);

	// Sets the minimum and maximum zoom percentages.
	// nZoomMin -- minimum value.
	// nZoomMax -- maximize zoom value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Zoom Range, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nZoomMin---Zoom Minimize, Specifies A double value.  
	//		nZoomMax---Zoom Maximize, Specifies A double value.
	void SetZoomRange(double nZoomMin, double nZoomMax);

	// Obtain the minimize scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Scale, Returns the specified value.
	//		Returns A double value (Object).
	double GetZoomScale() const;

	// Scale relative
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relative Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		dScaleWidth---Scale Width, Specifies a double dScaleWidth = 1.0 object(Value).  
	//		dScaleHeight---Scale Height, Specifies a double dScaleHeight = 1.0 object(Value).
	virtual CSize RelativeScale(double dScaleWidth = 1.0,
	                            double dScaleHeight = 1.0);

	// Scale relative
	
	//-----------------------------------------------------------------------
	// Summary:
	// Relative Scale, .
	//		Returns a CSize type value.  
	// Parameters:
	//		xNum---xNum, Specifies A integer value.  
	//		xDenom---xDenom, Specifies A integer value.  
	//		yNum---yNum, Specifies A integer value.  
	//		yDenom---yDenom, Specifies A integer value.
	CSize RelativeScale(int xNum, int xDenom,
	                    int yNum, int yDenom);

	// Center on shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Center On Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcTotal---&rcTotal, Specifies A CRect type value.
	virtual void CenterOnPosition(const CRect &rcTotal);

	// Change zoom scale value
	// nXScale -- x scale value * 100
	// nYScale -- y scale value * 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Zoom Value, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nXScale---X Scale, Specifies A integer value.  
	//		nYScale---Y Scale, Specifies A integer value.
	virtual void SetZoomValue(const double nXScale, const double nYScale);

	// Obtain the zoom scale value * 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual void GetZoomValue(double &dx, double &dy) const;

	// Zoom in
	// nXScale -- x scale value * 100
	// nYScale -- y scale value * 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Increase Zoom Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nXScale---X Scale, Specifies A double value.  
	//		nYScale---Y Scale, Specifies A double value.
	virtual void IncreaseZoomValue(const double nXScale, const double nYScale);

	// Zoom out
	// nXScale -- x scale value * 100
	// nYScale -- y scale value * 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Decrease Zoom Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		nXScale---X Scale, Specifies A double value.  
	//		nYScale---Y Scale, Specifies A double value.
	virtual void DecreaseZoomValue(const double nXScale, const double nYScale);

	// Get zoom percent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Zoom Percent, Returns the specified value.
	//		Returns a int type value.
	int	GetZoomPercent() const;

	// Increases the zoom level.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom In, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomIn();

	// Decreases the zoom level.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom Out, .
	// This member function is also a virtual function, you can Override it if you need,
    virtual void ZoomOut();

	// Increases the zoom level.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom In2, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptCenter---&ptCenter, Specifies A CPoint type value.
	virtual void ZoomIn2(const CPoint &ptCenter);
	
	// Decreases the zoom level.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom Out2, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptCenter---&ptCenter, Specifies A CPoint type value.
    virtual void ZoomOut2(const CPoint &ptCenter);

	// Zoom to fit current page size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomToFitPage();

	// Zoom to fit current select shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Select, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomToFitSelect();

	// Zoom to fit current page width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page Width, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomToFitPageWidth();

	// Zoom to fit current page height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Fit Page Height, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomToFitPageHeight();

	// Sets the scale as a percentage, where 100% is normal scale
	// percent -- scale value of zooming,if it is 100,it means no zoom in or zoom out.
	// bScroll -- scroll or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Zoom Scale, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		percent---Specifies A integer value.  
	//		bScroll---bScroll, Specifies A Boolean value.  
	//		&bRedraw---&bRedraw, Specifies A Boolean value.
	virtual void SetZoomScale(int percent,BOOL bScroll = TRUE, const BOOL &bRedraw = TRUE);

	// Sets the scale as a percentage, where 100% is normal scale
	// percent -- scale value of zooming,if it is 100,it means no zoom in or zoom out.
	// bScroll -- scroll or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Zoom Scale, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		percent---Specifies A integer value.  
	//		bScroll---bScroll, Specifies A Boolean value.  
	//		&bRedraw---&bRedraw, Specifies A Boolean value.
	virtual void SetNewZoomScale(int percent,BOOL bScroll = TRUE, const BOOL &bRedraw = TRUE);

	// Zoom to fit selected objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Selection, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ZoomToSelection();

	// Zoom to a specify rect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Zoom To Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rectZoom---rectZoom, Specifies A CRect type value.
	virtual void ZoomToRect(CRect rectZoom);
	
	// Get current zoom mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Zoom Mode, Returns the specified value.
	//		Returns a UINT type value.
    UINT  GetCurrentZoomMode() {return m_nCurrentZoomMode;}

	// Change current zoom mode.
	// nMode -- FOP_ZOOMMODE_OFF, FOP_ZOOMMODE_NORMAL, or FOP_ZOOMMODE_FIT.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Zoom Mode, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		nMode---nMode, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
    void  SetCurrentZoomMode(UINT nMode);

	// When zoom scale changed to call this function.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Zoom Scale Changing, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoZoomScaleChanging();

public:

	/*************************************************************************
	|*
	|* Panning and moving the viewport.
	|*
	\************************************************************************/

	// Panning and moving the view view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		xOff---xOff, Specifies A integer value.  
	//		yOff---yOff, Specifies A integer value.
	virtual CRect MoveView(int xOff,int yOff);

	// Panning and moving the view view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View2, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		xOff---xOff, Specifies A integer value.  
	//		yOff---yOff, Specifies A integer value.
	virtual CRect MoveView2(int xOff,int yOff);

	// Move one line up
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View Line Up, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void MoveViewLineUp(BOOL bVertical = TRUE);

	// Moves one line down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View Line Down, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void MoveViewLineDown(BOOL bVertical = TRUE);

	// Moves one page up.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View Page Up, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void MoveViewPageUp(BOOL bVertical = TRUE);

	// Moves one page down.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move View Page Down, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual void MoveViewPageDown(BOOL bVertical = TRUE);

	// Move to center origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To Center, .

	void MoveToCenter();

public:

	// Update data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( 
		// Model pointer.
		CObject * pModel,
		// Hint value.
		LPARAM lHint, CObject*pHint);

	// Layers changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layers Changed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lHint---lHint, Specifies A LPARAM value.
	virtual void DoLayersChanged(
		// Hint value.
		LPARAM lHint);

	// Do state change event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do State Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoStateChange(CFODrawShape *pShape, const CString &strState);

	// Do current value change event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Current Value Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void DoCurrentValueChange(CFODrawShape *pShape, const double &dValue);

	// Do blinking shape with value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Blink Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*listUpdate---*listUpdate, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strCondi---&strCondi, Specifies A CString type value.
	virtual BOOL DoBlinkShape(CFODrawShapeList *listUpdate, CFODrawShape *pShape, const CString &strCondi);

	// Do Visible shape with value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Visible Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strCondi---&strCondi, Specifies A CString type value.
	virtual BOOL DoVisibleShape(CFODrawShape *pShape, const CString &strCondi);

	// Do Visible shape with value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Disable Shape, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		&strCondi---&strCondi, Specifies A CString type value.
	virtual BOOL DoDisableShape(CFODrawShape *pShape, const CString &strCondi);

public:

	/*************************************************************************
	|*
	|* Logical setting of the view
	|*
	\************************************************************************/

	// Returns top, left edge of logical bounds.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Top Left, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetLogTopLeft() const;

	// Returns the top-right edge of the logical bounds
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Top Right, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetLogTopRight() const;

	// Returns bottom, left edge of logical bounds
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Bottom Left, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetLogBottomLeft() const;

	// Returns bottom, right edge of logical bounds
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Bottom Right, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetLogBottomRight() const;

	// Obtain the log Origin value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Origin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetLogOrigin() const;
	
	// Change the log Origin.
	// x -- x value of the starting position.
	// y -- y value of the starting position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Origin, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual CPoint SetLogOrigin(int x, int y);

	// Change the log origin.
	// ptLog -- new logical origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Origin, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CPoint type value.  
	// Parameters:
	//		ptLog---ptLog, Specifies A CPoint type value.
	CPoint SetLogOrigin(const CPoint& ptLog);

	// Offset log origin
	// xOffset -- x offset value.
	// yOffset -- y offset value 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Logical Origin, .
	//		Returns a CPoint type value.  
	// Parameters:
	//		xOffset---xOffset, Specifies A integer value.  
	//		yOffset---yOffset, Specifies A integer value.
	CPoint MoveLogOrigin(int xOffset, int yOffset);

	// Obtain the log size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetLogSize() const;

	// Change log size
	// cx -- cx logical value
	// cy -- cy logical value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual CSize SetLogSize(int cx, int cy);

	// Change log size
	// szLog -- new logical value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Size, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		szLog---szLog, Specifies A CSize type value.
	CSize SetLogSize(const CSize& szLog) {	return SetLogSize(szLog.cx, szLog.cy); }

	// Obtain the log center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Center, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetLogCenter() const;

	// Change the log center
	// x -- x value of the logical center.
	// y -- y value of the logical center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Center, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetLogCenter(int x, int y);

	// Change the log center.
	// ptCenter -- new logical center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Center, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		ptCenter---ptCenter, Specifies A CPoint type value.
	void SetLogCenter(const CPoint& ptCenter);
	
	// Obtain the log bounds
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Bounds, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetLogBounds() const;

	// Obtain the clipped log bounding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Clipped Logical Bounds, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetClippedLogBounds() const;

	// Obtain the log extent
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Extents, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetLogExtents() const;

	// Change the log extent
	// cx -- cx extent value
	// cy -- cy extent value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Extents, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	CSize SetLogExtents(int cx, int cy);

	// Is iso map mode or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is I S O Map, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsISOMap() const;

	// calculate factor
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Scale Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		xValue---xValue, Specifies a double& xValue object(Value).  
	//		yValue---yValue, Specifies a double& yValue object(Value).
	virtual void CalcScaleValue(double& xValue, double& yValue) const;

	// Change the log scaling
	// dXScale -- x scale value
	// dYScale -- y scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Zoom Value, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		dXScale---X Scale, Specifies a double dXScale = 1.0 object(Value).  
	//		dYScale---Y Scale, Specifies a double dYScale = 1.0 object(Value).
	virtual CSize SetLogZoomValue(double dXScale = 1.0,double dYScale = 1.0);

	// Change the log scaling
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Zoom Value, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		xNum---xNum, Specifies A integer value.  
	//		xDenom---xDenom, Specifies A integer value.  
	//		yNum---yNum, Specifies A integer value.  
	//		yDenom---yDenom, Specifies A integer value.
	CSize SetLogZoomValue(int xNum, int xDenom, int yNum, int yDenom);

public:
	/*************************************************************************
	|*
	|* Logical and device point converting.
	|*
	\************************************************************************/

	// Point change.
	// Convert from device point to logic point.
	// ppts -- points to be converted.
	// nCount -- total of points to be converted
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void FODPtoLP(LPPOINT ppts, int nCount = 1);

	// Convert from device point to logic point.
	// pArPoints -- points that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		pArPoints---Ar Points, A pointer to the CPoint> or NULL if the call failed.
	virtual void FODPtoLP(CArray<CPoint,CPoint>* pArPoints);

	// Convert from logic point to device point.
	// ppts -- points to be converted.
	// nCount -- total of points to be converted
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ppts---Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	virtual void FOLPtoDP(LPPOINT ppts, int nCount = 1);

	// convert form logic point to device point.
	// pArPoints -- points that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		pArPoints---Ar Points, A pointer to the CPoint> or NULL if the call failed.
	virtual void FOLPtoDP(CArray<CPoint,CPoint>* pArPoints);

	// Convert logical units to device units.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	virtual void FOLPtoDP( LPRECT lpRect ) const;

	// Convert logical units to device units.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto D P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpSize---lpSize, Specifies a LPSIZE lpSize object(Value).
	virtual void FOLPtoDP( LPSIZE lpSize ) const;

	// Convert device units to logical units
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpRect---lpRect, Specifies a LPRECT lpRect object(Value).
	virtual void FODPtoLP( LPRECT lpRect ) const;

	// Convert device units to logical units
	
	//-----------------------------------------------------------------------
	// Summary:
	// O D Pto L P, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpSize---lpSize, Specifies a LPSIZE lpSize object(Value).
	virtual void FODPtoLP( LPSIZE lpSize ) const;

	// Convert to map logical value.
	// nMap -- map mode
	// cx -- cx value
	// cy -- cy value
	
	//-----------------------------------------------------------------------
	// Summary:
	// O L Pto Map L P, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nMap---nMap, Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	BOOL FOLPtoMapLP(const int nMap, int& cx, int& cy);

	// Map mode change.
	// change from doc to Client
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void DocToClient(CRect& rect);

	// change from document to client.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void DocToClient(CPoint& point);

	// change from client to document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual void ClientToDoc(CPoint& point);

	// change from client to document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void ClientToDoc(CRect& rect);

public:
	/*************************************************************************
	|*
	|* Canvas virtual  rectangle,mostly it is the rectangle of the canvas,
	|* Total scrollbar range is equivelant to the total virtual size
	|* of this view.
	|*
	\************************************************************************/

	// Obtain the virtual origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Virtual Origin, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetVirtualOrigin() const;

	// Change the virtual origin
	// x -- x value of the origin
	// y -- y value of the origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Origin, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetVirtualOrigin(int x, int y);

	// Change the virtual origin
	// ptVirtualOrg -- origin of the virtual container
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Origin, Sets a specify value to current class CFOPCanvasCore
	// Parameters:
	//		ptVirtualOrg---Virtual Org, Specifies A CPoint type value.
	void SetVirtualOrigin(const CPoint& ptVirtualOrg)	{	SetVirtualOrigin(ptVirtualOrg.x, ptVirtualOrg.y);	}

	// Obtain the virtual size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Virtual Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetVirtualSize() const;

	// Change the virtual size
	// cx -- cx virtual size of the view
	// cy -- cy virtual size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual void SetVirtualSize(int cx, int cy);

	// Change the virtual size
	// size -- virtual size of the view.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Size, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		size---Specifies A CSize type value.
	virtual void SetVirtualSize(const CSize& size)	{	SetVirtualSize(size.cx,size.cy);	}

	
public:
	/*************************************************************************
	|*
	|* View's DC
	|*
	\************************************************************************/

	// Do prepare dc.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Prepare D C, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoPrepareDC(CDC* pDC);

	// Prepare dc
	// pDC -- pointer of the DC
	// bZoom -- need zoom or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Draw D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bZoom---bZoom, Specifies A Boolean value.
	virtual void PrepareDrawDC(CDC* pDC, const BOOL bZoom = TRUE);

	// Prepare ruler intersection dc
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Corner D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareCornerDC(CDC* pDC);

	// Obtain the map mode of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Map Mode, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCurMapMode() const	{ return m_nCurMapMode;	}

	// Change the map mode of the view,if you want to change the map mode please use ChangeMapMode(..) instead of
	// nMapMode -- map mode of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Map Mode, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		nMapMode---Map Mode, Specifies A integer value.
	virtual int SetCurMapMode(int nMapMode);

	// Returns the direction of the positive Y axis
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Axis Direction, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A FOCanvasAxisDirection value (Object).
	virtual FOCanvasAxisDirection GetCanvasAxisDirection() const;

	// Sets the direction of the positive Y Axis
	// aAxis -- axis direction,it should be one of the following value:
	// 	enum FOCanvasAxisDirection
	// 	{
	// 	FO_YAXIS_UP		= -1,
	// 	FO_YAXIS_DOWN	= 1
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Canvas Axis Direction, Sets a specify value to current class CFOPCanvasCore
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aAxis---aAxis, Specifies a FOCanvasAxisDirection aAxis object(Value).
	virtual void SetCanvasAxisDirection(FOCanvasAxisDirection aAxis);

	// Obtain the view extent size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get View Extents, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetViewExtents() const;

	// Change the view extent size
	// cx -- horizontal size of the view.
	// cy -- vertical size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Extents, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	CSize SetViewExtents(int cx, int cy);

	// Change the view extent
	// szView -- new view size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Extents, Sets a specify value to current class CFOPCanvasCore
	//		Returns a CSize type value.  
	// Parameters:
	//		szView---szView, Specifies A CSize type value.
	CSize SetViewExtents(const CSize& szView);

protected:

	// When form size change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update View, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void     DoUpdateView();

	// Status bar message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Status Bar Message, .
	// Parameters:
	//		fmt---A pointer to the TCHAR or NULL if the call failed.
	void StatusBarMessage(TCHAR* fmt);

	// Get rotating outline handle length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Out Length, Returns the specified value.
	//		Returns a int type value.
	int GetOutLength();

	// Show warning text,it will showing a message box.
	// strText -- waring text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Warning Text, Call this function to show the specify object.
	// Parameters:
	//		&strText---&strText, Specifies A CString type value.
	void ShowWarningText(const CString &strText);

public:
	// Overrides
	// ClassWizard generated virtual function overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnFOPPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Begin Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnFOPBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P End Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnFOPEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Print, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnFOPPrint(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnFOPUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Drag Enter, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnFOPDragEnter(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Drag Leave, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFOPDragLeave();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Drag Over, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnFOPDragOver(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Drop, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnFOPDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFOPInitialUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnFOPNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);

	//-----------------------------------------------------------------------
	// Summary:
	// Do show print preview.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print Preview, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pPrintView---Print View, A pointer to the CView or NULL if the call failed.  
	//		pPreviewViewClass---Preview View Class, A pointer to the CRuntimeClass or NULL if the call failed.  
	//		pState---pState, A pointer to the CPrintPreviewState or NULL if the call failed.
	virtual BOOL DoPrintPreview(UINT nIDResource, CView* pPrintView,
		CRuntimeClass* pPreviewViewClass, CPrintPreviewState* pState);

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnFOPCommand(WPARAM wParam, LPARAM lParam);

	// Do something before any shape is dragged to the canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Before Drag, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL OnBeforeDrag(CFODrawShape *pShape);

	// Do something before any shape is dropped on the canvas.
	// Do shape drop,override this method to handle shape drop action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Drop, Do something before any shape is dropped on the canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.
	virtual void	DoShapeDrop(
		// List of shapes.
		const CFODrawShapeList& listShapes,
		// Toolbox Item drop value.
		COleDataObject* pDataObject
		);

	// Do something before any shape is dropped on the canvas.
	// Do shape drop,override this method to handle shape drop action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Shape Drop, Do something before any shape is dropped on the canvas.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		listShapes---listShapes, Specifies a const CFODrawShapeList& listShapes object(Value).  
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.
	virtual void	DoShapeDropExtend(
		// List of shapes.
		CFODrawShapeList& listShapes,
		// Toolbox Item drop value.
		COleDataObject* pDataObject,
		// Point
		CPoint ptLog
		);

	// Activate View, override this method to handle view activate event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActiveView---Active View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnFOPActivateView(BOOL bActivate, CView* pActiveView, CView* pDeactiveView);

    // Create up right mode.
	// lpInPoints -- the source points.
	// lpOutPoints -- the output points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Up Right, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpInPoints---In Points, Specifies A LPPOINT Points array.  
	//		lpOutPoints---Out Points, Specifies A LPPOINT Points array.
	virtual void MakeUpRight(LPPOINT lpInPoints, LPPOINT lpOutPoints);
	
	// Implementation
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Get port count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Count, Returns the specified value.
	//		Returns a int type value.
	int GetPortsCount();

protected:
	
	// Adjust scroll bar point.
	// pt -- point to be corrected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Scroll Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	virtual void AdjustScrollPoint(CPoint &pt);

	// Normalize scale value,if the scale value is too small,we do nothing.
	// dScaleX -- x scale value.
	// dScaleY -- y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Normal Scale Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dScaleX---Scale X, Specifies a double &dScaleX object(Value).  
	//		&dScaleY---Scale Y, Specifies a double &dScaleY object(Value).
	virtual void NormalScaleValue(double &dScaleX,double &dScaleY);

	// Get correct property shape, override this method to handle the reference shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Correct Select Property Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetCorrectSelectPropShape();

	// Call this method to check if all selection shapes can not be rotated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shapes Cannot Rotated, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllSelectShapesCannotRotated();

	// Call this method to check if all selection shapes can not be resized.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shapes Cannot Resized, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllSelectShapesCannotResized();

	// Call this method to make sure if all selection shapes are locked or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Select Shapes Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllSelectShapesLocked();

	// Draw rotating center circle.
	// pDC-- pointer of the DC.
	// rcPos -- position of the rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Rotating Center, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void DrawRotatingCenter(CDC *pDC,const CRect &rcPos, const BOOL &bRotate = TRUE);

	// Drawing plus drag handle.
	// pDC -- pointer of the DC.
	// rcPos -- position of the drag handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Plus Drag Handle, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		Handle---Handle, Specifies A integer value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.
	virtual void DrawPlusDragHandle(CDC *pDC,int Handle, const CRect &rcPos);

	// Drawing normal drag handle.
	// pDC-- pointer of the DC.
	// rcPos -- position of the drag handle.
	// bVector -- vector or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal Drag Handle, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bVector---bVector, Specifies A Boolean value.
	virtual void DrawNormalDragHandle(CDC *pDC,const CRect &rcPos,BOOL bVector);

	// Drawing normal drag handle.
	// pDC-- pointer of the DC.
	// rcPos -- position of the drag handle.
	// bVector -- vector or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Normal Drag Handle2, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		bVector---bVector, Specifies A Boolean value.
	virtual void DrawNormalDragHandle2(CDC *pDC,const CRect &rcPos,BOOL bVector);

	// Generated message map functions
public:
	// The following methods are the menu command's functions.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Mouse Move, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P L Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P L Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P L Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Create, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	int OnFOPCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Destroy, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Ctl Color, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	HBRUSH OnFOPCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	void OnFOPSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	void OnFOPKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnFOPKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnFOPKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Char, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnFOPChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P R Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P R Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPRButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPMButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	BOOL OnFOPMButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL OnFOPSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Text Edit Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	void OnFOPTextEditNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Box Text Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	void OnFOPEditBoxTextNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Text Edit Change, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPTextEditChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Box Text Change, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditBoxTextChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Timer, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void OnFOPTimer(UINT nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Query New Palette, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL OnFOPQueryNewPalette();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Palette Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pFocusWnd---Focus Window, A pointer to the CWnd or NULL if the call failed.
	void OnFOPPaletteChanged(CWnd* pFocusWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Size, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	void OnFOPSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P H Scroll, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	void OnFOPHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P V Scroll, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	void OnFOPVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Select All, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditSelectAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Select All, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	void OnFOPUpdateEditSelectAll(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Clear, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditClear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Clear, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditClear(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Copy, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditCopy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Copy, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditCopy(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Cut, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditCut();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Cut, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditCut(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Paste, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditPaste();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Paste, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditPaste(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Bottom, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Bottom, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignBottom(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Center, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Center, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignCenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Inview Hor, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignInviewHor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Inview Hor, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignInviewHor(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Inview Ver, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignInviewVer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Inview Ver, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignInviewVer(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Left, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Left, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignLeft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Edit Spot, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoEditSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Edit Spot, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoEditSpot(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Design, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDesign();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Design, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDesign(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Right, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Right, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignRight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Top, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignTop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Top, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignTop(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Rotate, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRotate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Rotate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRotate(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Flip Horizontal, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFlipHorz();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Flip Horizontal, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFlipHorz(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Flip Vertical, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFlipVert();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Flip Vertical, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFlipVert(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Rotate Left, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRotateLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Rotate Left, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRotateLeft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Rotate Right, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRotateRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Rotate Right, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRotateRight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Vcenter, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignVcenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Alignment Vcenter, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAlignVcenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Back, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Back, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBack(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Backward, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoBackward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Backward, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBackward(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoCustomProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCustomProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Text Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoTextProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Text Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoTextProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Key Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoKeyProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Key Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoKeyProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Bullets, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoBullets();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Bullets, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBullets(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Line Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoLineProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Line Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLineProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Fill Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoFillProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Fill Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFillProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Event Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoEventProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Event Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoEventProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shadow Properties, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoShadowProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shadow Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShadowProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Components Select, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoCompsSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Components Select, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCompsSelect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Form Setting, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPFoFormSetting();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Form Setting, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFormSetting(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Print Header Footer, This member function is called by the framework to allow your application to handle a Windows message.

	virtual void OnFOPPrintHeaderFooter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Print Header Footer, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPrintHeaderFooter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Forward, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoForward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Forward, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoForward(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Front, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFront();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Front, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFront(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Grid, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGrid();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Grid, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGrid(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Margin, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoMargin();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Margin, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoMargin(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Size All, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSizeAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Size All, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSizeAll(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Size Height, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSizeHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Size Height, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSizeHeight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Size Width, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSizeWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Size Width, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSizeWidth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Space Across, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSpaceAcross();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Space Across, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSpaceAcross(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Space Down, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSpaceDown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Space Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSpaceDown(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Tab Order, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTabOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Tab Order, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoTabOrder(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Button, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawButton(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Frame, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawFrame();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Draw Frame, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoDrawFrame(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Tabel, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawTabel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Tabel, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawTabel(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRectangle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRectangle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Round Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRoundRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Round Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRoundRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Do Draw Image, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDoDrawImage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Do Draw Image, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDoDrawImage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Static, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawStatic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Static, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawStatic(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Grid Property, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGridProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Grid Property, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGridProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Select, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Select, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawSelect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo File Export, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFileExport();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo File Export, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFileExport(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Redo, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditRedo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Redo, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditRedo(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Undo, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditUndo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Undo, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditUndo(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Clear All, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPEditClearAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Edit Clear All, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateEditClearAll(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Ellipse, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Ellipse, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawEllipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Port, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawPort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Port, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawPort(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Dimension Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawDimLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Dimension Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawDimLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Arc Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawArcLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Arc Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawArcLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Pie, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawPie();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Pie, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawPie(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Arrow Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawArrowLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Arrow Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawArrowLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Cross Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawCrossLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Cross Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawCrossLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Free Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawFreeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Free Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawFreeLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Free Close Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawFreeCloseLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Free Close Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawFreeCloseLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Arrow Bezier Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawArrowBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Arrow Bezier Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawArrowBezierLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Polygon Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawPolyLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Polygon Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawPolyLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Panwnd, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewPanwnd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo View Panwnd, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoViewPanwnd(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Polygon, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Polygon, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawPolygon(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Round, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRound();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Round, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRound(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Close Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawCloseBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Close Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawCloseBezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Action Group, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoActionGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Action Group, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoActionGroup(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Action Un Group, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoActionUnGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Action Un Group, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoActionUnGroup(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Action Un Group Child Graph, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoActionUnGroupSubGraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Action Un Group Child Graph, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoActionUnGroupSubGraph(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Cmd Nudgeleft, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCmdNudgeleft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Cmd Nudgeleft, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCmdNudgeleft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Cmd Nudgeright, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCmdNudgeright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Cmd Nudgeright, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCmdNudgeright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Cmd Nudgetop, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCmdNudgetop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Cmd Nudgetop, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCmdNudgetop(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Cmd Nudgebottom, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCmdNudgebottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Cmd Nudgebottom, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCmdNudgebottom(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Cmd Automatic Pan, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCmdAutoPan();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Cmd Automatic Pan, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCmdAutoPan(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Link, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Link, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Link Normal, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawLinkNormal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Link Normal, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawLinkNormal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Page Setup, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL OnFOPPageSetup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P F O Lockcomp, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFOLockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update F O Lockcomp, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFOLockcomp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P F O Grid Snap, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFOGridSnap();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update F O Grid Snap, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFOGridSnap(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P F O Glue To Shape, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFOGlueToShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update F O Glue To Shape, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFOGlueToShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P F O Unlockcomp, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFOUnlockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update F O Unlockcomp, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFOUnlockcomp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Pots, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPots();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Pots, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPots(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Zoom50, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewZoom50();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Zoom50, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewZoom50(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Zoom75, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewZoom75();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Zoom75, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewZoom75(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Zoom100, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewZoom100();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Zoom100, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewZoom100(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Zoom150, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewZoom150();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Zoom150, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewZoom150(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Zoom200, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewZoom200();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Zoom200, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewZoom200(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Scaleadd25, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewScaleadd25();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Scaleadd25, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewScaleadd25(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo View Scalesub25, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoViewScalesub25();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo View Scalesub25, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoViewScalesub25(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Zoom Fitselect, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoZoomFitselect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Zoom Fitselect, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoZoomFitselect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Zoomfitheight, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoZoomfitheight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Zoomfitheight, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoZoomfitheight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Zoomfitpage, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoZoomfitpage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Zoomfitpage, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoZoomfitpage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Zoomfitwidth, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoZoomfitwidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Zoomfitwidth, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoZoomfitwidth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Zoom Within Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoZoomWithinRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Zoom Within Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoZoomWithinRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo File Save Selected, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFileSaveSelected();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo File Save Selected, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFileSaveSelected(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo File Openappend, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoFileOpenappend();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo File Openappend, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoFileOpenappend(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A0 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA0Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A0 Corner, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA0Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A0 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA0Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A0 Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA0Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Upright Circle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawUprightCircle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Upright Circle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawUprightCircle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Upright Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoUprightRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Upright Rectangle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoUprightRect(CCmdUI* pCmdUI);
	
	void OnFOPFoPolyAsymmetric();
	void OnFOPUpdateFoPolyAsymmetric(CCmdUI* pCmdUI);
	void OnFOPFoPolyAngular();
	void OnFOPUpdateFoPolyAngular(CCmdUI* pCmdUI);
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A1 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA1Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A1 Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA1Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A1 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA1Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A1 Corner, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA1Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A1 Normal, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA1Normal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A1 Normal, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA1Normal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A1 Upright, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA1Upright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A1 Upright, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA1Upright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A2 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA2Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A2 Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA2Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A2 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA2Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A2 Corner, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA2Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A2 Normal, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA2Normal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A2 Normal, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA2Normal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link A2 Upright, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkA2Upright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link A2 Upright, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkA2Upright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O Prot Properties, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOProtProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Prot Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoProtProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Multiselect, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawMultiselect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Multiselect, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawMultiselect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Delete Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDeleteHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Delete Helpline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDeleteHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Guides, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGuides();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Guides, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGuides(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Arc2, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawArc2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Arc2, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawArc2(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Chord, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawChord();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Chord, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawChord(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Mirror Free, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoMirrorFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Mirror Free, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoMirrorFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Lock Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLockHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Lock Helpline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLockHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Unlock Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoUnlockHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Unlock Helpline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoUnlockHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Position Properties, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPosProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Position Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPosProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Dragdropallow, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDragdropallow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Dragdropallow, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDragdropallow(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Layer Property, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLayerProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Layer Property, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLayerProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Layer Setting, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLayerSetting();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Layer Setting, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLayerSetting(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Convert Path, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoConvertPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Convert Path, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoConvertPath(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Convert Polygon, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoConvertPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Convert Polygon, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoConvertPolygon(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shapes Combine, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShapesCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shapes Combine, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShapesCombine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shapes Dismantle, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShapesDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shapes Dismantle, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShapesDismantle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shapes Merge Merge, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShapesMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shapes Merge Merge, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShapesMergeMerge(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shapes Merge Substract, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShapesMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shapes Merge Substract, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShapesMergeSubstract(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shapes Merge Intersect, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShapesMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shapes Merge Intersect, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShapesMergeIntersect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Connect Lines, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Connect Lines, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoConnectLines(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Break Lines, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoBreakLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Break Lines, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBreakLines(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Closeshape, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCloseshape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Closeshape, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCloseshape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Infront Shape, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoInfrontShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Infront Shape, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoInfrontShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Behind Shape, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoBehindShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Behind Shape, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBehindShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Shear Free, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Shear Free, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoShearFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Bend Free, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoBendFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Bend Free, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoBendFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Reverse Order, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoReverseOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Reverse Order, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoReverseOrder(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Glue To Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGlueToHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Glue To Helpline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGlueToHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Glue To Intersect Point, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGlueToIntersectPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Glue To Intersect Point, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGlueToIntersectPoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Glue To Shape Spot, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoGlueToShapeSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Glue To Shape Spot, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoGlueToShapeSpot(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Fromcenter, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawFromcenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Fromcenter, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawFromcenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Captionline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawCaptionline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Captionline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawCaptionline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Rectangle Callout, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRectCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Rectangle Callout, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRectCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Round Callout, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRoundCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Round Callout, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRoundCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Cloud Callout, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawCloudCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Cloud Callout, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawCloudCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Horizontal Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawHorzDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Horizontal Dimline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawHorzDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Vertical Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawVertDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Vertical Dimline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawVertDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Radius Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRadiusDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Radius Dimline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRadiusDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Extend Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawExtLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Extend Line, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawExtLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Set Background, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoSetBackground();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Set Background, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoSetBackground(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Make Subgraph, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoMakeSubgraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Make Subgraph, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoMakeSubgraph(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Polygon Insertpoint, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPolyInsertpoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Insertpoint, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolyInsertpoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Polygon Deletepoint, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPolyDeletepoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Deletepoint, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolyDeletepoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Polygon Makeline, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPolyMakeline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Makeline, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolyMakeline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Polygon Makecurve, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPolyMakecurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Makecurve, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolyMakecurve(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Polygon Ripuppoint, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPPolyRipuppoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Ripuppoint, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolyRipuppoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkTurncorner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkTurncorner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Link Break Center, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoLinkBreakCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Link Break Center, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoLinkBreakCenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Select Ellipse, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawSelectEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Select Ellipse, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawSelectEllipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Pixel, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewPixel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Pixel, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewPixel(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Inch, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewInch();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Inch, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewInch(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Cm, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewCm();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Cm, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewCm(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Feet, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewFeet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Feet, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewFeet(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Meters, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewMeters();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Meters, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewMeters(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Ruler View Mm, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRulerViewMm();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Ruler View Mm, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRulerViewMm(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Distribution, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDistribution();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Distribution, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDistribution(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Allow Main, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAllowMain();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Allow Main, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAllowMain(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Richedit, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawRichedit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Richedit, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawRichedit(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fop Port Property, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFopPortProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fop Port Property, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFopPortProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Extend Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawExtBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Draw Extend Bezier, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoDrawExtBezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Extend Closebezier, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawExtClosebezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Draw Extend Closebezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoDrawExtClosebezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Automatic Reroute, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAutoReroute();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Automatic Reroute, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoAutoReroute(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Colortheme, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoColortheme();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Colortheme, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoColortheme(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Curve Link, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCurveLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Curve Link, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCurveLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Two Points Curve Link, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTwoPointsCurveLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Two Points Curve Link, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoTwoPointsCurveLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Center Arrow Curve Link, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoCenterArrowCurveLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Center Arrow Curve Link, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoCenterArrowCurveLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Arc Link, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoArcLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Arc Link, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoArcLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Round Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoRoundLinkTurncorner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Round Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoRoundLinkTurncorner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Polygon Smooth, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoPolySmooth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Fo Polygon Smooth, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnFOPUpdateFoPolySmooth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Text, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellText();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Text, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellText(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Split, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellSplit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Split, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellSplit(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Merge, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Merge, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellMerge(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Fill, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellFill();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Fill, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellFill(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Delete Row, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellDelRow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Delete Row, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellDelRow(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Delete Column, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellDelCol();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Delete Column, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellDelCol(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Addrow Before, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellAddrowBefore();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Addrow Before, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellAddrowBefore(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Addrow After, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellAddrowAfter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Addrow After, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellAddrowAfter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Addcol Before, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellAddcolBefore();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Addcol Before, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellAddcolBefore(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Addcol After, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellAddcolAfter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Addcol After, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFoTableCellAddcolAfter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Draw Pipe Line, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoDrawPipeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Draw Pipe Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoDrawPipeLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Table Cell Linedlg, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoTableCellLinedlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Table Cell Linedlg, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoTableCellLinedlg(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button Add, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFoButtonAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Horizontal Adjacent, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignHorzAdjacent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Alignment Horizontal Adjacent, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoAlignHorzAdjacent(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Alignment Vertical Adjacent, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoAlignVertAdjacent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Alignment Vertical Adjacent, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoAlignVertAdjacent(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Fo Property Manager, This member function is called by the framework to allow your application to handle a Windows message.

	void OnFOPFoPropManager();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O P Fo Property Manager, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	void OnUpdateFOPFoPropManager(CCmdUI* pCmdUI);

	void OnFOPFoPolySymmetric();
	void OnFOPUpdateFoPolySymmetric(CCmdUI* pCmdUI);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Edit Menu Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnFOPEditMenuCommand( UINT nID );

	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	LRESULT OnFOPColorChange(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Reset Select, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wPar---wPar, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lPar---lPar, Specifies A LPARAM value.
	LRESULT OnFOPResetSelect(WPARAM wPar,LPARAM lPar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Position, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	void OnFOPUpdatePosition(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Mouse Position, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	void OnFOPUpdateMousePos(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Update Width, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	void OnFOPUpdateWidth(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O P Destroy Calendar, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	LONG OnFOPDestroyCalendar(WPARAM wParam, LPARAM lParam);
	// this is the end of the file.
};

struct FO_ZOOM_VALUE
{
	double dXScale;
	double dYScale;
	CPoint ptCenter;
};

// Zoom list.
 
//===========================================================================
// Summary:
//     The CFOPZoomList class derived from FOPList
//      F O P Zoom List
//===========================================================================

class FO_EXT_CLASS CFOPZoomList : public FOPList
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Zoom List, Constructs a CFOPZoomList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pCFOPCanvasCore---C F O P Canvas Core, A pointer to the CFOPCanvasCore or NULL if the call failed.
	CFOPZoomList(CFOPCanvasCore* pCFOPCanvasCore);
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Zoom List, Destructor of class CFOPZoomList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPZoomList();
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Zoom Rectangle, Inserts a child object at the given index..
	// Parameters:
	//		rRect---rRect, Specifies a const FO_ZOOM_VALUE& rRect object(Value).
	void		InsertZoomRect(const FO_ZOOM_VALUE& rRect);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Zoom Rectangle, Returns the specified value.
	//		Returns A FO_ZOOM_VALUE value (Object).
	FO_ZOOM_VALUE	GetCurrentZoomRect() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Zoom Rectangle, Returns the specified value.
	//		Returns A FO_ZOOM_VALUE value (Object).
	FO_ZOOM_VALUE	GetNextZoomRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Previous Zoom Rectangle, Returns the specified value.
	//		Returns A FO_ZOOM_VALUE value (Object).
	FO_ZOOM_VALUE	GetPreviousZoomRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Next Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsNextPossible() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Previous Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPreviousPossible() const;
	
private:
 
	// C F O P Canvas Core, This member maintains a pointer to the object CFOPCanvasCore.  
	CFOPCanvasCore*	mpCFOPCanvasCore;
 
	// Current Position, Specify a A 32-bit signed integer.  
	ULONG		mnCurPos;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPCANVASCORE_H__F1E8AEB4_98C3_4DFC_B40C_B758EBAF632A__INCLUDED_)
