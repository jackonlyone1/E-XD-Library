//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLINE_H__348324AB_F10B_4057_9001_0CF609661294__INCLUDED_)
#define AFX_FOPLINE_H__348324AB_F10B_4057_9001_0CF609661294__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLine.h : header file
//

#include "FOPUtil.h"
#include "FOPCollect.h"

/////////////////////////////////////////////////////////////////////////////////
//
// FOPLine -- line object.
// Use these methods to handle the functions of the line.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The FOPLine class derived from CObject
//      O P Line
//===========================================================================

class FO_EXT_CLASS FOPLine : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPLine---O P Line, Specifies a FOPLine object(Value).
	DECLARE_SERIAL(FOPLine);

	// Start point of the line.
 
	// Line Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptLineStart;

	// End point of the line.
 
	// Line End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptLineEnd;

	// Segment index of line.
 
	// Segment Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				nSegmentIndex;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line, Constructs a FOPLine object.
	//		Returns A  value (Object).
	FOPLine()	{ nSegmentIndex = 0; }

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line, Constructs a FOPLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	FOPLine(const FOPPoint& ptStart, const FOPPoint& ptEnd): 
	m_ptLineStart(ptStart), m_ptLineEnd(ptEnd)	{ nSegmentIndex = 0; }
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Start, .
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStart)---ptStart), Specifies a ptStart) object(Value).  
	//		m_ptLineEnd(ptEnd---Line End(pt End, Specifies a m_ptLineEnd(ptEnd object(Value).
	// Constructor
	FOPLine(const FOPPoint& ptStart, double dAngle, double dDis);

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// nSegmentIndex -- segment index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line, Constructs a FOPLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStartPoint---Start Point, Specifies A integer value.  
	//		ptEndPoint---End Point, Specifies A integer value.  
	//		segmentIndex---segmentIndex, Specifies A integer value.
	FOPLine(FOPPoint ptStartPoint, FOPPoint ptEndPoint, int segmentIndex)
	{
			m_ptLineStart = ptStartPoint;
			m_ptLineEnd = ptEndPoint;
			nSegmentIndex = segmentIndex;
	}

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Line, Constructs a FOPLine object.
	//		Returns A  value (Object).  
	// Parameters:
	//		line---Specifies a const FOPLine& line object(Value).
	FOPLine(const FOPLine& line);

	// Sets this set of equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPLine& value (Object).  
	// Parameters:
	//		prop---Specifies a const FOPLine& prop object(Value).
	FOPLine& operator=(const FOPLine& prop);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Line, Destructor of class FOPLine
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPLine() {}

	// Create with angle, distance 200
	void CreateWithAngle(FOPPoint ptStartPoint, int nAngle);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data.
	virtual void Serialize(CArchive &ar);

	// Change the Start point of the line.
	// ptStart -- start point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start, Sets a specify value to current class FOPLine
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.
	void SetStart(const FOPPoint& ptStart)	{	m_ptLineStart = ptStart;	}

	// Obtain the start point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start, Returns the specified value.
	//		Returns a int type value.
	const FOPPoint& Start() const		{	return m_ptLineStart;	}

	// Obtain the start point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start, Returns the specified value.
	//		Returns a int type value.
	const FOPPoint& GetStart() const		{	return m_ptLineStart;	}

	// Change the end point of the line.
	// ptEnd -- end point of the line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End, Sets a specify value to current class FOPLine
	// Parameters:
	//		ptEnd---ptEnd, Specifies A integer value.
	void SetEnd(const FOPPoint& ptEnd)		{	m_ptLineEnd = ptEnd;	}

	// Obtain the end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End, Returns the specified value.
	//		Returns a int type value.
	const FOPPoint& GetEnd() const			{	return m_ptLineEnd;	}

	
	// Obtain the end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End, Returns the specified value.
	//		Returns a int type value.
	const FOPPoint& End() const			{	return m_ptLineEnd;	}


	//-----------------------------------------------------------------------
	// Summary:
	// Left, .
	//		Returns A 32-bit long signed integer.
	// Left Border.
	long Left() const	{	return (m_ptLineStart.X() < m_ptLineEnd.X()) ? m_ptLineStart.X() : m_ptLineEnd.X();	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Top, .
	//		Returns A 32-bit long signed integer.
	// Top border
	long Top() const	{	return (m_ptLineStart.Y() < m_ptLineEnd.Y()) ? m_ptLineStart.Y() : m_ptLineEnd.Y();	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Right, .
	//		Returns A 32-bit long signed integer.
	// Right border.
	long Right() const	{	return (m_ptLineStart.X() > m_ptLineEnd.X()) ? m_ptLineStart.X() : m_ptLineEnd.X();	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// Bottom, .
	//		Returns A 32-bit long signed integer.
	// Bottom border.
	long Bottom() const	{	return (m_ptLineStart.Y() > m_ptLineEnd.Y()) ? m_ptLineStart.Y() : m_ptLineEnd.Y();	}

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.
	// dx value
	int dx() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.
	// dy value.
    int dy() const;

	// Is null.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null, Determines if the given value is correct or exist.
	//		Returns A Boolean value.
	bool IsNull() const;

	// Length
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Length, Returns the specified value.
	//		Returns A double value (Object).
	double GetLength() const;

	// Change length of line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Length, Sets a specify value to current class FOPLine
	// Parameters:
	//		len---Specifies A integer value.
	void SetLength(int len);

	// Obtain point at, toPercent will be 0.0 - 1.0 -...
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point At, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		toPercent---toPercent, Specifies a double toPercent object(Value).
	FOPPoint GetPointAt(double toPercent) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		maLine---maLine, Specifies a const FOPLine& maLine object(Value).  
	//		nPointX---Point X, Specifies A integer value.  
	//		nPointY---Point Y, Specifies A integer value.
	// Intersection.
	// maLine -- line object that intersect.
	// nPointX -- Result intersect point x value.
	// nPointY -- Result intersect point y value.
	BOOL Intersection(const FOPLine& maLine, double& nPointX, double& nPointY) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		maLine---maLine, Specifies a const FOPLine& maLine object(Value).  
	//		nPointX---Point X, Specifies A integer value.  
	//		nPointY---Point Y, Specifies A integer value.
	// Intersection.
	// maLine -- line object that intersect.
	// nPointX -- Result intersect point x value.
	// nPointY -- Result intersect point y value.
	BOOL IntersectionWithOut(const FOPLine& maLine, double& nPointX, double& nPointY) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		maLine---maLine, Specifies a const FOPLine& maLine object(Value).  
	//		ptPoint---ptPoint, Specifies A integer value.
	// Intersection.
	// maLine -- line object that intersect.
	// ptPoint -- result intersect point.
	BOOL Intersection(const FOPLine& maLine, FOPPoint& ptPoint) const;
	

	// Is two line intersection.
	BOOL IsIntersection(const FOPLine &maLine);

	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		maLine---maLine, Specifies a const FOPLine& maLine object(Value).  
	//		ptPoint---ptPoint, Specifies A integer value.
	// Intersection.
	// maLine -- line object that intersect.
	// ptPoint -- result intersect point.
	BOOL IntersectionWithOut(const FOPLine& maLine, FOPPoint& ptPoint) const;

	//-----------------------------------------------------------------------
	// Summary:
	// Intersection, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		aLine---aLine, Specifies a FOPLine& aLine object(Value).
	// Intersection.
	// rcRect -- rectangle that intersect.
	// ptPoint -- result intersect point.
	BOOL Intersection(const FOPRect& rcRect, FOPLine& aLine) const;

	// Distance.
	// aPtX -- X value of the point.
	// aPtY -- Y value of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		aPtX---Point X, Specifies a const double& aPtX object(Value).  
	//		aPtY---Point Y, Specifies a const double& aPtY object(Value).
	double GetDistance(const double& aPtX, const double& aPtY) const;

	// Get distance of the line.
	// ptPoint -- point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	double GetDistance(const FOPPoint& ptPoint) const	{	return(GetDistance(ptPoint.X(), ptPoint.Y())); }

	// Nearest point on the line.
	// ptPoint -- nearest point to on the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Nearest Point, .
	//		Returns a int type value.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A integer value.
	FOPPoint NearestPoint(const FOPPoint& ptPoint) const;

	// Angle between two lines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle, Returns the specified value.
	//		Returns A double value (Object).  
	// Parameters:
	//		&newLine---&newLine, Specifies a const FOPLine &newLine object(Value).
	double GetAngle(const FOPLine &newLine) const;

	// Offset line with
	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		&ptOffset---&ptOffset, Specifies A integer value.
	void Translate(const FOPPoint &ptOffset);

	// return The angle of the line (from start to endpoint).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle1, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
    virtual double GetAngle1() const 
	{
        return m_ptLineStart.AngleTo(m_ptLineEnd);
    }

	// Create parallel line that near to coord point.
	// coord -- near point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Parallel Line, You construct a FOPLine object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object FOPLine,or NULL if the call failed  
	// Parameters:
	//		coord---Specifies A integer value.  
	//		distance---Specifies a double distance object(Value).  
	//		number---Specifies A integer value.
	FOPLine* CreateParallelLine(const FOPPoint& coord,
                                double distance, int number);

	// return The angle of the line (from end to start point).
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
    virtual double GetAngle2() const 
	{
        return m_ptLineEnd.AngleTo(m_ptLineStart);
    }

	void SetAngle(double a);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reverse, .
	// This member function is also a virtual function, you can Override it if you need,
	// Reverse the line.
	virtual void Reverse();

	// return Direction 1. The angle at which the line starts at the start point. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direction1, Returns the specified value.
	//		Returns A double value (Object).
	double GetDirection1() const 
	{
		return GetAngle1();
	}
	
	// return Direction 2. The angle at which the line starts at the endpoint.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Direction2, Returns the specified value.
	//		Returns A double value (Object).
	double GetDirection2() const 
	{
		return GetAngle2();
	}

	// return the center point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Middlepoint, Returns the specified value.
	//		Returns a int type value.
    FOPPoint GetMiddlepoint();

	// Obtain the nearest end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Endpoint, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		coord---Specifies A integer value.  
	//		dist---A pointer to the double or NULL if the call failed.
	virtual FOPPoint GetNearestEndpoint(const FOPPoint& coord,
                                         double* dist = NULL);

	virtual FOPPoint GetVectorTo(const FOPPoint& point,
            bool limited = true) const;

	int GetLineIntersect(FOPRect rect,FOPFloat* ptsIntersect);

	FOPFloat getVectorFromEndpointTo(const FOPFloat& point) const;
	BOOL getLeftSideOfPoint(const FOPPoint& point) const;
	// Obtain the nearest center
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		coord---Specifies A integer value.  
	//		dist---A pointer to the double or NULL if the call failed.
	virtual FOPPoint GetNearestCenter(const FOPPoint& coord,
                                       double* dist = NULL);

	// Obtain distance to point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Distance To Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).  
	// Parameters:
	//		coord---Specifies A integer value.
	virtual double GetDistanceToPoint(const FOPPoint& coord);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		offset---Specifies A integer value.
	// Move line
	virtual void Move(FOPPoint offset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		center---Specifies A integer value.  
	//		angle---Specifies a double angle object(Value).
	// Rotate line
    virtual void Rotate(FOPPoint center, double angle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		center---Specifies A integer value.  
	//		factor---Specifies A integer value.
	// Scale line
    virtual void Scale(FOPPoint center, FOPPoint factor);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		axisPoint1---axisPoint1, Specifies A integer value.  
	//		axisPoint2---axisPoint2, Specifies A integer value.
	// Mirror line
    virtual void Mirror(FOPPoint axisPoint1, FOPPoint axisPoint2);

protected:

	// Unit vector
	
	//-----------------------------------------------------------------------
	// Summary:
	// Unit Vector, .
	//		Returns A FOPLine value (Object).
	FOPLine UnitVector() const;

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////
// CFOPMark -- it is defined for path shape only, it is the select vector mark.
//				mostly, it is the red spot that selected.
//

class CFOPathShape;
 
//===========================================================================
// Summary:
//      To use a CFOPMark object, just call the constructor.
//      F O P Mark
//===========================================================================

class FO_EXT_CLASS CFOPMark 
{ 
protected:

	// Pointer of the shape
 
	// Path Shape, This member maintains a pointer to the object CFOPathShape.  
	CFOPathShape*			m_pPathShape;

	// Index of the vector point.
 
	// Vector Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nVectorIndex;

public:

	// Constructor.
	// nIndex -- index of the vector.
	// pNewObj -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mark, Constructs a CFOPMark object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		pNewObj---New Object, A pointer to the CFOPathShape or NULL if the call failed.
	CFOPMark(const int &nIndex,CFOPathShape* pNewObj = NULL);
	
	// Constructor.
	// nIndex -- index of the vector.
	// pNewObj -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mark, Constructs a CFOPMark object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPtIndex---Point Index, Specifies A integer value.  
	//		pNewObj---New Object, A pointer to the CFOPathShape or NULL if the call failed.
	CFOPMark(const int &nPoly, const int &nPtIndex,CFOPathShape* pNewObj = NULL);
	
	// Copy constructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mark, Constructs a CFOPMark object.
	//		Returns A  value (Object).  
	// Parameters:
	//		propShape---propShape, Specifies a const CFOPMark& propShape object(Value).
	CFOPMark(const CFOPMark& propShape);
	
	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Mark, Destructor of class CFOPMark
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMark();

	// Sets this set of equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPMark& value (Object).  
	// Parameters:
	//		prop---Specifies a const CFOPMark& prop object(Value).
	CFOPMark& operator=(const CFOPMark& prop);

	// Determines if it is equal to this one. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		prop---Specifies a const CFOPMark prop object(Value).
	BOOL operator==(const CFOPMark &prop) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aMark---aMark, Specifies a const CFOPMark& aMark object(Value).
	BOOL operator!=(const CFOPMark& aMark) const 
	{ 
		return !(operator==(aMark)); 
	}

public:
	
	// Return Vector Index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Vector Index, Returns the specified value.
	//		Returns a int type value.
	int GetVectorIndex() const { return m_nVectorIndex;}

	// Change Vector Index value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Vector Index, Sets a specify value to current class CFOPMark
	// Parameters:
	//		&nValue---&nValue, Specifies A integer value.
	void SetVectorIndex( const int &nValue ) { m_nVectorIndex = nValue; }

	// Obtain the pointer of the shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns a pointer to the object CFOPathShape,or NULL if the call failed
	CFOPathShape* GetObj() const
	{ 
		return m_pPathShape; 
	}

	// Change the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object, Sets a specify value to current class CFOPMark
	// Parameters:
	//		pNewObj---New Object, A pointer to the CFOPathShape or NULL if the call failed.
	void SetObj(CFOPathShape* pNewObj)
	{ 
		m_pPathShape = pNewObj; 
	}

	// Pick nearest point by snap shape's spots
	// ptHit -- input point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		nHitBorder---Hit Border, Specifies A integer value.
	virtual BOOL HitTest(const CPoint &ptHit, int nHitBorder);

	// Number of the polygon.
 
	// Nub Polygon, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNubPolygon;

	// Number of the points.
 
	// Number Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNumPoints;

	// Number of the polygon.
 
	// Nub Polygon2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNubPolygon2;

	// Number of the points.
 
	// Number Points2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNumPoints2;

	// Is control handle.
 
	// Is , This member sets TRUE if it is right.  
	BOOL			m_bIsControl;

	// Last point index.
 
	// Last Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLastPoint;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPMarkList -- list of marks, a list that stores list of mark pointers.
//

 
//===========================================================================
// Summary:
//      To use a CFOPMarkList object, just call the constructor.
//      F O P Mark List
//===========================================================================

class FO_EXT_CLASS CFOPMarkList 
{
protected:
	// List of the marks
 
	// Marks, This member specify FOPContainer object.  
	FOPContainer		m_lstMarks;

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mark List, Constructs a CFOPMarkList object.
	//		Returns A  value (Object).
	CFOPMarkList();

	// Constructor.
	// aLst -- list object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Mark List, Constructs a CFOPMarkList object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aLst---aLst, Specifies a const CFOPMarkList& aLst object(Value).
	CFOPMarkList(const CFOPMarkList& aLst) ;

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Mark List, Destructor of class CFOPMarkList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPMarkList();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data.
	void Clear();
	
	// Obtain the count of the marks.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mark Count, Returns the specified value.
	//		Returns a int type value.
	int GetMarkCount() const 
	{ 
		return m_lstMarks.Count(); 
	}

	// Obtain the mark at specify number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Mark, Returns the specified value.
	//		Returns a pointer to the object CFOPMark,or NULL if the call failed  
	// Parameters:
	//		nNum---nNum, Specifies A integer value.
	CFOPMark* GetMark(int nNum) const 
	{ 
		return (CFOPMark*)(m_lstMarks.GetObject(nNum)); 
	}
	
	// Find mark index.
	// pObj -- pointer of path shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Object, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a int type value.  
	// Parameters:
	//		pObj---pObj, A pointer to the const CFOPathShape or NULL if the call failed.
	int FindObject(const CFOPathShape* pObj) const;

	// Insert new entry
	// aMark -- mark object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert Entry, Inserts a child object at the given index..
	// Parameters:
	//		aMark---aMark, Specifies a const CFOPMark& aMark object(Value).
	void InsertEntry(const CFOPMark& aMark);

	// Find mark with point.
	BOOL FindMarkPos(const int &nPoly, const int &nPt);

	// Delete mark
	// nNum -- number of the mark
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Mark, Deletes the given object.
	// Parameters:
	//		nNum---nNum, Specifies A integer value.
	void DeleteMark(int nNum);

	// Replace mark
	// aNewMark -- new mark
	// nNum -- number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Mark, .
	// Parameters:
	//		aNewMark---New Mark, Specifies a const CFOPMark& aNewMark object(Value).  
	//		nNum---nNum, Specifies A integer value.
	void ReplaceMark(const CFOPMark& aNewMark, int nNum);

	// operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	// Parameters:
	//		aLst---aLst, Specifies a const CFOPMarkList& aLst object(Value).
	void operator=(const CFOPMarkList& aLst);

	// Take snap rectangle of the all shapes within the marks.
	// rRect -- the result snap rectangle of all the shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Snap Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect& rRect object(Value).
	BOOL CalcSnapRect(FOPRect& rRect) const;

	// Take bounding rectangle of the all shapes within the marks.
	// rRect -- the result bounding rectangle of all the shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Bound Rectangle, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rRect---rRect, Specifies a FOPRect& rRect object(Value).
	BOOL CalcBoundRect(FOPRect& rRect) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Merge, .
	// Parameters:
	//		rSrcList---Source List, Specifies a const CFOPMarkList& rSrcList object(Value).
	// Merge a new list of marks to current list.
	// rSrcList -- marks list to be merged.
	void Merge(const CFOPMarkList& rSrcList);

};

//////////////////////////////////////////////////////////////////////////////////
// CFOLineConnect -- line connect, it is defined for link route only.

class CFOLineBridge;
 
//===========================================================================
// Summary:
//     The CFOLineConnect class derived from FOPLine
//      F O Line Connect
//===========================================================================

class FO_EXT_CLASS CFOLineConnect : public FOPLine
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOLineConnect---F O Line Connect, Specifies a E-XD++ CFOLineConnect object (Value).
	DECLARE_SERIAL(CFOLineConnect);

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Connect, Constructs a CFOLineConnect object.
	//		Returns A  value (Object).
	CFOLineConnect();

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Connect, Constructs a CFOLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	CFOLineConnect(const FOPPoint& ptStart, const FOPPoint& ptEnd);

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// nSegmentIndex -- segment index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Connect, Constructs a CFOLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStartPoint---Start Point, Specifies A integer value.  
	//		ptEndPoint---End Point, Specifies A integer value.  
	//		segmentIndex---segmentIndex, Specifies A integer value.
	CFOLineConnect(FOPPoint ptStartPoint, FOPPoint ptEndPoint, int segmentIndex);

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Connect, Constructs a CFOLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		line---Specifies a const FOPLine& line object(Value).
	CFOLineConnect(const FOPLine& line);

	// Sets this set of equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOLineConnect& value (Object).  
	// Parameters:
	//		prop---Specifies a const CFOLineConnect& prop object(Value).
	CFOLineConnect& operator=(const CFOLineConnect& prop);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Line Connect, Destructor of class CFOLineConnect
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOLineConnect();

public:

 
	// This member specify FOPContainer object.  
	FOPContainer m_bridges;
};

////////////////////////////////////////////////////////////
// CFOOrthogonalLineConnect -- the orthogonal line route object.

enum FO_Orth_Orign { Horizontal, Vertical };

 
//===========================================================================
// Summary:
//     The CFOOrthogonalLineConnect class derived from CFOLineConnect
//      F O Orthogonal Line Connect
//===========================================================================

class FO_EXT_CLASS CFOOrthogonalLineConnect : public CFOLineConnect
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOOrthogonalLineConnect---F O Orthogonal Line Connect, Specifies a E-XD++ CFOOrthogonalLineConnect object (Value).
	DECLARE_SERIAL(CFOOrthogonalLineConnect);

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Orthogonal Line Connect, Constructs a CFOOrthogonalLineConnect object.
	//		Returns A  value (Object).
	CFOOrthogonalLineConnect();

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Orthogonal Line Connect, Constructs a CFOOrthogonalLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStart---ptStart, Specifies A integer value.  
	//		ptEnd---ptEnd, Specifies A integer value.
	CFOOrthogonalLineConnect(const FOPPoint& ptStart, const FOPPoint& ptEnd) : CFOLineConnect(ptStart,ptEnd) { m_orientation = Horizontal; }

	// Constructor.
	// ptStart -- start point of the line.
	// ptEnd -- end point of the line.
	// nSegmentIndex -- segment index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Orthogonal Line Connect, Constructs a CFOOrthogonalLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptStartPoint---Start Point, Specifies A integer value.  
	//		ptEndPoint---End Point, Specifies A integer value.  
	//		segmentIndex---segmentIndex, Specifies A integer value.
	CFOOrthogonalLineConnect(FOPPoint ptStartPoint, FOPPoint ptEndPoint, int segmentIndex) : CFOLineConnect(ptStartPoint,ptEndPoint,segmentIndex) { m_orientation = Horizontal; }

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Orthogonal Line Connect, Constructs a CFOOrthogonalLineConnect object.
	//		Returns A  value (Object).  
	// Parameters:
	//		line---Specifies a const CFOLineConnect& line object(Value).
	CFOOrthogonalLineConnect(const CFOLineConnect& line)  : CFOLineConnect(line){m_orientation = Horizontal;}

	// Sets this set of equal to another. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOOrthogonalLineConnect& value (Object).  
	// Parameters:
	//		prop---Specifies a const CFOOrthogonalLineConnect& prop object(Value).
	CFOOrthogonalLineConnect& operator=(const CFOOrthogonalLineConnect& prop);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Orthogonal Line Connect, Destructor of class CFOOrthogonalLineConnect
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOOrthogonalLineConnect();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		&szOffset---&szOffset, Specifies a FOPSize &szOffset object(Value).
	// Move line
	void Move(FOPSize &szOffset);

	// Get Ortho offset.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ori Offset, Returns the specified value.
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		&szOffset---&szOffset, Specifies a const FOPSize &szOffset object(Value).
	FOPSize GetOriOffset( const FOPSize &szOffset );

	// Get orientation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Orign, Returns the specified value.
	//		Returns A FO_Orth_Orign value (Object).
	FO_Orth_Orign GetOrign() const { return m_orientation; }

	// Change orientation.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Orign, Sets a specify value to current class CFOOrthogonalLineConnect
	// Parameters:
	//		&origin---Specifies a const FO_Orth_Orign &origin object(Value).
	void SetOrign(const FO_Orth_Orign &origin) { m_orientation = origin; }

protected:

	// Origin of ling segment.
 
	// This member specify FO_Orth_Orign object.  
	FO_Orth_Orign m_orientation;
};

//////////////////////////////////////////////////////
// CFOLineBridge

 
//===========================================================================
// Summary:
//     The CFOLineBridge class derived from CObject
//      F O Line Bridge
//===========================================================================

class FO_EXT_CLASS CFOLineBridge : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOLineBridge---F O Line Bridge, Specifies a E-XD++ CFOLineBridge object (Value).
	DECLARE_SERIAL(CFOLineBridge);

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Bridge, Constructs a CFOLineBridge object.
	//		Returns A  value (Object).
	CFOLineBridge()	{}

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Line Bridge, Constructs a CFOLineBridge object.
	//		Returns A  value (Object).  
	// Parameters:
	//		*segment---A pointer to the CFOLineConnect  or NULL if the call failed.  
	//		offset---Specifies A float value.
	CFOLineBridge( CFOLineConnect *segment, float offset )
	{
		m_segmentIntersecting = segment;
		m_fOffset = offset;
	}

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Line Bridge, Destructor of class CFOLineBridge
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOLineBridge() {}

public:
	// Line intersecting
 
	// Intersecting, This member maintains a pointer to the object CFOLineConnect.  
	CFOLineConnect *m_segmentIntersecting;

	// Offset.
 
	// Offset, This member specify The float keyword designates a 32-bit floating-point number.  
	float m_fOffset;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLINE_H__348324AB_F10B_4057_9001_0CF609661294__INCLUDED_)
