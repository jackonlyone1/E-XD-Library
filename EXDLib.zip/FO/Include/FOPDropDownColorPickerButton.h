//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDROPDOWNCOLORPICKERBUTTON_H__C50BDF51_F0D2_406B_BA1C_2E692EE07ED8__INCLUDED_)
#define AFX_FOPDROPDOWNCOLORPICKERBUTTON_H__C50BDF51_F0D2_406B_BA1C_2E692EE07ED8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDropDownColorPickerButton.h : header file
//

#include "FOPDropColorPickerDrawPanel.h"
#include "FOPDropDownButtonBase.h"
#include "FOPPickerBaseWnd.h"

/////////////////////////////////////////////////////////////////////////////
// FOPDropDownColorPickerButton window
void FO_API_DECL AFXAPI DDX_ColorDropDown(CDataExchange *pDX, int nIDC, COLORREF& crColor);

 
//===========================================================================
// Summary:
//     The FOPDropDownColorPickerButton class derived from FOPDropDownButtonBase
//      O P Drop Down Color Picker Button
//===========================================================================

class FO_EXT_CLASS FOPDropDownColorPickerButton : public FOPDropDownButtonBase, FOPDropColorPickerCallback
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPDropDownColorPickerButton---O P Drop Down Color Picker Button, Specifies a FOPDropDownColorPickerButton object(Value).
	DECLARE_DYNCREATE(FOPDropDownColorPickerButton);

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Drop Down Color Picker Button, Constructs a FOPDropDownColorPickerButton object.
	//		Returns A  value (Object).
	FOPDropDownColorPickerButton();

// Attributes
public:
	// Drop down wnd
 
	// Drop Window, This member specify FOPPickerBaseWnd object.  
	FOPPickerBaseWnd			m_DropWnd;

	// Auto draw impl
 
	// Automatic Draw Impl, This member maintains a pointer to the object FOPDropColorPickerDrawPanel.  
	FOPDropColorPickerDrawPanel	*pAutoDrawImpl;

	// Draw impl
 
	// Draw Impl, This member maintains a pointer to the object FOPDropColorPickerDrawPanel.  
	FOPDropColorPickerDrawPanel*	pDrawImpl;

	// Color value.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF					m_crColor;

	// Palette
 
	// This member specify CPalette object.  
	CPalette					Palette;

	// Create palette
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Palette, You construct a FOPDropDownColorPickerButton object in two steps. First call the constructor, then call Create, which creates the object.

	void						CreatePalette();
// Operations
public:

	// Share draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Share Draw Impl, .
	// Parameters:
	//		button---Specifies a FOPDropDownColorPickerButton& button object(Value).
	void						ShareDrawImpl(FOPDropDownColorPickerButton& button);

	// Do realize palette
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Realize Palette, Do a event. 
	//		Returns a int type value.  
	// Parameters:
	//		foreground---Specifies A Boolean value.
	int							DoRealizePalette(BOOL  foreground);

	// Get color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF 					GetColor()	const	{	return(m_crColor);		}

	// Automatic color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Automatic Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetAutomaticColor();

	// Set automatic color value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Color, Sets a specify value to current class FOPDropDownColorPickerButton
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetAutomaticColor(const COLORREF &crColor);

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A const FOPDropColorPickerDrawPanel& value (Object).
	const FOPDropColorPickerDrawPanel&	GetDrawImpl() const	{	return *pDrawImpl;	}

	// Get draw impl
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Impl, Returns the specified value.
	//		Returns A FOPDropColorPickerDrawPanel& value (Object).
	FOPDropColorPickerDrawPanel&	GetDrawImpl()		{	return *pDrawImpl;	}

	// Get minimum height
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Minimum Height, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int					GetMinimumHeight() const;

	// Set color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class FOPDropDownColorPickerButton
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	void						SetColor(COLORREF crColor);

	// Do drop down picker action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Drop Down, Do a event. 

	void						DoDropDown();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		rc---Specifies A CRect type value.  
	//		bDraw---bDraw, Specifies A Boolean value.
	// Draw state
	void						Draw(CDC& dc, const CRect& rc, BOOL bDraw);

	// callbacks
	// Do when color change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		crColor---crColor, Specifies A 32-bit COLORREF value used as a color value.
	virtual void				OnWellColorChange(const COLORREF& crColor);

	// Do when cancel action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCancel();

	// Do when choose custom color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Custom Color, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellCustomColor();

	// Do when choose color none
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color None, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellColorNone();

	// Do when choose color automatic
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Color Automatic, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellColorAuto();

	// Do when choose button two.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Well Button Two, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void				OnWellButtonTwo();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FOPDropDownColorPickerButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Drop Down Color Picker Button, Destructor of class FOPDropDownColorPickerButton
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPDropDownColorPickerButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(FOPDropDownColorPickerButton)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query New Palette, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL				OnQueryNewPalette();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Palette Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pFocusWnd---Focus Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void				OnPaletteChanged(CWnd* pFocusWnd);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDROPDOWNCOLORPICKERBUTTON_H__C50BDF51_F0D2_406B_BA1C_2E692EE07ED8__INCLUDED_)
