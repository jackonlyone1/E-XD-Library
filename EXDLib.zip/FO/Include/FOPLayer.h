//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPLAYER_H__93DFF5DD_4866_4770_AFEA_F97728C79360__INCLUDED_)
#define AFX_FOPLAYER_H__93DFF5DD_4866_4770_AFEA_F97728C79360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPLayer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPLayer object -- layer object, you can place a list of shapes within one layer.

 
//===========================================================================
// Summary:
//     The CFOPLayer class derived from CObject
//      F O P Layer
//===========================================================================

class FO_EXT_CLASS CFOPLayer : public CObject  
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLayer---F O P Layer, Specifies a E-XD++ CFOPLayer object (Value).
	DECLARE_SERIAL(CFOPLayer);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer, Constructs a CFOPLayer object.
	//		Returns A  value (Object).
	CFOPLayer();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor. 
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layer, Constructs a CFOPLayer object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPLayer& source object(Value).
	CFOPLayer(const CFOPLayer& source);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPLayer& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPLayer& source object(Value).
	CFOPLayer& operator=(const CFOPLayer& source);

	//-----------------------------------------------------------------------
	// Summary:
	// == operator.
	// aCmp -- target compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPLayer& aCmp object(Value).
	BOOL operator==(const CFOPLayer& aCmp) const;

	//-----------------------------------------------------------------------
	// Summary:
	// != operator.
	// aCmp -- target compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aCmp---aCmp, Specifies a const CFOPLayer& aCmp object(Value).
	BOOL operator!=(const CFOPLayer& aCmp) const
	{
		return !operator == (aCmp);
	}

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPLayer,or NULL if the call failed
	// Create a duplicate copy of this object. 
	virtual CFOPLayer* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Layer, Destructor of class CFOPLayer
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLayer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Store the data to the file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize(CArchive &ar);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Get Object Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectName()	const;

	// Get Object Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Name, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectName(
		// Specify the name of shape.
		const CString &str
		);

	// Get Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get I D, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetID()	const;

	// Set Type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set I D, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetID(const UINT &nT);

	// Is It Lock
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsLock() const;

	// Lock Componet
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Component, .
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void		LockComp(const BOOL &bL);

	// Is It Visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsVisible() const;

	// Set Visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Visible, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bV---&bV, Specifies A Boolean value.
	void		SetVisible(const BOOL &bV);


	///////////////////////////////////////
	// Lock width and height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Resize Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bLock---&bLock, Specifies A Boolean value.
	void		SetResizeProtect(const BOOL &bLock) { m_bResizeProtect = bLock; }

	// Is width and height locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Resize Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsResizeProtect() const	{ return m_bResizeProtect; }


	////////////////////////////////////////
	// Is select protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Select Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsSelectProtect() const { return m_bSelectProtect; }

	// Set select protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Select Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bAllow---&bAllow, Specifies A Boolean value.
	void		SetSelectProtect(const BOOL &bAllow) { m_bSelectProtect = bAllow; }


	///////////////////////////////////////
	// Is moving protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Move Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsMoveProtect() const { return m_bMoveProtect; }

	// Set moving protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Move Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bProt---&bProt, Specifies A Boolean value.
	void		SetMoveProtect(const BOOL &bProt) { m_bMoveProtect = bProt; }


	//////////////////////////////////////
	// Is rotating protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Rotate Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsRotateProtect() const { return m_bRotateProtect; }

	// Set rotating protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rotate Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bProt---&bProt, Specifies A Boolean value.
	void		SetRotateProtect(const BOOL &bProt) { m_bRotateProtect = bProt; }


	//////////////////////////////////////
	// Is printing protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Print Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsPrintProtect() const { return m_bPrintProtect; }

	// Set printing protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Print Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bProt---&bProt, Specifies A Boolean value.
	void		SetPrintProtect(const BOOL &bProt) { m_bPrintProtect = bProt; }


	//////////////////////////////////////
	// Is copying protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Copy Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsCopyProtect() const { return m_bCopyProtect; }

	// Set copying protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Copy Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bProt---&bProt, Specifies A Boolean value.
	void		SetCopyProtect(const BOOL &bProt) { m_bCopyProtect = bProt; }


	//////////////////////////////////////
	// Is deleting protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Delete Protect, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsDeleteProtect() const { return m_bDeleteProtect; }

	// Set deleting protect.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Delete Protect, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bProt---&bProt, Specifies A Boolean value.
	void		SetDeleteProtect(const BOOL &bProt) { m_bDeleteProtect = bProt; }

	/////////////////////////////////////

	// Set color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetColor() const { return m_crColor; }

	// Change color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetColor(const COLORREF &crColor) { m_crColor = crColor; }

	// Is it active;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Active, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsActive() const { return m_bActive; }

	// Active this layer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Active, Sets a specify value to current class CFOPLayer
	// Parameters:
	//		&bActive---&bActive, Specifies A Boolean value.
	void		SetActive(const BOOL &bActive) { m_bActive = bActive; }

public:

	// Name of the layer.
 
	// Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strName;

	// Id of the layer.
 
	// I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nID;

	// Is Object Lock or not
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// Is Visible or not.
 
	// Visible, This member sets TRUE if it is right.  
	BOOL			m_bVisible;

	// Color of the layer.
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;

	// Activate or not.
 
	// Active, This member sets TRUE if it is right.  
	BOOL			m_bActive;

	///////////////////////////////////////
	// Lock width and height.
 
	// Resize Protect, This member sets TRUE if it is right.  
	BOOL			m_bResizeProtect;

	// Select protect.
 
	// Select Protect, This member sets TRUE if it is right.  
	BOOL			m_bSelectProtect;

	// Moving protect.
 
	// Move Protect, This member sets TRUE if it is right.  
	BOOL			m_bMoveProtect;

	// Rotating protect.
 
	// Rotate Protect, This member sets TRUE if it is right.  
	BOOL			m_bRotateProtect;

	// Print protect.
 
	// Print Protect, This member sets TRUE if it is right.  
	BOOL			m_bPrintProtect;

	// Protect for copying.
 
	// Copy Protect, This member sets TRUE if it is right.  
	BOOL			m_bCopyProtect;

	// Protect for deleting.
 
	// Delete Protect, This member sets TRUE if it is right.  
	BOOL			m_bDeleteProtect;

	
};

// list of layers.
typedef CTypedPtrList<CObList, CFOPLayer*> CFOPLayerList;

_FOLIB_INLINE	BOOL CFOPLayer::IsLock() const                       
{ 
	return m_bLock; 
}

_FOLIB_INLINE	void CFOPLayer::LockComp(const BOOL &bL)              
{ 
	m_bLock = bL;
}

_FOLIB_INLINE	CString CFOPLayer::GetObjectName()	const
{ 
	return m_strName;
}

_FOLIB_INLINE	void CFOPLayer::SetObjectName(const CString &str)	
{ 
	m_strName = str;
}

_FOLIB_INLINE	UINT CFOPLayer::GetID() const		
{
	return m_nID; 
}

_FOLIB_INLINE	void CFOPLayer::SetID(const UINT &nT)			
{ 
	m_nID = nT; 
}

_FOLIB_INLINE	BOOL CFOPLayer::IsVisible() const					
{ 
	return m_bVisible; 
}

_FOLIB_INLINE	void CFOPLayer::SetVisible(const BOOL &bV)			
{ 
	m_bVisible = bV; 
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPLAYER_H__93DFF5DD_4866_4770_AFEA_F97728C79360__INCLUDED_)
