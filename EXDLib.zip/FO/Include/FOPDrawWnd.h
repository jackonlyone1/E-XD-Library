//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPDRAWWND_H__BDEE03FF_40C6_484B_A1A1_F6F664D891A2__INCLUDED_)
#define AFX_FOPDRAWWND_H__BDEE03FF_40C6_484B_A1A1_F6F664D891A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPDrawWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPDrawWnd window

#include "FOPCanvasCore.h"
#include "FOPCanvasShell.h"
#include "FOPMenuWndImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CFOPPrintPreview view window.

class CFOPDrawWnd;
 
//===========================================================================
// Summary:
//     The CFOPPrintPreview class derived from CView
//      F O P Print Preview
//===========================================================================

class FO_EXT_CLASS CFOPPrintPreview : public CView
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Print Preview, Constructs a CFOPPrintPreview object.
	//		Returns A  value (Object).
	CFOPPrintPreview();           // protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPPrintPreview---F O P Print Preview, Specifies A integer value.
	DECLARE_DYNCREATE(CFOPPrintPreview)
		
		// Attributes
public:
 
	//  m_p Ctrl, This member maintains a pointer to the object CFOPDrawWnd.  
	CFOPDrawWnd *m_pCtrl;
 
	// Old Frame, This member maintains a pointer to the object CFrameWnd.  
	CFrameWnd *m_pOldFrame;
	
	// Operations
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On File Print Preview, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFilePrintPreview();
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPPrintPreview)
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Print Preview, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.  
	//		point---Specifies A integer value.  
	//		pView---pView, A pointer to the CPreviewView or NULL if the call failed.
	virtual void OnEndPrintPreview(CDC* pDC, CPrintInfo* pInfo, POINT point, CPreviewView* pView);
	//}}AFX_VIRTUAL
	
	
	// Implementation
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Print Preview, Destructor of class CFOPPrintPreview
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPPrintPreview();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPPrintPreview)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPDrawWnd -- the core class of window control based canvas, this is a CWnd derived
//			class, with this class, you can place the canvas of E-XD++ on any exist CWnd based
//			control, such as control bar. All the other details on this canvas are the same
//			with CFODrawView.
//
//			Using Create ro AttachWndCtrl to create this canvas.
//			Call OpenDoucment or SaveDocument methods to handle the file openning or saving.
//

 
//===========================================================================
// Summary:
//     The CFOPDrawWnd class derived from CWnd
//      F O P Draw Window
//===========================================================================

class FO_EXT_CLASS CFOPDrawWnd : public CWnd, public CFOPCanvasCore
{
// Construction
protected:
	// DECLARE DYNAMIC CREATE
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPDrawWnd---F O P Draw Window, Specifies a E-XD++ CFOPDrawWnd object (Value).
	DECLARE_DYNCREATE(CFOPDrawWnd)

protected:
	// Implementation Variables
	// pointer of the horizontal scrollbar.
 
	// Horizontal Scroll Bar, This member maintains a pointer to the object CScrollBar.  
	CScrollBar*			maHorzScrollBar;

	// pointer of the vertical scrollbar
 
	// Vertical Scroll Bar, This member maintains a pointer to the object CScrollBar.  
	CScrollBar*			maVertScrollBar;

	// pointer of the corner size box.
 
	// Window Corner Box, This member maintains a pointer to the object CScrollBar.  
	CScrollBar*			m_pWndCornerBox;

	// horizontal scroll line pixel.
 
	// Line Scroll, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nLineScroll;

	// horizontal scroll width.
 
	// H Scroll, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_cyHScroll;

	// vertical scroll height.
 
	// V Scroll, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_cxVScroll;

	// be init update
 
	// Has Inited, This member sets TRUE if it is right.  
	BOOL				m_bHasInited;

	// optimized redraw
 
	// Redrawed, This member sets TRUE if it is right.  
	BOOL				m_bRedrawed;

	// be center or not.
 
	// View Center, This member sets TRUE if it is right.  
	BOOL				m_bViewCenter;

	// auto timer id
 
	// Window  I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	static int			m_nWndCtrlID;

	// horizontal scrollbar visible or not.
 
	// Horizontal Visible, This member sets TRUE if it is right.  
	BOOL				m_bHorzVisible;

	// vertical scrollbar visible or not.
 
	// Vertical Visible, This member sets TRUE if it is right.  
	BOOL				m_bVertVisible;

	// With scroll bar support or not.
 
	// With Scroll Bar, This member sets TRUE if it is right.  
	BOOL				m_bWithScrollBar;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Draw Window, Constructs a CFOPDrawWnd object.
	//		Returns A  value (Object).
	CFOPDrawWnd();

protected:
	// Draw message shell.
 
	// Message Shell, This member maintains a pointer to the object CFOPCanvasShell.  
	CFOPCanvasShell *m_pMsgShell;

public:
	// Obtain the pointer of the message shell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Message Shell, Returns the specified value.
	//		Returns a pointer to the object CFOPCanvasShell ,or NULL if the call failed
	CFOPCanvasShell *GetMsgShell() { return m_pMsgShell; }

	// Create canvas shell.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Canvas Shell, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPCanvasShell ,or NULL if the call failed
	virtual CFOPCanvasShell *CreateCanvasShell();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	// dwStyle -- style of the window,do not use WS_VSCROLL and WS_HSCROLL
	// rect -- rectangle of the window.
	// pParentWnd -- pointer of the window.
	// nID -- ID value of the window control
	virtual BOOL Create( DWORD dwStyle, const RECT& rect,
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	// Create a new top most window.
	// rect -- rectangle of the window.
	// lpszTitle -- title of this window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Top Most, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rect---Specifies A CRect type value.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		lpszTitle---lpszTitle, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL CreateTopMost( const CRect& rect,
		CWnd* pParentWnd, LPCTSTR lpszTitle );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwStyleEx---Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	// dwStyle -- style of the window,do not use WS_VSCROLL and WS_HSCROLL
	// dwStyleEx -- extend style of the window.
	// rect -- rectangle of the window.
	// pParentWnd -- pointer of the window.
	// nID -- ID value of the window control
	virtual BOOL Create( DWORD dwStyle, DWORD dwStyleEx, const RECT& rect, 
		CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		rect---Specifies a const RECT& rect object(Value).  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.  
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pContext---pContext, A pointer to the CCreateContext or NULL if the call failed.
	// Create a new window.
	// lpszClassName -- name of the class.
	// lpszWindowName -- name of the window.
	// dwStyle -- style of the window,do not use WS_VSCROLL and WS_HSCROLL
	// rect -- rectangle of the window.
	// pParentWnd -- pointer of the window.
	// nID -- ID value of the window control
	virtual BOOL Create( LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
		DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	// Creation new window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Attach Window , Attaches this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		uID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pParentWnd---Parent Window, A pointer to the CWnd or NULL if the call failed.
	virtual BOOL AttachWndCtrl( UINT uID, CWnd* pParentWnd );

	// Save Document to a specify file.
	// lpszPathName -- name of the file with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open Document from a specify file.
	// lpszPathName -- name of the file with full path.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);

	// Do update scrollbars.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Scroll Bars, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoUpdateScrollBars();

	// Obtain scroll range.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Range Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		lpMinPos---Minimize Position, Specifies a LPINT lpMinPos object(Value).  
	//		lpMaxPos---Maximize Position, Specifies a LPINT lpMaxPos object(Value).
	virtual void GetScrollRangeExt(int nBar, LPINT lpMinPos, LPINT lpMaxPos);

	// Register window class.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Register Class, Do a event. 
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		stringClass---stringClass, Specifies A CString type value.
	BOOL DoRegisterClass(CString stringClass);
public:

	// Create extend.
	// dwExStyle -- extend style of the window.
	// lpszClassName -- name of the class.
	// lpszWindowName -- name of the window.
	// dwStyle -- style of the window,do not use WS_VSCROLL and WS_HSCROLL
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Ex, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		dwExStyle---Ex Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		lpszClassName---Class Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszWindowName---Window Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.  
	//		hWndParent---Window Parent, Specifies a HWND hWndParent object(Value).  
	//		nIDorHMenu---I Dor H Menu, Specifies a HMENU nIDorHMenu object(Value).  
	//		lpParam---lpParam, Specifies a LPVOID lpParam = NULL object(Value).
	virtual BOOL CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
		                   int x, int y, int cx, int cy, HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

public:

	// Change the optimize option that to be used for update the window or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Redrawed State, Sets a specify value to current class CFOPDrawWnd
	// Parameters:
	//		bOptimize---bOptimize, Specifies A Boolean value.
	void SetRedrawedState(BOOL bOptimize = TRUE) { m_bRedrawed = bOptimize; }

	
	// Obtain the optimize state for redrawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redrawed State, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetRedrawedState() { return m_bRedrawed; }

	// Show scrollbar state.
	// bHorz -- showing horz scrollbar or not.
	// bVert -- showing vertical scrollbar ot not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Scroll Bars, Call this function to show the specify object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bHorz---bHorz, Specifies A Boolean value.  
	//		bVert---bVert, Specifies A Boolean value.
	BOOL ShowScrollBars(BOOL bHorz=TRUE,BOOL bVert=TRUE);

	// Obtain the pointer of the horz scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Scroll Bar, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetHScrollBar();
	
	// Obtain the pointer of the vertical scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get V Scroll Bar, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetVScrollBar();

	// Obtain the pointer of the horz scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get H Scroll Bar1, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetHScrollBar1() const;
	
	// Obtain the pointer of the vertical scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get V Scroll Bar1, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* GetVScrollBar1() const;

	// Does it sharing scrollbar with parent.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Share Scroll, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsShareScroll() const;
	
	// Obtain the pointer of the sizing box.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Corner Box, Returns the specified value.
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	CScrollBar* GetCornerBox() { return m_pWndCornerBox; }

	// Change the scrollbar line pixels.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Line, Sets a specify value to current class CFOPDrawWnd
	// Parameters:
	//		nPixel---nPixel, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetScrollLine(UINT nPixel) { m_nLineScroll = nPixel; }
	
	// Obtain the scrollbar line pixels
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Line, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetScrollLine() { return m_nLineScroll; }

	// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitialUpdate();

	// Set the origin of an object.
	// x -- new x origin value
	// y -- new y origin value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Container Origin, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual CPoint SetContainerOrigin(int x, int y);

	// Change the log Origin.
	// x -- x value of the starting position.
	// y -- y value of the starting position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Origin, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual CPoint SetLogOrigin(int x, int y);

	// Change the view extent size
	// cx -- horizontal size of the view.
	// cy -- vertical size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Extents, Sets a specify value to current class CFOPDrawWnd
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	CSize SetViewExtents(int cx, int cy);

	// Change the log extent
	// cx -- cx extent value
	// cy -- cy extent value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Extents, Sets a specify value to current class CFOPDrawWnd
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	CSize SetLogExtents(int cx, int cy);

	// Set the width and height of an object. 
	// cx -- cx container value
	// cy -- cy container value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Container Size, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual CSize SetContainerSize(int cx, int cy);

	// Change log size
	// cx -- cx logical value
	// cy -- cy logical value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Size, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual CSize SetLogSize(int cx, int cy);


	// Do prepare dc with ruler support.
	// pDC -- pointer of the DC.
	// nRulerType -- type of the ruler,it must be one of the following value:
	//enum FOPRulerType
	// {
	//	FOP_HORZ_RULER,  Horz ruler
	//	FOP_VERT_RULER  // Vert ruler
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Ruler D C, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&nRulerType---Ruler Type, Specifies a const FOPRulerType &nRulerType object(Value).
	virtual void OnPrepareRulerDC(CDC* pDC, const FOPRulerType &nRulerType);

	// Change the log scaling
	// dXScale -- x scale value
	// dYScale -- y scale value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Logical Zoom Value, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		dXScale---X Scale, Specifies a double dXScale = 1.0 object(Value).  
	//		dYScale---Y Scale, Specifies a double dYScale = 1.0 object(Value).
	virtual CSize SetLogZoomValue(double dXScale = 1.0,double dYScale = 1.0);


	// Change the virtual size
	// cx -- cx virtual size of the view
	// cy -- cy virtual size of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Size, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	virtual void SetVirtualSize(int cx, int cy);

	// Change the virtual origin
	// x -- x value of the origin
	// y -- y value of the origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Virtual Origin, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.
	virtual void SetVirtualOrigin(int x, int y);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	// Draw full view.
	// pDC -- pointer of the DC
	virtual void Draw(CDC* pDC);

	// Invalidate when scrollbar changing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invlidate Scroll Moving, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bRepairNow---Repair Now, Specifies A Boolean value.
	virtual void InvlidateScrollMoving(BOOL bRepairNow = TRUE);

	// Create new scrollbars.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Scroll Bars, You construct a CFOPDrawWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL CreateScrollBars();
	
	// Set scrollbars's ranges
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Bar Ranges, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetScrollBarRanges();
	
	// Set page size of the scrollbars
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Bar Page Sizes, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetScrollBarPageSizes();
	
	// Set page size for scrollbars
	// szLog -- log size of the scrollbars page size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Bar Page Sizes, Sets a specify value to current class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		szLog---szLog, Specifies A CSize type value.
	virtual void SetScrollBarPageSizes(CSize szLog);
	
	// When showing full page size,all the scrollbars should be un visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide Scroll Bars With Full Page Size, Hides the objects by removing it from the display screen. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL HideScrollBarsWithFullPageSize();
	
	// Reset the position of the scrollbars.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Calculate Scroll Bars, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptLogOrigin---Logical Origin, Specifies A CPoint type value.
	virtual void ReCalcScrollBars(CPoint ptLogOrigin);
	
	// Reset scrollbars rectangles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Calculate Scroll Bars, .

	void ReCalcScrollBars() { ReCalcScrollBars(CPoint(0,0)); }

	// Obtain the scrollbar's ID value
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Scroll Bar I D, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.
	virtual UINT GetNextScrollBarID() 
		{ return CFOPDrawWnd::m_nWndCtrlID++; }

	// Create scrollbar object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Alloc Scroll Bar,  Alloc the specify space for this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed
	virtual CScrollBar* AllocScrollBar() { return new CScrollBar; }

	// Doing something when horz scrollbar moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll, Called when the user clicks the horizontal scroll bar of CWnd.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nScrollCode---Scroll Code, Specifies A integer value.  
	//		nPos---nPos, Specifies a short nPos object(Value).  
	//		hwndScrollBar---Scroll Bar, Specifies a HWND hwndScrollBar object(Value).
	virtual BOOL OnHScroll(int nScrollCode,short nPos,HWND hwndScrollBar);

	// Doing something when vertical scrollbar moving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nScrollCode---Scroll Code, Specifies A integer value.  
	//		nPos---nPos, Specifies a short nPos object(Value).  
	//		hwndScrollBar---Scroll Bar, Specifies a HWND hwndScrollBar object(Value).
	virtual BOOL OnVScroll(int nScrollCode,short nPos,HWND hwndScrollBar);

	// Prepare dc
	// pDC -- pointer of the DC
	// bZoom -- need zoom or not
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare Draw D C, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bZoom---bZoom, Specifies A Boolean value.
	virtual void PrepareDrawDC(CDC* pDC, const BOOL bZoom = TRUE);

	// Mouse wheel data
#if _MFC_VER > 0x0420
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		fwKeys---fwKeys, Specifies A integer value.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		xPos---xPos, Specifies a short xPos object(Value).  
	//		yPos---yPos, Specifies a short yPos object(Value).
	virtual BOOL OnMouseWheel(int fwKeys,short zDelta,short xPos,short yPos);
#endif

	// Is scrollbar visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get S B Visible, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bHorz---bHorz, Specifies A Boolean value.
	BOOL GetSBVisible(BOOL bHorz);

	// Automatic showing scrollbar if it beyond the logical bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do When Beyond Bounds, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoWhenBeyondBounds();

	// Invalidate a specify rectangle.
	// You must call DocToClient to convert rcPos at first.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Invalidate Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		bErase---bErase, Specifies A Boolean value.  
	//		bRedrawNow---Redraw Now, Specifies A Boolean value.
	virtual void FOPInvalidateRect(const CRect& rcPos, BOOL bErase = TRUE, BOOL bRedrawNow = FALSE);

	// Get Extend drawing size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extend Draw Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetExtendDrawSize();

public:

	// Obtain the default virtual origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Canvas Origin Offset, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetCanvasOriginOffset() const;

protected:

	// Obtain additional canvas offset size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Additional Canvas Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetAddiCanvasSize();

	// Obtain the pointer of menu parent window.
	// parent -- pointer of window.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu Parent Window, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CWnd ,or NULL if the call failed  
	// Parameters:
	//		parent---A pointer to the CFOPCanvasCore or NULL if the call failed.
	virtual CWnd * GetMenuParentWnd(CFOPCanvasCore* parent);

// Attributes
public:
	// Obtain the true client rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get True Client Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rc---Specifies A CRect type value.
	virtual void GetTrueClientRectangle(CRect &rc);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bErase---bErase, Specifies A Boolean value.  
	//		bRedrawNow---Redraw Now, Specifies A Boolean value.
	// Invalidate total window.
	virtual void Invalidate(BOOL bErase = TRUE, BOOL bRedrawNow = FALSE);

	// Invalidate a specify rectangle.
	// You must call DocToClient to convert rcPos at first.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, Invalidates the specify area of object. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		bErase---bErase, Specifies A Boolean value.  
	//		bRedrawNow---Redraw Now, Specifies A Boolean value.
	virtual void InvalidateRect(const CRect& rcPos, BOOL bErase = TRUE, BOOL bRedrawNow = FALSE);

	// Set cursor with ID.
	// nID -- cursor resource ID
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void FOSetCursor(UINT nID);

	// Set system cursor.
	// lpszCursor -- resource of cursor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Set System Cursor, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszCursor---lpszCursor, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual void FOSetSystemCursor(LPCTSTR lpszCursor);

	// Update current scroll bar position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateScrollBarPos();

	// Obtain the size of the device.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Device Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetDevSize() const;

	// Obtain the size of the scrollbar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get F O P Scroll Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.
	virtual CSize GetFOPScrollPosition();

	// Obtain the drop target pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Drop Target Pointer, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object COleDropTarget,or NULL if the call failed
	virtual COleDropTarget* GetDropTargetPointer() const;

	// Update scroll size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Scroll Bar Size, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateScrollBarSize();

	// Is view be center mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Center Mode, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsCenterMode() const;

	// Set view mode.
	// bCenter -- center of the view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set View Mode, Sets a specify value to current class CFOPDrawWnd
	// Parameters:
	//		&bCenter---&bCenter, Specifies A Boolean value.
	void SetViewMode(const BOOL &bCenter);

	// Obtain the dlg code
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Dialog Code, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a UINT type value.  
	// Parameters:
	//		uiDefaultVal---Default Value, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual UINT DoGetDlgCode(UINT uiDefaultVal);

	// do printing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print, Do a event. 

	void DoPrint();

	// Do print preview.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Print Preview, .

	void PrintPreview();
	
	// document template for print preview.
 
	// Template, This member maintains a pointer to the object CSingleDocTemplate.  
	CSingleDocTemplate* m_pTemplate;

	// Is preview mode or not.
 
	// Print Preview, This member sets TRUE if it is right.  
	BOOL m_bPrintPreview;

	// Update data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( 
		// Model pointer.
		CObject * pModel,
		// Hint value.
		LPARAM lHint, CObject*pHint);

	// Show or hide ruler bar
	// bVisible -- visible or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Rulers, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&bVisible---&bVisible, Specifies A Boolean value.
	virtual void ShowRulers(const BOOL &bVisible);

	// Get scroll bar control.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Bar , Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CScrollBar,or NULL if the call failed  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.
	virtual CScrollBar* GetScrollBarCtrl(int nBar) const;

	// Context help.
	// this notification is called as result of context help bing activated
	// over the UG area and should return context help ID to be displayed
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Context Help I D, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	// Parameters:
	//		section---Specifies A integer value.
	virtual DWORD OnGetContextHelpID(int section );

	// Move to center origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To Center, .

	void MoveToCenter();

	// With scrollbar or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hide All Scroll Bars, Hides the objects by removing it from the display screen. 

	void HideAllScrollBars();


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPDrawWnd)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Enter, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragEnter(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Leave, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnDragLeave();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drag Over, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A DROPEFFECT value (Object).  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dwKeyState---Key State, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		point---Specifies A CPoint type value.
	virtual DROPEFFECT OnDragOver(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Drop, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDataObject---Data Object, A pointer to the COleDataObject or NULL if the call failed.  
	//		dropEffect---dropEffect, Specifies a DROPEFFECT dropEffect object(Value).  
	//		point---Specifies A CPoint type value.
	virtual BOOL OnDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnWndMsg( UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO or NULL if the call failed.
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Scroll By, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		sizeScroll---sizeScroll, Specifies A CSize type value.  
	//		bDoScroll---Do Scroll, Specifies A Boolean value.
	virtual BOOL OnScrollBy(CSize sizeScroll, BOOL bDoScroll = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

	//Activate View
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActiveView---Active View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActiveView, CView* pDeactiveView);

protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);
	
	// Image data.
	CFOPMenuTheme *		m_pMenuData;
	
// Implementation
public:
	//Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Draw Window, Destructor of class CFOPDrawWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPDrawWnd();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	//AssertValid
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	//Dump
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOPDrawWnd)
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.
	
	afx_msg void OnClose();
	

	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Select All, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditSelectAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Select All, Called to notify a view that its document has been modified.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	afx_msg void OnUpdateEditSelectAll(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpCreateStruct---Create Struct, Specifies a LPCREATESTRUCT lpCreateStruct object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy, Called when CWnd is being destroyed.

	afx_msg void OnDestroy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctl Color, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg HBRUSH value (Object).  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nCtlColor---Ctl Color, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On M Button Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Cursor, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		nHitTest---Hit Test, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Clear, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditClear();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Clear, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditClear(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Copy, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditCopy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Copy, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Cut, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditCut();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Cut, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Paste, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditPaste();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Paste, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Bottom, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignBottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Bottom, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignBottom(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Center, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Center, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignCenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Inview Hor, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignInviewHor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Inview Hor, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignInviewHor(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Inview Ver, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignInviewVer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Inview Ver, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignInviewVer(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Left, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Left, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignLeft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Edit Spot, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoEditSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Edit Spot, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoEditSpot(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Design, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDesign();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Design, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDesign(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Right, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Right, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignRight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Top, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignTop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Top, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignTop(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Rotate, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRotate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Rotate, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRotate(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Flip Horizontal, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFlipHorz();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Flip Horizontal, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFlipHorz(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Flip Vertical, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFlipVert();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Flip Vertical, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFlipVert(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Rotate Left, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRotateLeft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Rotate Left, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRotateLeft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Rotate Right, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRotateRight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Rotate Right, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRotateRight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Vcenter, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignVcenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Vcenter, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignVcenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Back, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBack();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Back, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBack(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Backward, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBackward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Backward, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBackward(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCustomProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Custom Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCustomProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Text Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTextProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Text Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoTextProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Key Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoKeyProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Key Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoKeyProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Bullets, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBullets();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Bullets, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBullets(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Line Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLineProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Line Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLineProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Fill Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFillProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Fill Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFillProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Event Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoEventProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Event Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoEventProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shadow Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShadowProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shadow Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShadowProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Components Select, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCompsSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Components Select, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCompsSelect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Form Setting, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFormSetting();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Form Setting, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFormSetting(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Print Header Footer, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPrintHeaderFooter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Print Header Footer, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPrintHeaderFooter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Forward, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoForward();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Forward, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoForward(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Front, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFront();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Front, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFront(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Grid, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGrid();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Grid, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGrid(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Margin, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoMargin();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Margin, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoMargin(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Size All, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSizeAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnTextEditNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Box Text Notify, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnEditBoxTextNotify(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Size All, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSizeAll(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Size Height, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSizeHeight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Size Height, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSizeHeight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Size Width, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSizeWidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Size Width, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSizeWidth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Space Across, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSpaceAcross();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Space Across, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSpaceAcross(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Space Down, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSpaceDown();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Space Down, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSpaceDown(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Tab Order, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTabOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Tab Order, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoTabOrder(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Button, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawButton();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Button, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawButton(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Tabel, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawTabel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Tabel, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawTabel(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRectangle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Rectangle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRectangle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Round Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRoundRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Round Rectangle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRoundRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Do Draw Image, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDoDrawImage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Do Draw Image, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDoDrawImage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Static, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawStatic();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Static, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawStatic(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Grid Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGridProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Grid Property, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGridProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Select, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawSelect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Select, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawSelect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo File Export, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFileExport();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo File Export, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFileExport(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Redo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditRedo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Redo, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Undo, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditUndo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Undo, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Clear All, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditClearAll();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Edit Clear All, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Ellipse, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Ellipse, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawEllipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Port, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPort();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Port, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPort(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Dimension Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawDimLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Dimension Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawDimLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Arc Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawArcLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Arc Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawArcLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Pie, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPie();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Pie, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPie(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Arrow Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawArrowLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Arrow Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawArrowLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Cross Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawCrossLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Cross Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawCrossLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Free Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawFreeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Free Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawFreeLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Free Close Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawFreeCloseLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Free Close Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawFreeCloseLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Arrow Bezier Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawArrowBezierLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Arrow Bezier Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawArrowBezierLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Polygon Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPolyLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Polygon Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPolyLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Polygon, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Polygon, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPolygon(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Round, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRound();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Round, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRound(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Close Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawCloseBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Close Bezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawCloseBezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Action Group, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoActionGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Action Group, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoActionGroup(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Action Un Group, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoActionUnGroup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Action Un Group, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoActionUnGroup(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Cmd Nudgeleft, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCmdNudgeleft();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Cmd Nudgeleft, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCmdNudgeleft(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Cmd Nudgeright, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCmdNudgeright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Cmd Nudgeright, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCmdNudgeright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Cmd Nudgetop, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCmdNudgetop();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Cmd Nudgetop, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCmdNudgetop(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Cmd Nudgebottom, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCmdNudgebottom();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Cmd Nudgebottom, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCmdNudgebottom(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Cmd Automatic Pan, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCmdAutoPan();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Cmd Automatic Pan, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCmdAutoPan(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Link, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Link, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Link Normal, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawLinkNormal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Link Normal, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawLinkNormal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Page Setup, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPageSetup();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O Lockcomp, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOLockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O Lockcomp, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFOLockcomp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O Grid Snap, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOGridSnap();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O Grid Snap, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFOGridSnap(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O Glue To Shape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOGlueToShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O Glue To Shape, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFOGlueToShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On F O Unlockcomp, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFOUnlockcomp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update F O Unlockcomp, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFOUnlockcomp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnTextEditChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Box Text Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnEditBoxTextChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Pots, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPots();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Pots, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPots(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Zoom50, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewZoom50();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Zoom50, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewZoom50(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Zoom75, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewZoom75();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Zoom75, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewZoom75(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Zoom100, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewZoom100();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Zoom100, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewZoom100(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Zoom150, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewZoom150();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Zoom150, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewZoom150(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Zoom200, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewZoom200();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Zoom200, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewZoom200(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Scaleadd25, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewScaleadd25();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Scaleadd25, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewScaleadd25(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Scalesub25, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewScalesub25();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Scalesub25, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewScalesub25(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Zoom Fitselect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoZoomFitselect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Zoom Fitselect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoZoomFitselect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Zoomfitheight, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoZoomfitheight();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Zoomfitheight, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoZoomfitheight(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Zoomfitpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoZoomfitpage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Zoomfitpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoZoomfitpage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Zoomfitwidth, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoZoomfitwidth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Zoomfitwidth, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoZoomfitwidth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Zoom Within Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoZoomWithinRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Zoom Within Rectangle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoZoomWithinRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo File Save Selected, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFileSaveSelected();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo File Save Selected, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFileSaveSelected(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo File Openappend, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFileOpenappend();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo File Openappend, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFileOpenappend(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// Parameters:
	//		nIDEvent---I D Event, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Query New Palette, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.
	afx_msg BOOL OnQueryNewPalette();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Palette Changed, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pFocusWnd---Focus Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A0 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA0Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A0 Corner, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA0Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A0 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA0Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A0 Bezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA0Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Upright Circle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawUprightCircle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Upright Circle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawUprightCircle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Upright Rectangle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoUprightRect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Upright Rectangle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoUprightRect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A1 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA1Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A1 Bezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA1Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A1 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA1Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A1 Corner, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA1Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A1 Normal, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA1Normal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A1 Normal, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA1Normal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A1 Upright, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA1Upright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A1 Upright, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA1Upright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A2 Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA2Bezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A2 Bezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA2Bezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A2 Corner, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA2Corner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A2 Corner, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA2Corner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A2 Normal, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA2Normal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A2 Normal, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA2Normal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link A2 Upright, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkA2Upright();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link A2 Upright, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkA2Upright(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Prot Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoProtProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Prot Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoProtProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Multiselect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawMultiselect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Multiselect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawMultiselect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Char, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Key Up, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Delete Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDeleteHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Delete Helpline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDeleteHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Guides, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGuides();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Guides, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGuides(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Arc2, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawArc2();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Arc2, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawArc2(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Chord, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawChord();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Chord, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawChord(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Mirror Free, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoMirrorFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Mirror Free, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoMirrorFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Lock Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLockHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Lock Helpline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLockHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Unlock Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoUnlockHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Unlock Helpline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoUnlockHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Position Properties, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPosProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Position Properties, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPosProperties(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Dragdropallow, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDragdropallow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Dragdropallow, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDragdropallow(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Layer Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLayerProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Layer Property, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLayerProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Layer Setting, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLayerSetting();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Layer Setting, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLayerSetting(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Convert Path, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoConvertPath();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Convert Path, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoConvertPath(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Convert Polygon, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoConvertPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Convert Polygon, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoConvertPolygon(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shapes Combine, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShapesCombine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shapes Combine, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShapesCombine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shapes Dismantle, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShapesDismantle();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shapes Dismantle, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShapesDismantle(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shapes Merge Merge, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShapesMergeMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shapes Merge Merge, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShapesMergeMerge(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shapes Merge Substract, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShapesMergeSubstract();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shapes Merge Substract, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShapesMergeSubstract(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shapes Merge Intersect, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShapesMergeIntersect();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shapes Merge Intersect, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShapesMergeIntersect(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Connect Lines, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoConnectLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Connect Lines, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoConnectLines(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Break Lines, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBreakLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Break Lines, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBreakLines(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Closeshape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCloseshape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Closeshape, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCloseshape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Infront Shape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoInfrontShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Infront Shape, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoInfrontShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Behind Shape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBehindShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Behind Shape, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBehindShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Shear Free, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoShearFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Shear Free, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoShearFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Reverse Order, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoReverseOrder();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Reverse Order, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoReverseOrder(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Glue To Helpline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGlueToHelpline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Glue To Helpline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGlueToHelpline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Glue To Intersect Point, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGlueToIntersectPoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Glue To Intersect Point, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGlueToIntersectPoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Glue To Shape Spot, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGlueToShapeSpot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Glue To Shape Spot, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGlueToShapeSpot(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Fromcenter, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawFromcenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Fromcenter, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawFromcenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Captionline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawCaptionline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Captionline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawCaptionline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Rectangle Callout, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRectCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Rectangle Callout, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRectCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Round Callout, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRoundCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Round Callout, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRoundCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Cloud Callout, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawCloudCallout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Cloud Callout, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawCloudCallout(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Horizontal Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawHorzDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Horizontal Dimline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawHorzDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Vertical Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawVertDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Vertical Dimline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawVertDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Radius Dimline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRadiusDimline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Radius Dimline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRadiusDimline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Extend Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawExtLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Extend Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawExtLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Set Background, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoSetBackground();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Set Background, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoSetBackground(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Make Subgraph, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoMakeSubgraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Make Subgraph, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoMakeSubgraph(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Insertpoint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolyInsertpoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Insertpoint, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolyInsertpoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Deletepoint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolyDeletepoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Deletepoint, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolyDeletepoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Makeline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolyMakeline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Makeline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolyMakeline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Makecurve, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolyMakecurve();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Makecurve, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolyMakecurve(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Ripuppoint, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolyRipuppoint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Ripuppoint, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolyRipuppoint(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkTurncorner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link Turncorner, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkTurncorner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Link Break Center, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoLinkBreakCenter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Link Break Center, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoLinkBreakCenter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Select Ellipse, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawSelectEllipse();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Select Ellipse, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawSelectEllipse(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Pixel, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewPixel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Pixel, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewPixel(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Inch, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewInch();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Inch, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewInch(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Cm, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewCm();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Cm, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewCm(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Feet, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewFeet();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Feet, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewFeet(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Meters, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewMeters();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Meters, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewMeters(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ruler View Mm, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRulerViewMm();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ruler View Mm, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRulerViewMm(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Distribution, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDistribution();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Distribution, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDistribution(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Allow Main, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAllowMain();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Allow Main, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAllowMain(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Paint, Called to repaint a portion of the window.

	afx_msg void OnPaint();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Dialog Code, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns a UINT type value.
	afx_msg UINT OnGetDlgCode();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Menu Popup, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pMenu---pMenu, A pointer to the CMenu or NULL if the call failed.  
	//		nIndex---nIndex, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		bSysMenu---System Menu, Specifies A Boolean value.
	afx_msg void OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Makelink, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoMakelink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Makelink, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoMakelink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Normal, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewNormal();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Normal, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewNormal(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo View Editback, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoViewEditback();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo View Editback, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoViewEditback(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Richedit, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawRichedit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Richedit, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawRichedit(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Fontwork, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawFontwork();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Fontwork, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawFontwork(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Bend Free, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoBendFree();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Bend Free, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoBendFree(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fop Port Property, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFopPortProp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fop Port Property, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFopPortProp(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Ungraoup Subgraph, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoUngraoupSubgraph();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Ungraoup Subgraph, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoUngraoupSubgraph(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Extend Bezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawExtBezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Extend Bezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawExtBezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Table Shape, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawTableShape();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Table Shape, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawTableShape(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Automatic Reroute, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAutoReroute();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Automatic Reroute, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAutoReroute(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Colortheme, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoColortheme();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Colortheme, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoColortheme(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Glue To Aid Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGlueToAidLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Glue To Aid Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGlueToAidLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Glue To Newsnap Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoGlueToNewsnapLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Glue To Newsnap Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoGlueToNewsnapLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Freeform Drawing, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoFreeformDrawing();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Freeform Drawing, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoFreeformDrawing(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Curve Link, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoCurveLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Curve Link, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoCurveLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Arc Link, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoArcLink();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Arc Link, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoArcLink(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Round Link Turncorner, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoRoundLinkTurncorner();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Round Link Turncorner, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoRoundLinkTurncorner(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Polygon Smooth, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPolySmooth();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Polygon Smooth, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPolySmooth(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Pathline, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPathline();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Pathline, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPathline(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Path Polygon, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPathPolygon();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Path Polygon, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPathPolygon(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Text, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellText();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Text, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellText(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Split, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellSplit();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Split, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellSplit(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Merge, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellMerge();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Merge, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellMerge(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Fill, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellFill();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Fill, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellFill(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Delete Row, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellDelRow();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Delete Row, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellDelRow(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Delete Column, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellDelCol();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Delete Column, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellDelCol(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Addrow Before, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellAddrowBefore();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Addrow Before, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellAddrowBefore(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Addrow After, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellAddrowAfter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Addrow After, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellAddrowAfter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Addcol Before, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellAddcolBefore();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Addcol Before, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellAddcolBefore(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Addcol After, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellAddcolAfter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On New Update Fo Table Cell Addcol After, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnNewUpdateFoTableCellAddcolAfter(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Pipe Line, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawPipeLine();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Pipe Line, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawPipeLine(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Frame, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawFrame();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Frame, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawFrame(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Draw Extend Closebezier, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoDrawExtClosebezier();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Draw Extend Closebezier, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoDrawExtClosebezier(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Table Cell Linedlg, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoTableCellLinedlg();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Table Cell Linedlg, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoTableCellLinedlg(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Button Add, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoButtonAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Horizontal Adjacent, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignHorzAdjacent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Horizontal Adjacent, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignHorzAdjacent(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Alignment Vertical Adjacent, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoAlignVertAdjacent();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Alignment Vertical Adjacent, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoAlignVertAdjacent(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Property Manager, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnFoPropManager();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Fo Property Manager, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateFoPropManager(CCmdUI* pCmdUI);

	afx_msg void OnFoEditFind();
	afx_msg void OnUpdateFoEditFind(CCmdUI* pCmdUI);
	afx_msg void OnFoEditFindReplace();
	afx_msg void OnUpdateFoEditFindReplace(CCmdUI* pCmdUI);
	//}}AFX_MSG
	// Color Change
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Help Information, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pHelpInfo---Help Information, A pointer to the HELPINFO or NULL if the call failed.
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Help Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnHelpHitTest(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Edit Menu Command, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual afx_msg void OnEditMenuCommand( UINT nID );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Color Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnColorChange(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Reset Select, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wPar---wPar, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lPar---lPar, Specifies A LPARAM value.
	afx_msg LRESULT OnResetSelect(WPARAM wPar,LPARAM lPar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On View Core Message, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		WPARAM---P A R A M, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		LPARAM---P A R A M, Specifies A LPARAM value.
	afx_msg LRESULT OnViewCoreMsg(WPARAM, LPARAM);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Position, Called to notify a view that its document has been modified.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	afx_msg void OnUpdatePosition(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Mouse Position, Called to notify a view that its document has been modified.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	afx_msg void OnUpdateMousePos(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Width, Called to notify a view that its document has been modified.
	// Parameters:
	//		*pCmdUI---Cmd U I, A pointer to the CCmdUI  or NULL if the call failed.
	afx_msg void OnUpdateWidth(CCmdUI *pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Destroy Calendar, Called when CWnd is being destroyed.
	//		Returns A 32-bit LONG signed integer.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnDestroyCalendar(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CFOBaseCtrl window

class FO_EXT_CLASS CFOBaseCtrl :	public CStatic
{
	DECLARE_DYNAMIC(CFOBaseCtrl)

// Construction
public:
	CFOBaseCtrl();

// Operations
public:
	// Enable tool tip
	void EnableTooltip(BOOL bEnable = TRUE, BOOL bTooltipTrackingMode = FALSE);

	// Is tool tip enabled.
	BOOL IsTooltipEnabled() const {return m_bIsTooltip;}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOBaseCtrl)
	public:
	virtual BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID, DWORD dwStyle = WS_CHILD | WS_VISIBLE, CCreateContext* pContext = NULL);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

public:

	// Init control
	virtual void InitCtrl(const int &nType);

	// Init component.
	virtual void InitComp(const int &nRes);

	// Init component with file.
	virtual void InitCompFile(const CString &strFile);


	// Obtain rectangle.
	virtual FOPRect GetRect();

	// Set rectangle.
	virtual void SetRect(const FOPRect& rect, BOOL bRedraw = FALSE);

	// Mouse events:
	virtual BOOL OnMouseDown(int nButton, const FOPPoint& pt);
	virtual void OnMouseUp(int nButton, const FOPPoint& pt);
	virtual BOOL OnMouseDblClick(int nButton, const FOPPoint& pt);
	virtual void OnMouseMove(const FOPPoint& pt);
	virtual void OnMouseLeave();
	virtual BOOL OnMouseWheel(const FOPPoint& pt, short zDelta);
	virtual void OnCancelMode();

	virtual BOOL OnSetMouseCursor(const FOPPoint& pt);

	virtual UINT GetClickAndHoldID();
	virtual FOPRect GetClickAndHoldRect();

	virtual BOOL IsCloseOnClick(CPoint ptScreen);

	virtual void StartClickAndHold();
	virtual void StopClickAndHold();

	virtual void OnClickAndHoldEvent(UINT nID, const FOPPoint& point);

	// Keyboard events:
	virtual BOOL OnKeyboardDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	virtual BOOL OnKeyboardUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetCurrentValue();
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFODrawShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSimpleValue(const double &nValue);


	// Tooltip:
	virtual BOOL OnGetToolTip(const FOPPoint& pt, CString& strToolTip, CString& strDescr);

	// Is focused.
	BOOL IsFocused() const
	{
		return m_bIsFocused;
	}

	// Obtain shape.
	CFODrawShape *GetShape() { return m_pShape; }

// Implementation
public:
	virtual ~CFOBaseCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOBaseCtrl)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnEnable(BOOL bEnable);
	afx_msg void OnDestroy();
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnNcDestroy();
	afx_msg BOOL OnNcCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	afx_msg LRESULT OnFOPUpdateToolTips(WPARAM, LPARAM);
	afx_msg BOOL OnTTNeedTipText(UINT id, NMHDR* pNMH, LRESULT* pResult);
	afx_msg LRESULT OnFloatStatus(WPARAM, LPARAM);
	afx_msg LRESULT OnFOPPostRedraw(WPARAM, LPARAM);
	afx_msg LRESULT OnGestureEvent(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnTabletQuerySystemGestureStatus(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnPrintClient(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnGetObject(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

	static LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam);

	// Init tool tip
	void InitTooltip();
	
	// Captured.
	BOOL					m_bIsCaptured;

	// Tracked.
	BOOL					m_bIsTracked;

	// Is tool tip
	BOOL					m_bIsTooltip;

	// pointer of tool tip
	CToolTipCtrl*			m_pToolTip;

	// Tool tip cleared
	BOOL					m_bToolTipCleared;

	// Tool tip tracking mode.
	BOOL					m_bTooltipTrackingMode;

	// Last displayed tooltip
	CString					m_strLastDisplayedToolTip;

	// Last displayed tool tip description.
	CString					m_strLastDisplayedToolTipDescr;

	// Is focused
	BOOL					m_bIsFocused;

	// Dlg code
	UINT					m_nDlgCode;

	// Mouse hook
	static HHOOK			m_hookMouse;

	// In paint
	static BOOL				m_bInPaint;

	// pointer of shape.
	CFODrawShape			*m_pShape;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPDRAWWND_H__BDEE03FF_40C6_484B_A1A1_F6F664D891A2__INCLUDED_)
